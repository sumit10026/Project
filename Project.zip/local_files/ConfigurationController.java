package com.uniken.authserver.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.uniken.authserver.domains.ConfigurationRequest;
import com.uniken.authserver.domains.ConfigurationResponse;
import com.uniken.authserver.services.impl.ConfigurationServiceImpl;
import com.uniken.authserver.utility.AuthenticationUtils;
import com.uniken.authserver.utility.SessionConstants;

/**
 * This controller class handles operations related to configurations.
 * 
 * @author Kiran Borhade
 **/
@RestController
public class ConfigurationController {

    private static final Logger LOG = LoggerFactory.getLogger(ConfigurationController.class);

    @Autowired
    private ConfigurationServiceImpl configurationServiceImpl;

    /**
     * Gets the configuration.
     *
     * @param request
     *            the request
     * @param response
     *            the response
     * @param requestBody
     *            Body Params
     * @return the configurations along with accounts list
     */
    @PostMapping("/configs")
    public ResponseEntity<ConfigurationResponse> getConfigurations(final HttpServletRequest request,
            final HttpServletResponse response, @Valid @RequestBody final ConfigurationRequest requestBody) {
        try {
            // Validating Client Id in Request
            // AuthenticationUtils.validateClientId(request);

            final String webDeviceParameterChecksum = requestBody.getWebDeviceParameterChecksum();
            final String webDeviceParams = requestBody.getWebDeviceParameters();
            LOG.debug("Received browserFingerprint: {}, webDeviceParams: {}", webDeviceParameterChecksum,
                    webDeviceParams);

            request.getSession().setAttribute(SessionConstants.INIT_PARAM, true);
            AuthenticationUtils.putUserAgentInSession(webDeviceParams, request);

            LOG.info("getConfigurations() : Returning Config Successfully.");
            return ResponseEntity.ok(configurationServiceImpl.getConfigurations(request, webDeviceParameterChecksum));
        } catch (final Exception e) {
            LOG.error("getConfigurations() : Exception", e);

            request.getSession().setAttribute(SessionConstants.IS_REDIRECT_TO_ERROR_PAGE, true);

            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Gets the configuration.
     *
     * @param request
     *            the request
     * @param response
     *            the response
     * @return the Public Key for encrypting password
     */
    @PostMapping("/fetchPublicKey")
    public ResponseEntity<String> fetchPublicKey(final HttpServletRequest request, final HttpServletResponse response) {
        try {
            // Validating Client Id in Request
            AuthenticationUtils.validateClientId(request);

            LOG.info("getConfigurations() : Returning Public Key Successfully.");
            return ResponseEntity.ok(configurationServiceImpl.fetchPublicKey(request));
        } catch (final Exception e) {
            LOG.error("getConfigurations() : Exception", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

}
