package com.uniken.authserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RelIdAuthserverApplicationTests {

    @Test
    void contextLoads() {
    }

}
