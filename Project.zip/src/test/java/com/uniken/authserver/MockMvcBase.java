package com.uniken.authserver;

import static capital.scalable.restdocs.SnippetRegistry.AUTO_AUTHORIZATION;
import static capital.scalable.restdocs.SnippetRegistry.AUTO_REQUEST_FIELDS;
import static capital.scalable.restdocs.SnippetRegistry.CURL_REQUEST;
import static capital.scalable.restdocs.SnippetRegistry.HTTP_RESPONSE;
import static capital.scalable.restdocs.SnippetRegistry.REQUEST_HEADERS;
import static capital.scalable.restdocs.SnippetRegistry.REQUEST_PARAMETERS;
import static capital.scalable.restdocs.SnippetRegistry.RESPONSE_FIELDS;
import static capital.scalable.restdocs.response.ResponseModifyingPreprocessors.limitJsonArrayLength;
import static capital.scalable.restdocs.response.ResponseModifyingPreprocessors.replaceBinaryContent;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.document;
import static org.springframework.restdocs.mockmvc.MockMvcRestDocumentation.documentationConfiguration;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.preprocessResponse;
import static org.springframework.restdocs.operation.preprocess.Preprocessors.prettyPrint;
import static org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers.springSecurity;

import java.util.Arrays;
import java.util.Collection;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.extension.RegisterExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.restdocs.RestDocumentationContextProvider;
import org.springframework.restdocs.RestDocumentationExtension;
import org.springframework.restdocs.cli.CliDocumentation;
import org.springframework.restdocs.http.HttpDocumentation;
import org.springframework.restdocs.mockmvc.MockMvcRestDocumentation;
import org.springframework.restdocs.mockmvc.RestDocumentationResultHandler;
import org.springframework.restdocs.operation.Operation;
import org.springframework.restdocs.operation.preprocess.OperationResponsePreprocessor;
import org.springframework.restdocs.operation.preprocess.Preprocessors;
import org.springframework.restdocs.snippet.Snippet;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;

import capital.scalable.restdocs.AutoDocumentation;
import capital.scalable.restdocs.jackson.JacksonResultHandlers;
import capital.scalable.restdocs.response.ResponseModifyingPreprocessors;
import capital.scalable.restdocs.section.SectionBuilder;
import capital.scalable.restdocs.section.SectionSnippet;

public abstract class MockMvcBase {

    private static final String DEFAULT_AUTHORIZATION = "Basic Authentication is required.";

    @RegisterExtension
    final RestDocumentationExtension restDocumentation = new RestDocumentationExtension();

    @Autowired
    protected ObjectMapper objectMapper;

    protected MockMvc mockMvc;

    protected String[] defaultSnippetNames = new String[] { AUTO_AUTHORIZATION, AUTO_REQUEST_FIELDS, REQUEST_HEADERS,
            REQUEST_PARAMETERS, RESPONSE_FIELDS, CURL_REQUEST, HTTP_RESPONSE };

    @BeforeEach
    public void setUp(final WebApplicationContext webApplicationContext,
            final RestDocumentationContextProvider restDocumentation) throws Exception {
        this.mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).apply(springSecurity())
                .alwaysDo(JacksonResultHandlers.prepareJackson(objectMapper))
                .alwaysDo(MockMvcRestDocumentation.document("{class-name}/{method-name}",
                        Preprocessors.preprocessRequest(),
                        Preprocessors.preprocessResponse(ResponseModifyingPreprocessors.replaceBinaryContent(),
                                ResponseModifyingPreprocessors.limitJsonArrayLength(objectMapper),
                                Preprocessors.prettyPrint())))
                .apply(documentationConfiguration(restDocumentation).uris().withScheme("https")
                        .withHost("auth.relid.com").withPort(443).and().snippets()
                        .withDefaults(CliDocumentation.curlRequest(), HttpDocumentation.httpRequest(),
                                HttpDocumentation.httpResponse(), AutoDocumentation.requestHeaders(),
                                AutoDocumentation.requestFields(), AutoDocumentation.responseFields(),
                                AutoDocumentation.pathParameters(), AutoDocumentation.requestParameters(),
                                AutoDocumentation.description(), AutoDocumentation.methodAndPath(),
                                AutoDocumentation.section(), AutoDocumentation.authorization(DEFAULT_AUTHORIZATION)))
                .build();
    }

    protected RestDocumentationResultHandler commonDocumentation(final Snippet... snippets) {
        return document("{class-name}/{method-name}", commonResponsePreprocessor(), snippets);
    }

    protected OperationResponsePreprocessor commonResponsePreprocessor() {
        return preprocessResponse(replaceBinaryContent(), limitJsonArrayLength(objectMapper), prettyPrint());
    }

    static class CustomSectionSnippet extends SectionSnippet {

        private final String title;

        public CustomSectionSnippet(final Collection<String> sectionNames, final boolean skipEmpty,
                final String title) {
            super(sectionNames, skipEmpty);
            this.title = title;
        }

        @Override
        protected Map<String, Object> createModel(final Operation operation) {
            final Map<String, Object> model = super.createModel(operation);

            if (title != null) {
                model.put("title", title);
            }

            return model;
        }

    }

    public static class CustomSectionBuilder extends SectionBuilder {

        private Collection<String> snippetNames = DEFAULT_SNIPPETS;
        private final boolean skipEmpty = false;
        private String title;

        @Override
        public CustomSectionBuilder snippetNames(final String... snippetNames) {
            this.snippetNames = Arrays.asList(snippetNames);
            return this;
        }

        public CustomSectionBuilder sectionTitle(final String title) {
            this.title = title;
            return this;
        }

        public CustomSectionBuilder excludeSnippetNames(final String... snippetNames) {
            this.snippetNames.removeAll(Arrays.asList(snippetNames));
            return this;
        }

        @Override
        public SectionSnippet build() {
            return new CustomSectionSnippet(snippetNames, skipEmpty, title);
        }
    }

    public static CustomSectionBuilder customSectionBuilder() {
        return new CustomSectionBuilder();
    }

}
