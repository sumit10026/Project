package com.uniken.authserver.repo.impl;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;

@DataMongoTest
@ExtendWith(EmbeddedMongoInitExtension.class)
public class FIDO2AuthenticationIntegrationTests {
    //
    // @Autowired
    // private FIDO2AuthenticationRepository authenticationRepo;
    //
    // private static final String testuser = "dummyTestUser";
    // private static FidoAuthenticationDbRecordEntity authDbRecord;
    //
    // @BeforeAll
    // public static void initializeDB() throws IOException {
    // authDbRecord = new FidoAuthenticationDbRecordEntity(testuser,
    // "dummyLocalhost", "dummyChallenge",
    // "dummyCredentialCreationOptions", "dummyUserVerificationOptions", new
    // Date(), new Date());
    //
    // authDbRecord.setRegistrationKeyId("dummyRegisterKeyId");
    // authDbRecord.setUserId("dummyUserId");
    // authDbRecord.setW3cAuthenticatorAssertionResponse("dummyAuthenticatorAssertionResponse");
    // }
    //
    // @AfterAll
    // public static void shutdownDB() throws InterruptedException {
    // }
    //
    // @BeforeEach
    // public void setUp() throws Exception {
    // // authenticationRepo.save(authDbRecord);
    // }
    //
    // @AfterEach
    // public void tearDown() throws Exception {
    // // authenticationRepo.remove(authDbRecord);
    // }
    //
    // @Test
    // public void testFindByUsername() {
    //
    //// final Optional<FidoAuthenticationDbRecordEntity> vo =
    // authenticationRepo
    //// .findByUsername(authDbRecord.getUsername());
    //
    // assert (vo != null && vo.get() != null);
    // }
    //
    // @Test
    // public void testFindByUserId() {
    //
    // final Optional<FidoAuthenticationDbRecordEntity> vo =
    // authenticationRepo.findByUserId(authDbRecord.getUserId());
    //
    // assert (vo != null && vo.get() != null);
    // }
    //
    // @Test
    // public void testFindByChallenge() {
    //
    // final Optional<FidoAuthenticationDbRecordEntity> vo = authenticationRepo
    // .findByChallenge(authDbRecord.getChallenge());
    //
    // assert (vo != null && vo.get() != null);
    //
    // }
    //
    // @Test
    // public void testFindAllByUsername() {
    //
    // final List<FidoAuthenticationDbRecordEntity> vos = authenticationRepo
    // .findAllByUsername(authDbRecord.getUsername());
    //
    // assert (vos != null && !vos.isEmpty());
    // }
    //
    // @Test
    // public void testFindAllByUserId() {
    //
    // final List<FidoAuthenticationDbRecordEntity> vos =
    // authenticationRepo.findAllByUserId(authDbRecord.getUserId());
    //
    // assert (vos != null && !vos.isEmpty());
    // }
    //
    // @Test
    // public void testFindAllByChallenge() {
    //
    // final List<FidoAuthenticationDbRecordEntity> vos = authenticationRepo
    // .findAllByChallenge(authDbRecord.getChallenge());
    //
    // assert (vos != null && !vos.isEmpty());
    // }
    //
    // @Test
    // public void testFindAllByUsernameAndDomain() {
    //
    // final List<FidoAuthenticationDbRecordEntity> vos = authenticationRepo
    // .findAllByUsernameAndDomain(authDbRecord.getUsername(),
    // authDbRecord.getDomain());
    //
    // assert (vos != null && !vos.isEmpty());
    // }
    //
}
