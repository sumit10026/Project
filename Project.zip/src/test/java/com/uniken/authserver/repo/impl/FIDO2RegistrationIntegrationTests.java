package com.uniken.authserver.repo.impl;

import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.autoconfigure.data.mongo.DataMongoTest;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;

@DataMongoTest
@ExtendWith(EmbeddedMongoInitExtension.class)
public class FIDO2RegistrationIntegrationTests {

    // @Autowired
    // private FIDO2RegistrationRepository registrationRepo;
    //
    // private static FIDO2RegisteredAuthenticationModule fidoRegisteredModule;
    // private static final String testuser = "user19";
    //
    // @BeforeAll
    // public static void initializeDB() throws IOException {
    // fidoRegisteredModule = new
    // FIDO2RegisteredAuthenticationModule("dummyuserid", new Date(), new
    // Date(),
    // AuthType.FIDO, AuthTypeStatus.REGISTERED, "localhost", "dummyChallenge",
    // "dummyCredentialOptions",
    // "dummyPreferred");
    //
    // fidoRegisteredModule.setAuthenticatorAttestationResponse("dummyAuthenticatorAttestationResponse");
    // fidoRegisteredModule.setEcPoint("dummyECPoint");
    // fidoRegisteredModule.setRegistrationKeyId("dummyRegistrationKeyId");
    // fidoRegisteredModule.setRegistrationKeyType("dummyRegistrationKeyType");
    // fidoRegisteredModule.setCounter(1);
    // fidoRegisteredModule.setAttestationType("packed");
    // fidoRegisteredModule.setSigAlgorithmType(-7);
    //
    // }
    //
    // @AfterAll
    // public static void shutdownDB() throws InterruptedException {
    // }
    //
    // @BeforeEach
    // public void setUp() throws Exception {
    // registrationRepo.save(testuser, fidoRegisteredModule);
    // }
    //
    // @AfterEach
    // public void tearDown() throws Exception {
    // registrationRepo.remove(testuser, fidoRegisteredModule);
    // }
    //
    // @Test
    // public void testFindByPublicKeyId() {
    //
    // final Optional<FidoAuthenticationModule> fidoRegisteredModules =
    // registrationRepo.findByPublicKeyId(testuser,
    // fidoRegisteredModule.getRegistrationKeyId());
    //
    // assert (fidoRegisteredModules != null && fidoRegisteredModules.get() !=
    // null);
    // }
    //
    // @Test
    // public void testFindByUsername() {
    //
    // final Optional<FidoAuthenticationModule> vo =
    // registrationRepo.findByUsernameFromRELID(testuser);
    //
    // assert (vo != null && vo.get() != null);
    // }
    //
    // // @Test
    // // public void testFindByUserId() {
    // //
    // // final Optional<FidoAuthenticationModule> vo =
    // // registrationRepo.findByUserId(testuser,
    // // fidoRegisteredModule.getUserId());
    // //
    // // assert (vo != null && vo.get() != null);
    // // }
    //
    // @Test
    // public void testFindByChallenge() {
    //
    // final List<FidoAuthenticationModule> vo =
    // registrationRepo.findAllByChallengeFromRELID(testuser,
    // fidoRegisteredModule.getChallenge());
    //
    // assert (vo != null && !vo.isEmpty());
    //
    // }
    //
    // @Test
    // public void testFindAllByUsername() {
    //
    // final List<FidoAuthenticationModule> vo =
    // registrationRepo.findAllByUsernameFromRELID(testuser);
    //
    // assert (vo != null && !vo.isEmpty());
    // }
    //
    // // @Test
    // // public void testFindAllByUserId() {
    // //
    // // final List<FidoAuthenticationModule> vo =
    // // registrationRepo.findAllByUserId(testuser,
    // // fidoRegisteredModule.getUserId());
    // //
    // // assert (vo != null && !vo.isEmpty());
    // // }
    //
    // @Test
    // public void testFindAllByChallenge() {
    //
    // final List<FidoAuthenticationModule> vo =
    // registrationRepo.findAllByChallengeFromRELID(testuser,
    // fidoRegisteredModule.getChallenge());
    //
    // assert (vo != null && !vo.isEmpty());
    // }
    //
    // // @Test
    // // public void testFindAllByUsernameAndDomain() {
    // //
    // // final List<FidoAuthenticationModule> vo =
    // // registrationRepo.findAllByUsernameAndDomainFromRELID(testuser,
    // // fidoRegisteredModule.getDomain());
    // //
    // // assert (vo != null && !vo.isEmpty());
    // // }

}
