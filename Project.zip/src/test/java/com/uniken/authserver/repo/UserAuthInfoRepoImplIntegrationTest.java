/**
 * 
 */
package com.uniken.authserver.repo;

import java.util.Date;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.mongodb.client.result.UpdateResult;
import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.domains.enums.web.WebIdUserStatus;
import com.uniken.domains.web.user.WebId;

/**
 * @author Kushal Jaiswal
 */
@SpringBootTest
@ExtendWith(EmbeddedMongoInitExtension.class)
class UserAuthInfoRepoImplIntegrationTest {

    @Autowired
    UserAuthInfoRepo userAuthInfoRepo;

    /**
     * @throws java.lang.Exception
     */
    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @BeforeEach
    void setUp() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @AfterEach
    void tearDown() throws Exception {
    }

    /**
     * Test method for
     * {@link com.uniken.authserver.repo.impl.UserAuthInfoRepoImpl#insertWebId(java.lang.String, com.uniken.domains.web.user.WebId)}.
     */
    @Test
    final void testInsertWebIdIfValidWebIdIsProvided() {

        final String loginId = "k1";
        final WebId webId = new WebId("111-111-1111", WebIdUserStatus.CREATED, new Date(), new Date(), "1232-12123",
                "Window", new Date());

        final UpdateResult updateResult = userAuthInfoRepo.insertWebId(loginId, webId);

        Assertions.assertTrue(updateResult.getModifiedCount() > 0);

    }

    /**
     * Test method for
     * {@link com.uniken.authserver.repo.impl.UserAuthInfoRepoImpl#updateWebIdStatus(String, String, WebIdUserStatus)}.
     */
    @Test
    final void testUpdateWebIdStatusIfValidWebUUIDIsProvided() {

        final String loginId = "k1";

        final UpdateResult updateResult = userAuthInfoRepo.updateWebIdStatus(loginId, "111-111-1111",
                WebIdUserStatus.ACTIVE);

        Assertions.assertTrue(updateResult.getModifiedCount() > 0);

    }

}
