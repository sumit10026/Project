/**
 * 
 */
package com.uniken.authserver.repo;

import java.util.Collection;
import java.util.Date;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.oauth2.common.DefaultExpiringOAuth2RefreshToken;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2RefreshToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.repo.api.MongoTokenStoreRepo;
import com.uniken.authserver.utility.Constants;

/**
 * @author Kushal Jaiswal
 */
@SpringBootTest
@ExtendWith(EmbeddedMongoInitExtension.class)
public class MongoTokenStoreRepoImplIntegrationTest {

    private static final String TEST_ACCESS_TOKEN = "abca7fa3-4a72-4964-959d-1f3f89032f18";
    private static final String TEST_INVALID_ACCESS_TOKEN = "088f04b18-352e-4ac4-8ea3-d69d356a5e09";
    private static final String TEST_REFRESH_TOKEN = "7af5a5be-8565-4dfa-974b-06c33c02a2c7";
    private static final String TEST_INVALID_REFRESH_TOKEN = "ie1e02a1-2afa-4c3e-95fb-38afc82aa110";

    private static final String VALID_ACCESS_TOKEN_CLIENT_ID = "MjI5ODQwZjMtYTI2OC00ZjQ4LTk4NDAtZjNhMjY4YmY0ODkx";
    private static final String INVALID_ACCESS_TOKEN_CLIENT_ID = "invalid-client";

    @Autowired
    private MongoTokenStoreRepo tokenStoreRepoImpl;

    @BeforeAll
    static void setUpBeforeClass() {
        // Not yet implemented
    }

    @AfterAll
    static void tearDownAfterClass() {
        // Not yet implemented
    }

    @BeforeEach
    void setUp() {
        // Not yet implemented
    }

    @AfterEach
    void tearDown() {
        // Not yet implemented
    }

    @Test
    final void shouldReturnValidAuthenticationWhenGivenTokenIsPresentInDatabase() {
        // preconditions
        final String token = TEST_ACCESS_TOKEN;

        // call
        final OAuth2Authentication oAuth2Authentication = tokenStoreRepoImpl.readAuthentication(token);

        // test
        Assertions.assertNotNull(oAuth2Authentication);
    }

    @Test
    final void shouldReturnNullWhenGivenTokenIsNotPresentInDatabase() {
        // preconditions
        final String token = TEST_INVALID_ACCESS_TOKEN;

        // call
        final OAuth2Authentication oAuth2Authentication = tokenStoreRepoImpl.readAuthentication(token);

        // test
        Assertions.assertNull(oAuth2Authentication);
    }

    @Test
    final void shouldReturnValidAuthenticationWhenGivenOAuth2AccessTokenIsPresentInDatabase() {
        // preconditions
        final String token = TEST_ACCESS_TOKEN;

        // call
        final OAuth2AccessToken oAuth2AccessToken = tokenStoreRepoImpl.readAccessToken(token);
        final OAuth2Authentication oAuth2Authentication = tokenStoreRepoImpl.readAuthentication(oAuth2AccessToken);

        // test
        Assertions.assertNotNull(oAuth2Authentication);
    }

    @Test
    final void shouldReturnNullWhenGivenOAUth2AccessTokenIsNotPresentInDatabase() {
        // preconditions
        final String token = TEST_INVALID_ACCESS_TOKEN;

        // call
        final DefaultOAuth2AccessToken accessToken = new DefaultOAuth2AccessToken(token);

        final OAuth2Authentication oAuth2Authentication = tokenStoreRepoImpl.readAuthentication(accessToken);

        // test
        Assertions.assertNull(oAuth2Authentication);
    }

    // @Test
    // public void storeAccessToken(final OAuth2AccessToken token, final
    // OAuth2Authentication authentication) {
    // // TODO Auto-generated method stub
    //
    // }

    @Test
    final void shouldReturnValidOAuth2AccessTokenIfValidTokenIsPresentInDB() {

        // preconditions
        final String token = TEST_ACCESS_TOKEN;

        // call
        final OAuth2AccessToken accessToken = tokenStoreRepoImpl.readAccessToken(token);

        // test
        Assertions.assertNotNull(accessToken);
    }

    @Test
    final void shouldReturnNullOAuth2AccessTokenIfInvalidTokenIsProvided() {

        // preconditions
        final String token = TEST_INVALID_ACCESS_TOKEN;

        // call
        final OAuth2AccessToken accessToken = tokenStoreRepoImpl.readAccessToken(token);

        // test
        Assertions.assertNull(accessToken);
    }
    // @Test
    // public void removeAccessToken(final OAuth2AccessToken token) {
    // // TODO Auto-generated method stub
    //
    // }

    // @Test
    // public void storeRefreshToken(final OAuth2RefreshToken refreshToken,
    // final OAuth2Authentication authentication) {
    // // TODO Auto-generated method stub
    //
    // }

    @Test
    final void shouldReturnValidOAuth2RefreshTokenIfValidRefreshTokenIsPresentInDB() {
        // preconditions
        final String token = TEST_REFRESH_TOKEN;

        // call
        final OAuth2RefreshToken refreshToken = tokenStoreRepoImpl.readRefreshToken(token);

        // test
        Assertions.assertNotNull(refreshToken);
    }

    @Test
    final void shouldReturnNullOAuth2RefreshTokenIfInvalidRefreshTokenIsProvided() {
        // preconditions
        final String token = TEST_INVALID_REFRESH_TOKEN;

        // call
        final OAuth2RefreshToken refreshToken = tokenStoreRepoImpl.readRefreshToken(token);

        // test
        Assertions.assertNull(refreshToken);
    }

    @Test
    public void shouldReturnValidAuthenticationWhenValidRefreshTokenIsProvided() {

        // preconditions
        // Get Valid Refresh Token from DB.

        // call
        final OAuth2Authentication authentication = tokenStoreRepoImpl
                .readAuthenticationForRefreshToken(tokenStoreRepoImpl.readRefreshToken(TEST_REFRESH_TOKEN));

        // test
        Assertions.assertNotNull(authentication);
    }

    @Test
    public void shouldReturnNullAuthenticationWhenInvalidRefreshTokenIsProvided() {

        // preconditions
        // Get Valid Refresh Token from DB.

        final DefaultExpiringOAuth2RefreshToken refreshToken = new DefaultExpiringOAuth2RefreshToken(
                TEST_INVALID_REFRESH_TOKEN, new Date());

        // call
        final OAuth2Authentication authentication = tokenStoreRepoImpl.readAuthenticationForRefreshToken(refreshToken);

        // test
        Assertions.assertNull(authentication);
    }

    // @Test
    // public void removeRefreshToken(final OAuth2RefreshToken token) {
    // // TODO Auto-generated method stub
    //
    // }
    //
    // @Test
    // public void removeAccessTokenUsingRefreshToken(final OAuth2RefreshToken
    // refreshToken) {
    // // TODO Auto-generated method stub
    //
    // }

    @Test
    final void shouldReturnValidOAuth2AccessTokenIfValidOAuth2AuthenticationIsPresentInDB() {
        // call
        final OAuth2Authentication oAuth2Authentication = tokenStoreRepoImpl.readAuthentication(TEST_ACCESS_TOKEN);
        final OAuth2AccessToken accessToken = tokenStoreRepoImpl.getAccessToken(oAuth2Authentication);

        // test
        Assertions.assertNotNull(accessToken);
    }

    @Test
    final void shouldReturnNullOAuth2AccessTokenIfInvalidOAuth2AuthenticationIsProvided() {

        // call
        final String string = "{\"storedRequest\":{\"resourceIds\":[\"relid-verify-server\"],\"authorities\":[],\"approved\":true,\"responseTypes\":[],\"extensions\":{},\"clientId\":\"invalid-client\",\"scope\":[\"all\"],\"requestParameters\":{\"grant_type\":\"client_credentials\",\"scope\":\"all\"}},\"authorities\":[],\"authenticated\":false}";
        final OAuth2Authentication auth2Authentication = Constants.GSON.fromJson(string, OAuth2Authentication.class);

        final OAuth2AccessToken accessToken = tokenStoreRepoImpl.getAccessToken(auth2Authentication);

        // test
        Assertions.assertNull(accessToken);
    }

    // @Test
    // public Collection<OAuth2AccessToken>
    // findTokensByClientIdAndUserName(final String clientId, final String
    // userName) {
    // // TODO Auto-generated method stub
    // return null;
    // }

    @Test
    final void shouldReturnValidOAuth2AccessTokenListIfClientIdPresentInDB() {

        final Collection<OAuth2AccessToken> accessTokens = tokenStoreRepoImpl
                .findTokensByClientId(VALID_ACCESS_TOKEN_CLIENT_ID);

        Assertions.assertNotNull(accessTokens);
        Assertions.assertFalse(accessTokens.isEmpty());
    }

    @Test
    final void shouldReturnNullOAuth2AccessTokenListIfInvalidClientIdProvided() {

        final Collection<OAuth2AccessToken> accessTokens = tokenStoreRepoImpl
                .findTokensByClientId(INVALID_ACCESS_TOKEN_CLIENT_ID);

        Assertions.assertNotNull(accessTokens);
        Assertions.assertTrue(accessTokens.isEmpty());
    }

}
