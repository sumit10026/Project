package com.uniken.authserver.repo.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.repo.api.OidcConfigRepo;
import com.uniken.domains.auth.OIDCConfig;

@SpringBootTest
@ExtendWith(EmbeddedMongoInitExtension.class)
class OidcConfigRepoImplTest {

    @Autowired
    private OidcConfigRepo oidcConfigRepo;

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {
    }

    @BeforeEach
    void setUp() throws Exception {
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    /**
     * Should return all oidc configs.
     */
    @Test
    final void shouldReturnAllOidcConfigs() {
        final List<OIDCConfig> oidcConfigs = oidcConfigRepo.getAllOidcConfigs();

        assertNotNull(oidcConfigs, "OIDC configs are null");
        assertTrue(!oidcConfigs.isEmpty(), "OIDC configs are empty");
    }

}
