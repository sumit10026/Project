package com.uniken.authserver;

import static capital.scalable.restdocs.SnippetRegistry.AUTO_AUTHORIZATION;
import static capital.scalable.restdocs.SnippetRegistry.AUTO_REQUEST_FIELDS;
import static capital.scalable.restdocs.SnippetRegistry.AUTO_REQUEST_PARAMETERS;
import static capital.scalable.restdocs.SnippetRegistry.AUTO_RESPONSE_FIELDS;
import static capital.scalable.restdocs.SnippetRegistry.CURL_REQUEST;
import static capital.scalable.restdocs.SnippetRegistry.HTTP_RESPONSE;
import static capital.scalable.restdocs.SnippetRegistry.REQUEST_HEADERS;
import static capital.scalable.restdocs.SnippetRegistry.REQUEST_PARAMETERS;
import static capital.scalable.restdocs.SnippetRegistry.RESPONSE_FIELDS;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.springframework.restdocs.headers.HeaderDocumentation.headerWithName;
import static org.springframework.restdocs.headers.HeaderDocumentation.requestHeaders;
import static org.springframework.restdocs.payload.PayloadDocumentation.fieldWithPath;
import static org.springframework.restdocs.payload.PayloadDocumentation.responseFields;
import static org.springframework.restdocs.request.RequestDocumentation.parameterWithName;
import static org.springframework.restdocs.request.RequestDocumentation.requestParameters;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.restdocs.headers.HeaderDescriptor;
import org.springframework.restdocs.payload.FieldDescriptor;
import org.springframework.restdocs.request.ParameterDescriptor;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.jayway.jsonpath.JsonPath;
import com.uniken.authserver.config.TestDataImpl;
import com.uniken.authserver.utility.Constants;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@TestInstance(Lifecycle.PER_CLASS)
class TokenEndpointsTest extends MockMvcBase {

    private HeaderDescriptor[] headerDescriptor;
    private HttpHeaders httpHeaders;
    private static String access_token;
    private final String tokenType = "bearer";
    ClientDetails auth2Client;

    @Autowired
    TestDataImpl clientDetails;

    @BeforeAll
    void setUpBeforeClass() throws Exception {

        auth2Client = clientDetails.loadAnyOAuth2Client();
        headerDescriptor = new HeaderDescriptor[] {
                headerWithName(HttpHeaders.AUTHORIZATION).description("Basic auth credentials"),
                headerWithName(HttpHeaders.CONTENT_TYPE).description(MediaType.APPLICATION_JSON_VALUE),
                headerWithName(HttpHeaders.ACCEPT).description(MediaType.APPLICATION_JSON_VALUE) };

    }

    @BeforeEach
    void setUp() throws Exception {
        httpHeaders = new HttpHeaders();
        httpHeaders.setBasicAuth(auth2Client.getClientId(), auth2Client.getClientSecret());
        httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
    }

    @Test
    @Order(Integer.MIN_VALUE)
    void testAccessTokenApi() throws Exception {

        // preconditions
        final MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("grant_type", "client_credentials");
        params.add("scope", "all");

        // documentation
        final ParameterDescriptor[] oauthTokenRequestParameterDescriptors = new ParameterDescriptor[] {
                parameterWithName("grant_type").description("Requsted grant type"),
                parameterWithName("scope").description("Requested scope") };

        final FieldDescriptor[] oauthTokenResponseFieldDescriptors = new FieldDescriptor[] {
                fieldWithPath("access_token").description("Generated Access Token"),
                fieldWithPath("token_type").description("Type of Token"),
                fieldWithPath("expires_in").description("Expiry time in seconds"),
                fieldWithPath("scope").description("Scopes assigend to this token") };

        // call
        final MvcResult mvcResult = this.mockMvc
                .perform(post(Constants.GENERATE_ACCESS_TOKEN_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .headers(httpHeaders).params(params).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(commonDocumentation(requestHeaders(headerDescriptor),
                        requestParameters(oauthTokenRequestParameterDescriptors),
                        responseFields(oauthTokenResponseFieldDescriptors),
                        customSectionBuilder().sectionTitle("Generate Access Token")
                                .snippetNames(AUTO_AUTHORIZATION, AUTO_REQUEST_FIELDS, REQUEST_HEADERS,
                                        REQUEST_PARAMETERS, RESPONSE_FIELDS, CURL_REQUEST, HTTP_RESPONSE)
                                .build()))
                .andReturn();

        // test
        final String response = mvcResult.getResponse().getContentAsString();
        access_token = JsonPath.parse(response).read("$.access_token");
        final String responseTokenType = JsonPath.parse(response).read("$.token_type");
        final int expiresIn = JsonPath.parse(response).read("$.expires_in");
        assertNotNull(access_token);
        assertEquals(tokenType, responseTokenType);
        assertNotEquals(0, expiresIn);

    }

    @Test
    @Order(Integer.MIN_VALUE + 1)
    final void testCheckTokenApi() throws Exception {

        final MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("token", access_token);

        // documentation
        final ParameterDescriptor[] oauthTokenRequestParameterDescriptors = new ParameterDescriptor[] {
                parameterWithName("token").description("Token to check") };

        final FieldDescriptor[] oauthCheckTokenResponseFieldDescriptors = new FieldDescriptor[] {
                fieldWithPath("aud").description("Audience"), fieldWithPath("active").description("Type of Token"),
                fieldWithPath("exp").description("Expiry time in seconds"),
                fieldWithPath("scope").description("Scopes assigend to this token"),
                fieldWithPath("client_id").description("The Client ID for which token issued.") };

        // call

        // call
        final MvcResult mvcResult = this.mockMvc
                .perform(post(Constants.CHECK_TOKEN_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .headers(httpHeaders).params(params).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(commonDocumentation(requestHeaders(headerDescriptor),
                        requestParameters(oauthTokenRequestParameterDescriptors),
                        responseFields(oauthCheckTokenResponseFieldDescriptors),
                        customSectionBuilder().sectionTitle("Check Token")
                                .snippetNames(AUTO_AUTHORIZATION, AUTO_REQUEST_FIELDS, REQUEST_HEADERS,
                                        REQUEST_PARAMETERS, RESPONSE_FIELDS, CURL_REQUEST, HTTP_RESPONSE)
                                .build()))
                .andReturn();

        // test
        final String response = mvcResult.getResponse().getContentAsString();
        final boolean status = JsonPath.parse(response).read("$.active");
        final String clientId = JsonPath.parse(response).read("$.client_id");
        final int expiresIn = JsonPath.parse(response).read("$.exp");
        Assertions.assertTrue(status);
        assertNotNull(clientId);
        assertEquals(auth2Client.getClientId(), clientId);
        assertNotEquals(0, expiresIn);
    }

    @Test
    @Order(Integer.MAX_VALUE)
    void testRevokeTokenApi() throws Exception {

        // preconditions
        final MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("token", access_token);
        params.add("token_type", "access_token");

        // call
        final MvcResult mvcResult = this.mockMvc
                .perform(post(Constants.REVOKE_ACCESS_TOKEN_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .headers(httpHeaders).params(params).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andDo(commonDocumentation(requestHeaders(headerDescriptor),
                        customSectionBuilder().sectionTitle("Revoke Access Token")
                                .snippetNames(AUTO_AUTHORIZATION, AUTO_REQUEST_FIELDS, REQUEST_HEADERS,
                                        AUTO_REQUEST_PARAMETERS, AUTO_RESPONSE_FIELDS, CURL_REQUEST, HTTP_RESPONSE)
                                .build()))
                .andReturn();

        final String response = mvcResult.getResponse().getContentAsString();
        final String token = JsonPath.parse(response).read("$.token");
        final String tokenType = JsonPath.parse(response).read("$.tokenType");
        final String message = JsonPath.parse(response).read("$.message");
        assertEquals(access_token, token);
        assertEquals("access_token", tokenType);
        assertEquals("Success", message);
    }

    // @ParameterizedTest
    // @EmptySource
    // @ValueSource(strings = { "Basic ", " invalid" })
    void testAccessTokenApiInvalidAuthorizationHeader(final String authrizationHeader) throws Exception {

        // preconditions
        final MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("grant_type", "client_credentials");
        params.add("scope", "all");
        httpHeaders = new HttpHeaders();
        httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
        httpHeaders.add("Authorization", authrizationHeader);

        // call
        final MvcResult mvcResult = this.mockMvc
                .perform(post(Constants.GENERATE_ACCESS_TOKEN_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .headers(httpHeaders).params(params).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isUnauthorized()).andReturn();

        // test
        // final String response = mvcResult.getResponse().getContentAsString();
        // final String error = JsonPath.parse(response).read("$.error");
        // assertEquals("invalid_scope", error);

    }

    @Test
    @Order(Integer.MIN_VALUE + 2)
    void testAccessTokenApiInvalidScope() throws Exception {

        // preconditions
        final MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("grant_type", "client_credentials");
        params.add("scope", "invalid");

        // call
        final MvcResult mvcResult = this.mockMvc
                .perform(post(Constants.GENERATE_ACCESS_TOKEN_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .headers(httpHeaders).params(params).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest()).andReturn();

        // test
        final String response = mvcResult.getResponse().getContentAsString();
        final String error = JsonPath.parse(response).read("$.error");
        assertEquals("invalid_scope", error);

    }

    @Test
    @Order(Integer.MIN_VALUE + 3)
    void testAccessTokenApiUnsupportedGrantType() throws Exception {

        // preconditions
        final MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("grant_type", "invalid");
        params.add("scope", "all");

        // call
        final MvcResult mvcResult = this.mockMvc
                .perform(post(Constants.GENERATE_ACCESS_TOKEN_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .headers(httpHeaders).params(params).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest()).andReturn();

        // test
        final String response = mvcResult.getResponse().getContentAsString();
        final String error = JsonPath.parse(response).read("$.error");
        assertEquals("unsupported_grant_type", error);

    }

    @Test
    @Order(Integer.MIN_VALUE + 4)
    void testAccessTokenApiMissingGrantType() throws Exception {

        // preconditions
        final MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        // params.add("grant_type", "invalid");
        params.add("scope", "all");

        // call
        final MvcResult mvcResult = this.mockMvc
                .perform(post(Constants.GENERATE_ACCESS_TOKEN_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .headers(httpHeaders).params(params).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest()).andReturn();

        // test
        final String response = mvcResult.getResponse().getContentAsString();
        final String error = JsonPath.parse(response).read("$.error");
        final String errorDescription = JsonPath.parse(response).read("$.error_description");
        assertEquals("invalid_request", error);
        assertEquals("Missing grant type", errorDescription);

    }

    @Test
    @Order(Integer.MIN_VALUE + 5)
    void testRevokeTokenApiInvalidRequestMethodGet() throws Exception {

        // preconditions
        final MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("token", "test");
        params.add("token_type", "access_token");

        // call and test
        this.mockMvc
                .perform(get(Constants.REVOKE_ACCESS_TOKEN_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .headers(httpHeaders).params(params).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isMethodNotAllowed());
    }

    @Test
    @Order(Integer.MIN_VALUE + 6)
    void testRevokeTokenApiMissingParameterToken() throws Exception {

        // preconditions
        final MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        // params.add("token", "test");
        params.add("token_type", "access_token");

        // call
        final MvcResult mvcResult = this.mockMvc
                .perform(post(Constants.REVOKE_ACCESS_TOKEN_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .headers(httpHeaders).params(params).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest()).andReturn();

        // test
        final String response = mvcResult.getResponse().getContentAsString();
        final String error = JsonPath.parse(response).read("$.error");
        final String errorDescription = JsonPath.parse(response).read("$.error_description");
        assertEquals("invalid_request", error);
        assertEquals("Required String parameter 'token' is not present", errorDescription);

    }

    @Test
    @Order(Integer.MIN_VALUE + 7)
    void testRevokeTokenApiMissingParameterTokenType() throws Exception {

        // preconditions
        final MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("token", "test");
        // params.add("token_type", "access_token");

        // call
        final MvcResult mvcResult = this.mockMvc
                .perform(post(Constants.REVOKE_ACCESS_TOKEN_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .headers(httpHeaders).params(params).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest()).andReturn();

        // test
        final String response = mvcResult.getResponse().getContentAsString();
        final String error = JsonPath.parse(response).read("$.error");
        final String errorDescription = JsonPath.parse(response).read("$.error_description");
        assertEquals("invalid_request", error);
        assertEquals("Required String parameter 'token_type' is not present", errorDescription);

    }

    @Test
    @Order(Integer.MIN_VALUE + 8)
    void testRevokeTokenApiEmptyParameterToken() throws Exception {

        // preconditions
        final MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("token", "");
        params.add("token_type", "access_token");

        // call
        final MvcResult mvcResult = this.mockMvc
                .perform(post(Constants.REVOKE_ACCESS_TOKEN_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .headers(httpHeaders).params(params).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest()).andReturn();

        // test
        final String response = mvcResult.getResponse().getContentAsString();
        final String error = JsonPath.parse(response).read("$.error");
        final String errorDescription = JsonPath.parse(response).read("$.error_description");
        assertEquals("invalid_request", error);
        assertEquals("Missing token", errorDescription);

    }

    @Test
    @Order(Integer.MIN_VALUE + 9)
    void testRevokeTokenApiEmptyParameterTokenType() throws Exception {

        // preconditions
        final MultiValueMap<String, String> params = new LinkedMultiValueMap<>();
        params.add("token", "test");
        params.add("token_type", "");

        // call
        final MvcResult mvcResult = this.mockMvc
                .perform(post(Constants.REVOKE_ACCESS_TOKEN_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .headers(httpHeaders).params(params).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isBadRequest()).andReturn();

        // test
        final String response = mvcResult.getResponse().getContentAsString();
        final String error = JsonPath.parse(response).read("$.error");
        final String errorDescription = JsonPath.parse(response).read("$.error_description");
        assertEquals("invalid_request", error);
        assertEquals("Missing token type", errorDescription);

    }

}
