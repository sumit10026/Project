package com.uniken.authserver.mq.consumer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.HashMap;
import java.util.Map;

import org.bson.BsonValue;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mongodb.client.result.UpdateResult;
import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.repo.api.GenerateRVNMessageRepo;
import com.uniken.domains.relid.notification.NotificationUserActionResponse;

@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
public class NotificationUserActionResponseProcessorTest {
    private static final Logger LOG = LoggerFactory.getLogger(NotificationUserActionResponseProcessorTest.class);

    @Mock
    private GenerateRVNMessageRepo generateRVNMessageRepo;

    @InjectMocks
    private NotificationUserActionResponseProcessor notificationUserActionResponseProcessor;

    private static Map<String, Object> headers = new HashMap<String, Object>();
    private static String replyTo;
    private static String correlationId;
    private static String notificationUserActionResponse;

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {
    }

    @BeforeEach
    void setUp() throws Exception {
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    /**
     * This test-case should throws IllegalArgumentException when null
     * correlation ID found
     */
    @Test
    final void shouldThrowIllegalArgumentExceptionWhenCorrelationIDfoundToBeNull() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {

            // Precondition
            correlationId = null;

            // calling method
            notificationUserActionResponseProcessor.handleMessage(correlationId, notificationUserActionResponse,
                    replyTo, headers);

        });

        // Test
        assertEquals("Correlation ID is null or empty", exn.getMessage(), "Null correlation ID testcase");
    }

    /**
     * This test-case should throws IllegalArgumentException when empty
     * correlation ID found
     */
    @Test
    final void shouldThrowIllegalArgumentExceptionWhenCorrelationIDfoundToBeEmpty() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {

            // Precondition
            correlationId = "  ";

            // calling method
            notificationUserActionResponseProcessor.handleMessage(correlationId, notificationUserActionResponse,
                    replyTo, headers);

        });

        // Test
        assertEquals("Correlation ID is null or empty", exn.getMessage(), "Empty correlation ID testcase");
    }

    /**
     * This test-case should throws IllegalArgumentException when null
     * NotificationUserActionResponse found
     */
    @Test
    final void shouldThrowIllegalArgumentExceptionWhenNotificationUserActionResponsefoundToBeNull() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {

            // Precondition
            correlationId = "1234";
            notificationUserActionResponse = null;

            // calling method
            notificationUserActionResponseProcessor.handleMessage(correlationId, notificationUserActionResponse,
                    replyTo, headers);

        });

        // Test
        assertEquals("Notification User Action Response is null or empty", exn.getMessage(),
                "Null NotificationUserActionResponse testcase");
    }

    /**
     * This test-case should throws IllegalArgumentException when empty
     * NotificationUserActionResponse found
     */
    @Test
    final void shouldThrowIllegalArgumentExceptionWhenNotificationUserActionResponsefoundToBeEmpty() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {

            // Precondition
            correlationId = "1234";
            notificationUserActionResponse = "  ";

            // calling method
            notificationUserActionResponseProcessor.handleMessage(correlationId, notificationUserActionResponse,
                    replyTo, headers);

        });

        // Test
        assertEquals("Notification User Action Response is null or empty", exn.getMessage(),
                "Empty NotificationUserActionResponse testcase");
    }

    /**
     * This test-case should throws IllegalArgumentException when invalid json
     * NotificationUserActionResponse found
     */
    @Test
    final void shouldThrowIllegalArgumentExceptionWhenNotificationUserActionResponsefoundToBeInvalidJSON() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {

            // Precondition
            notificationUserActionResponse = "invalid json";

            // calling method
            notificationUserActionResponseProcessor.handleMessage(correlationId, notificationUserActionResponse,
                    replyTo, headers);

        });

        // Test
        assertEquals("Notification User Action Response is invalid", exn.getMessage(),
                "Invalid NotificationUserActionResponse testcase");
    }

    /**
     * This test-case handles the RVN message successfully
     */
    @Test
    final void handleRVNMessageSuccessfully() {

        // Precondition
        correlationId = "1234";
        notificationUserActionResponse = "{\"user_id\":\"user01\"}";
        final NotificationUserActionResponse response = new NotificationUserActionResponse();
        response.setActionResponse(notificationUserActionResponse);
        final UpdateResult result = new UpdateResult() {

            @Override
            public boolean wasAcknowledged() {
                return false;
            }

            @Override
            public BsonValue getUpsertedId() {
                return null;
            }

            @Override
            public long getModifiedCount() {
                return 1;
            }

            @Override
            public long getMatchedCount() {
                return 1;
            }
        };
        when(generateRVNMessageRepo.findAndSaveNotificationUserActionResponse(anyString(), any())).thenReturn(result);

        // calling method
        notificationUserActionResponseProcessor.handleMessage(correlationId, notificationUserActionResponse, replyTo,
                headers);

        // Test
        assertEquals(1, result.getModifiedCount(), "Updated successfully in database");
    }
}
