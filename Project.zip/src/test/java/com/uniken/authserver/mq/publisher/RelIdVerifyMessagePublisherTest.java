package com.uniken.authserver.mq.publisher;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.NullSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.security.oauth2.common.exceptions.InvalidRequestException;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.domains.SaveNotificationRequest;
import com.uniken.authserver.utility.Constants;

@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
public class RelIdVerifyMessagePublisherTest {

    private static final Logger LOG = LoggerFactory.getLogger(RelIdVerifyMessagePublisherTest.class);

    @Mock
    private AmqpTemplate amqpTemplate;

    @Mock
    private Constants constants;

    @InjectMocks
    private RelIdVerifyMessagePublisher rabbitMQPublisher;

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {
    }

    @BeforeEach
    void setUp() throws Exception {
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    /**
     * Should throw InvalidRequest Exception whenever payload is null
     */
    @Test
    final void shouldThrowInvalidRequestExceptionWhenInputMessageisNull() {
        LOG.info("Testcase : payload null case entered");
        final InvalidRequestException exn = assertThrows(InvalidRequestException.class, () -> {

            // Precondition
            final String payload = null;
            final String correlationId = "1234";

            // calling method
            rabbitMQPublisher.sendGenerateRVNRequestToVerify(payload, correlationId);

        });

        // Test
        assertEquals("Message payload is empty or null", exn.getMessage(), "Message payload null testcase");
    }

    /**
     * Should throw InvalidRequest Exception whenever payload is empty
     */
    @Test
    final void shouldThrowInvalidRequestExceptionWhenInputMessageisEmpty() {
        LOG.info("Testcase : payload empty case entered");
        final InvalidRequestException exn = assertThrows(InvalidRequestException.class, () -> {

            // Precondition
            final String payload = " ";
            final String correlationId = "1234";

            // calling method
            rabbitMQPublisher.sendGenerateRVNRequestToVerify(payload, correlationId);

        });

        // Test
        assertEquals("Message payload is empty or null", exn.getMessage(), "Message payload empty testcase");
    }

    /**
     * Should throw InvalidRequest Exception whenever correlation id is null
     */
    @ParameterizedTest
    @NullSource
    @EmptySource
    final void shouldThrowInvalidRequestExceptionWhenInputCorrelationIDisNullOrEmpty(final String correlationId) {
        LOG.info("Testcase : correlation id null case entered");

        final InvalidRequestException exn = assertThrows(InvalidRequestException.class, () -> {

            // Precondition
            final SaveNotificationRequest saveNotificationRequest = new SaveNotificationRequest();
            final String payload = Constants.GSON.toJson(saveNotificationRequest);

            // calling method
            rabbitMQPublisher.sendGenerateRVNRequestToVerify(payload, correlationId);

        });

        // Test
        assertEquals("CorrelationID is empty or null", exn.getMessage(), "Message correlation id null testcase");
    }

    /**
     * Should throw InvalidRequest Exception whenever incorrect json payload
     * found
     */
    @Test
    final void shouldThrowInvalidRequestExceptionWhenInputMessagewithIncorrectJSONString() {
        LOG.info("Testcase : payload incorrect case entered");
        final InvalidRequestException exn = assertThrows(InvalidRequestException.class, () -> {

            // Precondition
            final String payload = "{12333}";
            final String correlationId = "1234";

            // calling method
            rabbitMQPublisher.sendGenerateRVNRequestToVerify(payload, correlationId);

        });

        // Test
        assertEquals("Incorrect JSON : Message payload", exn.getMessage(), "Message payload incorrect json testcase");
    }

    @Test
    final void shouldPublishMessageonQueueWithSuccess() {
        LOG.info("Testcase : Publish message success case entered");

        // Precondition
        final String payload = "{mode_pref:\"REL-ID\",msg_id:\"1234\",enterprise_id:\"CBCVerify\",user_id:\"user01\",app_uuid=\"e808085f-875f-455e-8808-5f875f255e93\",app_id=\"tunneltestagent\", username:\"user01\",notification_msg:{message:\"final User has been enrolled\",subject:\"REL-final IDverify notification\"},msg:[{lng:\"English\",subject:\"Login Attempt\",message:\"You are attempting to login to Netbanking Retail\",label:{\"Accept\":\"Accept\",\"Reject\":\"Reject\"}}],expires_in:20,ds_required:\"True\",actions:[{label:\"Accept\",action:\"Accept\"},{label:\"Reject\",action:\"Reject\"}],callback_url:\"http://10.1.1.9:8443/callback/printHeaders\"}";
        final String correlationId = "1234";

        final boolean ret = rabbitMQPublisher.sendGenerateRVNRequestToVerify(payload, correlationId);

        // Test
        assertEquals(true, ret, "Message publish success testcase");
    }

}
