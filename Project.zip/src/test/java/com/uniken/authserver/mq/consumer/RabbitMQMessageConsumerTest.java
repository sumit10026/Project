package com.uniken.authserver.mq.consumer;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageProperties;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.repo.impl.ServiceLocator;
import com.uniken.authserver.utility.MQConstant;

@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
public class RabbitMQMessageConsumerTest {
    private static final Logger LOG = LoggerFactory.getLogger(RabbitMQMessageConsumerTest.class);

    @Mock
    private ServiceLocator serviceLocator;

    @Mock
    private MessageProcessor messageProcessor;

    @InjectMocks
    private RabbitMQMessageConsumer rabbitMQConsumer;

    private Message message;

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {
    }

    @BeforeEach
    void setUp() throws Exception {
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    /**
     * This test-case should throws IllegalArgumentException when null Message
     * found
     */
    @Test
    final void shouldThrowIllegalArgumentExceptionWhenMessageToBeNull() {
        LOG.info("Null Message object testcase");
        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {

            // Precondition
            message = null;

            // calling method
            rabbitMQConsumer.onMessage(message);

        });

        // Test
        assertEquals("Null message received on queue", exn.getMessage(), "Null message testcase");
    }

    /**
     * Null Service bean found test case
     */
    @Test
    final void LocateNullServiceBeanTestcaseGeneratesIllegalArgumentException() {

        LOG.info("Null Service bean object testcase");

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {

            // Precondition
            final String response = "{\"user_id\":\"user01\"}";
            final MessageProperties msgProperties = new MessageProperties();
            msgProperties.setCorrelationId("1234");
            msgProperties.setReceivedRoutingKey("incorrectroutingkey");
            message = new Message(response.getBytes(), msgProperties);

            // calling method
            rabbitMQConsumer.onMessage(message);

        });

        // Test
        assertEquals("Routing key is not registered", exn.getMessage(),
                "Invalid NotificationUserActionResponse testcase");
    }

    /**
     * Successfully located Service bean and invoked handleMessage
     */
    @Test
    final void LocatedSuccessfullyServiceBeanTestcaseInvokedHandleMessage() {

        LOG.info("Sucess testcase");

        // Precondition
        final String response = "{\"user_id\":\"user01\"}";
        final MessageProperties msgProperties = new MessageProperties();
        msgProperties.setCorrelationId("1234");
        msgProperties.setReceivedRoutingKey(MQConstant.AUTHSERVER_RECEIVING_ACTION_ROUTING_KEY);
        message = new Message(response.getBytes(), msgProperties);
        when(serviceLocator.getService(anyString())).thenReturn(messageProcessor);
        final boolean ret = true;

        // calling method
        rabbitMQConsumer.onMessage(message);

        assertEquals(true, ret, "Success testcase");
    }
}
