package com.uniken.authserver.config;

import static org.junit.jupiter.api.extension.ExtensionContext.Namespace.GLOBAL;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.junit.jupiter.api.extension.BeforeAllCallback;
import org.junit.jupiter.api.extension.ExtensionContext;

public class EmbeddedMongoInitExtension
        implements
        BeforeAllCallback,
        ExtensionContext.Store.CloseableResource {

    private static boolean started = false;
    // Gate keeper to prevent multiple Threads within the same routine
    final static Lock lock = new ReentrantLock();

    @Override
    public void beforeAll(final ExtensionContext context) throws Exception {
        // lock the access so only one Thread has access to it
        lock.lock();
        if (!started) {
            started = true;
            EmbedMongoStartupConfig.startEmbedMongo();

            // The following line registers a callback hook when the root test
            // context is shut down
            context.getRoot().getStore(GLOBAL).put("EmbeddedMongoExtension", this);
        }
        // free the access
        lock.unlock();
    }

    @Override
    public void close() throws Exception {
        // Your "after all tests" logic goes here
        EmbedMongoStartupConfig.stopEmbedMongo();
    }
}
