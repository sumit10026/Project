package com.uniken.authserver.config;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;

import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.bulk.BulkWriteResult;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.BulkWriteOptions;
import com.mongodb.client.model.InsertOneModel;

import de.flapdoodle.embed.mongo.MongoImportExecutable;
import de.flapdoodle.embed.mongo.MongoImportProcess;
import de.flapdoodle.embed.mongo.MongoImportStarter;
import de.flapdoodle.embed.mongo.MongodExecutable;
import de.flapdoodle.embed.mongo.MongodProcess;
import de.flapdoodle.embed.mongo.MongodStarter;
import de.flapdoodle.embed.mongo.config.MongoImportConfig;
import de.flapdoodle.embed.mongo.config.MongodConfig;
import de.flapdoodle.embed.mongo.config.Net;
import de.flapdoodle.embed.mongo.distribution.Version;
import de.flapdoodle.embed.process.runtime.Network;

public class EmbedMongoStartupConfig {
    private static final Logger LOG = LoggerFactory.getLogger(EmbedMongoStartupConfig.class);
    private static MongodExecutable mongodExecutable = null;
    private static final Properties testProperties = new Properties();
    private static final Properties testConfigs = new Properties();
    private static String defaultAppConfigLoaderPath = null;

    /**
     * TODO: 1. Read test application.properties for getting path of test
     * appconfigloader.properties 2. Fetch APP_CONFIG_LOADER_PATH before
     * overriding it. 3. Make port & connectionString configurable 4. DB name,
     * collection name & config JSON path should be configurable. 5. Replace new
     * APP_CONFIG_LOADER_PATH with old APP_CONFIG_LOADER_PATH & reset the envMap
     * 
     * @throws Exception
     */
    public static MongodExecutable startEmbedMongo() throws Exception {
        LOG.info("Starting Embedded Mongo =====>>>>>>>>>>>>>>");

        if (mongodExecutable == null) {
            initializeTestProperties();

            final Map<String, String> envMap = new HashMap<String, String>();
            envMap.putAll(System.getenv());

            defaultAppConfigLoaderPath = envMap.get("APP_CONFIG_LOADER_PATH");
            final String appConfigLoaderPath = new ClassPathResource(
                    testProperties.getProperty("embed.config.prop.filename")).getFile().getAbsolutePath();
            envMap.put("APP_CONFIG_LOADER_PATH", appConfigLoaderPath);
            setEnv(envMap);
            mongodExecutable = createEmbeddedMongo();
        }

        return mongodExecutable;
    }

    public static void resetAppConfigLoaderPathInEnvVariables() throws Exception {
        final Map<String, String> envMap = new HashMap<String, String>();
        envMap.putAll(System.getenv());

        envMap.put("APP_CONFIG_LOADER_PATH", defaultAppConfigLoaderPath);

        setEnv(envMap);
    }

    public static void stopEmbedMongo() throws Exception {
        LOG.info("Stopping Embedded Mongo =====>>>>>>>>>>>>>>");
        if (mongodExecutable != null) {
            mongodExecutable.stop();
        }

        if (StringUtils.isNotBlank(defaultAppConfigLoaderPath)) {
            resetAppConfigLoaderPathInEnvVariables();
        }
    }

    private static void initializeTestProperties() throws IOException {
        final InputStream iStream = new ClassPathResource("application-test.properties").getInputStream();
        testProperties.load(iStream);

        /*
         * final InputStream iStream2 = new
         * ClassPathResource("test-configs.properties").getInputStream();
         * testConfigs.load(iStream2);
         */
    }

    @SuppressWarnings({ "unchecked", "rawtypes" })
    private static void setEnv(final Map<String, String> newenv) throws Exception {
        try {
            final Class<?> processEnvironmentClass = Class.forName("java.lang.ProcessEnvironment");
            final Field theEnvironmentField = processEnvironmentClass.getDeclaredField("theEnvironment");
            theEnvironmentField.setAccessible(true);
            final Map<String, String> env = (Map<String, String>) theEnvironmentField.get(null);
            env.putAll(newenv);
            final Field theCaseInsensitiveEnvironmentField = processEnvironmentClass
                    .getDeclaredField("theCaseInsensitiveEnvironment");
            theCaseInsensitiveEnvironmentField.setAccessible(true);
            final Map<String, String> cienv = (Map<String, String>) theCaseInsensitiveEnvironmentField.get(null);
            cienv.putAll(newenv);
        } catch (final NoSuchFieldException e) {
            final Class[] classes = Collections.class.getDeclaredClasses();
            final Map<String, String> env = System.getenv();
            for (final Class cl : classes) {
                if ("java.util.Collections$UnmodifiableMap".equals(cl.getName())) {
                    final Field field = cl.getDeclaredField("m");
                    field.setAccessible(true);
                    final Object obj = field.get(env);
                    final Map<String, String> map = (Map<String, String>) obj;
                    map.clear();
                    map.putAll(newenv);
                }
            }
        }
    }

    private static MongodExecutable createEmbeddedMongo() throws IOException {

        final MongodStarter starter = MongodStarter.getDefaultInstance();

        final int port = Integer.parseInt(testProperties.getProperty("mongodb.port"));
        final String connectionString = testProperties.getProperty("mongodb.dbConnectionString");
        final String configDbName = testProperties.getProperty("mongodb.dbname");
        final String configsDbCollection = testProperties.getProperty("mongodb.collection.name");
        final MongodConfig mongodConfig = MongodConfig.builder().version(Version.Main.PRODUCTION)
                .net(new Net(port, de.flapdoodle.embed.process.runtime.Network.localhostIsIPv6())).build();
        final String authserverConfigsFileName = testProperties.getProperty("authserver.configs.json.filename");
        final String commonConfigsFileName = testProperties.getProperty("common.configs.json.filename");
        final String gmConfigsFileName = testProperties.getProperty("gm.configs.json.filename");
        final String testConfigsFileName = testProperties.getProperty("test.configs.json.filename");

        MongodExecutable mongodExecutable = null;
        try {
            mongodExecutable = starter.prepare(mongodConfig);
            final MongodProcess mongod = mongodExecutable.start();

            final MongoClientSettings clientSettings2 = MongoClientSettings.builder()
                    .applyConnectionString(new ConnectionString(connectionString)).build();
            final MongoClient client = MongoClients.create(clientSettings2);

            MongoDatabase db = null;
            MongoCollection<Document> collection = null;

            // Bulk Approach:
            db = client.getDatabase(configDbName);
            // db.createCollection("configs");

            collection = db.getCollection(configsDbCollection);
            collection.drop();

            /**
             * Using FlapDoodle Methods
             */
            // importDocToMongo(configDbName, port, configsDbCollection,
            // authserverConfigsPath);
            // importDocToMongo(configDbName, port, configsDbCollection,
            // commonConfigsPath);
            // importDocToMongo(configDbName, port, configsDbCollection,
            // testConfigsPath);

            /**
             * Json reading & Comparing Operation
             */
            // AuthServer Configuration
            // insertDocToMongo(collection, authserverConfigsPath);
            // Common Configuration
            // insertDocToMongo(collection, commonConfigsPath);

            /**
             * Json Reading & directly inserting it into EmbedMongo
             */
            insertSimpleDocToMongo(collection, authserverConfigsFileName, false);
            insertSimpleDocToMongo(collection, commonConfigsFileName, false);
            insertSimpleDocToMongo(collection, gmConfigsFileName, false);
            insertSimpleDocToMongo(collection, testConfigsFileName, true);

        } catch (final Exception e) {
            if (mongodExecutable != null) {
                mongodExecutable.stop();
            }
            LOG.error("Excepion while starting the embedded mongo : ");
            e.printStackTrace();
        }
        return mongodExecutable;
    }

    @SuppressWarnings("unused")
    private static void insertDocToMongo(final MongoCollection<Document> collection, final String filePath)
            throws FileNotFoundException, IOException {
        int count = 0;
        final int batch = 100;
        final List<InsertOneModel<Document>> docs = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            StringBuffer sb = new StringBuffer();
            boolean isOverriddenProp = false;
            String propertyKey = null;
            while ((line = br.readLine()) != null) {
                if (line.trim().startsWith("\"config_name\":")) {
                    propertyKey = line.trim().split("\"config_name\":")[1].replace(",", "").replace("\"", "").trim();

                    if (testConfigs.containsKey(propertyKey)) {
                        isOverriddenProp = true;
                    }
                }

                sb.append(line);
                if (line.equals("}")) {
                    docs.add(new InsertOneModel<>(
                            Document.parse(isOverriddenProp ? testConfigs.getProperty(propertyKey) : sb.toString())));
                    sb = new StringBuffer();
                    isOverriddenProp = false;
                    propertyKey = null;
                    count++;
                }
                if (count == batch) {
                    collection.bulkWrite(docs, new BulkWriteOptions().ordered(false));
                    docs.clear();
                    count = 0;
                }
            }
        }
        if (count > 0) {
            final BulkWriteResult bulkWriteResult = collection.bulkWrite(docs, new BulkWriteOptions().ordered(false));
            System.out.println("Inserted" + bulkWriteResult);
        }

        // Printing Docs
        /*
         * final FindIterable<Document> iterDoc1 = collection.find(); int i1 =
         * 1; // Getting the iterator final Iterator it1 = iterDoc1.iterator();
         * System.out.
         * println("Printing Configs Collection Document============>>>>>>>>>>>>>>>>>>>>>"
         * ); while (it1.hasNext()) { System.out.println(it1.next()); i1++; }
         */
    }

    private static void insertSimpleDocToMongo(final MongoCollection<Document> collection, final String fileName,
            final boolean isClasspathResource) throws FileNotFoundException, IOException {
        int count = 0;
        final int batch = 100;
        final List<InsertOneModel<Document>> docs = new ArrayList<>();

        File file = null;
        if (isClasspathResource) {
            file = new ClassPathResource(fileName).getFile();
        } else {
            file = new File("." + fileName);
        }

        try (BufferedReader br = new BufferedReader(new FileReader(file))) {
            String line;
            StringBuffer sb = new StringBuffer();

            while ((line = br.readLine()) != null) {

                sb.append(line);
                if (line.equals("}")) {
                    docs.add(new InsertOneModel<>(Document.parse(sb.toString())));
                    sb = new StringBuffer();
                    count++;
                }
                if (count == batch) {
                    collection.bulkWrite(docs, new BulkWriteOptions().ordered(false));
                    docs.clear();
                    count = 0;
                }
            }
        }
        if (count > 0) {
            final BulkWriteResult bulkWriteResult = collection.bulkWrite(docs, new BulkWriteOptions().ordered(false));
            System.out.println("Inserted" + bulkWriteResult);
        }

        // Printing Docs
        /*
         * final FindIterable<Document> iterDoc1 = collection.find(); // Getting
         * the iterator
         * @SuppressWarnings("rawtypes") final Iterator it1 =
         * iterDoc1.iterator(); System.out.
         * println("Printing Configs Collection Document============>>>>>>>>>>>>>>>>>>>>>"
         * ); while (it1.hasNext()) { System.out.println(it1.next()); }
         */
    }

    @SuppressWarnings("unused")
    private static void importDocToMongo(final String database, final int defaultConfigPort, final String collection,
            final String jsonFilePath) throws IOException {
        final MongoImportConfig mongoImportConfig = MongoImportConfig.builder().version(Version.Main.PRODUCTION)
                .net(new Net(defaultConfigPort, Network.localhostIsIPv6())).databaseName(database)
                .collectionName(collection).isUpsertDocuments(true).isDropCollection(true).isJsonArray(true)
                .importFile(jsonFilePath).build();

        final MongoImportExecutable mongoImportExecutable = MongoImportStarter.getDefaultInstance()
                .prepare(mongoImportConfig);
        final MongoImportProcess mongoImport = mongoImportExecutable.start();

        while (!mongoImport.isProcessRunning()) {
            System.out.println("Mongo Import Done =====>>>> ");
        }
    }

}
