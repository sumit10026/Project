/**
 * 
 */
package com.uniken.authserver.config;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.ClientRegistrationException;
import org.springframework.stereotype.Component;

import com.uniken.authserver.utility.Constants;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.encdecutils.PropertiesEncryptDecrypt;

/**
 * @author Kushal Jaiswal
 */
@Component
public class TestDataImpl {

    @Resource(name = Constants.RESOURCE_GMDB_MONGO_TEMPLATE)
    private final MongoTemplate gmdbMongoTemplate;

    @Autowired
    private MongoTemplate mongoTemplate;

    public TestDataImpl(final MongoTemplate gmdbMongoTemplate) {
        this.gmdbMongoTemplate = gmdbMongoTemplate;
    }

    public ClientDetails loadAnyOAuth2Client() throws ClientRegistrationException {

        final Query query = new Query(Criteria.where(EnterpriseInfo.METHOD_STR).is("OAuth2"));

        final EnterpriseInfo details = gmdbMongoTemplate.findOne(query, EnterpriseInfo.class);

        details.setClientSecret(PropertiesEncryptDecrypt.decryptWithAES(details.getClientSecret()));
        return details;
    }

}
