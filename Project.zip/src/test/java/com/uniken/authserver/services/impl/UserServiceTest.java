package com.uniken.authserver.services.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.net.HttpCookie;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.Cookie;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.CollectionUtils;

import com.google.common.collect.Sets;
import com.mongodb.client.result.UpdateResult;
import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.domains.ValidateUserRequest;
import com.uniken.authserver.exception.AttemptCounterExceededException;
import com.uniken.authserver.exception.InvalidSecureCookieException;
import com.uniken.authserver.exception.InvalidUserException;
import com.uniken.authserver.exception.SessionConflictedException;
import com.uniken.authserver.exception.ValidateUserException;
import com.uniken.authserver.repo.impl.UserAuthInfoRepoImpl;
import com.uniken.authserver.services.api.AuthenticationService;
import com.uniken.authserver.services.api.SecureCookieService;
import com.uniken.authserver.services.api.SessionService;
import com.uniken.authserver.services.api.UserService;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.SessionConstants;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.auth.fido.FIDO2RegisteredAuthenticationModule;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.WebUserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.user.RelId;
import com.uniken.domains.relid.user.UserBrowser;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.domains.user.vos.UserAuthInfoRegAuthModuleVo;
import com.uniken.domains.user.vos.WebUserDetails;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
class UserServiceTest {

    @Autowired
    ApplicationContext applicationContext;

    UserService userService;

    UserAuthInfoRepoImpl userAuthInfoRepoImpl;

    SessionService sessionService;

    SecureCookieService secureCookieService;

    AuthenticationService authenticationService;

    WebDevMasterService webDevMasterService;

    MockHttpServletRequest request;

    MockHttpServletResponse response;

    MockHttpSession session;

    ValidateUserRequest validateUserRequest = new ValidateUserRequest();

    String webDevParam = "{\"userAgent\": \"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36\", \"webdriver\": false, \"language\": \"en-US\", "
            + "\"colorDepth\": 24}";

    private static List<Integer> defaultAttemptCounter = new ArrayList<Integer>();

    @BeforeAll
    public static void initializeDefaultAttemptCounter() {
        defaultAttemptCounter = new ArrayList<Integer>(PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER);
    }

    public void resetDefaultAttemptCounter() {
        PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER.clear();
        PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER.addAll(defaultAttemptCounter);
    }

    @BeforeEach
    public void setup() throws Exception {
        MockitoAnnotations.openMocks(this);

        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
        session = new MockHttpSession();

        userService = new UserServiceImpl(applicationContext);
        userAuthInfoRepoImpl = mock(UserAuthInfoRepoImpl.class);
        sessionService = mock(SessionService.class);
        authenticationService = mock(AuthenticationService.class);
        webDevMasterService = mock(WebDevMasterService.class);
        secureCookieService = mock(SecureCookieService.class);

        ReflectionTestUtils.setField(userService, "userAuthInfoRepoImpl", userAuthInfoRepoImpl);
        ReflectionTestUtils.setField(userService, "sessionService", sessionService);
        ReflectionTestUtils.setField(userService, "authenticationService", authenticationService);
        ReflectionTestUtils.setField(userService, "webDevMasterService", webDevMasterService);
        ReflectionTestUtils.setField(userService, "secureCookieService", secureCookieService);

        resetDefaultAttemptCounter();
    }

    void prepareInitialRequest() {
        validateUserRequest = new ValidateUserRequest();
        validateUserRequest.setUserName("testUser");
        validateUserRequest.setWebDeviceParameters(webDevParam);

        session.setAttribute(EnterpriseInfo.CLIENT_ID, "test_client_id");
        request.setSession(session);
    }

    void prepareLevel1AuthRequest() {
        validateUserRequest = new ValidateUserRequest();
        validateUserRequest.setUserName("testUser");
        validateUserRequest.setWebDeviceParameters(webDevParam);
        validateUserRequest.setAuthType(AuthType.TOTP.getName());
        validateUserRequest.setAuthValue("1234");

        session.setAttribute(EnterpriseInfo.CLIENT_ID, "test_client_id");
        session.setAttribute(SessionConstants.PENDING_AUTH_TYPES,
                new HashSet<>(Arrays.asList(AuthType.TOTP.getName())));
        session.setAttribute(SessionConstants.CURRENT_USERNAME, "testUser");
        request.setSession(session);
    }

    void prepareValidSecureCookie() {
        final SecureCookieService secureCookieService = new SecureCookieServiceImpl();
        final HttpCookie httpCookie = HttpCookie.parse(secureCookieService.generateSecureCookie()).get(0);

        final Cookie cookie = new Cookie(httpCookie.getName(), httpCookie.getValue());
        request.setCookies(cookie);
    }

    WebDevMaster prepareWebDevMaster() {
        final WebDevMaster webDevMaster = new WebDevMaster("webDev1", null, null, null, null, null, null);
        return webDevMaster;
    }

    void prepareLevel2AuthRequest() {
        validateUserRequest = new ValidateUserRequest();
        validateUserRequest.setUserName("testUser");
        validateUserRequest.setWebDeviceParameters(webDevParam);
        validateUserRequest.setAuthType(AuthType.SMSOTP.getName());
        validateUserRequest.setAuthValue("6789");

        session.setAttribute(EnterpriseInfo.CLIENT_ID, "test_client_id");
        session.setAttribute(SessionConstants.PENDING_AUTH_TYPES,
                new HashSet<>(Arrays.asList(AuthType.SMSOTP.getName(), AuthType.RELID_VERIFY.getName())));
        session.setAttribute(SessionConstants.CURRENT_USERNAME, "testUser");
        request.setSession(session);
    }

    UserAuthInfoVO prepareValidUserAuthInfo() {
        final UserAuthInfoVO userAuthInfo = new UserAuthInfoVO();
        userAuthInfo.setUserStatus(RelIdUserStatus.ACTIVE);

        final List<RelId> relIdList = new ArrayList<>();
        final RelId relId = new RelId();
        relId.setRelIdStatus(RelIdUserStatus.ACTIVE);
        relIdList.add(relId);
        userAuthInfo.setRelIds(relIdList);

        final WebUserDetails webUserDetails = new WebUserDetails();
        webUserDetails.setWebUserStatus(WebUserStatus.ACTIVE);
        final UserBrowser browser = new UserBrowser();
        browser.setWebDeviceUuid("webDev1");
        webUserDetails.setBrowsers(Arrays.asList(browser));
        userAuthInfo.setWebUserDetails(webUserDetails);
        return userAuthInfo;
    }

    UserAuthInfoRegAuthModuleVo prepareUserAuthInfoRegAuthModuleVo() {
        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = new UserAuthInfoRegAuthModuleVo();
        userAuthInfoRegAuthModuleVo.setMobileNumber("9898776611");
        userAuthInfoRegAuthModuleVo.setUserStatus(RelIdUserStatus.ACTIVE);

        final List<RelId> relIdList = new ArrayList<>();
        final RelId relId = new RelId();
        relId.setRelIdStatus(RelIdUserStatus.ACTIVE);
        relIdList.add(relId);
        userAuthInfoRegAuthModuleVo.setRelIds(relIdList);

        final WebUserDetails webUserDetails = new WebUserDetails();
        webUserDetails.setWebUserStatus(WebUserStatus.ACTIVE);
        final UserBrowser browser = new UserBrowser();
        browser.setWebDeviceUuid("webDev1");
        webUserDetails.setBrowsers(Arrays.asList(browser));
        userAuthInfoRegAuthModuleVo.setWebUserDetails(webUserDetails);

        userAuthInfoRegAuthModuleVo.setRegAuthTypes(Sets.newHashSet(AuthType.SMSOTP));

        return userAuthInfoRegAuthModuleVo;
    }

    @Test
    void testValidateRequestParameters() throws Exception {

        // Validate Invalid Username
        validateUserRequest.setUserName("testUser1$");
        Exception e = assertThrows(ValidateUserException.class, () -> {
            userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        });
        assertEquals("Invalid Characters in Username", e.getMessage());

        // Validate Invalid WebDevParameters
        validateUserRequest.setUserName("testUser1");
        e = assertThrows(IllegalArgumentException.class, () -> {
            userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        });
        assertEquals("webDeviceParameters are null or empty", e.getMessage());

        // Validate Client ID
        validateUserRequest.setWebDeviceParameters(webDevParam);
        e = assertThrows(IllegalArgumentException.class, () -> {
            userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        });
        assertEquals("clientId is null or empty", e.getMessage());

        // Validate Auth Type
        session.setAttribute(EnterpriseInfo.CLIENT_ID, "test_client_id");
        request.setSession(session);
        validateUserRequest.setAuthType("TOTP");
        e = assertThrows(IllegalArgumentException.class, () -> {
            userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        });
        assertEquals("Auth Type is not valid", e.getMessage());

        // Validate Disabled Auth Type
        PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.setSmsOtp(false);
        validateUserRequest.setAuthType("smsotp");
        e = assertThrows(IllegalArgumentException.class, () -> {
            userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        });
        PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.setSmsOtp(true);
        assertEquals("System has disabled the smsotp - Auth Factor for performing authentication.", e.getMessage());
    }

    @Test
    void testInitialSignInFlow() throws Exception {
        prepareInitialRequest();

        // Validate Unregistered User
        final Exception e = assertThrows(InvalidUserException.class, () -> {
            userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        });
        assertEquals("Invalid User : User is not registered in the system", e.getMessage());

        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(prepareUserAuthInfoRegAuthModuleVo());
        assertTrue(userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest)
                .contains(AuthType.TOTP.getName()));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testLevel1SuccessAuthFlow() throws Exception {
        prepareLevel1AuthRequest();

        // Level 1 Authentication Flow
        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = prepareUserAuthInfoRegAuthModuleVo();

        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(userAuthInfoRegAuthModuleVo);
        when(authenticationService.validateUserByTOTP(request, response, validateUserRequest)).thenReturn(true);

        /**
         * After successful Level 1 Authentication, we should get Level 2
         * Authenticators.
         */
        final Set<String> pendingAuthTypes = userService.getUserAuthFactorsBasedOnUserValidity(request, response,
                validateUserRequest);
        assertTrue(pendingAuthTypes.size() >= 2);
        assertTrue(pendingAuthTypes.contains(AuthType.RELID_VERIFY.getName()));
        assertTrue(pendingAuthTypes.contains(AuthType.SMSOTP.getName()));

        /**
         * Validated Level 1 Authenticator, should be present in session inside
         * validated_auth_types parameter
         */
        assertTrue(((Set<String>) session.getAttribute(SessionConstants.VALIDATED_AUTH_TYPES))
                .contains(AuthType.TOTP.getName()));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testLevel1FailAuthFlow() throws Exception {
        prepareLevel1AuthRequest();

        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = prepareUserAuthInfoRegAuthModuleVo();

        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(userAuthInfoRegAuthModuleVo);
        when(authenticationService.validateUserByTOTP(request, response, validateUserRequest)).thenReturn(false);

        // If auth value is incorrect, then authentication should get failed.
        final Exception e = assertThrows(ValidateUserException.class, () -> {
            userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        });
        assertEquals("Incorrect TOTP", e.getMessage());

        /**
         * If authentication is failed, then that authenticator should not be
         * added in session inside validated_auth_types parameter
         */
        assertTrue(CollectionUtils.isEmpty((Set<String>) session.getAttribute(SessionConstants.VALIDATED_AUTH_TYPES)));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testLevel1AuthFlowWithValidSecureCookie() throws Exception {
        prepareLevel1AuthRequest();
        prepareValidSecureCookie();

        // Level 1 Authentication Flow
        final UserAuthInfoVO userAuthInfo = prepareValidUserAuthInfo();
        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = prepareUserAuthInfoRegAuthModuleVo();

        when(userAuthInfoRepoImpl.fetchUserDetailsFromLoginId("testUser")).thenReturn(userAuthInfo);
        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(userAuthInfoRegAuthModuleVo);
        when(webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(Mockito.anyString()))
                .thenReturn(prepareWebDevMaster());

        /**
         * After successful Level 1 Authentication, we should get Level 2
         * Authenticators.
         */
        final Set<String> pendingAuthTypes = userService.getUserAuthFactorsBasedOnUserValidity(request, response,
                validateUserRequest);
        assertTrue(pendingAuthTypes.size() >= 2);
        assertTrue(pendingAuthTypes.contains(AuthType.RELID_VERIFY.getName()));
        assertTrue(pendingAuthTypes.contains(AuthType.SMSOTP.getName()));

        /**
         * Validated Level 1 Authenticator, should be present in session inside
         * validated_auth_types parameter
         */
        assertTrue(((Set<String>) session.getAttribute(SessionConstants.VALIDATED_AUTH_TYPES))
                .contains(AuthType.SECURE_COOKIE.getName()));
    }

    @Test
    void testLevel1AuthFlowWithInvalidSecureCookie() throws Exception {
        prepareLevel1AuthRequest();
        prepareValidSecureCookie();

        // Level 1 Authentication Flow
        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = prepareUserAuthInfoRegAuthModuleVo();

        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(userAuthInfoRegAuthModuleVo);
        when(webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(Mockito.anyString())).thenReturn(null);

        final Exception e = assertThrows(InvalidSecureCookieException.class, () -> {
            userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        });
        assertEquals("Request Has Invalid Secure Cookie.", e.getMessage());
    }

    @SuppressWarnings("unchecked")
    @Test
    void testLevel1AuthFlowWithExpiredSecureCookie() throws Exception {
        prepareLevel1AuthRequest();
        prepareValidSecureCookie();

        // Level 1 Authentication Flow
        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = prepareUserAuthInfoRegAuthModuleVo();

        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(userAuthInfoRegAuthModuleVo);
        when(secureCookieService.isSecureCookieExpired(request)).thenReturn(true);
        when(authenticationService.validateUserByTOTP(request, response, validateUserRequest)).thenReturn(true);

        /**
         * After successful Level 1 Authentication, we should get Level 2
         * Authenticators.
         */
        final Set<String> pendingAuthTypes = userService.getUserAuthFactorsBasedOnUserValidity(request, response,
                validateUserRequest);
        assertTrue(pendingAuthTypes.size() >= 2);
        assertTrue(pendingAuthTypes.contains(AuthType.RELID_VERIFY.getName()));
        assertTrue(pendingAuthTypes.contains(AuthType.SMSOTP.getName()));

        /**
         * As secure cookie is expired, we should follow the Level 1
         * Authentication instead of bypassing it.
         */
        assertFalse(((Set<String>) session.getAttribute(SessionConstants.VALIDATED_AUTH_TYPES))
                .contains(AuthType.SECURE_COOKIE.getName()));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testLevel2SuccessAuthFlow() throws Exception {
        prepareLevel2AuthRequest();

        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = prepareUserAuthInfoRegAuthModuleVo();

        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(userAuthInfoRegAuthModuleVo);
        when(authenticationService.validateUserBySMSOTP(request, response, validateUserRequest)).thenReturn(true);

        userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);

        /**
         * Validated Level 2 Authenticator, should be present in session inside
         * validated_auth_types parameter
         */
        assertTrue(((Set<String>) session.getAttribute(SessionConstants.VALIDATED_AUTH_TYPES))
                .contains(AuthType.SMSOTP.getName()));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testLevel2FailAuthFlow() throws Exception {
        prepareLevel2AuthRequest();

        // Level 2 Authentication Flow
        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = prepareUserAuthInfoRegAuthModuleVo();

        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(userAuthInfoRegAuthModuleVo);
        when(authenticationService.validateUserBySMSOTP(request, response, validateUserRequest)).thenReturn(false);

        // If auth value is incorrect, then authentication should get failed.
        final Exception e = assertThrows(ValidateUserException.class, () -> {
            userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        });
        assertEquals("Incorrect SMS OTP", e.getMessage());

        /**
         * If authentication is failed, then that authenticator should not be
         * added in session inside validated_auth_types parameter
         */
        assertTrue(CollectionUtils.isEmpty((Set<String>) session.getAttribute(SessionConstants.VALIDATED_AUTH_TYPES)));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testLevel2ValidationAttemptCounterExceedCase() throws Exception {
        prepareLevel2AuthRequest();

        // Level 2 Authentication Flow
        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = prepareUserAuthInfoRegAuthModuleVo();

        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(userAuthInfoRegAuthModuleVo);

        when(authenticationService.validateUserBySMSOTP(request, response, validateUserRequest)).thenReturn(false);

        session.setAttribute(SessionConstants.VALIDATED_AUTH_TYPES,
                new HashSet<>(Arrays.asList(AuthType.TOTP.getName())));

        for (int i = PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER.get(1); i > 0; i--) {
            userAuthInfoRegAuthModuleVo.getWebUserDetails().setWebAttemptCounter(
                    Arrays.asList(PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER.get(0), i));
            if (i == 1) {
                final Exception e = assertThrows(AttemptCounterExceededException.class, () -> {
                    userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
                });
                assertEquals("Level 2 Authentication Attempt Count Exceeded.", e.getMessage());
            } else {// If auth value is incorrect, then authentication should
                    // get failed.
                final Exception e = assertThrows(ValidateUserException.class, () -> {
                    userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
                });
                assertEquals("Incorrect SMS OTP", e.getMessage());
            }
        }

        /**
         * If authentication is failed, then that authenticator should not be
         * added in session inside validated_auth_types parameter
         */
        assertTrue(!((Set<String>) session.getAttribute(SessionConstants.VALIDATED_AUTH_TYPES))
                .contains(AuthType.SMSOTP.getName()));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testAuthenticationForBlockedUserDueToLevel2AttemptCounterExceedCase() throws Exception {
        prepareLevel2AuthRequest();

        // Level 2 Authentication Flow
        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = prepareUserAuthInfoRegAuthModuleVo();

        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(userAuthInfoRegAuthModuleVo);
        when(authenticationService.validateUserBySMSOTP(request, response, validateUserRequest)).thenReturn(false);

        session.setAttribute(SessionConstants.VALIDATED_AUTH_TYPES,
                new HashSet<>(Arrays.asList(AuthType.TOTP.getName())));

        for (int i = PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER.get(1); i > 0; i--) {
            userAuthInfoRegAuthModuleVo.getWebUserDetails().setWebAttemptCounter(
                    Arrays.asList(PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER.get(0), i));
            if (i == 1) {
                final Exception e = assertThrows(AttemptCounterExceededException.class, () -> {
                    userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
                });
                assertEquals("Level 2 Authentication Attempt Count Exceeded.", e.getMessage());
            } else {// If auth value is incorrect, then authentication should
                    // get failed.
                final Exception e = assertThrows(ValidateUserException.class, () -> {
                    userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
                });
                assertEquals("Incorrect SMS OTP", e.getMessage());
            }
        }

        /**
         * Authentication Attempt for Blocked User, user should not be
         * authenticated until the completion of cooling period.
         */
        final Exception e = assertThrows(AttemptCounterExceededException.class, () -> {
            userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        });
        assertEquals("User is blocked", e.getMessage());

        /**
         * After completion of cooling period, user should be able to perform
         * authentication.
         */
        final Date blockTs = userAuthInfoRegAuthModuleVo.getWebUserDetails().getBlockedTs();
        userAuthInfoRegAuthModuleVo.getWebUserDetails()
                .setBlockedTs(Date.from(blockTs.toInstant().minus(30, ChronoUnit.MINUTES)));

        prepareLevel1AuthRequest();
        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(prepareUserAuthInfoRegAuthModuleVo());
        when(authenticationService.validateUserByTOTP(request, response, validateUserRequest)).thenReturn(true);

        userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        assertTrue(((Set<String>) session.getAttribute(SessionConstants.VALIDATED_AUTH_TYPES))
                .contains(AuthType.TOTP.getName()));

    }

    @SuppressWarnings("unchecked")
    @Test
    void testGenerationAttemptCounterForSmsOtp() throws Exception {
        prepareInitialRequest();

        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(prepareUserAuthInfoRegAuthModuleVo());
        assertTrue(userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest)
                .contains(AuthType.TOTP.getName()));

        assertTrue(!CollectionUtils.isEmpty(
                (HashMap<String, Integer>) session.getAttribute(SessionConstants.AUTH_GENERATION_ATTEMPT_COUNTER)));
    }

    @Test
    void testDeleteAccountFromChooserForValidCookie() {
        validateUserRequest.setUserName("testUser");
        prepareValidSecureCookie();
        when(secureCookieService.isSecureCookieExpired(request)).thenReturn(false);
        when(webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(Mockito.anyString()))
                .thenReturn(prepareWebDevMaster());
        when(userAuthInfoRepoImpl.fetchUserDetailsFromLoginId("testUser")).thenReturn(prepareValidUserAuthInfo());

        assertEquals(true, userService.deleteBrowserMappingForUser(request, validateUserRequest));
    }

    @Test
    void testDeleteAccountFromChooserForNoCookie() {
        validateUserRequest.setUserName("testUser");
        assertEquals(false, userService.deleteBrowserMappingForUser(request, validateUserRequest));
    }

    @Test
    void testDeleteAccountFromChooserForExpiredCookie() {
        validateUserRequest.setUserName("testUser");
        prepareValidSecureCookie();
        when(secureCookieService.isSecureCookieExpired(request)).thenReturn(true);

        assertEquals(false, userService.deleteBrowserMappingForUser(request, validateUserRequest));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testSessionConflictScenarioWithMultipleUser() throws Exception {
        prepareLevel1AuthRequest();

        // Level 1 Authentication Flow
        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = prepareUserAuthInfoRegAuthModuleVo();

        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(userAuthInfoRegAuthModuleVo);
        when(authenticationService.validateUserByTOTP(request, response, validateUserRequest)).thenReturn(true);

        /**
         * After successful Level 1 Authentication, we should get Level 2
         * Authenticators.
         */
        final Set<String> pendingAuthTypes = userService.getUserAuthFactorsBasedOnUserValidity(request, response,
                validateUserRequest);
        assertTrue(pendingAuthTypes.size() >= 2);
        assertTrue(pendingAuthTypes.contains(AuthType.RELID_VERIFY.getName()));
        assertTrue(pendingAuthTypes.contains(AuthType.SMSOTP.getName()));

        /**
         * Validated Level 1 Authenticator, should be present in session inside
         * validated_auth_types parameter
         */
        assertTrue(((Set<String>) session.getAttribute(SessionConstants.VALIDATED_AUTH_TYPES))
                .contains(AuthType.TOTP.getName()));

        // Level 2 Authentication Flow With Different User
        prepareLevel2AuthRequest();
        validateUserRequest.setUserName("testUser2");
        final Exception e = assertThrows(SessionConflictedException.class, () -> {
            userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        });
        assertEquals("Session Conflicted Between Different Users, terminating the session for User: "
                + validateUserRequest.getUserName(), e.getMessage());
    }

    @Test
    void testLevel1AttemptCounterExceedCase() throws Exception {
        prepareLevel1AuthRequest();

        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = prepareUserAuthInfoRegAuthModuleVo();

        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(userAuthInfoRegAuthModuleVo);
        when(authenticationService.validateUserByTOTP(request, response, validateUserRequest)).thenReturn(false);

        for (int i = PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER.get(0); i > 0; i--) {
            userAuthInfoRegAuthModuleVo.getWebUserDetails().setWebAttemptCounter(
                    Arrays.asList(i, PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER.get(1)));
            if (i == 1) {
                final Exception e = assertThrows(AttemptCounterExceededException.class, () -> {
                    userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
                });
                assertEquals("Level 1 Authentication Attempt Count Exceeded.", e.getMessage());
            } else {
                final Exception e = assertThrows(ValidateUserException.class, () -> {
                    userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
                });
                assertEquals("Incorrect TOTP", e.getMessage());
            }
        }
    }

    @SuppressWarnings("unchecked")
    @Test
    void testAuthenticationForBlockedUserDueToLevel1AttemptCounterExceedCase() throws Exception {
        prepareLevel1AuthRequest();

        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = prepareUserAuthInfoRegAuthModuleVo();

        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(userAuthInfoRegAuthModuleVo);
        when(authenticationService.validateUserByTOTP(request, response, validateUserRequest)).thenReturn(false);

        for (int i = PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER.get(0); i > 0; i--) {
            userAuthInfoRegAuthModuleVo.getWebUserDetails().setWebAttemptCounter(
                    Arrays.asList(i, PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER.get(1)));

            if (i == 1) {
                final Exception e = assertThrows(AttemptCounterExceededException.class, () -> {
                    userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
                });
                assertEquals("Level 1 Authentication Attempt Count Exceeded.", e.getMessage());
            } else {
                final Exception e = assertThrows(ValidateUserException.class, () -> {
                    userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
                });
                assertEquals("Incorrect TOTP", e.getMessage());
            }

        }

        /**
         * Authentication Attempt for Blocked User, user should not be
         * authenticated until the completion of cooling period.
         */
        final Exception e = assertThrows(AttemptCounterExceededException.class, () -> {
            userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        });
        assertEquals("User is blocked", e.getMessage());

        /**
         * After completion of cooling period, user should be able to perform
         * authentication.
         */
        final Date blockTs = userAuthInfoRegAuthModuleVo.getWebUserDetails().getBlockedTs();
        userAuthInfoRegAuthModuleVo.getWebUserDetails()
                .setBlockedTs(Date.from(blockTs.toInstant().minus(30, ChronoUnit.MINUTES)));

        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(prepareUserAuthInfoRegAuthModuleVo());
        when(authenticationService.validateUserByTOTP(request, response, validateUserRequest)).thenReturn(true);

        userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        assertTrue(((Set<String>) session.getAttribute(SessionConstants.VALIDATED_AUTH_TYPES))
                .contains(AuthType.TOTP.getName()));
    }

    @Test
    void testUnblockWebUser() {
        when(userAuthInfoRepoImpl.unblockWebUser(any(), any())).thenReturn(mock(UpdateResult.class));
        userService.unblockWebUser(any(), any());
        assertTrue(true);
    }

    @Test
    void testNullUserVO_getUserInfo() {
        Mockito.when(userAuthInfoRepoImpl.fetchUserDetailsFromLoginId(Mockito.anyString())).thenReturn(null);

        assertThrows(UsernameNotFoundException.class, () -> {
            userService.getUserInfo(Mockito.anyString());
        });
    }

    @Test
    void testEmptyUserVO_getUserInfo() {

        final UserAuthInfoVO userVo = new UserAuthInfoVO();

        Mockito.when(userAuthInfoRepoImpl.fetchUserDetailsFromLoginId(Mockito.anyString())).thenReturn(userVo);
        assertNotNull(userService.getUserInfo(Mockito.anyString()));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testValidDefaultAttemptCounterCase() throws Exception {

        prepareInitialRequest();

        // Initial Sign In Request, we should get default validation attempt
        // counters
        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(prepareUserAuthInfoRegAuthModuleVo());
        userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        assertTrue(PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER
                .containsAll((List<Integer>) request.getSession().getAttribute(SessionConstants.ATTEMPTS_COUNTER)));

        // Decreasing the default attempt counter
        PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER.set(0, 2);
        userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        assertEquals(2, ((List<Integer>) request.getSession().getAttribute(SessionConstants.ATTEMPTS_COUNTER)).get(0));

        // Increasing the default attempt counter
        PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER.set(0, 10);
        userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);
        assertEquals(10, ((List<Integer>) request.getSession().getAttribute(SessionConstants.ATTEMPTS_COUNTER)).get(0));
    }

    @SuppressWarnings("unchecked")
    @Test
    void testValidateAttemptCounterCaseForLevel1() throws Exception {

        prepareInitialRequest();

        // Initial Sign In Request, we should get default validation attempt
        // counters
        when(userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(Mockito.anyString()))
                .thenReturn(prepareUserAuthInfoRegAuthModuleVo());

        userService.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);

        final List<Integer> validationAttemptsCounter = (List<Integer>) request.getSession()
                .getAttribute(SessionConstants.ATTEMPTS_COUNTER);
        assertTrue(PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER.containsAll(validationAttemptsCounter));

    }

    @Test
    void testNullUsernameForFetchUserAuthInfoRegAuthModuleFromLoginId() {

        final String loginId = null;
        final List<FIDO2RegisteredAuthenticationModule> regAuthModuleList = userService
                .fetchRegisteredAuthenticationModuleFromLoginId(loginId);
        assertEquals(null, regAuthModuleList, "Registered Auth Module List is null, due to invalid username passed");

    }

    @Test
    void testValidUsernameForFetchUserAuthInfoRegAuthModuleFromLoginId() {

        final String loginId = "testUser";

        final List<FIDO2RegisteredAuthenticationModule> moduleList = new ArrayList<>();

        when(userAuthInfoRepoImpl.fetchRegisteredAuthenticationModuleFromLoginId("testUser")).thenReturn(moduleList);
        final List<FIDO2RegisteredAuthenticationModule> regAuthModuleList = userService
                .fetchRegisteredAuthenticationModuleFromLoginId(loginId);
        assertNotNull(regAuthModuleList, "Getting valid Registered Auth Module List");

    }

    @Test
    void testInvalidInputForDeleteRegisteredAuthModule() {

        final String loginId = null;
        final String regAuthTypeId = null;
        final boolean status = userService.deleteRegisteredAuthModule(loginId, regAuthTypeId);
        assertEquals(false, status, "Registered Auth Module Deletion failed due to invalid loginId & regAuthTypeId");

    }

    @Test
    void testInvalidUsernameForDeleteRegisteredAuthModule() {

        final String loginId = null;
        final String regAuthTypeId = "REG_AUTH_ID";
        final boolean status = userService.deleteRegisteredAuthModule(loginId, regAuthTypeId);
        assertEquals(false, status, "Registered Auth Module Deletion failed due to invalid loginId");

    }

    @Test
    void testInvalidRegAuthTypeIdForDeleteRegisteredAuthModule() {

        final String loginId = "testUser";
        final String regAuthTypeId = null;
        final boolean status = userService.deleteRegisteredAuthModule(loginId, regAuthTypeId);
        assertEquals(false, status, "Registered Auth Module Deletion failed due to invalid regAuthTypeId");

    }

    @Test
    void testValidInputForDeleteRegisteredAuthModule() {

        final String loginId = "testUser";
        final String regAuthTypeId = "REG_AUTH_ID";
        final boolean result = true;
        when(userAuthInfoRepoImpl.deleteRegisteredAuthModule("testUser", "REG_AUTH_ID")).thenReturn(result);
        final boolean status = userService.deleteRegisteredAuthModule(loginId, regAuthTypeId);
        assertEquals(true, status, "Registered Auth Module Deletion Successful");

    }

    @Test
    void testInvalidInputForChangeRegAuthFactorState() {

        final String loginId = null;
        final String regAuthTypeId = null;
        final boolean result = userService.updateRegAuthFactorStatus(loginId, regAuthTypeId, true);
        assertEquals(false, result,
                "Registered Auth Factor State Change failed due to invalid loginId & regAuthTypeId");

    }

    @Test
    void testInvalidUsernameForChangeRegAuthFactorState() {

        final String loginId = null;
        final String regAuthTypeId = "REG_AUTH_ID";
        final boolean status = userService.updateRegAuthFactorStatus(loginId, regAuthTypeId, true);
        assertEquals(false, status, "Registered Auth Factor State Change failed due to invalid loginId");

    }

    @Test
    void testInvalidRegAuthTypeIdForChangeRegAuthFactorState() {

        final String loginId = "testUser";
        final String regAuthTypeId = null;
        final boolean result = userService.updateRegAuthFactorStatus(loginId, regAuthTypeId, true);
        assertEquals(false, result, "Registered Auth Factor State Change failed due to invalid regAuthTypeId");

    }

    @Test
    void testValidInputForChangeRegAuthFactorState() {

        final String loginId = "testUser";
        final String regAuthTypeId = "REG_AUTH_ID";
        final boolean result = true;
        when(userAuthInfoRepoImpl.updateRegAuthFactorStatus("testUser", "REG_AUTH_ID", true)).thenReturn(result);
        final boolean status = userService.updateRegAuthFactorStatus(loginId, regAuthTypeId, true);
        assertEquals(true, status, "Registered Auth Module State Changed Successful");

    }

}
