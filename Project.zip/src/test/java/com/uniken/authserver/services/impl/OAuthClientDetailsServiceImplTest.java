package com.uniken.authserver.services.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

import java.util.UUID;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.NoSuchClientException;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.auth.EnterpriseInfo;

@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
class OAuthClientDetailsServiceImplTest {

    @Mock
    private MongoTemplate gmdbMongoTemplate;

    @InjectMocks
    private OAuthClientDetailsServiceImpl oauth2ClientDetailsService;

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {
    }

    @BeforeEach
    void setUp() throws Exception {
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    /**
     * Should throw no such client exception when enterprise info is not present
     * for given client id.
     */
    @Test
    final void shouldThrowNoSuchClientExceptionWhenEnterpriseInfoIsNotPresentForGivenClientId() {

        final String clientId = UUID.randomUUID().toString();

        final NoSuchClientException thrown = assertThrows(NoSuchClientException.class, () -> {
            // preconditions
            final EnterpriseInfo enterpriseInfo = null;
            when(gmdbMongoTemplate.findOne(any(), eq(EnterpriseInfo.class))).thenReturn(enterpriseInfo);

            // call
            oauth2ClientDetailsService.loadClientByClientId(clientId);
        });

        // test
        assertEquals(String.format("No client with requested id: %s", clientId), thrown.getMessage());
    }

    /**
     * Should return valid client details when valid client id is provided.
     */
    @Test
    final void shouldReturnValidClientDetailsWhenValidClientIdIsProvided() {

        final String clientId = "t14";

        // preconditions
        final EnterpriseInfo enterpriseInfo = Constants.GSON.fromJson(
                "{\"_id\":\"5ddfbc76611e1616312b8561\",\"enterprise_id\":\"t14\",\"method\":\"OAuth2\",\"apple_server_certificate_dev_mode\":false,\"credsUploadStatusGoogle\":\"PENDING\",\"credsUploadStatusApple\":\"PENDING\",\"resource_ids\":[\"relid-verify-server\"],\"authorized_grant_types\":[\"client_credentials\",\"refresh_token\"],\"access_token_validity_seconds\":123123,\"enable_refresh_token\":true,\"refresh_token_validity_seconds\":1000,\"client_id\":\"MmUzNmEzY2YtMDYxOC00NzQyLWI2YTMtY2YwNjE4OTc0MmNh\",\"client_secret\":\"36yfiZ8cNUkv99O8OMPNsAYmP4JX/aGNA810GfDKhh//IFye2PwstbP3/NSLyO6UvjdGr7ruEUg9tGEsRIcWxXzTis+7gKva0fwoMnrKO14=\",\"secret_required\":false,\"scoped\":false,\"scope\":[\"all\"],\"authorities\":[],\"auto_approve\":false}",
                EnterpriseInfo.class);
        when(gmdbMongoTemplate.findOne(any(), eq(EnterpriseInfo.class))).thenReturn(enterpriseInfo);

        // call
        final ClientDetails clientDetails = oauth2ClientDetailsService.loadClientByClientId(clientId);

        // test
        assertNotNull(clientDetails);
        assertNotNull(clientDetails.getClientSecret());
    }

}
