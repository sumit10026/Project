package com.uniken.authserver.services.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.util.Collections;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.exceptions.InvalidClientException;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.repo.api.AppAgentEnterpriseMappingRepo;
import com.uniken.authserver.repo.api.EnterpriseRepo;
import com.uniken.authserver.repo.api.OidcConfigRepo;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.services.api.JwtService;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.auth.AppAgentEnterpriseMapping;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.auth.OIDCConfig;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;

@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
class OpenIdAccessTokenEnhancerTest {

    @Mock
    private JwtService jwtService;

    @Mock
    private OidcConfigRepo oidcConfigRepo;

    @Mock
    private UserAuthInfoRepo userAuthInfoRepo;

    @Mock
    private EnterpriseRepo enterpriseRepo;

    @Mock
    private AppAgentEnterpriseMappingRepo appAgentEnterpriseMappingRepo;

    @InjectMocks
    private OpenIdAccessTokenEnhancer openIdAccessTokenEnhancer;

    private String userId;
    private String clientId;
    private String enterpriseId;
    private String appId;

    private DefaultOAuth2AccessToken accessToken;
    private OAuth2Authentication authentication;
    private OAuth2Request oAuth2Request;
    private EnterpriseInfo enterpriseInfo;
    private AppAgentEnterpriseMapping appAgentEnterpriseMapping;
    private OIDCConfig oidcConfig;
    private UserAuthInfoVO userAuthInfoVO;

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {
    }

    @BeforeEach
    void setUp() throws Exception {
        userId = "testuser";
        clientId = "testClientId";
        enterpriseId = "testEnterprise";
        appId = "testAppId";

        accessToken = new DefaultOAuth2AccessToken("");
        authentication = mock(OAuth2Authentication.class);
        oAuth2Request = mock(OAuth2Request.class);
        enterpriseInfo = mock(EnterpriseInfo.class);
        appAgentEnterpriseMapping = mock(AppAgentEnterpriseMapping.class);
        oidcConfig = Constants.GSON.fromJson(
                "{\"appAgentName\":\"omkarappuniken3\",\"appAgentUuid\":\"5813aced-abd9-428d-93ac-edabd9528d88\","
                        + "\"jwtConfig\":{\"kid\":\"c4ceb980-7d42-11e9-8f9e-2a86e4085a59\",\"audience\":\"Client 1\","
                        + "\"issuer\":\"https://auth.relid.temenos.com:9080/oauth2\",\"algorithm\":\"RS256\","
                        + "\"keystorePassword\":\"yKbAg8gQCyEQzO2PC6+i3A==\",\"certificateType\":\"PKCS12\",\"certificateAlias\":\"test_keystore\","
                        + "\"rsBlob\":\"MIIKKQIBAzCCCeIGCSqGSIb3DQEHAaCCCdMEggnPMIIJyzCCBXcGCSqGSIb3DQEHAaCCBWgEggVkMIIFYDCCBVwGCyqGSIb3DQEMCgECoIIE"
                        + "+zCCBPcwKQYKKoZIhvcNAQwBAzAbBBTx8Jh2rze23/HN9d2YK4h+exsO5gIDAMNQBIIEyAP/uASyRXbWXLRPvtz2/8GSqJWTuDsDGqiIvWX4QkxqQ4qoWVDMl"
                        + "SuC7O/93r6WryeaEUMf1RwA4/CrWz2XvzxNvsaHOniuvXHQIjMLP3BfN2T3MEZnuNHmX/lG+L4BdprtmFF1OZI38ZTPHHosvBpzxC0w+8+bLRzLLJU1H/cmOl"
                        + "ta2pCy8Y0SNlRlECXau0ADMxbd4QfrkRZ2gvoqVFZmLLmEW+rZlQuDE9AEQtyGiOJ1qG+KEW/K45CMHGrcwtSTQjK2mqfunO+wTwBWWQ60PM0G8QzeIIrruZP"
                        + "+zzJUxBJFyvQTjy/IhI6Mkq/JCQnH8NLdsAixlTqcRRWmqx0Sv+RT6bxy+50LWNHMYAlypT112GyYEe69d17ppT/BlkRMOjk1V2bdprdxOTkbn23qtirjkIH4"
                        + "FeD15HhtSIV4Xemw3vFTx+mk+2oRHsCDmZS0yech/bDwNjkgCbzRWSUtzuM6Lnc7HBbjK4QTBHBiGWKZBqIQToO+DJ9c43xsiUJKSAe4gA93lFB7dlZJ3uqyS"
                        + "n+IhejuQh80Jx7dt1/dhVEvFGdJ9+/sfSm1kNHf70Az3O6zKl5lo+B5ap2sacmQdgUEMPbdOxU0vvdGzsCE2Xpn5pS4sokvkP3J46bknaHo62AMohBonjI4md"
                        + "HlNhvtthj1cj2xA4ZCXtbhhtPX9j0ZX+Btc+Z5PyPnen/XLYvodINBceI1HfQPCt+GnPXzNpdkpZeH47A0uWIkxbRQfMUr0jl0cegvmQIZ/24r8AiutzTwxVT"
                        + "8gaaXWicIrqp4OaWVgOsKiJZMzKvaE5PnQ/KCR35W1gxx4Qbb2TBFx5/xsuvoNbn5YfBuPfT2Lhj2SRl4KuN+IxBBnGL3oZvu30xCrdPaxn3pYq9Ygje7snvd"
                        + "U1LTFapX3+I5hDh+9/9SQGed0J6kR0a3KsfLF8tkbTZDterlJ3DA2Lu6U3pD0q+iyJuV4jq2ix31t9IVOwSfY0Vl+OVAF6XVFqz0WD0uRB00QfZcW8ncMLY39"
                        + "TY4KObdDgI6w9f63OBeLQsedRaWR/eTeY0Ssw5+oecN8SHTfbZ1/IaPxYEhBS/7thX6mJQB0dFYUAFAifgr6JwP8uTc6qZ9yPMHuuSoXhRZjtY0DKxGnDH3L"
                        + "bIlz5ArbCsARWii7Ijc4cN2s2QzR7G3lRY/JctJoBkWRfCCrgKsK0+lsfA+YvnGDWR5nE5OSxvrEJmiGJ9M1e6iHRwby8h3KXYUBgV+RF8uuDQ9Y7CIB+n/IS"
                        + "e+X9aCqBs9e+SA8scgw7ZsuhsdoUKfsZu9cZKtXNICtQ5AlRmdiDj87PKu9NbrQFTUXCqGw6sQ5Ro2UPoQzb6/gkFWyr4ApnmbJmjpdTKvtgW4cJB6Gu/S+E+"
                        + "jJwND6ZvGyISl/yWRyhY1AAv79VYhOF9YV+Lrh/aSgrXo46irrPKK/2zOU+4jxfdwTnTc/Y+EPbiaITft3cKYzikB5NdnvvfoSC3R/nWthFcWvcqTG6gR86Gh"
                        + "Hkqe4C2I6BrG+eNdD9rN8A6vxek2DnLYKD3K0e/s1eZaH05+qaUsw2Ht08lXPfkeYhW9oaWTCF73YjrjM9HnEQEB+8Dt6BxHD4rdMnVJyFsdlb6iyuvozvBBR"
                        + "jr4lM0YKTFOMCkGCSqGSIb3DQEJFDEcHhoAdABlAHMAdABfAGsAZQB5AHMAdABvAHIAZTAhBgkqhkiG9w0BCRUxFAQSVGltZSAxNTc4OTkwNDUwNzUzMIIETA"
                        + "YJKoZIhvcNAQcGoIIEPTCCBDkCAQAwggQyBgkqhkiG9w0BBwEwKQYKKoZIhvcNAQwBBjAbBBRIxaaIqlcZJSLxP2fPctm7FqmsRwIDAMNQgIID+I+DQINg9uq"
                        + "2zm/EzRNfRyNAWCxWqeDAt3elhKTIbuWObUxubARbZKBjhCb1mEHdk/qdPT03ibRX37AhGucT1sabvjD7LVH0Reo6phDep6mCrcuznpM0hP8AVGorzPI6Tudd"
                        + "o/mU73dqVJhTf+41QPcVa9gANaf7EQPK9DZxlr7OqMZZ5v3WSGo6pRF65pfPLsme7Es3ZSJicXt28ePM51r+uD/0LH++hfYuBsYGM/dxSbwOR1Q57RgCwp1xd"
                        + "2FwbXIwlBdX+ypOJib0V7SQT43GXsExtE9BK7lE6PVONekvBAVuA4nkKYSlokd5dS82mYH34x26DbY71jMIMwKQf7udwR3xvslyImWQbZdf+JflSb7kh6HuCw"
                        + "KwMTUaak9du4PY/eLfI4AtMPTvjA3WXwb1vBvN4i8QFujyXD2OMs5GOaE4TKug261GO2SMGW/CheVNXh08BtPJLx68HcOfKiT7Eok2QNU2Kz3wojR6Dj+lb/5w"
                        + "vSghgErud6+OiAhmy7955zj+llLQgYTpezRFZlNToeCXp/3BSiRs4NwJaP1lmPpoz8vFcNOpnWxugeCf4XjQeRD51J0y3z3rnASedzOENdR2utXv4iEPqxdUCc"
                        + "Ft9Q7mD+Y2P8wy30i6UGHi5SzmxXy1Tufh1v6uXUjdo0ypzfAFNLNks2SS7L4iGyoAgp3PQ99MdsnoAtl3CLDuKGGv1Q3kyEsjWt47evRpU9H/p9GoOhVX7ZQn"
                        + "JqoUVMT+P87L9SJqC9zkjl4wUn0pDe/sz4z5CgEqVbF0HVQU2IM580q0ad5l5lAF++TH2lyQIt1a2GF5BSt1Dz81gGZTMpZ/Cs3LwKyzjqveM+TsBrjZ4YVn6L"
                        + "gUXC9KWCFUqSUvKFB6S/fxqiFXpWaFJsjAPBteCoeKPwvuJhawe/rUvW1yM+NuZbxqVKegEQXdNltsnIQAOy3p3vxmtFZU40qvikTnl3Kz9LzgLlCpMZwDihVP"
                        + "htGtt87ehDjyXzz9AkKak2AmFB/tq7ZRtBtXFi6/n5PbznFH1J1hdBZjfxE3Zs+HU5cLtJExzqUpcCWa5rxqXjcZmzUy9y31xWPXERAzvL1vZoMGhybhK3yxov"
                        + "zq/i5Jm0gFwqahsWrEDxwxgUGWFmvEGPTXj/A5T7HgBf4UKqW9NyaRdaOOFdlqJ6Enhu5PN+6XNA4U5/A0dWhmpLkasP+9WYs5IHZOA0kNBJvwm/e/U5rwTOg"
                        + "hDr5B8d63PVgOm0aJX+h4vckCx9djeGCOqixkzMhzj3yIDEt3QfWtAkGmwAVMojfD+jE4MkxLaIGNwv+xTHcU6DxPUWm6fEh4zI9U1Ylr9oENVY7H1K+feu8Y"
                        + "c3TwSxN2MD4wITAJBgUrDgMCGgUABBRJ706O0AScBxSXPRF31cXWlvrJwQQUukNRh0RSwRqvKVzTdlpU2dpV0vkCAwGGoA==\"}}",
                OIDCConfig.class);
        userAuthInfoVO = Constants.GSON.fromJson(
                "{\"user_id\":\"o28\",\"login_id\":\"o28\"," + "\"created_ts\":\"2019-07-05T12:02:18.450+0000\","
                        + "\"cipher_spec\":\"AES/256/CFB/NoPadding:SHA-256\",\"source_type\":\"RELID\",\"counter\":0,"
                        + "\"is_relId_zero_enabled\":true,\"user_status\":\"ACTIVE\",\"rel_id_type\":\"USER\","
                        + "\"primary_group_uuid\":\"c254bcfc-6d2b-49a7-94bc-fc6d2b39a749\",\"first_name\":\"à\","
                        + "\"last_name\":\"Tashildar\",\"gm_user_id\":\"sruser\",\"primary_group_name\":\"group1\","
                        + "\"secondary_group_uuids\":[],\"secondary_group_names\":[]}",
                UserAuthInfoVO.class);
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    /**
     * Should generate id token when scope is openid.
     */
    @Test
    final void shouldGenerateIdTokenWhenScopeIsOpenid() {

        // preconditions
        accessToken.setScope(Collections.singleton("openid"));
        when(authentication.getPrincipal()).thenReturn(userId);
        when(authentication.getOAuth2Request()).thenReturn(oAuth2Request);
        when(oAuth2Request.getClientId()).thenReturn(clientId);
        when(enterpriseRepo.getEnterpriseByClientId(clientId)).thenReturn(enterpriseInfo);
        when(enterpriseInfo.getEnterprise_id()).thenReturn(enterpriseId);
        when(appAgentEnterpriseMappingRepo.getAppAgentMappingByEnterpriseId(enterpriseInfo.getEnterprise_id()))
                .thenReturn(appAgentEnterpriseMapping);
        when(appAgentEnterpriseMapping.getAppId()).thenReturn(appId);
        when(oidcConfigRepo.getOidcConfigByAppAgentName(appAgentEnterpriseMapping.getAppId())).thenReturn(oidcConfig);
        when(userAuthInfoRepo.fetchUserDetailsFromLoginId(userId)).thenReturn(userAuthInfoVO);
        when(jwtService.generateEncodedJwt(any(), any(), any())).thenReturn("test");

        // call
        openIdAccessTokenEnhancer.enhance(accessToken, authentication);

        // test
        assertTrue(accessToken.getAdditionalInformation().containsKey("id_token"));
    }

    /**
     * Should not generate id token when scope is not openid.
     */
    @Test
    final void shouldNotGenerateIdTokenWhenScopeIsNotOpenid() {

        // preconditions
        accessToken.setScope(Collections.emptySet());

        // call
        openIdAccessTokenEnhancer.enhance(accessToken, authentication);

        // test
        assertFalse(accessToken.getAdditionalInformation().containsKey("id_token"));
    }

    /**
     * Should throw invalid client exception when app agent mapping is not
     * present.
     */
    @Test
    final void shouldThrowInvalidClientExceptionWhenAppAgentMappingIsNotPresent() {

        final InvalidClientException thrown = assertThrows(InvalidClientException.class, () -> {
            // preconditions
            accessToken.setScope(Collections.singleton("openid"));
            when(authentication.getPrincipal()).thenReturn(userId);
            when(authentication.getOAuth2Request()).thenReturn(oAuth2Request);
            when(oAuth2Request.getClientId()).thenReturn(clientId);
            when(enterpriseRepo.getEnterpriseByClientId(clientId)).thenReturn(enterpriseInfo);
            when(enterpriseInfo.getEnterprise_id()).thenReturn(enterpriseId);

            // call
            openIdAccessTokenEnhancer.enhance(accessToken, authentication);
        });

        // test
        assertEquals("Client is not configured for scope openid", thrown.getMessage());
    }

    /**
     * Should throw invalid client exception when OIDC config is not present.
     */
    @Test
    final void shouldThrowInvalidClientExceptionWhenOIDCConfigIsNotPresent() {

        final InvalidClientException thrown = assertThrows(InvalidClientException.class, () -> {
            // preconditions
            accessToken.setScope(Collections.singleton("openid"));
            when(authentication.getPrincipal()).thenReturn(userId);
            when(authentication.getOAuth2Request()).thenReturn(oAuth2Request);
            when(oAuth2Request.getClientId()).thenReturn(clientId);
            when(enterpriseRepo.getEnterpriseByClientId(clientId)).thenReturn(enterpriseInfo);
            when(enterpriseInfo.getEnterprise_id()).thenReturn(enterpriseId);
            when(appAgentEnterpriseMappingRepo.getAppAgentMappingByEnterpriseId(enterpriseInfo.getEnterprise_id()))
                    .thenReturn(appAgentEnterpriseMapping);
            when(appAgentEnterpriseMapping.getAppId()).thenReturn(appId);
            when(oidcConfigRepo.getOidcConfigByAppAgentName(appAgentEnterpriseMapping.getAppId()))
                    .thenReturn(mock(OIDCConfig.class));

            // call
            openIdAccessTokenEnhancer.enhance(accessToken, authentication);
        });

        // test
        assertEquals("Client is not configured for scope openid", thrown.getMessage());
    }

    /**
     * Should throw invalid client exception when JWT config is not present.
     */
    @Test
    final void shouldThrowInvalidClientExceptionWhenJWTConfigIsNotPresent() {

        final InvalidClientException thrown = assertThrows(InvalidClientException.class, () -> {
            // preconditions
            accessToken.setScope(Collections.singleton("openid"));
            when(authentication.getPrincipal()).thenReturn(userId);
            when(authentication.getOAuth2Request()).thenReturn(oAuth2Request);
            when(oAuth2Request.getClientId()).thenReturn(clientId);
            when(enterpriseRepo.getEnterpriseByClientId(clientId)).thenReturn(enterpriseInfo);
            when(enterpriseInfo.getEnterprise_id()).thenReturn(enterpriseId);
            when(appAgentEnterpriseMappingRepo.getAppAgentMappingByEnterpriseId(enterpriseInfo.getEnterprise_id()))
                    .thenReturn(appAgentEnterpriseMapping);
            when(appAgentEnterpriseMapping.getAppId()).thenReturn(appId);

            // call
            openIdAccessTokenEnhancer.enhance(accessToken, authentication);
        });

        // test
        assertEquals("Client is not configured for scope openid", thrown.getMessage());
    }

}
