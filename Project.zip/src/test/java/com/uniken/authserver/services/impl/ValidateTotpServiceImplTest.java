package com.uniken.authserver.services.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.NullSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.common.exceptions.InvalidClientException;
import org.springframework.security.oauth2.common.exceptions.InvalidScopeException;
import org.springframework.security.oauth2.common.exceptions.UnauthorizedUserException;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.domains.TOTPValidationLog;
import com.uniken.authserver.repo.api.TOTPValidationRepo;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.services.api.OAuth2ClientDetailsService;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.TotpInitializer;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.totp.domains.SeedDetails;
import com.uniken.totp.enums.TOTPHmacSpecs;
import com.uniken.totp.exception.TOTPValidationException;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
public class ValidateTotpServiceImplTest {

    @Mock
    OAuth2ClientDetailsService OAuthClientDetailsService;

    @Mock
    UserAuthInfoRepo userAuthInfoRepo;

    @InjectMocks
    private ValidateTotpServiceImpl validateTotpServiceImpl;

    @Autowired
    TotpInitializer totpInitializer;

    @Mock
    TOTPValidationRepo totValidationRepo;

    final HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse response = null;
    private final MockHttpSession mockSession = Mockito.mock(MockHttpSession.class);
    final Date date = Mockito.mock(Date.class);

    Map<String, Object> params = new HashMap<>();

    final String clientId = "5678gbjkyghj";
    final String testUsername = "testUser";
    final String testTotp = "98989898";
    final String scopeString = "all";
    final String resourceIdsString = "[\"relid-verify-server\"]";
    final static SeedDetails testSeedDetails = new SeedDetails();
    static List<SeedDetails> seedDetailsList = new ArrayList<>();

    EnterpriseInfo clientDetails = Constants.GSON
            .fromJson("{\"_id\":ObjectId(\"5dfca4ab8065a92ca3f533af\"),\"enterprise_id\":\"test02\","
                    + "\"method\":\"OAuth2\",\"apple_server_certificate_dev_mode\":false,"
                    + "\"credsUploadStatusGoogle\":\"PENDING\",\"credsUploadStatusApple\":\"PENDING\","
                    + "\"resource_ids\":[\"OIDC\"],"
                    + "\"authorized_grant_types\":[\"client_credentials\",\"referesh_token\"],"
                    + "\"access_token_validity_seconds\":8765,\"enable_refresh_token\":true,"
                    + "\"refresh_token_validity_seconds\":8876,"
                    + "\"client_id\":\"ODQ3N2ZlYTYtY2U5OC00MTc4LWI3ZmUtYTZjZTk4NzE3OGRj\","
                    + "\"client_secret\":\"iq7Kip8aZU9+p9ThZZeZ4WLmJzEUMUvNVcK8Fmin/0ocpfoqcn+zufex96s748PiTq7PMKJsyR1Zzp/1s3dREjRmPGR+yjizL5rWY6e7TPI=\","
                    + "\"secret_required\":false,\"scoped\":false,\"scope\":[\"all\"],"
                    + "\"registered_redirect_uri\":[\"http://localhost:8080/GM/enterprise-management.htm\"],"
                    + "\"registered_error_uri\":[\"http://localhost:8080/GM/enterprise-management.htm\"],"
                    + "\"authorities\":[],\"auto_approve\":false}", EnterpriseInfo.class);

    UserAuthInfoVO user = Constants.GSON.fromJson(
            "{\"user_uuid\":\"3b6e732a-298e-4523-ae73-2a298e352383\",\"privacy_key\":\"59fcc73c0ecbd3b8f5c3502aa59b4244b86346abe7f2080a3f92fbc14f0634e4\","
                    + "\"user_id\":\"testUser\",\"login_id\":\"testUser\","
                    + "\"relids\":[{\"relid_uuid\":\"b6f3e241-6cdd-4c59-b3e2-416cddfc5985\",\"relid_version\":\"v6\","
                    + "\"relid_client\":\"DATA_STORED_ON_SECURE_STORAGE\",\"relid_status\":\"ACTIVE\","
                    + "\"relid_created_ts\":\"2019-12-24T11:11:44.744+0000\",\"relid_updated_ts\":\"2019-12-24T11:12:08.591+0000\","
                    + "\"cipher_salt\":\"SgyVKBg32YpsKCaXomzgoNllzKLxiATC7sd3UqEC15A=\","
                    + "\"password_attempts_left\":3,\"dev_uuid\":\"6COKQTXDOCYIE23H7Z1UHS4Z4IAWHQKSION4Q7CJNZ2TRD5UOA\","
                    + "\"dev_name\":\"Android_SM-M205F_122419164203\",\"dev_platform\":\"Android\","
                    + "\"dev_type\":\"SECURED\",\"app_uuid\":\"3f8dee2a-2fc9-4852-8dee-2a2fc9e852bb\","
                    + "\"hmac_index_val\":18,\"old_passwords\":[\"\"],"
                    + "\"password_hash\":\"DATA_STORED_ON_SECURE_STORAGE\",\"password_updated_ts\":\"2019-12-24T11:12:08.558+0000\","
                    + "\"dev_last_accessed_ts\":\"2019-12-24T11:12:08.936+0000\","
                    + "\"dev_token\":\"fFXl---4Phk:APA91bEeALMY24_JrP4wCHQvqh0We02u1Gt4xA-rexsgsF-K0sZGY43JxPNhVkwBQsi_XXmIkaCXZsq4gWjtB1YEpE6e3WdrY6oaxl22nVOF9-blJqj3744TLTDNlBgXv92L1KduSYTO\","
                    + "\"hmac\":\"SHA512\",\"totp_seed\":\"PRfc+OB+DsKapruTUgO5Ov+ceUbd417/DToE2dwVbY97YOMrzk7CGljyfXaM4V4qDyNLd2iaVJ46Tx1Ql37JkA==\","
                    + "\"certificate\":\"LS0tLS1CRUdJTiBDRVJUSUZJQ0FURS0tLS0tCk1JSUNzVENDQVptZ0F3SUJBZ0lCQURBTkJna3Foa2lHOXcwQkFRc0ZBREFsTVJNd0VRWURWUVFLREFwVlRrbEwKUlU0Z1NVNURNUTR3REFZRFZRUUREQVZTUlV4SlJEQWVGdzB4T1RFeU1qUXhNVEF5TURWYUZ3MHlNREV5TWpNeApNVEV5TURWYU1CTXhFVEFQQmdOVkJBTU1DSFJsYzNSVmMyVnlNSUlCSWpBTkJna3Foa2lHOXcwQkFRRUZBQU9DCkFROEFNSUlCQ2dLQ0FRRUF1UlVDYTFzWkNOZWdCQjRkVGNUK20rSDZwRlFDR0lTTjFZUllvT3RNVDdnQXkzY0kKcnZaeVdScm91SzgzenArQ3JXMmNLNEczRWJ4eEtIR1R2cHdtZHJGY3ZBbnFQNXp1RUcwK0hGYXZFN3gwZDBwLwpkRVNzWXhJMTdJaDBiZjdzbTNJZUc3Z0pSTElYMUkySjNUZXBIRk94YTVhclViOHNhbk1ic3JVUEN3ME94VG1QCjVOSVdhR1hkb3lIcHUrRTd2d0tUbUl1UXZ1ZlpUYlZtMjZLczJGWThUUCtEYlhkb0x4Y0wwQ0hDMG9DOEJCdXAKcVNtbm5JT0lQdjZueEVlWENYMk5QQXFDNU5JcWF0Z1AxeGZiT0g4MWNBN0QxSkM0RjFzRjd2SS9YRFhTTTdoSApzdlJQQWNXQzlJTUZtRUFyZmpSM2NxOTg1Z2FuV3N4Sy9weE0yd0lEQVFBQk1BMEdDU3FHU0liM0RRRUJDd1VBCkE0SUJBUUNleTVDVU1tb1hxR0VlU0wxY0hTTkhwbjVQcFJoWCtDeWhxMjYxNXpMd0l6TWJ5TmlRQTB3ZU1GdksKc1IrbHJPcE50dnBSOFppbWU2czRWMFphYXZ0eG5PZWt0TFRGVjFpV2NQbng5b0ZrL1FwZXRSVUJzR2Z5RnFEYgphbTRETCtQSVhNa1M0SlR2a2VJc2t6YllUeklkRTJOb01RYWNpc2tBQk1QSWdDQzRyRVpFc2JhcDR0NUh0Q0dEClZ4U1pyRUxHTWNzNlJQSjFhWURLbmNVYmowY0NkZCtCTGM5NGZHdUtYSU5pVS9XeVMxeXlKa1AxWWlpUnhZY2wKYjNNMWdXSTAzR3lFVmwyWHFPUldOamYrT0lySk0yTXNJZkNLcUNGR2pacjJyUFNDWHlTVllzaS9yMU9DdWdCLwpuRGduL2N6cCtPUGh6MXVtUDVGYjE3b2MwY3UrCi0tLS0tRU5EIENFUlRJRklDQVRFLS0tLS0K\"}],"
                    + "\"created_ts\":\"2019-12-19T07:52:15.536+0000\",\"updated_ts\":\"2019-12-24T11:12:08.591+0000\","
                    + "\"cipher_spec\":\"AES/256/CFB/NoPadding:SHA-256\",\"source_type\":\"RELID\","
                    + "\"counter\":0,\"is_relId_zero_enabled\":true,"
                    + "\"user_status\":\"ACTIVE\",\"rel_id_type\":\"USER\","
                    + "\"primary_group_uuid\":\"5e73657d-adaf-4861-b365-7dadaf386184\","
                    + "\"email_id\":\"abhinay.kumar@uniken.com\",\"mobile_number\":\"\","
                    + "\"first_name\":\"\",\"last_name\":\"\",\"gm_user_id\":\"gmuser\","
                    + "\"primary_group_name\":\"group\",\"secondary_group_uuids\":[],"
                    + "\"secondary_group_names\":[],\"last_accessed_dev_uuid\":\"6COKQTXDOCYIE23H7Z1UHS4Z4IAWHQKSION4Q7CJNZ2TRD5UOA\","
                    + "\"last_accessed_ts\":\"2019-12-24T11:12:08.936+0000\"}",
            UserAuthInfoVO.class);

    // Constants.setTotpEnabledAppAgents();

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
        testSeedDetails.setDeviceSeed(
                "PRfc+OB+DsKapruTUgO5Ov+ceUbd417/DToE2dwVbY97YOMrzk7CGljyfXaM4V4qDyNLd2iaVJ46Tx1Ql37JkA==");
        testSeedDetails.setDeviceUuid("6COKQTXDOCYIE23H7Z1UHS4Z4IAWHQKSION4Q7CJNZ2TRD5UOA");
        testSeedDetails.setHashIndexVal(18);
        testSeedDetails.setHmacSpec(TOTPHmacSpecs.valueOf("SHA512"));
        testSeedDetails.setUserActivationTs(new Date().getTime() / 1000);
        seedDetailsList.add(testSeedDetails);
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {

    }

    private HttpServletResponse setFixedHeader(final HttpServletResponse responseLocal) {
        responseLocal.setHeader("Cache-Control", "no-store");
        responseLocal.setHeader("Pragma", "no-cache");
        responseLocal.setHeader("Content-Type", "application/json;charset=UTF-8");
        responseLocal.setHeader("X-FRAME-OPTIONS", "DENY");
        return responseLocal;
    }

    @BeforeEach
    void setUp() throws Exception {

        Constants.getTotpEnabledAppAgents().clear();
        Constants.getTotpEnabledAppAgents().add("3f8dee2a-2fc9-4852-8dee-2a2fc9e852bb");

        user.getRelIds().forEach(relId -> relId.setRelIdCreatedTs(new Date()));
        response = Mockito.mock(HttpServletResponse.class);
        response = setFixedHeader(response);
        when(request.getSession()).thenReturn(mockSession);
        when(mockSession.getAttribute(EnterpriseInfo.CLIENT_ID)).thenReturn(clientId);
        when(mockSession.getAttribute(EnterpriseInfo.SCOPE)).thenReturn(scopeString);
        when(request.getAttribute(Constants.REQUESTOR_ID)).thenReturn("lkjhgfgxfcvjhb987");
    }

    @AfterEach
    void tearDown() throws Exception {

    }

    @ParameterizedTest
    @NullSource
    @EmptySource
    final void throwsInvalidClientExceptionIfNullOrEmptyClientIdReceived(final String clientId) {

        final InvalidClientException exn = assertThrows(InvalidClientException.class, () -> {
            when(mockSession.getAttribute(EnterpriseInfo.CLIENT_ID)).thenReturn(clientId);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            validateTotpServiceImpl.validateTotp(request, response, params);

        });

        assertEquals("clientId is null or empty", exn.getMessage());

    }

    @ParameterizedTest
    @NullSource
    @EmptySource
    void throwsInvalidScopeExceptionIfNullOrEmptyScopeReceived(final String scope) {

        final InvalidScopeException exn = assertThrows(InvalidScopeException.class, () -> {
            when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(testUsername);
            when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn(testTotp);
            when(mockSession.getAttribute(EnterpriseInfo.SCOPE)).thenReturn(scope);
            when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            validateTotpServiceImpl.validateTotp(request, response, params);

        });

        assertEquals("scope is null or empty", exn.getMessage());

    }

    @Test
    void throwsInvalidScopeExceptionIfInvalidScopeReceived() {

        final String scope = "invalid";

        final InvalidScopeException exn = assertThrows(InvalidScopeException.class, () -> {

            when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(testUsername);
            when(mockSession.getAttribute(EnterpriseInfo.SCOPE)).thenReturn(scope);
            when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn(testTotp);
            when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            validateTotpServiceImpl.validateTotp(request, response, params);

        });

        assertEquals(String.format("Invalid scope: %s", scope), exn.getMessage());

    }

    @Test
    void throwsAccesDeniedExceptionIfInvalidResourceIdReceived() {

        final EnterpriseInfo testClientDetails = Constants.GSON
                .fromJson("{\"_id\":ObjectId(\"5dfca4ab8065a92ca3f533af\"),\"enterprise_id\":\"test02\","
                        + "\"method\":\"OAuth2\",\"apple_server_certificate_dev_mode\":false,"
                        + "\"credsUploadStatusGoogle\":\"PENDING\",\"credsUploadStatusApple\":\"PENDING\","
                        + "\"resource_ids\":[\"ant-shant\"],"
                        + "\"authorized_grant_types\":[\"client_credentials\",\"referesh_token\"],"
                        + "\"access_token_validity_seconds\":8765,\"enable_refresh_token\":true,"
                        + "\"refresh_token_validity_seconds\":8876,"
                        + "\"client_id\":\"ODQ3N2ZlYTYtY2U5OC00MTc4LWI3ZmUtYTZjZTk4NzE3OGRj\","
                        + "\"client_secret\":\"iq7Kip8aZU9+p9ThZZeZ4WLmJzEUMUvNVcK8Fmin/0ocpfoqcn+zufex96s748PiTq7PMKJsyR1Zzp/1s3dREjRmPGR+yjizL5rWY6e7TPI=\","
                        + "\"secret_required\":false,\"scoped\":false,\"scope\":[\"all\"],"
                        + "\"registered_redirect_uri\":[\"http://localhost:8080/GM/enterprise-management.htm\"],"
                        + "\"registered_error_uri\":[\"http://localhost:8080/GM/enterprise-management.htm\"],"
                        + "\"authorities\":[],\"auto_approve\":false}", EnterpriseInfo.class);

        final AccessDeniedException exn = assertThrows(AccessDeniedException.class, () -> {
            when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(testUsername);
            when(request.getParameter(EnterpriseInfo.SCOPE)).thenReturn(scopeString);
            when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn(testTotp);
            when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(testClientDetails);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            validateTotpServiceImpl.validateTotp(request, response, params);

        });

        assertEquals(String.format("client with id: %s does not have access to the requested resource", clientId),
                exn.getMessage());

    }

    @ParameterizedTest
    @NullSource
    @EmptySource
    void throwsUsernameNotFoundExceptionIfNullOrEmptyUsernameReceived(final String userName) {

        final UsernameNotFoundException exn = assertThrows(UsernameNotFoundException.class, () -> {
            when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(userName);
            when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn(testTotp);
            when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            validateTotpServiceImpl.validateTotp(request, response, params);

        });

        assertEquals("unauthorized access", exn.getMessage());
    }

    @ParameterizedTest
    @NullSource
    @EmptySource
    void throwsIllegalArgumentExceptionIfNullOrEmptyTotpReceived(final String totp) {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(testUsername);
            when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn(totp);
            when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            validateTotpServiceImpl.validateTotp(request, response, params);

        });

        assertEquals("totp is null or empty", exn.getMessage());
    }

    @Test
    void throwsIllegalArgumentExceptionIfTotpRegexValidationFails() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(testUsername);
            when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn("987667ag");
            when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            validateTotpServiceImpl.validateTotp(request, response, params);

        });

        assertEquals("regex validation for TOTP failed", exn.getMessage());
    }

    @Test
    void throwsAccessDeniedExceptionIfTotpSeedIsNotRegisteredForDevice() {

        final AccessDeniedException exn = assertThrows(AccessDeniedException.class, () -> {

            user.getRelIds().forEach(relId -> relId.setTotpSeed(""));

            when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(testUsername);
            when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn(testTotp);
            when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);
            when(userAuthInfoRepo.fetchUserDetailsFromLoginId(Mockito.anyString())).thenReturn(user);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            validateTotpServiceImpl.validateTotp(request, response, params);

        });

        assertEquals("Service Unavailable", exn.getMessage());
    }

    @Test
    void throwsAccessDeniedExceptionIfHmacIsNotFoundForDevice() {

        final AccessDeniedException exn = assertThrows(AccessDeniedException.class, () -> {

            user.getRelIds().forEach(relId -> relId.setHmac(""));
            user.getRelIds().forEach(relId -> relId.setRelIdCreatedTs(new Date()));

            when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(testUsername);
            when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn(testTotp);
            when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);
            when(userAuthInfoRepo.fetchUserDetailsFromLoginId(Mockito.anyString())).thenReturn(user);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            validateTotpServiceImpl.validateTotp(request, response, params);

        });

        assertEquals("Service Unavailable", exn.getMessage());
    }

    @Test
    void throwsAccessDeniedExceptionIfHmacIndexValForDeviceIsInvalid() {

        final AccessDeniedException exn = assertThrows(AccessDeniedException.class, () -> {

            user.getRelIds().forEach(relId -> relId.setHmacIndexVal(0));
            user.getRelIds().forEach(relId -> relId.setRelIdCreatedTs(new Date()));

            when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(testUsername);
            when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn(testTotp);
            when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);
            when(userAuthInfoRepo.fetchUserDetailsFromLoginId(Mockito.anyString())).thenReturn(user);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            validateTotpServiceImpl.validateTotp(request, response, params);

        });

        assertEquals("Service Unavailable", exn.getMessage());
    }

    @Test
    void throwsUsernameNotFoundExceptionIfNoUserIsFoundInDB() {

        final UsernameNotFoundException exn = assertThrows(UsernameNotFoundException.class, () -> {

            when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(testUsername);
            when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn(testTotp);
            when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);
            when(userAuthInfoRepo.fetchUserDetailsFromLoginId(Mockito.anyString())).thenReturn(null);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            validateTotpServiceImpl.validateTotp(request, response, params);

        });

        assertEquals("Authentication Failed", exn.getMessage());
    }

    @ParameterizedTest
    @EnumSource(value = RelIdUserStatus.class, names = { "CREATED", "UNENROLLED", "DISABLE" })
    void throwsUnauthorizedUserExceptionIfUserStatusIsNotActive(final RelIdUserStatus status) {

        final UnauthorizedUserException exn = assertThrows(UnauthorizedUserException.class, () -> {

            user.setUserStatus(status);

            when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(testUsername);
            when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn(testTotp);
            when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);
            when(userAuthInfoRepo.fetchUserDetailsFromLoginId(Mockito.anyString())).thenReturn(user);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            validateTotpServiceImpl.validateTotp(request, response, params);

        });

        assertEquals("Authentication Failed", exn.getMessage());
    }

    // @Test
    void throwsUnauthorizedUserExceptionIfUserStatusIsBlocked() {

        final UnauthorizedUserException exn = assertThrows(UnauthorizedUserException.class, () -> {

            user.setUserStatus(RelIdUserStatus.BLOCKED);

            when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(testUsername);
            when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn(testTotp);
            when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);
            when(userAuthInfoRepo.fetchUserDetailsFromLoginId(Mockito.anyString())).thenReturn(user);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            validateTotpServiceImpl.validateTotp(request, response, params);

        });

        assertEquals(String.format("user %s final is BLOCKED", testUsername), exn.getMessage());
    }

    @ParameterizedTest
    @EnumSource(value = RelIdUserStatus.class, names = { "CREATED", "BLOCKED", "UNENROLLED", "DISABLE" })
    void throwsUnauthorizedUserExceptionIfRelIdStatusIsNotActive(final RelIdUserStatus status) {

        final UnauthorizedUserException exn = assertThrows(UnauthorizedUserException.class, () -> {

            user.getRelIds().forEach(relId -> relId.setRelIdStatus(status));

            when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(testUsername);
            when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn(testTotp);
            when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);
            when(userAuthInfoRepo.fetchUserDetailsFromLoginId(Mockito.anyString())).thenReturn(user);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            validateTotpServiceImpl.validateTotp(request, response, params);

        });

        assertEquals(Constants.UNAUTHORIZED_ACCESS, exn.getMessage());
    }

    @Test
    void throwsUnauthorizedUserExceptionIfAppAgentIsNotEnabledForTotp() {

        final UnauthorizedUserException exn = assertThrows(UnauthorizedUserException.class, () -> {

            user.getRelIds().forEach(relId -> relId.setAppUuid("3f8dee2a-2fc9-4852-8dee-2a2fc9e852bc"));

            when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(testUsername);
            when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn(testTotp);
            when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);
            when(userAuthInfoRepo.fetchUserDetailsFromLoginId(Mockito.anyString())).thenReturn(user);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            validateTotpServiceImpl.validateTotp(request, response, params);

        });

        assertEquals("App Agent is not enabled for TOTP.", exn.getMessage());
    }

    @Test
    void returnsFalseIfTotpDoesNotMatch() throws TOTPValidationException {

        user.getRelIds().forEach(relId -> relId.setRelIdCreatedTs(new Date()));

        when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(testUsername);
        when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn(testTotp);
        when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);
        when(userAuthInfoRepo.fetchUserDetailsFromLoginId(Mockito.anyString())).thenReturn(user);

        // calling method
        response.setHeader("X-FRAME-OPTIONS", "DENY");
        final boolean validated = validateTotpServiceImpl.validateTotp(request, response, params);

        assertFalse(validated);

    }

    @Test
    void returnsTrueIfTotpMatches() throws TOTPValidationException {

        user.getRelIds().forEach(relId -> relId.setRelIdCreatedTs(new Date()));

        when(request.getParameter(Constants.REQ_PARAM_USERNAME)).thenReturn(testUsername);
        when(request.getParameter(TOTPValidationLog.TOTP)).thenReturn("91741606");
        when(OAuthClientDetailsService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);
        when(userAuthInfoRepo.fetchUserDetailsFromLoginId(Mockito.anyString())).thenReturn(user);
        when(date.getTime() / 1000).thenReturn((long) 91741606);
        when(totValidationRepo.isTOTPConsumed(Mockito.anyString(), Mockito.anyString(), Mockito.anyString()))
                .thenReturn(false);

        // calling method
        response.setHeader("X-FRAME-OPTIONS", "DENY");
        final boolean validated = validateTotpServiceImpl.validateTotp(request, response, params);

        assertTrue(validated);
    }

}
