package com.uniken.authserver.services.impl;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.NullSource;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.jwt.crypto.sign.MacSigner;
import org.springframework.security.jwt.crypto.sign.Signer;
import org.springframework.security.oauth2.common.util.RandomValueStringGenerator;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;

@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
class JwtServiceImplTest {

    @InjectMocks
    private JwtServiceImpl jwtService;

    private final String verifierKey = new RandomValueStringGenerator().generate();
    private final Signer signer = new MacSigner(verifierKey);

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {
    }

    @BeforeEach
    void setUp() throws Exception {
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    /**
     * Should throw illegal argument exception when given claims is invalid.
     *
     * @param claims
     *            the claims
     */
    @ParameterizedTest
    @NullSource
    @EmptySource
    final void shouldThrowIllegalArgumentExceptionWhenGivenClaimsIsInvalid(final Map<String, Object> claims) {
        final IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            // call
            jwtService.generateEncodedJwt(claims, signer);
        });

        // test
        assertEquals("Invalid claims", thrown.getMessage());
    }

    /**
     * Should throw illegal argument exception when given signer is invalid.
     */
    @Test
    final void shouldThrowIllegalArgumentExceptionWhenGivenSignerIsInvalid() {
        final IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            // preconditions
            final Map<String, Object> payload = new HashMap<>();
            payload.put("someClaim", "someClaimValue");
            final Signer signer = null;

            // call
            jwtService.generateEncodedJwt(payload, signer);
        });

        // test
        assertEquals("Invalid signer", thrown.getMessage());
    }

    /**
     * Should throw illegal argument exception when getting jwt claims and given
     * jwt is invalid.
     *
     * @param jwt
     *            the jwt
     */
    @ParameterizedTest
    @NullSource
    @EmptySource
    final void shouldThrowIllegalArgumentExceptionWhenGettingJwtClaimsAndGivenJwtIsInvalid(final String jwt) {
        final IllegalArgumentException thrown = assertThrows(IllegalArgumentException.class, () -> {
            // call
            jwtService.getJwtClaims(jwt);
        });

        // test
        assertEquals("Invalid jwt", thrown.getMessage());
    }

    /**
     * Should return valid encoded jwt string.
     */
    @Test
    final void shouldReturnValidEncodedJwtString() {
        // preconditions
        final Map<String, Object> payload = new HashMap<>();
        payload.put("someClaim", "someClaimValue");

        // call
        final String jwt = jwtService.generateEncodedJwt(payload, signer);

        // test
        assertNotNull(jwt);
    }

    /**
     * Should return valid jwt claims when jwt is valid.
     */
    @Test
    final void shouldReturnValidJwtClaimsWhenJwtIsValid() {
        // preconditions
        final Map<String, Object> expectedClaims = new HashMap<>();
        expectedClaims.put("someClaim1", "someClaimValue1");
        expectedClaims.put("someClaim2", "someClaimValue2");
        final String jwt = jwtService.generateEncodedJwt(expectedClaims, signer);

        // call
        final Map<String, Object> actualJwtClaims = jwtService.getJwtClaims(jwt);

        // test
        assertThat(actualJwtClaims, is(expectedClaims));
    }

}
