package com.uniken.authserver.services.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.util.CollectionUtils;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.domains.Configuration;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.user.DeviceStatus;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.domains.user.vos.WebUserDetails;

@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
class SessionServiceImplTest {

    @InjectMocks
    SessionServiceImpl sessionServiceImpl;

    @Mock
    SecureCookieServiceImpl secureCookieServiceImpl;

    @Mock
    Configuration configuration;

    @Mock
    WebDevMasterService webDevMasterService;

    @Mock
    UserAuthInfoRepo userAuthInfoRepo;

    MockHttpServletRequest request;

    MockHttpServletResponse response;

    String checksum;

    Cookie secureCookie;

    WebDevMaster webDevMaster;

    @BeforeEach
    public void setup() {
        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();

        secureCookie = new Cookie("__Host-ACC_CH", "8b52dba7-060f-4c9f-ba56-86b77a2985d5");
        secureCookie.setDomain("");
        secureCookie.setHttpOnly(true);
        secureCookie.setPath("/");
        secureCookie.setSecure(true);
        request.setCookies(secureCookie);

        final Map<String, Object> deviceParameters = new HashMap<>();
        deviceParameters.put("Platform", "Firefox");
        deviceParameters.put("IPAddress", "10.1.1.9");

        final String webDeviceUUID = "123e4567-e89b-12d3-a456-426655440000";
        final String webDeviceParametersChecksum = "1234";

        webDevMaster = new WebDevMaster(webDeviceUUID, DeviceStatus.ACTIVE.getName(), null, deviceParameters,
                new Date(), new Date(), webDeviceParametersChecksum);
    }

    @Test
    void getSecureCookieWhenRememberMeEnabled() throws Exception {
        when(secureCookieServiceImpl.generateSecureCookie())
                .thenReturn("__Host-ACC_CH=8b52dba7-060f-4c9f-ba56-86b77a2985d5; Path=/; Max-Age=86400; "
                        + "Expires=Sat, 05 Jun 2021 03:41:29 GMT; Secure; HttpOnly; SameSite=Strict; priority=HIGH");

        checksum = "c1d14151b66fe046e05e1f970ee0d012";

        // FIXME : Confirm about checksum
        when(webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(secureCookie.getValue())).thenReturn(null);

        when(webDevMasterService.fetchWebDeviceMaster(checksum)).thenReturn(webDevMaster);

        when(webDevMasterService.updateWebDeviceMaster(webDevMaster)).thenReturn(webDevMaster);

        final String userId = "o2";
        final WebUserDetails userAuthInfo = new WebUserDetails();
        when(userAuthInfoRepo.fetchUserDetailsFromUserId(userId)).thenReturn(new UserAuthInfoVO());

        when(userAuthInfoRepo.updateUserAuthInfo(new UserAuthInfoVO())).thenReturn(new UserAuthInfoVO());

        PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.setRememberMe(true);

        sessionServiceImpl.preLogoutSecureCookieHandling(request, response);

        assertNotNull(response.getHeaders("Set-Cookie"));
    }

    @Test
    void getSecureCookieWhenRememberMeDisabled() throws Exception {
        PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.setRememberMe(false);

        sessionServiceImpl.preLogoutSecureCookieHandling(request, response);

        assertTrue(response.getHeaders("Set-Cookie").isEmpty());
    }

    @Test
    void shouldGenerateCookieForNewUser() throws Exception {
        final Cookie[] cookies = new Cookie[] { new Cookie("DummyCookie", "DummyValue") };
        request.setCookies(cookies);

        when(secureCookieServiceImpl.generateSecureCookie())
                .thenReturn("__Host-ACC_CH=8b52dba7-060f-4c9f-ba56-86b77a2985d5; Path=/; Max-Age=86400; "
                        + "Expires=Sat, 05 Jun 2021 03:41:29 GMT; Secure; HttpOnly; SameSite=Strict; priority=HIGH");

        checksum = "c1d14151b66fe046e05e1f970ee0d012";

        when(webDevMasterService.fetchWebDeviceMaster(checksum)).thenReturn(webDevMaster);

        when(webDevMasterService.updateWebDeviceMaster(webDevMaster)).thenReturn(webDevMaster);

        final String userId = "o2";
        final WebUserDetails userAuthInfo = new WebUserDetails();
        when(userAuthInfoRepo.fetchUserDetailsFromUserId(userId)).thenReturn(new UserAuthInfoVO());

        when(userAuthInfoRepo.updateUserAuthInfo(new UserAuthInfoVO())).thenReturn(new UserAuthInfoVO());

        PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.setRememberMe(true);

        sessionServiceImpl.preLogoutSecureCookieHandling(request, response);

        System.out.print(response.getHeaders("Set-Cookie"));

        assertNotNull(response.getHeaders("Set-Cookie"));
    }

    @Test
    void shouldGenerateNewCookieIfExistingCookieIsNotMappedWithCurrentUser() throws Exception {
        when(secureCookieServiceImpl.generateSecureCookie())
                .thenReturn("__Host-ACC_CH=9x52dba7-060f-4c9f-ba56-86b77a2985g6; Path=/; Max-Age=86400; "
                        + "Expires=Sat, 05 Jun 2021 03:41:29 GMT; Secure; HttpOnly; SameSite=Strict; priority=HIGH");

        checksum = "c1d14151b66fe046e05e1f970ee0d012";

        // FIXME : Confirm about checksum
        when(webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(secureCookie.getValue())).thenReturn(null);

        when(webDevMasterService.fetchWebDeviceMaster(checksum)).thenReturn(webDevMaster);

        when(webDevMasterService.updateWebDeviceMaster(webDevMaster)).thenReturn(webDevMaster);

        final String userId = "o2";
        final WebUserDetails userAuthInfo = new WebUserDetails();
        when(userAuthInfoRepo.fetchUserDetailsFromUserId(userId)).thenReturn(new UserAuthInfoVO());

        when(userAuthInfoRepo.updateUserAuthInfo(new UserAuthInfoVO())).thenReturn(new UserAuthInfoVO());

        PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.setRememberMe(true);

        sessionServiceImpl.preLogoutSecureCookieHandling(request, response);

        assertNotNull(response.getHeaders("Set-Cookie"));
        assertEquals("__Host-ACC_CH=9x52dba7-060f-4c9f-ba56-86b77a2985g6",
                response.getHeader("Set-Cookie").split("; ")[0]);
    }

    @Test
    void shouldNotGenerateNewCookieIfExistingCookieIsMappedWithCurrentUser() throws Exception {
        checksum = "c1d14151b66fe046e05e1f970ee0d012";

        // FIXME : Confirm about checksum
        when(webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(secureCookie.getValue()))
                .thenReturn(webDevMaster);

        final String userId = "o2";
        final WebUserDetails userAuthInfo = new WebUserDetails();
        when(userAuthInfoRepo.fetchUserDetailsFromUserId(userId)).thenReturn(new UserAuthInfoVO());

        when(userAuthInfoRepo.updateUserAuthInfo(new UserAuthInfoVO())).thenReturn(new UserAuthInfoVO());

        PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.setRememberMe(true);

        sessionServiceImpl.preLogoutSecureCookieHandling(request, response);

        assertTrue(CollectionUtils.isEmpty(response.getHeaders("Set-Cookie")));
    }

}
