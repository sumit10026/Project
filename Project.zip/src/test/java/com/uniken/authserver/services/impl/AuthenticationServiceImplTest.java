package com.uniken.authserver.services.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.mock;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.util.ReflectionTestUtils;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.domains.AllowedAuthenticationFactors;
import com.uniken.authserver.domains.ValidateUserRequest;
import com.uniken.authserver.exception.RelIDAuthServerOAuth2Exception;
import com.uniken.authserver.exception.RelIDNotificationRejectedException;
import com.uniken.authserver.services.api.OAuth2ClientDetailsService;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.SessionConstants;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.relid.notification.NotificationUserActionResponse;
import com.uniken.totp.exception.TOTPValidationException;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
class AuthenticationServiceImplTest {
    MockHttpServletRequest request;
    MockHttpServletResponse response;
    MockHttpSession session;

    AuthenticationServiceImpl authenticationServiceImpl;
    OAuth2ClientDetailsService customClientDetailService;
    CustomUserDetailsService customUserDetailsService;
    AuthenticateTotpServiceImpl authenticateTotpServiceImpl;
    WebDevMasterService webDevMasterService;

    ValidateUserRequest validateUserRequest;

    private String correlationID = "";
    final static String testUsername = "testUser";
    String WEBDEVICEFINGERPRINT = "12345";
    String WEBDEVICEPARAMETERS = "{\"platform\":\"win32\", \"userAgent\":\"firefox\"}";
    final EnterpriseInfo clientDetails = Constants.GSON.fromJson(
            "{\"_id\":ObjectId(\"5df9af6320bc1363dff1cb01\"),\"enterprise_id\":\"CBCVerify\",\"method\":\"OAuth2\",\"apple_server_certificate_dev_mode\":false,\"credsUploadStatusGoogle\":\"PENDING\",\"credsUploadStatusApple\":\"PENDING\",\"resource_ids\":[\"relid-verify-server\",\"user-api-server\",\"OIDC\"],\"authorized_grant_types\":[\"refresh_token\",\"authorization_code\",\"client_credentials\"],\"access_token_validity_seconds\":180,\"enable_refresh_token\":false,\"refresh_token_validity_seconds\":0,\"client_id\":\"MTEzMmZhNTEtOGU1Zi00NTQyLWIyZmEtNTE4ZTVmZjU0MjU1\",\"client_secret\":\"jPnN2ptGYk4p8NKwY8DJtIfyIulxfOvo7zwnpl9MVKBEm0QDwGOqDLiuMhrgDBcccY8nxxTkDJ8ANWqZnm7lh+qYJfHe+UWI+fu1YpLPpKc=\",\"secret_required\":false,\"scoped\":false,\"scope\":[\"all\"],\"authorities\":[],\"registered_redirect_uri\":[\"http://127.0.0.1:8008/relid/authserver/oauth/login\",\"http://127.0.0.1:8080/GM/show-login-page.htm\"],\"auto_approve\":false,\"mapped_appagent_name\":\"tunneltestagent\",\"mapped_appagent_uuid\":\"e808085f-875f-455e-8808-5f875f255e93\",\"apple_server_certificate_content\":\"MIINAwIBAzCCDMoGCSqGSIb3DQEHAaCCDLsEggy3MIIMszCCB08GCSqGSIb3DQEHBqCCB0Awggc8AgEAMIIHNQYJKoZIhvcNAQcBMBwGCiqGSIb3DQEMAQYwDgQIfh5AyahrRsoCAggAgIIHCMrbMZluTN17B1cYJfEYu9kmIGoVOfCPn5kVHcjFW8LZc8QSSXCEdTCJAhugsNvit85ScGyJxZLGoxCBCJaP8Ym7J03IUmoXtzApe8jtm1KSygAxJlgUzSmqpisNeSW8fvaaS6ZZjl+EnKnhykTwXv0Is805H6r7yAD2GR1/GVktwLbxsu/al3u2XVedbjnnZQgHx8HC2KmrQatBbxeXSD8lkEIwXGL6XjvgAZ7rLIcm//qzri+FrI8AgeRljYnj9sJk/HRxXZa/3KFUEiuEcYiv77E1GbV/h5ztP2RwmAlJ0Oue185+yAJlG4ZcG5dHo7jIqOBbMkz1xAc2AqKq0JjU5IulBtE42TxG5Gb/k7Ppy/b9bnFrUAYA3306L9D6PigyEhor+w5hUTsFeZxwMB9++wpBdLHWm2qQFDpvuVWad+0QlkpL3TLPCLTrV2llpZsiios8N9HdYz9xqzC4DO5LJ0NOYNOfv+Tfelw/JtjZh5bnl+rV2qFdRIfz9uZzLKMPLRRWPKcFraLZvesmkyfSyH57HJlEts5IT22elvHjehqDzL409vzy+rmcf8P15TTXJgvXQPJsAtghJSXuUkT8EBpl577/pd5Y1C0sXlBaF6ibQm0/83YELHcQEpR8lJWmn1BPwzFcxI2uNtKl3L1fH0snyoT/N0elrNkpUKi0WabqKmOiAz3S7ZCAjnDR8eTPrqa++W7E/fXXe8K/vyfOTmz8ZfwouVPdQX71/oOoI/LU5NC4miPncQPJXYiQ/yU3TFIA1ZKC6oYEQjRCJKKcY5OCHSjlVxX8HOSZ0mZjcvjQJPzTXdRvLf2Go3Y07ZFJfK7Ka9AFQnDaVS5PDCoq5/ZdMfup07kB4b2VQieYVwRduLorxgmRCXZLsPXSmqedj44DUr1uZujK9WlFJ1bf1ZKdRHLqb/G2ElZCHGMhnq9S0Uh0LxrlG6aLy6+RfTqffNtwJOlOfZUOz7aZN3JaD1GD5FT79wVGSqQO81EDXB2dIOO+24ZFTy2KGYicrRRMuSLuSDURDhQnOugZe8a85zX6KXSmtz+To0jhL3CducRLy/N2cx+VUqXr5zQm9ZkvKGk9gTkNqFOBeHYDyBNHzjv+/z82yEtFtoGcybnhJXXhfMar+JXRX5NZRm2Y3b9pZjXqoHulu6Nrz8ngTuwwuEMo/fRKucyOrar+tIDw2qCOGmg9GI8B8fN+UCuKCiQLu/6ojtvpCwgeoN41GMTQhFIVxGD4UOKzeehvdLaXRtItFNgaMs1TwSn2WOA1ID1kSsYg6fxA4EXnHVrMJaTWjxwGaLmnzn5HugkwN62iiBxizMECjhmTnULAjO7JHA4mKv+KYU2jPfmBN2c8Co6DsQH7niBRNAixrZvsVsmpbXFH7mbuA7b6M/dmj+zKySxf0AhtpL7JKSsNbyOWuoEUZLG62ES8jLDiRo3B2U7z8AJc2pbpfjZE9Fgwf45RSCWmlPeBGjDx/nOv+7EzqhKGPl5FoTK8buz0sinXdOnf5zlzoeu1D9SwP2KE8fobchECinHlAduWR/SahMs5Jz6hMHndOF5WEkZlakSCpYQX5XLybfPm6EQp2FB1eIRXEIP+Asm7d7oJshAGfSY+sydsf1+vOpwIcYX/ATqBlhvsb2XOnGZTi+oTy1dgeUf5OFM1F3E/Jp1zn0lUSgY3AgM1FMnFOVgNMHYIgdEBGEPhbQGqb4ANhxBjOioSGKAGyLbr8XdMZLaC+b2mNgIdYjggJRtn1ei/v10LM2RwBMaJ/j6I1Gr8D47zEyNA9m+bPaPfHpwsPQaqYNXncNafSp7LS3iUGhdqviPklIp5OdfxVQGKVkCMMS7+1aNwEZA+sr8/XYrAXUT23jK4tvUoUpCG+/QrrA0Lmg/41eXymWTwjQTtlI+WylZXtQO8nU1D9mujd/3mjQ7tJqxp7NgbLcvf/u5vk0btv4LPLL8dGgTuUHtzWygxYSK5D3j8Bd4xm0I1M3lwUdKLNDhvZ7vTSzarzOf51eTl1caOEJAqX2WR2xpnyeY9Bn5h7miv43Nv8aHYgy7D8yELWGIuhN0P8r7GlW5DWL2pwaqI76HLOeSFpnbWCGCq5rB80GSuRM7E8p8MqGu94BP4wPzdjh+74zgeTRkVztTBVZAV7PBgc6CHfZS73xPkF82IfEbCJFN+98fDaJfYtrfaN3CkF6oI/IC72jE6P/yNIs31leXPbj8N+LnS+FKonnW9BPMv9pw00x/Su6QS5UBYQkWXa8DuN7cObdJ9k6Y8Yo1ADPKUymT1B94yGw9FILYYrnEw5BprobEGkyv7qYHUmNq5/djW+SdIZDuXb4sAkE5QFQtEitalav7VAHLZl+ma1rZ8LhPuXG4m3rmHyMcJTNnod6W5CsWAagFgJH+7bDCCBVwGCSqGSIb3DQEHAaCCBU0EggVJMIIFRTCCBUEGCyqGSIb3DQEMCgECoIIE7jCCBOowHAYKKoZIhvcNAQwBAzAOBAhP2Y6ltJrVXwICCAAEggTIJ0aIGjc13vVhjo5dRjOh0m/p+GMWhBpsshkB/o885emHwk/uvinxiDI+/ub593esCSTYiQVitWFct93GVKNNeehsY+ubl2Ys/hnlZyy59YkZhzP6H2nirGeIu0ALUZhxIIHSvOZnXuqTxkSzyi3X8kwVQU5yjlfesnTM9qgC6GCi7xuvtSK9DrdUZ30R552U5FLPNECMCc1RhitRLUiodZrZSU8Dj2fmM911jiJpGYs4AFpezGLQRaKXS0uRZOAIGgc6/qag1FpPo8VjwF6Mc5mv4nsXNsCwEV9KXCRVbTveytzmzwoJooYkh7zNCA/yQwcBPd88doG/e5TU8X+fgRfvVP9FpCKFM8qsTcdG7+Zh1wSwKoMCkvuuch7767E98373utg11QFsRY4mmiuh2jkLsmLuVKkBIiS8M2hHAfr1iSvI+fdJ0ldYHHK9CrGybfOrWqn7SCI/KbVhG1x0/UzLcqxrGXHyj7V+8hPAydOmr/GlLoe8Hw7UqYM6qoTY9SNcA02yoTkuRe+QxsWzTScbV+G6emcUlf53XF3LsPbCFXfLpkZ1NYeLxZuIxxDm7AtpBWHOqqAGyNbtxX9II0MCiiSNN61TJcoje1OWVOihye94BKmKUVSys/JZjZEVsKHNbaU7OpQ4G3jTgXiaPf6BvkWdJMYGmz59LcDC01pXX+NTUwXogOQUOvl/FSLjAv0zdzHXvYtohkbK6poZba+02b9+0updDzDCoRjCUg6eAlgfyO7aUr0ufFk9hD9ij0JJoIlKe8AAqTEwligKZjgs+nHiqyGnazkMIz4vGOn5XkYcYQOMav4Wo7RaOkqDuHED+nhYMeslldJTXcpOeZmgN1nvyh993gvTbvibbdvqCZ9Jc9D6kksHha5C8qhCMfb8BHU6mkuXwM56V+/mFbETGAY2CwC24e6cXhlSSsqMdNBASrJJbQTGFa3FF9SqceCOwKzkiyHIuyMQARP7UHQ2JHkKrERKvryjhJPpywu4ILDCpbw6CR2b6BwWBg1LyhZmYDvTkZULRybviHsgzqCa+/AER7hoXw/s5UO4CdBmtklMqZ6686r4Mdwv6WahsFoOHkmQue3piutyDPjd0fUcCR6Rt0OZNHHjUnfH3jsyMk9JwOpKiMr2QjBvApxdvp9itJaIh8ZXbibAoyBn+WVYUPQPjir8exaQShZuiUT5E6g2O4Qq1JvX+rbtxeXxBnryb0hF+93kQDrk2GVzXTA4qcDtaw9iH8viyB4LJOyq88XErbCJxlQclawRhyxi+n917WFkxJ4QdCDEBvF2Ru1MtScVGlOAixdL48rPTNth+rXFdV5nkzkzCq4r1F2dDQXSEP4OvY89JU/wC8sAJmkrtz6Hh05MHqOl+LyObTPov5YSZq0lJa2Ge2TWU/XO4mNyzjzDCqvKmZ78LNuyIS6XS/CbRvVs0Ufdp9PeUfqXAAy7Vd66/Kdm7liNxrfB0uOvUPZrl7Q4ZSk18991JPYt5p3wyUGisyU0VcTQrzYhBylBbl19yN/3vxwCCJRDX4GHGhWzHqufSxCnqcuUYdwfCo72FMLnUcsqe7dBVzfbpOxzO+/XN1Qhhu7oz9gRaPOwH0LUA19nf9eflTTdRucp5MtiZoDbMUAwGQYJKoZIhvcNAQkUMQweCgBvAG4AawBhAHIwIwYJKoZIhvcNAQkVMRYEFHNKUx4EhDXShY69cGBF5HaRW2vHMDAwITAJBgUrDgMCGgUABBR7lESH7sO8GNH30zPJbC9f+8S/3AQI4BCxYzPIqaECAQE=\",\"apple_server_certificate_password\":\"yKbAg8gQMBkp4uGDB6Ou0A==\",\"google_server_authentication_key\":\"/IHTif4HQl5XnNfIYvTsm4AozoAGaMPFfWpxltUNSIsDnu09q/Z6ngvStV0T1SCc\"}",
            EnterpriseInfo.class);

    @BeforeEach
    void setUp() throws Exception {

        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();
        session = new MockHttpSession();

        authenticationServiceImpl = new AuthenticationServiceImpl();
        customClientDetailService = mock(OAuth2ClientDetailsService.class);
        authenticateTotpServiceImpl = mock(AuthenticateTotpServiceImpl.class);
        customUserDetailsService = mock(CustomUserDetailsService.class);
        webDevMasterService = mock(WebDevMasterService.class);

        ReflectionTestUtils.setField(authenticationServiceImpl, "customUserDetailsService", customUserDetailsService);
        ReflectionTestUtils.setField(authenticationServiceImpl, "customClientDetailService", customClientDetailService);
        ReflectionTestUtils.setField(authenticationServiceImpl, "authenticateTotpServiceImpl",
                authenticateTotpServiceImpl);

        correlationID = "1234";
        request.setAttribute(Constants.REQUESTOR_ID, "lkjhgfgxfcvjhb987");

        final AllowedAuthenticationFactors factors = new AllowedAuthenticationFactors();
        // factors.setRelidTotp(true);

        final Field field = PropertyConstants.class.getField("AUTH_SERVER_ALLOWED_AUTH_FACTORS");
        field.setAccessible(true);

        final Field modifiersField = Field.class.getDeclaredField("modifiers");
        modifiersField.setAccessible(true);
        modifiersField.setInt(field, field.getModifiers() & ~Modifier.FINAL);

        field.set(null, factors);

    }

    void prepareLevel1AuthRequest() {
        validateUserRequest = new ValidateUserRequest();
        validateUserRequest.setUserName("testUser");
        validateUserRequest.setWebDeviceParameters(WEBDEVICEPARAMETERS);
        validateUserRequest.setAuthType(AuthType.TOTP.getName());
        validateUserRequest.setAuthValue("1234");

        session.setAttribute(EnterpriseInfo.CLIENT_ID, "test_client_id");
        session.setAttribute(SessionConstants.PENDING_AUTH_TYPES,
                new HashSet<>(Arrays.asList(AuthType.TOTP.getName())));
        session.setAttribute(SessionConstants.CURRENT_USERNAME, "testUser");
        session.setAttribute(Constants.CORRELATION_ID, "1234");
        request.setSession(session);
    }

    @Test
    final void shouldThrowIllegalArgumentExceptionIfNullCorrelationIDFound() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {

            // Precondition
            correlationID = null;

            // calling method
            authenticationServiceImpl.checkIfNotificationIsActed(correlationID);

        });

        // Test
        assertEquals("CorrelationID is null or empty", exn.getMessage(), "Null Correlation ID testcase");

    }

    @Test
    final void shouldThrowIllegalArgumentExceptionIfEmptyCorrelationIDFound() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {

            // Precondition
            correlationID = "   ";

            // calling method
            authenticationServiceImpl.checkIfNotificationIsActed(correlationID);

        });

        // Test
        assertEquals("CorrelationID is null or empty", exn.getMessage(), "Null Correlation ID testcase");

    }

    @Test
    final void shouldRespondWithNoContentIfNotificationNotYetActedCase() {

        // Precondition
        Constants.getVerifyNotificationResponseMap().remove(correlationID);

        // calling method
        final HttpStatus status = authenticationServiceImpl.checkIfNotificationIsActed(correlationID);

        // Test
        assertEquals(HttpStatus.ACCEPTED, status, "Invalid Correlation ID, Notification not yet acted testcase");

    }

    @Test
    final void shouldRespondWithNoContentIfNoContentScenario() {

        // Precondition
        final NotificationUserActionResponse response = new NotificationUserActionResponse();
        response.setResponseCode(401);
        Constants.getVerifyNotificationResponseMap().put(correlationID, response);

        // calling method
        final HttpStatus status = authenticationServiceImpl.checkIfNotificationIsActed(correlationID);

        // Test
        assertEquals(HttpStatus.NO_CONTENT, status, "Valid Correlation ID, but no content scenario testcase");

    }

    @Test
    final void shouldRespondWithNoContentIfNotificationActedTestcase() {

        // Precondition
        final NotificationUserActionResponse response = new NotificationUserActionResponse();
        response.setResponseCode(100);
        Constants.getVerifyNotificationResponseMap().put(correlationID, response);

        // calling method
        final HttpStatus status = authenticationServiceImpl.checkIfNotificationIsActed(correlationID);

        // Test
        assertEquals(HttpStatus.OK, status, "Valid Correlation ID, and notification acted scenario testcase");

    }

    @Test
    final void shouldThrowIllegalArgumentExceptionWhileCheckingNotificationResponseWithNullCorrelationID() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            // Precondition
            correlationID = null;
            WEBDEVICEFINGERPRINT = "browser-checksum";
            WEBDEVICEPARAMETERS = "browser-DFP";

            // calling method
            authenticationServiceImpl.checkNotificationResponse(correlationID, WEBDEVICEFINGERPRINT,
                    WEBDEVICEPARAMETERS, request);

        });
        // Test
        assertEquals("CorrelationID is null or empty", exn.getMessage(),
                "Null Correlation ID while checking notification response testcase");

    }

    @Test
    final void shouldThrowIllegalArgumentExceptionWhileCheckingNotificationResponseWithEmptyCorrelationID() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            // Precondition
            correlationID = "   ";
            WEBDEVICEFINGERPRINT = "browser-checksum";
            WEBDEVICEPARAMETERS = "browser-DFP";

            // calling method
            authenticationServiceImpl.checkNotificationResponse(correlationID, WEBDEVICEFINGERPRINT,
                    WEBDEVICEPARAMETERS, request);

        });
        // Test
        assertEquals("CorrelationID is null or empty", exn.getMessage(),
                "Empty Correlation ID while checking notification response testcase");

    }

    @Test
    final void shouldThrowIllegalArgumentExceptionWhileCheckingNotificationResponseWithNullBrowserDFP() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            // Precondition
            correlationID = "1234";
            WEBDEVICEFINGERPRINT = "browser-dfp-checksum";
            WEBDEVICEPARAMETERS = null;

            // calling method
            authenticationServiceImpl.checkNotificationResponse(correlationID, WEBDEVICEFINGERPRINT,
                    WEBDEVICEPARAMETERS, request);

        });
        // Test
        assertEquals("browserDFP is null or empty", exn.getMessage(),
                "Null browserDFP while checking notification response testcase");

    }

    @Test
    final void shouldThrowIllegalArgumentExceptionWhileCheckingNotificationResponseWithEmptyBrowserDFP() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            // Precondition
            correlationID = "1234";
            WEBDEVICEFINGERPRINT = "browser-dfp-checksum";
            WEBDEVICEPARAMETERS = "   ";

            // calling method
            authenticationServiceImpl.checkNotificationResponse(correlationID, WEBDEVICEFINGERPRINT,
                    WEBDEVICEPARAMETERS, request);

        });
        // Test
        assertEquals("browserDFP is null or empty", exn.getMessage(),
                "Empty browserDFP while checking notification response testcase");

    }

    @Test
    final void shouldThrowIllegalArgumentExceptionWhileCheckingNotificationResponseWithInvalidBrowserDFP() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            // Precondition
            correlationID = "1234";
            WEBDEVICEFINGERPRINT = "browser-dfp-checksum";
            WEBDEVICEPARAMETERS = "Invalid json dfp";

            // calling method
            authenticationServiceImpl.checkNotificationResponse(correlationID, WEBDEVICEFINGERPRINT,
                    WEBDEVICEPARAMETERS, request);

        });
        // Test
        assertEquals("browser DFP is invalid", exn.getMessage(), "Invalid JSON browserDFP testcase");

    }

    @Test
    final void shouldThrowRelIDAuthServerOAuth2ExceptionWhileCheckingNotificationResponseWithNullUserActionResponse() {

        final RelIDAuthServerOAuth2Exception exn = assertThrows(RelIDAuthServerOAuth2Exception.class, () -> {
            // Precondition
            correlationID = "1234";
            WEBDEVICEFINGERPRINT = "browser-checksum";
            WEBDEVICEPARAMETERS = "{\"1234\":\"1234\"}";
            Constants.getVerifyNotificationResponseMap().put(correlationID, null);

            // calling method
            authenticationServiceImpl.checkNotificationResponse(correlationID, WEBDEVICEFINGERPRINT,
                    WEBDEVICEPARAMETERS, request);
        });
        // Test
        assertEquals("Either invalid correlation ID provided or notification is NOT still acted", exn.getMessage(),
                "Null Useraction response object testcase");

    }

    @Test
    final void shouldThrowRelIDAuthServerOAuth2ExceptionWhileCheckingNotificationResponseWithEmptyUserActionResponse() {

        final RelIDAuthServerOAuth2Exception exn = assertThrows(RelIDAuthServerOAuth2Exception.class, () -> {
            // Precondition
            correlationID = "1234";
            WEBDEVICEFINGERPRINT = "browser-checksum";
            WEBDEVICEPARAMETERS = "{\"1234\":\"1234\"}";
            final NotificationUserActionResponse userActionResponse = new NotificationUserActionResponse();
            Constants.getVerifyNotificationResponseMap().put(correlationID, userActionResponse);

            // calling method
            authenticationServiceImpl.checkNotificationResponse(correlationID, WEBDEVICEFINGERPRINT,
                    WEBDEVICEPARAMETERS, request);
        });
        // Test
        assertEquals("Notification is NOT still acted", exn.getMessage(), "Empty user action response object testcase");

    }

    @Test
    final void checkNotificationResponseWithNotificationAcceptedScenario() {

        // Precondition
        correlationID = "1234";
        WEBDEVICEFINGERPRINT = "browser-checksum";
        WEBDEVICEPARAMETERS = "{\"1234\":\"1234\"}";
        final NotificationUserActionResponse userActionResponse = new NotificationUserActionResponse();
        userActionResponse.setActionResponse(PropertyConstants.RelIdVerifyConstants.NOTIFICATION_ACCEPT_LABEL);
        Constants.getVerifyNotificationResponseMap().put(correlationID, userActionResponse);

        // calling method
        final boolean notificationResponse = authenticationServiceImpl.checkNotificationResponse(correlationID,
                WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request);

        // Test
        assertEquals(true, notificationResponse, "Notification accepted scenario");

    }

    @Test
    final void checkNotificationResponseWithNotificationRejectedScenario() {

        // Precondition
        correlationID = "1234";
        WEBDEVICEFINGERPRINT = "browser-checksum";
        WEBDEVICEPARAMETERS = "{\"1234\":\"1234\"}";
        final NotificationUserActionResponse userActionResponse = new NotificationUserActionResponse();
        userActionResponse.setActionResponse(PropertyConstants.RelIdVerifyConstants.NOTIFICATION_REJECT_LABEL);
        Constants.getVerifyNotificationResponseMap().put(correlationID, userActionResponse);

        // calling method
        final boolean notificationResponse = authenticationServiceImpl.checkNotificationResponse(correlationID,
                WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request);

        // Test
        assertEquals(false, notificationResponse, "Notification rejected scenario");

    }

    @Test
    final void checkNotificationResponseWithNotificationFraudScenario() {

        // Precondition
        correlationID = "1234";
        WEBDEVICEFINGERPRINT = "browser-checksum";
        WEBDEVICEPARAMETERS = "{\"1234\":\"1234\"}";
        final NotificationUserActionResponse userActionResponse = new NotificationUserActionResponse();
        userActionResponse.setActionResponse(PropertyConstants.RelIdVerifyConstants.NOTIFICATION_FRAUD_LABEL);
        Constants.getVerifyNotificationResponseMap().put(correlationID, userActionResponse);

        // calling method
        final boolean notificationResponse = authenticationServiceImpl.checkNotificationResponse(correlationID,
                WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request);

        // Test
        assertEquals(false, notificationResponse, "Notification fraud scenario");

    }

    @Test
    final void checkNotificationResponseWithNotificationIncorrectActionResponseScenario() {

        final RelIDAuthServerOAuth2Exception exn = assertThrows(RelIDAuthServerOAuth2Exception.class, () -> {
            // Precondition
            correlationID = "1234";
            WEBDEVICEFINGERPRINT = "browser-checksum";
            WEBDEVICEPARAMETERS = "{\"1234\":\"1234\"}";
            final NotificationUserActionResponse userActionResponse = new NotificationUserActionResponse();
            userActionResponse.setActionResponse("incorrect-action-response");
            Constants.getVerifyNotificationResponseMap().put(correlationID, userActionResponse);

            // calling method
            authenticationServiceImpl.checkNotificationResponse(correlationID, WEBDEVICEFINGERPRINT,
                    WEBDEVICEPARAMETERS, request);

        });

        // Test
        assertEquals("Incorrect action response found", exn.getMessage(), "Incorrect Action Response scenario");

    }

    /**
     * This should return false at the time of validating TOTP, as request is
     * null.
     */
    @Test
    final void shouldReturnFalseIfNullRequest() {

        // Precondition
        final HttpServletRequest request = null;

        // calling method
        final boolean isValid = authenticationServiceImpl.validateUserByTOTP(request, response, validateUserRequest);

        assertFalse(isValid);

    }

    /**
     * This should return false at the time of validating TOTP, as response is
     * null.
     */
    @Test
    final void shouldReturnFalseIfNullResponse() {

        // Precondition
        final HttpServletResponse response = null;

        // calling method
        final boolean isValid = authenticationServiceImpl.validateUserByTOTP(request, response, validateUserRequest);

        assertFalse(isValid);

    }

    /**
     * This should return false at the time of validating TOTP, as request body
     * is null.
     */
    @Test
    final void shouldReturnFalseIfNullRequestBody() {

        // Precondition
        final ValidateUserRequest validateUserRequest = null;

        // calling method
        final boolean isValid = authenticationServiceImpl.validateUserByTOTP(request, response, validateUserRequest);

        assertFalse(isValid);

    }

    /**
     * This should return false at the time of validating TOTP, as client Id is
     * null in session.
     */
    @Test
    final void shouldReturnFalseIfNullClientIdReceived() {

        prepareLevel1AuthRequest();

        session.setAttribute(EnterpriseInfo.CLIENT_ID, null);
        request.setSession(session);

        // calling method
        final boolean isValid = authenticationServiceImpl.validateUserByTOTP(request, response, validateUserRequest);

        assertFalse(isValid);

    }

    /**
     * This should return false at the time of validating TOTP, as client Id is
     * empty in session.
     */
    @Test
    final void shouldReturnFalseIfEmptyClientIdReceived() {

        prepareLevel1AuthRequest();

        session.setAttribute(EnterpriseInfo.CLIENT_ID, " ");
        request.setSession(session);

        // calling method
        final boolean isValid = authenticationServiceImpl.validateUserByTOTP(request, response, validateUserRequest);

        assertFalse(isValid);

    }

    /**
     * This should return false at the time of validating TOTP, as scope is null
     * in session.
     */
    @Test
    final void shouldReturnFalseIfNullScopeReceived() {

        prepareLevel1AuthRequest();

        session.setAttribute(EnterpriseInfo.SCOPE, null);
        request.setSession(session);

        // calling method
        final boolean isValid = authenticationServiceImpl.validateUserByTOTP(request, response, validateUserRequest);

        assertFalse(isValid);

    }

    /**
     * This should return false at the time of validating TOTP, as scope is null
     * in session.
     */
    @Test
    final void shouldReturnFalseIfEmptyScopeReceived() {

        prepareLevel1AuthRequest();

        session.setAttribute(EnterpriseInfo.SCOPE, " ");
        request.setSession(session);

        // calling method
        final boolean isValid = authenticationServiceImpl.validateUserByTOTP(request, response, validateUserRequest);

        assertFalse(isValid);

    }

    /**
     * This should return false at the time of validating TOTP, as username is
     * null in request.
     */
    @Test
    final void shouldReturnFalseIfNullUsernameReceived() {

        prepareLevel1AuthRequest();

        validateUserRequest.setUserName(null);

        // calling method
        final boolean isValid = authenticationServiceImpl.validateUserByTOTP(request, response, validateUserRequest);

        assertFalse(isValid);

    }

    /**
     * This should return false at the time of validating TOTP, as username is
     * empty in request.
     */
    @Test
    final void shouldReturnFalseIfEmptyUsernameReceived() {

        prepareLevel1AuthRequest();

        validateUserRequest.setUserName(" ");

        // calling method
        final boolean isValid = authenticationServiceImpl.validateUserByTOTP(request, response, validateUserRequest);

        assertFalse(isValid);

    }

    /**
     * This should return false at the time of validating TOTP, as
     * WebDevParameters is null in request.
     */
    @Test
    final void shouldReturnFalseIfNullWebDevParametersReceived() {

        prepareLevel1AuthRequest();

        validateUserRequest.setWebDeviceParameters(null);

        // calling method
        final boolean isValid = authenticationServiceImpl.validateUserByTOTP(request, response, validateUserRequest);

        assertFalse(isValid);

    }

    /**
     * This should return false at the time of validating TOTP, as
     * WebDevParameters is empty in request.
     */
    @Test
    final void shouldReturnFalseIfEmptyWebDevParametersReceived() {

        prepareLevel1AuthRequest();

        validateUserRequest.setWebDeviceParameters(" ");

        // calling method
        final boolean isValid = authenticationServiceImpl.validateUserByTOTP(request, response, validateUserRequest);

        assertFalse(isValid);

    }

    /**
     * This should return false at the time of validating TOTP, as
     * WebDevParameters is invalid in request.
     * 
     * @throws SecurityException
     * @throws NoSuchFieldException
     * @throws IllegalAccessException
     * @throws IllegalArgumentException
     */
    @Test
    final void shouldReturnFalseIfInvalidWebDevParametersReceived()
            throws NoSuchFieldException, SecurityException, IllegalArgumentException, IllegalAccessException {

        prepareLevel1AuthRequest();

        validateUserRequest.setWebDeviceParameters("key=value");

        // calling method
        final boolean isValid = authenticationServiceImpl.validateUserByTOTP(request, response, validateUserRequest);

        assertFalse(isValid);

    }

    /**
     * This testcase throws AccessDeniedException whenever totp is valid
     */
    @SuppressWarnings("deprecation")
    @Test
    final void totpValidScenario() {
        // Precondition
        prepareLevel1AuthRequest();

        try {
            Mockito.when(authenticateTotpServiceImpl.validateTotp(Mockito.anyObject(), Mockito.anyObject(),
                    Mockito.anyObject(), Mockito.anyString())).thenReturn(true);
        } catch (final TOTPValidationException e) {

        }

        final NotificationUserActionResponse actionResponse = new NotificationUserActionResponse();
        actionResponse.setResponseCode(100);
        actionResponse.setActionResponse(PropertyConstants.RelIdVerifyConstants.NOTIFICATION_ACCEPT_LABEL);
        Constants.getVerifyNotificationResponseMap().put(correlationID, actionResponse);

        final Map<String, String> deviceParameters = new HashMap<String, String>();
        deviceParameters.put("Platform", "Firefox");
        deviceParameters.put("IPAddress", "10.1.1.9");

        Mockito.when(customClientDetailService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);

        // calling method
        final boolean isTOTPValid = authenticationServiceImpl.validateUserByTOTP(request, response,
                validateUserRequest);

        // Test
        assertTrue(isTOTPValid, "Success TOTP scenario");

    }

    /**
     * This testcase throws AccessDeniedException whenever totp is valid
     */
    @SuppressWarnings("deprecation")
    @Test
    final void totpValidScenarioDiscardNotification() {
        // Precondition
        prepareLevel1AuthRequest();

        try {
            Mockito.when(authenticateTotpServiceImpl.validateTotp(Mockito.anyObject(), Mockito.anyObject(),
                    Mockito.anyObject(), Mockito.anyString())).thenReturn(true);
        } catch (final TOTPValidationException e) {

        }

        Constants.getVerifyNotificationResponseMap().remove(correlationID);

        Mockito.when(customClientDetailService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);

        // calling method
        final boolean isTOTPValid = authenticationServiceImpl.validateUserByTOTP(request, response,
                validateUserRequest);

        // Test
        assertTrue(isTOTPValid, "Send discard notification scenario");

    }

    /**
     * This testcase throws AccessDeniedException whenever totp is valid
     */
    @Test
    final void totpValidScenarioRejectNotification() {
        prepareLevel1AuthRequest();

        // Precondition
        WEBDEVICEFINGERPRINT = "12345";

        WEBDEVICEPARAMETERS = "{\"platform\":\"win32\", \"userAgent\":\"firefox\"}";

        final NotificationUserActionResponse actionResponse = new NotificationUserActionResponse();
        actionResponse.setResponseCode(100);
        actionResponse.setActionResponse(PropertyConstants.RelIdVerifyConstants.NOTIFICATION_REJECT_LABEL);
        actionResponse.setUserId(testUsername);
        Constants.getVerifyNotificationResponseMap().put(correlationID, actionResponse);

        Mockito.when(customClientDetailService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);

        // calling method
        final boolean isTOTPValid = authenticationServiceImpl.validateUserByTOTP(request, response,
                validateUserRequest);

        // Test
        assertFalse(isTOTPValid, "Reject Notification scenario");

    }

    /**
     * This testcase throws AccessDeniedException whenever totp is valid
     */
    @Test
    final void totpValidScenarioFraudNotification() {
        // Precondition
        prepareLevel1AuthRequest();

        final NotificationUserActionResponse actionResponse = new NotificationUserActionResponse();
        actionResponse.setResponseCode(100);
        actionResponse.setActionResponse(PropertyConstants.RelIdVerifyConstants.NOTIFICATION_FRAUD_LABEL);
        Constants.getVerifyNotificationResponseMap().put(correlationID, actionResponse);

        Mockito.when(customClientDetailService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);

        // calling method
        final boolean isTOTPValid = authenticationServiceImpl.validateUserByTOTP(request, response,
                validateUserRequest);

        // Test
        assertFalse(isTOTPValid, "FRAUD Notification scenario");

    }

    /**
     * This testcase throws AccessDeniedException whenever totp is valid
     */
    @SuppressWarnings("deprecation")
    @Test
    final void totpInvalidscenario() {

        // Precondition
        prepareLevel1AuthRequest();

        try {
            Mockito.when(authenticateTotpServiceImpl.validateTotp(Mockito.anyObject(), Mockito.anyObject(),
                    Mockito.anyObject(), Mockito.anyString())).thenReturn(false);
        } catch (final TOTPValidationException e) {

        }

        Constants.getVerifyNotificationResponseMap().remove(correlationID);

        Mockito.when(customClientDetailService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);

        // calling method
        final boolean isTOTPValid = authenticationServiceImpl.validateUserByTOTP(request, response,
                validateUserRequest);

        // Test
        assertFalse(isTOTPValid, "Invalid TOTP scenario");

    }

    /**
     * This testcase throws AccessDeniedException whenever totp is valid
     */
    @Test
    final void totpValidationProcessThrowsExceptionScenario() {

        // Precondition
        prepareLevel1AuthRequest();

        Constants.getVerifyNotificationResponseMap().remove(correlationID);

        Mockito.when(customClientDetailService.loadClientByClientId(Mockito.anyString())).thenReturn(clientDetails);

        // calling method
        final boolean isTOTPValid = authenticationServiceImpl.validateUserByTOTP(request, response,
                validateUserRequest);

        // Test
        assertFalse(isTOTPValid, "Invalid TOTP scenario");

    }

    @Test
    final void checkUserActionOnNotificationScenario1() {

        // Precondition
        prepareLevel1AuthRequest();
        request.getSession().setAttribute(Constants.CORRELATION_ID, null);

        Constants.getVerifyNotificationResponseMap().remove(correlationID);

        // calling method
        final boolean isTOTPValid = authenticationServiceImpl.checkUserActionOnNotification(request, response,
                validateUserRequest);

        // Test
        assertFalse(isTOTPValid, "Invalid Correlation ID scenario");
    }

    @Test
    final void checkUserActionOnNotificationScenario2() {

        // Precondition
        prepareLevel1AuthRequest();

        correlationID = "1234";

        final NotificationUserActionResponse actionResponse = new NotificationUserActionResponse();
        actionResponse.setResponseCode(100);
        actionResponse.setActionResponse(PropertyConstants.RelIdVerifyConstants.NOTIFICATION_REJECT_LABEL);
        Constants.getVerifyNotificationResponseMap().put(correlationID, actionResponse);

        final Exception e = assertThrows(RelIDNotificationRejectedException.class, () -> {
            authenticationServiceImpl.checkUserActionOnNotification(request, response, validateUserRequest);
        });

        // Test
        assertEquals("REL-ID Notification is rejected.", e.getMessage());
    }

    @Test
    final void checkUserActionOnNotificationScenario3() {

        // Precondition
        prepareLevel1AuthRequest();

        correlationID = "1234";

        final NotificationUserActionResponse actionResponse = new NotificationUserActionResponse();
        actionResponse.setResponseCode(100);
        actionResponse.setActionResponse(PropertyConstants.RelIdVerifyConstants.NOTIFICATION_ACCEPT_LABEL);
        Constants.getVerifyNotificationResponseMap().put(correlationID, actionResponse);

        // calling method
        final boolean isTOTPValid = authenticationServiceImpl.checkUserActionOnNotification(request, response,
                validateUserRequest);

        // Test
        assertTrue(isTOTPValid, "Authentication success");

    }
}
