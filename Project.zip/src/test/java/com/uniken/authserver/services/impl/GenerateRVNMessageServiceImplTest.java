package com.uniken.authserver.services.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.security.oauth2.common.exceptions.InvalidRequestException;
import org.springframework.security.oauth2.common.exceptions.InvalidScopeException;
import org.springframework.security.oauth2.common.exceptions.UnauthorizedClientException;
import org.springframework.security.oauth2.provider.NoSuchClientException;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.google.gson.reflect.TypeToken;
import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.exception.AuthGenerationAttemptCounterExceededException;
import com.uniken.authserver.exception.RelIDAuthServerOAuth2Exception;
import com.uniken.authserver.mq.publisher.RelIdVerifyMessagePublisher;
import com.uniken.authserver.repo.api.GenerateRVNMessageRepo;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.services.api.OAuth2ClientDetailsService;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.SessionConstants;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.enums.auth.OAuthResources;
import com.uniken.domains.relid.device.UserLocation;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.user.DeviceStatus;
import com.uniken.domains.relid.user.RelId;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;

@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
public class GenerateRVNMessageServiceImplTest {

    final Type hashType = new TypeToken<HashMap<String, Object>>() {
    }.getType();

    @Mock
    private OAuth2ClientDetailsService customClientDetailService;

    @Mock
    UserAuthInfoRepo userAuthInfoRepo;

    @Mock
    RelIdVerifyMessagePublisher publisher;

    @Mock
    private GenerateRVNMessageRepo generateRVNMessageRepo;

    @Mock
    private WebDevMasterService webDevMasterService;

    @InjectMocks
    private GenerateRVNMessageServiceImpl generateRVNMessageServiceImpl;

    private HttpServletRequest request = null;
    private HttpServletResponse response = null;
    private Map<String, Object> inputParameters = null;
    private MockHttpSession mockSession;
    private ServletRequestAttributes servletRequestAttributes;

    final static String clientId = "5678gbjkyghj";
    final static String testUsername = "testUser";
    final static String scopeString = "all ";
    final static String requestorID = "1234";
    final static String resourceIdsString = "[\"relid-verify-server\"]";

    final static String WEBDEVICEPARAMETERS = "{\"platform\":\"win32\", \"userAgent\":\"firefox\"}";

    final UserLocation userLocation = new UserLocation("1.322312321", "0.3453464564");

    final static String WEBDEVICEFINGERPRINT = "12345";
    final static String webDeviceUUID = "123e4567-e89b-12d3-a456-426655440000";

    final EnterpriseInfo clientDetails = Constants.GSON
            .fromJson("{\"_id\":ObjectId(\"5dfca4ab8065a92ca3f533af\"),\"enterprise_id\":\"test02\","
                    + "\"method\":\"OAuth2\",\"apple_server_certificate_dev_mode\":false,"
                    + "\"credsUploadStatusGoogle\":\"PENDING\",\"credsUploadStatusApple\":\"PENDING\","
                    + "\"resource_ids\":[\"relid-verify-server\"],"
                    + "\"authorized_grant_types\":[\"client_credentials\",\"referesh_token\"],"
                    + "\"access_token_validity_seconds\":8765,\"enable_refresh_token\":true,"
                    + "\"refresh_token_validity_seconds\":8876,"
                    + "\"client_id\":\"ODQ3N2ZlYTYtY2U5OC00MTc4LWI3ZmUtYTZjZTk4NzE3OGRj\","
                    + "\"client_secret\":\"iq7Kip8aZU9+p9ThZZeZ4WLmJzEUMUvNVcK8Fmin/0ocpfoqcn+zufex96s748PiTq7PMKJsyR1Zzp/1s3dREjRmPGR+yjizL5rWY6e7TPI=\","
                    + "\"secret_required\":false,\"scoped\":false,\"scope\":[\"all\",\"oidc\",\"login\"],"
                    + "\"registered_redirect_uri\":[\"http://localhost:8080/GM/enterprise-management.htm\"],"
                    + "\"registered_error_uri\":[\"http://localhost:8080/GM/enterprise-management.htm\"],"
                    + "\"authorities\":[],\"auto_approve\":false}", EnterpriseInfo.class);

    final EnterpriseInfo clientDetailsNew = Constants.GSON.fromJson(
            "{\"_id\":ObjectId(\"5df9af6320bc1363dff1cb01\"),\"enterprise_id\":\"CBCVerify\",\"method\":\"OAuth2\",\"apple_server_certificate_dev_mode\":false,\"credsUploadStatusGoogle\":\"PENDING\",\"credsUploadStatusApple\":\"PENDING\",\"resource_ids\":[\"relid-verify-server\",\"user-api-server\",\"OIDC\"],\"authorized_grant_types\":[\"refresh_token\",\"authorization_code\",\"client_credentials\"],\"access_token_validity_seconds\":180,\"enable_refresh_token\":false,\"refresh_token_validity_seconds\":0,\"client_id\":\"MTEzMmZhNTEtOGU1Zi00NTQyLWIyZmEtNTE4ZTVmZjU0MjU1\",\"client_secret\":\"jPnN2ptGYk4p8NKwY8DJtIfyIulxfOvo7zwnpl9MVKBEm0QDwGOqDLiuMhrgDBcccY8nxxTkDJ8ANWqZnm7lh+qYJfHe+UWI+fu1YpLPpKc=\",\"secret_required\":false,\"scoped\":false,\"scope\":[\"all\"],\"authorities\":[],\"registered_redirect_uri\":[\"http://127.0.0.1:8008/relid/authserver/oauth/login\",\"http://127.0.0.1:8080/GM/show-login-page.htm\"],\"auto_approve\":false,\"mapped_appagent_name\":\"tunneltestagent\",\"mapped_appagent_uuid\":\"e808085f-875f-455e-8808-5f875f255e93\",\"apple_server_certificate_content\":\"MIINAwIBAzCCDMoGCSqGSIb3DQEHAaCCDLsEggy3MIIMszCCB08GCSqGSIb3DQEHBqCCB0Awggc8AgEAMIIHNQYJKoZIhvcNAQcBMBwGCiqGSIb3DQEMAQYwDgQIfh5AyahrRsoCAggAgIIHCMrbMZluTN17B1cYJfEYu9kmIGoVOfCPn5kVHcjFW8LZc8QSSXCEdTCJAhugsNvit85ScGyJxZLGoxCBCJaP8Ym7J03IUmoXtzApe8jtm1KSygAxJlgUzSmqpisNeSW8fvaaS6ZZjl+EnKnhykTwXv0Is805H6r7yAD2GR1/GVktwLbxsu/al3u2XVedbjnnZQgHx8HC2KmrQatBbxeXSD8lkEIwXGL6XjvgAZ7rLIcm//qzri+FrI8AgeRljYnj9sJk/HRxXZa/3KFUEiuEcYiv77E1GbV/h5ztP2RwmAlJ0Oue185+yAJlG4ZcG5dHo7jIqOBbMkz1xAc2AqKq0JjU5IulBtE42TxG5Gb/k7Ppy/b9bnFrUAYA3306L9D6PigyEhor+w5hUTsFeZxwMB9++wpBdLHWm2qQFDpvuVWad+0QlkpL3TLPCLTrV2llpZsiios8N9HdYz9xqzC4DO5LJ0NOYNOfv+Tfelw/JtjZh5bnl+rV2qFdRIfz9uZzLKMPLRRWPKcFraLZvesmkyfSyH57HJlEts5IT22elvHjehqDzL409vzy+rmcf8P15TTXJgvXQPJsAtghJSXuUkT8EBpl577/pd5Y1C0sXlBaF6ibQm0/83YELHcQEpR8lJWmn1BPwzFcxI2uNtKl3L1fH0snyoT/N0elrNkpUKi0WabqKmOiAz3S7ZCAjnDR8eTPrqa++W7E/fXXe8K/vyfOTmz8ZfwouVPdQX71/oOoI/LU5NC4miPncQPJXYiQ/yU3TFIA1ZKC6oYEQjRCJKKcY5OCHSjlVxX8HOSZ0mZjcvjQJPzTXdRvLf2Go3Y07ZFJfK7Ka9AFQnDaVS5PDCoq5/ZdMfup07kB4b2VQieYVwRduLorxgmRCXZLsPXSmqedj44DUr1uZujK9WlFJ1bf1ZKdRHLqb/G2ElZCHGMhnq9S0Uh0LxrlG6aLy6+RfTqffNtwJOlOfZUOz7aZN3JaD1GD5FT79wVGSqQO81EDXB2dIOO+24ZFTy2KGYicrRRMuSLuSDURDhQnOugZe8a85zX6KXSmtz+To0jhL3CducRLy/N2cx+VUqXr5zQm9ZkvKGk9gTkNqFOBeHYDyBNHzjv+/z82yEtFtoGcybnhJXXhfMar+JXRX5NZRm2Y3b9pZjXqoHulu6Nrz8ngTuwwuEMo/fRKucyOrar+tIDw2qCOGmg9GI8B8fN+UCuKCiQLu/6ojtvpCwgeoN41GMTQhFIVxGD4UOKzeehvdLaXRtItFNgaMs1TwSn2WOA1ID1kSsYg6fxA4EXnHVrMJaTWjxwGaLmnzn5HugkwN62iiBxizMECjhmTnULAjO7JHA4mKv+KYU2jPfmBN2c8Co6DsQH7niBRNAixrZvsVsmpbXFH7mbuA7b6M/dmj+zKySxf0AhtpL7JKSsNbyOWuoEUZLG62ES8jLDiRo3B2U7z8AJc2pbpfjZE9Fgwf45RSCWmlPeBGjDx/nOv+7EzqhKGPl5FoTK8buz0sinXdOnf5zlzoeu1D9SwP2KE8fobchECinHlAduWR/SahMs5Jz6hMHndOF5WEkZlakSCpYQX5XLybfPm6EQp2FB1eIRXEIP+Asm7d7oJshAGfSY+sydsf1+vOpwIcYX/ATqBlhvsb2XOnGZTi+oTy1dgeUf5OFM1F3E/Jp1zn0lUSgY3AgM1FMnFOVgNMHYIgdEBGEPhbQGqb4ANhxBjOioSGKAGyLbr8XdMZLaC+b2mNgIdYjggJRtn1ei/v10LM2RwBMaJ/j6I1Gr8D47zEyNA9m+bPaPfHpwsPQaqYNXncNafSp7LS3iUGhdqviPklIp5OdfxVQGKVkCMMS7+1aNwEZA+sr8/XYrAXUT23jK4tvUoUpCG+/QrrA0Lmg/41eXymWTwjQTtlI+WylZXtQO8nU1D9mujd/3mjQ7tJqxp7NgbLcvf/u5vk0btv4LPLL8dGgTuUHtzWygxYSK5D3j8Bd4xm0I1M3lwUdKLNDhvZ7vTSzarzOf51eTl1caOEJAqX2WR2xpnyeY9Bn5h7miv43Nv8aHYgy7D8yELWGIuhN0P8r7GlW5DWL2pwaqI76HLOeSFpnbWCGCq5rB80GSuRM7E8p8MqGu94BP4wPzdjh+74zgeTRkVztTBVZAV7PBgc6CHfZS73xPkF82IfEbCJFN+98fDaJfYtrfaN3CkF6oI/IC72jE6P/yNIs31leXPbj8N+LnS+FKonnW9BPMv9pw00x/Su6QS5UBYQkWXa8DuN7cObdJ9k6Y8Yo1ADPKUymT1B94yGw9FILYYrnEw5BprobEGkyv7qYHUmNq5/djW+SdIZDuXb4sAkE5QFQtEitalav7VAHLZl+ma1rZ8LhPuXG4m3rmHyMcJTNnod6W5CsWAagFgJH+7bDCCBVwGCSqGSIb3DQEHAaCCBU0EggVJMIIFRTCCBUEGCyqGSIb3DQEMCgECoIIE7jCCBOowHAYKKoZIhvcNAQwBAzAOBAhP2Y6ltJrVXwICCAAEggTIJ0aIGjc13vVhjo5dRjOh0m/p+GMWhBpsshkB/o885emHwk/uvinxiDI+/ub593esCSTYiQVitWFct93GVKNNeehsY+ubl2Ys/hnlZyy59YkZhzP6H2nirGeIu0ALUZhxIIHSvOZnXuqTxkSzyi3X8kwVQU5yjlfesnTM9qgC6GCi7xuvtSK9DrdUZ30R552U5FLPNECMCc1RhitRLUiodZrZSU8Dj2fmM911jiJpGYs4AFpezGLQRaKXS0uRZOAIGgc6/qag1FpPo8VjwF6Mc5mv4nsXNsCwEV9KXCRVbTveytzmzwoJooYkh7zNCA/yQwcBPd88doG/e5TU8X+fgRfvVP9FpCKFM8qsTcdG7+Zh1wSwKoMCkvuuch7767E98373utg11QFsRY4mmiuh2jkLsmLuVKkBIiS8M2hHAfr1iSvI+fdJ0ldYHHK9CrGybfOrWqn7SCI/KbVhG1x0/UzLcqxrGXHyj7V+8hPAydOmr/GlLoe8Hw7UqYM6qoTY9SNcA02yoTkuRe+QxsWzTScbV+G6emcUlf53XF3LsPbCFXfLpkZ1NYeLxZuIxxDm7AtpBWHOqqAGyNbtxX9II0MCiiSNN61TJcoje1OWVOihye94BKmKUVSys/JZjZEVsKHNbaU7OpQ4G3jTgXiaPf6BvkWdJMYGmz59LcDC01pXX+NTUwXogOQUOvl/FSLjAv0zdzHXvYtohkbK6poZba+02b9+0updDzDCoRjCUg6eAlgfyO7aUr0ufFk9hD9ij0JJoIlKe8AAqTEwligKZjgs+nHiqyGnazkMIz4vGOn5XkYcYQOMav4Wo7RaOkqDuHED+nhYMeslldJTXcpOeZmgN1nvyh993gvTbvibbdvqCZ9Jc9D6kksHha5C8qhCMfb8BHU6mkuXwM56V+/mFbETGAY2CwC24e6cXhlSSsqMdNBASrJJbQTGFa3FF9SqceCOwKzkiyHIuyMQARP7UHQ2JHkKrERKvryjhJPpywu4ILDCpbw6CR2b6BwWBg1LyhZmYDvTkZULRybviHsgzqCa+/AER7hoXw/s5UO4CdBmtklMqZ6686r4Mdwv6WahsFoOHkmQue3piutyDPjd0fUcCR6Rt0OZNHHjUnfH3jsyMk9JwOpKiMr2QjBvApxdvp9itJaIh8ZXbibAoyBn+WVYUPQPjir8exaQShZuiUT5E6g2O4Qq1JvX+rbtxeXxBnryb0hF+93kQDrk2GVzXTA4qcDtaw9iH8viyB4LJOyq88XErbCJxlQclawRhyxi+n917WFkxJ4QdCDEBvF2Ru1MtScVGlOAixdL48rPTNth+rXFdV5nkzkzCq4r1F2dDQXSEP4OvY89JU/wC8sAJmkrtz6Hh05MHqOl+LyObTPov5YSZq0lJa2Ge2TWU/XO4mNyzjzDCqvKmZ78LNuyIS6XS/CbRvVs0Ufdp9PeUfqXAAy7Vd66/Kdm7liNxrfB0uOvUPZrl7Q4ZSk18991JPYt5p3wyUGisyU0VcTQrzYhBylBbl19yN/3vxwCCJRDX4GHGhWzHqufSxCnqcuUYdwfCo72FMLnUcsqe7dBVzfbpOxzO+/XN1Qhhu7oz9gRaPOwH0LUA19nf9eflTTdRucp5MtiZoDbMUAwGQYJKoZIhvcNAQkUMQweCgBvAG4AawBhAHIwIwYJKoZIhvcNAQkVMRYEFHNKUx4EhDXShY69cGBF5HaRW2vHMDAwITAJBgUrDgMCGgUABBR7lESH7sO8GNH30zPJbC9f+8S/3AQI4BCxYzPIqaECAQE=\",\"apple_server_certificate_password\":\"yKbAg8gQMBkp4uGDB6Ou0A==\",\"google_server_authentication_key\":\"/IHTif4HQl5XnNfIYvTsm4AozoAGaMPFfWpxltUNSIsDnu09q/Z6ngvStV0T1SCc\"}",
            EnterpriseInfo.class);

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {
    }

    private HttpServletResponse setFixedHeader(final HttpServletResponse responseLocal) {
        responseLocal.setHeader("Cache-Control", "no-store");
        responseLocal.setHeader("Pragma", "no-cache");
        responseLocal.setHeader("Content-Type", "application/json;charset=UTF-8");
        responseLocal.setHeader("X-FRAME-OPTIONS", "DENY");
        return responseLocal;
    }

    @BeforeEach
    void setUp() throws Exception {
        request = mock(HttpServletRequest.class);
        final HttpServletResponse responseLocal = mock(HttpServletResponse.class);
        response = setFixedHeader(responseLocal);
        mockSession = new MockHttpSession();
        inputParameters = new HashMap<String, Object>();
        servletRequestAttributes = new ServletRequestAttributes(request);
        RequestContextHolder.setRequestAttributes(servletRequestAttributes);
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    /**
     * This should throw InvalidRequestException whenever request object found
     * to be null
     */
    @Test
    final void shouldThrowInvalidRequestExceptionIfNullRequest() {

        final InvalidRequestException exn = assertThrows(InvalidRequestException.class, () -> {

            // Precondition
            request = null;

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals("HttpServletRequest is null or empty", exn.getMessage(), "Null Request object testcase");

    }

    /**
     * This should throw InvalidRequestException whenever response object found
     * to be null
     */
    @Test
    final void shouldThrowInvalidRequestExceptionIfNullResponse() {

        final InvalidRequestException exn = assertThrows(InvalidRequestException.class, () -> {

            // Precondition
            response = null;

            // calling method
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals("HttpServletResponse is null or empty", exn.getMessage(), "Null Response object testcase");

    }

    /**
     * This should throw InvalidRequestException whenever input parameters found
     * to be null
     */
    @Test
    final void shouldThrowInvalidRequestExceptionIfNullInputParameters() {

        final InvalidRequestException exn = assertThrows(InvalidRequestException.class, () -> {

            // Precondition
            inputParameters = null;

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals("InputParameters are null or empty", exn.getMessage(), "Null input parameter testcase");

    }

    /**
     * This should throw InvalidRequestException whenever input parameters found
     * to be empty
     */
    @Test
    final void shouldThrowInvalidRequestExceptionIfEmptyInputParameters() {

        final InvalidRequestException exn = assertThrows(InvalidRequestException.class, () -> {

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals("InputParameters are null or empty", exn.getMessage(), "Empty input parameters testcase");

    }

    /**
     * This testcase throws InvalidRequestException whenever null client id
     * received
     */
    @Test
    final void shouldThrowsInvalidRequestExceptionIfNullClientIdReceived() {

        final InvalidRequestException exn = assertThrows(InvalidRequestException.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, null);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals("clientId is null or empty", exn.getMessage(), "Null client id testcase");

    }

    /**
     * This testcase throws InvalidRequestException whenever empty client id
     * received
     */
    @Test
    final void shouldThrowsInvalidRequestExceptionIfEmptyClientIdReceived() {

        final InvalidRequestException exn = assertThrows(InvalidRequestException.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, " ");

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals("clientId is null or empty", exn.getMessage(), "Empty client id testcase");

    }

    /**
     * This testcase throws InvalidRequestException if null scope is received
     */
    @Test
    final void shouldThrowsInvalidRequestExceptionIfNullScopeReceived() {

        final InvalidRequestException exn = assertThrows(InvalidRequestException.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(EnterpriseInfo.SCOPE, null);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals("scope is null or empty", exn.getMessage(), "Null scope test case");

    }

    /**
     * This testcase throws InvalidRequestException if empty scope is received
     */
    @Test
    final void shouldThrowsInvalidRequestExceptionIfEmptyScopeReceived() {

        final InvalidRequestException exn = assertThrows(InvalidRequestException.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(EnterpriseInfo.SCOPE, " ");

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals("scope is null or empty", exn.getMessage(), "Empty scope test case");

    }

    /**
     * This testcase throws IllegalArgumentException whenever username is null
     */
    @Test
    final void shouldThrowsIllegalArgumentExceptionIfNullUsernameReceived() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, null);
            inputParameters.put(EnterpriseInfo.SCOPE, scopeString);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals("username is null or empty", exn.getMessage(), "Username null test case");

    }

    /**
     * This testcase throws IllegalArgumentException whenever username is empty
     */
    @Test
    final void shouldThrowsIllegalArgumentExceptionIfEmptyUsernameReceived() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, " ");
            inputParameters.put(EnterpriseInfo.SCOPE, scopeString);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals("username is null or empty", exn.getMessage(), "Empty user name test case");

    }

    /**
     * This testcase throws IllegalArgumentException whenever WebDeviceParameter
     * is null
     */
    @Test
    final void shouldThrowsIllegalArgumentExceptionIfNullWebDeviceParameterReceived() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, null);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, WEBDEVICEFINGERPRINT);

            inputParameters.put(EnterpriseInfo.SCOPE, scopeString);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals("webDeviceParameters are null or empty", exn.getMessage(), "Null device parameter case test case");

    }

    /**
     * This testcase throws IllegalArgumentException whenever WebDeviceParameter
     * is empty
     */
    @Test
    final void shouldThrowsIllegalArgumentExceptionIfEmptyWebDeviceParameterReceived() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, " ");
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, WEBDEVICEFINGERPRINT);
            inputParameters.put(EnterpriseInfo.SCOPE, scopeString);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals("webDeviceParameters are null or empty", exn.getMessage(),
                "Empty device parameter case test case");

    }

    /**
     * This testcase throws IllegalArgumentException whenever
     * WebDeviceFingerprint is null
     */
    @Test
    final void shouldThrowsIllegalArgumentExceptionIfNullWebDeviceFingerprintReceived() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, WEBDEVICEPARAMETERS);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, null);
            inputParameters.put(EnterpriseInfo.SCOPE, scopeString);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals("webDeviceFingerprint is null or empty", exn.getMessage(),
                "Null device fingerprint case test case");

    }

    /**
     * This testcase throws IllegalArgumentException whenever
     * WebDeviceFingerprint is empty
     */
    @Test
    final void shouldThrowsIllegalArgumentExceptionIfEmptyWebDeviceFingerprintReceived() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, WEBDEVICEPARAMETERS);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, " ");
            inputParameters.put(EnterpriseInfo.SCOPE, scopeString);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals("webDeviceFingerprint is null or empty", exn.getMessage(),
                "Empty device fingerprint case test case");

    }

    /**
     * This testcase throws IllegalArgumentException whenever invalid json value
     * received in WebDeviceParameter parameter
     */
    @Test
    final void shouldThrowsIllegalArgumentExceptionIfInvalidWebDeviceParameterReceived() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, "key=value");
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, WEBDEVICEFINGERPRINT);
            inputParameters.put(EnterpriseInfo.SCOPE, scopeString);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals("webDeviceFingerprint is invalid", exn.getMessage(), "Invalid device parameter case test case");

    }

    /**
     * Throws IllegalArgumentException whenever blocked device status found
     */
    @Test
    final void shouldThrowsIllegalArgumentExceptionIfBlockedWebDeviceFound() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {

            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
            inputParameters.put(EnterpriseInfo.SCOPE, scopeString);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, WEBDEVICEPARAMETERS);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, WEBDEVICEFINGERPRINT);
            final Map<String, Object> webDeviceParameter = Constants.GSON.fromJson(WEBDEVICEPARAMETERS, hashType);
            final WebDevMaster webDevice = new WebDevMaster(webDeviceUUID, DeviceStatus.BLOCKED.getName(), userLocation,
                    webDeviceParameter, new Date(), new Date(), WEBDEVICEFINGERPRINT);
            when(webDevMasterService.fetchWebDeviceMaster(anyString())).thenReturn(webDevice);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals(String.format("WebDevMaster device is BLOCKED for UUID = %s", webDeviceUUID), exn.getMessage(),
                "Blocked web device test case");
    }

    /**
     * Throws InvalidScopeException whenever invalid enterprise scope found
     */
    @Test
    final void shouldThrowsInvalidScopeExceptionIfInvalidEnterpriseScopeReceived() {

        final String invalidScope = "incorrect";

        final InvalidScopeException exn = assertThrows(InvalidScopeException.class, () -> {

            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, WEBDEVICEPARAMETERS);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, WEBDEVICEFINGERPRINT);
            inputParameters.put(EnterpriseInfo.SCOPE, invalidScope);

            final Map<String, Object> webDeviceParameter = Constants.GSON.fromJson(WEBDEVICEPARAMETERS, hashType);
            final WebDevMaster webDevice = new WebDevMaster(webDeviceUUID, DeviceStatus.ACTIVE.getName(), userLocation,
                    webDeviceParameter, new Date(), new Date(), WEBDEVICEFINGERPRINT);
            when(webDevMasterService.fetchWebDeviceMaster(anyString())).thenReturn(webDevice);
            when(customClientDetailService.loadClientByClientId(anyString())).thenReturn(clientDetails);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals(String.format("Invalid scope: %s", invalidScope), exn.getMessage(),
                "Invalid enterprise scope test case");
    }

    /**
     * This testcase throws UnauthorizedClientException whenever incorrect
     * resource id is received
     */
    @Test
    final void shouldThrowsUnauthorizedClientExceptionIfIncorrectResourceIDReceived() {

        final UnauthorizedClientException exn = assertThrows(UnauthorizedClientException.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
            inputParameters.put(EnterpriseInfo.SCOPE, scopeString);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, WEBDEVICEPARAMETERS);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, WEBDEVICEFINGERPRINT);
            final Map<String, Object> webDeviceParameter = Constants.GSON.fromJson(WEBDEVICEPARAMETERS, hashType);
            final WebDevMaster webDevice = new WebDevMaster(webDeviceUUID, DeviceStatus.ACTIVE.getName(), userLocation,
                    webDeviceParameter, new Date(), new Date(), WEBDEVICEFINGERPRINT);
            when(webDevMasterService.fetchWebDeviceMaster(anyString())).thenReturn(webDevice);
            when(customClientDetailService.loadClientByClientId(anyString())).thenReturn(clientDetails);
            final Set<String> resourceIds = new HashSet<String>();
            resourceIds.add(OAuthResources.RELID_VERIFY_SERVER.getResourceId());
            clientDetails.setResourceIds(resourceIds);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals(String.format("client with id: %s does not have the OIDC privileges", clientId), exn.getMessage(),
                "Incorrect Resource ID testcase");
    }

    /**
     * This testcase throws IllegalArgumentException whenever null resource id
     * is received
     */
    @Test
    final void shouldThrowsIllegalArgumentExceptionIfNullResourceIDReceived() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
            inputParameters.put(EnterpriseInfo.SCOPE, scopeString);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, WEBDEVICEPARAMETERS);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, WEBDEVICEFINGERPRINT);
            final Map<String, Object> webDeviceParameter = Constants.GSON.fromJson(WEBDEVICEPARAMETERS, hashType);
            final WebDevMaster webDevice = new WebDevMaster(webDeviceUUID, DeviceStatus.ACTIVE.getName(), userLocation,
                    webDeviceParameter, new Date(), new Date(), WEBDEVICEFINGERPRINT);
            when(webDevMasterService.fetchWebDeviceMaster(anyString())).thenReturn(webDevice);
            when(customClientDetailService.loadClientByClientId(anyString())).thenReturn(clientDetails);
            clientDetails.setResourceIds(null);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals(String.format("OIDC resource is null for client with id: %s ", clientId), exn.getMessage(),
                "OIDC Resource null test case");
    }

    /**
     * This test case throws IllegalArgumentException whenever incorrect userid
     * received
     */
    @Test
    final void shouldThrowsIllegalArgumentExceptionIfIncorrectUserIDReceived() {

        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, "incorrect");
            inputParameters.put(EnterpriseInfo.SCOPE, scopeString);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, WEBDEVICEPARAMETERS);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, WEBDEVICEFINGERPRINT);
            final Map<String, Object> webDeviceParameter = Constants.GSON.fromJson(WEBDEVICEPARAMETERS, hashType);
            final WebDevMaster webDevice = new WebDevMaster(webDeviceUUID, DeviceStatus.ACTIVE.getName(), userLocation,
                    webDeviceParameter, new Date(), new Date(), WEBDEVICEFINGERPRINT);
            when(webDevMasterService.fetchWebDeviceMaster(anyString())).thenReturn(webDevice);
            when(customClientDetailService.loadClientByClientId(anyString())).thenReturn(clientDetails);
            final Set<String> resourceIds = new HashSet<String>();
            resourceIds.add(OAuthResources.OIDC.getResourceId());
            clientDetails.setResourceIds(resourceIds);

            when(userAuthInfoRepo.fetchUserDetailsFromLoginId(anyString())).thenReturn(null);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals(String.format("User : %s is does NOT present in RELID system", "incorrect"), exn.getMessage(),
                "User not found testcase");
    }

    /**
     * This testcase throws RelIDAuthServerOAuth2Exception whenever invalid user
     * status found
     */
    @Test
    final void shouldThrowsRelIDAuthServerOAuth2ExceptionIfInvalidUserStatusReceived() {

        final RelIDAuthServerOAuth2Exception exn = assertThrows(RelIDAuthServerOAuth2Exception.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
            inputParameters.put(EnterpriseInfo.SCOPE, scopeString);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, WEBDEVICEPARAMETERS);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, WEBDEVICEFINGERPRINT);
            final Map<String, Object> webDeviceParameter = Constants.GSON.fromJson(WEBDEVICEPARAMETERS, hashType);
            final WebDevMaster webDevice = new WebDevMaster(webDeviceUUID, DeviceStatus.ACTIVE.getName(), userLocation,
                    webDeviceParameter, new Date(), new Date(), WEBDEVICEFINGERPRINT);
            when(webDevMasterService.fetchWebDeviceMaster(anyString())).thenReturn(webDevice);
            when(customClientDetailService.loadClientByClientId(anyString())).thenReturn(clientDetails);
            final Set<String> resourceIds = new HashSet<String>();
            resourceIds.add(OAuthResources.OIDC.getResourceId());
            clientDetails.setResourceIds(resourceIds);

            final UserAuthInfoVO userAuthInfoVO = new UserAuthInfoVO();
            userAuthInfoVO.setUserId(testUsername);
            userAuthInfoVO.setUserStatus(RelIdUserStatus.CREATED);
            when(userAuthInfoRepo.fetchUserDetailsFromLoginId(anyString())).thenReturn(userAuthInfoVO);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals(String.format("User [%s] has invalid status in RELID system", testUsername), exn.getMessage(),
                "Invalid user status test case");
    }

    /**
     * This should throws RelIDAuthServerOAuth2Exception if user found to be NON
     * REL-ID Verify user
     */
    @Test
    final void shouldThrowsRelIDAuthServerOAuth2ExceptionIfInvalidRelIDZeroUserReceived() {

        final RelIDAuthServerOAuth2Exception exn = assertThrows(RelIDAuthServerOAuth2Exception.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
            inputParameters.put(EnterpriseInfo.SCOPE, scopeString);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, WEBDEVICEPARAMETERS);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, WEBDEVICEFINGERPRINT);

            final Map<String, Object> webDeviceParameter = Constants.GSON.fromJson(WEBDEVICEPARAMETERS, hashType);
            final WebDevMaster webDevice = new WebDevMaster(webDeviceUUID, DeviceStatus.ACTIVE.getName(), userLocation,
                    webDeviceParameter, new Date(), new Date(), WEBDEVICEFINGERPRINT);

            when(webDevMasterService.fetchWebDeviceMaster(anyString())).thenReturn(webDevice);
            when(customClientDetailService.loadClientByClientId(anyString())).thenReturn(clientDetails);

            final Set<String> resourceIds = new HashSet<String>();
            resourceIds.add(OAuthResources.OIDC.getResourceId());

            clientDetails.setResourceIds(resourceIds);

            final UserAuthInfoVO userAuthInfoVO = new UserAuthInfoVO();
            userAuthInfoVO.setUserId(testUsername);
            userAuthInfoVO.setUserStatus(RelIdUserStatus.ACTIVE);
            userAuthInfoVO.setRelIdZeroEnabled(false);
            when(userAuthInfoRepo.fetchUserDetailsFromLoginId(anyString())).thenReturn(userAuthInfoVO);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Tests
        assertEquals(
                String.format("User [%s] is not enabled for REL-ID Verify notifications in RELID system", testUsername),
                exn.getMessage(), "Non-RELID verify enabled user test case");
    }

    /**
     * This test case throws RelIDAuthServerOAuth2Exception If invalid user
     * device status found
     */
    @Test
    final void shouldThrowsRelIDAuthServerOAuth2ExceptionIfInvalidUserDeviceStatusReceived() {

        final RelIDAuthServerOAuth2Exception exn = assertThrows(RelIDAuthServerOAuth2Exception.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
            inputParameters.put(EnterpriseInfo.SCOPE, scopeString);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, WEBDEVICEPARAMETERS);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, WEBDEVICEFINGERPRINT);
            final Map<String, Object> webDeviceParameter = Constants.GSON.fromJson(WEBDEVICEPARAMETERS, hashType);
            final WebDevMaster webDevice = new WebDevMaster(webDeviceUUID, DeviceStatus.ACTIVE.getName(), userLocation,
                    webDeviceParameter, new Date(), new Date(), WEBDEVICEFINGERPRINT);
            when(webDevMasterService.fetchWebDeviceMaster(anyString())).thenReturn(webDevice);
            when(customClientDetailService.loadClientByClientId(anyString())).thenReturn(clientDetails);
            final Set<String> resourceIds = new HashSet<String>();
            resourceIds.add(OAuthResources.OIDC.getResourceId());
            clientDetails.setResourceIds(resourceIds);

            final UserAuthInfoVO userAuthInfoVO = new UserAuthInfoVO();
            userAuthInfoVO.setUserId(testUsername);
            userAuthInfoVO.setUserStatus(RelIdUserStatus.ACTIVE);
            userAuthInfoVO.setRelIdZeroEnabled(true);

            final RelId deviceOne = new RelId();
            deviceOne.setRelIdStatus(RelIdUserStatus.CREATED);
            final List<RelId> devices = new ArrayList<RelId>();
            devices.add(deviceOne);
            userAuthInfoVO.setRelIds(devices);
            when(userAuthInfoRepo.fetchUserDetailsFromLoginId(anyString())).thenReturn(userAuthInfoVO);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals(
                String.format("User [%s] has no valid device in RELID system to generate notification", testUsername),
                exn.getMessage(), "Invalid device test case");
    }

    /**
     * This testcase generates notification successfully
     */
    @Test
    final void shouldGenerateNotificationSuccess() {
        // Precondition
        inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
        inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
        inputParameters.put(EnterpriseInfo.SCOPE, scopeString);
        inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, WEBDEVICEPARAMETERS);
        inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, WEBDEVICEFINGERPRINT);
        inputParameters.put(WebDevMaster.USER_LOCATION_STR, Constants.GSON.toJson(userLocation));
        inputParameters.put(Constants.REQ_PARAM_REMEMBER_ME, false);

        final Map<String, Integer> generationAttemptCounter = new HashMap<String, Integer>();
        generationAttemptCounter.put(AuthType.RELID_VERIFY.name(), 5);
        mockSession.setAttribute(SessionConstants.AUTH_GENERATION_ATTEMPT_COUNTER, generationAttemptCounter);

        final Map<String, Object> webDeviceParameter = Constants.GSON.fromJson(WEBDEVICEPARAMETERS, hashType);
        final WebDevMaster webDevice = new WebDevMaster(webDeviceUUID, DeviceStatus.ACTIVE.getName(), userLocation,
                webDeviceParameter, new Date(), new Date(), WEBDEVICEFINGERPRINT);
        // when(webDevMasterService.fetchWebDeviceMaster(anyString())).thenReturn(webDevice);
        when(customClientDetailService.loadClientByClientId(anyString())).thenReturn(clientDetails);
        when(request.getSession()).thenReturn(mockSession);
        when(request.getRemoteAddr()).thenReturn("127.0.0.1");
        // final byte bytes[] =
        // String.valueOf(System.currentTimeMillis()).getBytes();
        when(request.getAttribute(Constants.REQUESTOR_ID)).thenReturn("123456");

        final Set<String> resourceIds = new HashSet<String>();
        resourceIds.add(OAuthResources.OIDC.getResourceId());
        clientDetails.setResourceIds(resourceIds);

        final UserAuthInfoVO userAuthInfoVO = new UserAuthInfoVO();
        userAuthInfoVO.setUserId(testUsername);
        userAuthInfoVO.setUserStatus(RelIdUserStatus.ACTIVE);
        userAuthInfoVO.setRelIdZeroEnabled(true);

        final RelId deviceOne = new RelId();
        deviceOne.setRelIdStatus(RelIdUserStatus.ACTIVE);
        final List<RelId> devices = new ArrayList<RelId>();
        devices.add(deviceOne);
        userAuthInfoVO.setRelIds(devices);
        when(userAuthInfoRepo.fetchUserDetailsFromLoginId(anyString())).thenReturn(userAuthInfoVO);

        // calling method
        response.setHeader("X-FRAME-OPTIONS", "DENY");
        final boolean ret = generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        // Test
        assertEquals(true, ret, "Success testcase");
    }

    @Test
    final void testGenerationAttemptCounterExceedCase() {
        // Precondition
        inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
        inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
        inputParameters.put(EnterpriseInfo.SCOPE, scopeString);
        inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, WEBDEVICEPARAMETERS);
        inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, WEBDEVICEFINGERPRINT);
        inputParameters.put(WebDevMaster.USER_LOCATION_STR, Constants.GSON.toJson(userLocation));
        inputParameters.put(Constants.REQ_PARAM_REMEMBER_ME, false);

        final Map<String, Integer> generationAttemptCounter = new HashMap<String, Integer>();
        generationAttemptCounter.put(AuthType.RELID_VERIFY.name(), 5);
        mockSession.setAttribute(SessionConstants.AUTH_GENERATION_ATTEMPT_COUNTER, generationAttemptCounter);

        // final Map<String, Object> webDeviceParameter =
        // Constants.GSON.fromJson(WEBDEVICEPARAMETERS, hashType);
        // final WebDevMaster webDevice = new WebDevMaster(webDeviceUUID,
        // DeviceStatus.ACTIVE.getName(), userLocation,
        // webDeviceParameter, new Date(), new Date(), WEBDEVICEFINGERPRINT);
        // when(webDevMasterService.fetchWebDeviceMaster(anyString())).thenReturn(webDevice);
        when(customClientDetailService.loadClientByClientId(anyString())).thenReturn(clientDetails);
        when(request.getSession()).thenReturn(mockSession);
        when(request.getRemoteAddr()).thenReturn("127.0.0.1");
        // final byte bytes[] =
        // String.valueOf(System.currentTimeMillis()).getBytes();
        when(request.getAttribute(Constants.REQUESTOR_ID)).thenReturn("123456");

        final Set<String> resourceIds = new HashSet<String>();
        resourceIds.add(OAuthResources.OIDC.getResourceId());
        clientDetails.setResourceIds(resourceIds);

        final UserAuthInfoVO userAuthInfoVO = new UserAuthInfoVO();
        userAuthInfoVO.setUserId(testUsername);
        userAuthInfoVO.setUserStatus(RelIdUserStatus.ACTIVE);
        userAuthInfoVO.setRelIdZeroEnabled(true);

        final RelId deviceOne = new RelId();
        deviceOne.setRelIdStatus(RelIdUserStatus.ACTIVE);
        final List<RelId> devices = new ArrayList<RelId>();
        devices.add(deviceOne);
        userAuthInfoVO.setRelIds(devices);
        when(userAuthInfoRepo.fetchUserDetailsFromLoginId(anyString())).thenReturn(userAuthInfoVO);

        // calling method
        response.setHeader("X-FRAME-OPTIONS", "DENY");

        for (int i = 1; i <= 5; i++) {
            if (i == 5) {
                final Exception e = assertThrows(AuthGenerationAttemptCounterExceededException.class, () -> {
                    generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);
                });
                assertEquals("RELID-Verify Notification Generation Attempt Counter Exhausted", e.getMessage());
            } else {
                final boolean ret = generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response,
                        inputParameters);
                assertEquals(true, ret, "RELID Verify Notification Generated Successfully");
            }
        }
    }

    /**
     * This test case throws NoSuchClientException If no client record found
     */
    @Test
    final void shouldThrowsNoSuchClientExceptionIfNullClientRecordFound() {

        final NoSuchClientException exn = assertThrows(NoSuchClientException.class, () -> {
            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
            inputParameters.put(EnterpriseInfo.SCOPE, scopeString);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, WEBDEVICEPARAMETERS);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, WEBDEVICEFINGERPRINT);
            final Map<String, Object> webDeviceParameter = Constants.GSON.fromJson(WEBDEVICEPARAMETERS, hashType);
            final WebDevMaster webDevice = new WebDevMaster(webDeviceUUID, DeviceStatus.ACTIVE.getName(), userLocation,
                    webDeviceParameter, new Date(), new Date(), WEBDEVICEFINGERPRINT);
            when(webDevMasterService.fetchWebDeviceMaster(anyString())).thenReturn(webDevice);
            when(customClientDetailService.loadClientByClientId(anyString())).thenReturn(null);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals(String.format(String.format("client record with id: %s is null", clientId)), exn.getMessage(),
                "Null client record testcase");
    }

    // TODO: Incorrect Test case
    /**
     * Should add new web device if no device found in database and throw
     * InvalidScopeException
     */
    @Test
    final void shouldAddNewWebDeviceNullWebDeviceFoundInDatabaseAndThrowInvalidScopeException() {

        final String invalidScope = "incorrect";

        final InvalidScopeException exn = assertThrows(InvalidScopeException.class, () -> {

            // Precondition
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
            inputParameters.put(EnterpriseInfo.SCOPE, invalidScope);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, WEBDEVICEPARAMETERS);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, WEBDEVICEFINGERPRINT);
            when(webDevMasterService.fetchWebDeviceMaster(anyString())).thenReturn(null);
            // when(request.getParameter(EnterpriseInfo.SCOPE)).thenReturn("incorrect");
            when(customClientDetailService.loadClientByClientId(anyString())).thenReturn(clientDetails);

            // calling method
            response.setHeader("X-FRAME-OPTIONS", "DENY");
            generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);

        });

        // Test
        assertEquals(String.format("Invalid scope: %s", invalidScope), exn.getMessage(),
                "Invalid enterprise scope test case");
    }

}
