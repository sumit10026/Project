package com.uniken.authserver.services.impl;

import com.uniken.authserver.config.PKCEOAuth2Validator;
import com.uniken.authserver.services.api.OAuth2AuthorizationCodeServicesApi;
import com.uniken.authserver.services.impl.OAuth2AuthorizationCodeServices;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.platform.runner.JUnitPlatform;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.oauth2.common.exceptions.InvalidGrantException;
import org.springframework.security.oauth2.common.exceptions.InvalidRequestException;
import org.springframework.security.oauth2.provider.*;
import org.springframework.security.oauth2.provider.request.DefaultOAuth2RequestValidator;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;


@ExtendWith(MockitoExtension.class)
@RunWith(JUnitPlatform.class)
public class PKCEOAuth2ValidatorUnitTest {

    @Mock
    OAuth2AuthorizationCodeServicesApi oAuth2AuthorizationCodeServices;

    PKCEOAuth2Validator pkceoAuth2Validator;

    AuthorizationRequest authorizationRequest;

    TokenRequest tokenRequest;

    Map<String, String> authorizationRequestParams = new HashMap<>();

    Map<String, String> authorizationRequestParamsWithNullCodeChallenge = new HashMap<>();

    Map<String, String> authorizationRequestParamsWithEmptyCodeChallenge = new HashMap<>();

    Map<String, String> tokenRequestParams = new HashMap<>();

    @BeforeEach
    void setup() {

        pkceoAuth2Validator = new PKCEOAuth2Validator(oAuth2AuthorizationCodeServices);

        authorizationRequestParams.put("scope", "all openid");
        authorizationRequestParams.put("client_id", "Y2MwYzVkNWEtY2Q0YS00N2QxLThjNWQtNWFjZDRhYTdkMWQx");
        authorizationRequestParams.put("state", "12345");
        authorizationRequestParams.put("code_challenge", "BwqAAFAw5gbl5Y6Cvaj2y6pszXP9k9DYbRpQOAQ8XiU");
        authorizationRequestParams.put("code_challenge_method", "S256");

        authorizationRequestParamsWithNullCodeChallenge.putAll(authorizationRequestParams);
        authorizationRequestParamsWithNullCodeChallenge.put("code_challenge", null);

        authorizationRequestParamsWithEmptyCodeChallenge.putAll(authorizationRequestParams);
        authorizationRequestParamsWithEmptyCodeChallenge.put("code_challenge", "");

        tokenRequestParams.put("code_verifier", "BwqAAFAw5gbl5Y6Cvaj2y6pszXP9k9DYbRpQOAQ8XiU");

    }

    @Test
    void test_validate_scope_when_code_challenge_is_null() {

        authorizationRequest = new AuthorizationRequest();
        authorizationRequest.setRequestParameters(authorizationRequestParamsWithNullCodeChallenge);
       Assertions.assertThrows(InvalidRequestException.class, () -> {
            pkceoAuth2Validator.validateScope(authorizationRequest, null);
        });

       try {
           pkceoAuth2Validator.validateScope(authorizationRequest, null);
       } catch (InvalidRequestException exception) {
           Assertions.assertEquals(exception.getMessage(), "code challenge required");
           Assertions.assertEquals(exception.getOAuth2ErrorCode(), "invalid_request");
       }

    }

    @Test
    void test_validate_scope_when_code_challenge_is_empty() {

        authorizationRequest = new AuthorizationRequest();
        authorizationRequest.setRequestParameters(authorizationRequestParamsWithEmptyCodeChallenge);
        Assertions.assertThrows(InvalidRequestException.class, () -> {
            pkceoAuth2Validator.validateScope(authorizationRequest, null);
        });

        try {
            pkceoAuth2Validator.validateScope(authorizationRequest, null);
        } catch (InvalidRequestException exception) {
            Assertions.assertEquals(exception.getMessage(), "code challenge required");
            Assertions.assertEquals(exception.getOAuth2ErrorCode(), "invalid_request");
        }

    }

    @Test
    void test_validate_scope_when_code_challenge_method_is_null() {


        authorizationRequestParamsWithEmptyCodeChallenge.put("code_challenge_method", null);
        authorizationRequestParamsWithEmptyCodeChallenge.put("code_challenge", "code challenge");

        authorizationRequest = new AuthorizationRequest();
        authorizationRequest.setRequestParameters(authorizationRequestParamsWithEmptyCodeChallenge);
        Assertions.assertThrows(InvalidRequestException.class, () -> {
            pkceoAuth2Validator.validateScope(authorizationRequest, null);
        });

        try {
            pkceoAuth2Validator.validateScope(authorizationRequest, null);
        } catch (InvalidRequestException exception) {
            Assertions.assertEquals(exception.getMessage(), "transform algorithm not supported");
            Assertions.assertEquals(exception.getOAuth2ErrorCode(), "invalid_request");
        }

    }

    @Test
    void test_validate_scope_when_code_challenge_method_is_not_plain_or_S256() {

        authorizationRequestParamsWithEmptyCodeChallenge.put("code_challenge_method", "not_plain_or_s256");
        authorizationRequestParamsWithEmptyCodeChallenge.put("code_challenge", "code challenge");

        authorizationRequest = new AuthorizationRequest();
        authorizationRequest.setRequestParameters(authorizationRequestParamsWithEmptyCodeChallenge);

        Assertions.assertThrows(InvalidRequestException.class, () -> {
            pkceoAuth2Validator.validateScope(authorizationRequest, null);
        });

        try {
            pkceoAuth2Validator.validateScope(authorizationRequest, null);
        } catch (InvalidRequestException exception) {
            Assertions.assertEquals(exception.getMessage(), "transform algorithm not supported");
            Assertions.assertEquals(exception.getOAuth2ErrorCode(), "invalid_request");
        }

    }

//    @Test
//    void test_validate_token_request_when_code_is_null_or_empty() {
//
//        tokenRequestParams.put("code", "");
//
//        tokenRequest = new TokenRequest(tokenRequestParams, "client id", new HashSet<>(), "grant type");
//
//        Assertions.asser(InvalidGrantException.class, () -> {
//            pkceoAuth2Validator.validateScope(tokenRequest, null);
//        });
//
//        tokenRequestParams.put("code", null);
//
//        tokenRequest = new TokenRequest(tokenRequestParams, "client id", new HashSet<>(), "grant type");
//
//        Assertions.assertThrows(InvalidGrantException.class, () -> {
//            pkceoAuth2Validator.validateScope(tokenRequest, null);
//        });
//
//        try {
//
//            pkceoAuth2Validator.validateScope(tokenRequest, null);
//        } catch (InvalidGrantException exception) {
//
//            Assertions.assertEquals(exception.getMessage(), "Code is required in pcke token request");
//            Assertions.assertEquals(exception.getOAuth2ErrorCode(), "invalid_grant");
//
//        }
//
//    }


    @Test
    void test_validate_token_request_with_valid_code_method_S256() {

        // Used this site to generate the code verifier and code challenge
        // https://tonyxu-io.github.io/pkce-generator/

        authorizationRequestParams.put("code_challenge", "yy6_p3GTG7dZH5tpLlASnjxyZExMEAsf14_Z-oR3m_0");

        tokenRequestParams.put("code", "asdfasdf");
        tokenRequestParams.put("code_verifier", "52cb2.sJ3J9abFiX1VxVkuHOs5IZur1DHzjOa.~sqs1LbiQVlgwlW.DnO6YRGlpW4~gWCPLo~AUX6LbtfEx.XhQQ4Ixovwzys8GwWnYP8K.z7kwMnryo7HGVV_nn3~wr");

        OAuth2Request oAuth2Request = new OAuth2Request(authorizationRequestParams, null, null, true, new HashSet<>(), null, null, null, null);

        lenient().when(oAuth2AuthorizationCodeServices.getAuthenticationCode(any())).
                thenReturn((new OAuth2Authentication(oAuth2Request, null)));

        tokenRequest = new TokenRequest(tokenRequestParams, "client id", new HashSet<>(), "grant type");

        Assertions.assertDoesNotThrow(() -> pkceoAuth2Validator.validateScope(tokenRequest, null));
    }


    @Test
    void test_validate_token_request_with_invalid_code_method_S256() {

        // Used this site to generate the code verifier and code challenge
        // https://tonyxu-io.github.io/pkce-generator/

        tokenRequestParams.put("code", "asdfasdf");
        tokenRequestParams.put("code_verifier", "52cb2.sJ3J9abFiX1VxVkuHOs5IZur1DHzjOa.~sqs1LbiQVlgwlW.DnO6YRGlpW4~gWCPLo~AUX6LbtfEx.XhQQ4Ixovwzys8GwWnYP8K.z7kwMnryo7HGVV_nn3~wr");

        authorizationRequestParams.put("code_challenge", "sFQX7Hj4pxUozvgfWbXNaBqOLTvJULOK8"); // should be "sFQX7Hj4pxUozvgfWbXNoJc-QE-_EYaBqOLTvJULOK8"

        OAuth2Request oAuth2Request = new OAuth2Request(authorizationRequestParams, null, null, true, new HashSet<>(), null, null, null, null);

        when(oAuth2AuthorizationCodeServices.getAuthenticationCode(any()))
                .thenReturn(new OAuth2Authentication(oAuth2Request, null));
        tokenRequest = new TokenRequest(tokenRequestParams, "client id", new HashSet<>(), "grant type");

        Assertions.assertThrows(InvalidGrantException.class, () -> {
            pkceoAuth2Validator.validateScope(tokenRequest, null);
        });


        try {
            pkceoAuth2Validator.validateScope(tokenRequest, null);
        } catch (InvalidGrantException exception) {
            Assertions.assertEquals(exception.getMessage(), "Code challenge doest match with given challenge method");
            Assertions.assertEquals(exception.getOAuth2ErrorCode(), "invalid_grant");
        }
    }

    @Test
    void test_validate_token_request_with_code_valid_method_plain() {

        /**
         * Used this site to generate the code verifier and code challenge
         * https://tonyxu-io.github.io/pkce-generator/
         **/
        authorizationRequestParams.put("code_challenge", "yy6_p3GTG7dZH5tpLlASnjxyZExMEAsf14_Z-oR3m_0");
        authorizationRequestParams.put("code_challenge_method", "plain");

        tokenRequestParams.put("code", "asdfasdf");
        tokenRequestParams.put("code_verifier", "yy6_p3GTG7dZH5tpLlASnjxyZExMEAsf14_Z-oR3m_0");

        OAuth2Request oAuth2Request = new OAuth2Request(authorizationRequestParams, null, null, true, new HashSet<>(), null, null, null, null);

        lenient().when(oAuth2AuthorizationCodeServices.getAuthenticationCode(any())).
                thenReturn((new OAuth2Authentication(oAuth2Request, null)));

        tokenRequest = new TokenRequest(tokenRequestParams, "client id", new HashSet<>(), "grant type");

        Assertions.assertDoesNotThrow(() -> pkceoAuth2Validator.validateScope(tokenRequest, null));

    }

    @Test
    void test_validate_token_request_with_invalid_code_method_plain() {


        tokenRequestParams.put("code", "asdfasdf");
        tokenRequestParams.put("code_verifier", "yy6_p3GTG7dZH5tpLlASnjxyZExMEAsf14_Z-oR3m_0");

        OAuth2Request oAuth2Request = new OAuth2Request(authorizationRequestParams, null, null, true, new HashSet<>(), null, null, null, null);

        authorizationRequestParams.put("code_challenge", "sFQX7Hj4pxUozvgfWbXNaBqOLTvJULOK8"); // should be "sFQX7Hj4pxUozvgfWbXNoJc-QE-_EYaBqOLTvJULOK8"

        oAuth2Request = new OAuth2Request(authorizationRequestParams, null, null, true, new HashSet<>(), null, null, null, null);

        when(oAuth2AuthorizationCodeServices.getAuthenticationCode(any()))
                .thenReturn(new OAuth2Authentication(oAuth2Request, null));
        tokenRequest = new TokenRequest(tokenRequestParams, "client id", new HashSet<>(), "grant type");

        Assertions.assertThrows(InvalidGrantException.class, () -> {
            pkceoAuth2Validator.validateScope(tokenRequest, null);
        });

        try {
            pkceoAuth2Validator.validateScope(tokenRequest, null);
        } catch (InvalidGrantException exception) {
            Assertions.assertEquals(exception.getMessage(), "Code challenge doest match with given challenge method");
            Assertions.assertEquals(exception.getOAuth2ErrorCode(), "invalid_grant");
        }
    }

    @Test
    void test_validate_token_request_with_no_code_verifier() {


        tokenRequestParams.put("code", "asdfasdf");

        OAuth2Request oAuth2Request = new OAuth2Request(authorizationRequestParams, null, null, true, new HashSet<>(), null, null, null, null);

        authorizationRequestParams.put("code_challenge", "sFQX7Hj4pxUozvgfWbXNaBqOLTvJULOK8"); // should be "sFQX7Hj4pxUozvgfWbXNoJc-QE-_EYaBqOLTvJULOK8"

        oAuth2Request = new OAuth2Request(authorizationRequestParams, null, null, true, new HashSet<>(), null, null, null, null);

        when(oAuth2AuthorizationCodeServices.getAuthenticationCode(any()))
                .thenReturn(new OAuth2Authentication(oAuth2Request, null));
        tokenRequest = new TokenRequest(tokenRequestParams, "client id", new HashSet<>(), "grant type");

        Assertions.assertThrows(InvalidGrantException.class, () -> {
            pkceoAuth2Validator.validateScope(tokenRequest, null);
        });

        try {
            pkceoAuth2Validator.validateScope(tokenRequest, null);
        } catch (InvalidGrantException exception) {
            Assertions.assertEquals(exception.getMessage(), "Code challenge doest match with given challenge method");
            Assertions.assertEquals(exception.getOAuth2ErrorCode(), "invalid_grant");
        }
    }

    @Test
    void test_validate_challenge_encode() throws UnsupportedEncodingException, NoSuchAlgorithmException {

         /**
          Appendix A.  Notes on Implementing Base64url Encoding without Padding `https://datatracker.ietf.org/doc/html/rfc7636#appendix-A`

         This appendix describes how to implement a base64url-encoding
         function without padding, based upon the standard base64-encoding
         function that uses padding.

         To be concrete, example C# code implementing these functions is shown
         below.  Similar code could be used in other languages.

         static string base64urlencode(byte [] arg)
         {
             string s = Convert.ToBase64String(arg); // Regular base64 encoder
             s = s.Split('=')[0]; // Remove any trailing '='s
             s = s.Replace('+', '-'); // 62nd char of encoding
             s = s.Replace('/', '_'); // 63rd char of encoding
             return s;
         }
          **/

        String generatedChallenge = pkceoAuth2Validator.makeCodeChallenge("52cb2.sJ3J9abFiX1VxVkuHOs5IZur1DHzjOa.~sqs1LbiQVlgwlW.DnO6YRGlpW4~gWCPLo~AUX6LbtfEx.XhQQ4Ixovwzys8GwWnYP8K.z7kwMnryo7HGVV_nn3~wr");

        Assertions.assertFalse(generatedChallenge.contains("/"));
        Assertions.assertFalse(generatedChallenge.contains("+"));
        Assertions.assertFalse(generatedChallenge.contains("="));

        Assertions.assertEquals(generatedChallenge, "yy6_p3GTG7dZH5tpLlASnjxyZExMEAsf14_Z-oR3m_0");

    }


}
