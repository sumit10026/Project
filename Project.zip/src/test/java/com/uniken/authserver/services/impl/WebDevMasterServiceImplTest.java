package com.uniken.authserver.services.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.repo.api.WebDevMasterRepo;
import com.uniken.domains.relid.device.UserLocation;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.user.DeviceStatus;

@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
public class WebDevMasterServiceImplTest {

    @Mock
    private WebDevMasterRepo webDevMasterRepo;

    private static String webDeviceUUID = "123e4567-e89b-12d3-a456-426655440000";
    private static String webDeviceParametersChecksum = "1234";

    @InjectMocks
    private WebDevMasterServiceImpl webDevMasterServiceImplTest;

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {
    }

    @BeforeEach
    void setUp() throws Exception {
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    final UserLocation userLocation = new UserLocation("1.322312321", "0.3453464564");

    /**
     * This should return null whenever device parameter checksum is null
     */
    /**
     * Should throw new IllegalArgumentException while adding new web device
     * master object
     */
    @Test
    final void shouldThrowNewIllegalArgumentExceptionWhileFetchingWebDevMasterObjectInDatabase() {

        // Precondition
        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            final String webDevChecksum = null;

            // calling method
            webDevMasterServiceImplTest.fetchWebDeviceMaster(webDevChecksum);
        });

        // Test
        assertEquals("Web Device Checksum value is null or empty", exn.getMessage(),
                "Null web device signature testcase");

    }

    /**
     * Success : Should fetch the existing web device master object
     */
    @Test
    final void shouldFetchWebDevMasterObjectInDatabaseSuccessfully() {

        // Precondition
        final Map<String, Object> deviceParameters = new HashMap<>();
        deviceParameters.put("Platform", "Firefox");
        deviceParameters.put("IPAddress", "10.1.1.9");
        final WebDevMaster webDevMaster = new WebDevMaster(webDeviceUUID, DeviceStatus.ACTIVE.getName(), userLocation,
                deviceParameters, new Date(), new Date(), webDeviceParametersChecksum);
        when(webDevMasterRepo.fetchWebDeviceMaster(anyString())).thenReturn(webDevMaster);

        // calling method
        final WebDevMaster retrievedWebDevMaster = webDevMasterServiceImplTest
                .fetchWebDeviceMaster(webDeviceParametersChecksum);

        // Test
        assertEquals(webDevMaster, retrievedWebDevMaster, "Success testcase");

    }

    /**
     * Should throw new IllegalArgumentException while adding new web device
     * master object
     */
    @Test
    final void shouldThrowNewIllegalArgumentExceptionWhileAddingNewWebDevMasterObjectInDatabase() {

        // Precondition
        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            final WebDevMaster webDevMaster = null;

            // calling method
            webDevMasterServiceImplTest.addWebDeviceMaster(webDevMaster);
        });

        // Test
        assertEquals("WebDevMaster is null", exn.getMessage(), "Success testcase");

    }

    /**
     * Success : Should add new web device master object
     */
    @Test
    final void shouldAddNewWebDevMasterObjectInDatabaseSuccessfully() {

        // Precondition
        final Map<String, Object> deviceParameters = new HashMap<>();
        deviceParameters.put("Platform", "Firefox");
        deviceParameters.put("IPAddress", "10.1.1.9");
        final WebDevMaster webDevMaster = new WebDevMaster(webDeviceUUID, DeviceStatus.ACTIVE.getName(), userLocation,
                deviceParameters, new Date(), new Date(), webDeviceParametersChecksum);

        // calling method
        webDevMasterServiceImplTest.addWebDeviceMaster(webDevMaster);

        // Test
        assertEquals(webDevMaster, webDevMaster, "Success testcase");

    }

    /**
     * Should throw new IllegalArgumentException while updating existing web
     * device master object
     */
    @Test
    final void shouldThrowNewIllegalArgumentExceptionWhileUpdatingWebDevMasterObjectInDatabase() {

        // Precondition
        final IllegalArgumentException exn = assertThrows(IllegalArgumentException.class, () -> {
            final Map<String, Object> deviceParameters = new HashMap<String, Object>();
            deviceParameters.put("Platform", "Firefox");
            deviceParameters.put("IPAddress", "10.1.1.9");
            final WebDevMaster webDevMaster = null;

            // calling method
            webDevMasterServiceImplTest.updateWebDeviceMaster(webDevMaster);
        });

        // Test
        assertEquals("WebDevMaster is null", exn.getMessage(), "Success testcase");
    }

    /**
     * Success : Should Update existing web device master object
     */
    @Test
    final void shouldUpdateExistingWebDevMasterObjectInDatabaseSuccessfully() {

        // Precondition
        final Map<String, Object> deviceParameters = new HashMap<String, Object>();
        deviceParameters.put("Platform", "Firefox");
        deviceParameters.put("IPAddress", "10.1.1.9");
        final WebDevMaster webDevMaster = new WebDevMaster(webDeviceUUID, DeviceStatus.ACTIVE.getName(), userLocation,
                deviceParameters, new Date(), new Date(), webDeviceParametersChecksum);
        when(webDevMasterRepo.updateWebDeviceMaster(webDevMaster)).thenReturn(webDevMaster);

        // calling method
        final WebDevMaster retrievedWebDevMaster = webDevMasterServiceImplTest.updateWebDeviceMaster(webDevMaster);

        // Test
        assertEquals(webDevMaster, retrievedWebDevMaster, "Success testcase");

    }
}
