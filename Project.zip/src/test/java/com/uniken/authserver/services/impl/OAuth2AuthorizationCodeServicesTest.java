/**
 * 
 */
package com.uniken.authserver.services.impl;

import static org.junit.jupiter.api.Assertions.fail;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;

/**
 * @author Kushal Jaiswal
 */
@ExtendWith(EmbeddedMongoInitExtension.class)
class OAuth2AuthorizationCodeServicesTest {

    @Autowired
    OAuth2AuthorizationCodeServices authorizationCodeServices;

    /**
     * @throws java.lang.Exception
     */
    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @BeforeEach
    void setUp() throws Exception {
    }

    /**
     * @throws java.lang.Exception
     */
    @AfterEach
    void tearDown() throws Exception {
    }

    /**
     * Test method for
     * {@link com.uniken.authserver.services.impl.OAuth2AuthorizationCodeServices#store(java.lang.String, org.springframework.security.oauth2.provider.OAuth2Authentication)}.
     */
    @Test
    final void testStoreStringOAuth2Authentication() {
        fail("Not yet implemented"); // TODO
    }

    /**
     * Test method for
     * {@link com.uniken.authserver.services.impl.OAuth2AuthorizationCodeServices#remove(java.lang.String)}.
     */
    @Test
    final void testRemoveString() {
        fail("Not yet implemented"); // TODO
    }

    /**
     * Test method for
     * {@link com.uniken.authserver.services.impl.OAuth2AuthorizationCodeServices#logAuthorizationCode(com.uniken.domains.auth.CustomOAuth2AuthorizationCode)}.
     */
    @Test
    final void testLogAuthorizationCode() {
        fail("Not yet implemented"); // TODO
    }

}
