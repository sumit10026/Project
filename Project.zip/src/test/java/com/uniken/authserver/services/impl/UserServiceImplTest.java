package com.uniken.authserver.services.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.catalina.core.ApplicationContext;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.mq.publisher.RelIdVerifyMessagePublisher;
import com.uniken.authserver.repo.impl.UserAuthInfoRepoImpl;
import com.uniken.authserver.services.api.OAuth2ClientDetailsService;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.relid.device.UserLocation;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
class UserServiceImplTest {

    @Mock
    private WebDevMasterService webDevMasterService;

    @Mock
    private CustomUserDetailsService customUserDetailsService;

    @Mock
    private OAuth2ClientDetailsService customClientDetailService;

    @Mock
    private ValidateTotpServiceImpl validateTotpServiceImpl;

    @Mock
    private RelIdVerifyMessagePublisher verifyPublisher;

    @Mock
    private UserAuthInfoRepoImpl userAuthInfoRepoImpl;

    @Mock
    ApplicationContext applicationContext;

    @InjectMocks
    private UserServiceImpl userServiceImpl;

    private String correlationID = "";
    HttpServletRequest request = null;
    HttpServletResponse response = null;
    HttpSession session = null;

    final static String clientId = "5678gbjkyghj";
    final static String testUsername = "testUser";
    final static String scopeString = "all ";
    final static String requestorID = "1234";
    final static String resourceIdsString = "[\"relid-verify-server\"]";
    final UserLocation userLocation = new UserLocation("1.322312321", "0.3453464564");
    String WEBDEVICEFINGERPRINT = "12345";
    String WEBDEVICEPARAMETERS = "{\"platform\":\"win32\", \"userAgent\":\"firefox\"}";
    final String webDeviceUUID = "123e4567-e89b-12d3-a456-426655440000";
    final EnterpriseInfo clientDetails = Constants.GSON.fromJson(
            "{\"_id\":ObjectId(\"5df9af6320bc1363dff1cb01\"),\"enterprise_id\":\"CBCVerify\",\"method\":\"OAuth2\",\"apple_server_certificate_dev_mode\":false,\"credsUploadStatusGoogle\":\"PENDING\",\"credsUploadStatusApple\":\"PENDING\",\"resource_ids\":[\"relid-verify-server\",\"user-api-server\",\"OIDC\"],\"authorized_grant_types\":[\"refresh_token\",\"authorization_code\",\"client_credentials\"],\"access_token_validity_seconds\":180,\"enable_refresh_token\":false,\"refresh_token_validity_seconds\":0,\"client_id\":\"MTEzMmZhNTEtOGU1Zi00NTQyLWIyZmEtNTE4ZTVmZjU0MjU1\",\"client_secret\":\"jPnN2ptGYk4p8NKwY8DJtIfyIulxfOvo7zwnpl9MVKBEm0QDwGOqDLiuMhrgDBcccY8nxxTkDJ8ANWqZnm7lh+qYJfHe+UWI+fu1YpLPpKc=\",\"secret_required\":false,\"scoped\":false,\"scope\":[\"all\"],\"authorities\":[],\"registered_redirect_uri\":[\"http://127.0.0.1:8008/relid/authserver/oauth/login\",\"http://127.0.0.1:8080/GM/show-login-page.htm\"],\"auto_approve\":false,\"mapped_appagent_name\":\"tunneltestagent\",\"mapped_appagent_uuid\":\"e808085f-875f-455e-8808-5f875f255e93\",\"apple_server_certificate_content\":\"MIINAwIBAzCCDMoGCSqGSIb3DQEHAaCCDLsEggy3MIIMszCCB08GCSqGSIb3DQEHBqCCB0Awggc8AgEAMIIHNQYJKoZIhvcNAQcBMBwGCiqGSIb3DQEMAQYwDgQIfh5AyahrRsoCAggAgIIHCMrbMZluTN17B1cYJfEYu9kmIGoVOfCPn5kVHcjFW8LZc8QSSXCEdTCJAhugsNvit85ScGyJxZLGoxCBCJaP8Ym7J03IUmoXtzApe8jtm1KSygAxJlgUzSmqpisNeSW8fvaaS6ZZjl+EnKnhykTwXv0Is805H6r7yAD2GR1/GVktwLbxsu/al3u2XVedbjnnZQgHx8HC2KmrQatBbxeXSD8lkEIwXGL6XjvgAZ7rLIcm//qzri+FrI8AgeRljYnj9sJk/HRxXZa/3KFUEiuEcYiv77E1GbV/h5ztP2RwmAlJ0Oue185+yAJlG4ZcG5dHo7jIqOBbMkz1xAc2AqKq0JjU5IulBtE42TxG5Gb/k7Ppy/b9bnFrUAYA3306L9D6PigyEhor+w5hUTsFeZxwMB9++wpBdLHWm2qQFDpvuVWad+0QlkpL3TLPCLTrV2llpZsiios8N9HdYz9xqzC4DO5LJ0NOYNOfv+Tfelw/JtjZh5bnl+rV2qFdRIfz9uZzLKMPLRRWPKcFraLZvesmkyfSyH57HJlEts5IT22elvHjehqDzL409vzy+rmcf8P15TTXJgvXQPJsAtghJSXuUkT8EBpl577/pd5Y1C0sXlBaF6ibQm0/83YELHcQEpR8lJWmn1BPwzFcxI2uNtKl3L1fH0snyoT/N0elrNkpUKi0WabqKmOiAz3S7ZCAjnDR8eTPrqa++W7E/fXXe8K/vyfOTmz8ZfwouVPdQX71/oOoI/LU5NC4miPncQPJXYiQ/yU3TFIA1ZKC6oYEQjRCJKKcY5OCHSjlVxX8HOSZ0mZjcvjQJPzTXdRvLf2Go3Y07ZFJfK7Ka9AFQnDaVS5PDCoq5/ZdMfup07kB4b2VQieYVwRduLorxgmRCXZLsPXSmqedj44DUr1uZujK9WlFJ1bf1ZKdRHLqb/G2ElZCHGMhnq9S0Uh0LxrlG6aLy6+RfTqffNtwJOlOfZUOz7aZN3JaD1GD5FT79wVGSqQO81EDXB2dIOO+24ZFTy2KGYicrRRMuSLuSDURDhQnOugZe8a85zX6KXSmtz+To0jhL3CducRLy/N2cx+VUqXr5zQm9ZkvKGk9gTkNqFOBeHYDyBNHzjv+/z82yEtFtoGcybnhJXXhfMar+JXRX5NZRm2Y3b9pZjXqoHulu6Nrz8ngTuwwuEMo/fRKucyOrar+tIDw2qCOGmg9GI8B8fN+UCuKCiQLu/6ojtvpCwgeoN41GMTQhFIVxGD4UOKzeehvdLaXRtItFNgaMs1TwSn2WOA1ID1kSsYg6fxA4EXnHVrMJaTWjxwGaLmnzn5HugkwN62iiBxizMECjhmTnULAjO7JHA4mKv+KYU2jPfmBN2c8Co6DsQH7niBRNAixrZvsVsmpbXFH7mbuA7b6M/dmj+zKySxf0AhtpL7JKSsNbyOWuoEUZLG62ES8jLDiRo3B2U7z8AJc2pbpfjZE9Fgwf45RSCWmlPeBGjDx/nOv+7EzqhKGPl5FoTK8buz0sinXdOnf5zlzoeu1D9SwP2KE8fobchECinHlAduWR/SahMs5Jz6hMHndOF5WEkZlakSCpYQX5XLybfPm6EQp2FB1eIRXEIP+Asm7d7oJshAGfSY+sydsf1+vOpwIcYX/ATqBlhvsb2XOnGZTi+oTy1dgeUf5OFM1F3E/Jp1zn0lUSgY3AgM1FMnFOVgNMHYIgdEBGEPhbQGqb4ANhxBjOioSGKAGyLbr8XdMZLaC+b2mNgIdYjggJRtn1ei/v10LM2RwBMaJ/j6I1Gr8D47zEyNA9m+bPaPfHpwsPQaqYNXncNafSp7LS3iUGhdqviPklIp5OdfxVQGKVkCMMS7+1aNwEZA+sr8/XYrAXUT23jK4tvUoUpCG+/QrrA0Lmg/41eXymWTwjQTtlI+WylZXtQO8nU1D9mujd/3mjQ7tJqxp7NgbLcvf/u5vk0btv4LPLL8dGgTuUHtzWygxYSK5D3j8Bd4xm0I1M3lwUdKLNDhvZ7vTSzarzOf51eTl1caOEJAqX2WR2xpnyeY9Bn5h7miv43Nv8aHYgy7D8yELWGIuhN0P8r7GlW5DWL2pwaqI76HLOeSFpnbWCGCq5rB80GSuRM7E8p8MqGu94BP4wPzdjh+74zgeTRkVztTBVZAV7PBgc6CHfZS73xPkF82IfEbCJFN+98fDaJfYtrfaN3CkF6oI/IC72jE6P/yNIs31leXPbj8N+LnS+FKonnW9BPMv9pw00x/Su6QS5UBYQkWXa8DuN7cObdJ9k6Y8Yo1ADPKUymT1B94yGw9FILYYrnEw5BprobEGkyv7qYHUmNq5/djW+SdIZDuXb4sAkE5QFQtEitalav7VAHLZl+ma1rZ8LhPuXG4m3rmHyMcJTNnod6W5CsWAagFgJH+7bDCCBVwGCSqGSIb3DQEHAaCCBU0EggVJMIIFRTCCBUEGCyqGSIb3DQEMCgECoIIE7jCCBOowHAYKKoZIhvcNAQwBAzAOBAhP2Y6ltJrVXwICCAAEggTIJ0aIGjc13vVhjo5dRjOh0m/p+GMWhBpsshkB/o885emHwk/uvinxiDI+/ub593esCSTYiQVitWFct93GVKNNeehsY+ubl2Ys/hnlZyy59YkZhzP6H2nirGeIu0ALUZhxIIHSvOZnXuqTxkSzyi3X8kwVQU5yjlfesnTM9qgC6GCi7xuvtSK9DrdUZ30R552U5FLPNECMCc1RhitRLUiodZrZSU8Dj2fmM911jiJpGYs4AFpezGLQRaKXS0uRZOAIGgc6/qag1FpPo8VjwF6Mc5mv4nsXNsCwEV9KXCRVbTveytzmzwoJooYkh7zNCA/yQwcBPd88doG/e5TU8X+fgRfvVP9FpCKFM8qsTcdG7+Zh1wSwKoMCkvuuch7767E98373utg11QFsRY4mmiuh2jkLsmLuVKkBIiS8M2hHAfr1iSvI+fdJ0ldYHHK9CrGybfOrWqn7SCI/KbVhG1x0/UzLcqxrGXHyj7V+8hPAydOmr/GlLoe8Hw7UqYM6qoTY9SNcA02yoTkuRe+QxsWzTScbV+G6emcUlf53XF3LsPbCFXfLpkZ1NYeLxZuIxxDm7AtpBWHOqqAGyNbtxX9II0MCiiSNN61TJcoje1OWVOihye94BKmKUVSys/JZjZEVsKHNbaU7OpQ4G3jTgXiaPf6BvkWdJMYGmz59LcDC01pXX+NTUwXogOQUOvl/FSLjAv0zdzHXvYtohkbK6poZba+02b9+0updDzDCoRjCUg6eAlgfyO7aUr0ufFk9hD9ij0JJoIlKe8AAqTEwligKZjgs+nHiqyGnazkMIz4vGOn5XkYcYQOMav4Wo7RaOkqDuHED+nhYMeslldJTXcpOeZmgN1nvyh993gvTbvibbdvqCZ9Jc9D6kksHha5C8qhCMfb8BHU6mkuXwM56V+/mFbETGAY2CwC24e6cXhlSSsqMdNBASrJJbQTGFa3FF9SqceCOwKzkiyHIuyMQARP7UHQ2JHkKrERKvryjhJPpywu4ILDCpbw6CR2b6BwWBg1LyhZmYDvTkZULRybviHsgzqCa+/AER7hoXw/s5UO4CdBmtklMqZ6686r4Mdwv6WahsFoOHkmQue3piutyDPjd0fUcCR6Rt0OZNHHjUnfH3jsyMk9JwOpKiMr2QjBvApxdvp9itJaIh8ZXbibAoyBn+WVYUPQPjir8exaQShZuiUT5E6g2O4Qq1JvX+rbtxeXxBnryb0hF+93kQDrk2GVzXTA4qcDtaw9iH8viyB4LJOyq88XErbCJxlQclawRhyxi+n917WFkxJ4QdCDEBvF2Ru1MtScVGlOAixdL48rPTNth+rXFdV5nkzkzCq4r1F2dDQXSEP4OvY89JU/wC8sAJmkrtz6Hh05MHqOl+LyObTPov5YSZq0lJa2Ge2TWU/XO4mNyzjzDCqvKmZ78LNuyIS6XS/CbRvVs0Ufdp9PeUfqXAAy7Vd66/Kdm7liNxrfB0uOvUPZrl7Q4ZSk18991JPYt5p3wyUGisyU0VcTQrzYhBylBbl19yN/3vxwCCJRDX4GHGhWzHqufSxCnqcuUYdwfCo72FMLnUcsqe7dBVzfbpOxzO+/XN1Qhhu7oz9gRaPOwH0LUA19nf9eflTTdRucp5MtiZoDbMUAwGQYJKoZIhvcNAQkUMQweCgBvAG4AawBhAHIwIwYJKoZIhvcNAQkVMRYEFHNKUx4EhDXShY69cGBF5HaRW2vHMDAwITAJBgUrDgMCGgUABBR7lESH7sO8GNH30zPJbC9f+8S/3AQI4BCxYzPIqaECAQE=\",\"apple_server_certificate_password\":\"yKbAg8gQMBkp4uGDB6Ou0A==\",\"google_server_authentication_key\":\"/IHTif4HQl5XnNfIYvTsm4AozoAGaMPFfWpxltUNSIsDnu09q/Z6ngvStV0T1SCc\"}",
            EnterpriseInfo.class);
    final WebDevMaster webDevMaster = Constants.GSON.fromJson(
            "{\"_id\":ObjectId(\"5e0f415992fe973391c561a0\"),\"web_device_uuid\":\"7fcfba9a-3299-46f0-8fba-9a329916f005\",\"status\":\"Created\",\"user_location\":{\"latitude\":\"18.5559044\",\"longitude\":\"73.7595417\"},\"web_device_parameters\":{\"fontsFlash\":\"swf object not loaded\",\"hasLiedLanguages\":\"false\",\"touchSupport\":\"0,false,false\",\"timezone\":\"Asia/Calcutta\",\"plugins\":\"Chrome PDF Plugin,Portable Document Format,application/x-google-chrome-pdf,pdf,Chrome PDF Viewer,,application/pdf,pdf,Native Client,,application/x-nacl,,application/x-pnacl,\",\"localStorage\":\"true\",\"language\":\"en-US\",\"hasLiedBrowser\":\"false\",\"platform\":\"Win32\",\"availableScreenResolution\":\"728,1366\",\"timezoneOffset\":\"-330\",\"fonts\":\"Arial,Arial Black,Arial Narrow,Arial Unicode MS,Book Antiqua,Bookman Old Style,Calibri,Cambria,Cambria Math,Century,Century Gothic,Century Schoolbook,Comic Sans MS,Consolas,Courier,Courier New,Georgia,Helvetica,Impact,Lucida Bright,Lucida Calligraphy,Lucida Console,Lucida Fax,Lucida Handwriting,Lucida Sans,Lucida Sans Typewriter,Lucida Sans Unicode,Microsoft Sans Serif,Monotype Corsiva,MS Gothic,MS PGothic,MS Reference Sans Serif,MS Sans Serif,MS Serif,Palatino Linotype,Segoe Print,Segoe Script,Segoe UI,Segoe UI Light,Segoe UI Semibold,Segoe UI Symbol,Tahoma,Times,Times New Roman,Trebuchet MS,Verdana,Wingdings,Wingdings 2,Wingdings 3\",\"sessionStorage\":\"true\",\"webdriver\":\"not available\",\"audio\":\"124.04344884395687\",\"screenResolution\":\"768,1366\",\"openDatabase\":\"true\",\"enumerateDevices\":\"id=default;gid=6f2131438b51a7734d3ee50a18da3b2ea639ae507d43436a67f06c7eb7966120;audioinput;,id=communications;gid=6f2131438b51a7734d3ee50a18da3b2ea639ae507d43436a67f06c7eb7966120;audioinput;,id=337a03fe08dcabd6b6f50322106e0a27240af08b555e6c7893204e8e7e29f8b0;gid=6f2131438b51a7734d3ee50a18da3b2ea639ae507d43436a67f06c7eb7966120;audioinput;,id=947b4c262284da9e2eae8bed1cc6326b896aaad81906408c6bf9131c0abe997f;gid=20a3c45854f2ab13f50f2e3d2362b889ca58d730d36cbd985ed28fffe8175ff9;videoinput;,id=default;gid=6f2131438b51a7734d3ee50a18da3b2ea639ae507d43436a67f06c7eb7966120;audiooutput;,id=communications;gid=6f2131438b51a7734d3ee50a18da3b2ea639ae507d43436a67f06c7eb7966120;audiooutput;,id=df29133b56bafca601035baf97bc6ec529561df63abdf94a17ff4204bb48fd3c;gid=6f2131438b51a7734d3ee50a18da3b2ea639ae507d43436a67f06c7eb7966120;audiooutput;\",\"adBlock\":\"false\",\"webglVendorAndRenderer\":\"Google Inc.~ANGLE (Intel(R) HD Graphics 620 Direct3D11 vs_5_0 ps_5_0)\",\"cpuClass\":\"not available\",\"hasLiedOs\":\"false\",\"userAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.88 Safari/537.36\",\"indexedDb\":\"true\",\"deviceMemory\":\"8\",\"hasLiedResolution\":\"false\",\"addBehavior\":\"false\",\"hardwareConcurrency\":\"4\",\"doNotTrack\":\"not available\",\"pixelRatio\":\"1\",\"colorDepth\":\"24\"},\"created_ts\":\"2020-01-03T13:27:53.475+0000\",\"updated_ts\":\"2020-01-06T07:01:05.965+0000\",\"web_device_parameter_checksum\":\"839a116449d9e601f7430fe7c3742c37\",\"_class\":\"com.uniken.domains.relid.device.WebDevMaster\"}",
            WebDevMaster.class);

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {
    }

    @BeforeEach
    void setUp() throws Exception {

        request = mock(HttpServletRequest.class);
        response = mock(HttpServletResponse.class);
        session = mock(HttpSession.class);

        correlationID = "1234";
        when(request.getAttribute(Constants.REQUESTOR_ID)).thenReturn("lkjhgfgxfcvjhb987");
        when(webDevMasterService.fetchWebDeviceMaster(Mockito.anyString())).thenReturn(webDevMaster);
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    /*
     * @Test final void
     * shouldThrowIllegalArgumentExceptionIfNullCorrelationIDFound() { final
     * IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * correlationID = null; // calling method
     * userServiceImpl.checkIfNotificationIsActed(correlationID); }); // Test
     * assertEquals("CorrelationID is null or empty", exn.getMessage(),
     * "Null Correlation ID testcase"); }
     * @Test final void
     * shouldThrowIllegalArgumentExceptionIfEmptyCorrelationIDFound() { final
     * IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * correlationID = "   "; // calling method
     * userServiceImpl.checkIfNotificationIsActed(correlationID); }); // Test
     * assertEquals("CorrelationID is null or empty", exn.getMessage(),
     * "Null Correlation ID testcase"); }
     * @Test final void
     * shouldRespondWithNoContentIfNotificationNotYetActedCase() { //
     * Precondition
     * Constants.getVerifyNotificationResponseMap().remove(correlationID); //
     * calling method final HttpStatus status =
     * userServiceImpl.checkIfNotificationIsActed(correlationID); // Test
     * assertEquals(HttpStatus.ACCEPTED, status,
     * "Invalid Correlation ID, Notification not yet acted testcase"); }
     * @Test final void shouldRespondWithNoContentIfNoContentScenario() { //
     * Precondition final NotificationUserActionResponse response = new
     * NotificationUserActionResponse(); response.setResponseCode(401);
     * Constants.getVerifyNotificationResponseMap().put(correlationID,
     * response); //
     * when(Constants.getVerifyNotificationResponseMap().get(anyString())).
     * thenReturn(response); // calling method final HttpStatus status =
     * userServiceImpl.checkIfNotificationIsActed(correlationID); // Test
     * assertEquals(HttpStatus.NO_CONTENT, status,
     * "Valid Correlation ID, but no content scenario testcase"); }
     * @Test final void shouldRespondWithNoContentIfNotificationActedTestcase()
     * { // Precondition final NotificationUserActionResponse response = new
     * NotificationUserActionResponse(); response.setResponseCode(100);
     * Constants.getVerifyNotificationResponseMap().put(correlationID,
     * response); //
     * when(Constants.getVerifyNotificationResponseMap().get(anyString())).
     * thenReturn(response); // calling method final HttpStatus status =
     * userServiceImpl.checkIfNotificationIsActed(correlationID); // Test
     * assertEquals(HttpStatus.OK, status,
     * "Valid Correlation ID, and notification acted scenario testcase"); }
     * @Test final void
     * shouldThrowIllegalArgumentExceptionWhileCheckingNotificationResponseWithNullCorrelationID
     * () { final IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * correlationID = null; WEBDEVICEFINGERPRINT = "browser-checksum";
     * WEBDEVICEPARAMETERS = "browser-DFP"; // calling method
     * userServiceImpl.checkNotificationResponse(correlationID,
     * WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request); }); // Test
     * assertEquals("CorrelationID is null or empty", exn.getMessage(),
     * "Null Correlation ID while checking notification response testcase"); }
     * @Test final void
     * shouldThrowIllegalArgumentExceptionWhileCheckingNotificationResponseWithEmptyCorrelationID
     * () { final IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * correlationID = "   "; WEBDEVICEFINGERPRINT = "browser-checksum";
     * WEBDEVICEPARAMETERS = "browser-DFP"; // calling method
     * userServiceImpl.checkNotificationResponse(correlationID,
     * WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request); }); // Test
     * assertEquals("CorrelationID is null or empty", exn.getMessage(),
     * "Empty Correlation ID while checking notification response testcase"); }
     * @Test final void
     * shouldThrowIllegalArgumentExceptionWhileCheckingNotificationResponseWithNullBrowserDFPChecksum
     * () { final IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * correlationID = "1234"; WEBDEVICEFINGERPRINT = null; WEBDEVICEPARAMETERS
     * = "browser-DFP"; // calling method
     * userServiceImpl.checkNotificationResponse(correlationID,
     * WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request); }); // Test
     * assertEquals("browserDFPChecksum is null or empty", exn.getMessage(),
     * "Null Browser DFP checksum while checking notification response testcase"
     * ); }
     * @Test final void
     * shouldThrowIllegalArgumentExceptionWhileCheckingNotificationResponseWithEmptyBrowserDFPChecksum
     * () { final IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * correlationID = "1234"; WEBDEVICEFINGERPRINT = "   "; WEBDEVICEPARAMETERS
     * = "browser-DFP"; // calling method
     * userServiceImpl.checkNotificationResponse(correlationID,
     * WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request); }); // Test
     * assertEquals("browserDFPChecksum is null or empty", exn.getMessage(),
     * "Empty Browser DFP checksum while checking notification response testcase"
     * ); }
     * @Test final void
     * shouldThrowIllegalArgumentExceptionWhileCheckingNotificationResponseWithNullBrowserDFP
     * () { final IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * correlationID = "1234"; WEBDEVICEFINGERPRINT = "browser-dfp-checksum";
     * WEBDEVICEPARAMETERS = null; // calling method
     * userServiceImpl.checkNotificationResponse(correlationID,
     * WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request); }); // Test
     * assertEquals("browserDFP is null or empty", exn.getMessage(),
     * "Null browserDFP while checking notification response testcase"); }
     * @Test final void
     * shouldThrowIllegalArgumentExceptionWhileCheckingNotificationResponseWithEmptyBrowserDFP
     * () { final IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * correlationID = "1234"; WEBDEVICEFINGERPRINT = "browser-dfp-checksum";
     * WEBDEVICEPARAMETERS = "   "; // calling method
     * userServiceImpl.checkNotificationResponse(correlationID,
     * WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request); }); // Test
     * assertEquals("browserDFP is null or empty", exn.getMessage(),
     * "Empty browserDFP while checking notification response testcase"); }
     * @Test final void
     * shouldThrowIllegalArgumentExceptionWhileCheckingNotificationResponseWithInvalidBrowserDFP
     * () { final IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * correlationID = "1234"; WEBDEVICEFINGERPRINT = "browser-dfp-checksum";
     * WEBDEVICEPARAMETERS = "Invalid json dfp"; // calling method
     * userServiceImpl.checkNotificationResponse(correlationID,
     * WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request); }); // Test
     * assertEquals("browser DFP is invalid", exn.getMessage(),
     * "Invalid JSON browserDFP testcase"); }
     * @Test final void
     * shouldThrowRelIDAuthServerOAuth2ExceptionWhileCheckingNotificationResponseWithNullUserActionResponse
     * () { final RelIDAuthServerOAuth2Exception exn =
     * assertThrows(RelIDAuthServerOAuth2Exception.class, () -> { //
     * Precondition correlationID = "1234"; WEBDEVICEFINGERPRINT =
     * "browser-checksum"; WEBDEVICEPARAMETERS = "{\"1234\":\"1234\"}";
     * Constants.getVerifyNotificationResponseMap().put(correlationID, null); //
     * calling method userServiceImpl.checkNotificationResponse(correlationID,
     * WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request); }); // Test
     * assertEquals("Either invalid correlation ID provided or notification is NOT still acted"
     * , exn.getMessage(), "Null Useraction response object testcase"); }
     * @Test final void
     * shouldThrowRelIDAuthServerOAuth2ExceptionWhileCheckingNotificationResponseWithEmptyUserActionResponse
     * () { final RelIDAuthServerOAuth2Exception exn =
     * assertThrows(RelIDAuthServerOAuth2Exception.class, () -> { //
     * Precondition correlationID = "1234"; WEBDEVICEFINGERPRINT =
     * "browser-checksum"; WEBDEVICEPARAMETERS = "{\"1234\":\"1234\"}"; final
     * NotificationUserActionResponse userActionResponse = new
     * NotificationUserActionResponse();
     * Constants.getVerifyNotificationResponseMap().put(correlationID,
     * userActionResponse); // calling method
     * userServiceImpl.checkNotificationResponse(correlationID,
     * WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request); }); // Test
     * assertEquals("Notification is NOT still acted", exn.getMessage(),
     * "Empty user action response object testcase"); }
     * @Test final void
     * checkNotificationResponseWithNotificationAcceptedScenario() { //
     * Precondition correlationID = "1234"; WEBDEVICEFINGERPRINT =
     * "browser-checksum"; WEBDEVICEPARAMETERS = "{\"1234\":\"1234\"}"; final
     * NotificationUserActionResponse userActionResponse = new
     * NotificationUserActionResponse();
     * userActionResponse.setActionResponse(PropertyConstants.
     * RelIdVerifyConstants.NOTIFICATION_ACCEPT_LABEL);
     * Constants.getVerifyNotificationResponseMap().put(correlationID,
     * userActionResponse); // calling method final boolean notificationResponse
     * = userServiceImpl.checkNotificationResponse(correlationID,
     * WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request); // Test
     * assertEquals(true, notificationResponse,
     * "Notification accepted scenario"); }
     * @Test final void
     * checkNotificationResponseWithNotificationRejectedScenario() { //
     * Precondition correlationID = "1234"; WEBDEVICEFINGERPRINT =
     * "browser-checksum"; WEBDEVICEPARAMETERS = "{\"1234\":\"1234\"}"; final
     * NotificationUserActionResponse userActionResponse = new
     * NotificationUserActionResponse();
     * userActionResponse.setActionResponse(PropertyConstants.
     * RelIdVerifyConstants.NOTIFICATION_REJECT_LABEL);
     * Constants.getVerifyNotificationResponseMap().put(correlationID,
     * userActionResponse); // calling method final boolean notificationResponse
     * = userServiceImpl.checkNotificationResponse(correlationID,
     * WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request); // Test
     * assertEquals(false, notificationResponse,
     * "Notification rejected scenario"); }
     * @Test final void checkNotificationResponseWithNotificationFraudScenario()
     * { // Precondition correlationID = "1234"; WEBDEVICEFINGERPRINT =
     * "browser-checksum"; WEBDEVICEPARAMETERS = "{\"1234\":\"1234\"}"; final
     * NotificationUserActionResponse userActionResponse = new
     * NotificationUserActionResponse();
     * userActionResponse.setActionResponse(PropertyConstants.
     * RelIdVerifyConstants.NOTIFICATION_FRAUD_LABEL);
     * Constants.getVerifyNotificationResponseMap().put(correlationID,
     * userActionResponse); // calling method final boolean notificationResponse
     * = userServiceImpl.checkNotificationResponse(correlationID,
     * WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request); // Test
     * assertEquals(false, notificationResponse, "Notification fraud scenario");
     * }
     * @Test final void
     * checkNotificationResponseWithNotificationIncorrectActionResponseScenario(
     * ) { final RelIDAuthServerOAuth2Exception exn =
     * assertThrows(RelIDAuthServerOAuth2Exception.class, () -> { //
     * Precondition correlationID = "1234"; WEBDEVICEFINGERPRINT =
     * "browser-checksum"; WEBDEVICEPARAMETERS = "{\"1234\":\"1234\"}"; final
     * NotificationUserActionResponse userActionResponse = new
     * NotificationUserActionResponse();
     * userActionResponse.setActionResponse("incorrect-action-response");
     * Constants.getVerifyNotificationResponseMap().put(correlationID,
     * userActionResponse); // calling method
     * userServiceImpl.checkNotificationResponse(correlationID,
     * WEBDEVICEFINGERPRINT, WEBDEVICEPARAMETERS, request); }); // Test
     * assertEquals("Incorrect action response found", exn.getMessage(),
     * "Incorrect Action Response scenario"); }
     *//**
        * This should throw InvalidRequestException whenever request object
        * found to be null
        */
    /*
     * @Test final void shouldThrowInvalidRequestExceptionIfNullRequest() {
     * final InvalidRequestException exn =
     * assertThrows(InvalidRequestException.class, () -> { // Precondition final
     * HttpServletRequest request = null; final Map<String, Object>
     * inputParameters = new HashMap<String, Object>(); // calling method
     * userServiceImpl.validateUserByTOTP(request, response, inputParameters);
     * }); // Test assertEquals("HttpServletRequest is null or empty",
     * exn.getMessage(), "Null Request object testcase"); }
     *//**
        * This should throw InvalidRequestException whenever response object
        * found to be null
        */
    /*
     * @Test final void shouldThrowInvalidRequestExceptionIfNullResponse() {
     * final InvalidRequestException exn =
     * assertThrows(InvalidRequestException.class, () -> { // Precondition final
     * HttpServletResponse response = null; final Map<String, Object>
     * inputParameters = new HashMap<String, Object>(); // calling method
     * userServiceImpl.validateUserByTOTP(request, response, inputParameters);
     * }); // Test assertEquals("HttpServletResponse is null or empty",
     * exn.getMessage(), "Null Response object testcase"); }
     *//**
        * This should throw InvalidRequestException whenever input parameters
        * found to be null
        */
    /*
     * @Test final void
     * shouldThrowInvalidRequestExceptionIfNullInputParameters() { final
     * InvalidRequestException exn = assertThrows(InvalidRequestException.class,
     * () -> { // Precondition final Map<String, Object> inputParameters = null;
     * // calling method userServiceImpl.validateUserByTOTP(request, response,
     * inputParameters); }); // Test
     * assertEquals("InputParameters are null or empty", exn.getMessage(),
     * "Null input parameter testcase"); }
     *//**
        * This should throw InvalidRequestException whenever input parameters
        * found to be empty
        */
    /*
     * @Test final void
     * shouldThrowInvalidRequestExceptionIfEmptyInputParameters() { final
     * InvalidRequestException exn = assertThrows(InvalidRequestException.class,
     * () -> { final Map<String, Object> inputParameters = new HashMap<String,
     * Object>(); // calling method userServiceImpl.validateUserByTOTP(request,
     * response, inputParameters); }); // Test
     * assertEquals("InputParameters are null or empty", exn.getMessage(),
     * "Empty input parameters testcase"); }
     *//**
        * This testcase throws InvalidRequestException whenever null client id
        * received
        */
    /*
     * @Test final void
     * shouldThrowsInvalidRequestExceptionIfNullClientIdReceived() { final
     * InvalidRequestException exn = assertThrows(InvalidRequestException.class,
     * () -> { // Precondition final Map<String, Object> inputParameters = new
     * HashMap<String, Object>(); inputParameters.put(EnterpriseInfo.CLIENT_ID,
     * null); // calling method userServiceImpl.validateUserByTOTP(request,
     * response, inputParameters); }); // Test
     * assertEquals("clientId is null or empty", exn.getMessage(),
     * "Null client id testcase"); }
     *//**
        * This testcase throws InvalidRequestException whenever empty client id
        * received
        */
    /*
     * @Test final void
     * shouldThrowsInvalidRequestExceptionIfEmptyClientIdReceived() { final
     * InvalidRequestException exn = assertThrows(InvalidRequestException.class,
     * () -> { // Precondition final Map<String, Object> inputParameters = new
     * HashMap<String, Object>(); inputParameters.put(EnterpriseInfo.CLIENT_ID,
     * " "); // calling method userServiceImpl.validateUserByTOTP(request,
     * response, inputParameters); }); // Test
     * assertEquals("clientId is null or empty", exn.getMessage(),
     * "Empty client id testcase"); }
     *//**
        * This testcase throws InvalidRequestException if null scope is received
        */
    /*
     * @Test final void shouldThrowsInvalidRequestExceptionIfNullScopeReceived()
     * { final InvalidRequestException exn =
     * assertThrows(InvalidRequestException.class, () -> { // Precondition final
     * Map<String, Object> inputParameters = new HashMap<String, Object>();
     * inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
     * inputParameters.put(EnterpriseInfo.SCOPE, null); // calling method
     * userServiceImpl.validateUserByTOTP(request, response, inputParameters);
     * }); // Test assertEquals("scope is null or empty", exn.getMessage(),
     * "Null scope test case"); }
     *//**
        * This testcase throws InvalidRequestException if empty scope is
        * received
        */
    /*
     * @Test final void
     * shouldThrowsInvalidRequestExceptionIfEmptyScopeReceived() { final
     * InvalidRequestException exn = assertThrows(InvalidRequestException.class,
     * () -> { // Precondition final Map<String, Object> inputParameters = new
     * HashMap<String, Object>(); inputParameters.put(EnterpriseInfo.CLIENT_ID,
     * clientId); inputParameters.put(EnterpriseInfo.SCOPE, " "); // calling
     * method userServiceImpl.validateUserByTOTP(request, response,
     * inputParameters); }); // Test assertEquals("scope is null or empty",
     * exn.getMessage(), "Empty scope test case"); }
     *//**
        * This testcase throws IllegalArgumentException whenever username is
        * null
        */
    /*
     * @Test final void
     * shouldThrowsIllegalArgumentExceptionIfNullUsernameReceived() { final
     * IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * final Map<String, Object> inputParameters = new HashMap<String,
     * Object>(); inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
     * inputParameters.put(Constants.REQ_PARAM_USERNAME, null);
     * inputParameters.put(EnterpriseInfo.SCOPE, scopeString); // calling method
     * userServiceImpl.validateUserByTOTP(request, response, inputParameters);
     * }); // Test assertEquals("username is null or empty", exn.getMessage(),
     * "Username null test case"); }
     *//**
        * This testcase throws IllegalArgumentException whenever username is
        * empty
        */
    /*
     * @Test final void
     * shouldThrowsIllegalArgumentExceptionIfEmptyUsernameReceived() { final
     * IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * final Map<String, Object> inputParameters = new HashMap<String,
     * Object>(); inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
     * inputParameters.put(Constants.REQ_PARAM_USERNAME, " ");
     * inputParameters.put(EnterpriseInfo.SCOPE, scopeString); // calling method
     * userServiceImpl.validateUserByTOTP(request, response, inputParameters);
     * }); // Test assertEquals("username is null or empty", exn.getMessage(),
     * "Empty user name test case"); }
     *//**
        * This testcase throws IllegalArgumentException whenever
        * WebDeviceParameter is null
        */
    /*
     * @Test final void
     * shouldThrowsIllegalArgumentExceptionIfNullWebDeviceParameterReceived() {
     * final IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * final Map<String, Object> inputParameters = new HashMap<String,
     * Object>(); inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
     * inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, null);
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR,
     * WEBDEVICEFINGERPRINT); inputParameters.put(EnterpriseInfo.SCOPE,
     * scopeString); // calling method
     * userServiceImpl.validateUserByTOTP(request, response, inputParameters);
     * }); // Test assertEquals("webDeviceParameters are null or empty",
     * exn.getMessage(), "Null device parameter case test case"); }
     *//**
        * This testcase throws IllegalArgumentException whenever
        * WebDeviceParameter is empty
        */
    /*
     * @Test final void
     * shouldThrowsIllegalArgumentExceptionIfEmptyWebDeviceParameterReceived() {
     * final IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * final Map<String, Object> inputParameters = new HashMap<String,
     * Object>(); inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
     * inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, " ");
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR,
     * WEBDEVICEFINGERPRINT); inputParameters.put(EnterpriseInfo.SCOPE,
     * scopeString); // calling method
     * userServiceImpl.validateUserByTOTP(request, response, inputParameters);
     * }); // Test assertEquals("webDeviceParameters are null or empty",
     * exn.getMessage(), "Empty device parameter case test case"); }
     *//**
        * This testcase throws IllegalArgumentException whenever
        * WebDeviceFingerprint is null
        */
    /*
     * @Test final void
     * shouldThrowsIllegalArgumentExceptionIfNullWebDeviceFingerprintReceived()
     * { final IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * final Map<String, Object> inputParameters = new HashMap<String,
     * Object>(); inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
     * inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR,
     * WEBDEVICEPARAMETERS);
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, null);
     * inputParameters.put(EnterpriseInfo.SCOPE, scopeString); // calling method
     * userServiceImpl.validateUserByTOTP(request, response, inputParameters);
     * }); // Test assertEquals("webDeviceFingerprint is null or empty",
     * exn.getMessage(), "Null device fingerprint case test case"); }
     *//**
        * This testcase throws IllegalArgumentException whenever
        * WebDeviceFingerprint is empty
        */
    /*
     * @Test final void
     * shouldThrowsIllegalArgumentExceptionIfEmptyWebDeviceFingerprintReceived()
     * { final IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * final Map<String, Object> inputParameters = new HashMap<String,
     * Object>(); inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
     * inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR,
     * WEBDEVICEPARAMETERS);
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, " ");
     * inputParameters.put(EnterpriseInfo.SCOPE, scopeString); // calling method
     * userServiceImpl.validateUserByTOTP(request, response, inputParameters);
     * }); // Test assertEquals("webDeviceFingerprint is null or empty",
     * exn.getMessage(), "Empty device fingerprint case test case"); }
     *//**
        * This testcase throws IllegalArgumentException whenever invalid json
        * value received in WebDeviceParameter parameter
        */
    /*
     * @Test final void
     * shouldThrowsIllegalArgumentExceptionIfInvalidWebDeviceParameterReceived()
     * { final IllegalArgumentException exn =
     * assertThrows(IllegalArgumentException.class, () -> { // Precondition
     * final Map<String, Object> inputParameters = new HashMap<String,
     * Object>(); inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
     * inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, "key=value");
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR,
     * WEBDEVICEFINGERPRINT); inputParameters.put(EnterpriseInfo.SCOPE,
     * scopeString); // calling method
     * userServiceImpl.validateUserByTOTP(request, response, inputParameters);
     * }); // Test assertEquals("web device Parameters are invalid",
     * exn.getMessage(), "Invalid device parameter case test case"); }
     *//**
        * This testcase throws AccessDeniedException whenever totp is valid
        */
    /*
     * @Test final void totpValidScenario() { // Precondition final Map<String,
     * Object> inputParameters = new HashMap<String, Object>();
     * inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
     * inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR,
     * WEBDEVICEPARAMETERS);
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR,
     * WEBDEVICEFINGERPRINT); inputParameters.put(EnterpriseInfo.SCOPE,
     * scopeString); try { Mockito.when(
     * validateTotpServiceImpl.validateTotp(Mockito.anyObject(),
     * Mockito.anyObject(), Mockito.anyMap())) .thenReturn(true); } catch (final
     * TOTPValidationException e) { }
     * Mockito.when(request.getSession()).thenReturn(session);
     * Mockito.when(request.getSession().getAttribute(Mockito.anyString())).
     * thenReturn(correlationID); final NotificationUserActionResponse
     * actionResponse = new NotificationUserActionResponse();
     * actionResponse.setResponseCode(100);
     * actionResponse.setActionResponse(PropertyConstants.RelIdVerifyConstants.
     * NOTIFICATION_ACCEPT_LABEL);
     * Constants.getVerifyNotificationResponseMap().put(correlationID,
     * actionResponse); final List<GrantedAuthority> authorities = new
     * ArrayList<>(); authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
     * final UserDetails user = new User(testUsername, "", authorities); //
     * final Date date = new Date(); final Map<String, String> deviceParameters
     * = new HashMap<String, String>(); deviceParameters.put("Platform",
     * "Firefox"); deviceParameters.put("IPAddress", "10.1.1.9"); // final
     * WebDevMaster device = new WebDevMaster("11", //
     * DeviceStatus.ACTIVE.getName(), userLocation, // deviceParameters, date,
     * date, WEBDEVICEFINGERPRINT);
     * Mockito.when(customUserDetailsService.loadUserByUsername(Mockito.
     * anyString())).thenReturn(user); //
     * Mockito.when(customClientDetailService.loadClientByClientId(Mockito.
     * anyString())).thenReturn(clientDetails); //
     * Mockito.when(webDevMasterService.fetchWebDeviceMaster(Mockito.anyString()
     * )).thenReturn(device); // calling method final Authentication
     * authentication = userServiceImpl.validateUserByTOTP(request, response,
     * inputParameters); // Test assertNotNull(authentication,
     * "Success TOTP scenario"); }
     *//**
        * This testcase throws AccessDeniedException whenever totp is valid
        */
    /*
     * @Test final void totpValidScenarioDiscardNotification() { // Precondition
     * final Map<String, Object> inputParameters = new HashMap<String,
     * Object>(); WEBDEVICEFINGERPRINT = "12345";
     * inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
     * inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
     * WEBDEVICEPARAMETERS =
     * "{\"platform\":\"win32\", \"userAgent\":\"firefox\"}";
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR,
     * WEBDEVICEPARAMETERS);
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR,
     * WEBDEVICEFINGERPRINT); inputParameters.put(EnterpriseInfo.SCOPE,
     * scopeString); try { Mockito.when(
     * validateTotpServiceImpl.validateTotp(Mockito.anyObject(),
     * Mockito.anyObject(), Mockito.anyMap())) .thenReturn(true); } catch (final
     * TOTPValidationException e) { }
     * Mockito.when(request.getSession()).thenReturn(session);
     * Mockito.when(request.getSession().getAttribute(Mockito.anyString())).
     * thenReturn(correlationID);
     * Constants.getVerifyNotificationResponseMap().remove(correlationID); final
     * List<GrantedAuthority> authorities = new ArrayList<>();
     * authorities.add(new SimpleGrantedAuthority("ROLE_USER")); final
     * UserDetails user = new User(testUsername, "", authorities); final Date
     * date = new Date(); final Map<String, Object> deviceParameters = new
     * HashMap<String, Object>(); deviceParameters.put("Platform", "Firefox");
     * deviceParameters.put("IPAddress", "10.1.1.9"); final WebDevMaster device
     * = new WebDevMaster("11", DeviceStatus.ACTIVE.getName(), userLocation,
     * deviceParameters, date, date, WEBDEVICEFINGERPRINT);
     * Mockito.when(customUserDetailsService.loadUserByUsername(Mockito.
     * anyString())).thenReturn(user);
     * Mockito.when(customClientDetailService.loadClientByClientId(Mockito.
     * anyString())).thenReturn(clientDetails);
     * Mockito.when(webDevMasterService.fetchWebDeviceMaster(Mockito.anyString()
     * )).thenReturn(device); // calling method final Authentication
     * authentication = userServiceImpl.validateUserByTOTP(request, response,
     * inputParameters); // Test assertNotNull(authentication,
     * "Send discard notification scenario"); }
     *//**
        * This testcase throws AccessDeniedException whenever totp is valid
        */
    /*
     * @Test final void totpValidScenarioRejectNotification() { final
     * AccessDeniedException exn = assertThrows(AccessDeniedException.class, ()
     * -> { // Precondition final Map<String, Object> inputParameters = new
     * HashMap<String, Object>(); WEBDEVICEFINGERPRINT = "12345";
     * inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
     * inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
     * WEBDEVICEPARAMETERS =
     * "{\"platform\":\"win32\", \"userAgent\":\"firefox\"}";
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR,
     * WEBDEVICEPARAMETERS);
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR,
     * WEBDEVICEFINGERPRINT); inputParameters.put(EnterpriseInfo.SCOPE,
     * scopeString); Mockito.when(request.getSession()).thenReturn(session);
     * Mockito.when(request.getSession().getAttribute(Mockito.anyString())).
     * thenReturn(correlationID); final NotificationUserActionResponse
     * actionResponse = new NotificationUserActionResponse();
     * actionResponse.setResponseCode(100);
     * actionResponse.setActionResponse(PropertyConstants.RelIdVerifyConstants.
     * NOTIFICATION_REJECT_LABEL); actionResponse.setUserId(testUsername);
     * Constants.getVerifyNotificationResponseMap().put(correlationID,
     * actionResponse); final List<GrantedAuthority> authorities = new
     * ArrayList<>(); authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
     * // final UserDetails user = new User(testUsername, "", authorities); //
     * final Date date = new Date(); final Map<String, String> deviceParameters
     * = new HashMap<String, String>(); deviceParameters.put("Platform",
     * "Firefox"); deviceParameters.put("IPAddress", "10.1.1.9"); // calling
     * method userServiceImpl.validateUserByTOTP(request, response,
     * inputParameters); }); // Test assertEquals(Constants.UNAUTHORIZED_ACCESS,
     * exn.getMessage(), "Reject Notification scenario"); }
     *//**
        * This testcase throws AccessDeniedException whenever totp is valid
        */
    /*
     * @Test final void totpValidScenarioFraudNotification() { final
     * AccessDeniedException exn = assertThrows(AccessDeniedException.class, ()
     * -> { // Precondition final Map<String, Object> inputParameters = new
     * HashMap<String, Object>(); WEBDEVICEFINGERPRINT = "12345";
     * inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
     * inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
     * WEBDEVICEPARAMETERS =
     * "{\"platform\":\"win32\", \"userAgent\":\"firefox\"}";
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR,
     * WEBDEVICEPARAMETERS);
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR,
     * WEBDEVICEFINGERPRINT); inputParameters.put(EnterpriseInfo.SCOPE,
     * scopeString); Mockito.when(request.getSession()).thenReturn(session);
     * Mockito.when(request.getSession().getAttribute(Mockito.anyString())).
     * thenReturn(correlationID); final NotificationUserActionResponse
     * actionResponse = new NotificationUserActionResponse();
     * actionResponse.setResponseCode(100);
     * actionResponse.setActionResponse(PropertyConstants.RelIdVerifyConstants.
     * NOTIFICATION_FRAUD_LABEL);
     * Constants.getVerifyNotificationResponseMap().put(correlationID,
     * actionResponse); final List<GrantedAuthority> authorities = new
     * ArrayList<>(); authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
     * // final UserDetails user = new User(testUsername, "", authorities); //
     * final Date date = new Date(); final Map<String, String> deviceParameters
     * = new HashMap<String, String>(); deviceParameters.put("Platform",
     * "Firefox"); deviceParameters.put("IPAddress", "10.1.1.9"); // calling
     * method userServiceImpl.validateUserByTOTP(request, response,
     * inputParameters); }); // Test assertEquals(Constants.UNAUTHORIZED_ACCESS,
     * exn.getMessage(), "FRAUD Notification scenario"); }
     *//**
        * This testcase throws AccessDeniedException whenever totp is valid
        */

    /*
     * @Test final void totpInvalidscenario() { final AccessDeniedException exn
     * = assertThrows(AccessDeniedException.class, () -> { // Precondition final
     * Map<String, Object> inputParameters = new HashMap<String, Object>();
     * WEBDEVICEFINGERPRINT = "12345";
     * inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
     * inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
     * WEBDEVICEPARAMETERS =
     * "{\"platform\":\"win32\", \"userAgent\":\"firefox\"}";
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR,
     * WEBDEVICEPARAMETERS);
     * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR,
     * WEBDEVICEFINGERPRINT); inputParameters.put(EnterpriseInfo.SCOPE,
     * scopeString); try {
     * Mockito.when(validateTotpServiceImpl.validateTotp(Mockito.anyObject(),
     * Mockito.anyObject(), Mockito.anyMap())).thenReturn(false); } catch (final
     * TOTPValidationException e) { }
     * Mockito.when(request.getSession()).thenReturn(session);
     * Mockito.when(request.getSession().getAttribute(Mockito.anyString())).
     * thenReturn(correlationID);
     * Constants.getVerifyNotificationResponseMap().remove(correlationID); final
     * Map<String, String> deviceParameters = new HashMap<String, String>();
     * deviceParameters.put("Platform", "Firefox");
     * deviceParameters.put("IPAddress", "10.1.1.9"); // calling method
     * userServiceImpl.validateUserByTOTP(request, response, inputParameters);
     * }); // Test assertEquals(Constants.UNAUTHORIZED_ACCESS, exn.getMessage(),
     * "Invalid TOTP scenario"); }
     *//**
        * This testcase throws AccessDeniedException whenever totp is valid
        *//*
           * @Test final void totpValidationProcessThrowsExceptionScenario() {
           * final AuthenticationServiceException exn =
           * assertThrows(AuthenticationServiceException.class, () -> { //
           * Precondition final Map<String, Object> inputParameters = new
           * HashMap<String, Object>(); WEBDEVICEFINGERPRINT = "12345";
           * inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
           * inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
           * WEBDEVICEPARAMETERS =
           * "{\"platform\":\"win32\", \"userAgent\":\"firefox\"}";
           * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR,
           * WEBDEVICEPARAMETERS);
           * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR,
           * WEBDEVICEFINGERPRINT); inputParameters.put(EnterpriseInfo.SCOPE,
           * scopeString); try {
           * Mockito.when(validateTotpServiceImpl.validateTotp(Mockito.anyObject
           * (), Mockito.anyObject(), Mockito.anyMap())).thenThrow(new
           * AuthenticationServiceException("error in totp validation")); }
           * catch (final TOTPValidationException e) { }
           * Mockito.when(request.getSession()).thenReturn(session);
           * Mockito.when(request.getSession().getAttribute(Mockito.anyString())
           * ).thenReturn(correlationID);
           * Constants.getVerifyNotificationResponseMap().remove(correlationID);
           * final Map<String, String> deviceParameters = new HashMap<String,
           * String>(); deviceParameters.put("Platform", "Firefox");
           * deviceParameters.put("IPAddress", "10.1.1.9"); // calling method
           * userServiceImpl.validateUserByTOTP(request, response,
           * inputParameters); }); // Test
           * assertEquals("error in totp validation", exn.getMessage(),
           * "Invalid TOTP scenario"); }
           * @Test final void checkUserActionOnNotificationScenario1() { final
           * UnauthorizedUserException exn =
           * assertThrows(UnauthorizedUserException.class, () -> { //
           * Precondition final Map<String, Object> inputParameters = new
           * HashMap<String, Object>(); WEBDEVICEFINGERPRINT = "12345";
           * inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
           * inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
           * WEBDEVICEPARAMETERS =
           * "{\"platform\":\"win32\", \"userAgent\":\"firefox\"}";
           * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR,
           * WEBDEVICEPARAMETERS);
           * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR,
           * WEBDEVICEFINGERPRINT); inputParameters.put(EnterpriseInfo.SCOPE,
           * scopeString);
           * Mockito.when(request.getSession()).thenReturn(session);
           * Mockito.when(request.getSession().getAttribute(Mockito.anyString())
           * ).thenReturn(null);
           * Constants.getVerifyNotificationResponseMap().remove(correlationID);
           * final Map<String, String> deviceParameters = new HashMap<String,
           * String>(); deviceParameters.put("Platform", "Firefox");
           * deviceParameters.put("IPAddress", "10.1.1.9"); // calling method
           * userServiceImpl.checkUserActionOnNotification(request, response,
           * inputParameters); }); // Test
           * assertEquals(Constants.UNAUTHORIZED_ACCESS, exn.getMessage(),
           * "Invalid Correlation ID scenario"); }
           * @Test final void checkUserActionOnNotificationScenario2() { final
           * UnauthorizedUserException exn =
           * assertThrows(UnauthorizedUserException.class, () -> { //
           * Precondition final Map<String, Object> inputParameters = new
           * HashMap<String, Object>(); WEBDEVICEFINGERPRINT = "12345";
           * inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
           * inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
           * WEBDEVICEPARAMETERS =
           * "{\"platform\":\"win32\", \"userAgent\":\"firefox\"}";
           * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR,
           * WEBDEVICEPARAMETERS);
           * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR,
           * WEBDEVICEFINGERPRINT); inputParameters.put(EnterpriseInfo.SCOPE,
           * scopeString); correlationID = "1234";
           * Mockito.when(request.getSession()).thenReturn(session);
           * Mockito.when(request.getSession().getAttribute(Mockito.anyString())
           * ).thenReturn(correlationID); final NotificationUserActionResponse
           * actionResponse = new NotificationUserActionResponse();
           * actionResponse.setResponseCode(100);
           * actionResponse.setActionResponse(PropertyConstants.
           * RelIdVerifyConstants.NOTIFICATION_REJECT_LABEL);
           * Constants.getVerifyNotificationResponseMap().put(correlationID,
           * actionResponse); final Map<String, String> deviceParameters = new
           * HashMap<String, String>(); deviceParameters.put("Platform",
           * "Firefox"); deviceParameters.put("IPAddress", "10.1.1.9"); //
           * calling method
           * userServiceImpl.checkUserActionOnNotification(request, response,
           * inputParameters); }); // Test
           * assertEquals(Constants.UNAUTHORIZED_ACCESS, exn.getMessage(),
           * "Invalid Correlation ID scenario"); }
           * @Test final void checkUserActionOnNotificationScenario3() { //
           * Precondition final Map<String, Object> inputParameters = new
           * HashMap<String, Object>(); correlationID = "1234";
           * WEBDEVICEFINGERPRINT = "12345"; WEBDEVICEPARAMETERS =
           * "{\"platform\":\"win32\", \"userAgent\":\"firefox\"}";
           * inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
           * inputParameters.put(Constants.REQ_PARAM_USERNAME, testUsername);
           * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR,
           * WEBDEVICEPARAMETERS);
           * inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR,
           * WEBDEVICEFINGERPRINT); inputParameters.put(EnterpriseInfo.SCOPE,
           * scopeString); final Map<String, String> deviceParameters = new
           * HashMap<String, String>(); deviceParameters.put("Platform",
           * "Firefox"); deviceParameters.put("IPAddress", "10.1.1.9");
           * Mockito.when(request.getSession()).thenReturn(session);
           * Mockito.when(request.getSession().getAttribute(Mockito.anyString())
           * ).thenReturn(correlationID); final NotificationUserActionResponse
           * actionResponse = new NotificationUserActionResponse();
           * actionResponse.setResponseCode(100);
           * actionResponse.setActionResponse(PropertyConstants.
           * RelIdVerifyConstants.NOTIFICATION_ACCEPT_LABEL);
           * Constants.getVerifyNotificationResponseMap().put(correlationID,
           * actionResponse); final List<GrantedAuthority> authorities = new
           * ArrayList<>(); authorities.add(new
           * SimpleGrantedAuthority("ROLE_USER")); final UserDetails user = new
           * User(testUsername, "", authorities);
           * Mockito.when(customUserDetailsService.loadUserByUsername(Mockito.
           * anyString())).thenReturn(user); // calling method final
           * Authentication authentication =
           * userServiceImpl.checkUserActionOnNotification(request, response,
           * inputParameters); // Test assertNotNull(authentication,
           * "Authentication success"); }
           */

    @Test
    void testNullUserVO_getUserInfo() {
        Mockito.when(userAuthInfoRepoImpl.fetchUserDetailsFromLoginId(Mockito.anyString())).thenReturn(null);

        assertThrows(UsernameNotFoundException.class, () -> {
            userServiceImpl.getUserInfo(Mockito.anyString());
        });
    }

    @Test
    void testEmptyUserVO_getUserInfo() {

        final UserAuthInfoVO userVo = new UserAuthInfoVO();

        Mockito.when(userAuthInfoRepoImpl.fetchUserDetailsFromLoginId(Mockito.anyString())).thenReturn(userVo);
        assertNotNull(userServiceImpl.getUserInfo(Mockito.anyString()));
    }

    /*
     * @Test void shouldFetchTOTPAuthFactorsForValidUser() throws
     * NoSuchAlgorithmException { final RelId relId = new RelId();
     * relId.setRelIdStatus(RelIdUserStatus.ACTIVE); final List<RelId> relIdList
     * = new ArrayList<RelId>(); relIdList.add(relId); final UserAuthInfoVO user
     * = new UserAuthInfoVO(); user.setRelIds(relIdList);
     * user.setUserStatus(RelIdUserStatus.ACTIVE);
     * when(userAuthInfoRepoImpl.fetchUserDetailsFromLoginId(testUsername)).
     * thenReturn(user); final AuthType authType =
     * userServiceImpl.getUserAuthFactorsBasedOnUserValidity(testUsername);
     * assertEquals(AuthType.TOTP, authType); }
     * @Test void shouldFetchRandomAuthFactorsForInvalidUser() throws
     * NoSuchAlgorithmException { final RelId relId = new RelId();
     * relId.setRelIdStatus(RelIdUserStatus.ACTIVE); final List<RelId> relIdList
     * = new ArrayList<RelId>(); relIdList.add(relId); final UserAuthInfoVO user
     * = new UserAuthInfoVO(); user.setRelIds(relIdList);
     * user.setUserStatus(RelIdUserStatus.ACTIVE); final List<AuthType>
     * allowedAuthType = new ArrayList<AuthType>();
     * allowedAuthType.add(AuthType.PASS); allowedAuthType.add(AuthType.TOTP);
     * when(userAuthInfoRepoImpl.fetchUserDetailsFromLoginId(testUsername)).
     * thenReturn(null); final AuthType authType =
     * userServiceImpl.getUserAuthFactorsBasedOnUserValidity(testUsername);
     * assertNotNull(authType); assertTrue(allowedAuthType.contains(authType));
     * }
     * @Test void shouldFetchPASSAuthFactorsForNonActiveUser() throws
     * NoSuchAlgorithmException { final RelId relId = new RelId();
     * relId.setRelIdStatus(RelIdUserStatus.ACTIVE); final List<RelId> relIdList
     * = new ArrayList<RelId>(); relIdList.add(relId); final UserAuthInfoVO user
     * = new UserAuthInfoVO(); user.setRelIds(relIdList);
     * user.setUserStatus(RelIdUserStatus.INACTIVE);
     * when(userAuthInfoRepoImpl.fetchUserDetailsFromLoginId(testUsername)).
     * thenReturn(user); final AuthType authType =
     * userServiceImpl.getUserAuthFactorsBasedOnUserValidity(testUsername);
     * assertEquals(AuthType.PASS, authType); }
     * @Test void shouldFetchPASSAuthFactorsForNonActiveRelId() throws
     * NoSuchAlgorithmException { final RelId relId = new RelId();
     * relId.setRelIdStatus(RelIdUserStatus.INACTIVE); final List<RelId>
     * relIdList = new ArrayList<RelId>(); relIdList.add(relId); final
     * UserAuthInfoVO user = new UserAuthInfoVO(); user.setRelIds(relIdList);
     * user.setUserStatus(RelIdUserStatus.ACTIVE);
     * when(userAuthInfoRepoImpl.fetchUserDetailsFromLoginId(testUsername)).
     * thenReturn(user); final AuthType authType =
     * userServiceImpl.getUserAuthFactorsBasedOnUserValidity(testUsername);
     * assertEquals(AuthType.PASS, authType); }
     */
}
