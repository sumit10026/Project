package com.uniken.authserver.services.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.utility.Constants;

@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
class SecureCookieServiceImplTest {

    @InjectMocks
    SecureCookieServiceImpl secureCookieService;

    @Test
    void testSecureCookie() {
        final String cookie = secureCookieService.generateSecureCookie();
        final Map<String, String> cookieAttributes = new HashMap<>();

        for (final String cookieAttr : cookie.split(";")) {
            final String[] keyValue = cookieAttr.trim().split("=");
            if (keyValue.length > 1 && keyValue[0] != "Expires") {
                cookieAttributes.put(keyValue[0], keyValue[1]);
            } else {
                cookieAttributes.put(keyValue[0], "true");
            }
        }

        assertEquals("/", cookieAttributes.get("Path"));
        assertEquals("86400", cookieAttributes.get("Max-Age"));
        assertEquals("Strict", cookieAttributes.get("SameSite"));
        assertEquals("HIGH", cookieAttributes.get("priority"));
        assertEquals("true", cookieAttributes.get("Secure"));
        assertEquals("true", cookieAttributes.get("HttpOnly"));
        assertTrue(cookieAttributes.containsKey(Constants.SECURE_COOKIE_NAME));

    }

}
