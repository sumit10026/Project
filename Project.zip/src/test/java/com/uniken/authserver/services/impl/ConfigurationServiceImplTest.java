package com.uniken.authserver.services.impl;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;

import com.uniken.authserver.services.api.SecureCookieService;
import com.uniken.authserver.services.api.SessionService;
import com.uniken.pass.handler.library.sync.api.PassHandler;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.domains.Configuration;
import com.uniken.authserver.domains.ConfigurationResponse;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.user.DeviceStatus;

@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
class ConfigurationServiceImplTest {

    @InjectMocks
    ConfigurationServiceImpl service;

    @Mock
    Configuration configuration;

    @Mock
    WebDevMasterService webDevMasterService;

    @Mock
    UserAuthInfoRepo userAuthInfoRepo;

    @Mock
    SecureCookieService secureCookieService;

    @Mock
    SessionService sessionService;

    @Mock
    PassHandler passHandler;

    MockHttpServletRequest request;

    MockHttpServletResponse response;

    Cookie secureCookie;

    WebDevMaster webDevMaster;

    String webDeviceParameterChecksum;

    @BeforeEach
    public void setup() {
        request = new MockHttpServletRequest();
        response = new MockHttpServletResponse();

        secureCookie = new Cookie("__Host-ACC_CH", "8b52dba7-060f-4c9f-ba56-86b77a2985d5");
        secureCookie.setDomain("");
        secureCookie.setHttpOnly(true);
        secureCookie.setPath("/");
        secureCookie.setSecure(true);
        request.setCookies(secureCookie);

        final Map<String, Object> deviceParameters = new HashMap<>();
        deviceParameters.put("Platform", "Firefox");
        deviceParameters.put("IPAddress", "10.1.1.9");

        final String webDeviceUUID = "123e4567-e89b-12d3-a456-426655440000";
        webDeviceParameterChecksum = "1234";

        webDevMaster = new WebDevMaster(webDeviceUUID, DeviceStatus.ACTIVE.getName(), null, deviceParameters,
                new Date(), new Date(), webDeviceParameterChecksum);
    }

    @Test
    void getConfigurationWhileInvalidCookieAvailable() throws JsonProcessingException {

        when(secureCookieService.isSecureCookieExpired(request)).thenReturn(true);

//        when(secureCookieService.decryptSecureCookie(anyString())).thenReturn(anyString());

        // FIXME : Confirm about checksum
//        when(webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(secureCookie.getValue()))
//                .thenReturn(webDevMaster);

//        when(userAuthInfoRepo.fetchAssociatedUserWithWebDeviceUuid(webDevMaster.getWebDeviceUuid()))
//                .thenReturn(new ArrayList<Map<String, String>>());

        final ConfigurationResponse response = service.getConfigurations(request, webDeviceParameterChecksum);

        assertNotNull(response);

        // FIXME : Enable Password in Milestone 2
        // assertNotNull(response.getConfiguration().isPassword());

        assertNotNull(response.getConfiguration().isRememberMe());
        assertTrue(CollectionUtils.isEmpty(response.getAccounts()));
    }

    // FIXME : Handle it later
    /*
     * @Test void getConfigurationWhileValidCookieAvailable() throws
     * JsonProcessingException {
     * when(webDevMasterService.fetchWebDeviceMasterUsingSecureCookie(
     * secureCookie.getValue())) .thenReturn(webDevMaster); final
     * List<Map<String, String>> userList = new ArrayList<>(); Map<String,
     * String> userList.add("User1"); userList.add("User2");
     * when(userAuthInfoRepo.fetchAssociatedUserWithWebDeviceUuid(webDevMaster.
     * getWebDeviceUuid())) .thenReturn(userList); final ConfigurationResponse
     * response = service.getConfigurations(request,
     * webDeviceParameterChecksum); assertNotNull(response); // FIXME : Enable
     * Password in Milestone 2 //
     * assertNotNull(response.getConfiguration().isPassword());
     * assertNotNull(response.getConfiguration().isRememberMe());
     * assertTrue(response.getAccounts().contains("User1")); }
     */

}
