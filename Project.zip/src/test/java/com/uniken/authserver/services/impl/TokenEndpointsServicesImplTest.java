package com.uniken.authserver.services.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Date;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.EmptySource;
import org.junit.jupiter.params.provider.EnumSource;
import org.junit.jupiter.params.provider.NullSource;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.oauth2.common.exceptions.InvalidClientException;
import org.springframework.security.oauth2.common.exceptions.InvalidTokenException;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;

import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.repo.api.MongoTokenStoreRepo;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.auth.CustomOAuth2AccessToken;
import com.uniken.domains.auth.CustomOAuth2RefreshToken;
import com.uniken.domains.auth.CustomOAuth2RefreshTokenLog;
import com.uniken.domains.enums.auth.OAuthTokenTypes;

@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
class TokenEndpointsServicesImplTest {

    @Mock
    private DefaultTokenServices tokenServices;

    @Mock
    private MongoTokenStoreRepo mongoTokenStoreRepo;

    @InjectMocks
    private TokenEndpointsServicesImpl tokenEndpointsServices;

    private final String token = "1f6eb764-8e63-4044-aec7-5d25bb9a6329";
    private final String clientId = "MmUzNmEzY2YtMDYxOC00NzQyLWI2YTMtY2YwNjE4OTc0MmNh";
    private CustomOAuth2RefreshToken refreshToken = null;
    private CustomOAuth2AccessToken accessToken = null;

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {
    }

    @BeforeEach
    void setUp() throws Exception {
        refreshToken = Constants.GSON.fromJson(
                "{\"_id\":\"5df4e1ec8a376a51126834f6\",\"tokenId\":\"dc1b5f512b6d420a1a075f0183d598e9\","
                        + "\"token\":{\"value\":\"e819a9db-787f-423f-a9e9-5b133380eedf\","
                        + "\"_class\":\"org.springframework.security.oauth2.common.DefaultOAuth2RefreshToken\"},"
                        + "\"authentication\":{\"storedRequest\":{\"resourceIds\":[\"relid-verify-server\"],\"authorities\":[],"
                        + "\"approved\":true,\"responseTypes\":[],\"extensions\":{},"
                        + "\"clientId\":\"MmUzNmEzY2YtMDYxOC00NzQyLWI2YTMtY2YwNjE4OTc0MmNh\",\"scope\":[\"all\"],"
                        + "\"requestParameters\":{\"grant_type\":\"client_credentials\",\"scope\":\"all\"}},\"authorities\":[],"
                        + "\"authenticated\":false},\"created_ts\":\"2019-12-14T13:21:48.768+0000\","
                        + "\"_class\":\"com.uniken.domains.auth.CustomOAuth2RefreshToken\"}",
                CustomOAuth2RefreshToken.class);
        accessToken = Constants.GSON.fromJson(
                "{\"_id\":\"5df667675624a21e5f20ef4e\",\"token_id\":\"ecef62e066d898224ce8164b83e8aa87\","
                        + "\"refresh_token_id\":\"4d2224d1c1689e3b07f81083df1808ef\",\"authentication_id\":\"e7ce368730a4950b3409e7127f39008e\","
                        + "\"client_id\":\"MmUzNmEzY2YtMDYxOC00NzQyLWI2YTMtY2YwNjE4OTc0MmNh\","
                        + "\"authentication\":{\"storedRequest\":{\"resourceIds\":[\"relid-verify-server\"],\"authorities\":[],"
                        + "\"approved\":true,\"responseTypes\":[],\"extensions\":{},"
                        + "\"clientId\":\"MmUzNmEzY2YtMDYxOC00NzQyLWI2YTMtY2YwNjE4OTc0MmNh\",\"scope\":[\"all\"],"
                        + "\"requestParameters\":{\"grant_type\":\"client_credentials\",\"scope\":\"all\"}},\"authorities\":[],"
                        + "\"authenticated\":false},\"refresh_token\":{\"expiration\":\"2019-12-15T17:20:15.458+0000\","
                        + "\"value\":\"1bb60678-bf4a-4106-bcfa-819b131fa3ab\","
                        + "\"_class\":\"org.springframework.security.oauth2.common.DefaultExpiringOAuth2RefreshToken\"},"
                        + "\"created_ts\":\"2019-12-15T17:03:35.462+0000\",\"refresh_token_available\":false,"
                        + "\"value\":\"1f6eb764-8e63-4044-aec7-5d25bb9a6329\",\"expiration\":\"2019-12-17T03:15:38.461+0000\","
                        + "\"tokenType\":\"bearer\",\"scope\":[\"all\"],\"additionalInformation\":{},"
                        + "\"_class\":\"com.uniken.domains.auth.CustomOAuth2AccessToken\"}",
                CustomOAuth2AccessToken.class);
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    /**
     * Should return same boolean value as returned by default token services.
     *
     * @param returnValue
     *            the return value
     */
    @ParameterizedTest
    @ValueSource(booleans = { true, false })
    final void shouldReturnSameBooleanValueAsReturnedByDefaultTokenServices(final boolean returnValue) {

        // preconditions
        when(tokenServices.revokeToken(anyString())).thenReturn(returnValue);

        // call
        final boolean refreshTokenRevoked = tokenEndpointsServices.revokeRefreshToken(anyString());

        // test
        assertEquals(returnValue, refreshTokenRevoked);
    }

    /**
     * Should throw invalid token exception when given token type is invalid.
     *
     * @param tokenType
     *            the token type
     */
    @ParameterizedTest
    @NullSource
    @EmptySource
    @ValueSource(strings = { " ", "-", "invalid" })
    final void shouldThrowInvalidTokenExceptionWhenGivenTokenTypeIsInvalid(final String tokenType) {

        final InvalidTokenException thrown = assertThrows(InvalidTokenException.class, () -> {
            // preconditions
            final String token = null;
            final String clientId = null;

            // call
            tokenEndpointsServices.revokeToken(token, tokenType, clientId);
        });

        // test
        assertEquals("Invalid token type: " + tokenType, thrown.getMessage());
    }

    /**
     * Should throw invalid token exception when given refresh and access token
     * is not present in DB.
     *
     * @param tokenType
     *            the token type
     */
    @ParameterizedTest
    @EnumSource(value = OAuthTokenTypes.class, names = { "REFRESH_TOKEN", "ACCESS_TOKEN" })
    final void shouldThrowInvalidTokenExceptionWhenGivenRefreshAndAccessTokenIsNotPresentInDB(
            final OAuthTokenTypes tokenType) {

        final InvalidTokenException thrown = assertThrows(InvalidTokenException.class, () -> {
            // preconditions
            final String token = anyString(); // <-- Exception thrown due to
                                              // this
            final String clientId = null;

            // call
            tokenEndpointsServices.revokeToken(token, tokenType.name(), clientId);
        });

        // test
        assertEquals("Token was not recognised", thrown.getMessage());
    }

    /**
     * Should revoke refresh token when given refresh token is valid.
     */
    @Test
    void shouldRevokeRefreshTokenWhenGivenRefreshTokenIsValid() {

        // preconditions
        final String tokenType = OAuthTokenTypes.REFRESH_TOKEN.name();
        final OAuth2Authentication authentication = refreshToken.getAuthentication();
        final CustomOAuth2RefreshTokenLog refreshTokenLog = CustomOAuth2RefreshTokenLog
                .getInstanceOfExpiredRefreshTokenLog(refreshToken, new Date());
        when(mongoTokenStoreRepo.readRefreshToken(token)).thenReturn(refreshToken);
        when(mongoTokenStoreRepo.readAuthenticationForRefreshToken(refreshToken)).thenReturn(authentication);
        when(mongoTokenStoreRepo.readAndRemoveRefreshToken(token)).thenReturn(refreshTokenLog);

        // call
        final boolean revokeToken = tokenEndpointsServices.revokeToken(token, tokenType, clientId);

        // test
        assertTrue(revokeToken);
        verify(mongoTokenStoreRepo, times(1)).removeAccessTokenUsingRefreshToken(refreshTokenLog);
    }

    /**
     * Should throw invalid token exception when failed to remove refresh token
     * from DB.
     */
    @Test
    void shouldThrowInvalidTokenExceptionWhenFailedToRemoveRefreshTokenFromDB() {

        final InvalidTokenException thrown = assertThrows(InvalidTokenException.class, () -> {
            // preconditions
            final String tokenType = OAuthTokenTypes.REFRESH_TOKEN.name();
            final OAuth2Authentication authentication = refreshToken.getAuthentication();
            final CustomOAuth2RefreshToken refreshTokenLog = null; // <--
                                                                   // Exception
                                                                   // thrown due
                                                                   // to this
            when(mongoTokenStoreRepo.readRefreshToken(token)).thenReturn(refreshToken);
            when(mongoTokenStoreRepo.readAuthenticationForRefreshToken(refreshToken)).thenReturn(authentication);
            when(mongoTokenStoreRepo.readAndRemoveRefreshToken(token)).thenReturn(refreshTokenLog);

            // call
            tokenEndpointsServices.revokeToken(token, tokenType, clientId);
        });

        // test
        assertEquals("Invalid refresh token: " + token, thrown.getMessage());
    }

    /**
     * Should revoke access token when given access token is valid.
     */
    @Test
    void shouldRevokeAccessTokenWhenGivenAccessTokenIsValid() {

        // preconditions
        final String tokenType = OAuthTokenTypes.ACCESS_TOKEN.name();
        final OAuth2Authentication authentication = accessToken.getAuthentication();
        when(mongoTokenStoreRepo.readAccessToken(token)).thenReturn(accessToken);
        when(mongoTokenStoreRepo.readAuthentication(token)).thenReturn(authentication);
        when(tokenServices.revokeToken(anyString())).thenReturn(true);

        // call
        final boolean revokeToken = tokenEndpointsServices.revokeToken(token, tokenType, clientId);

        // test
        assertTrue(revokeToken);
    }

    /**
     * Should throw invalid token exception when failed to remove access token
     * from DB.
     */
    @Test
    void shouldThrowInvalidTokenExceptionWhenFailedToRemoveAccessTokenFromDB() {

        final InvalidTokenException thrown = assertThrows(InvalidTokenException.class, () -> {
            // preconditions
            final String tokenType = OAuthTokenTypes.ACCESS_TOKEN.name();
            final OAuth2Authentication authentication = accessToken.getAuthentication();
            when(mongoTokenStoreRepo.readAccessToken(token)).thenReturn(accessToken);
            when(mongoTokenStoreRepo.readAuthentication(token)).thenReturn(authentication);
            final boolean defaultTokenServicesReturnValueOnRevokeToken = false; // <--
                                                                                // Exception
                                                                                // thrown
                                                                                // due
                                                                                // to
                                                                                // this
            when(tokenServices.revokeToken(token)).thenReturn(defaultTokenServicesReturnValueOnRevokeToken);

            // call
            tokenEndpointsServices.revokeToken(token, tokenType, clientId);
        });

        // test
        assertEquals("Invalid access token: " + token, thrown.getMessage());
    }

    /**
     * Should throw invalid client exception when one client tries to revoke
     * other clients access token.
     */
    @Test
    void shouldThrowInvalidClientExceptionWhenOneClientTriesToRevokeOtherClientsAccessToken() {

        final InvalidClientException thrown = assertThrows(InvalidClientException.class, () -> {
            // preconditions
            final String tokenType = OAuthTokenTypes.REFRESH_TOKEN.name();
            final String clientIdDifferentFromRequestedClient = "someOtherClientId"; // <--
                                                                                     // Exception
                                                                                     // thrown
                                                                                     // due
                                                                                     // to
                                                                                     // this
            final OAuth2Authentication authentication = refreshToken.getAuthentication();
            when(mongoTokenStoreRepo.readRefreshToken(token)).thenReturn(refreshToken);
            when(mongoTokenStoreRepo.readAuthenticationForRefreshToken(refreshToken)).thenReturn(authentication);

            // call
            tokenEndpointsServices.revokeToken(token, tokenType, clientIdDifferentFromRequestedClient);
        });

        // test
        assertEquals("Given client ID does not match with the token client", thrown.getMessage());
    }

    /**
     * Should throw invalid client exception when one client tries to revoke
     * other clients refresh token.
     */
    @Test
    void shouldThrowInvalidClientExceptionWhenOneClientTriesToRevokeOtherClientsRefreshToken() {

        final InvalidClientException thrown = assertThrows(InvalidClientException.class, () -> {
            // preconditions
            final String tokenType = OAuthTokenTypes.ACCESS_TOKEN.name();
            final String clientIdDifferentFromRequestedClient = "someOtherClientId"; // <--
                                                                                     // Exception
                                                                                     // thrown
                                                                                     // due
                                                                                     // to
                                                                                     // this
            final OAuth2Authentication authentication = accessToken.getAuthentication();
            when(mongoTokenStoreRepo.readAccessToken(token)).thenReturn(accessToken);
            when(mongoTokenStoreRepo.readAuthentication(token)).thenReturn(authentication);

            // call
            tokenEndpointsServices.revokeToken(token, tokenType, clientIdDifferentFromRequestedClient);
        });

        // test
        assertEquals("Given client ID does not match with the token client", thrown.getMessage());
    }

}
