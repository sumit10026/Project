package com.uniken.authserver.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.http.auth.BasicUserPrincipal;
import org.bson.BsonValue;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.data.web.PageableHandlerMethodArgumentResolver;
import org.springframework.data.web.config.EnableSpringDataWebSupport;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.mongodb.client.result.UpdateResult;
import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.domains.RegAuthFactorRequest;
import com.uniken.authserver.domains.ValidatedBrowserRequest;
import com.uniken.authserver.repo.impl.UserAuthInfoRepoImpl;
import com.uniken.authserver.services.api.OAuth2ClientDetailsService;
import com.uniken.authserver.services.api.UserService;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.auth.fido.FIDO2RegisteredAuthenticationModule;
import com.uniken.domains.enums.WebUserStatus;
import com.uniken.domains.relid.user.UserAuthInfo;
import com.uniken.domains.relid.user.UserBrowser;
import com.uniken.domains.relid.user.WebUserBrowserDetailsDTO;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
@EnableSpringDataWebSupport
class UserPortalControllerTest {

    UserAuthInfoRepoImpl userAuthInfoRepoImpl;

    private MockMvc standaloneMockMvc;
    private MockHttpSession mockSession;

    @InjectMocks
    UserPortalController userPortalController;

    @Autowired
    ApplicationContext applicationContext;

    UserService userService;

    OAuth2ClientDetailsService oAuth2ClientDetailsService;

    UpdateResult updateResult;

    @BeforeEach
    public void setup() throws Exception {
        MockitoAnnotations.openMocks(this);

        userService = mock(UserService.class);
        oAuth2ClientDetailsService = mock(OAuth2ClientDetailsService.class);

        MockitoAnnotations.initMocks(this);
        standaloneMockMvc = MockMvcBuilders.standaloneSetup(userPortalController)
                .setCustomArgumentResolvers(new PageableHandlerMethodArgumentResolver()).build();
        mockSession = new MockHttpSession();
        mockSession.setAttribute(EnterpriseInfo.CLIENT_ID, "YWJkNDY3MDctZjMxOC00MDM5LTk0NjctMDdmMzE4ZjAzOTEy");

        updateResult = new UpdateResult() {

            @Override
            public boolean wasAcknowledged() {
                return false;
            }

            @Override
            public BsonValue getUpsertedId() {
                return null;
            }

            @Override
            public long getModifiedCount() {
                return 1;
            }

            @Override
            public long getMatchedCount() {
                return 1;
            }
        };
    }

    @Test
    void testNoAuthRegisteredAuthFactorPage() throws Exception {
        this.standaloneMockMvc
                .perform(get(Constants.REG_AUTH_FACTOR_PAGE).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .session(mockSession))
                .andExpect(status().isOk()).andExpect(view().name("authFactorManagement"))
                .andExpect(model().attributeDoesNotExist("username"));
    }

    @Test
    void testValidAuthRegisteredAuthFactorPage() throws Exception {
        final String loginId = "testUser";
        final Principal principal = new BasicUserPrincipal(loginId);

        this.standaloneMockMvc
                .perform(get(Constants.REG_AUTH_FACTOR_PAGE).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .principal(principal).session(mockSession))
                .andExpect(status().isOk()).andExpect(view().name("authFactorManagement"))
                .andExpect(model().attributeExists("username"));
    }

    @Test
    void testNoAuthForGetRegAuthFactorForUserAPI() throws Exception {
        final MvcResult result = this.standaloneMockMvc
                .perform(get(Constants.GET_REG_AUTH_FACTOR_FOR_USER).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .accept(MediaType.APPLICATION_JSON).session(mockSession))
                .andExpect(status().is(HttpStatus.OK.value())).andReturn();

        final String response = result.getResponse().getContentAsString();
        assertEquals("[]", response);
    }

    @Test
    void testValidForGetRegAuthFactorForUserAPI() throws Exception {
        final String loginId = "testUser";

        final Principal principal = new BasicUserPrincipal(loginId);

        final List<FIDO2RegisteredAuthenticationModule> moduleList = new ArrayList<>();
        moduleList.add(mock(FIDO2RegisteredAuthenticationModule.class));
        moduleList.add(mock(FIDO2RegisteredAuthenticationModule.class));

        when(userService.fetchRegisteredAuthenticationModuleFromLoginId("testUser")).thenReturn(moduleList);

        final MvcResult result = this.standaloneMockMvc
                .perform(get(Constants.GET_REG_AUTH_FACTOR_FOR_USER).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .accept(MediaType.APPLICATION_JSON).session(mockSession).principal(principal))
                .andExpect(status().is(HttpStatus.OK.value())).andReturn();

        final String response = result.getResponse().getContentAsString();
        assertEquals(2, Utils.mapStringToObject(response, ArrayList.class).size());
    }

    @Test
    void testNoAuthForDeleteRegAuthFactorForUserAPI() throws Exception {
        final MvcResult result = this.standaloneMockMvc
                .perform(post(Constants.DELETE_REG_AUTH_FACTOR_FOR_USER).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
                        .content(Constants.JACKSON_OBJECT_MAPPER.writeValueAsString(new RegAuthFactorRequest()))
                        .session(mockSession))
                .andExpect(status().is(HttpStatus.PRECONDITION_FAILED.value())).andReturn();

        final String response = result.getResponse().getContentAsString();
        assertEquals("Failed to Delete Auth Factor", response);
    }

    @Test
    void testValidAuthForDeleteRegAuthFactorForUserAPI() throws Exception {
        final String loginId = "testUser";
        final Principal principal = new BasicUserPrincipal(loginId);
        final RegAuthFactorRequest regAuthFactorRequest = new RegAuthFactorRequest();
        regAuthFactorRequest.setRegAuthTypeId("REG_AUTH_ID");

        when(userService.deleteRegisteredAuthModule(Mockito.anyString(), Mockito.anyString())).thenReturn(true);

        final MvcResult result = this.standaloneMockMvc
                .perform(post(Constants.DELETE_REG_AUTH_FACTOR_FOR_USER).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON)
                        .content(Constants.JACKSON_OBJECT_MAPPER.writeValueAsString(regAuthFactorRequest))
                        .session(mockSession).principal(principal))
                .andExpect(status().is(HttpStatus.OK.value())).andReturn();

        final String response = result.getResponse().getContentAsString();
        assertEquals("Auth Factor Deleted Successfully", response);
    }

    @Test
    void testNoAuthForUpdateStatusRegAuthFactorForUserAPI() throws Exception {
        final MvcResult result = this.standaloneMockMvc
                .perform(post(Constants.UPDATE_STATUS_REG_AUTH_FACTOR_FOR_USER)
                        .contextPath(Constants.AUTH_SERVER_CONTEXT_URL).accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(Constants.JACKSON_OBJECT_MAPPER.writeValueAsString(new RegAuthFactorRequest()))
                        .session(mockSession))
                .andExpect(status().is(HttpStatus.PRECONDITION_FAILED.value())).andReturn();

        final String response = result.getResponse().getContentAsString();
        assertEquals("Failed to Change Auth Factor State", response);
    }

    @Test
    void testValidAuthForUpdateStatusRegAuthFactorForUserAPI() throws Exception {
        final String loginId = "testUser";
        final Principal principal = new BasicUserPrincipal(loginId);
        final RegAuthFactorRequest regAuthFactorRequest = new RegAuthFactorRequest();
        regAuthFactorRequest.setRegAuthTypeId("REG_AUTH_ID");
        regAuthFactorRequest.setEnabledState(false);

        when(userService.updateRegAuthFactorStatus(Mockito.anyString(), Mockito.anyString(), Mockito.anyBoolean()))
                .thenReturn(true);

        final MvcResult result = this.standaloneMockMvc
                .perform(post(Constants.UPDATE_STATUS_REG_AUTH_FACTOR_FOR_USER)
                        .contextPath(Constants.AUTH_SERVER_CONTEXT_URL).accept(MediaType.APPLICATION_JSON)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(Constants.JACKSON_OBJECT_MAPPER.writeValueAsString(regAuthFactorRequest))
                        .session(mockSession).principal(principal))
                .andExpect(status().is(HttpStatus.OK.value())).andReturn();

        final String response = result.getResponse().getContentAsString();
        assertEquals("Auth Factor State Changed Successfully", response);
    }

    @Test
    void testNoAuthBrowserManagementPage() throws Exception {
        this.standaloneMockMvc
                .perform(get(Constants.BROWSER_MANAGEMENT_PAGE).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .session(mockSession))
                .andExpect(status().isOk()).andExpect(view().name("browser_management"))
                .andExpect(model().attributeDoesNotExist("username"));
    }

    @Test
    void testValidAuthBrowserManagementPage() throws Exception {
        final String loginId = "testUser";
        final Principal principal = new BasicUserPrincipal(loginId);

        this.standaloneMockMvc
                .perform(get(Constants.BROWSER_MANAGEMENT_PAGE).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .principal(principal).session(mockSession))
                .andExpect(status().isOk()).andExpect(view().name("browser_management"))
                .andExpect(model().attributeExists("username"));
    }

    @Test
    void testNoAuthGetBrowserManagementList() throws Exception {
        this.standaloneMockMvc
                .perform(get(Constants.GET_BROWSER_MANAGEMENT_LIST).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .session(mockSession))
                .andExpect(status().isOk())
                .andExpect(view().name("fragments/browser_list_fragment :: browser_list_fragment"))
                .andExpect(model().attributeDoesNotExist("username"))
                .andExpect(model().attributeDoesNotExist("browsers"));
    }

    @Test
    void testValidAuthGetBrowserManagementList() throws Exception {
        final String loginId = "testUser";
        final Principal principal = new BasicUserPrincipal(loginId);
        when(userService.getBrowsers(Mockito.anyString())).thenReturn(new ArrayList<WebUserBrowserDetailsDTO>());

        this.standaloneMockMvc
                .perform(get(Constants.GET_BROWSER_MANAGEMENT_LIST).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .principal(principal).session(mockSession))
                .andExpect(status().isOk())
                .andExpect(view().name("fragments/browser_list_fragment :: browser_list_fragment"))
                .andExpect(model().attributeExists("username")).andExpect(model().attributeExists("browsers"));
    }

    @Test
    void testUpdateWebUserBrowerStatusForInvalidLoginId() throws Exception {
        final String loginId = "testUser";

        final MvcResult result = this.standaloneMockMvc.perform(post(Constants.UPDATE_WEB_USER_BROWSER_STATUS, loginId)
                .contextPath(Constants.AUTH_SERVER_CONTEXT_URL).session(mockSession)
                .param(UserAuthInfo.LOGIN_ID_STR, "").param(UserBrowser.WEB_DEVICE_UUID_STR, loginId)
                .param(UserBrowser.STATUS, WebUserStatus.ACTIVE.name())).andExpect(status().isOk()).andReturn();
        final String response = result.getResponse().getContentAsString();
        assertEquals("", response);
    }

    @Test
    void testUpdateWebUserBrowerStatusForInvalidWebDeviceUUID() throws Exception {
        final String loginId = "testUser";

        final MvcResult result = this.standaloneMockMvc.perform(post(Constants.UPDATE_WEB_USER_BROWSER_STATUS, loginId)
                .contextPath(Constants.AUTH_SERVER_CONTEXT_URL).session(mockSession)
                .param(UserAuthInfo.LOGIN_ID_STR, loginId).param(UserBrowser.WEB_DEVICE_UUID_STR, "")
                .param(UserBrowser.STATUS, WebUserStatus.ACTIVE.name())).andExpect(status().isOk()).andReturn();
        final String response = result.getResponse().getContentAsString();
        assertEquals("", response);
    }

    @Test
    void testUpdateWebUserBrowerStatusForInvalidWebUserStatus() throws Exception {
        final String loginId = "testUser";

        final MvcResult result = this.standaloneMockMvc.perform(
                post(Constants.UPDATE_WEB_USER_BROWSER_STATUS, loginId).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .session(mockSession).param(UserAuthInfo.LOGIN_ID_STR, loginId)
                        .param(UserBrowser.WEB_DEVICE_UUID_STR, loginId).param(UserBrowser.STATUS, ""))
                .andExpect(status().isOk()).andReturn();
        final String response = result.getResponse().getContentAsString();
        assertEquals("", response);
    }

    @Test
    void testUpdateWebUserBrowerStatus() throws Exception {
        final String loginId = "testUser";
        final Principal principal = new BasicUserPrincipal(loginId);

        when(userService.updateWebUserBrowserStatus(loginId, loginId, WebUserStatus.ACTIVE)).thenReturn(updateResult);

        final MvcResult result = this.standaloneMockMvc.perform(post(Constants.UPDATE_WEB_USER_BROWSER_STATUS, loginId)
                .contextPath(Constants.AUTH_SERVER_CONTEXT_URL).principal(principal).session(mockSession)
                .param(UserAuthInfo.LOGIN_ID_STR, loginId).param(UserBrowser.WEB_DEVICE_UUID_STR, loginId)
                .param(UserBrowser.STATUS, WebUserStatus.ACTIVE.name())).andExpect(status().isOk()).andReturn();
        final String response = result.getResponse().getContentAsString();
        assertEquals(1, Utils.mapStringToObject(response, HashMap.class).get("modifiedCount"));
    }

    @Test
    void testUnrememberWebUserBrowerForInvalidLoginId() throws Exception {
        final String loginId = "testUser";

        final MvcResult result = this.standaloneMockMvc.perform(post(Constants.UNREMEBER_WEB_USER_BROWSER)
                .contextPath(Constants.AUTH_SERVER_CONTEXT_URL).session(mockSession)
                .param(UserAuthInfo.LOGIN_ID_STR, "").param(UserBrowser.WEB_DEVICE_UUID_STR, loginId))
                .andExpect(status().isOk()).andReturn();
        final String response = result.getResponse().getContentAsString();
        assertEquals("", response);
    }

    @Test
    void testUnrememberWebUserBrowerForInvalidWebDeviceUUID() throws Exception {
        final String loginId = "testUser";

        final MvcResult result = this.standaloneMockMvc.perform(post(Constants.UNREMEBER_WEB_USER_BROWSER)
                .contextPath(Constants.AUTH_SERVER_CONTEXT_URL).session(mockSession)
                .param(UserAuthInfo.LOGIN_ID_STR, "").param(UserBrowser.WEB_DEVICE_UUID_STR, loginId))
                .andExpect(status().isOk()).andReturn();
        final String response = result.getResponse().getContentAsString();
        assertEquals("", response);
    }

    @Test
    void testUnrememberWebUserBrower() throws Exception {
        final String loginId = "testUser";
        final Principal principal = new BasicUserPrincipal(loginId);

        when(userService.unRememberWebUserBrowser(Mockito.anyString(), Mockito.anyString())).thenReturn(updateResult);

        final MvcResult result = this.standaloneMockMvc.perform(post(Constants.UNREMEBER_WEB_USER_BROWSER)
                .contextPath(Constants.AUTH_SERVER_CONTEXT_URL).principal(principal).session(mockSession)
                .param(UserAuthInfo.LOGIN_ID_STR, loginId).param(UserBrowser.WEB_DEVICE_UUID_STR, loginId))
                .andExpect(status().isOk()).andReturn();
        final String response = result.getResponse().getContentAsString();
        assertEquals(1, Utils.mapStringToObject(response, HashMap.class).get("modifiedCount"));
    }

    @Test
    void testDeleteWebUserBrowerForInvalidLoginId() throws Exception {
        final ValidatedBrowserRequest validatedBrowserRequest = new ValidatedBrowserRequest();
        validatedBrowserRequest.setLoginId("");
        validatedBrowserRequest.setWebDeviceUuid("WEB_UUID");

        final MvcResult result = this.standaloneMockMvc
                .perform(post(Constants.DELETE_WEB_USER_BROWSER).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .session(mockSession).contentType(MediaType.APPLICATION_JSON)
                        .content(Constants.JACKSON_OBJECT_MAPPER.writeValueAsString(validatedBrowserRequest)))
                .andExpect(status().isBadRequest()).andReturn();
        final String response = result.getResponse().getContentAsString();
        assertEquals("", response);
    }

    @Test
    void testDeleteWebUserBrowerForInvalidWebDeviceUUID() throws Exception {
        final ValidatedBrowserRequest validatedBrowserRequest = new ValidatedBrowserRequest();
        validatedBrowserRequest.setLoginId("testUser");
        validatedBrowserRequest.setWebDeviceUuid("");

        final MvcResult result = this.standaloneMockMvc
                .perform(post(Constants.DELETE_WEB_USER_BROWSER).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .session(mockSession).contentType(MediaType.APPLICATION_JSON)
                        .content(Constants.JACKSON_OBJECT_MAPPER.writeValueAsString(validatedBrowserRequest)))
                .andExpect(status().isBadRequest()).andReturn();
        final String response = result.getResponse().getContentAsString();
        assertEquals("", response);
    }

    @Test
    void testDeleteWebUserBrower() throws Exception {
        final String loginId = "testUser";
        final ValidatedBrowserRequest validatedBrowserRequest = new ValidatedBrowserRequest();
        validatedBrowserRequest.setLoginId(loginId);
        validatedBrowserRequest.setWebDeviceUuid("WEB_UUID");

        when(userService.deleteWebUserBrowser(Mockito.anyString(), Mockito.anyString())).thenReturn(updateResult);

        final MvcResult result = this.standaloneMockMvc
                .perform(post(Constants.DELETE_WEB_USER_BROWSER).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .session(mockSession).contentType(MediaType.APPLICATION_JSON)
                        .content(Constants.JACKSON_OBJECT_MAPPER.writeValueAsString(validatedBrowserRequest)))
                .andExpect(status().isOk()).andReturn();
        final String response = result.getResponse().getContentAsString();
        assertEquals(1, Utils.mapStringToObject(response, HashMap.class).get("modifiedCount"));
    }

}
