package com.uniken.authserver.controller;

import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.google.api.client.util.Lists;
import com.uniken.authserver.MockMvcBase;
import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.domains.Configuration;
import com.uniken.authserver.domains.ConfigurationResponse;
import com.uniken.authserver.services.impl.ConfigurationServiceImpl;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.EnterpriseInfo;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
class ConfigurationControllerTest extends MockMvcBase {

    @InjectMocks
    ConfigurationController configurationController;

    @Mock
    ConfigurationServiceImpl configurationServiceImpl;

    private MockMvc standaloneMockMvc;
    private MockHttpSession mockSession;
    private Configuration configuration;
    private ConfigurationResponse configurationResponse;
    MockHttpServletRequest request;
    String webDeviceParameterChecksum;

    @BeforeEach
    public void setup() {
        standaloneMockMvc = MockMvcBuilders.standaloneSetup(configurationController).build();
        mockSession = new MockHttpSession();
        mockSession.setAttribute(EnterpriseInfo.CLIENT_ID, "dummyClientId");

        configuration = Utils.mapStringToObject("\"rememberMe\":\"true\"}", Configuration.class);
        configurationResponse = new ConfigurationResponse(configuration, Lists.newArrayList());
        request = new MockHttpServletRequest();
        webDeviceParameterChecksum = "checksum";
    }

    @Test
    void testValidConfigurationAPI() throws Exception {
        this.standaloneMockMvc.perform(post(Constants.GET_CONFIGURATION_REQ)
                .contextPath(Constants.AUTH_SERVER_CONTEXT_URL).accept("*/*").contentType(MediaType.APPLICATION_JSON)
                .content(
                        "{\"web_device_parameter_checksum\":\"cs\",\"web_device_parameters\": {\"userAgent\": \"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36\", \"webdriver\": false, \"language\": \"en-US\", \"colorDepth\": 24}}")
                .session(mockSession)).andExpect(status().is(HttpStatus.OK.value())).andReturn();
    }

    @Test
    void testInvalidConfigurationAPI() throws Exception {
        this.standaloneMockMvc
                .perform(post(Constants.GET_CONFIGURATION_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .accept(MediaType.APPLICATION_JSON).session(mockSession))
                .andExpect(status().is(HttpStatus.BAD_REQUEST.value())).andReturn();
    }

    @Test
    void testFetchedConfiguration() throws Exception {
        when(configurationServiceImpl.getConfigurations(request, webDeviceParameterChecksum))
                .thenReturn(configurationResponse);

        final MvcResult result = this.standaloneMockMvc.perform(post(Constants.GET_CONFIGURATION_REQ)
                .contextPath(Constants.AUTH_SERVER_CONTEXT_URL).accept("*/*").contentType(MediaType.APPLICATION_JSON)
                .content(
                        "{\"web_device_parameter_checksum\":\"cs\",\"web_device_parameters\": {\"userAgent\": \"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/92.0.4515.131 Safari/537.36\", \"webdriver\": false, \"language\": \"en-US\", \"colorDepth\": 24}}")
                .session(mockSession)).andExpect(status().is(HttpStatus.OK.value())).andReturn();

        final String response = result.getResponse().getContentAsString();
        assertTrue(response.contains("\"rememberMe\":true"));
    }

}
