package com.uniken.authserver.controller;

import static capital.scalable.restdocs.SnippetRegistry.AUTO_REQUEST_FIELDS;
import static capital.scalable.restdocs.SnippetRegistry.AUTO_REQUEST_HEADERS;
import static capital.scalable.restdocs.SnippetRegistry.AUTO_REQUEST_PARAMETERS;
import static capital.scalable.restdocs.SnippetRegistry.CURL_REQUEST;
import static capital.scalable.restdocs.SnippetRegistry.HTTP_RESPONSE;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;

import com.uniken.authserver.MockMvcBase;
import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.utility.Constants;

@SpringBootTest
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
class JwksControllerTest extends MockMvcBase {

    @BeforeAll
    static void setUpBeforeClass() throws Exception {
    }

    @AfterAll
    static void tearDownAfterClass() throws Exception {
    }

    @BeforeEach
    void setUp() throws Exception {
    }

    @AfterEach
    void tearDown() throws Exception {
    }

    @Test
    final void testJwksApi() throws Exception {
        // call
        this.mockMvc
                .perform(get(Constants.JWKS_URI)
                        .contextPath(Constants.AUTH_SERVER_CONTEXT_URL).accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk()).andDo(
                        commonDocumentation(customSectionBuilder()
                                .sectionTitle("JWKS (JSON Web Key Set) Endpoint").snippetNames(AUTO_REQUEST_HEADERS,
                                        AUTO_REQUEST_FIELDS, AUTO_REQUEST_PARAMETERS, CURL_REQUEST, HTTP_RESPONSE)
                                .build()));

    }

}
