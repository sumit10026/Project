package com.uniken.authserver.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.springframework.restdocs.headers.HeaderDocumentation.headerWithName;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ApplicationContext;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.restdocs.headers.HeaderDescriptor;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import com.uniken.authserver.MockMvcBase;
import com.uniken.authserver.config.EmbeddedMongoInitExtension;
import com.uniken.authserver.domains.GenericResponse;
import com.uniken.authserver.domains.ValidateUserRequest;
import com.uniken.authserver.services.api.UserService;
import com.uniken.authserver.services.impl.GenerateRVNMessageServiceImpl;
import com.uniken.authserver.services.impl.UserServiceImpl;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.relid.notification.NotificationUserActionResponse;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
@ExtendWith(EmbeddedMongoInitExtension.class)
class UserControllerTest extends MockMvcBase {

    @Autowired
    ApplicationContext applicationContext;

    @InjectMocks
    UserController userController;

    @Mock
    private GenerateRVNMessageServiceImpl generateRVNMessageServiceImpl;

    @Mock
    private UserServiceImpl userService;

    @Mock
    private UserService userServiceImpl;

    @Mock
    private OAuth2Authentication oAuthAuthentication;

    @Mock
    private DefaultTokenServices defaultTokenServices;

    @Mock
    private Authentication authentication;

    private MockMvc standaloneMockMvc;
    private MockHttpSession mockSession;
    private final MultiValueMap<String, String> params = new LinkedMultiValueMap<>();

    @BeforeEach
    public void setup() {
        // preconditions

        final String testWebDeviceParams = "{"
                + "\"userAgent\": \"Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:71.0) Gecko/20100101 Firefox/71.0\","
                + "\"webdriver\": \"false\"," + "\"language\": \"en-US\"," + "\"colorDepth\": \"24\","
                + "\"deviceMemory\": \"not available\"" + "}";
        final String testUserLocation = "{\"latitude\" : \"1232312312\", \"longitude\" : \"asdasdasds \"  }";

        params.add("username", "akash1");
        params.add("scope", "all");
        params.add("user_location", testUserLocation);
        params.add("web_device_parameters", testWebDeviceParams);
        params.add("web_device_parameter_checksum", "asddvashvd");

        MockitoAnnotations.initMocks(this);
        standaloneMockMvc = MockMvcBuilders.standaloneSetup(userController).build();
        mockSession = new MockHttpSession();
        mockSession.setAttribute(EnterpriseInfo.CLIENT_ID, "YWJkNDY3MDctZjMxOC00MDM5LTk0NjctMDdmMzE4ZjAzOTEy");
        // Constants.getVerifyNotificationResponseMap().put("111111",
        // Mockito.any());
    }

    final HeaderDescriptor[] headerDescriptor;
    final HttpHeaders httpHeaders;

    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    HttpServletResponse response = Mockito.mock(HttpServletResponse.class);

    {
        headerDescriptor = new HeaderDescriptor[] {
                headerWithName(HttpHeaders.CONTENT_TYPE).description(MediaType.APPLICATION_JSON_VALUE),
                headerWithName(HttpHeaders.ACCEPT).description(MediaType.APPLICATION_JSON_VALUE) };

        httpHeaders = new HttpHeaders();
        httpHeaders.add("Content-Type", MediaType.APPLICATION_JSON_VALUE);
    }

    private void setFixedHeader(final HttpServletResponse response) {
        response.setHeader("Cache-Control", "no-store");
        response.setHeader("Pragma", "no-cache");
        response.setHeader("Content-Type", "application/json;charset=UTF-8");
        response.setHeader("X-FRAME-OPTIONS", "DENY");
    }

    @Test
    @Order(1)
    void testSuccessValidateUserAPI() throws Exception {

        final HttpServletResponse response = Mockito.isA(HttpServletResponse.class);
        setFixedHeader(response);
        when(generateRVNMessageServiceImpl.processGenerateRVNRequest(Mockito.isA(HttpServletRequest.class), response,
                Mockito.anyMap())).thenReturn(true);

        this.standaloneMockMvc
                .perform(post(Constants.VALIDATE_USER_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .accept(MediaType.APPLICATION_JSON).params(params).session(mockSession))
                .andExpect(status().is(HttpStatus.OK.value())).andReturn();
    }

    @Test
    void testValidateUserBasedOnAuthTypeAPI() throws Exception {
        // final Set<String> authTypes = new HashSet<>();

        final ValidateUserRequest validateUserRequest = new ValidateUserRequest();

        validateUserRequest.setWebDeviceParameters(params.getFirst("web_device_parameters"));
        validateUserRequest.setUserName("o2");

        final Set<String> authTypes = new HashSet<>();

        authTypes.add(com.uniken.domains.enums.auth.AuthType.TOTP.getName());

        when(userServiceImpl.getUserAuthFactorsBasedOnUserValidity(Mockito.any(), Mockito.any(), Mockito.any()))
                .thenReturn(authTypes);

        this.standaloneMockMvc.perform(post(Constants.VALIDATE_USER_BASED_ON_AUTH_TYPE_REQ)
                .contextPath(Constants.AUTH_SERVER_CONTEXT_URL).accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(Constants.JACKSON_OBJECT_MAPPER.writeValueAsString(validateUserRequest)).session(mockSession))
                .andExpect(status().is(HttpStatus.ACCEPTED.value())).andReturn();
    }

    @Test
    void testValidateUserBasedOnAuthTypeAPIforNULLValidateUserRequest() throws Exception {
        // final Set<String> authTypes = new HashSet<>();

        final ValidateUserRequest validateUserRequest = new ValidateUserRequest();

        // validateUserRequest.setWebDeviceParameters(params.getFirst("web_device_parameters"));
        // validateUserRequest.setUserName("o2");

        final Set<String> authTypes = new HashSet<>();

        authTypes.add(com.uniken.domains.enums.auth.AuthType.TOTP.getName());

        // when(userServiceImpl.getUserAuthFactorsBasedOnUserValidity(Mockito.any(),
        // Mockito.any(), Mockito.any()))
        // .thenReturn(authTypes);

        this.standaloneMockMvc.perform(post(Constants.VALIDATE_USER_BASED_ON_AUTH_TYPE_REQ)
                .contextPath(Constants.AUTH_SERVER_CONTEXT_URL).accept(MediaType.APPLICATION_JSON)
                .contentType(MediaType.APPLICATION_JSON)
                .content(Constants.JACKSON_OBJECT_MAPPER.writeValueAsString(validateUserRequest)).session(mockSession))
                .andExpect(status().is(HttpStatus.BAD_REQUEST.value())).andReturn();
    }

    @Test
    void testInvalidHttpRequestMethod_ValidateUser() throws Exception {

        this.mockMvc
                .perform(get(Constants.VALIDATE_USER_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .accept(MediaType.APPLICATION_JSON).params(params))
                .andExpect(status().is(HttpStatus.METHOD_NOT_ALLOWED.value())).andReturn();

    }

    @Test
    void testNullInputParamUserName_validateUser() throws Exception {
        params.remove("username");
        params.add("username", null);

        this.mockMvc
                .perform(post(Constants.VALIDATE_USER_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL).params(params)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().is(HttpStatus.BAD_REQUEST.value())).andReturn();

    }

    @Test
    void testNullOrEmptyClientIDInSession() throws Exception {

        this.mockMvc
                .perform(post(Constants.VALIDATE_USER_REQ).contextPath(Constants.AUTH_SERVER_CONTEXT_URL).params(params)
                        .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().is(HttpStatus.UNAUTHORIZED.value())).andReturn();

    }

    @Test
    @Order(2)
    void test200_Acted_GetUserValidatedStatus() throws Exception {

        mockSession.setAttribute("username", "akash1");
        mockSession.setAttribute("correlationID", "111111");

        Constants.getVerifyNotificationResponseMap().put("111111", new NotificationUserActionResponse());

        when(userService.checkIfNotificationIsActed(Mockito.anyString())).thenReturn(HttpStatus.OK);

        this.standaloneMockMvc
                .perform(get(Constants.IS_USER_REQ_AUTHENTICATED).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .accept(MediaType.APPLICATION_JSON).session(mockSession))
                .andExpect(status().is(HttpStatus.OK.value())).andReturn();
    }

    @Test
    void test202_NotActed_GetUserAuthenticatedStatus() throws Exception {

        mockSession.setAttribute("username", "akash1");
        mockSession.setAttribute("correlationID", "111111");

        Constants.getVerifyNotificationResponseMap().put("111111", new NotificationUserActionResponse());

        when(userService.checkIfNotificationIsActed(Mockito.anyString())).thenReturn(HttpStatus.ACCEPTED);

        this.standaloneMockMvc
                .perform(get(Constants.IS_USER_REQ_AUTHENTICATED).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .accept(MediaType.APPLICATION_JSON).session(mockSession))
                .andExpect(status().is(HttpStatus.ACCEPTED.value())).andReturn();
    }

    @Test
    void testEmptyAuthHeader() throws Exception {
        this.mockMvc
                .perform(get(Constants.USER_INFO_REQ).accept(MediaType.APPLICATION_PROBLEM_JSON_UTF8)
                        .header(Constants.AUTH_HEADER, "").contextPath(Constants.AUTH_SERVER_CONTEXT_URL))
                .andExpect(status().isBadRequest()).andReturn();

    }

    @Test
    void testInvalidAuthHeader_validTokenTypeButEmptyToken() throws Exception {

        this.mockMvc.perform(get(Constants.USER_INFO_REQ).accept(MediaType.APPLICATION_PROBLEM_JSON_UTF8)
                .header(Constants.AUTH_HEADER, Constants.AUTH_HEADER_BEARER)
                .contextPath(Constants.AUTH_SERVER_CONTEXT_URL)).andExpect(status().isBadRequest()).andReturn();

    }

    @Test
    void testInvalidAuthHeader_nullTokenType() throws Exception {
        this.mockMvc
                .perform(get(Constants.USER_INFO_REQ).accept(MediaType.APPLICATION_PROBLEM_JSON_UTF8)
                        .header(Constants.AUTH_HEADER, "123456789").contextPath(Constants.AUTH_SERVER_CONTEXT_URL))
                .andExpect(status().isBadRequest()).andReturn();

    }

    @Test
    void testInvalidAuthHeader_invalidTokenType_2() throws Exception {
        this.mockMvc.perform(get(Constants.USER_INFO_REQ).accept(MediaType.APPLICATION_PROBLEM_JSON_UTF8)
                .header(Constants.AUTH_HEADER, "invalid " + 12345678).contextPath(Constants.AUTH_SERVER_CONTEXT_URL))
                .andExpect(status().isBadRequest()).andReturn();
    }

    @Test
    void testSuccess_getUserInfo() throws Exception {

        final List<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority("ROLE_USER"));

        oAuthAuthentication.setAuthenticated(true);
        when(defaultTokenServices.loadAuthentication(Mockito.anyString())).thenReturn(oAuthAuthentication);
        when(oAuthAuthentication.getName()).thenReturn("a1");
        when(userService.getUserInfo(Mockito.anyString())).thenReturn(Mockito.anyObject());

        this.standaloneMockMvc.perform(get(Constants.USER_INFO_REQ).accept(MediaType.APPLICATION_PROBLEM_JSON_UTF8)
                .header(Constants.AUTH_HEADER, "bearer " + 12345678).contextPath(Constants.AUTH_SERVER_CONTEXT_URL))
                .andExpect(status().isOk()).andReturn();
    }

    @Test
    void testDeleteAccountForNullUser() throws Exception {
        final ValidateUserRequest validateUserRequest = new ValidateUserRequest();
        validateUserRequest.setUserName(null);

        final MvcResult result = this.standaloneMockMvc
                .perform(post(Constants.DELETE_ACCOUNT).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .session(mockSession).contentType(MediaType.APPLICATION_JSON)
                        .content(Constants.JACKSON_OBJECT_MAPPER.writeValueAsString(validateUserRequest)))
                .andExpect(status().isBadRequest()).andReturn();
        final String response = result.getResponse().getContentAsString();
        assertEquals("", response);
    }

    @Test
    void testDeleteAccountForEmptyUser() throws Exception {
        final ValidateUserRequest validateUserRequest = new ValidateUserRequest();
        validateUserRequest.setUserName("");

        final MvcResult result = this.standaloneMockMvc
                .perform(post(Constants.DELETE_ACCOUNT).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .session(mockSession).contentType(MediaType.APPLICATION_JSON)
                        .content(Constants.JACKSON_OBJECT_MAPPER.writeValueAsString(validateUserRequest)))
                .andExpect(status().isBadRequest()).andReturn();
        final String response = result.getResponse().getContentAsString();
        assertEquals("", response);
    }

    @Test
    void testDeleteAccountForInvalidUser() throws Exception {
        final ValidateUserRequest validateUserRequest = new ValidateUserRequest();
        validateUserRequest.setUserName("testUser");
        validateUserRequest.setWebDeviceParameters(params.getFirst("web_device_parameters"));

        when(userServiceImpl.deleteBrowserMappingForUser(Mockito.any(), Mockito.any())).thenReturn(false);

        final MvcResult result = this.standaloneMockMvc
                .perform(post(Constants.DELETE_ACCOUNT).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .session(mockSession).contentType(MediaType.APPLICATION_JSON)
                        .content(Constants.JACKSON_OBJECT_MAPPER.writeValueAsString(validateUserRequest)))
                .andExpect(status().isPreconditionFailed()).andReturn();
        final GenericResponse response = Constants.JACKSON_OBJECT_MAPPER
                .readValue(result.getResponse().getContentAsString(), GenericResponse.class);
        assertEquals("Failed to remove user account", response.getError());
    }

    @Test
    void testDeleteAccountForValidUser() throws Exception {
        final ValidateUserRequest validateUserRequest = new ValidateUserRequest();
        validateUserRequest.setUserName("testUser");
        validateUserRequest.setWebDeviceParameters(params.getFirst("web_device_parameters"));

        when(userServiceImpl.deleteBrowserMappingForUser(Mockito.any(), Mockito.any())).thenReturn(true);

        final MvcResult result = this.standaloneMockMvc
                .perform(post(Constants.DELETE_ACCOUNT).contextPath(Constants.AUTH_SERVER_CONTEXT_URL)
                        .session(mockSession).contentType(MediaType.APPLICATION_JSON)
                        .content(Constants.JACKSON_OBJECT_MAPPER.writeValueAsString(validateUserRequest)))
                .andExpect(status().isOk()).andReturn();
        final GenericResponse response = Constants.JACKSON_OBJECT_MAPPER
                .readValue(result.getResponse().getContentAsString(), GenericResponse.class);
        assertEquals("User account removed successfully", response.getSuccess());
    }

}
