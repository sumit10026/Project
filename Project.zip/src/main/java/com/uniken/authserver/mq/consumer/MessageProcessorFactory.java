package com.uniken.authserver.mq.consumer;

/**
 * This super interface is used to locate service bean from receiving routing
 * key
 * 
 * @author Uday T
 */
public interface MessageProcessorFactory {

    /**
     * Method used to locate service based on routing key
     * 
     * @param routingKey
     * @return
     */
    public MessageProcessor getService(String routingKey);
}
