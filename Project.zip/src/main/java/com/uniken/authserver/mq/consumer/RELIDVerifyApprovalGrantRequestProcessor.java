package com.uniken.authserver.mq.consumer;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.apache.commons.codec.binary.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.stereotype.Service;

import com.uniken.authserver.domains.GenerateTokenDomain;
import com.uniken.authserver.mq.publisher.RelIdVerifyMessagePublisher;
import com.uniken.authserver.repo.api.OidcConfigRepo;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.repo.impl.EnterpriseRepoImpl;
import com.uniken.authserver.services.api.JwtService;
import com.uniken.authserver.services.impl.CustomUserDetailsService;
import com.uniken.authserver.services.impl.JwtServiceImpl;
import com.uniken.authserver.services.impl.OpenIdAccessTokenEnhancer;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.MQConstant;
import com.uniken.authserver.utility.RequestParams;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.EnterpriseInfo;

/**
 * Message processor when request from REL-ID Verify server lands on Auth Server
 * only upon successful approval to fetch an access token, this service is
 * invoked.
 * 
 * @author Uniken Inc.
 */

@Service(MQConstant.RELIDVERIFYSERVER_GENERATE_TOKEN_REQUEST_KEY)
public class RELIDVerifyApprovalGrantRequestProcessor
        implements
        MessageProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(RELIDVerifyApprovalGrantRequestProcessor.class);

    @Autowired
    private UserAuthInfoRepo userAuthInfoRepo;

    @Autowired
    private OidcConfigRepo oidcConfigRepo;

    @Autowired
    private RelIdVerifyMessagePublisher relidVerifyMessagePublisher;

    @Autowired
    private DefaultTokenServices tokenServices;

    @Autowired
    private CustomUserDetailsService customUserDetailsService;

    @Autowired
    private EnterpriseRepoImpl enterpriseInfoRepo;

    @Override
    public void handleMessage(final String correlationID, final String message, final String replyToRoutingKey,
            final Map<String, Object> mqHeaders) {

        LOG.info("handleMessage() -> correlationID:{}", correlationID);
        String encodedString = "";
        try {
            if (Utils.isNullOrEmpty(correlationID)) {
                LOG.error("Correlation ID is null or empty");
                throw new IllegalArgumentException("Correlation ID is null or empty");
            }

            if (Utils.isNullOrEmpty(message)) {
                LOG.error("RELIDVerifyApprovalGrantRequestProcessor message is null or empty");
                throw new IllegalArgumentException("RELIDVerifyApprovalGrantRequestProcessor message is null or empty");
            }

            final GenerateTokenDomain generateTokenDomain = Constants.GSON.fromJson(message, GenerateTokenDomain.class);

            final String userName = generateTokenDomain.getUserId();
            final String grantType = generateTokenDomain.getGrantType();
            final String enterpriseName = generateTokenDomain.getEnterpriseId();
            final Set<String> responseTypes = new HashSet<String>();
            responseTypes.add("form_post");

            final EnterpriseInfo enterpriseInfo = enterpriseInfoRepo.getEnterpriseByEnterpriseId(enterpriseName);
            final String clientId = enterpriseInfo.getClientId();
            LOG.info("userName :{}", userName);
            LOG.info("grantType :{}", grantType);
            LOG.info("enterpriseName :{}", enterpriseName);
            LOG.info("clientId :{}", clientId);

            final Map<String, String> map = new HashMap<String, String>();
            map.put("username", userName);
            map.put("grant_type", grantType);

            /**
             * set resourceIds as null, otherwise resourceIds will be used in
             * "aud" claim
             */

            if (enterpriseInfo == null) {
                LOG.error("EnterpriseInfo is null");
                throw new IllegalArgumentException("UnAuthorized Access");
            }
            final UserDetails user = customUserDetailsService.loadUserByUsername(userName);
            final UsernamePasswordAuthenticationToken authReq = new UsernamePasswordAuthenticationToken(
                    user.getUsername(), null, user.getAuthorities());

            LOG.debug("refreshTokenRequired :{}", enterpriseInfo.isRefreshTokenRequired());
            LOG.debug("refreshTokenValidityInSeconds :{}", enterpriseInfo.getRefreshTokenValiditySeconds());
            LOG.debug("accessTokenValidityInSeconds : {}", enterpriseInfo.getAccessTokenValiditySeconds());

            final String redirectUri = (enterpriseInfo.getRegisteredRedirectUri() != null
                    && enterpriseInfo.getRegisteredRedirectUri().toArray().length > 0)
                            ? (String) enterpriseInfo.getRegisteredRedirectUri().toArray()[0]
                            : "N/A";
            LOG.info("redirectUri :{}", redirectUri);
            final OAuth2Request storedRequest = new OAuth2Request(map, clientId, user.getAuthorities(), true,
                    enterpriseInfo.getScope(), enterpriseInfo.getResourceIds(), redirectUri, responseTypes,
                    new HashMap<String, Serializable>());

            final OAuth2Authentication oAuth2Authentication = new OAuth2Authentication(storedRequest, authReq);
            LOG.info("grant_type:{}", oAuth2Authentication.getOAuth2Request().getGrantType());
            LOG.info("source :{}", oAuth2Authentication.getOAuth2Request().getRequestParameters()
                    .get(RequestParams.PasswordGrant.SOURCE));

            // final CustomJwtAccessTokenConverter customAccessTokenConverter =
            // new
            // CustomJwtAccessTokenConverter(
            // oidcConfigRepo, userAuthInfoRepo);

            final JwtService serviceJwt = new JwtServiceImpl();
            final OpenIdAccessTokenEnhancer openIdEnhancer = new OpenIdAccessTokenEnhancer(serviceJwt, oidcConfigRepo,
                    userAuthInfoRepo, enterpriseInfoRepo);

            tokenServices.setSupportRefreshToken(enterpriseInfo.isRefreshTokenRequired());
            tokenServices.setRefreshTokenValiditySeconds(enterpriseInfo.getRefreshTokenValiditySeconds());
            tokenServices.setAccessTokenValiditySeconds(enterpriseInfo.getAccessTokenValiditySeconds());
            tokenServices.setTokenEnhancer(openIdEnhancer);

            final OAuth2AccessToken token = tokenServices.createAccessToken(oAuth2Authentication);

            LOG.debug("accesstoken type :{}", token.getTokenType());
            LOG.debug("accesstoken expiresIn :{}", token.getExpiresIn());

            // final OAuth2AccessToken enhancedToken =
            // openIdEnhancer.enhance(token,
            // oAuth2Authentication);
            encodedString = Base64.encodeBase64String(Constants.GSON_BSON.toJson(token).getBytes());
        } catch (final Exception e) {
            LOG.error("Error while processing ciba request due to {}", e.getMessage(), e);
        }
        relidVerifyMessagePublisher.sendAccessCumIDTokenGenerationResponse(encodedString, correlationID,
                replyToRoutingKey);
    }

}
