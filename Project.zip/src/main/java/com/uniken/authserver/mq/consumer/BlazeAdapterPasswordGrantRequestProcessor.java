package com.uniken.authserver.mq.consumer;

import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.util.JsonParser;
import org.springframework.security.oauth2.common.util.JsonParserFactory;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.stereotype.Service;

import com.google.gson.internal.LinkedTreeMap;
import com.uniken.authserver.mq.publisher.BlazeAdapterMessagePublisher;
import com.uniken.authserver.repo.api.OidcConfigRepo;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.repo.impl.EnterpriseRepoImpl;
import com.uniken.authserver.services.impl.CustomJwtAccessTokenConverter;
import com.uniken.authserver.services.impl.CustomUserDetailsService;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.MQConstant;
import com.uniken.authserver.utility.RequestParams;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.AccessTokenResponse;
import com.uniken.domains.auth.EnterpriseInfo;

/**
 * Message processor when request from Blaze Adapter landed on Auth Server to
 * fetch an access token, this service is invoked.
 * 
 * @author Uday T
 */

@Service(MQConstant.BLAZEADAPTER_GENERATE_ACCESS_TOKEN_REQUEST_KEY)
public class BlazeAdapterPasswordGrantRequestProcessor
        implements
        MessageProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(BlazeAdapterPasswordGrantRequestProcessor.class);

    private final JsonParser objectMapper = JsonParserFactory.create();

    @Autowired
    private UserAuthInfoRepo userAuthInfoRepo;

    @Autowired
    private OidcConfigRepo oidcConfigRepo;

    @Autowired
    private BlazeAdapterMessagePublisher blazeAdapterMessagePublisher;

    @Autowired
    private DefaultTokenServices tokenServices;

    @Autowired
    private CustomUserDetailsService customUserDetailsService;

    @Autowired
    private EnterpriseRepoImpl enterpriseInfoRepo;

    @Override
    public void handleMessage(final String correlationID, final String message, final String replyToRoutingKey,
            final Map<String, Object> mqHeaders) {

        LOG.info("handleMessage() -> correlationID:{}", correlationID);

        if (Utils.isNullOrEmpty(correlationID)) {
            LOG.error("Correlation ID is null or empty");
            throw new IllegalArgumentException("Correlation ID is null or empty");
        }

        if (Utils.isNullOrEmpty(message)) {
            LOG.error("BlazeAdapterPasswordGrantRequestProcessor message is null or empty");
            throw new IllegalArgumentException("BlazeAdapterPasswordGrantRequestProcessor message is null or empty");
        }

        final org.springframework.http.HttpEntity<Object> requestHttpEntity = Constants.GSON.fromJson(message,
                org.springframework.http.HttpEntity.class);

        final LinkedTreeMap<String, Object> msgBody = (LinkedTreeMap<String, Object>) requestHttpEntity.getBody();
        final String userName = (String) ((java.util.ArrayList) msgBody.get("username")).get(0);
        final String sessionId = (String) ((java.util.ArrayList) msgBody.get("session_id")).get(0);
        final String grantType = (String) ((java.util.ArrayList) msgBody.get("grant_type")).get(0);
        final String appAgentName = (String) ((java.util.ArrayList) msgBody.get("app_agent_name")).get(0);
        final String deviceId = (String) ((java.util.ArrayList) msgBody.get("device_id")).get(0);
        final String source = (String) ((java.util.ArrayList) msgBody.get("source")).get(0);
        final Set<String> scope = new HashSet(((java.util.ArrayList) msgBody.get("scope")));
        final List<GrantedAuthority> authorities = ((java.util.ArrayList) msgBody.get("authorities"));
        final Set<String> resourceIds = new HashSet(((java.util.ArrayList) msgBody.get("RESOURCE_IDS")));
        final String clientId = ((String) ((java.util.ArrayList) msgBody.get("CLIENT_ID")).get(0));
        final String clientSecret = ((String) ((java.util.ArrayList) msgBody.get("CLIENT_SECRET")).get(0));
        final Object[] authorizedGrantType = ((java.util.ArrayList) msgBody.get("AUTHORIZED_GRANT_TYPE")).toArray();
        final String redirectURI = ((String) ((java.util.ArrayList) msgBody.get("REDIRECT_URI")).get(0));
        final Set<String> responseTypes = new HashSet(((java.util.ArrayList) msgBody.get("RESPONSE_TYPE")));

        LOG.info("userName :{}", userName);

        final Map<String, String> map = new HashMap<String, String>();
        map.put("username", userName);
        map.put("session_id", sessionId);
        map.put("grant_type", grantType);
        map.put("app_agent_name", appAgentName);
        map.put("device_id", deviceId);
        map.put("source", source);

        /**
         * set resourceIds as null, otherwise resourceIds will be used in "aud"
         * claim
         */

        final EnterpriseInfo enterpriseInfo = enterpriseInfoRepo.getEnterpriseByClientId(clientId);

        if (enterpriseInfo == null) {
            LOG.error("EnterpriseInfo is null");
            throw new IllegalArgumentException("UnAuthorized Access");
        }
        final UserDetails user = customUserDetailsService.loadUserByUsername(userName);
        final UsernamePasswordAuthenticationToken authReq = new UsernamePasswordAuthenticationToken(user.getUsername(),
                null, user.getAuthorities());

        LOG.debug("autoApprove :{}", ((scope.toArray()[0])));
        LOG.debug("refreshTokenRequired :{}", enterpriseInfo.isRefreshTokenRequired());
        LOG.debug("refreshTokenValidityInSeconds :{}", enterpriseInfo.getRefreshTokenValiditySeconds());
        LOG.debug("accessTokenValidityInSeconds : {}", enterpriseInfo.getAccessTokenValiditySeconds());

        final OAuth2Request storedRequest = new OAuth2Request(map, clientId, user.getAuthorities(), true, scope,
                resourceIds, redirectURI, responseTypes, new HashMap<String, Serializable>());

        final OAuth2Authentication oAuth2Authentication = new OAuth2Authentication(storedRequest, authReq);
        LOG.info("grant_type:{}", oAuth2Authentication.getOAuth2Request().getGrantType());
        LOG.info("source :{}",
                oAuth2Authentication.getOAuth2Request().getRequestParameters().get(RequestParams.PasswordGrant.SOURCE));

        final CustomJwtAccessTokenConverter customAccessTokenConverter = new CustomJwtAccessTokenConverter(
                oidcConfigRepo, userAuthInfoRepo);
        tokenServices.setSupportRefreshToken(enterpriseInfo.isRefreshTokenRequired());
        tokenServices.setRefreshTokenValiditySeconds(enterpriseInfo.getRefreshTokenValiditySeconds());
        tokenServices.setAccessTokenValiditySeconds(enterpriseInfo.getAccessTokenValiditySeconds());
        tokenServices.setTokenEnhancer(customAccessTokenConverter);

        final OAuth2AccessToken token = tokenServices.createAccessToken(oAuth2Authentication);

        LOG.debug("accesstoken type :{}", token.getTokenType());
        LOG.debug("accesstoken expiresIn :{}", token.getExpiresIn());
        final AccessTokenResponse newEnhancedToken = new AccessTokenResponse(token.getValue(), token.getTokenType(),
                String.valueOf(token.getExpiresIn()), (String) (token.getScope().toArray()[0]),
                (String) token.getAdditionalInformation().get("jti"), token.getRefreshToken().getValue());

        blazeAdapterMessagePublisher.publishMessage(Constants.GSON_BSON.toJson(newEnhancedToken), correlationID,
                replyToRoutingKey);
    }

}
