package com.uniken.authserver.mq.consumer;

import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.jwt.crypto.sign.Signer;
import org.springframework.security.oauth2.common.DefaultOAuth2RefreshToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.util.JsonParser;
import org.springframework.security.oauth2.common.util.JsonParserFactory;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.DefaultAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.DefaultUserAuthenticationConverter;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.stereotype.Service;

import com.google.gson.internal.LinkedTreeMap;
import com.uniken.authserver.mq.publisher.BlazeAdapterMessagePublisher;
import com.uniken.authserver.repo.api.MongoTokenStoreRepo;
import com.uniken.authserver.repo.api.OidcConfigRepo;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.repo.impl.EnterpriseRepoImpl;
import com.uniken.authserver.services.impl.CustomJwtAccessTokenConverter;
import com.uniken.authserver.services.impl.CustomUserDetailsService;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.MQConstant;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.AccessTokenResponse;
import com.uniken.domains.auth.EnterpriseInfo;

/**
 * Message processor when request from Blaze Adapter landed on Auth Server to
 * fetch an access token, this service is invoked.
 * 
 * @author Uday T
 */

@Service(MQConstant.BLAZEADAPTER_GENERATE_ACCESS_TOKEN__REQUEST_BY_REFRESH_TOKEN_KEY)
public class BlazeAdapterPasswordGrantByRefreshTokenRequestProcessor
        implements
        MessageProcessor {

    private static final Logger LOG = LoggerFactory
            .getLogger(BlazeAdapterPasswordGrantByRefreshTokenRequestProcessor.class);

    private final JsonParser objectMapper = JsonParserFactory.create();

    @Autowired
    private UserAuthInfoRepo userAuthInfoRepo;

    @Autowired
    private OidcConfigRepo oidcConfigRepo;

    @Autowired
    private MongoTokenStoreRepo mongoTokenStoreRepo;

    @Autowired
    private BlazeAdapterMessagePublisher blazeAdapterMessagePublisher;

    @Autowired
    private DefaultTokenServices tokenServices;

    @Autowired
    private CustomUserDetailsService customUserDetailsService;

    @Autowired
    private EnterpriseRepoImpl enterpriseInfoRepo;

    @Override
    public void handleMessage(final String correlationID, final String message, final String replyToRoutingKey,
            final Map<String, Object> mqHeaders) {

        LOG.info("handleMessage() -> correlationID:{}", correlationID);

        if (Utils.isNullOrEmpty(correlationID)) {
            LOG.error("Correlation ID is null or empty");
            throw new IllegalArgumentException("Correlation ID is null or empty");
        }

        if (Utils.isNullOrEmpty(message)) {
            LOG.error("BlazeAdapterPasswordGrantRequestProcessor message is null or empty");
            throw new IllegalArgumentException("BlazeAdapterPasswordGrantRequestProcessor message is null or empty");
        }

        final org.springframework.http.HttpEntity<Object> requestHttpEntity = Constants.GSON.fromJson(message,
                org.springframework.http.HttpEntity.class);

        final LinkedTreeMap<String, Object> msgBody = (LinkedTreeMap<String, Object>) requestHttpEntity.getBody();
        final String grantType = (String) ((java.util.ArrayList) msgBody.get("grant_type")).get(0);
        final String refreshToken = (String) ((java.util.ArrayList) msgBody.get("refresh_token")).get(0);
        final String clientId = ((String) ((java.util.ArrayList) msgBody.get("CLIENT_ID")).get(0));
        final String clientSecret = ((String) ((java.util.ArrayList) msgBody.get("CLIENT_SECRET")).get(0));
        final String userName = ((String) ((java.util.ArrayList) msgBody.get("USER_NAME")).get(0));

        final EnterpriseInfo enterpriseInfo = enterpriseInfoRepo.getEnterpriseByClientId(clientId);

        if (enterpriseInfo == null) {
            LOG.error("EnterpriseInfo is null");
            throw new IllegalArgumentException("UnAuthorized Access");
        }

        if (LOG.isDebugEnabled()) {
            if (null != enterpriseInfo.getRegisteredRedirectUri()
                    && enterpriseInfo.getRegisteredRedirectUri().toArray().length > 0) {
                LOG.debug("registeredRedirectURI : {}", (enterpriseInfo.getRegisteredRedirectUri().toArray()[0]));
            } else {
                LOG.debug("registeredRedirectURI : null");
            }
            LOG.debug("refreshTokenRequired :{}", enterpriseInfo.isRefreshTokenRequired());
            LOG.debug("refreshTokenValidityInSeconds :{}", enterpriseInfo.getRefreshTokenValiditySeconds());
            LOG.debug("accessTokenValidityInSeconds : {}", enterpriseInfo.getAccessTokenValiditySeconds());
        }

        final DefaultOAuth2RefreshToken refreshTokenObject = (DefaultOAuth2RefreshToken) mongoTokenStoreRepo
                .readRefreshToken(refreshToken);

        final OAuth2Authentication oAuth2Authentication = mongoTokenStoreRepo
                .readAuthenticationForRefreshToken(refreshTokenObject);
        final CustomJwtAccessTokenConverter customAccessTokenConverter = new CustomJwtAccessTokenConverter(
                oidcConfigRepo, userAuthInfoRepo);
        tokenServices.setSupportRefreshToken(enterpriseInfo.isRefreshTokenRequired());
        tokenServices.setRefreshTokenValiditySeconds(enterpriseInfo.getRefreshTokenValiditySeconds());
        tokenServices.setAccessTokenValiditySeconds(enterpriseInfo.getAccessTokenValiditySeconds());
        tokenServices.setTokenEnhancer(customAccessTokenConverter);
        final OAuth2AccessToken token = tokenServices.createAccessToken(oAuth2Authentication);

        LOG.debug("accesstoken type :{}", token.getTokenType());
        LOG.debug("accesstoken expiresIn :{}", token.getExpiresIn());

        final AccessTokenResponse newEnhancedToken = new AccessTokenResponse(token.getValue(), token.getTokenType(),
                String.valueOf(token.getExpiresIn()), (String) (token.getScope().toArray()[0]),
                (String) token.getAdditionalInformation().get("jti"), token.getRefreshToken().getValue());

        blazeAdapterMessagePublisher.publishMessage(Constants.GSON_BSON.toJson(newEnhancedToken), correlationID,
                replyToRoutingKey);
    }

    /**
     * Gets the jwt access token converter with custom headers and custom user
     * token converter.
     *
     * @param signer
     *            the signer
     * @param headers
     *            the headers
     * @return the jwt access token converter with headers
     */
    private JwtAccessTokenConverter getJwtAccessTokenConverterWithCustomHeadersAndCustomUserTokenConverter(
            final Signer signer, final Map<String, String> headers) {
        final DefaultAccessTokenConverter defaultAccessTokenConverter = new DefaultAccessTokenConverter();
        final JwtAccessTokenConverter jwtAccessTokenConverterWithCustomHeaders = new JwtAccessTokenConverter() {
            @Override
            protected String encode(final OAuth2AccessToken accessToken, final OAuth2Authentication authentication) {
                String content;
                try {
                    content = objectMapper
                            .formatMap(defaultAccessTokenConverter.convertAccessToken(accessToken, authentication));
                } catch (final Exception e) {
                    throw new IllegalStateException("Cannot convert access token to JSON", e);
                }
                return JwtHelper.encode(content, signer, headers).getEncoded();
            }
        };
        defaultAccessTokenConverter.setUserTokenConverter(new DefaultUserAuthenticationConverter() {
            @Override
            public Map<String, ?> convertUserAuthentication(final Authentication authentication) {
                // FIXME: Remove this code block as below comment is not valid
                // anymore
                /**
                 * Do not add user_name to access_token as it is a combination
                 * of username:app:device;session and we want only username to
                 * be included in the access_token JWT.
                 */
                return new LinkedHashMap<>();
            }

        });
        jwtAccessTokenConverterWithCustomHeaders.setAccessTokenConverter(defaultAccessTokenConverter);
        jwtAccessTokenConverterWithCustomHeaders.setSigner(signer);
        return jwtAccessTokenConverterWithCustomHeaders;
    }
}
