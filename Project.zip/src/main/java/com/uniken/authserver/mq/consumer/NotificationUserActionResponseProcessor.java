package com.uniken.authserver.mq.consumer;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.gson.JsonParseException;
import com.mongodb.client.result.UpdateResult;
import com.uniken.authserver.repo.api.GenerateRVNMessageRepo;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.MQConstant;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.relid.notification.NotificationUserActionResponse;

/**
 * Message processor when REL-ID Verify notification was acted upon, this
 * service is invoked.
 * 
 * @author Uday T
 */

@Service(MQConstant.AUTHSERVER_RECEIVING_ACTION_ROUTING_KEY)
public class NotificationUserActionResponseProcessor
        implements
        MessageProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(NotificationUserActionResponseProcessor.class);

    @Autowired
    private GenerateRVNMessageRepo generateRVNMessageRepo;

    @Override
    public void handleMessage(final String correlationID, final String notificationUserActionResponse,
            final String replyToRoutingKey, final Map<String, Object> headers) {

        LOG.info("handleMessage() -> correlationID:{}, notificationUserActionResponse:{}", correlationID,
                notificationUserActionResponse);

        if (Utils.isNullOrEmpty(correlationID)) {
            LOG.error("Correlation ID is null or empty");
            throw new IllegalArgumentException("Correlation ID is null or empty");
        }

        if (Utils.isNullOrEmpty(notificationUserActionResponse)) {
            LOG.error("Notification User Action Response is null or empty");
            throw new IllegalArgumentException("Notification User Action Response is null or empty");
        }

        NotificationUserActionResponse response = null;
        try {
            response = Constants.GSON.fromJson(notificationUserActionResponse, NotificationUserActionResponse.class);
        } catch (final JsonParseException e) {
            LOG.error("Invalid Notification User Action response json found", e);
            throw new IllegalArgumentException("Notification User Action Response is invalid");
        }
        Constants.getVerifyNotificationResponseMap().put(correlationID, response);

        /**
         * Save the User action into the DB.
         */
        final UpdateResult result = generateRVNMessageRepo.findAndSaveNotificationUserActionResponse(correlationID,
                response);

        LOG.info("handleMessage() : updated response for correlationId = {},  modifiedcount = {}, matchedCount = {}",
                correlationID, result.getModifiedCount(), result.getMatchedCount());

        LOG.trace(
                "handleMessage() : Populated working map with NotificationActionResponse object for correlationID = {}, message = {}",
                correlationID, notificationUserActionResponse);

    }

}
