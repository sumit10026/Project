package com.uniken.authserver.mq.publisher;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.exceptions.InvalidRequestException;
import org.springframework.stereotype.Service;

import com.google.gson.JsonSyntaxException;
import com.uniken.authserver.domains.SaveNotificationRequest;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.MQConstant;
import com.uniken.authserver.utility.Utils;

@Service
public class RelIdVerifyMessagePublisher {

    private static final Logger LOG = LoggerFactory.getLogger(RelIdVerifyMessagePublisher.class);

    @Autowired
    private AmqpTemplate amqpTemplate;

    /**
     * This function validates pay-load and correlation ID and then-after it
     * publishes on the given Routing Key and REL-ID verify exchange
     * 
     * @param payload
     *            the payload
     * @param correlationID
     *            the co-relation id
     * @param routingKey
     *            the MQ routing key.
     * @return
     */
    private boolean publishMessage(final String payload, final String correlationID, final String routingKey) {

        boolean ret = false;

        if (Utils.isNullOrEmpty(payload)) {
            LOG.error("sendMessage() : Message payload is empty or null");
            throw new InvalidRequestException("Message payload is empty or null");
        }

        if (Utils.isNullOrEmpty(correlationID)) {
            LOG.error("sendMessage() : correlationID is empty or null");
            throw new InvalidRequestException("CorrelationID is empty or null");
        }

        LOG.info("sendMessage() : Sending Message on routing key: {}, with correlationID = {}", routingKey,
                correlationID);

        final MessageProperties messageProperties = new MessageProperties();
        messageProperties.setCorrelationId(correlationID);
        messageProperties.setHeader(Constants.REQUESTOR_IP_DEFAULT_HEADER, Constants.AUTH_SERVER_LOCAL_IP);
        messageProperties.setHeader(Constants.NOTIFICATION_REQUESTOR_NAME, Constants.AUTH_SERVER_COMPONENT_NAME);

        final Message sendMessage = MessageBuilder.withBody(payload.getBytes()).andProperties(messageProperties)
                .build();

        amqpTemplate.send(Constants.VERIFY_NODE_EXCHANGE, routingKey, sendMessage);

        LOG.info("sendMessage() Message sent successfully for generating push notifications with correlationID = {}",
                correlationID);

        ret = true;
        return ret;
    }

    /**
     * This function validates pay-load and correlation ID and then-after it
     * publishes on Routing Key RZNOTIFICATION.SAVE.REQUEST and REL-ID verify
     * exchange
     * 
     * @param payload
     *            the payload
     * @param correlationID
     *            the co-relation id
     */
    public boolean sendGenerateRVNRequestToVerify(final String payload, final String correlationID) {

        try {
            /**
             * To validate the payload JSON.
             */
            Constants.GSON_BSON.fromJson(payload, SaveNotificationRequest.class);
        } catch (final JsonSyntaxException exc) {
            LOG.error("sendGenerateRVNRequestToVerify() -> Incorrect Message payload", exc);
            throw new InvalidRequestException("Incorrect JSON : Message payload");
        }

        return publishMessage(payload, correlationID, MQConstant.VERIFY_NODE_GENERATE_NOTIFICATION_ROUTING_KEY);

    }

    /**
     * This function validates pay-load and correlation ID and then-after it
     * publishes to discard the notification on Routing Key
     * RZNOTIFICATION.DISCARD.REQUEST and REL-ID verify exchange
     * 
     * @param payload
     *            the payload
     * @param correlationID
     *            the co-relation id
     */
    public boolean sendDiscardRVNRequestToVerify(final String payload, final String correlationID) {

        try {
            /**
             * To validate the payload JSON.
             */
            Constants.GSON_BSON.fromJson(payload, SaveNotificationRequest.class);
        } catch (final JsonSyntaxException exc) {
            LOG.error("sendDiscardRVNRequestToVerify() -> Incorrect Message payload", exc);
            throw new InvalidRequestException("Incorrect JSON : Message payload");
        }

        return publishMessage(payload, correlationID, MQConstant.VERIFY_DISCARD_NOTIFICATION_ROUTING_KEY);

    }

    /**
     * The method is used to send the access token / id token to REL-ID Verify
     * server.
     * 
     * @param payload
     * @param correlationID
     * @param routingKey
     * @return
     */
    public boolean sendAccessCumIDTokenGenerationResponse(final String payload, final String correlationID,
            final String routingKey) {
        LOG.info(
                "sendAccessCumIDTokenGenerationResponse() responding back to REL-ID Verify server for correlationID :{}",
                correlationID);
        return publishMessage(payload, correlationID, routingKey);
    }
}
