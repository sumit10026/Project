package com.uniken.authserver.mq.publisher;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.core.MessageBuilder;
import org.springframework.amqp.core.MessageProperties;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.exceptions.InvalidRequestException;
import org.springframework.stereotype.Service;

import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.Utils;

@Service
public class BlazeAdapterMessagePublisher {

    private static final Logger LOG = LoggerFactory.getLogger(BlazeAdapterMessagePublisher.class);

    @Autowired
    private AmqpTemplate amqpTemplate;

    /**
     * This function validates pay-load and correlation ID and then-after it
     * publishes on the given Routing Key and REL-ID verify exchange
     * 
     * @param payload
     *            the payload
     * @param correlationID
     *            the co-relation id
     * @param routingKey
     *            the MQ routing key.
     * @return
     */
    public boolean publishMessage(final String payload, final String correlationID, final String routingKey) {

        boolean ret = false;

        if (Utils.isNullOrEmpty(payload)) {
            LOG.error("sendMessage() : Message payload is empty or null");
            throw new InvalidRequestException("Message payload is empty or null");
        }

        if (Utils.isNullOrEmpty(correlationID)) {
            LOG.error("sendMessage() : correlationID is empty or null");
            throw new InvalidRequestException("CorrelationID is empty or null");
        }

        LOG.info("sendMessage() : Sending Message on routing key: {}, with correlationID = {}", routingKey,
                correlationID);

        final MessageProperties messageProperties = new MessageProperties();
        messageProperties.setCorrelationId(correlationID);
        messageProperties.setReceivedRoutingKey(routingKey);

        final Message sendMessage = MessageBuilder.withBody(payload.getBytes()).andProperties(messageProperties)
                .build();

        amqpTemplate.send(Constants.BLAZEADAPTER_NODE_EXCHANGE, routingKey, sendMessage);

        LOG.info("publishMessage() Message sent successfully towards BlazeAdapter with correlationID = {}",
                correlationID);

        ret = true;
        return ret;
    }

}
