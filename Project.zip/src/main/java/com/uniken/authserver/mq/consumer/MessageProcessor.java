package com.uniken.authserver.mq.consumer;

import java.util.Map;

/**
 * Interface used to handle message using correlation Id and message body
 * 
 * @author Uday T
 */
public interface MessageProcessor {
    /**
     * Handle message
     * 
     * @param correlationId
     * @param message
     * @param replyToRoutingKey
     * @param headers
     */
    public void handleMessage(String correlationId, String message, String replyToRoutingKey,
            Map<String, Object> headers);
}
