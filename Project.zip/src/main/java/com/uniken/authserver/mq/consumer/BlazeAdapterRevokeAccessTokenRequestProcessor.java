package com.uniken.authserver.mq.consumer;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.exceptions.InvalidRequestException;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.google.gson.internal.LinkedTreeMap;
import com.uniken.authserver.services.api.TokenEndpointsServices;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.MQConstant;
import com.uniken.authserver.utility.Utils;

/**
 * Message processor when request from Blaze Adapter landed on Auth Server to
 * revoke an access token, this service is invoked.
 * 
 * @author Uday T
 */

@Service(MQConstant.BLAZEADAPTER_REVOKE_ACCESS_TOKEN_REQUEST_KEY)
public class BlazeAdapterRevokeAccessTokenRequestProcessor
        implements
        MessageProcessor {

    private static final Logger LOG = LoggerFactory.getLogger(BlazeAdapterRevokeAccessTokenRequestProcessor.class);

    @Autowired
    private TokenEndpointsServices endpointsServices;

    @Override
    public void handleMessage(final String correlationID, final String message, final String replyToRoutingKey,
            final Map<String, Object> mqHeaders) {

        LOG.info("handleMessage() -> correlationID:{}", correlationID);

        if (Utils.isNullOrEmpty(message)) {
            LOG.error("BlazeAdapterRevokeAccessTokenRequestProcessor message is null or empty");
            throw new IllegalArgumentException(
                    "BlazeAdapterRevokeAccessTokenRequestProcessor message is null or empty");
        }

        final org.springframework.http.HttpEntity<Object> requestHttpEntity = Constants.GSON.fromJson(message,
                org.springframework.http.HttpEntity.class);

        final LinkedTreeMap<String, Object> msgBody = (LinkedTreeMap<String, Object>) requestHttpEntity.getBody();
        final String token = (String) ((java.util.ArrayList) msgBody.get("token")).get(0);
        final String tokenType = (String) ((java.util.ArrayList) msgBody.get("token_type")).get(0);
        final String endPointURL = (String) ((java.util.ArrayList) msgBody.get("END_POINT_URL")).get(0);
        final String clientId = (String) ((java.util.ArrayList) msgBody.get("CLIENT_ID")).get(0);
        final String clientSecret = (String) ((java.util.ArrayList) msgBody.get("CLIENT_SECRET")).get(0);

        if (!StringUtils.hasText(token)) {
            throw new InvalidRequestException("Missing token");
        }

        if (!StringUtils.hasText(tokenType)) {
            throw new InvalidRequestException("Missing token type");
        }

        // final String clientId = getClientId(principal);

        LOG.debug("revoke accesstoken type :{}", tokenType);

        endpointsServices.revokeToken(token, tokenType, clientId);
    }

}
