package com.uniken.authserver.mq.consumer;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.Message;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uniken.authserver.repo.impl.ServiceLocator;
import com.uniken.authserver.utility.Constants;

/**
 * @author Kushal Jaiswal
 */
@Service
public class RabbitMQMessageConsumer {
    private static final Logger LOG = LoggerFactory.getLogger(RabbitMQMessageConsumer.class);

    @Autowired
    private ServiceLocator serviceLocator;

    @RabbitListener(queues = Constants.AUTH_SERVER_NODE_RECEIVING_QUEUE)
    public void onMessage(final Message message) {

        if (message == null) {
            LOG.error("Null message received on queue");
            throw new IllegalArgumentException("Null message received on queue");
        }

        try {
            LOG.info("onMessage() : Msg recvd on key {}", message.getMessageProperties().getReceivedRoutingKey());

            final String messageBody = new String(message.getBody());
            final String correlationID = message.getMessageProperties().getCorrelationId();
            final String replyToRoutingKey = message.getMessageProperties().getReplyTo();
            final Map<String, Object> headers = message.getMessageProperties().getHeaders();

            final MessageProcessor messageProcessorService = serviceLocator
                    .getService(message.getMessageProperties().getReceivedRoutingKey());

            if (messageProcessorService == null) {
                LOG.error("Message received on invalid routing key {}",
                        message.getMessageProperties().getReceivedRoutingKey());
                throw new IllegalArgumentException("Routing key is not registered");
            }

            messageProcessorService.handleMessage(correlationID, messageBody, replyToRoutingKey, headers);
        } catch (final Exception e) {
            LOG.error("Error while receiving rabbitmq message and its processing", e);
        }
    }

}
