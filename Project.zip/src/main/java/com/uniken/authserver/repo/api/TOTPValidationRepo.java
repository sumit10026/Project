package com.uniken.authserver.repo.api;

import java.util.List;

import com.uniken.authserver.domains.TOTPValidationLog;

public interface TOTPValidationRepo {

    /**
     * @param userId
     * @param totp
     * @param deviceUuid
     * @return
     */
    public boolean isTOTPConsumed(String userId, String totp, String deviceUuid);

    /**
     * @param totpValidationLog
     */
    public void insertLog(TOTPValidationLog totpValidationLog);

    /**
     * @param totpEnabledApps
     * @return
     */
    public List<String> getTOTPEnabledAppUuids();

}
