/**
 * 
 */
package com.uniken.authserver.repo.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.uniken.authserver.repo.api.SessionTicketRepo;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.enums.CollectionNames;
import com.uniken.domains.relid.session.SessionTicket;

/**
 * @author Omkar
 */
@Repository
public class SessionTicketRepoImpl
        implements
        SessionTicketRepo {

    private static final Logger LOG = LoggerFactory.getLogger(SessionTicketRepoImpl.class);

    @Resource(name = Constants.RESOURCE_RELIDDB_MONGO_TEMPLATE)
    private MongoTemplate relIddbMongoTemplate;

    @Override
    public SessionTicket findSessionTicketById(final String sessionTicketId) {
        LOG.info("findSessionTicketById() -> Fetching session ticket.");

        final Query query = new Query();
        query.addCriteria(Criteria.where(SessionTicket.SESSION_TICKET_ID).is(sessionTicketId));

        return relIddbMongoTemplate.findOne(query, SessionTicket.class,
                CollectionNames.SESSION_TICKET.getCollectionName());
    }

}
