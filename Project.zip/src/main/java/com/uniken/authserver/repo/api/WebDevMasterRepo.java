package com.uniken.authserver.repo.api;

import com.mongodb.client.result.UpdateResult;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.user.vos.SecureCookie;

/**
 * Interface used to interact with WebDevMaster collection
 * 
 * @author Uday T
 */
public interface WebDevMasterRepo {

    /**
     * This function fetches from web device master collection if matching
     * checksum found, else returns null
     * 
     * @param webDeviceCheckSum
     * @return
     */
    public WebDevMaster fetchWebDeviceMaster(String webDeviceCheckSum);

    /**
     * This function adds into web device master collection
     * 
     * @param WebDevMaster
     */
    public void addWebDeviceMaster(WebDevMaster webDevMaster);

    /**
     * This function updates web device master collection if matching object
     * found
     * 
     * @param webDevMaster
     * @return WebDevMaster
     */
    public WebDevMaster updateWebDeviceMaster(WebDevMaster webDevMaster);

    /**
     * This method fetches from web device master collection if matching secure
     * cookie found, else returns null
     * 
     * @param webDeviceCheckSum
     * @return
     */
    public WebDevMaster fetchWebDeviceMasterUsingSecureCookieValue(String secureCookieValue);

    /**
     * @param webDeviceUuid
     * @param secureCookie
     * @return
     */
    UpdateResult addSecureCookieForWebDevMaster(String webDeviceUuid, SecureCookie secureCookie);

    /**
     * @param webDeviceUuid
     * @param secureCookie
     * @return
     */
    UpdateResult updateSecureCookieForWebDevMaster(String webDeviceUuid, SecureCookie secureCookie);

}
