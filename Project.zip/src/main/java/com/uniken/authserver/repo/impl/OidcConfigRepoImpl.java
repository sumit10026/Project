package com.uniken.authserver.repo.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.uniken.authserver.repo.api.OidcConfigRepo;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.auth.OIDCConfig;

/**
 * @author Omkar
 */
@Repository
public class OidcConfigRepoImpl
        implements
        OidcConfigRepo {

    private static final Logger LOG = LoggerFactory.getLogger(OidcConfigRepoImpl.class);

    @Resource(name = Constants.RESOURCE_ADAPTERDB_MONGO_TEMPLATE)
    private MongoTemplate adapterdbMongoTemplate;

    @Override
    public List<OIDCConfig> getAllOidcConfigs() {
        LOG.info("getAllOidcConfigs() -> Fetching all OIDC configs.");

        return adapterdbMongoTemplate.findAll(OIDCConfig.class);
    }

    @Override
    public OIDCConfig getOidcConfigByAppAgentName(final String appAgentName) {
        LOG.info("getAllOidcConfigs() -> Fetching OIDC config by App Agent Name : {}", appAgentName);

        final Query query = new Query(Criteria.where(OIDCConfig.APP_AGENT_NAME).is(appAgentName));

        return adapterdbMongoTemplate.findOne(query, OIDCConfig.class);
    }

}
