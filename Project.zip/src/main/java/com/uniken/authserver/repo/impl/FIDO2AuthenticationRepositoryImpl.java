package com.uniken.authserver.repo.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import javax.annotation.Resource;

import org.apache.commons.lang3.NotImplementedException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.mastercard.ess.fido2.database.FIDO2AuthenticationEntity;
import com.mastercard.ess.fido2.database.FIDO2AuthenticationRepository;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.auth.fido.AuthenticatorAssertionResponse;
import com.uniken.domains.auth.fido.FIDO2AuthenticationDetails;
import com.uniken.domains.auth.fido.PublicKeyCredentialRequestOptions;
import com.uniken.domains.enums.CollectionNames;
import com.uniken.domains.relid.user.UserIdLoginIdMapping;

/**
 * The repo layer used to store the FIDO2 authentication records
 * 
 * @author Uniken Inc.
 */
@Repository("FIDO2AuthenticationRepository")
public class FIDO2AuthenticationRepositoryImpl
        implements
        FIDO2AuthenticationRepository {

    private static final Logger LOG = LoggerFactory.getLogger(FIDO2AuthenticationRepositoryImpl.class);

    private static final String NOT_IMPLEMENTED_MSG = "Functionality Not Implemented.";

    @Resource(name = "relIddbMongoTemplate")
    private MongoTemplate relIddbMongoTemplate;

    @Autowired
    UserAuthInfoRepo userAuthInfoRepo;

    @Override
    public List<FIDO2AuthenticationEntity> findAllByChallenge(final String challenge) {

        LOG.info("findAllByChallenge() -> entered, challenge:{}", challenge);

        // Not Tested

        final List<FIDO2AuthenticationDetails> authenticationDetails = relIddbMongoTemplate.find(
                Query.query(Criteria.where(FIDO2AuthenticationDetails.CHALLENGE_STR).is(challenge)),
                FIDO2AuthenticationDetails.class, CollectionNames.FIDO2_AUTHN_DB_RECORDS.getCollectionName());

        if (authenticationDetails.isEmpty()) {
            return Collections.emptyList();
        }

        return getMasterCardsFIDO2AuthenticationEntities(authenticationDetails);

    }

    @Override
    public List<FIDO2AuthenticationEntity> findAllByUserId(final String loginId) {

        LOG.info("findAllByUserId() -> entered, loginId:{}", loginId);

        // Not Tested

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("findAllByUserId() : mapping object not found for loginId :{}", loginId);
            return Collections.emptyList();
        }

        final String userId = mapping.getUserId();

        final List<FIDO2AuthenticationDetails> authenticationDetails = relIddbMongoTemplate.find(
                Query.query(Criteria.where(FIDO2AuthenticationDetails.USERID_STR).is(userId)),
                FIDO2AuthenticationDetails.class, CollectionNames.FIDO2_AUTHN_DB_RECORDS.getCollectionName());

        if (authenticationDetails.isEmpty()) {
            return Collections.emptyList();
        }

        return getMasterCardsFIDO2AuthenticationEntities(authenticationDetails);
    }

    @Override
    public List<FIDO2AuthenticationEntity> findAllByUsername(final String loginId) {

        LOG.info("findAllByUsername() -> entered, loginId:{}", loginId);

        // Not Tested

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("findAllByUsername() : mapping object not found for loginId :{}", loginId);
            return Collections.emptyList();
        }

        final String username = mapping.getUserId();

        final List<FIDO2AuthenticationDetails> authenticationDetails = relIddbMongoTemplate.find(
                Query.query(Criteria.where(FIDO2AuthenticationDetails.USERNAME_STR).is(username)),
                FIDO2AuthenticationDetails.class, CollectionNames.FIDO2_AUTHN_DB_RECORDS.getCollectionName());

        if (authenticationDetails.isEmpty()) {
            return Collections.emptyList();
        }

        return getMasterCardsFIDO2AuthenticationEntities(authenticationDetails);
    }

    @Override
    public List<FIDO2AuthenticationEntity> findAllByUsernameAndDomain(final String loginId, final String domain) {

        LOG.info("findAllByUsernameAndDomain() : entering");

        // Not Tested

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("findAllByUsernameAndDomain() : mapping object not found for loginId :{}", loginId);
            return Collections.emptyList();
        }

        final String username = mapping.getUserId();

        final Query query = new Query();
        query.addCriteria(Criteria.where(FIDO2AuthenticationDetails.USERNAME_STR).is(username));
        query.addCriteria(Criteria.where(FIDO2AuthenticationDetails.DOMAIN_STR).is(domain));

        final List<FIDO2AuthenticationDetails> authenticationDetails = relIddbMongoTemplate.find(query,
                FIDO2AuthenticationDetails.class, CollectionNames.FIDO2_AUTHN_DB_RECORDS.getCollectionName());

        if (authenticationDetails.isEmpty()) {
            return Collections.emptyList();
        }

        return getMasterCardsFIDO2AuthenticationEntities(authenticationDetails);

    }

    @Override
    public Optional<FIDO2AuthenticationEntity> findByChallenge(final String challenge) {

        LOG.info("FIDO2AuthenticationRepoImpl -> findByChallenge() entering");

        final Query query = new Query();
        query.addCriteria(Criteria.where(FIDO2AuthenticationDetails.CHALLENGE_STR).is(challenge));

        final FIDO2AuthenticationDetails authenticationDetail = relIddbMongoTemplate.findOne(query,
                FIDO2AuthenticationDetails.class, CollectionNames.FIDO2_AUTHN_DB_RECORDS.getCollectionName());

        return Optional.ofNullable(getMasterCardAuthenticationEntity(authenticationDetail));

    }

    @Override
    public Optional<FIDO2AuthenticationEntity> findByUserId(final String loginId) {

        LOG.info("findByUserId() entering");
        // Not Tested

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("findByUserId() : mapping object not found for loginId :{}", loginId);
            return Optional.empty();
        }

        final String userId = mapping.getUserId();

        final Query query = new Query();
        query.addCriteria(Criteria.where(FIDO2AuthenticationDetails.USERID_STR).is(userId));

        final FIDO2AuthenticationDetails authenticationDetail = relIddbMongoTemplate.findOne(query,
                FIDO2AuthenticationDetails.class, CollectionNames.FIDO2_AUTHN_DB_RECORDS.getCollectionName());

        return Optional.ofNullable(getMasterCardAuthenticationEntity(authenticationDetail));
    }

    @Override
    public Optional<FIDO2AuthenticationEntity> findByUsername(final String loginId) {
        LOG.info("findByUsername() entering");

        // Not Tested

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("findByUserId() : mapping object not found for loginId :{}", loginId);
            return Optional.empty();
        }

        final String username = mapping.getUserId();

        final Query query = new Query();
        query.addCriteria(Criteria.where(FIDO2AuthenticationDetails.USERNAME_STR).is(username));

        final FIDO2AuthenticationDetails authenticationDetail = relIddbMongoTemplate.findOne(query,
                FIDO2AuthenticationDetails.class, CollectionNames.FIDO2_AUTHN_DB_RECORDS.getCollectionName());

        return Optional.ofNullable(getMasterCardAuthenticationEntity(authenticationDetail));

    }

    @Override
    public <S extends FIDO2AuthenticationEntity> S save(final S authenticationDbRecord) {
        LOG.info("save() entering");

        final String challengeReceived = ((FIDO2AuthenticationEntity) authenticationDbRecord).getChallenge();

        final Query query = new Query();
        query.addCriteria(Criteria.where(FIDO2AuthenticationDetails.CHALLENGE_STR).is(challengeReceived));

        FIDO2AuthenticationDetails authenticationDetail = relIddbMongoTemplate.findOne(query,
                FIDO2AuthenticationDetails.class, CollectionNames.FIDO2_AUTHN_DB_RECORDS.getCollectionName());

        if (authenticationDetail != null) {
            authenticationDetail.setW3cAuthenticatorAssertionResponse(Constants.GSON.fromJson(
                    ((FIDO2AuthenticationEntity) authenticationDbRecord).getW3cAuthenticatorAssertionResponse(),
                    AuthenticatorAssertionResponse.class));
        } else {
            authenticationDetail = getFIDO2AuthenticationDetails(authenticationDbRecord);
        }
        relIddbMongoTemplate.save(authenticationDetail, CollectionNames.FIDO2_AUTHN_DB_RECORDS.getCollectionName());

        LOG.info("FIDO2AuthenticationRepoImpl -> save() exiting");
        return authenticationDbRecord;
    }

    /**
     * @param masterCardAuthenticationRecord
     * @return
     */
    private FIDO2AuthenticationDetails getFIDO2AuthenticationDetails(
            final FIDO2AuthenticationEntity masterCardAuthenticationRecord) {

        final FIDO2AuthenticationDetails authenticationDetails = new FIDO2AuthenticationDetails(
                masterCardAuthenticationRecord.getUsername(), masterCardAuthenticationRecord.getDomain(),
                masterCardAuthenticationRecord.getChallenge(),
                Constants.GSON.fromJson(masterCardAuthenticationRecord.getW3cCredentialRequestOptions(),
                        PublicKeyCredentialRequestOptions.class),
                masterCardAuthenticationRecord.getUserVerificationOption(),
                masterCardAuthenticationRecord.getCreatedDate(), masterCardAuthenticationRecord.getUpdatedDate());

        authenticationDetails.setRegistrationKeyId(masterCardAuthenticationRecord.getRegistrationId());
        if (masterCardAuthenticationRecord.getW3cAuthenticatorAssertionResponse() != null) {
            authenticationDetails.setW3cAuthenticatorAssertionResponse(
                    Constants.GSON.fromJson(masterCardAuthenticationRecord.getW3cAuthenticatorAssertionResponse(),
                            AuthenticatorAssertionResponse.class));
        }
        authenticationDetails.setUserId(masterCardAuthenticationRecord.getUserId());

        return authenticationDetails;
    }

    /**
     * @param authenticationDetails
     * @return
     */
    private List<FIDO2AuthenticationEntity> getMasterCardsFIDO2AuthenticationEntities(
            final List<FIDO2AuthenticationDetails> authenticationDetails) {

        final List<FIDO2AuthenticationEntity> masterCardAuthenticationList = new ArrayList<>();

        for (final FIDO2AuthenticationDetails authenticationDetail : authenticationDetails) {
            masterCardAuthenticationList.add(getMasterCardAuthenticationEntity(authenticationDetail));
        }

        return masterCardAuthenticationList;
    }

    /**
     * @param authenticationDetail
     * @return
     */
    private FIDO2AuthenticationEntity getMasterCardAuthenticationEntity(
            final FIDO2AuthenticationDetails authenticationDetail) {

        final FIDO2AuthenticationEntity masterCardAuthenticationEntity = new FIDO2AuthenticationEntity();

        masterCardAuthenticationEntity.setChallenge(authenticationDetail.getChallenge());
        masterCardAuthenticationEntity.setCreatedDate(authenticationDetail.getCreatedDate());
        masterCardAuthenticationEntity.setDomain(authenticationDetail.getDomain());
        masterCardAuthenticationEntity.setRegistrationId(authenticationDetail.getRegistrationKeyId());
        masterCardAuthenticationEntity.setUpdatedDate(authenticationDetail.getUpdatedDate());
        masterCardAuthenticationEntity.setUserId(authenticationDetail.getUserId());
        masterCardAuthenticationEntity.setUsername(authenticationDetail.getUsername());
        masterCardAuthenticationEntity.setUserVerificationOption(authenticationDetail.getUserVerificationOption());
        masterCardAuthenticationEntity.setW3cAuthenticatorAssertionResponse(
                Constants.GSON.toJson(authenticationDetail.getW3cAuthenticatorAssertionResponse()));
        masterCardAuthenticationEntity.setW3cCredentialRequestOptions(
                Constants.GSON.toJson(authenticationDetail.getCredentialCreationRequestOptions()));

        return masterCardAuthenticationEntity;
    }

    @Override
    public List<FIDO2AuthenticationEntity> findAll() {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public List<FIDO2AuthenticationEntity> findAll(final Sort sort) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public List<FIDO2AuthenticationEntity> findAllById(final Iterable<String> ids) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2AuthenticationEntity> List<S> saveAll(final Iterable<S> entities) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void flush() {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2AuthenticationEntity> S saveAndFlush(final S entity) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void deleteInBatch(final Iterable<FIDO2AuthenticationEntity> entities) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void deleteAllInBatch() {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public FIDO2AuthenticationEntity getOne(final String id) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2AuthenticationEntity> List<S> findAll(final Example<S> example) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2AuthenticationEntity> List<S> findAll(final Example<S> example, final Sort sort) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public Page<FIDO2AuthenticationEntity> findAll(final Pageable pageable) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public Optional<FIDO2AuthenticationEntity> findById(final String id) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public boolean existsById(final String id) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public long count() {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void deleteById(final String id) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void delete(final FIDO2AuthenticationEntity entity) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void deleteAll(final Iterable<? extends FIDO2AuthenticationEntity> entities) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);

    }

    @Override
    public void deleteAll() {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2AuthenticationEntity> Optional<S> findOne(final Example<S> example) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2AuthenticationEntity> Page<S> findAll(final Example<S> example, final Pageable pageable) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2AuthenticationEntity> long count(final Example<S> example) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2AuthenticationEntity> boolean exists(final Example<S> example) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void deleteAllByIdInBatch(final Iterable<String> ids) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void deleteAllInBatch(final Iterable<FIDO2AuthenticationEntity> fido2AuhenticationEntities) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public FIDO2AuthenticationEntity getById(final String id) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2AuthenticationEntity> List<S> saveAllAndFlush(final Iterable<S> fido2AuhenticationEntities) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void deleteAllById(final Iterable<? extends String> ids) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

}
