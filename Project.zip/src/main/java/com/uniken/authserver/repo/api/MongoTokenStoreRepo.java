/**
 * 
 */
package com.uniken.authserver.repo.api;

import org.springframework.security.oauth2.provider.token.TokenStore;

import com.uniken.domains.auth.CustomOAuth2AccessTokenLog;
import com.uniken.domains.auth.CustomOAuth2RefreshToken;

/**
 * @author Kushal Jaiswal
 */
public interface MongoTokenStoreRepo
        extends
        TokenStore {

    /**
     * Log Access token into the AccessTokenLog Collection.
     * 
     * @param accessTokenLog
     */
    void logAccessToken(CustomOAuth2AccessTokenLog accessTokenLog);

    /**
     * Read and remove a refresh token from the store.
     * 
     * @param tokenValue
     *            The value of the token to read.
     * @return The token.
     */
    CustomOAuth2RefreshToken readAndRemoveRefreshToken(String tokenValue);
}
