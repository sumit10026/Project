package com.uniken.authserver.repo.api;

import com.uniken.domains.auth.AppAgentEnterpriseMapping;

public interface AppAgentEnterpriseMappingRepo {

    /**
     * Gets the app agent mapping by enterprise id.
     *
     * @param enterpriseId
     *            the enterprise id
     * @return the mapped app agent app uuid by enterprise id
     */
    AppAgentEnterpriseMapping getAppAgentMappingByEnterpriseId(String enterpriseId);

}
