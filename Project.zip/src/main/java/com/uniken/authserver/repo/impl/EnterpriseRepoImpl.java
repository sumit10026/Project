package com.uniken.authserver.repo.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.uniken.authserver.repo.api.EnterpriseRepo;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.auth.EnterpriseInfo;

/**
 * @author Omkar
 */
@Repository
public class EnterpriseRepoImpl
        implements
        EnterpriseRepo {

    private static final Logger LOG = LoggerFactory.getLogger(EnterpriseRepoImpl.class);

    @Resource(name = Constants.RESOURCE_GMDB_MONGO_TEMPLATE)
    private MongoTemplate gmdbMongoTemplate;

    @Override
    public EnterpriseInfo getEnterpriseByClientId(final String clientId) {
        LOG.info("getEnterpriseByClientId() : Get enterprise by client id: {}", clientId);

        final Query query = new Query(Criteria.where(EnterpriseInfo.CLIENT_ID).is(clientId));

        return gmdbMongoTemplate.findOne(query, EnterpriseInfo.class);
    }

    @Override
    public EnterpriseInfo getEnterpriseByEnterpriseId(final String enterpriseId) {
        LOG.info("getEnterpriseByEnterpriseId() : Get enterprise by enterprise id: {}", enterpriseId);

        final Query query = new Query(Criteria.where(EnterpriseInfo.ENTERPRISE_ID_STR).is(enterpriseId));

        return gmdbMongoTemplate.findOne(query, EnterpriseInfo.class);
    }

}
