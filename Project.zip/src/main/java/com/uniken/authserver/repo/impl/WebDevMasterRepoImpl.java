package com.uniken.authserver.repo.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.mongodb.client.result.UpdateResult;
import com.uniken.authserver.repo.api.WebDevMasterRepo;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.enums.CollectionNames;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.user.vos.SecureCookie;

/**
 * Repository for web device master collection
 * 
 * @author Uday T
 */
@Repository
public class WebDevMasterRepoImpl
        implements
        WebDevMasterRepo {

    private static final Logger LOG = LoggerFactory.getLogger(WebDevMasterRepoImpl.class);

    @Resource(name = Constants.RESOURCE_RELIDDB_MONGO_TEMPLATE)
    private MongoTemplate relIddbMongoTemplate;

    @Override
    public WebDevMaster fetchWebDeviceMaster(final String webDeviceCheckSum) {
        LOG.info("fetchWebDeviceMaster() -> fetching WebDevMaster record");
        final Query query = new Query();
        query.addCriteria(Criteria.where(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR).is(webDeviceCheckSum));
        return relIddbMongoTemplate.findOne(query, WebDevMaster.class);
    }

    @Override
    public void addWebDeviceMaster(final WebDevMaster webDevMaster) {
        LOG.info("addWebDeviceMaster() -> adding WebDevMaster record");
        relIddbMongoTemplate.insert(webDevMaster, CollectionNames.WEB_DEV_MASTER.getCollectionName());
    }

    @Override
    public WebDevMaster updateWebDeviceMaster(final WebDevMaster webDevMaster) {
        LOG.info("updateWebDeviceMaster() -> updating WebDevMaster record");
        return relIddbMongoTemplate.save(webDevMaster, CollectionNames.WEB_DEV_MASTER.getCollectionName());
    }

    @Override
    public WebDevMaster fetchWebDeviceMasterUsingSecureCookieValue(final String secureCookieValue) {
        LOG.info("fetchWebDeviceMaster() -> fetching WebDevMaster record using secure cookie");
        final Query query = new Query();
        query.addCriteria(Criteria.where(WebDevMaster.SECURE_COOKIE + "." + SecureCookie.SECURE_COOKIE_VALUE)
                .is(secureCookieValue));
        return relIddbMongoTemplate.findOne(query, WebDevMaster.class);
    }

    @Override
    public UpdateResult addSecureCookieForWebDevMaster(final String webDeviceUuid, final SecureCookie secureCookie) {
        LOG.info("addSecureCookieForWebDevMaster() -> Adding secureCookie inside WebDevMaster: {}", webDeviceUuid);

        final Query query = new Query();
        query.addCriteria(Criteria.where(WebDevMaster.WEB_ID_STR).is(webDeviceUuid));

        final Update update = new Update();
        update.set(WebDevMaster.SECURE_COOKIE, secureCookie);

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update,
                CollectionNames.WEB_DEV_MASTER.getCollectionName());

        LOG.debug(
                "addSecureCookieForWebDevMaster() -> Adding secureCookie inside WebDevMaster: {}. No of elements updated: {}",
                webDeviceUuid, updateResult.getModifiedCount());

        return updateResult;
    }

    @Override
    public UpdateResult updateSecureCookieForWebDevMaster(final String webDeviceUuid, final SecureCookie secureCookie) {
        LOG.info("updateSecureCookieForWebDevMaster() -> Updating secureCookie inside WebDevMaster: {}", webDeviceUuid);

        final Query query = new Query();
        query.addCriteria(Criteria.where(WebDevMaster.WEB_ID_STR).is(webDeviceUuid));

        final Update update = new Update();
        update.set(WebDevMaster.SECURE_COOKIE + "." + SecureCookie.SECURE_COOKIE_UPDATED_TS,
                secureCookie.getSecureCookieUpdatedTs());
        update.set(WebDevMaster.SECURE_COOKIE + "." + SecureCookie.SECURE_COOKIE_EXPIRY_TS,
                secureCookie.getSecureCookieExpiryTs());
        update.set(WebDevMaster.SECURE_COOKIE + "." + SecureCookie.SECURE_COOKIE_MAX_AGE_IN_SECONDS,
                secureCookie.getSecureCookieMaxAgeInSeconds());

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update,
                CollectionNames.WEB_DEV_MASTER.getCollectionName());

        LOG.debug(
                "updateSecureCookieForWebDevMaster() -> Updating secureCookie inside WebDevMaster: {}. No of elements updated: {}",
                webDeviceUuid, updateResult.getModifiedCount());

        return updateResult;
    }
}
