package com.uniken.authserver.repo.api;

import com.mongodb.client.result.UpdateResult;
import com.uniken.authserver.domains.GenerateRVNMessageLog;
import com.uniken.domains.relid.notification.NotificationUserActionResponse;

public interface GenerateRVNMessageRepo {

    /**
     * This method insert RVNMessageLog record into collection
     * 
     * @param generateRVNMessageLog
     */
    public void insertLog(GenerateRVNMessageLog generateRVNMessageLog);

    /**
     * This method fetches RVNMessageLog record from correlationId and save the
     * notification user action response.
     * 
     * @param correlationID
     *            the correlationID
     * @return UpdateResult
     */
    public UpdateResult findAndSaveNotificationUserActionResponse(String correlationID,
            NotificationUserActionResponse notificationUserActionResponse);

}
