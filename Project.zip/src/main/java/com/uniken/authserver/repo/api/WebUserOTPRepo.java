package com.uniken.authserver.repo.api;

import com.uniken.domains.enums.OTPType;
import com.uniken.domains.relid.user.Message;
import com.uniken.domains.relid.user.OTP;

public interface WebUserOTPRepo {

    public void sendAndPersistOTP(OTP otp, Message message);

    public OTP validateWebUserOTP(String otpValue, OTPType otpType, String userId);

    public void archiveWebUserOTP(OTP otp);
}
