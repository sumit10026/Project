package com.uniken.authserver.repo.api;

import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.mongodb.client.result.UpdateResult;
import com.uniken.domains.auth.fido.FIDO2RegisteredAuthenticationModule;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.WebUserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.enums.web.WebIdUserStatus;
import com.uniken.domains.relid.user.UserAuthInfo;
import com.uniken.domains.relid.user.UserBrowser;
import com.uniken.domains.relid.user.UserIdLoginIdMapping;
import com.uniken.domains.relid.user.WebUserBrowserDetailsDTO;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.domains.user.vos.UserAuthInfoRegAuthModuleVo;
import com.uniken.domains.user.vos.WebUserDetails;
import com.uniken.domains.web.user.WebId;

public interface UserAuthInfoRepo {

    /**
     * @param loginId
     * @return
     */
    public UserAuthInfoVO fetchUserDetailsFromLoginId(String loginId);

    /**
     * @param loginId
     * @return
     */
    public List<FIDO2RegisteredAuthenticationModule> getListOFIDO2fRegAuthModuleLoginId(String loginId);

    /**
     * Insert the new element of {@link WebId} into the {@link UserAuthInfo}
     * 
     * @param loginId
     *            the loginId
     * @param webId
     *            the webId
     * @return the updateResult
     */
    public UpdateResult insertWebId(String loginId, WebId webId);

    /**
     * Update the status of {@link WebId} into the {@link UserAuthInfo}
     * 
     * @param loginId
     *            the loginId
     * @param webUUID
     *            the web UUID
     * @param webIdUserStatus
     *            the webId
     * @return the updateResult
     */
    public UpdateResult updateWebIdStatus(String loginId, String webUUID, WebIdUserStatus webIdUserStatus);

    /**
     * Checks for fido device registered.
     *
     * @param username
     *            the username
     * @return true, if successful
     */
    boolean hasFidoDeviceRegistered(String username);

    /**
     * Returns transport for registered fido devices.
     *
     * @param username
     *            the username
     * @return set of string as FIDO transports, if successful
     */
    Set<String> hasFidoDeviceRegisteredTransport(String username);

    /**
     * Check if the AuthType is registered with the user.
     * 
     * @param username
     * @param authType
     * @return true if AuthType registered with user otherwise false.
     */
    boolean hasAuthTypeRegistered(String username, AuthType authType);

    /**
     * Fetches user details using UserId & associated webDeviceUuid.
     * 
     * @param userId
     * @param webDeviceUuid
     * @return {@link UserAuthInfoVO}
     */
    UserAuthInfoVO fetchUserDetailsFromUserIdWebDeviceUuid(String userId, String webDeviceUuid);

    /**
     * Fetches user details using UserId
     * 
     * @param userId
     * @return {@link UserAuthInfoVO}
     */
    UserAuthInfoVO fetchUserDetailsFromUserId(String userId);

    /**
     * Updates {@link UserAuthInfoVO} object in UserAuthInfo collection
     * 
     * @param userAuthInfoVO
     * @return {@link UserAuthInfoVO}
     */
    UserAuthInfoVO updateUserAuthInfo(UserAuthInfoVO userAuthInfoVO);

    /**
     * Update user auth info doc.
     *
     * @param loginId
     *            the login id
     * @param fieldName
     *            the field name
     * @param value
     *            the value
     * @return the update result
     */
    UpdateResult updateUserAuthInfoDoc(String loginId, String fieldName, Object value);

    /**
     * Activate user.
     *
     * @param loginId
     *            the login id
     * @param userCurrentStatus
     *            the user current status
     * @param webOnly
     *            the web only
     * @param authTypes
     *            the auth types
     * @param mobileNumber
     *            the mobile number
     * @param email
     *            the email
     * @return the update result
     */
    UpdateResult activateUser(final String loginId, RelIdUserStatus userCurrentStatus, final boolean webOnly,
            final Set<AuthType> authTypes, String mobileNumber, String email);

    /**
     * Fetch associated userId with webDeviceUuid
     * 
     * @param webDeviceUuid
     * @return List of userIds
     */
    List<Map<String, String>> fetchAssociatedUserWithWebDeviceUuid(String webDeviceUuid);

    /**
     * This method fetches the all the details for specified user.
     * 
     * @param loginId
     * @return {@link UserAuthInfoRegAuthModuleVo}
     */
    UserAuthInfoRegAuthModuleVo fetchUserAuthInfoRegAuthModuleFromLoginId(String loginId);

    /**
     * Update web user attempt counter.
     *
     * @param loginId
     *            the login id
     * @param attemptCounters
     *            the attempt counters
     * @return the update result
     */
    UpdateResult updateWebUserAttemptCounter(String loginId, List<Integer> attemptCounters);

    /**
     * Block web user.
     *
     * @param userAuthInfo
     *            the user auth info
     * @return the update result
     */
    UpdateResult blockWebUser(final WebUserDetails webUserDetails, final String loginId);

    /**
     * Unblock web user.
     *
     * @param userAuthInfo
     *            the user auth info
     * @return the update result
     */
    UpdateResult unblockWebUser(final WebUserDetails webUserDetails, final String loginId);

    /**
     * Block web user browser.
     *
     * @param userBrowser
     *            the user browser
     * @return the update result
     */
    UpdateResult updateWebUserBrowserStatus(final String loginId, final String webDeviceUuid,
            final WebUserStatus status);

    /**
     * Get list of web user browsers
     */
    public List<UserBrowser> getListOfUserBrowsers(final String loginId);

    public List<WebUserBrowserDetailsDTO> getListOfBrowsers(final String loginId);

    public Page<UserBrowser> getListOfUserBrowsers(final String loginId, final String filter, Pageable pageable);

    public UpdateResult deleteWebUserBrowser(final String login, final String webDeviceUuid);

    public UpdateResult unRememberWebUserBrowser(final String login, final String webDeviceUuid);

    /**
     * @param loginId
     * @param authGenerationAttemptsCounter
     * @return
     */
    UpdateResult updateWebUserAuthGenerationAttemptCounter(String loginId,
            Map<String, Integer> authGenerationAttemptsCounter);

    /**
     * @param loginId
     * @param authTypestatus
     * @return
     */
    boolean deleteRegisteredAuthModule(final String loginId, final String authTypestatus);

    /**
     * @param loginId
     * @param authenticatorUuid
     * @param isEnabledState
     * @return
     */
    boolean updateRegAuthFactorStatus(final String loginId, final String authenticatorUuid, boolean isEnabledState);

    /**
     * @param loginId
     * @return
     */
    List<FIDO2RegisteredAuthenticationModule> fetchRegisteredAuthenticationModuleFromLoginId(String loginId);

    /**
     * @param loginId
     * @return
     */
    List<FIDO2RegisteredAuthenticationModule> fetchArchivedRegisteredAuthenticationModuleFromLoginId(String loginId);

    /**
     * @param loginId
     * @param authenticatorUuid
     * @return
     */
    FIDO2RegisteredAuthenticationModule fetchRegisteredAuthenticationModuleFromLoginIdAndAuthenticatorUuid(
            String loginId, String authenticatorUuid);

    /**
     * Fetches userid from loginid
     * 
     * @param loginId
     * @return
     */
    public UserIdLoginIdMapping findUserIdLoginIdMapping(final String loginId);

    /**
     * Update mobile number.
     *
     * @param loginId
     *            the login id
     * @param mobileNumber
     *            the mobile number
     * @return true, if successful
     */
    boolean updateMobileNumber(String loginId, String mobileNumber);

    /**
     * Update email id.
     *
     * @param loginId
     *            the login id
     * @param emailId
     *            the email id
     * @return true, if successful
     */
    boolean updateEmailId(String loginId, String emailId);

    /**
     * @param loginId
     * @param fidoType
     * @return
     */
    public boolean isFidoDeviceRegisteredByTypeFromUserId(String loginId, String fidoPlatformTransportType,
            String authenticatorUuid);

    public UserAuthInfoVO fetchUserDetailsFromMobileNumber(String mobileNumber);

    public UserAuthInfoVO fetchUserDetailsFromEmailId(String emailId);

}
