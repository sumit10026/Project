package com.uniken.authserver.repo.impl;

import java.util.Date;

import javax.annotation.Resource;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.session.Session;
import org.springframework.stereotype.Repository;

import com.uniken.authserver.repo.api.WebDevSessionRepo;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.enums.CollectionNames;

@Repository
public class WebDevSessionRepoImpl
        implements
        WebDevSessionRepo {

    private static final Logger LOG = LoggerFactory.getLogger(WebDevSessionRepoImpl.class);

    @Resource(name = Constants.RESOURCE_AUTHSERVERDB_MONGO_TEMPLATE)
    private MongoTemplate authserverdbMongoTemplate;

    @Override
    public void archiveWebDevSession(final Session mongoSession) {
        LOG.info("archiveWebDevSession() entered");
        if (mongoSession != null) {
            archiveWebDevSession(mongoSession.getId());
        }
    }

    @Override
    public void archiveWebDevSessionById(final String id) {
        LOG.info("archiveWebDevSessionById() entered");
        archiveWebDevSession(id);
    }

    private void archiveWebDevSession(final String id) {
        final Document session = authserverdbMongoTemplate.findById(id, Document.class,
                CollectionNames.WEB_DEV_SESSIONS.getCollectionName());

        if (null != session) {
            session.append("archived_ts", new Date());
            authserverdbMongoTemplate.save(session, CollectionNames.WEB_DEV_SESSIONS_ARC.getCollectionName());
        }
    }

}
