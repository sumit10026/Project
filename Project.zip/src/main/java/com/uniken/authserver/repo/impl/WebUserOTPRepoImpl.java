package com.uniken.authserver.repo.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.uniken.authserver.repo.api.WebUserOTPRepo;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.enums.CollectionNames;
import com.uniken.domains.enums.OTPType;
import com.uniken.domains.relid.user.Message;
import com.uniken.domains.relid.user.OTP;
import com.uniken.domains.relid.user.OTP_STATUS;

@Repository
public class WebUserOTPRepoImpl
        implements
        WebUserOTPRepo {

    private static final Logger LOG = LoggerFactory.getLogger(WebUserOTPRepoImpl.class);

    @Resource(name = Constants.RESOURCE_AUTHSERVERDB_MONGO_TEMPLATE)
    private MongoTemplate authserverdbMongoTemplate;

    @Resource(name = Constants.RESOURCE_OOBMSGDB_MONGO_TEMPLATE)
    private MongoTemplate oobmsgdbMongoTemplate;

    @Override
    public void sendAndPersistOTP(final OTP otp, final Message message) {
        LOG.info("sendAndPersistOTP() : entering");

        archiveWebUserOTPIfExist(otp.getUser_id());

        LOG.debug("sendAndPersistOTP() : persisting OTP into database");
        authserverdbMongoTemplate.save(otp, CollectionNames.WEB_USER_OTP.getCollectionName());
        LOG.debug("sendAndPersistOTP() : persisted OTP into database");

        LOG.debug("sendAndPersistOTP() : storing otp in message collection for delivery");
        oobmsgdbMongoTemplate.save(message, CollectionNames.MESSAGE.getCollectionName());
        LOG.debug("sendAndPersistOTP() : stored otp in message collection for delivery");

        LOG.info("sendAndPersistOTP() : exiting");
    }

    @Override
    public OTP validateWebUserOTP(final String otpValue, final OTPType otpType, final String userId) {

        LOG.info("validateWebUserOTP() : entering");

        final Query query = new Query();
        query.addCriteria(Criteria.where(OTP.USER_ID).is(userId));
        query.addCriteria(Criteria.where(OTP.OTP_VALUE).is(otpValue));
        query.addCriteria(Criteria.where(OTP.OTP_STATUS).is(OTP_STATUS.ACTIVE.name()));
        query.addCriteria(Criteria.where(OTP.OTP_TYPE_STR).is(otpType.name()));
        final OTP otp = authserverdbMongoTemplate.findOne(query, OTP.class,
                CollectionNames.WEB_USER_OTP.getCollectionName());

        LOG.info("validateWebUserOTP() : exiting");
        return otp;
    }

    @Override
    public void archiveWebUserOTP(final OTP otp) {
        LOG.info("archiveWebUserOTP() : entering");

        LOG.info("archiveWebUserOTP() : removing otp object");

        final Query query = new Query();
        query.addCriteria(Criteria.where(OTP.USER_ID).is(otp.getUser_id()));
        query.addCriteria(Criteria.where(OTP.OTP_ID).is(otp.getOtp_id()));
        query.addCriteria(Criteria.where(OTP.OTP_VALUE).is(otp.getOtp_value()));
        query.addCriteria(Criteria.where(OTP.OTP_TYPE_STR).is(otp.getOtp_type().name()));

        authserverdbMongoTemplate.findAndRemove(query, OTP.class, CollectionNames.WEB_USER_OTP.getCollectionName());
        LOG.info("archiveWebUserOTP() : removed otp object");

        LOG.info("archiveWebUserOTP() : archiving otp object");
        authserverdbMongoTemplate.save(otp, CollectionNames.WEB_USER_OTP_ARC.getCollectionName());
        LOG.info("archiveWebUserOTP() : archived otp object");

        LOG.info("archiveWebUserOTP() : exiting");
    }

    /**
     * This function is used to archive all otp objects into to web_user_otp_arc
     * object
     * 
     * @param userId
     */
    private void archiveWebUserOTPIfExist(final String userId) {
        LOG.info("archiveWebUserOTPIfExist() : entering userId :{}", userId);

        final Query query = new Query();
        query.addCriteria(Criteria.where(OTP.USER_ID).is(userId));

        final List<OTP> removedOTPs = authserverdbMongoTemplate.findAllAndRemove(query, OTP.class,
                CollectionNames.WEB_USER_OTP.getCollectionName());
        LOG.info("archiveWebUserOTPIfExist() : removed otp object :{}", removedOTPs.size());

        LOG.info("archiveWebUserOTPIfExist() : archiving otp object");
        authserverdbMongoTemplate.insert(removedOTPs, CollectionNames.WEB_USER_OTP_ARC.getCollectionName());
        LOG.info("archiveWebUserOTPIfExist() : archived otp object");

        LOG.info("archiveWebUserOTPIfExist() : exiting");
    }
}
