package com.uniken.authserver.repo.api;

import org.springframework.session.Session;

/**
 * This repo layer is used to manage mongo sessions.
 * 
 * @author Uday T
 */
public interface WebDevSessionRepo {

    /**
     * This method is used to archive the web dev session.
     */
    public void archiveWebDevSession(Session id);

    /**
     * Archive web dev session by id.
     *
     * @param id
     *            the id
     */
    public void archiveWebDevSessionById(final String id);
}
