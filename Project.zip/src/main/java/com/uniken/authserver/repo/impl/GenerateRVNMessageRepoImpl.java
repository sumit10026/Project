package com.uniken.authserver.repo.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.mongodb.client.result.UpdateResult;
import com.uniken.authserver.domains.GenerateRVNMessageLog;
import com.uniken.authserver.repo.api.GenerateRVNMessageRepo;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.enums.CollectionNames;
import com.uniken.domains.relid.notification.NotificationUserActionResponse;

@Repository
public class GenerateRVNMessageRepoImpl
        implements
        GenerateRVNMessageRepo {

    private static final Logger LOG = LoggerFactory.getLogger(GenerateRVNMessageRepoImpl.class);

    @Resource(name = Constants.RESOURCE_RELIDDB_MONGO_TEMPLATE)
    private MongoTemplate relIddbMongoTemplate;

    @Override
    public void insertLog(final GenerateRVNMessageLog generateRVNMessage) {

        LOG.info("insertLog() -> Inserting GenerateRVNMessage log");
        relIddbMongoTemplate.insert(generateRVNMessage, CollectionNames.GENERATE_RVN_MSG_LOGS.getCollectionName());

    }

    @Override
    public UpdateResult findAndSaveNotificationUserActionResponse(final String correlationID,
            final NotificationUserActionResponse notificationUserActionResponse) {
        LOG.info(
                "findAndSaveNotificationUserActionResponse() -> find and update GenerateRVNMessage log using correlation id");
        final Query query = new Query();
        query.addCriteria(Criteria.where(GenerateRVNMessageLog.CORRELATION_ID_STR).is(correlationID));

        final Update update = new Update();
        update.push(GenerateRVNMessageLog.NOTIFICATION_USER_ACTION_RESPONSE_STR, notificationUserActionResponse);

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update, GenerateRVNMessageLog.class,
                CollectionNames.GENERATE_RVN_MSG_LOGS.getCollectionName());

        LOG.debug(
                "findAndSaveNotificationUserActionResponse() : Updated the NotificationUserActionResponse element. No of element inserted {}",
                updateResult.getModifiedCount());

        return updateResult;
    }
}
