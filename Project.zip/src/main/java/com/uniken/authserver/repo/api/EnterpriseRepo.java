package com.uniken.authserver.repo.api;

import com.uniken.domains.auth.EnterpriseInfo;

public interface EnterpriseRepo {

    /**
     * Gets the enterprise by client id.
     *
     * @param clientId
     *            the client id
     * @return the enterprise by client id
     */
    EnterpriseInfo getEnterpriseByClientId(String clientId);

    /**
     * Gets the Enterprise by enterprise id
     * 
     * @param enterpriseId
     * @return
     */
    EnterpriseInfo getEnterpriseByEnterpriseId(String enterpriseId);

}
