package com.uniken.authserver.repo.api;

import com.uniken.domains.relid.session.SessionTicket;

public interface SessionTicketRepo {

    /**
     * Find session ticket by id.
     *
     * @param sessionTicketId
     *            the session ticket id
     * @return the session ticket
     */
    public SessionTicket findSessionTicketById(String sessionTicketId);

}
