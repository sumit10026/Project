package com.uniken.authserver.repo.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.BasicQuery;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.mongodb.client.result.UpdateResult;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.RegisteredAuthenticationModule;
import com.uniken.domains.auth.fido.FIDO2RegisteredAuthenticationModule;
import com.uniken.domains.enums.CollectionNames;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.UserBrowserStatus;
import com.uniken.domains.enums.WebUserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.enums.auth.AuthTypeStatus;
import com.uniken.domains.enums.web.WebIdUserStatus;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.user.UserAuthInfo;
import com.uniken.domains.relid.user.UserBrowser;
import com.uniken.domains.relid.user.UserIdLoginIdMapping;
import com.uniken.domains.relid.user.WebUserBrowserDetailsDTO;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.domains.user.vos.UserAuthInfoRegAuthModule;
import com.uniken.domains.user.vos.UserAuthInfoRegAuthModuleVo;
import com.uniken.domains.user.vos.WebUserDetails;
import com.uniken.domains.web.user.WebId;
import com.uniken.domains.web.user.vo.UserAuthInfoWebVo;

@Repository
public class UserAuthInfoRepoImpl
        implements
        UserAuthInfoRepo {

    private static final Logger LOG = LoggerFactory.getLogger(UserAuthInfoRepoImpl.class);

    @Resource(name = Constants.RESOURCE_RELIDDB_MONGO_TEMPLATE)
    private MongoTemplate relIddbMongoTemplate;

    @Override
    public UserAuthInfoVO fetchUserDetailsFromLoginId(final String loginId) {
        LOG.info("fetchUserDetailsFromLoginID () : fetch user details from loginID = {}", loginId);

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Document userAuthInfoDoc = relIddbMongoTemplate.findOne(
                Query.query(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(userIdLoginIdMapping.getUserId())),
                Document.class, CollectionNames.USER_AUTH_INFO.getCollectionName());

        if (userAuthInfoDoc == null) {
            return null;
        }

        return Constants.GSON.fromJson(Constants.GSON.toJson(userAuthInfoDoc), UserAuthInfoVO.class);
    }

    /**
     * Fetches userid from login Id
     * 
     * @param loginId
     * @return
     */
    @Override
    public UserIdLoginIdMapping findUserIdLoginIdMapping(final String loginId) {
        LOG.info("findUserIdLoginIdMapping() -> Find User Id Login Id Mapping in DB for login id : {}", loginId);

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserIdLoginIdMapping.LOGIN_ID_STR).is(loginId));
        return relIddbMongoTemplate.findOne(query, UserIdLoginIdMapping.class,
                CollectionNames.USERID_LOGINID_MAPPING.getCollectionName());
    }

    @Override
    public UpdateResult insertWebId(final String loginId, final WebId webId) {

        LOG.info("insertWebId() : Entered. Insert WebId element into the UserAuthInfo.");

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));

        final Update update = new Update();
        update.push(UserAuthInfoWebVo.WEBIDS_STR, webId);

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update, UserAuthInfoWebVo.class,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        LOG.debug("insertWebId() : Inserted the WebId element. No of element inserted {}",
                updateResult.getModifiedCount());

        return updateResult;
    }

    @Override
    public UpdateResult updateWebIdStatus(final String loginId, final String webUUID,
            final WebIdUserStatus webIdUserStatus) {

        LOG.info("updateWebIdStatus() : Entered. Update the Status of WebId into the UserAuthInfo.");

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));
        query.addCriteria(Criteria.where(UserAuthInfoWebVo.WEBIDS_STR + "." + WebId.WEBID_UUID_STR).is(webUUID));

        final Update update = new Update();
        update.set(UserAuthInfoWebVo.WEBIDS_STR + ".$." + WebId.WEBID_STATUS_STR, webIdUserStatus);

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update, UserAuthInfoWebVo.class,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        LOG.debug("updateWebIdStatus() : Update the WebId for UUID: {} and  Status to {}. No of element inserted {}",
                webUUID, webIdUserStatus, updateResult.getModifiedCount());

        return updateResult;
    }

    @Override
    public boolean hasFidoDeviceRegistered(final String username) {

        LOG.info("hasFidoDeviceRegisted() : Entered. Checking if user has fido device registered.");

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(username);

        if (userIdLoginIdMapping == null) {
            return false;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModuleVo.REG_AUTH_TYPE_STR).in(AuthType.FIDO.name()));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR + "."
                + RegisteredAuthenticationModule.AUTHTYPESTATUS_STR).in(AuthTypeStatus.REGISTERED.name()));

        return relIddbMongoTemplate.exists(query, CollectionNames.USER_AUTH_INFO.getCollectionName());
    }

    @Override
    public Set<String> hasFidoDeviceRegisteredTransport(final String username) {

        LOG.info("hasFidoDeviceRegisteredTransport() : Entered. Checking if user has fido device registered.");

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(username);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModuleVo.REG_AUTH_TYPE_STR).in(AuthType.FIDO.name()));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR + "."
                + RegisteredAuthenticationModule.AUTHTYPESTATUS_STR).in(AuthTypeStatus.REGISTERED.name()));

        query.fields().include(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR);
        query.fields().exclude("_id");

        @SuppressWarnings("unchecked")
        final List<Document> fidoDocs = (List<Document>) relIddbMongoTemplate
                .findOne(query, Document.class, CollectionNames.USER_AUTH_INFO.getCollectionName())
                .get(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR);

        if (fidoDocs == null || fidoDocs.isEmpty()) {
            return null;
        }

        final Set<String> fidoTransports = new LinkedHashSet<String>();
        for (final Document fido2Doc : fidoDocs) {

            if (fido2Doc.get(RegisteredAuthenticationModule.AUTHTYPE_STR).equals(AuthType.FIDO.name())) {
                fidoTransports.add(Constants.GSON
                        .fromJson(Constants.GSON.toJson(fido2Doc), FIDO2RegisteredAuthenticationModule.class)
                        .getTransport());
            }
        }

        return fidoTransports;
    }

    @Override
    public boolean hasAuthTypeRegistered(final String username, final AuthType authType) {

        LOG.info("getUserByAuthType() : Entered. Get User Details by username {} and AuthType {}.", username, authType);

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(username);

        if (userIdLoginIdMapping == null) {
            return false;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModuleVo.REG_AUTH_TYPE_STR).is(authType));
        if (authType.equals(AuthType.FIDO)) {
            query.addCriteria(Criteria.where(UserAuthInfoRegAuthModuleVo.REG_AUTH_TYPE_STR).in(AuthType.FIDO.name()));
            query.addCriteria(Criteria.where(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR + "."
                    + RegisteredAuthenticationModule.AUTHTYPESTATUS_STR).in(AuthTypeStatus.REGISTERED.name()));
        }
        return relIddbMongoTemplate.exists(query, CollectionNames.USER_AUTH_INFO.getCollectionName());
    }

    @Override
    public List<FIDO2RegisteredAuthenticationModule> getListOFIDO2fRegAuthModuleLoginId(final String loginId) {

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));

        query.fields().include(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR);
        query.fields().exclude("_id");

        @SuppressWarnings("unchecked")
        final List<Document> fidoDocs = (List<Document>) relIddbMongoTemplate
                .findOne(query, Document.class, CollectionNames.USER_AUTH_INFO.getCollectionName())
                .get(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR);

        if (fidoDocs == null || fidoDocs.isEmpty()) {
            return Collections.emptyList();
        }
        final List<FIDO2RegisteredAuthenticationModule> registeredAuthenticationModules = new ArrayList<>();

        for (final Document fido2Doc : fidoDocs) {

            if (fido2Doc.get(RegisteredAuthenticationModule.AUTHTYPE_STR).equals(AuthType.FIDO.name())) {
                registeredAuthenticationModules.add(Constants.GSON.fromJson(Constants.GSON.toJson(fido2Doc),
                        FIDO2RegisteredAuthenticationModule.class));
            }
        }

        return registeredAuthenticationModules;
    }

    @Override
    public UserAuthInfoVO fetchUserDetailsFromUserIdWebDeviceUuid(final String userId, final String webDeviceUuid) {
        LOG.info("fetchUserDetailsFromUserId () : fetch user details from userID = {}", userId);

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(userId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(userIdLoginIdMapping.getUserId())
                .andOperator(Criteria.where(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR + "."
                        + UserBrowser.WEB_DEVICE_UUID_STR).is(webDeviceUuid)));

        final Document userAuthInfoDoc = relIddbMongoTemplate.findOne(query, Document.class,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        if (userAuthInfoDoc == null) {
            return null;
        }

        return Constants.GSON.fromJson(Constants.GSON.toJson(userAuthInfoDoc), UserAuthInfoVO.class);
    }

    @Override
    public UserAuthInfoVO fetchUserDetailsFromUserId(final String userId) {
        LOG.info("fetchUserDetailsFromUserId () : fetch user details from userID = {}", userId);

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(userId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));

        final Document userAuthInfoDoc = relIddbMongoTemplate.findOne(query, Document.class,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        if (userAuthInfoDoc == null) {
            return null;
        }

        return Constants.GSON.fromJson(Constants.GSON.toJson(userAuthInfoDoc), UserAuthInfoVO.class);
    }

    @Override
    public UserAuthInfoVO updateUserAuthInfo(final UserAuthInfoVO userAuthInfoVO) {
        LOG.info("updateUserAuthInfo() -> updating UserAuthInfo record");
        return relIddbMongoTemplate.save(userAuthInfoVO, CollectionNames.USER_AUTH_INFO.getCollectionName());
    }

    @Override
    public List<Map<String, String>> fetchAssociatedUserWithWebDeviceUuid(final String webDeviceUuid) {
        LOG.info("fetchAssociatedUserWithWebDeviceUuid () : fetch associated user from webDeviceUuid = {}",
                webDeviceUuid);

        final List<Map<String, String>> usersList = new ArrayList<>();
        final Query query = new Query();

        query.addCriteria(Criteria.where(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR + "."
                + UserBrowser.WEB_DEVICE_UUID_STR).is(webDeviceUuid));

        final List<Document> userAuthInfoDoc = relIddbMongoTemplate.find(query, Document.class,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        userAuthInfoDoc.stream().forEach(doc -> {
            final Map<String, String> userMap = new HashMap<>();
            final UserAuthInfoVO userAuthInfoVO = Constants.GSON.fromJson(Constants.GSON.toJson(doc),
                    UserAuthInfoVO.class);

            userMap.put("userId", userAuthInfoVO.getUserId());

            // FIXME : Perform data processing at service level
            final String userName = PropertyConstants.UI_MESSAGES_PAGE_LOGIN_USERNAME_START_WITH_FIRSTNAME
                    ? userAuthInfoVO.getFirstName() + " " + userAuthInfoVO.getLastName()
                    : userAuthInfoVO.getLastName() + " " + userAuthInfoVO.getFirstName();
            userMap.put("userName", userName);

            final String email = StringUtils.isNotBlank(userAuthInfoVO.getEmailId()) ? userAuthInfoVO.getEmailId() : "";
            userMap.put("email", email);

            usersList.add(userMap);
        });

        return usersList;
    }

    @Override
    public UserAuthInfoRegAuthModuleVo fetchUserAuthInfoRegAuthModuleFromLoginId(final String loginId) {
        LOG.info("fetchUserDetailsFromLoginID () : fetch user details from loginID = {}", loginId);

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Document userAuthInfoDoc = relIddbMongoTemplate.findOne(
                Query.query(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(userIdLoginIdMapping.getUserId())),
                Document.class, CollectionNames.USER_AUTH_INFO.getCollectionName());

        if (userAuthInfoDoc == null) {
            return null;
        }

        return Constants.GSON.fromJson(Constants.GSON.toJson(userAuthInfoDoc), UserAuthInfoRegAuthModuleVo.class);
    }

    @Override
    public UpdateResult updateUserAuthInfoDoc(final String loginId, final String fieldName, final Object value) {
        LOG.info("updateUserAuthInfoDoc() : Entered.");
        LOG.debug("updateUserAuthInfoDoc() : Entered. {}, {}.", loginId, fieldName);

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));

        final Update update = new Update();
        update.set(fieldName, value);

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        LOG.debug("updateUserAuthInfoDoc() : No of element updated {}", updateResult.getModifiedCount());

        return updateResult;
    }

    @Override
    public UpdateResult activateUser(final String loginId, final RelIdUserStatus userCurrentStatus,
            final boolean webOnly, final Set<AuthType> authTypes, final String mobileNumber, final String email) {

        LOG.info("activateUser() : Entered. User: {}", loginId);

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));

        final Update update = new Update();

        if (webOnly) {
            update.set(UserAuthInfoVO.WEB_ONLY, true);
            update.set(UserAuthInfoVO.PREVIOUS_STATUS, userCurrentStatus);
            update.set(UserAuthInfoVO.USER_STATUS_STR, RelIdUserStatus.ACTIVE);
        }

        if (!Utils.isNullOrEmpty(mobileNumber)) {
            update.set(UserAuthInfoVO.MOBILE_NUMBER_STR, mobileNumber);
        }

        if (!Utils.isNullOrEmpty(email)) {
            update.set(UserAuthInfoVO.EMAIL_ID_STR, email);
        }

        if (!authTypes.contains(AuthType.FIDO)) {
            update.unset(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR);
        }

        update.set(UserAuthInfoRegAuthModuleVo.REG_AUTH_TYPE_STR, authTypes);

        final Date currentTs = new Date();
        update.set(UserAuthInfoVO.UPDATE_TS_STR, currentTs);

        return relIddbMongoTemplate.updateFirst(query, update, CollectionNames.USER_AUTH_INFO.getCollectionName());
    }

    @Override
    public UpdateResult updateWebUserAttemptCounter(final String loginId, final List<Integer> attemptCounters) {
        LOG.info("updateWebUserAttemptCounter() -> Updating user attempt counter: {}", loginId);

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));

        final Update update = new Update();
        update.set(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.WEB_ATTEMPT_COUNTER, attemptCounters);

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        LOG.debug("updateWebUserAttemptCounter() -> Updated user attempt counter: {}. No of elements updated: {}",
                loginId, updateResult.getModifiedCount());

        return updateResult;
    }

    @Override
    public UpdateResult updateWebUserAuthGenerationAttemptCounter(final String loginId,
            final Map<String, Integer> authGenerationAttemptsCounter) {
        LOG.info("updateWebUserAuthGenerationAttemptCounter() -> Updating auth generation attempt counter: {}",
                loginId);

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));

        final Update update = new Update();
        update.set(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.AUTH_GENERATION_ATTEMPT_COUNTER,
                authGenerationAttemptsCounter);

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        LOG.debug(
                "updateWebUserAuthGenerationAttemptCounter() -> Updated auth generation attempt counter: {}. No of elements updated: {}",
                loginId, updateResult.getModifiedCount());

        return updateResult;
    }

    @Override
    public UpdateResult blockWebUser(final WebUserDetails webUserDetails, final String loginId) {
        LOG.info("blockWebUser() -> Blocking web user: {}", loginId);

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));

        final Update update = new Update();
        update.set(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.WEB_ATTEMPT_COUNTER,
                webUserDetails.getWebAttemptCounter());
        update.set(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.WEB_USER_STATUS, WebUserStatus.BLOCKED);
        update.set(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.BLOCKED_TS, new Date());
        update.set(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.LAST_BLOCKED_METHOD,
                webUserDetails.getLastBlockedMethod());
        update.set(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.LAST_BLOCKED_INTERVAL,
                webUserDetails.getLastBlockedInterval());

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        LOG.debug("blockWebUser() : Blocked web user: {}. No of elements updated: {}", loginId,
                updateResult.getModifiedCount());

        return updateResult;
    }

    @Override
    public UpdateResult unblockWebUser(final WebUserDetails webUserDetails, final String loginId) {
        LOG.info("unblockWebUser() -> Unblocking web user: {}", loginId);

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));

        final Update update = new Update();
        update.set(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.WEB_ATTEMPT_COUNTER,
                webUserDetails.getWebAttemptCounter());
        update.set(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.WEB_USER_STATUS, WebUserStatus.ACTIVE);
        update.set(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.LAST_BLOCKED_INTERVAL, 0);

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        LOG.debug("unblockWebUser() : Unblocked web user: {}. No of elements updated: {}", loginId,
                updateResult.getModifiedCount());

        return updateResult;
    }

    @Override
    public UpdateResult updateWebUserBrowserStatus(final String loginId, final String webDeviceUuid,
            final WebUserStatus status) {
        LOG.info("blockWebUserBrowser() -> block Web User Browser with user id: {}", loginId);

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));
        query.addCriteria(Criteria.where(UserAuthInfo.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR + "."
                + UserBrowser.WEB_DEVICE_UUID_STR).is(webDeviceUuid));

        final Update update = new Update();
        update.set(UserAuthInfo.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR + ".$." + UserBrowser.STATUS,
                status);

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        LOG.debug("blockWebUserBrowser() : Block web user browser: {}. No of elements updated: {}", loginId,
                updateResult.getModifiedCount());

        return updateResult;
    }

    @Override
    public List<UserBrowser> getListOfUserBrowsers(final String userId) {

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(userId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Document webDetails = (Document) relIddbMongoTemplate
                .findOne(Query.query(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId())),
                        Document.class, CollectionNames.USER_AUTH_INFO.getCollectionName())
                .get(UserAuthInfo.WEB_USER_DETAILS);

        @SuppressWarnings("unchecked")
        final List<Document> browserDocs = (List<Document>) webDetails.get(WebUserDetails.BROWSERS_STR);

        if (browserDocs == null || browserDocs.isEmpty()) {
            return Collections.emptyList();
        }
        final List<UserBrowser> userBrowsers = new ArrayList<>();

        for (final Document usrBrowser : browserDocs) {

            userBrowsers.add(Constants.GSON.fromJson(Constants.GSON.toJson(usrBrowser), UserBrowser.class));
        }

        return userBrowsers;
    }

    @Override
    public List<WebUserBrowserDetailsDTO> getListOfBrowsers(final String userId) {

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(userId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Document webDetails = (Document) relIddbMongoTemplate
                .findOne(Query.query(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId())),
                        Document.class, CollectionNames.USER_AUTH_INFO.getCollectionName())
                .get(UserAuthInfo.WEB_USER_DETAILS);

        @SuppressWarnings("unchecked")
        final List<Document> browserDocs = (List<Document>) webDetails.get(WebUserDetails.BROWSERS_STR);

        if (browserDocs == null || browserDocs.isEmpty()) {
            return Collections.emptyList();
        }
        final List<WebUserBrowserDetailsDTO> userBrowsers = new ArrayList<>();

        for (final Document usrBrowser : browserDocs) {

            final Document webmaster = relIddbMongoTemplate.findOne(
                    Query.query(Criteria.where(WebDevMaster.WEB_ID_STR)
                            .is(usrBrowser.get(UserBrowser.WEB_DEVICE_UUID_STR))),
                    Document.class, CollectionNames.WEB_DEV_MASTER.getCollectionName());

            userBrowsers.add(new WebUserBrowserDetailsDTO(
                    Constants.GSON.fromJson(Constants.GSON.toJson(usrBrowser), UserBrowser.class),
                    Constants.GSON.fromJson(Constants.GSON.toJson(webmaster), WebDevMaster.class)));
        }

        userBrowsers.sort((browser1, browser2) -> browser2.getUserBrowser().getLastLoginTs()
                .compareTo(browser1.getUserBrowser().getLastLoginTs()));

        return userBrowsers;
    }

    @Override
    public Page<UserBrowser> getListOfUserBrowsers(final String loginId, final String filter, final Pageable pageable) {

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final String query = "{ \"user_id\" : \"" + userIdLoginIdMapping.getUserId() + "\"}";
        final String fields = "{ \"web_user_details.browsers\" : { \"$slice\" : [ " + pageable.getOffset() + ","
                + pageable.getPageSize() + "] } }";

        final BasicQuery searchQuery = new BasicQuery(query, fields);

        final Document webDetails = (Document) relIddbMongoTemplate
                .findOne(searchQuery, Document.class, CollectionNames.USER_AUTH_INFO.getCollectionName())
                .get(UserAuthInfo.WEB_USER_DETAILS);

        @SuppressWarnings("unchecked")
        final List<Document> browserDocs = (List<Document>) webDetails.get(WebUserDetails.BROWSERS_STR);

        if (browserDocs == null || browserDocs.isEmpty()) {
            return null;
        }
        final List<UserBrowser> userBrowsers = new ArrayList<>();

        for (final Document usrBrowser : browserDocs) {

            userBrowsers.add(Constants.GSON.fromJson(Constants.GSON.toJson(usrBrowser), UserBrowser.class));
        }

        return new PageImpl<UserBrowser>(userBrowsers, pageable, userBrowsers.size());
    }

    @Override
    public UpdateResult deleteWebUserBrowser(final String loginId, final String webDeviceUuid) {

        LOG.info("deleteWebUserBrowser() -> deleteWebUserBrowser web user: {}", loginId);

        UpdateResult updateResult = null;
        int count = 0; // Tie secure cookie (remembered browser) to FIDO platform

        final UserAuthInfoVO user = fetchUserDetailsFromLoginId(loginId);

        if (user != null) {
            final List<UserBrowser> userBrowsers = new ArrayList<>();
            UserBrowser deletedBrowser = null;
            for (final UserBrowser browser : user.getWebUserDetails().getBrowsers()) {
                if (browser.getWebDeviceUuid().equals(webDeviceUuid)) {
                    deletedBrowser = browser;
                } else {
                    userBrowsers.add(browser);
                }
            }

            if (deletedBrowser != null) {
                user.getWebUserDetails().getArchiveBrowsers().add(deletedBrowser);
                deletedBrowser.setStatus(UserBrowserStatus.INACTIVE.name());
                deletedBrowser.setArchivedTS(new Date());

                final Query query = new Query();
                query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(user.getUserId()));

                final Update update = new Update();
                update.set(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.ARCHIVE_BROWSERS,
                        user.getWebUserDetails().getArchiveBrowsers());
                update.set(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR, userBrowsers);

                updateResult = relIddbMongoTemplate.updateFirst(query, update,
                        CollectionNames.USER_AUTH_INFO.getCollectionName());

                LOG.debug("deleteWebUserBrowser() : Delete web user browser: {}. No of elements updated: {}", loginId,
                        updateResult.getModifiedCount());
                // Tie secure cookie (remembered browser) to FIDO platform
                // test this scenario after TASK : prevent duplication
                if (deletedBrowser.getAuthenticatorUuid() != null) {
                    for (final UserBrowser browser : user.getWebUserDetails().getBrowsers()) {
                        if (browser.getAuthenticatorUuid() != null
                                && browser.getAuthenticatorUuid().equals(deletedBrowser.getAuthenticatorUuid())) {
                            count += 1;
                        }
                    }
                    if (count == 1) {
                        deleteRegisteredAuthModule(loginId, deletedBrowser.getAuthenticatorUuid());
                    }
                }

            }
        }

        return updateResult;
    }

    @Override
    public UpdateResult unRememberWebUserBrowser(final String loginId, final String webDeviceUuid) {

        LOG.info("unRememberWebUserBrowser() -> Un-remember web user browser. User: {}", loginId);

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));
        query.addCriteria(Criteria.where(UserAuthInfo.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR + "."
                + UserBrowser.WEB_DEVICE_UUID_STR).is(webDeviceUuid));

        final Document doc = (Document) relIddbMongoTemplate
                .findOne(query, Document.class, CollectionNames.USER_AUTH_INFO.getCollectionName())
                .get(UserAuthInfo.WEB_USER_DETAILS);

        final Document userBrowser = ((List<Document>) doc.get(WebUserDetails.BROWSERS_STR)).get(0);

        final Update update = new Update();

        update.push(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.ARCHIVE_BROWSERS, userBrowser);
        update.set(UserAuthInfo.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR + ".$." + UserBrowser.STATUS,
                WebUserStatus.INACTIVE);

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        LOG.debug("unRememberWebUserBrowser() : Un-remember web user browser. User: {}. No of elements updated: {}",
                loginId, updateResult.getModifiedCount());

        return updateResult;
    }

    @Override
    public boolean deleteRegisteredAuthModule(final String loginId, final String authenticatorUuid) {

        LOG.info("deleteRegisteredAuthModule() -> Deleting Registered Auth Moule for user : {}", loginId);

        UpdateResult updateResult = null;

        final List<FIDO2RegisteredAuthenticationModule> regAuthModuleList = fetchRegisteredAuthenticationModuleFromLoginId(
                loginId);

        if (!CollectionUtils.isEmpty(regAuthModuleList)) {
            final List<RegisteredAuthenticationModule> userModules = new ArrayList<>();
            FIDO2RegisteredAuthenticationModule deletedModule = null;
            for (final FIDO2RegisteredAuthenticationModule module : regAuthModuleList) {
                if (module.getAuthenticatorUuid().equals(authenticatorUuid)) {
                    deletedModule = module;
                } else {
                    userModules.add(module);
                }
            }
            // If browser was already present (user had already remembered the
            // browser) and registered a FIDO platform authenticator later
            // (using Register FIDO screen, we added only the mapping
            // information authenticator_uuid and added_for_authenticator
            // (false)),
            // then just remove the fields authenticator_uuid and
            // added_for_authenticator for that browser, otherwise delete the
            // browser.

            if (deletedModule.getTransport().equalsIgnoreCase("internal")) {
                final List<UserBrowser> uBs = getListOfUserBrowsers(loginId);
                for (final UserBrowser browser : uBs) {
                    if (browser.getAuthenticatorUuid() != null
                            && browser.getAuthenticatorUuid().equals(authenticatorUuid)
                            && !browser.isAddedForAuthenticator()) {
                        LOG.info(
                                "deleteRegisteredAuthModule() -> Deleting Resident Registered Auth Moule mapping from user browsers");
                        LOG.info(
                                "deleteRegisteredAuthModule() -> Deleting Resident Registered Auth Moule mapping from user browsers "
                                        + browser.getAuthenticatorUuid() + ", " + browser.getWebDeviceUuid());

                        final Query query = new Query();
                        query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(loginId));
                        query.addCriteria(
                                Criteria.where(UserAuthInfo.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR + "."
                                        + UserBrowser.WEB_DEVICE_UUID_STR).is(browser.getWebDeviceUuid()));
                        final Update update = new Update();
                        // update.unset(UserBrowser.AUTHENTICATOR_UUID);

                        update.unset(UserAuthInfo.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR + ".$."
                                + UserBrowser.AUTHENTICATOR_UUID);
                        update.unset(UserAuthInfo.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR + ".$."
                                + UserBrowser.ADDED_FOR_AUTHENTICATOR);
                        updateResult = relIddbMongoTemplate.updateFirst(query, update,
                                CollectionNames.USER_AUTH_INFO.getCollectionName());

                    } else if (browser.getAuthenticatorUuid() != null
                            && browser.getAuthenticatorUuid().equals(authenticatorUuid)
                            && browser.isAddedForAuthenticator()) {
                        deleteWebUserBrowser(loginId, browser.getWebDeviceUuid());
                    }
                }
            }

            if (deletedModule != null) {

                final List<FIDO2RegisteredAuthenticationModule> archivedRegAuthModuleList = fetchArchivedRegisteredAuthenticationModuleFromLoginId(
                        loginId);
                deletedModule.setAuthTypeStatus(AuthTypeStatus.DELETED);
                deletedModule.setArchivedTS(new Date());
                archivedRegAuthModuleList.add(deletedModule);

                final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

                if (userIdLoginIdMapping == null) {
                    return false;
                }

                Set<AuthType> regAuthTypes = null;
                if (userModules.isEmpty()) {
                    regAuthTypes = fetchUserAuthInfoRegAuthModuleFromLoginId(loginId).getRegAuthTypes();
                    regAuthTypes.remove(AuthType.FIDO);
                }

                final Query query = new Query();
                query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));

                // FIXME : Update the element directly into the array, without
                // fetching the complete array.
                final Update update = new Update();
                update.set(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.ARCHIVE_REG_AUTHENTICATION_MODULE,
                        archivedRegAuthModuleList);

                update.set(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR, userModules);
                if (regAuthTypes != null) {
                    update.set(UserAuthInfoRegAuthModuleVo.REG_AUTH_TYPE_STR, regAuthTypes);
                }

                updateResult = relIddbMongoTemplate.updateFirst(query, update,
                        CollectionNames.USER_AUTH_INFO.getCollectionName());

                LOG.debug(
                        "deleteRegisteredAuthModule() : Deleting Registered Auth Moule for user: {}. No of elements updated: {}",
                        loginId, updateResult.getModifiedCount());
            }
        }

        return updateResult != null && updateResult.getModifiedCount() > 0 ? true : false;
    }

    @Override
    public boolean updateRegAuthFactorStatus(final String loginId, final String authenticatorUuid,
            final boolean isEnabledState) {

        LOG.info("updateRegAuthFactorStatus() -> updating Registered Auth Module for user : {}", loginId);

        FIDO2RegisteredAuthenticationModule module = null;

        final FIDO2RegisteredAuthenticationModule filteredModule = fetchRegisteredAuthenticationModuleFromLoginIdAndAuthenticatorUuid(
                loginId, authenticatorUuid);

        if (filteredModule != null) {

            final AuthTypeStatus currentAuthTypeStatus = filteredModule.getAuthTypeStatus();
            final AuthTypeStatus lastAuthTypeStatus = filteredModule.getLastAuthTypeStatus();
            final AuthTypeStatus updatedAuthTypeStatus = isEnabledState ? lastAuthTypeStatus : AuthTypeStatus.DISABLED;

            filteredModule.setAuthTypeStatus(updatedAuthTypeStatus);
            filteredModule.setLastAuthTypeStatus(currentAuthTypeStatus);

            final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

            if (userIdLoginIdMapping == null) {
                return false;
            }

            final Query query = new Query();
            query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));
            query.addCriteria(Criteria.where(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR + "."
                    + FIDO2RegisteredAuthenticationModule.AUTHENTICATOR_UUID).is(authenticatorUuid));
            query.fields().include(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + ".$");

            final Update update = new Update();

            update.set(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR + ".$."
                    + RegisteredAuthenticationModule.AUTHTYPESTATUS_STR, updatedAuthTypeStatus);
            update.set(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR + ".$."
                    + RegisteredAuthenticationModule.LAST_AUTH_TYPE_STATUS, currentAuthTypeStatus);

            module = relIddbMongoTemplate.findAndModify(query, update, FIDO2RegisteredAuthenticationModule.class,
                    CollectionNames.USER_AUTH_INFO.getCollectionName());

            LOG.debug(
                    "updateRegAuthFactorStatus() : Updating Auth type status for Module for user: {}. Module Id updated: {}",
                    loginId, module.getAuthenticatorUuid());
        }

        return module != null ? true : false;
    }

    @Override
    public FIDO2RegisteredAuthenticationModule fetchRegisteredAuthenticationModuleFromLoginIdAndAuthenticatorUuid(
            final String loginId, final String authenticatorUuid) {
        LOG.info(
                "fetchRegisteredAuthenticationModuleFromLoginIdAndAuthenticatorUuid () : fetch registered auth module from loginID = {}",
                loginId);

        FIDO2RegisteredAuthenticationModule regModule = null;

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + "."
                + FIDO2RegisteredAuthenticationModule.AUTHENTICATOR_UUID).is(authenticatorUuid));
        query.fields().include(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + ".$");

        @SuppressWarnings("unchecked")
        final List<Document> fidoDocs = (List<Document>) relIddbMongoTemplate
                .findOne(query, Document.class, CollectionNames.USER_AUTH_INFO.getCollectionName())
                .get(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR);

        if (fidoDocs == null || fidoDocs.isEmpty()) {
            return null;
        }

        regModule = Constants.GSON.fromJson(Constants.GSON.toJson(fidoDocs.get(0)),
                FIDO2RegisteredAuthenticationModule.class);

        return regModule;
    }

    @Override
    public List<FIDO2RegisteredAuthenticationModule> fetchRegisteredAuthenticationModuleFromLoginId(
            final String loginId) {
        LOG.info("fetchRegisteredAuthenticationModuleFromLoginId () : fetch registered auth module from loginID = {}",
                loginId);

        final List<FIDO2RegisteredAuthenticationModule> regModuleList = new ArrayList<>();

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));
        query.fields().include(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR);

        @SuppressWarnings("unchecked")
        final List<Document> fidoDocs = (List<Document>) relIddbMongoTemplate
                .findOne(query, Document.class, CollectionNames.USER_AUTH_INFO.getCollectionName())
                .get(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR);

        if (fidoDocs == null || fidoDocs.isEmpty()) {
            return null;
        }

        for (final Document fido2Doc : fidoDocs) {
            regModuleList.add(Constants.GSON.fromJson(Constants.GSON.toJson(fido2Doc),
                    FIDO2RegisteredAuthenticationModule.class));
        }

        return regModuleList;
    }

    @Override
    public List<FIDO2RegisteredAuthenticationModule> fetchArchivedRegisteredAuthenticationModuleFromLoginId(
            final String loginId) {
        LOG.info(
                "fetchArchivedRegisteredAuthenticationModuleFromLoginId () : fetch registered auth module from loginID = {}",
                loginId);

        final List<FIDO2RegisteredAuthenticationModule> archivedRegModuleList = new ArrayList<>();

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return null;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));
        query.fields()
                .include(UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.ARCHIVE_REG_AUTHENTICATION_MODULE);
        query.fields().exclude("_id");

        @SuppressWarnings("unchecked")
        final List<Document> fidoDocs = ((List<Document>) ((Document) relIddbMongoTemplate
                .findOne(query, Document.class, CollectionNames.USER_AUTH_INFO.getCollectionName())
                .get(UserAuthInfoVO.WEB_USER_DETAILS)).get(WebUserDetails.ARCHIVE_REG_AUTHENTICATION_MODULE));

        if (fidoDocs == null || fidoDocs.isEmpty()) {
            return archivedRegModuleList;
        }

        for (final Document fido2Doc : fidoDocs) {
            archivedRegModuleList.add(Constants.GSON.fromJson(Constants.GSON.toJson(fido2Doc),
                    FIDO2RegisteredAuthenticationModule.class));
        }

        return archivedRegModuleList;
    }

    @Override
    public boolean updateMobileNumber(final String loginId, final String mobileNumber) {
        LOG.info("updateMobileNumber() : Updating user's mobile number.");

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return false;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));

        final Update update = new Update();
        update.set(UserAuthInfo.MOBILE_NUMBER_STR, mobileNumber);

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        LOG.debug("updateMobileNumber() : No of element updated {}", updateResult.getModifiedCount());

        return updateResult.getModifiedCount() > 0;
    }

    @Override
    public boolean updateEmailId(final String loginId, final String emailId) {
        LOG.info("updateEmailId() : Updating user's email id.");

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return false;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfo.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));

        final Update update = new Update();
        update.set(UserAuthInfo.EMAIL_ID_STR, emailId);

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        LOG.debug("updateEmailId() : No of element updated {}", updateResult.getModifiedCount());

        return updateResult.getModifiedCount() > 0;
    }

    @Override
    public boolean isFidoDeviceRegisteredByTypeFromUserId(final String loginId, final String fidoType,
            final String authenticatorUuid) {
        LOG.info(
                "fetchRegisteredAuthenticationModuleFromLoginIdAndAuthenticatorUuid () : fetch registered auth module from loginID = {}",
                loginId);

        final UserIdLoginIdMapping userIdLoginIdMapping = findUserIdLoginIdMapping(loginId);

        if (userIdLoginIdMapping == null) {
            return false;
        }

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(userIdLoginIdMapping.getUserId()));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + "."
                + FIDO2RegisteredAuthenticationModule.TRANSPORT_STR).is(fidoType));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + "."
                + FIDO2RegisteredAuthenticationModule.AUTHENTICATOR_UUID).is(authenticatorUuid));
        query.fields().include(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + ".$");

        final Document fidoResultMap = relIddbMongoTemplate.findOne(query, Document.class,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        @SuppressWarnings("unchecked")
        final List<Document> fidoDocs = fidoResultMap == null ? null
                : (List<Document>) fidoResultMap.get(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR);

        if (fidoDocs == null || fidoDocs.isEmpty()) {
            return false;
        }

        /*
         * regModule =
         * Constants.GSON.fromJson(Constants.GSON.toJson(fidoDocs.get(0)),
         * FIDO2RegisteredAuthenticationModule.class);
         */

        return true;
    }

    @Override
    public UserAuthInfoVO fetchUserDetailsFromMobileNumber(final String mobileNumber) {

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.MOBILE_NUMBER_STR).is(mobileNumber)
                .and(UserAuthInfo.USER_STATUS_STR).ne("DELETED"));
        query.fields().include(UserAuthInfoVO.USER_ID_STR);
        final Document userAuthInfoDoc = relIddbMongoTemplate.findOne(query, Document.class,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        if (userAuthInfoDoc == null) {
            return null;
        }

        return Constants.GSON.fromJson(Constants.GSON.toJson(userAuthInfoDoc), UserAuthInfoVO.class);

    }

    @Override
    public UserAuthInfoVO fetchUserDetailsFromEmailId(final String emailId) {
        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.EMAIL_ID_STR).is(emailId).and(UserAuthInfo.USER_STATUS_STR)
                .ne("DELETED"));

        query.fields().include(UserAuthInfoVO.USER_ID_STR);

        final Document userAuthInfoDoc = relIddbMongoTemplate.findOne(query, Document.class,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        if (userAuthInfoDoc == null) {
            return null;
        }

        return Constants.GSON.fromJson(Constants.GSON.toJson(userAuthInfoDoc), UserAuthInfoVO.class);
    }
}
