package com.uniken.authserver.repo.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.NotImplementedException;
import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.aggregation.Aggregation;
import org.springframework.data.mongodb.core.aggregation.AggregationResults;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.mastercard.ess.fido2.ctap.AttestationConveyancePreference;
import com.mastercard.ess.fido2.ctap.AuthenticatorTransport;
import com.mastercard.ess.fido2.database.FIDO2RegistrationEntity;
import com.mastercard.ess.fido2.database.FIDO2RegistrationRepository;
import com.mastercard.ess.fido2.database.RegistrationStatus;
import com.mongodb.client.result.UpdateResult;
import com.uniken.authserver.exception.InvalidSecureCookieException;
import com.uniken.authserver.exception.InvalidUserException;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.services.api.SecureCookieService;
import com.uniken.authserver.services.api.SessionService;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.authserver.utility.AuthenticationUtils;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.RegisteredAuthenticationModule;
import com.uniken.domains.auth.fido.AuthenticatorAttestationResponse;
import com.uniken.domains.auth.fido.FIDO2RegisteredAuthenticationModule;
import com.uniken.domains.auth.fido.PublicKeyCredentialCreationOptions;
import com.uniken.domains.enums.CollectionNames;
import com.uniken.domains.enums.UserBrowserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.enums.auth.AuthTypeStatus;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.user.UserAuthInfo;
import com.uniken.domains.relid.user.UserBrowser;
import com.uniken.domains.relid.user.UserIdLoginIdMapping;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.domains.user.vos.SecureCookie;
import com.uniken.domains.user.vos.UserAuthInfoRegAuthModule;
import com.uniken.domains.user.vos.UserAuthInfoRegAuthModuleVo;
import com.uniken.domains.user.vos.WebUserDetails;
import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;

/**
 * Concrete implementation of FIDO2 registration interfaces
 * 
 * @author Uniken Inc.
 */
@Repository("FIDO2RegistrationRepository")
public class FIDO2RegistrationRepositoryImpl
        implements
        FIDO2RegistrationRepository {

    private static final Logger LOG = LoggerFactory.getLogger(FIDO2RegistrationRepositoryImpl.class);

    private static final String NOT_IMPLEMENTED_MSG = "Functionality Not Implemented.";

    @Resource(name = "relIddbMongoTemplate")
    private MongoTemplate relIddbMongoTemplate;

    @Autowired
    private UserAuthInfoRepo userAuthInfoRepo;

    @Autowired
    private WebDevMasterService webDevMasterService;

    @Autowired
    private SessionService sessionService;

    @Autowired
    SecureCookieService secureCookieService;

    @Override
    public Optional<FIDO2RegistrationEntity> findByPublicKeyId(final String publicKeyId) {
        LOG.info("findByPublicKeyId() entering");

        final String loginId = Utils.getUsernameFromSecurityContextOrRequestContext();

        if (loginId == null) {
            LOG.error("findByPublicKeyId() : loginId is null");
            return Optional.empty();
        }

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("findByPublicKeyId() : mapping object not found for loginId :{}", loginId);
            return Optional.empty();
        }

        final String username = mapping.getUserId();

        final Aggregation agg = Aggregation.newAggregation(
                Aggregation.match(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(username)),
                Aggregation.match(Criteria.where(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + "."
                        + FIDO2RegisteredAuthenticationModule.REGISTRATIONKEYID_STR).is(publicKeyId)),

                Aggregation.unwind("$" + UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR),
                Aggregation.project().andInclude(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR,
                        UserAuthInfoRegAuthModule.REG_AUTH_TYPE_STR, UserAuthInfo.USER_ID_STR),
                Aggregation.match(Criteria
                        .where(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + "."
                                + FIDO2RegisteredAuthenticationModule.REGISTRATIONKEYID_STR)
                        .is(publicKeyId)),
                Aggregation.match(Criteria.where(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + "."
                        + RegisteredAuthenticationModule.AUTHTYPE_STR).is(AuthType.FIDO.name())));

        final AggregationResults<UserAuthInfoRegAuthModule> aggregationResults = relIddbMongoTemplate.aggregate(agg,
                CollectionNames.USER_AUTH_INFO.getCollectionName(), UserAuthInfoRegAuthModule.class);

        final FIDO2RegisteredAuthenticationModule regAuthModule = (FIDO2RegisteredAuthenticationModule) aggregationResults
                .getUniqueMappedResult().getRegAuthModule();

        return Optional.ofNullable(getFido2RegistrationEntity(regAuthModule, username));
    }

    @Override
    public Optional<FIDO2RegistrationEntity> findByUsername(final String loginId) {

        LOG.info("FIDO2RegistrationRepoImpl -> findByUsername() entering");

        // TODO: Not Tested

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("findByUsername() : mapping object not found for loginId :{}", loginId);
            return Optional.empty();
        }

        final String username = mapping.getUserId();

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(username));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + "."
                + RegisteredAuthenticationModule.AUTHTYPE_STR).is(AuthType.FIDO.name()));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + "."
                + RegisteredAuthenticationModule.AUTHTYPESTATUS_STR).is(AuthTypeStatus.REGISTERED.name()));

        final FIDO2RegisteredAuthenticationModule authenticationModule = relIddbMongoTemplate.findOne(query,
                FIDO2RegisteredAuthenticationModule.class, CollectionNames.USER_AUTH_INFO.getCollectionName());

        return Optional.ofNullable(getFido2RegistrationEntity(authenticationModule, username));
    }

    @Override
    public Optional<FIDO2RegistrationEntity> findByUserId(final String userId) {
        LOG.info("FIDO2RegistrationRepoImpl -> findByUserId() entering");

        // TODO: Not Tested

        final String loginId = Utils.getUsernameFromSecurityContextOrRequestContext();

        if (loginId == null) {
            LOG.error("findByUserId() : loginId is null");
            return Optional.empty();
        }
        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("findByUserId() : mapping object not found for loginId :{}", loginId);
            return Optional.empty();
        }

        final String username = mapping.getUserId();

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(username));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + "."
                + FIDO2RegisteredAuthenticationModule.USERID_STR).is(userId));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + "."
                + RegisteredAuthenticationModule.AUTHTYPE_STR).is(AuthType.FIDO.name()));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + "."
                + RegisteredAuthenticationModule.AUTHTYPESTATUS_STR).is(AuthTypeStatus.REGISTERED.name()));

        final FIDO2RegisteredAuthenticationModule authenticationModule = relIddbMongoTemplate.findOne(query,
                FIDO2RegisteredAuthenticationModule.class, CollectionNames.USER_AUTH_INFO.getCollectionName());

        return Optional.ofNullable(getFido2RegistrationEntity(authenticationModule, username));
    }

    @Override
    public Optional<FIDO2RegistrationEntity> findByChallenge(final String challenge) {

        LOG.info("FIDO2RegistrationRepoImpl -> findByChallenge() entering");

        // TODO: Not Tested

        final String loginId = Utils.getUsernameFromSecurityContextOrRequestContext();

        if (loginId == null) {
            LOG.error("findByChallenge() : loginId is null");
            return Optional.empty();
        }

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("findByChallenge() : mapping object not found for loginId :{}", loginId);
            return Optional.empty();
        }

        final String username = mapping.getUserId();

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(username));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + "."
                + FIDO2RegisteredAuthenticationModule.CHALLENGE_STR).is(challenge));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + "."
                + RegisteredAuthenticationModule.AUTHTYPE_STR).is(AuthType.FIDO.name()));

        final FIDO2RegisteredAuthenticationModule authenticationModule = relIddbMongoTemplate.findOne(query,
                FIDO2RegisteredAuthenticationModule.class, CollectionNames.USER_AUTH_INFO.getCollectionName());

        return Optional.ofNullable(getFido2RegistrationEntity(authenticationModule, username));
    }

    @Override
    public List<FIDO2RegistrationEntity> findAllByUsernameAndStatus(final String loginId, final String status) {
        LOG.info("FIDO2RegistrationRepoImpl -> findAllByUsernameAndStatus() entering");

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("findAllByUsernameAndStatus() : mapping object not found for loginId :{}", loginId);
            return Collections.emptyList();
        }

        final String username = mapping.getUserId();

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(username));

        final UserAuthInfoRegAuthModuleVo authenticationModules = relIddbMongoTemplate.findOne(query,
                UserAuthInfoRegAuthModuleVo.class, CollectionNames.USER_AUTH_INFO.getCollectionName());

        if (authenticationModules == null || authenticationModules.getRegAuthModule() == null
                || authenticationModules.getRegAuthModule().isEmpty()) {
            return Collections.emptyList();
        }

        final List<RegisteredAuthenticationModule> regAuthModule = authenticationModules.getRegAuthModule();
        return getFido2RegistrationEntities(regAuthModule, username, status);
    }

    @Override
    public List<FIDO2RegistrationEntity> findAllByUsernameAndDomainAndAuthTypeAndStatus(final String loginId,
            final String rpDomainName, final String authType, final String status) {
        LOG.info(
                "FIDO2RegistrationRepoImpl -> findAllByUsernameAndDomainAndAuthTypeAndStatus() entering , authType:{}, status:{},",
                authType, status);

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("findAllByUsernameAndDomainAndAuthTypeAndStatus() : mapping object not found for loginId :{}",
                    loginId);
            return Collections.emptyList();
        }

        final String username = mapping.getUserId();

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(username));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR + "."
                + FIDO2RegisteredAuthenticationModule.DOMAIN_STR).is(rpDomainName));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR + "."
                + RegisteredAuthenticationModule.AUTHTYPESTATUS_STR).is(status));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR + "."
                + RegisteredAuthenticationModule.AUTHTYPE_STR).is(authType));

        final UserAuthInfoRegAuthModuleVo authenticationModules = relIddbMongoTemplate.findOne(query,
                UserAuthInfoRegAuthModuleVo.class, CollectionNames.USER_AUTH_INFO.getCollectionName());

        if (authenticationModules == null || authenticationModules.getRegAuthModule() == null
                || authenticationModules.getRegAuthModule().isEmpty()) {
            return Collections.emptyList();
        }

        final List<RegisteredAuthenticationModule> regAuthModule = authenticationModules.getRegAuthModule();
        return getFido2RegistrationEntities(regAuthModule, username, rpDomainName, authType, status);
    }

    @Override
    public List<FIDO2RegistrationEntity> findAllByUsername(final String loginId) {
        LOG.info("FIDO2RegistrationRepoImpl -> findAllByUsername() entering");

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("findAllByUsername() : mapping object not found for loginId :{}", loginId);
            return Collections.emptyList();
        }

        final String username = mapping.getUserId();

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(username));

        final UserAuthInfoRegAuthModuleVo authenticationModules = relIddbMongoTemplate.findOne(query,
                UserAuthInfoRegAuthModuleVo.class, CollectionNames.USER_AUTH_INFO.getCollectionName());

        if (authenticationModules == null || authenticationModules.getRegAuthModule() == null
                || authenticationModules.getRegAuthModule().isEmpty()) {
            return Collections.emptyList();
        }

        final List<RegisteredAuthenticationModule> regAuthModule = authenticationModules.getRegAuthModule();
        return getFido2RegistrationEntities(regAuthModule, username);
    }

    @Override
    public List<FIDO2RegistrationEntity> findAllByUserId(final String userId) {
        LOG.info("findAllByUserId() entering");

        // TODO: Not Tested

        final String loginId = Utils.getUsernameFromSecurityContextOrRequestContext();

        if (loginId == null) {
            LOG.error("findAllByUserId() : loginId is null");
            return Collections.emptyList();
        }

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("findAllByUserId() : mapping object not found for loginId :{}", loginId);
            return Collections.emptyList();
        }

        final String username = mapping.getUserId();

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(username));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModule.REG_AUTHENTICATION_MODULE_STR + "."
                + FIDO2RegisteredAuthenticationModule.USERID_STR).is(userId));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR + "."
                + RegisteredAuthenticationModule.AUTHTYPE_STR).is(AuthType.FIDO.name()));

        final UserAuthInfoRegAuthModuleVo authenticationModules = relIddbMongoTemplate.findOne(query,
                UserAuthInfoRegAuthModuleVo.class, CollectionNames.USER_AUTH_INFO.getCollectionName());

        if (authenticationModules == null || authenticationModules.getRegAuthModule() == null
                || authenticationModules.getRegAuthModule().isEmpty()) {
            return Collections.emptyList();
        }

        final List<RegisteredAuthenticationModule> regAuthModule = authenticationModules.getRegAuthModule();

        return

        getFido2RegistrationEntities(regAuthModule, username);
    }

    @Override
    public List<FIDO2RegistrationEntity> findAllByChallenge(final String challenge) {
        LOG.info("findAllByChallenge() : entering");

        final String username = Utils.getUsernameFromSecurityContextOrRequestContext();

        if (username == null) {
            LOG.error("findAllByChallenge() : username is null");
            return Collections.emptyList();
        }

        final FIDO2RegisteredAuthenticationModule regAuthModule = Utils.getFidoRegistrationRecordInSession();

        if (regAuthModule == null) {
            return Collections.emptyList();
        }

        return getFido2RegistrationEntities(Arrays.asList(regAuthModule), username);
    }

    @Override
    public List<FIDO2RegistrationEntity> findAllByUsernameAndDomain(final String loginId, final String domain) {

        LOG.info("findAllByUsernameAndDomain() : entering");

        // TODO: Not Tested

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("findAllByUsernameAndDomain() : mapping object not found for loginId :{}", loginId);
            return Collections.emptyList();
        }

        final String username = mapping.getUserId();

        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(username));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR + "."
                + FIDO2RegisteredAuthenticationModule.DOMAIN_STR).is(domain));
        query.addCriteria(Criteria.where(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR + "."
                + RegisteredAuthenticationModule.AUTHTYPE_STR).is(AuthType.FIDO.name()));

        final UserAuthInfoRegAuthModuleVo authenticationModules = relIddbMongoTemplate.findOne(query,
                UserAuthInfoRegAuthModuleVo.class, CollectionNames.USER_AUTH_INFO.getCollectionName());

        if (authenticationModules == null || authenticationModules.getRegAuthModule() == null
                || authenticationModules.getRegAuthModule().isEmpty()) {
            return Collections.emptyList();
        }

        final List<RegisteredAuthenticationModule> regAuthModule = authenticationModules.getRegAuthModule();

        return getFido2RegistrationEntities(regAuthModule, username);
    }

    @Override
    public FIDO2RegistrationEntity saveForAssertionFlow(final FIDO2RegistrationEntity fidoRegisteredModule) {

        LOG.info("saveForAssertionFlow() entering");

        final String loginId = Utils.getUsernameFromSecurityContextOrRequestContext();

        if (loginId == null) {
            LOG.error("saveForAssertionFlow() : username is null");
            return null;
        }

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("saveForAssertionFlow() : mapping object not found for loginId :{}", loginId);
            return null;
        }

        final List<FIDO2RegisteredAuthenticationModule> regFidoTokens = userAuthInfoRepo
                .getListOFIDO2fRegAuthModuleLoginId(loginId);

        final FIDO2RegisteredAuthenticationModule authenticationModule = getFIDO2RegisteredAuthenticationModule(
                fidoRegisteredModule);

        final String username = mapping.getUserId();

        final Query query = new Query();
        final Update update = new Update();

        if (regFidoTokens == null || regFidoTokens.isEmpty()) {

            LOG.warn("saveForAssertionFlow() must not come");
            query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(username));

            authenticationModule.setAuthTypeStatus(AuthTypeStatus.PENDING);
            update.push(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR, authenticationModule);
            update.push(UserAuthInfoRegAuthModuleVo.REG_AUTH_TYPE_STR, AuthType.FIDO);

        } else {

            final Optional<FIDO2RegisteredAuthenticationModule> optionalModule = regFidoTokens.stream()
                    .filter(pp -> pp.getChallenge().equals(fidoRegisteredModule.getChallenge())).findFirst();

            if (optionalModule.isPresent()) {

                final FIDO2RegisteredAuthenticationModule module = optionalModule.get();

                query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(username)
                        .andOperator(Criteria
                                .where(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR + "."
                                        + FIDO2RegisteredAuthenticationModule.CHALLENGE_STR)
                                .in(fidoRegisteredModule.getChallenge())));

                authenticationModule.setAuthenticatorUuid(module.getAuthenticatorUuid());

                update.set(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR + ".$", authenticationModule);

            } else {

                LOG.warn("saveForAssertionFlow() must not come 1");
                query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(username));

                authenticationModule.setAuthTypeStatus(AuthTypeStatus.PENDING);
                update.push(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR, authenticationModule);

            }

        }

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        LOG.debug("FIDO2RegistrationRepoImpl -> saveForAssertionFlow() -> {}", updateResult.getModifiedCount());

        LOG.info("FIDO2RegistrationRepoImpl -> saveForAssertionFlow() exiting");

        return updateResult.getModifiedCount() > 0 ? fidoRegisteredModule : null;

    }

    @Override
    public <S extends FIDO2RegistrationEntity> S save(final S fidoRegisteredModule) {

        LOG.info("save() entering");

        final String loginId = Utils.getUsernameFromSecurityContextOrRequestContext();

        if (loginId == null) {
            LOG.error("save() : username is null");
            return null;
        }

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("save() : mapping object not found for loginId :{}", loginId);
            return null;
        }

        final String username = mapping.getUserId();
        boolean tobeSaved = false;
        final Query query = new Query();
        final Update update = new Update();

        final FIDO2RegisteredAuthenticationModule authenticationModule = getFIDO2RegisteredAuthenticationModule(
                fidoRegisteredModule);

        final FIDO2RegisteredAuthenticationModule sessionFido2Record = Utils.getFidoRegistrationRecordInSession();

        if (sessionFido2Record == null) {
            LOG.info("save() sessionFido2Record is null");
            authenticationModule.setAuthTypeStatus(AuthTypeStatus.PENDING);
        } else {
            LOG.info("save() Attestation flow is ongoing");
            final boolean isChallengeExist = authenticationModule.getChallenge()
                    .equalsIgnoreCase(sessionFido2Record.getChallenge());
            LOG.info("save() Attestation flow : chalenge exist :{}", isChallengeExist);
            if (isChallengeExist) {
                query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(username));
                authenticationModule.setAuthTypeStatus(AuthTypeStatus.REGISTERED);
                authenticationModule.setLastAuthTypeStatus(AuthTypeStatus.REGISTERED);
                update.push(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR, authenticationModule);
                update.addToSet(UserAuthInfoRegAuthModuleVo.REG_AUTH_TYPE_STR).each(Arrays.asList(AuthType.FIDO));
                tobeSaved = true;
            } else {
                authenticationModule.setAuthTypeStatus(AuthTypeStatus.PENDING);
            }
        }

        if (tobeSaved) {
            /*
             * To map the FIDO platform authenticator to the secure cookie
             * adding below fields to User -> browsers array authenticator_uuid
             * - string, same as FIDO device authenticator_uuid
             * added_for_authenticator - boolean, true, if this secure cookie is
             * set specifically for FIDO platform authenticator registration
             * (new browser is added), false otherwise (browser was already
             * present).
             */
            SecureCookie secureCookie = null;
            Cookie sCookie = null;
            WebDevMaster webDevMaster = null;
            boolean addedForAuthenticator = false;
            UserAuthInfoVO userAuthInfo = null;
            LOG.info("save() tie secureCookie transports {}", authenticationModule.getTransport());
            if (authenticationModule.getTransport().equalsIgnoreCase("internal") // FIXME
                                                                                 // refer
                                                                                 // enum
            ) {
                LOG.info("save() tie secureCookie");

                final boolean isSecureCookiePresent = Utils.getIsSecureCookieSetFromRequestContext();
                boolean createNewSecureCookie = true;

                final HttpServletRequest request = Utils.getHttpServletRequestFromRequestContext();
                if (isSecureCookiePresent && !secureCookieService.isSecureCookieExpired(request)) {
                    sCookie = Utils.getSecureCookieFromRequestContext();

                    if (secureCookieService.decryptSecureCookie(sCookie.getValue()) == null) {
                        EventLogger.log(EventId.RelidAuthServer.INVALID_SECURE_COOKIE,
                                Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                                AuthenticationUtils.getUsername(request), AuthenticationUtils.getUserAgent(request),
                                "Request Has Invalid Secure Cookie");
                        throw new InvalidSecureCookieException("Request Has Invalid Secure Cookie");
                    }

                    webDevMaster = webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(sCookie.getValue());

                    if (webDevMaster != null) {
                        final List<Map<String, String>> userIdList = userAuthInfoRepo
                                .fetchAssociatedUserWithWebDeviceUuid(webDevMaster.getWebDeviceUuid());

                        createNewSecureCookie = userIdList.isEmpty();
                    }
                }

                if (createNewSecureCookie) {

                    LOG.info("save() tie secureCookie inside");
                    webDevMaster = sessionService.createSecureCookieForFIDO2();
                    addedForAuthenticator = true;
                    secureCookie = webDevMaster.getSecureCookie();
                } else {
                    sCookie = Utils.getSecureCookieFromRequestContext();
                    LOG.info("save() existing secureCookie");
                    webDevMaster = webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(sCookie.getValue());
                    LOG.info("webDevMaster.getWebDeviceUuid(): {}", webDevMaster.getWebDeviceUuid());
                }

                userAuthInfo = userAuthInfoRepo.fetchUserDetailsFromLoginId(loginId);
                if (userAuthInfo == null) {
                    throw new InvalidUserException("Invalid User : User is not registered in the system");
                }
                final String webDeviceUuid = webDevMaster.getWebDeviceUuid();
                final Optional<UserBrowser> optionalBrowser = userAuthInfo.getWebUserDetails().getBrowsers().stream()
                        .filter(browser -> StringUtils.equals(webDeviceUuid, browser.getWebDeviceUuid())).findFirst();
                UserBrowser browser = null;
                if (optionalBrowser.isPresent()) {
                    browser = optionalBrowser.get();
                    browser.setAuthenticatorUuid(authenticationModule.getAuthenticatorUuid());
                    browser.setAddedForAuthenticator(addedForAuthenticator);
                    // userAuthInfo.getWebUserDetails().getBrowsers().add(browser);

                } else {
                    browser = new UserBrowser();
                    browser.setId(new ObjectId());
                    browser.setCreatedTs(new Date());
                    browser.setLastLoginTs(new Date());
                    browser.setStatus(UserBrowserStatus.ACTIVE.getValue());
                    browser.setWebDeviceUuid(webDeviceUuid);
                    browser.setUserOptedOutForFidoReg(false);
                    browser.setAuthenticatorUuid(authenticationModule.getAuthenticatorUuid());
                    browser.setAddedForAuthenticator(true);

                    userAuthInfo.getWebUserDetails().getBrowsers().add(browser);
                }
            }

            final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update,
                    CollectionNames.USER_AUTH_INFO.getCollectionName());
            LOG.debug("FIDO2RegistrationRepoImpl -> save() -> {}", updateResult.getModifiedCount());
            Utils.removeFidoRegistrationRecordInSession();
            LOG.info("FIDO2RegistrationRepoImpl -> save() -> removed fido registration record from session");

            if (userAuthInfo != null && userAuthInfo.getWebUserDetails() != null) {
                userAuthInfoRepo.updateUserAuthInfoDoc(loginId,
                        UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR,
                        userAuthInfo.getWebUserDetails().getBrowsers());
            }

            return updateResult.getModifiedCount() > 0 ? fidoRegisteredModule : null;

        } else {
            LOG.info("FIDO2Registration Module is saved into session");
            Utils.setFidoRegistrationRecordInSession(authenticationModule);
        }
        LOG.info("FIDO2RegistrationRepoImpl -> save() exiting");
        return null;
    }

    @Override
    public void delete(final FIDO2RegistrationEntity registration) {

        LOG.info("remove() entering");

        // TODO: Not Tested

        final String loginId = Utils.getUsernameFromSecurityContextOrRequestContext();

        if (loginId == null) {
            LOG.error("remove() : loginId is null");
            return;
        }

        final UserIdLoginIdMapping mapping = userAuthInfoRepo.findUserIdLoginIdMapping(loginId);

        if (mapping == null || mapping.getUserId() == null) {
            LOG.error("remove() : mapping object not found for loginId :{}", loginId);
            return;
        }

        final String username = mapping.getUserId();
        final Query query = new Query();
        query.addCriteria(Criteria.where(UserAuthInfoVO.USER_ID_STR).is(username));

        final Update update = new Update();
        update.pull(UserAuthInfoRegAuthModuleVo.REG_AUTHENTICATION_MODULE_STR + "."
                + FIDO2RegisteredAuthenticationModule.USERID_STR, registration.getUserId());

        final UpdateResult updateResult = relIddbMongoTemplate.updateFirst(query, update, UserAuthInfoVO.class,
                CollectionNames.USER_AUTH_INFO.getCollectionName());

        LOG.debug("FIDO2RegistrationRepoImpl -> remove() -> {}", updateResult.getModifiedCount());

        LOG.info("FIDO2RegistrationRepoImpl -> remove() exiting");

    }

    /**
     * @param authenticationModule
     * @param username
     * @return
     */
    private FIDO2RegistrationEntity getFido2RegistrationEntity(
            final FIDO2RegisteredAuthenticationModule authenticationModule, final String username) {

        final FIDO2RegistrationEntity registrationEntity = new FIDO2RegistrationEntity();

        if (authenticationModule.getAttestationConveyancePreference() != null) {
            registrationEntity.setAttestationConveyancePreferenceType(
                    AttestationConveyancePreference.valueOf(authenticationModule.getAttestationConveyancePreference()));
        }

        if (authenticationModule.getAttestationType() != null) {
            registrationEntity.setAttestationType(authenticationModule.getAttestationType());
        }
        registrationEntity.setChallenge(authenticationModule.getChallenge());
        registrationEntity.setCounter(authenticationModule.getCounter());
        registrationEntity.setCreatedDate(authenticationModule.getCreatedTS());
        registrationEntity.setDomain(authenticationModule.getDomain());
        registrationEntity.setPublicKeyId(authenticationModule.getRegistrationKeyId());
        registrationEntity.setSignatureAlgorithm(authenticationModule.getSigAlgorithmType());

        registrationEntity.setStatus(
                RegistrationStatus.REGISTERED.name().equalsIgnoreCase(authenticationModule.getAuthTypeStatus().name())
                        ? RegistrationStatus.REGISTERED
                        : RegistrationStatus.PENDING);

        registrationEntity.setType(authenticationModule.getRegistrationKeyType());
        registrationEntity.setUncompressedECPoint(authenticationModule.getEcPoint());
        registrationEntity.setUpdatedDate(authenticationModule.getUpdatedTS());
        registrationEntity.setUserId(authenticationModule.getUserId());
        registrationEntity.setUsername(username);
        registrationEntity.setW3cAuthenticatorAttenstationResponse(
                Constants.GSON.toJson(authenticationModule.getAuthenticatorAttestationResponse()));
        registrationEntity.setW3cCredentialCreationOptions(
                Constants.GSON.toJson(authenticationModule.getCredentialCreationOptions()));
        final List<String> transportsStr = new ArrayList<String>(
                Arrays.asList(authenticationModule.getTransport().split(",")));
        if (transportsStr.size() > 0) {
            final List<AuthenticatorTransport> transports = new ArrayList<AuthenticatorTransport>(transportsStr.size());
            for (int kk = 0; kk < transportsStr.size(); kk++) {
                transports.add(AuthenticatorTransport.valueOf(transportsStr.get(kk)));
            }
            registrationEntity.setAuthenticatorTransports(transports);
        }
        registrationEntity.setAuthenticatorDescription(authenticationModule.getAuthenticatorDescription());
        registrationEntity.setAuthenticatorAaguid(authenticationModule.getAuthenticatorAaguid());
        return registrationEntity;
    }

    private List<FIDO2RegistrationEntity> getFido2RegistrationEntities(
            final List<RegisteredAuthenticationModule> authenticationModules, final String username) {

        final List<FIDO2RegistrationEntity> fido2RegistrationEntities = new ArrayList<>();

        for (final RegisteredAuthenticationModule authenticationModule : authenticationModules) {
            fido2RegistrationEntities.add(
                    getFido2RegistrationEntity(((FIDO2RegisteredAuthenticationModule) authenticationModule), username));
        }

        return fido2RegistrationEntities;

    }

    private List<FIDO2RegistrationEntity> getFido2RegistrationEntities(
            final List<RegisteredAuthenticationModule> authenticationModules, final String username,
            final String status) {

        final List<FIDO2RegistrationEntity> fido2RegistrationEntities = new ArrayList<>();

        for (final RegisteredAuthenticationModule authenticationModule : authenticationModules) {
            if (authenticationModule.getAuthTypeStatus().equals(AuthTypeStatus.valueOf(status))) {
                fido2RegistrationEntities.add(getFido2RegistrationEntity(
                        ((FIDO2RegisteredAuthenticationModule) authenticationModule), username));
            }
        }

        return fido2RegistrationEntities;

    }

    private List<FIDO2RegistrationEntity> getFido2RegistrationEntities(
            final List<RegisteredAuthenticationModule> authenticationModules, final String username,
            final String rpDomain, final String authType, final String status) {

        final List<FIDO2RegistrationEntity> fido2RegistrationEntities = new ArrayList<>();

        for (final RegisteredAuthenticationModule authenticationModule : authenticationModules) {
            if (authenticationModule.getAuthTypeStatus().equals(AuthTypeStatus.valueOf(status))
                    && authType.equals(AuthType.FIDO.name())) {
                fido2RegistrationEntities.add(getFido2RegistrationEntity(
                        ((FIDO2RegisteredAuthenticationModule) authenticationModule), username));
            }
        }

        return fido2RegistrationEntities;

    }

    private FIDO2RegisteredAuthenticationModule getFIDO2RegisteredAuthenticationModule(

            final FIDO2RegistrationEntity fidoRegisteredModule) {

        final FIDO2RegisteredAuthenticationModule authModule = new FIDO2RegisteredAuthenticationModule(
                fidoRegisteredModule.getUserId(),
                fidoRegisteredModule.getCreatedDate() != null ? fidoRegisteredModule.getCreatedDate() : new Date(),
                fidoRegisteredModule.getUpdatedDate() != null ? fidoRegisteredModule.getUpdatedDate() : new Date(),
                AuthType.FIDO, AuthTypeStatus.REGISTERED, fidoRegisteredModule.getDomain(),
                fidoRegisteredModule.getChallenge(),
                Constants.GSON.fromJson(fidoRegisteredModule.getW3cCredentialCreationOptions(),
                        PublicKeyCredentialCreationOptions.class),
                fidoRegisteredModule.getAttestationConveyancePreferenceType().name(),
                (fidoRegisteredModule.getAuthenticatorTransports() != null
                        && !fidoRegisteredModule.getAuthenticatorTransports().isEmpty())
                                ? fidoRegisteredModule.getAuthenticatorTransports().stream().map(n -> n.name()).collect(
                                        Collectors.joining(","))
                                : null,
                fidoRegisteredModule.getAuthenticatorDescription());

        authModule.setAttestationType(fidoRegisteredModule.getAttestationType());
        authModule.setAuthenticatorAttestationResponse(
                Constants.GSON.fromJson(fidoRegisteredModule.getW3cAuthenticatorAttenstationResponse(),
                        AuthenticatorAttestationResponse.class));
        authModule.setCounter(fidoRegisteredModule.getCounter());
        authModule.setEcPoint(fidoRegisteredModule.getUncompressedECPoint());
        authModule.setRegistrationKeyId(fidoRegisteredModule.getPublicKeyId());
        authModule.setRegistrationKeyType(fidoRegisteredModule.getType());
        authModule.setSigAlgorithmType(fidoRegisteredModule.getSignatureAlgorithm());
        authModule.setAuthenticatorDescription(fidoRegisteredModule.getAuthenticatorDescription());
        authModule.setAuthenticatorName(formAuthenticatorName(fidoRegisteredModule.getAuthenticatorDescription()));
        authModule.setAuthenticatorUuid(UUID.randomUUID().toString()); // authModule.setAuthenticatorUuid(authModule.getAuthenticatorUuid()
                                                                       // !=
                                                                       // null ?
                                                                       // authModule.getAuthenticatorUuid()
                                                                       // :
                                                                       // UUID.randomUUID().toString());
        authModule.setUserAgent(Utils.getUserAgentfromRequestContext());
        authModule.setAuthenticatorAaguid(fidoRegisteredModule.getAuthenticatorAaguid());
        return authModule;

    }

    private String formAuthenticatorName(final String auntenticatorDesc) {

        String authName = null;
        if (auntenticatorDesc != null) {
            authName = auntenticatorDesc;
            authName = authName.replaceAll("\\s+", "_");
            final Date date = Calendar.getInstance().getTime();
            final DateFormat dateFormat = new SimpleDateFormat("MMddyyHHmmss");
            final String strDate = dateFormat.format(date);
            authName = authName + "_" + strDate;
            LOG.info("formAuthenticatorName -> {}", authName);

        }
        return authName;

    }

    @Override
    public List<FIDO2RegistrationEntity> findAll() {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public List<FIDO2RegistrationEntity> findAll(final Sort sort) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public List<FIDO2RegistrationEntity> findAllById(final Iterable<String> ids) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2RegistrationEntity> List<S> saveAll(final Iterable<S> entities) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void flush() {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);

    }

    @Override
    public <S extends FIDO2RegistrationEntity> S saveAndFlush(final S entity) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void deleteInBatch(final Iterable<FIDO2RegistrationEntity> entities) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);

    }

    @Override
    public void deleteAllInBatch() {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);

    }

    @Override
    public FIDO2RegistrationEntity getOne(final String id) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2RegistrationEntity> List<S> findAll(final Example<S> example) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2RegistrationEntity> List<S> findAll(final Example<S> example, final Sort sort) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public Page<FIDO2RegistrationEntity> findAll(final Pageable pageable) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public Optional<FIDO2RegistrationEntity> findById(final String id) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public boolean existsById(final String id) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public long count() {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void deleteById(final String id) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);

    }

    @Override
    public void deleteAll(final Iterable<? extends FIDO2RegistrationEntity> entities) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void deleteAll() {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2RegistrationEntity> Optional<S> findOne(final Example<S> example) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2RegistrationEntity> Page<S> findAll(final Example<S> example, final Pageable pageable) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2RegistrationEntity> long count(final Example<S> example) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2RegistrationEntity> boolean exists(final Example<S> example) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void deleteAllByIdInBatch(final Iterable<String> ids) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void deleteAllInBatch(final Iterable<FIDO2RegistrationEntity> fido2RegistrationEntities) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public FIDO2RegistrationEntity getById(final String id) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public <S extends FIDO2RegistrationEntity> List<S> saveAllAndFlush(final Iterable<S> fido2RegistrationEntities) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

    @Override
    public void deleteAllById(final Iterable<? extends String> ids) {
        throw new NotImplementedException(NOT_IMPLEMENTED_MSG);
    }

}
