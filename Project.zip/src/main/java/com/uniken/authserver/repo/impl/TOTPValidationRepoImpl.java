package com.uniken.authserver.repo.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.uniken.authserver.domains.TOTPValidationLog;
import com.uniken.authserver.repo.api.TOTPValidationRepo;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.enums.CollectionNames;

@Repository
public class TOTPValidationRepoImpl
        implements
        TOTPValidationRepo {

    @Resource(name = Constants.RESOURCE_RELIDDB_MONGO_TEMPLATE)
    private MongoTemplate relIddbMongoTemplate;

    @Resource(name = Constants.RESOURCE_GMDB_MONGO_TEMPLATE)
    private MongoTemplate gmdbMongoTemplate;

    private static final Logger LOG = LoggerFactory.getLogger(TOTPValidationRepoImpl.class);

    @Override
    public void insertLog(final TOTPValidationLog totpValidationLog) {

        LOG.info("insertLog() -> Inserting TOTP validation log");
        relIddbMongoTemplate.insert(totpValidationLog, CollectionNames.TOTP_VALIDATION_LOG.getCollectionName());

    }

    @Override
    public boolean isTOTPConsumed(final String userId, final String totp, final String deviceUuid) {

        LOG.info("isTOTPConsumed() -> Finding TOTP log consumed by userId : {} from device {}", userId, deviceUuid);

        boolean consumed = true;
        final Query query = new Query();
        query.addCriteria(Criteria.where("totp").is(totp));

        if (relIddbMongoTemplate.find(query, TOTPValidationLog.class).isEmpty()) {
            consumed = false;
        }

        return consumed;

    }

    @Override
    public List<String> getTOTPEnabledAppUuids() {

        LOG.info("getTOTPEnabledAppUuids() -> Finding uuids for app agents enabled for totp.");

        final Query query = new Query();
        query.addCriteria(Criteria.where("appAgentName").in(Constants.getTotpEnabledAppAgents()));
        return gmdbMongoTemplate.findDistinct(query, "uuid", CollectionNames.APP_AGENT.getCollectionName(),
                String.class);

    }

}
