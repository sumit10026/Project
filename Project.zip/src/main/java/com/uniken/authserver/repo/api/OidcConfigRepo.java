package com.uniken.authserver.repo.api;

import java.util.List;

import com.uniken.domains.auth.OIDCConfig;

/**
 * Repository for OIDC Configs.
 */
public interface OidcConfigRepo {

    /**
     * Get all OIDC Configurations.
     * 
     * @param callback
     * @return list of All App Agents.
     */
    List<OIDCConfig> getAllOidcConfigs();

    /**
     * Gets the ooidc config by app agent name.
     *
     * @param appAgentName
     *            the app agent name
     * @return the ooidc config by app agent name
     */
    OIDCConfig getOidcConfigByAppAgentName(String appAgentName);
}
