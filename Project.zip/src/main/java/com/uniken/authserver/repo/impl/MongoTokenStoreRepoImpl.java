/**
 * 
 */
package com.uniken.authserver.repo.impl;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.oauth2.common.DefaultExpiringOAuth2RefreshToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2RefreshToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.AuthenticationKeyGenerator;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.web.authentication.preauth.PreAuthenticatedAuthenticationToken;
import org.springframework.stereotype.Repository;

import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;
import com.uniken.authserver.repo.api.MongoTokenStoreRepo;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.CustomOAuth2AccessToken;
import com.uniken.domains.auth.CustomOAuth2AccessTokenLog;
import com.uniken.domains.auth.CustomOAuth2RefreshToken;
import com.uniken.domains.auth.CustomOAuth2RefreshTokenLog;
import com.uniken.domains.enums.CollectionNames;
import com.uniken.domains.util.OAuthUtils;

/**
 * Implementation of token services that stores tokens in a database. <br>
 * Also see : {@link TokenStore}
 * 
 * @author Kushal Jaiswal
 */
@Repository
public class MongoTokenStoreRepoImpl
        implements
        MongoTokenStoreRepo {

    private static final Logger LOG = LoggerFactory.getLogger(MongoTokenStoreRepoImpl.class);

    @Autowired
    private MongoTemplate mongoTemplate;

    @Autowired
    private AuthenticationKeyGenerator authenticationKeyGenerator;

    @Override
    public OAuth2Authentication readAuthentication(final OAuth2AccessToken token) {
        return readAuthentication(token.getValue());
    }

    @Override
    public OAuth2Authentication readAuthentication(final String token) {
        LOG.info("readAuthentication() : Entered. Read authentication from database.");

        /**
         * Purposefully reading collection into the Document.class and then
         * converted into the POJO class. If we directly read collection into
         * the POJO MongoTemplate throws exception, as a fix we are first
         * reading document and then parsing it.
         */
        final Document auth2AccessTokenDoc = mongoTemplate.findOne(
                Query.query(Criteria.where(CustomOAuth2AccessToken.TOKEN_ID_KEY).is(OAuthUtils.extractTokenKey(token))),
                Document.class, CollectionNames.OAUTH_ACCESS_TOKEN.getCollectionName());

        if (auth2AccessTokenDoc == null) {
            return null;
        }

        final CustomOAuth2AccessToken auth2AccessToken = Constants.GSON
                .fromJson(Constants.GSON.toJson(auth2AccessTokenDoc), CustomOAuth2AccessToken.class);

        return auth2AccessToken == null ? null : auth2AccessToken.getAuthentication();
    }

    @Override
    public void storeAccessToken(final OAuth2AccessToken token, OAuth2Authentication authentication) {
        LOG.info("storeAccessToken(): Entered");

        // FIXME: User authentication is appearing sometimes as a
        // java.lang.String or java.util.LinkedHashMap(instead
        // of org.springframework.security.core.userdetails.User, after parsing
        // document into CustomOAuth2RefreshToken object.
        // So, currently we're checking if authentication can be parsed into
        // org.springframework.security.core.userdetails.User, or returning as
        // it is. This needs proper implementation and we might need to make use
        // of custom user principal across all use cases, such as OIDC flow,
        // blaze server requests, client credentials, etc to avoid this issue.
        if (authentication.getUserAuthentication() instanceof PreAuthenticatedAuthenticationToken) {
            authentication = new OAuth2Authentication(authentication.getOAuth2Request(),
                    new PreAuthenticatedAuthenticationToken(authentication.getUserAuthentication().getName(), null,
                            authentication.getAuthorities()));
        }

        final CustomOAuth2AccessToken accessToken = new CustomOAuth2AccessToken(token, authentication,
                authenticationKeyGenerator.extractKey(authentication));

        final String tokenId = accessToken.getTokenId();

        final Document auth2AccessTokenDoc = mongoTemplate.findOne(
                Query.query(Criteria.where(CustomOAuth2AccessToken.TOKEN_ID_KEY).is(tokenId)), Document.class,
                CollectionNames.OAUTH_ACCESS_TOKEN.getCollectionName());

        if (auth2AccessTokenDoc != null) {
            final CustomOAuth2AccessToken auth2AccessToken = Constants.GSON.fromJson(
                    // FIXME Using GSON we are not getting _id
                    auth2AccessTokenDoc.toJson(), CustomOAuth2AccessToken.class);

            accessToken.set_id(auth2AccessToken.get_id());
        } else {
            accessToken.setCreatedTS(new Date());
        }

        accessToken.setRequestorId(MDC.get(Constants.REQUESTOR_ID));

        mongoTemplate.save(accessToken, CollectionNames.OAUTH_ACCESS_TOKEN.getCollectionName());
    }

    @Override
    public OAuth2AccessToken readAccessToken(final String tokenValue) {
        LOG.info("readAccessToken(): Entered");

        final Document accessTokenDoc = mongoTemplate.findOne(
                Query.query(Criteria.where(CustomOAuth2AccessToken.TOKEN_ID_KEY)
                        .is(OAuthUtils.extractTokenKey(tokenValue))),
                Document.class, CollectionNames.OAUTH_ACCESS_TOKEN.getCollectionName());

        if (accessTokenDoc == null) {
            return null;
        }

        return Constants.GSON.fromJson(Constants.GSON.toJson(accessTokenDoc), CustomOAuth2AccessToken.class);

    }

    @Override
    public void removeAccessToken(final OAuth2AccessToken token) {
        LOG.info("removeAccessToken(): Entered");

        /**
         * If Access Token is expired then delete the token and insert into the
         * log collection and don't delete the Refresh Token as it's going to
         * used to get the Access Token.<br>
         * Otherwise if Access Token is Revoked the delete the AccessToken and
         * RefreshToken as well.
         */

        final Document deletedAccessTokenDoc = mongoTemplate.findAndRemove(
                Query.query(Criteria.where(CustomOAuth2AccessToken.TOKEN_ID_KEY)
                        .is(OAuthUtils.extractTokenKey(token.getValue()))),
                Document.class, CollectionNames.OAUTH_ACCESS_TOKEN.getCollectionName());

        if (deletedAccessTokenDoc != null) {

            final CustomOAuth2AccessToken deletedAccessToken = Constants.GSON
                    .fromJson(Constants.GSON.toJson(deletedAccessTokenDoc), CustomOAuth2AccessToken.class);

            CustomOAuth2AccessTokenLog accessTokenLog = null;

            if (token.isExpired()) {
                accessTokenLog = CustomOAuth2AccessTokenLog.getInstanceOfExpiredAccessTokenLog(deletedAccessToken,
                        new Date());
            } else {

                /**
                 * If Access Token is revoked the revoke refresh token as well.
                 */
                accessTokenLog = CustomOAuth2AccessTokenLog.getInstanceOfRevokedAccessTokenLog(deletedAccessToken,
                        new Date());

            }

            logAccessToken(accessTokenLog);
        }
    }

    @Override
    public void storeRefreshToken(final OAuth2RefreshToken refreshToken, OAuth2Authentication authentication) {

        LOG.info("storeRefreshToken(): Entered");

        // FIXME: User authentication is appearing sometimes as a
        // java.lang.String or java.util.LinkedHashMap(instead
        // of org.springframework.security.core.userdetails.User, after parsing
        // document into CustomOAuth2RefreshToken object.
        // So, currently we're checking if authentication can be parsed into
        // org.springframework.security.core.userdetails.User, or returning as
        // it is. This needs proper implementation and we might need to make use
        // of custom user principal across all use cases, such as OIDC flow,
        // blaze server requests, client credentials, etc to avoid this issue.
        if (authentication.getUserAuthentication() instanceof PreAuthenticatedAuthenticationToken) {
            authentication = new OAuth2Authentication(authentication.getOAuth2Request(),
                    new PreAuthenticatedAuthenticationToken(authentication.getUserAuthentication().getName(), null,
                            authentication.getAuthorities()));
        }

        final DefaultExpiringOAuth2RefreshToken token = (DefaultExpiringOAuth2RefreshToken) refreshToken;

        final CustomOAuth2RefreshToken auth2RefreshToken = new CustomOAuth2RefreshToken(token.getValue(),
                token.getExpiration(), authentication, new Date(), MDC.get(Constants.REQUESTOR_ID));

        mongoTemplate.save(auth2RefreshToken);

    }

    @Override
    public OAuth2RefreshToken readRefreshToken(final String tokenValue) {
        LOG.info("readRefreshToken(): Entered");

        final Document auth2RefreshTokenDoc = mongoTemplate.findOne(
                Query.query(Criteria.where(CustomOAuth2RefreshToken.TOKEN_ID_KEY)
                        .is(OAuthUtils.extractTokenKey(tokenValue))),
                Document.class, CollectionNames.OAUTH_REFRESH_TOKEN.getCollectionName());

        if (auth2RefreshTokenDoc == null) {
            return null;
        }

        return Constants.GSON.fromJson(Constants.GSON.toJson(auth2RefreshTokenDoc), CustomOAuth2RefreshToken.class);
    }

    @Override
    public OAuth2Authentication readAuthenticationForRefreshToken(final OAuth2RefreshToken token) {
        LOG.info("readAuthenticationForRefreshToken(): Entered");

        final Document auth2RefreshTokenDoc = mongoTemplate.findOne(
                Query.query(Criteria.where(CustomOAuth2RefreshToken.TOKEN_ID_KEY)
                        .is(OAuthUtils.extractTokenKey(token.getValue()))),
                Document.class, CollectionNames.OAUTH_REFRESH_TOKEN.getCollectionName());

        if (auth2RefreshTokenDoc == null) {
            return null;
        }

        final CustomOAuth2RefreshToken auth2RefreshToken = Constants.GSON
                .fromJson(Constants.GSON.toJson(auth2RefreshTokenDoc), CustomOAuth2RefreshToken.class);

        if (auth2RefreshToken == null) {
            return null;
        }

        // FIXME: User authentication is appearing sometimes as a
        // java.lang.String or java.util.LinkedHashMap(instead
        // of org.springframework.security.core.userdetails.User, after parsing
        // document into CustomOAuth2RefreshToken object.
        // So, currently we're checking if authentication can be parsed into
        // org.springframework.security.core.userdetails.User, or returning as
        // it is. This needs proper implementation and we might need to make use
        // of custom user principal across all use cases, such as OIDC flow,
        // blaze server requests, client credentials, etc to avoid this issue.
        if (auth2RefreshToken.getAuthentication().getUserAuthentication() != null) {
            try {
                // final User user = Constants.GSON.fromJson(
                // Constants.GSON
                // .toJson(auth2RefreshToken.getAuthentication().getUserAuthentication().getPrincipal()),
                // User.class);
                return new OAuth2Authentication(auth2RefreshToken.getAuthentication().getOAuth2Request(),
                        new UsernamePasswordAuthenticationToken(
                                auth2RefreshToken.getAuthentication().getUserAuthentication().getName(),
                                auth2RefreshToken.getAuthentication().getUserAuthentication().getCredentials(),
                                auth2RefreshToken.getAuthentication().getUserAuthentication().getAuthorities()));
            } catch (final JsonSyntaxException e) {
            }
        }

        return auth2RefreshToken.getAuthentication();
    }

    @Override
    public void removeRefreshToken(final OAuth2RefreshToken token) {

        LOG.info("removeRefreshToken(): Entered.");

        final Document refreshTokenDoc = mongoTemplate.findAndRemove(
                Query.query(Criteria.where(CustomOAuth2RefreshToken.TOKEN_ID_KEY)
                        .is(OAuthUtils.extractTokenKey(token.getValue()))),
                Document.class, CollectionNames.OAUTH_REFRESH_TOKEN.getCollectionName());

        if (refreshTokenDoc != null) {

            final CustomOAuth2RefreshToken refreshToken = Constants.GSON
                    .fromJson(Constants.GSON.toJson(refreshTokenDoc), CustomOAuth2RefreshToken.class);

            CustomOAuth2RefreshTokenLog refreshTokenLog = null;

            if (Utils.isExpired(refreshToken)) {

                refreshTokenLog = CustomOAuth2RefreshTokenLog.getInstanceOfExpiredRefreshTokenLog(refreshToken,
                        new Date());

            } else {
                refreshTokenLog = CustomOAuth2RefreshTokenLog.getInstanceOfRevokedRefreshTokenLog(refreshToken,
                        new Date());
            }

            mongoTemplate.insert(refreshTokenLog);
        }

    }

    @Override
    public void removeAccessTokenUsingRefreshToken(final OAuth2RefreshToken refreshToken) {

        LOG.info("removeAccessTokenUsingRefreshToken(): Entered");

        final List<Document> accessTokenDocs = mongoTemplate.findAllAndRemove(
                Query.query(Criteria.where(CustomOAuth2AccessToken.REFRESH_TOKEN_ID_KEY)
                        .is(OAuthUtils.extractTokenKey(refreshToken.getValue()))),
                Document.class, CollectionNames.OAUTH_ACCESS_TOKEN.getCollectionName());

        if (!accessTokenDocs.isEmpty()) {

            final List<CustomOAuth2AccessToken> accessTokens = Utils.convertListOfMongoDocumentsToList(accessTokenDocs,
                    CustomOAuth2AccessToken.class);

            final List<CustomOAuth2AccessTokenLog> accessTokenLogs = new ArrayList<>();

            for (final CustomOAuth2AccessToken accessToken : accessTokens) {
                CustomOAuth2AccessTokenLog accessTokenLog = null;

                if (Utils.isExpired(refreshToken)) {

                    accessTokenLog = CustomOAuth2AccessTokenLog.getInstanceOfExpiredAccessTokenLog(accessToken,
                            new Date());

                } else {
                    accessTokenLog = CustomOAuth2AccessTokenLog.getInstanceOfRevokedAccessTokenLog(accessToken,
                            new Date());
                }

                accessTokenLogs.add(accessTokenLog);
            }

            mongoTemplate.insertAll(accessTokenLogs);
        }
    }

    @Override
    public OAuth2AccessToken getAccessToken(final OAuth2Authentication authentication) {
        LOG.info("getAccessToken(): Entered");

        final String extractKey = authenticationKeyGenerator.extractKey(authentication);

        final Document accessTokenDoc = mongoTemplate.findOne(
                Query.query(Criteria.where(CustomOAuth2AccessToken.AUTHENTICATION_ID_KEY).is(extractKey)),
                Document.class, CollectionNames.OAUTH_ACCESS_TOKEN.getCollectionName());

        if (accessTokenDoc == null) {
            return null;
        }

        final CustomOAuth2AccessToken accessToken = Constants.GSON.fromJson(Constants.GSON.toJson(accessTokenDoc),
                CustomOAuth2AccessToken.class);

        if (accessToken != null && !extractKey
                .equals(this.authenticationKeyGenerator.extractKey(readAuthentication(accessToken.getValue())))) {

            this.removeAccessToken(accessToken);
            this.storeAccessToken(accessToken, authentication);
        }
        return accessToken;
    }

    @Override
    public Collection<OAuth2AccessToken> findTokensByClientIdAndUserName(final String clientId, final String userName) {
        LOG.info("findTokensByClientIdAndUserName(): Entered. Client Id: {}, User Name: {}", clientId, userName);

        final List<Document> accessTokenDocs = mongoTemplate.find(
                Query.query(Criteria.where(CustomOAuth2AccessToken.CLIENT_ID_KEY).is(clientId)
                        .andOperator(Criteria.where(CustomOAuth2AccessToken.USERNAME_KEY).is(userName))),
                Document.class, CollectionNames.OAUTH_ACCESS_TOKEN.getCollectionName());

        if (accessTokenDocs.isEmpty()) {
            return Collections.emptyList();
        }

        return Constants.GSON.fromJson(Constants.GSON.toJson(accessTokenDocs),
                TypeToken.getParameterized(ArrayList.class, CustomOAuth2AccessToken.class).getType());

    }

    @Override
    public Collection<OAuth2AccessToken> findTokensByClientId(final String clientId) {
        LOG.info("findTokensByClientId() : Entered. Client Id: {}", clientId);

        final List<Document> accessTokenDocs = mongoTemplate.find(
                Query.query(Criteria.where(CustomOAuth2AccessToken.CLIENT_ID_KEY).is(clientId)), Document.class,
                CollectionNames.OAUTH_ACCESS_TOKEN.getCollectionName());

        if (accessTokenDocs.isEmpty()) {
            return Collections.emptyList();
        }

        return Constants.GSON.fromJson(Constants.GSON.toJson(accessTokenDocs),
                TypeToken.getParameterized(ArrayList.class, CustomOAuth2AccessToken.class).getType());

    }

    @Override
    public CustomOAuth2RefreshToken readAndRemoveRefreshToken(final String tokenValue) {

        LOG.info("readAndRemoveRefreshToken() : Entered");

        final Document refreshTokenDoc = mongoTemplate.findAndRemove(
                Query.query(Criteria.where(CustomOAuth2RefreshToken.TOKEN_ID_KEY)
                        .is(OAuthUtils.extractTokenKey(tokenValue))),
                Document.class, CollectionNames.OAUTH_REFRESH_TOKEN.getCollectionName());

        if (refreshTokenDoc == null) {
            return null;
        }

        final CustomOAuth2RefreshToken refreshToken = Constants.GSON.fromJson(Constants.GSON.toJson(refreshTokenDoc),
                CustomOAuth2RefreshToken.class);

        CustomOAuth2RefreshTokenLog refreshTokenLog = null;

        if (Utils.isExpired(refreshToken)) {
            refreshTokenLog = CustomOAuth2RefreshTokenLog.getInstanceOfExpiredRefreshTokenLog(refreshToken, new Date());

        } else {
            refreshTokenLog = CustomOAuth2RefreshTokenLog.getInstanceOfRevokedRefreshTokenLog(refreshToken, new Date());
        }

        mongoTemplate.insert(refreshTokenLog);

        return refreshToken;

    }

    @Override
    public void logAccessToken(final CustomOAuth2AccessTokenLog accessTokenLog) {
        LOG.info("logAccessToken() : Entered");
        mongoTemplate.insert(accessTokenLog);
    }
}
