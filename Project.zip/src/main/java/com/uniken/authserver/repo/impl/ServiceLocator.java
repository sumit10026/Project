package com.uniken.authserver.repo.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uniken.authserver.mq.consumer.MessageProcessor;
import com.uniken.authserver.mq.consumer.MessageProcessorFactory;

/**
 * This service is used to identify the proper bean using routing key
 * 
 * @author Uday T
 */
@Service
public class ServiceLocator {

    MessageProcessorFactory messageProcessorFactory;

    @Autowired
    public ServiceLocator(final MessageProcessorFactory messageProcessorFactory) {
        this.messageProcessorFactory = messageProcessorFactory;
    }

    /**
     * This function returns the appropriate service from routing key
     * 
     * @param routingKey
     * @return
     */
    public MessageProcessor getService(final String routingKey) {
        return messageProcessorFactory.getService(routingKey);
    }

}
