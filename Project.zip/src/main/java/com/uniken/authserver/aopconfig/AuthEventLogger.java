package com.uniken.authserver.aopconfig;

import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.codec.binary.Base64;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.util.StringUtils;
import org.springframework.web.util.ContentCachingRequestWrapper;
import org.springframework.web.util.ContentCachingResponseWrapper;

import com.google.gson.JsonObject;
import com.uniken.authserver.services.api.SessionService;
import com.uniken.authserver.utility.AuthenticationUtils;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;

@Aspect
@Configuration
public class AuthEventLogger {

    @Autowired
    SessionService sessionService;

    private static final Logger LOG = LoggerFactory.getLogger(AuthEventLogger.class);

    private static final String ERROR_DESC_STR = "error_description";
    private static final String PRE_AUTH_URI_STR = "INIT_AUTH";
    private static final String POST_AUTH_SUCCESS_URI_STR = "AUTH_SUCCESS";
    private static final String POST_AUTH_FAILED_URI_STR = "AUTH_FAILED";

    private static final Map<String, EventId> preRequestEventURIMapping = new HashMap<>();
    private static final Map<String, EventId> postRequestFailureEventURIMapping = new HashMap<>();
    private static final Map<String, EventId> postRequestSuccessEventURIMapping = new HashMap<>();

    static {
        // pre-success url mappings
        preRequestEventURIMapping.put(PRE_AUTH_URI_STR, EventId.RelidAuthServer.INIT_AUTHENTICATION_REQ);
        preRequestEventURIMapping.put(Constants.GENERATE_ACCESS_TOKEN_REQ,
                EventId.RelidAuthServer.INIT_GENERATE_ACCESS_TOKEN_REQ);
        preRequestEventURIMapping.put(Constants.REVOKE_ACCESS_TOKEN_REQ,
                EventId.RelidAuthServer.INIT_REVOKE_ACCESS_TOKEN_REQ);
        preRequestEventURIMapping.put(Constants.AUTHORIZE_REQ, EventId.RelidAuthServer.INIT_GENERATE_AUTH_CODE_REQ);
        preRequestEventURIMapping.put(Constants.USER_INFO_REQ, EventId.RelidAuthServer.INIT_USER_AUTHENTICATION_REQ);
        preRequestEventURIMapping.put(Constants.USER_INFO_REQ_2, EventId.RelidAuthServer.INIT_USER_AUTHENTICATION_REQ);

        // post-success url mappings
        postRequestSuccessEventURIMapping.put(POST_AUTH_SUCCESS_URI_STR,
                EventId.RelidAuthServer.AUTHENTICATION_SUCCESS);
        postRequestSuccessEventURIMapping.put(Constants.GENERATE_ACCESS_TOKEN_REQ,
                EventId.RelidAuthServer.GENERATE_ACCESS_TOKEN_SUCCESS);
        postRequestSuccessEventURIMapping.put(Constants.REVOKE_ACCESS_TOKEN_REQ,
                EventId.RelidAuthServer.REVOKE_ACCESS_TOKEN_SUCCESS);
        postRequestSuccessEventURIMapping.put(Constants.AUTHORIZE_REQ,
                EventId.RelidAuthServer.GENERATE_AUTH_CODE_SUCCESS);
        postRequestSuccessEventURIMapping.put(Constants.USER_INFO_REQ, EventId.RelidAuthServer.USER_INFO_REQ_SUCCESS);
        postRequestSuccessEventURIMapping.put(Constants.USER_INFO_REQ_2, EventId.RelidAuthServer.USER_INFO_REQ_SUCCESS);

        // post-failure url mappings
        postRequestFailureEventURIMapping.put(POST_AUTH_FAILED_URI_STR, EventId.RelidAuthServer.AUTHENTICATION_FAILED);
        postRequestFailureEventURIMapping.put(Constants.GENERATE_ACCESS_TOKEN_REQ,
                EventId.RelidAuthServer.GENERATE_ACCESS_TOKEN_FAILED);
        postRequestFailureEventURIMapping.put(Constants.REVOKE_ACCESS_TOKEN_REQ,
                EventId.RelidAuthServer.REVOKE_ACCESS_TOKEN_FAILED);
        postRequestFailureEventURIMapping.put(Constants.AUTHORIZE_REQ,
                EventId.RelidAuthServer.GENERATE_AUTH_CODE_FAILED);
        postRequestFailureEventURIMapping.put(Constants.USER_INFO_REQ, EventId.RelidAuthServer.USER_INFO_REQ_FAILURE);
        postRequestFailureEventURIMapping.put(Constants.USER_INFO_REQ_2, EventId.RelidAuthServer.USER_INFO_REQ_FAILURE);
    }

    @Around("execution(* org.springframework.security.web.authentication.www.BasicAuthenticationFilter.doFilterInternal(..))")
    public void aroundRequest(final ProceedingJoinPoint joinPoint) throws Throwable {

        final Object[] signatureArgs = joinPoint.getArgs();
        final ContentCachingRequestWrapper request = new ContentCachingRequestWrapper(
                (HttpServletRequest) signatureArgs[0]);
        final ContentCachingResponseWrapper response = new ContentCachingResponseWrapper(
                (HttpServletResponse) signatureArgs[1]);

        final String requestURI = request.getRequestURI();

        Utils.generateRequestorId(request, request);
        /*
         * Below condition is to check, weather the event is registered with the
         * requested URI or not. If not then avoid logging and pass the control
         * to the actual method. If you want to log the event for the requested
         * URI, then it should be registered (above defined static block)
         */
        if (!preRequestEventURIMapping.containsKey(requestURI)) {
            joinPoint.proceed(new Object[] { request, response, signatureArgs[2] });
            response.copyBodyToResponse();
            return;
        }

        final HttpSession httpSession = request.getSession();

        if (Constants.AUTHORIZE_REQ.equals(requestURI)) {
            httpSession.setAttribute(EnterpriseInfo.SCOPE, request.getParameter(EnterpriseInfo.SCOPE));
        }

        // Default "N/A" is assigned if basic auth header is invalid and unable
        // to extract the clientId.
        String clientId = "N/A";

        /**
         * Decoding the Auth header to get client ID. If auth header's value is
         * invalid then we're placing N/A as client id. As this is config class
         * specific to event logging, so we are not handling this invalid case
         * here. Its authenticator's job to handle invalid case
         */
        if (StringUtils.hasText(request.getHeader(HttpHeaders.AUTHORIZATION))) {
            final String[] encodedClientDetails = request.getHeader(HttpHeaders.AUTHORIZATION).split(" ", 2);
            if (encodedClientDetails.length == 2) {
                clientId = getDecodedClientId(encodedClientDetails[1]);
                httpSession.setAttribute(EnterpriseInfo.CLIENT_ID, clientId);
            }
            logEvent(request, response, joinPoint, clientId);
        } else {
            logEvent(request, response, joinPoint);
        }
    }

    /**
     * Log events according to the request URIs if authentication header is not
     * available
     * 
     * @param request
     *            : request object having all the request related details
     * @param response
     *            : response object having all the response related details
     * @param joinPoint
     *            : joint point to proceed the intercepted request
     * @throws Throwable
     */
    @SuppressWarnings("unchecked")
    private void logEvent(final ContentCachingRequestWrapper request, final ContentCachingResponseWrapper response,
            final ProceedingJoinPoint joinPoint) throws Throwable {

        final String requestorId = request.getAttribute(Constants.REQUESTOR_ID).toString();
        final String remoteIP = request.getRemoteAddr();
        final String requestURI = request.getRequestURI();
        final Object[] signatureArgs = joinPoint.getArgs();

        // If username is not present at this time
        String clientId = "N/A";

        if (request.getParameterMap().containsKey(EnterpriseInfo.CLIENT_ID)) {
            clientId = request.getParameter(EnterpriseInfo.CLIENT_ID);
            request.getSession().setAttribute(EnterpriseInfo.CLIENT_ID, clientId);

        }

        LOG.info("logEvent() -> requestor id generated {}", requestorId);

        EventLogger.log(preRequestEventURIMapping.get(requestURI), remoteIP, requestorId, clientId, "Received request");

        joinPoint.proceed(new Object[] { request, response, signatureArgs[2] });

        /**
         * If response code is 200 i.e. OK or 303 i.e. Redirected URI log
         * success
         */
        if (response.getStatus() == HttpStatus.OK.value()) {
            EventLogger.log(postRequestSuccessEventURIMapping.get(requestURI), remoteIP, requestorId, clientId,
                    Constants.REQUEST_SUCCESS_MESSAGE);
        } else if (response.getStatus() == HttpStatus.SEE_OTHER.value()) {
            // Below event is not in map because it is not mapped with any URI,
            // it is specific to HTTP response code
            EventLogger.log(EventId.RelidAuthServer.INIT_USER_AUTHENTICATION_SUCCESS, remoteIP, requestorId, clientId,
                    "User Authenticated now access token exchange started");

            /**
             * Invoke SessionService to handle secure cookie related operations
             */
            sessionService.preLogoutSecureCookieHandling(request, response);

            final HttpSession session = request.getSession(false);
            if (session != null) {
                EventLogger.log(EventId.RelidAuthServer.SESSION_INVALIDATED, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request), "Invalidating Session in AuthEventLogger");
                session.invalidate();
                SecurityContextHolder.clearContext();
            }
        } else if (response.getStatus() == HttpStatus.FOUND.value()) {
            // Below event is not in map because it is not mapped with any URI,
            // it is specific to HTTP response code
            EventLogger.log(EventId.RelidAuthServer.INIT_USER_AUTHENTICATION_REQ, remoteIP, requestorId, clientId,
                    "User is not authenticated. Request redirected to login page, to authenticate user");
        } else {
            final String responseStr = getResponseString(response);
            EventLogger.log(postRequestFailureEventURIMapping.get(requestURI), remoteIP, requestorId, clientId,
                    responseStr);
        }
        response.copyBodyToResponse();

    }

    /**
     * Log events according to the request URIs
     * 
     * @param request
     *            : request object having all the request related details
     * @param response
     *            : response object having all the response related details
     * @param joinPoint
     *            : joint point to proceed the intercepted request
     * @param clientId
     *            : client Id of the request owner
     * @throws Throwable
     */
    private void logEvent(final ContentCachingRequestWrapper request, final ContentCachingResponseWrapper response,
            final ProceedingJoinPoint joinPoint, final String clientId) throws Throwable {

        final String requestorId = request.getAttribute(Constants.REQUESTOR_ID).toString();
        final String remoteIP = request.getRemoteAddr();
        final String requestURI = request.getRequestURI();

        LOG.info("logEvent() -> requestor id generated {}", requestorId);
        final Object[] signatureArgs = joinPoint.getArgs();

        EventLogger.log(preRequestEventURIMapping.get(requestURI), remoteIP, requestorId, clientId, "Received request");
        EventLogger.log(preRequestEventURIMapping.get(PRE_AUTH_URI_STR), remoteIP, requestorId, clientId,
                Constants.BASIC_AUTH_INIT_MESSAGE);

        joinPoint.proceed(new Object[] { request, response, signatureArgs[2] });

        if (response.getStatus() == HttpStatus.OK.value()) {
            EventLogger.log(postRequestSuccessEventURIMapping.get(POST_AUTH_SUCCESS_URI_STR), remoteIP, requestorId,
                    clientId, Constants.BASIC_AUTH_SUCCESS_MESSAGE);
            EventLogger.log(postRequestSuccessEventURIMapping.get(requestURI), remoteIP, requestorId, clientId,
                    Constants.REQUEST_SUCCESS_MESSAGE);
        } else {
            final String responseStr = getResponseString(response);

            if (response.getStatus() == HttpStatus.BAD_REQUEST.value()) {
                EventLogger.log(postRequestSuccessEventURIMapping.get(POST_AUTH_SUCCESS_URI_STR), remoteIP, requestorId,
                        clientId, Constants.BASIC_AUTH_SUCCESS_MESSAGE);
                EventLogger.log(postRequestFailureEventURIMapping.get(requestURI), remoteIP, requestorId, clientId,
                        responseStr);
            } else if (response.getStatus() == HttpStatus.UNAUTHORIZED.value()) {
                EventLogger.log(postRequestFailureEventURIMapping.get(POST_AUTH_FAILED_URI_STR), remoteIP, requestorId,
                        clientId, !responseStr.isEmpty() ? responseStr : Constants.BASIC_AUTH_FAILED_MESSAGE);
            } else {
                EventLogger.log(postRequestFailureEventURIMapping.get(requestURI), remoteIP, requestorId, clientId,
                        responseStr);
            }
        }
        response.copyBodyToResponse();

    }

    /**
     * Decode the authorization header and retrieve the clientId
     * 
     * @param authValue
     * @return : clientId
     */
    private String getDecodedClientId(final String authValue) {

        final String[] decodedClientDetails = new String(Base64.decodeBase64(authValue)).split(":", 2);
        return decodedClientDetails.length != 2 ? "N/A" : decodedClientDetails[0];
    }

    /**
     * Parsing full response to get actual description. If ERROR_DESC_STR is not
     * present then print whole response message
     * 
     * @return : Returns the response message
     */
    private String getResponseString(final ContentCachingResponseWrapper response) {

        if (response.getContentAsByteArray().length == 0) {
            return "";
        }

        // Fetching actual response message from response object
        String responseStr = new String(response.getContentAsByteArray(), StandardCharsets.UTF_8);
        final JsonObject jsonObj;
        try {
            jsonObj = Constants.GSON.fromJson(responseStr, JsonObject.class);

        } catch (final Exception e) {
            return responseStr;
        }

        if (jsonObj.has(ERROR_DESC_STR)) {
            responseStr = jsonObj.get(ERROR_DESC_STR).getAsString();
        }
        return responseStr;
    }

}
