package com.uniken.authserver.controller;

import java.security.GeneralSecurityException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.JsonNode;
import com.mastercard.ess.fido2.attestation.AttestationService;
import com.mastercard.ess.fido2.service.Fido2RPRuntimeException;
import com.uniken.authserver.domains.ActivateWebOnlyUserRequest;
import com.uniken.authserver.domains.ConfigurationRequest;
import com.uniken.authserver.domains.RegisterUserRequest;
import com.uniken.authserver.domains.UserRegistrationConfiguration;
import com.uniken.authserver.domains.UserRegistrationOptions;
import com.uniken.authserver.exception.ActivationGenerationAttemptCounterExceededException;
import com.uniken.authserver.exception.InvalidInputException;
import com.uniken.authserver.exception.InvalidTokenException;
import com.uniken.authserver.exception.InvalidUserException;
import com.uniken.authserver.exception.ValidateUserException;
import com.uniken.authserver.services.api.EmailOTPService;
import com.uniken.authserver.services.api.SMSOTPService;
import com.uniken.authserver.services.api.SessionService;
import com.uniken.authserver.services.api.UserService;
import com.uniken.authserver.utility.AuthenticationUtils;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.InputValidationUtils;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.RegisterUserSessionUtils;
import com.uniken.authserver.utility.SessionConstants;
import com.uniken.authserver.utility.UserRegistrationConstants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.fido.FIDO2RegisteredAuthenticationModule;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.fido2.utils.FidoUtils;
import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;
import com.uniken.pass.handler.library.sync.api.PassHandler;
import com.uniken.token.handler.library.TokenHandlerDomain;
import com.uniken.token.handler.library.enums.TokenHandlerStatus;
import com.uniken.token.handler.library.sync.api.TokenHandler;

@Controller
public class RegisterController {

    private static final String REDIRECT_ERROR = "redirect:error";

    private static final Logger LOG = LoggerFactory.getLogger(RegisterController.class);

    private final SessionService sessionService;
    private final UserService userService;
    private final PassHandler passHandler;
    private final SMSOTPService smsotpService;
    private final EmailOTPService emailotpService;
    private final AttestationService attestationService;
    private final TokenHandler tokenHandler;

    @Autowired
    public RegisterController(final SessionService sessionService, final UserService userService,
            final PassHandler passHandler, final SMSOTPService smsotpService, final EmailOTPService emailotpService,
            final AttestationService attestationService, final TokenHandler tokenHandler) {

        this.sessionService = sessionService;
        this.userService = userService;
        this.passHandler = passHandler;
        this.smsotpService = smsotpService;
        this.emailotpService = emailotpService;
        this.attestationService = attestationService;
        this.tokenHandler = tokenHandler;
    }

    @GetMapping(UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI)
    public String getRegisterPage(final HttpServletRequest request, final HttpServletResponse response,
            final HttpSession session, final Model model) {

        final String token = request.getParameter(UserRegistrationConstants.TOKEN);

        try {

            LOG.info("getRegisterPage() -> Showing registration page");

            validateWebOnlyUserActivationRequest(token);

            model.addAttribute("isManageAccountSecurityEnabled", PropertyConstants.MANAGE_SECURITY_PREF_ENABLED);
            model.addAllAttributes(Utils.getPlatformSpecificMessages(request.getHeader(Constants.USER_AGENT_STR),
                    new HashMap<>(PropertyConstants.UI_MESSAGES_PAGE_LOGIN)));
            model.addAllAttributes(Utils.getPlatformSpecificMessages(request.getHeader(Constants.USER_AGENT_STR),
                    new HashMap<>(PropertyConstants.UI_MESSAGES_PAGE_REGISTER)));
            model.addAllAttributes(Utils.getPlatformSpecificMessages(request.getHeader(Constants.USER_AGENT_STR),
                    new HashMap<>(PropertyConstants.UI_MESSAGES_PAGE_REGISTER_USER)));

            final String userId = (String) RegisterUserSessionUtils.getInputParameters().get(SessionConstants.USERNAME);
            final UserAuthInfoVO userInfo = this.userService.getUserAuthInfoByUserName(userId);
            final StringBuilder username = new StringBuilder();
            if (PropertyConstants.UI_MESSAGES_PAGE_LOGIN_USERNAME_START_WITH_FIRSTNAME) {
                username.append(userInfo.getFirstName());
                username.append(" ").append(userInfo.getLastName());
            } else {
                username.append(userInfo.getLastName());
                username.append(" ").append(userInfo.getFirstName());
            }
            if (username.toString().trim().length() > 0) {
                username.append(" (").append(userId).append(")");
            } else {
                username.append(userId);
            }

            model.addAttribute("username", username.toString().replace("  ", " "));

            model.addAllAttributes(Utils.getPlatformSpecificMessages(request.getHeader(Constants.USER_AGENT_STR),
                    new HashMap<>(PropertyConstants.UI_MESSAGES_PAGE_REGISTER_FIDO_CONSENT)));

            return "user_register";

        } catch (final InvalidTokenException e) {
            LOG.error("Invalid token", e);
            return invalidateTokenAndredirectToError(token);

        } catch (final Exception e) {
            LOG.error("Exception", e);
            return invalidateTokenAndredirectToError(token);
        }
    }

    @PostMapping(UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI)
    public String submitRegister(final HttpServletRequest request, final HttpServletResponse response)
            throws Exception {
        LOG.info("Submit registration info");

        /**
         * Invoke SessionService to handle secure cookie related operations
         */
        final Map<String, Object> inputParameters = RegisterUserSessionUtils.getInputParameters();
        inputParameters.put(Constants.REQ_PARAM_REMEMBER_ME,
                Boolean.parseBoolean(request.getParameter(Constants.REQ_PARAM_REMEMBER_ME)));
        inputParameters.put(WebDevMaster.USER_LOCATION_STR, request.getParameter(WebDevMaster.USER_LOCATION_STR));
        inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR,
                request.getParameter(WebDevMaster.WEB_DEV_PARAMETERS_STR));

        sessionService.registerUserSecureCookieHandling(request, response);

        // get redirect uri before invalidating the session
        final String redirectUri = RegisterUserSessionUtils.getRedirectUri();

        // Set the status of token as "Success"
        // after completion of registration flow
        final String token = RegisterUserSessionUtils.getToken();
        tokenHandler.updateTokenStatus(token, TokenHandlerStatus.SUCCESS);

        final HttpSession session = request.getSession();

        /*
         * final Object registrationSecureCookie =
         * session.getAttribute(SessionConstants.REGISTRATION_SECURE_COOKIE); if
         * (registrationSecureCookie != null) {
         * response.addHeader(HttpHeaders.SET_COOKIE, (String)
         * registrationSecureCookie); }
         */

        session.invalidate();

        return "redirect:" + redirectUri;
    }

    /**
     * Gets the configuration.
     *
     * @param request
     *            the request
     * @param response
     *            the response
     * @return the configurations along with accounts list
     */
    @PostMapping(UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI + "/configs")
    @ResponseBody
    public ResponseEntity<UserRegistrationOptions> getConfigurations(final HttpServletRequest request,
            @RequestBody final ConfigurationRequest requestBody, final HttpServletResponse response,
            final HttpSession session) {
        try {
            final String webDeviceParameterChecksum = requestBody.getWebDeviceParameterChecksum();
            final String webDeviceParams = requestBody.getWebDeviceParameters();
            LOG.debug("Received browserFingerprint: {}, webDeviceParams: {}", webDeviceParameterChecksum,
                    webDeviceParams);

            session.setAttribute(SessionConstants.INIT_PARAM, true);
            // AuthenticationUtils.putUserAgentInSession(webDeviceParams,
            // request);

            final Map<String, Object> inputParameters = RegisterUserSessionUtils.getInputParameters();
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, webDeviceParams);

            LOG.info("getConfigurations() : Returning Config Successfully.");

            final String username = (String) session.getAttribute(SessionConstants.USERNAME);

            if (Utils.isNullOrEmpty(username)) {
                throw new IllegalArgumentException("Username not found");
            }

            final UserAuthInfoVO userInfo = this.userService.getUserAuthInfoByUserName(username);

            final UserRegistrationOptions userRegistrationOptions = new UserRegistrationOptions();
            userRegistrationOptions.setUsername(userInfo.getUserId());

            final UserRegistrationConfiguration configuration = new UserRegistrationConfiguration();
            configuration.setRememberMe(PropertyConstants.AUTH_SERVER_ALLOWED_REG_FACTORS.isRememberMe());
            configuration.setPassword(PropertyConstants.AUTH_SERVER_ALLOWED_REG_FACTORS.isPassword());
            configuration.setSmsOtp(PropertyConstants.AUTH_SERVER_ALLOWED_REG_FACTORS.isSmsOtp());
            configuration.setEmailOtp(PropertyConstants.AUTH_SERVER_ALLOWED_REG_FACTORS.isEmailOtp());
            configuration.setFidoPlatform(PropertyConstants.AUTH_SERVER_ALLOWED_REG_FACTORS.isFidoPlatform());
            configuration.setFidoRoaming(PropertyConstants.AUTH_SERVER_ALLOWED_REG_FACTORS.isFidoRoaming());
            configuration.setShowPassStrength(PropertyConstants.SHOW_PASS_STRENGTH);
            configuration.setAlwaysAskForPassword(
                    PropertyConstants.AUTH_SERVER_ALLOWED_REG_FACTORS.isAlwaysAskForPassword());
            try {
                configuration
                        .setDelayBeforeRedirect(Integer.parseInt(PropertyConstants.ACTIVATION_DELAY_BEFORE_REDIRECT));
            } catch (final NumberFormatException numberFormatException) {
                LOG.debug("Activation delay before direct parsing issue",
                        PropertyConstants.ACTIVATION_DELAY_BEFORE_REDIRECT);
            }

            if (configuration.isSmsOtp()) {
                userRegistrationOptions.setMobileNumber(userInfo.getMobileNumber());
                configuration.setMobileNumberRegex(PropertyConstants.GmConstants.MOBILE_NUM_REGEX);
            }
            if (configuration.isEmailOtp()) {
                userRegistrationOptions.setEmail(userInfo.getEmailId());
                configuration.setEmailRegex(PropertyConstants.GmConstants.EMAIL_ID_REGEX);
            }

            configuration.setPassPolicy(Constants.PASS_POLICY);

            userRegistrationOptions.setConfiguration(configuration);

            return ResponseEntity.ok(userRegistrationOptions);

        } catch (final Exception e) {
            LOG.error("getConfigurations() : Exception", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI + "/generateOtp")
    public ResponseEntity<Object> generateOTP(final HttpServletRequest request, final HttpServletResponse response,
            @Valid @RequestBody final RegisterUserRequest registerUserRequest) throws GeneralSecurityException {

        final String authType = registerUserRequest.getAuthType();
        try {

            final String username = RegisterUserSessionUtils.getUserId();
            if (StringUtils.isBlank(username)) {
                throw new UsernameNotFoundException(Constants.USERNAME_NOT_FOUND_IN_SESSION_MSG);
            }

            final String authValue = registerUserRequest.getAuthValue();

            EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_OTP_GENERATION_STARTED,
                    Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                    RegisterUserSessionUtils.getUserId(),
                    String.format("Activation OTP Generation Started For %s Registration", authType));

            LOG.info("generateOTP() : Request received to generate otp : {} ", username);

            final Map<String, Object> inputParameters = new HashMap<>();

            inputParameters.put(Constants.REQ_PARAM_USERNAME, username);

            boolean successful = false;

            if (RegisterUserSessionUtils.getRegisteredAuthTypes().size() != 1) {
                throw new InvalidInputException("Auth type is not allowed to generate: " + authType);
            }

            final Map<String, Integer> activationGenerationAttemptsCounter = RegisterUserSessionUtils
                    .getActivationGenerationAttemptCounter();
            String authTypeName = "";

            if (StringUtils.equals(AuthType.SMSOTP.getName(), authType)
                    && PropertyConstants.AUTH_SERVER_ALLOWED_REG_FACTORS.isSmsOtp()) {

                // Validation of SMS OTP Notification Generation Attempt Counter
                authTypeName = AuthType.SMSOTP.name();
                if (activationGenerationAttemptsCounter.get(authTypeName) < 1) {
                    throw new ActivationGenerationAttemptCounterExceededException(
                            "Activation SMS OTP Generation Attempt Counter Exhausted");
                }

                inputParameters.put(UserRegistrationConstants.MOBILE_NUMBER, authValue);
                RegisterUserSessionUtils.setMobileNumber(authValue);
                successful = smsotpService.saveMobileNumberAndGenerateOTP(request, response, inputParameters);

            } else if (StringUtils.equals(AuthType.EMAILOTP.getName(), authType)
                    && PropertyConstants.AUTH_SERVER_ALLOWED_REG_FACTORS.isEmailOtp()) {

                // Validation of Email OTP Notification Generation Attempt
                // Counter
                authTypeName = AuthType.EMAILOTP.name();
                if (activationGenerationAttemptsCounter.get(authTypeName) < 1) {
                    throw new ActivationGenerationAttemptCounterExceededException(
                            "Activation Email OTP Generation Attempt Counter Exhausted");
                }

                inputParameters.put(UserRegistrationConstants.EMAIL, authValue);
                RegisterUserSessionUtils.setEmail(authValue);
                successful = emailotpService.saveEmailAndGenerateOTP(request, response, inputParameters);

            } else {
                throw new InvalidInputException("Auth type is not allowed to register: " + authType);
            }

            if (successful) {
                EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_OTP_GENERATION_SUCCESS,
                        Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                        RegisterUserSessionUtils.getUserId(),
                        String.format("Activation OTP Generated Successfully For %s Registration", authType));

                // Decrementing the activation generation attempt counter &
                // updating it into the session
                if (activationGenerationAttemptsCounter.get(authTypeName) > 1) {
                    final int decrementedCounter = activationGenerationAttemptsCounter.get(authTypeName) - 1;
                    activationGenerationAttemptsCounter.put(authTypeName, decrementedCounter);

                    EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_DECREMENT_AUTH_GENERATION_ATTMEPT_COUNTER,
                            Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                            AuthenticationUtils.getUsername(request), AuthenticationUtils.getUserAgent(request),
                            "Auth Generation Attempt Counter Decremented For " + authTypeName
                                    + " & current Auth Generation Attempt Counter is " + decrementedCounter);
                } else {
                    activationGenerationAttemptsCounter.put(authTypeName, 0);

                    EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_EXHAUSTED_AUTH_GENERATION_ATTMEPT_COUNTER,
                            Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                            AuthenticationUtils.getUsername(request), AuthenticationUtils.getUserAgent(request),
                            "Auth Generation Attempt Counter Exhausted For " + authTypeName);
                }

                // Updating the generation attempt counter in Session & DB
                RegisterUserSessionUtils.setActivationGenerationAttemptCounter(activationGenerationAttemptsCounter);

            } else {
                EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_OTP_GENERATION_FAILED,
                        Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                        RegisterUserSessionUtils.getUserId(),
                        String.format("Activation OTP Generation Failed For %s Registration", authType));
            }

            return new ResponseEntity<>(successful ? HttpStatus.OK : HttpStatus.UNPROCESSABLE_ENTITY);

        } catch (final InvalidInputException e) {
            LOG.error("generateOTP() -> Exception", e);
            EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_OTP_GENERATION_FAILED,
                    Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                    RegisterUserSessionUtils.getUserId(),
                    String.format("Activation OTP Generation Failed For %s Registration", authType));
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        } catch (final ActivationGenerationAttemptCounterExceededException e) {
            /*
             * If generation attempt counter exceeded for Email / SMS OTP, then
             * send 401 status and handle it at UI side
             */
            return new ResponseEntity<>(e.getMessage(), HttpStatus.UNAUTHORIZED);
        }
    }

    @PostMapping(value = UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI + "/validateOtp")
    public ResponseEntity<Object> validateOtp(final HttpServletRequest request, final HttpServletResponse response,
            @Valid @RequestBody final RegisterUserRequest registerUserRequest) {

        final String authType = registerUserRequest.getAuthType();
        try {

            final String username = RegisterUserSessionUtils.getUserId();
            if (StringUtils.isBlank(username)) {
                throw new UsernameNotFoundException(Constants.USERNAME_NOT_FOUND_IN_SESSION_MSG);
            }

            final String authValue = registerUserRequest.getAuthValue();

            LOG.info("validateOtp() : Request received to validate Otp. User: {} ", username);

            EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_OTP_VALIDATION_STARTED,
                    Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                    RegisterUserSessionUtils.getUserId(),
                    String.format("Activation OTP Validation Started For %s Registration", authType));

            final Map<String, Object> inputParameters = new HashMap<>();

            inputParameters.put(Constants.REQ_PARAM_USERNAME, username);
            inputParameters.put(Constants.REQ_PARAM_AUTH_TYPE, authType);

            boolean successful = false;

            if (RegisterUserSessionUtils.getRegisteredAuthTypes().size() != 1) {
                throw new InvalidInputException("Auth type is not allowed to validate: " + authType);
            }

            if (StringUtils.equals(AuthType.SMSOTP.getName(), authType)) {
                inputParameters.put("SMSOTP", authValue);
                successful = smsotpService.validateUserRegistrationByOTP(request, response, inputParameters);

                if (successful) {
                    RegisterUserSessionUtils.registerAuthType(AuthType.SMSOTP);
                    RegisterUserSessionUtils.setValidatedMobileNumber(RegisterUserSessionUtils.getMobileNumber());
                    activateUser();
                }

            } else if (StringUtils.equals(AuthType.EMAILOTP.getName(), authType)) {
                inputParameters.put("EMAILOTP", authValue);
                successful = emailotpService.validateUserRegistrationByOTP(request, response, inputParameters);

                if (successful) {
                    RegisterUserSessionUtils.registerAuthType(AuthType.EMAILOTP);
                    RegisterUserSessionUtils.setValidatedEmail(RegisterUserSessionUtils.getEmail());
                    activateUser();
                }
            }

            LOG.info("validateOtp() : Request received to validate {} for user: {}, success: {}", authType, username,
                    successful);

            if (successful) {
                EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_OTP_VALIDATION_SUCCESS,
                        Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                        RegisterUserSessionUtils.getUserId(),
                        String.format("Activation OTP Validation Successful For %s Registration", authType));
            } else {
                EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_OTP_VALIDATION_FAILED,
                        Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                        RegisterUserSessionUtils.getUserId(),
                        String.format("Activation OTP Validation Failed For %s Registration", authType));
            }

            return new ResponseEntity<>(successful ? HttpStatus.OK : HttpStatus.UNPROCESSABLE_ENTITY);
        } catch (final Exception e) {
            LOG.error("validateOtp() -> Exception", e);
            EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_OTP_VALIDATION_FAILED,
                    Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                    RegisterUserSessionUtils.getUserId(),
                    String.format("Activation OTP Validation Failed For %s Registration", authType));
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI + "/save-password")
    public ResponseEntity<Object> savePassword(final HttpServletRequest request, final HttpServletResponse response,
            @Valid @RequestBody final RegisterUserRequest registerUserRequest) {
        LOG.info("savePassword() : Request received to save password");

        EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_SAVE_PASSWORD_STARTED,
                Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                RegisterUserSessionUtils.getUserId(), "Activation Save Password Started");

        final String pass = registerUserRequest.getAuthValue();
        final boolean isUserSelectedRememberMe = registerUserRequest.getIsRememberMe();

        final String userId = RegisterUserSessionUtils.getUserId();
        if (StringUtils.isBlank(userId)) {
            throw new UsernameNotFoundException(Constants.USERNAME_NOT_FOUND_IN_SESSION_MSG);
        }

        try {
            if (!InputValidationUtils.isValidUserName(userId)) {
                throw new ValidateUserException("Invalid username");
            }

            if (Utils.isNullOrEmpty(pass)
                    || !Utils.validatePassword(passHandler.decryptReceivedPassword(pass), userId)) {
                LOG.error("savePassword() : Invalid password entered. User: {}", userId);
                return new ResponseEntity<>(HttpStatus.UNPROCESSABLE_ENTITY);
            }

            if (!RegisterUserSessionUtils.getRegisteredAuthTypes().isEmpty()) {
                throw new InvalidInputException("Auth type is not allowed to generate: " + AuthType.PASS.getName());
            }

            final boolean passwordSaved = this.passHandler.storePassword(userId, pass);
            LOG.info("savePassword() : Password saved: {}", passwordSaved);

            if (passwordSaved) {
                RegisterUserSessionUtils.registerAuthType(AuthType.PASS);

                final boolean isRememberMeFunctionalityEnabled = PropertyConstants.AUTH_SERVER_ALLOWED_REG_FACTORS
                        .isRememberMe();

                if (isRememberMeFunctionalityEnabled && isUserSelectedRememberMe) {
                    RegisterUserSessionUtils.setIsRememberMe(true);
                }

                EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_SAVE_PASSWORD_SUCCESS,
                        Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                        RegisterUserSessionUtils.getUserId(), "Activation Save Password Successful");
            } else {
                EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_SAVE_PASSWORD_FAILED,
                        Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                        RegisterUserSessionUtils.getUserId(), "Activation Save Password Failed");
            }

            return new ResponseEntity<>(passwordSaved ? HttpStatus.OK : HttpStatus.UNPROCESSABLE_ENTITY);
        } catch (final Exception e) {
            LOG.error("savePassword() : Exception", e);
            EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_SAVE_PASSWORD_FAILED,
                    Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                    RegisterUserSessionUtils.getUserId(), "Activation Save Password Failed");
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @PostMapping(value = {
            UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI + "/attestation/options" }, produces = {
                    "application/json" }, consumes = { "application/json" })
    public ResponseEntity<JsonNode> options(@RequestBody final JsonNode params, final HttpServletRequest request) {
        LOG.info("attestation options() method is entered");
        EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_FIDO_REG_STEP1_STARTED,
                Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                RegisterUserSessionUtils.getUserId(), "Activation Fido Registration Step 1 Started");
        JsonNode node = null;
        try {
            node = attestationService.options(params);

            EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_FIDO_REG_STEP1_SUCCESS,
                    Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                    RegisterUserSessionUtils.getUserId(), "Activation Fido Registration Step 1 Success");
            return new ResponseEntity<>(node, getFixedHeaders(), HttpStatus.OK);
        } catch (final Fido2RPRuntimeException e) {
            LOG.error("Error while registering FIDO2 device (step1) due to exception", e);
        } catch (final Exception e) {
            LOG.error("Error while registering FIDO2 device (step1) due to exception", e);
        }

        EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_FIDO_REG_STEP1_FAILED,
                Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                RegisterUserSessionUtils.getUserId(), "Activation Fido Registration Step 1 Failed");
        return new ResponseEntity<>(node, getFixedHeaders(), HttpStatus.UNPROCESSABLE_ENTITY);
    }

    @PostMapping(value = {
            UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI + "/attestation/result" }, produces = {
                    "application/json" }, consumes = { "application/json" })
    public ResponseEntity<JsonNode> result(final HttpServletRequest request, @RequestBody final JsonNode params) {
        LOG.info("attestation verify method is entered");
        EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_FIDO_REG_STEP2_STARTED,
                Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                RegisterUserSessionUtils.getUserId(), "Activation Fido Registration Step 2 Started");

        JsonNode node = null;
        try {
            node = attestationService.verify(params);
            RegisterUserSessionUtils.registerAuthType(AuthType.FIDO);

            final JsonNode keyIdNode = params.get("id");
            final List<FIDO2RegisteredAuthenticationModule> registeredAuthenticationModules = userService
                    .fetchRegisteredAuthenticationModuleFromLoginId(RegisterUserSessionUtils.getUserId());
            registeredAuthenticationModules.stream()
                    .filter(regAuthModule -> regAuthModule.getRegistrationKeyId().equals(keyIdNode.asText()))
                    .findFirst()
                    .ifPresent(regAuthModule -> RegisterUserSessionUtils.setFidoReg2fa(FidoUtils.is2FaAuthenticator(
                            regAuthModule.getAuthenticatorAttestationResponse().getAttestationObject())));

            // If user has already activated using other auth options(Except
            // FIDO Platform Auth), then in that case user can register the FIDO
            // Platform Auth, if available. In that case as user is already
            // registered,
            // there is no need to activate the user again.
            if (!RegisterUserSessionUtils.getIsActivatedUser()) {
                activateUser();
            }

            EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_FIDO_REG_STEP2_SUCCESS,
                    Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                    RegisterUserSessionUtils.getUserId(), "Activation Fido Registration Step 2 Success");
            return new ResponseEntity<>(node, getFixedHeaders(), HttpStatus.OK);
        } catch (final Fido2RPRuntimeException e) {
            LOG.error("Error while registering FIDO2 device (step2) due to exception", e);
        } catch (final Exception e) {
            LOG.error("Error while registering FIDO2 device (step2) due to exception", e);
        }

        EventLogger.log(EventId.RelidAuthServer.USER_ACTIVATION_FIDO_REG_STEP2_FAILED,
                Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                RegisterUserSessionUtils.getUserId(), "Activation Fido Registration Step 2 Failed");
        return new ResponseEntity<>(node, getFixedHeaders(), HttpStatus.UNPROCESSABLE_ENTITY);
    }

    /**
     * Gets the configuration.
     *
     * @param request
     *            the request
     * @param response
     *            the response
     * @return the Public Key for encrypting password
     */
    @PostMapping(UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI + "/fetchPublicKey")
    public ResponseEntity<String> fetchPublicKey(final HttpServletRequest request, final HttpServletResponse response) {
        try {
            LOG.info("fetchPublicKey() : Fetching public key");
            return ResponseEntity.ok(passHandler.retrievePublicKey());
        } catch (final Exception e) {
            LOG.error("fetchPublicKey() : Exception", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    private void validateWebOnlyUserActivationRequest(final String token) throws InvalidTokenException {
        if (Utils.isNullOrEmpty(token)) {
            throw new InvalidTokenException("Token is empty");
        }

        final String validatedTokenPayload = tokenHandler.validateToken(token);

        if (Utils.isNullOrEmpty(validatedTokenPayload)) {
            throw new InvalidTokenException("Invalid token");
        }

        final TokenHandlerDomain tokenHandlerDomain = tokenHandler.getTokenInfo(token);
        if (tokenHandlerDomain == null) {
            throw new InvalidTokenException("Invalid token");
        }

        if (Utils.isNullOrEmpty(tokenHandlerDomain.getUserId())) {
            throw new InvalidTokenException("Invalid user id");
        }

        // final TokenHandlerStatus status = tokenHandlerDomain.getStatus();
        // if (tokenHandlerDomain != null && tokenHandlerDomain.getStatus() !=
        // TokenHandlerStatus.PENDING) {
        // throw new InvalidTokenException("Invalid token status: " + status);
        // }

        final ActivateWebOnlyUserRequest activateWebOnlyUserRequest = Utils.mapStringToObject(validatedTokenPayload,
                ActivateWebOnlyUserRequest.class);

        if (activateWebOnlyUserRequest == null) {
            throw new InvalidTokenException("Invalid token payload");
        }

        if (Utils.isNullOrEmpty(activateWebOnlyUserRequest.getRedirectUri())) {
            throw new InvalidTokenException("Invalid redirect uri");
        }

        tokenHandler.updateTokenStatus(token, TokenHandlerStatus.INPROGRESS);

        final String userId = tokenHandlerDomain.getUserId();
        final String redirectUri = activateWebOnlyUserRequest.getRedirectUri();

        LOG.info("validateWebOnlyUserActivationRequest() -> User Id: {}", userId);

        final UserAuthInfoVO userInfo = this.userService.getUserAuthInfoByUserName(userId);

        if (userInfo == null) {
            throw new InvalidUserException("User not found: " + userId);
        }

        if (RelIdUserStatus.CREATED != userInfo.getUserStatus() && RelIdUserStatus.RESET != userInfo.getUserStatus()) {
            throw new InvalidUserException(
                    String.format("Invalid user status for user: %s, status: %s", userId, userInfo.getUserStatus()));
        }

        RegisterUserSessionUtils.setToken(token);
        RegisterUserSessionUtils.setUsername(userId);
        RegisterUserSessionUtils.setRedirectUri(redirectUri);
    }

    private void activateUser() {
        final String userId = RegisterUserSessionUtils.getUserId();

        LOG.info("activateUser() -> Activating user: {}", userId);

        final String token = RegisterUserSessionUtils.getToken();

        if (RegisterUserSessionUtils.isUserAuthenticated()) {

            final UserAuthInfoVO userAuthInfo = userService.getUserAuthInfoByUserName(userId);

            boolean webOnly = true;
            final RelIdUserStatus userStatus = userAuthInfo.getUserStatus();
            final String mobileNumber = RegisterUserSessionUtils.getValidatedMobileNumber();
            final String email = RegisterUserSessionUtils.getValidatedEmail();
            final boolean isUserWebOnly = Boolean.TRUE.equals(userAuthInfo.isWebOnly());

            if (userStatus == RelIdUserStatus.CREATED || userStatus == RelIdUserStatus.RESET) {
                this.userService.activateUser(userId, userStatus, webOnly,
                        RegisterUserSessionUtils.getRegisteredAuthTypes(), mobileNumber, email);
            } else if (userStatus == RelIdUserStatus.ACTIVE && !isUserWebOnly) {
                LOG.info("User is already activated");
                webOnly = false;
                this.userService.activateUser(userId, userStatus, webOnly,
                        RegisterUserSessionUtils.getRegisteredAuthTypes(), mobileNumber, email);
            } else {
                tokenHandler.updateTokenStatus(token, TokenHandlerStatus.ERROR);
                throw new InvalidUserException(
                        String.format("Invalid user status for user: %s, status: %s, isUserWebOnly: %s", userId,
                                userStatus, isUserWebOnly));
            }

            if (RegisterUserSessionUtils.getIsRememberMe()) {
                RegisterUserSessionUtils.setIsActivatedUser(true);
            }

            LOG.info("activateUser() -> Successfully activated user: {}", userId);
        } else {

            tokenHandler.updateTokenStatus(token, TokenHandlerStatus.ERROR);
            throw new InvalidUserException("Could not activate user: " + userId);
        }

    }

    private String invalidateTokenAndredirectToError(final String token) {
        LOG.info("invalidateTokenAndredirectToError() -> Invalidating token and redirecting to error. Token: {}",
                token);
        if (!Utils.isNullOrEmpty(token)) {
            final boolean updatedTokenStatus = tokenHandler.updateTokenStatus(token, TokenHandlerStatus.INVALIDATED);
            LOG.debug("invalidateTokenAndredirectToError() -> Updated token status: {}", updatedTokenStatus);
        }
        RegisterUserSessionUtils.getSession().invalidate();
        return REDIRECT_ERROR;
    }

    private HttpHeaders getFixedHeaders() {
        final HttpHeaders headers = new HttpHeaders();
        headers.set("Cache-Control", "no-store");
        headers.set("Pragma", "no-cache");
        headers.set("Content-Type", "application/json;charset=UTF-8");
        headers.set("X-FRAME-OPTIONS", "DENY");
        return headers;
    }
}
