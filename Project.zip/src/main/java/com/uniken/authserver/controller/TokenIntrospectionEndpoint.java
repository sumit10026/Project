package com.uniken.authserver.controller;

import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.common.exceptions.InvalidTokenException;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.springframework.security.oauth2.provider.error.DefaultWebResponseExceptionTranslator;
import org.springframework.security.oauth2.provider.error.WebResponseExceptionTranslator;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.server.ServerErrorException;

import com.uniken.authserver.services.api.TokenEndpointsServices;

@Controller
public class TokenIntrospectionEndpoint {

    private final TokenEndpointsServices endpointsServices;

    protected final Logger logger = LoggerFactory.getLogger(getClass());

    private final WebResponseExceptionTranslator<OAuth2Exception> exceptionTranslator = new DefaultWebResponseExceptionTranslator();

    public TokenIntrospectionEndpoint(final TokenEndpointsServices endpointsServices) {
        this.endpointsServices = endpointsServices;
    }

    @PostMapping(value = "/oauth/introspect")
    @ResponseBody
    public Map<String, ?> checkToken(final Authentication authentication, @RequestParam("token") final String value,
            @RequestParam(value = "token_type_hint", required = false) final String tokenTypeHint) {

        logger.info("introspect() -> Introspecting a token. Token type hint: {}", tokenTypeHint);

        return endpointsServices.instrospectToken(authentication, value, tokenTypeHint);

    }

    @ExceptionHandler(InvalidTokenException.class)
    public ResponseEntity<OAuth2Exception> handleInvalidTokenException(final Exception e) throws Exception {
        logger.info("Handling error: " + e.getClass().getSimpleName() + ", " + e.getMessage());
        // This isn't an oauth resource, so we don't want to send an
        // unauthorized code here. The client has already authenticated
        // successfully with basic auth and should just
        // get back the invalid token error.
        @SuppressWarnings("serial")
        final InvalidTokenException e400 = new InvalidTokenException(e.getMessage()) {
            @Override
            public int getHttpErrorCode() {
                return 400;
            }
        };
        return exceptionTranslator.translate(e400);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<OAuth2Exception> handleException(final Exception e) throws Exception {
        logger.info("Handling error: " + e.getClass().getSimpleName() + ", " + e.getMessage(), e);
        // This isn't an oauth resource, so we don't want to send an
        // unauthorized code here. The client has already authenticated
        // successfully with basic auth and should just
        // get back the server error.
        @SuppressWarnings("serial")
        final ServerErrorException e500 = new ServerErrorException(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase(),
                e);
        return exceptionTranslator.translate(e500);
    }

}
