package com.uniken.authserver.controller;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uniken.authserver.domains.AccountRecoveryConfiguration;
import com.uniken.authserver.domains.AccountRecoveryCredentialRequest;
import com.uniken.authserver.domains.AccountRecoveryCredentialResponse;
import com.uniken.authserver.domains.AccountRecoveryOptions;
import com.uniken.authserver.domains.AccountRecoveryTokenDetails;
import com.uniken.authserver.domains.AccountRecoveryUserRequest;
import com.uniken.authserver.domains.ConfigurationRequest;
import com.uniken.authserver.exception.InvalidTokenException;
import com.uniken.authserver.exception.InvalidUserException;
import com.uniken.authserver.services.api.AccountRecoveryCredentialService;
import com.uniken.authserver.services.api.UserService;
import com.uniken.authserver.utility.AccountRecoveryConstants;
import com.uniken.authserver.utility.AccountRecoverySessionUtils;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.InputValidationUtils;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.SessionConstants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.pass.handler.library.sync.api.PassHandler;
import com.uniken.token.handler.library.TokenHandlerDomain;
import com.uniken.token.handler.library.enums.TokenHandlerStatus;
import com.uniken.token.handler.library.sync.api.TokenHandler;

@Controller
public class AccountRecoveryCredentialsController {

    private static final Logger LOG = LoggerFactory.getLogger(AccountRecoveryCredentialsController.class);

    @Autowired
    private TokenHandler tokenHandler;

    @Autowired
    private UserService userService;

    @Autowired
    private AccountRecoveryCredentialService accountRecoveryCredentialService;

    @Autowired
    private PassHandler passHandler;

    @PostMapping(AccountRecoveryConstants.GET_CREDENTIAL_ACTIVATION_TOKEN)
    public String getTokenForCredentialActivation(final HttpServletRequest request, final HttpServletResponse response,
            @RequestBody final AccountRecoveryUserRequest accountRecoveryUserRequest) {

        return "token";
    }

    @GetMapping(AccountRecoveryConstants.ACCOUNT_RECOVERY_CREDENTIAL_BASE_URI)
    public String getCredentialRecoveryPage(final HttpServletRequest request, final HttpServletResponse response,
            @RequestParam(value = AccountRecoveryConstants.ARC_TOKEN, required = true) String accountRecoveryCredentialToken,
            final Model model) {

        try {

            // Reset session parameters
            AccountRecoverySessionUtils.resetAccountRecoverySession();

            // Dummy Token Part
            final AccountRecoveryTokenDetails accountRecoveryTokenDetails = new AccountRecoveryTokenDetails();
            accountRecoveryTokenDetails.setAuthFactorNeedsToReset(AuthType.PASS.getName());
            accountRecoveryTokenDetails.setUserId("rupesh");
            accountRecoveryTokenDetails.setRedirectUri(
                    "https://localhost:8006/relid/authserver/oauth/authorize?scope=all openid&client_id=Y2MwYzVkNWEtY2Q0YS00N2QxLThjNWQtNWFjZDRhYTdkMWQx&response_type=code&state=12345");
            accountRecoveryCredentialToken = tokenHandler
                    .generateToken(new ObjectMapper().writeValueAsString(accountRecoveryTokenDetails), "rupesh");

            // Token Validation
            validateARCToken(accountRecoveryCredentialToken);

            model.addAttribute("arc_token", accountRecoveryCredentialToken);

            model.addAllAttributes(Utils.getPlatformSpecificMessages(request.getHeader(Constants.USER_AGENT_STR),
                    new HashMap<>(PropertyConstants.UI_MESSAGES_PAGE_ACCOUNT_RECOVERY_CREDENTIAL)));

        } catch (final Exception e) {
            return invalidateTokenAndRedirectToError(accountRecoveryCredentialToken);
        }

        return "accountRecoveryCredential";
    }

    @GetMapping(AccountRecoveryConstants.GET_RESET_CREDENTIAL_FACTOR)
    public ResponseEntity<AccountRecoveryCredentialResponse> getResetCredentialFactor(final HttpServletRequest request,
            final HttpServletResponse response,
            @RequestParam(value = AccountRecoveryConstants.ARC_TOKEN, required = true) final String accountRecoveryCredentialToken) {

        final AccountRecoveryCredentialResponse arcResponse = new AccountRecoveryCredentialResponse();
        try {
            if (Utils.isNullOrEmpty(accountRecoveryCredentialToken)
                    || !accountRecoveryCredentialToken.equals(AccountRecoverySessionUtils.getARCToken())) {
                throw new InvalidTokenException("Invalid Token Passed");
            }

            final AccountRecoveryTokenDetails accountRecoveryTokenDetails = validateARCToken(
                    accountRecoveryCredentialToken);

            AccountRecoverySessionUtils.setARCTokenDetails(accountRecoveryTokenDetails);

            arcResponse.setResetCredentialFactor(
                    accountRecoveryCredentialService.getResetCredentialFactor(accountRecoveryTokenDetails));
            arcResponse.setUsername(accountRecoveryTokenDetails.getUserId());

        } catch (final InvalidTokenException e) {
            LOG.error("getResetCredentialFactor() : token: {}", accountRecoveryCredentialToken, e);
            return new ResponseEntity<>(new AccountRecoveryCredentialResponse(), HttpStatus.UNAUTHORIZED);
        }
        return new ResponseEntity<>(arcResponse, HttpStatus.OK);

    }

    /**
     * Gets the configuration.
     *
     * @param request
     *            the request
     * @param response
     *            the response
     * @return the configurations
     */
    @PostMapping(AccountRecoveryConstants.ACCOUNT_RECOVERY_CREDENTIAL_CONFIGS)
    @ResponseBody
    public ResponseEntity<AccountRecoveryOptions> getConfigurations(final HttpServletRequest request,
            @RequestBody final ConfigurationRequest requestBody, final HttpServletResponse response,
            final HttpSession session) {
        try {
            final String webDeviceParameterChecksum = requestBody.getWebDeviceParameterChecksum();
            final String webDeviceParams = requestBody.getWebDeviceParameters();
            LOG.debug("Received browserFingerprint: {}, webDeviceParams: {}", webDeviceParameterChecksum,
                    webDeviceParams);

            session.setAttribute(SessionConstants.INIT_PARAM, true);

            LOG.info("getConfigurations() : Returning Config Successfully.");

            final String username = AccountRecoverySessionUtils.getARCUsername();

            if (Utils.isNullOrEmpty(username)) {
                throw new IllegalArgumentException("Username not found");
            }

            final UserAuthInfoVO userInfo = this.userService.getUserAuthInfoByUserName(username);

            final AccountRecoveryOptions accountRecoveryOptions = new AccountRecoveryOptions();
            accountRecoveryOptions.setUsername(userInfo.getUserId());

            final AccountRecoveryConfiguration configuration = new AccountRecoveryConfiguration();
            configuration.setPassword(PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isPassword());
            configuration.setSmsOtp(PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isSmsOtp());
            configuration.setEmailOtp(PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isEmailOtp());
            configuration.setFidoRoaming(PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isFidoRoaming());
            configuration.setShowPassStrength(PropertyConstants.SHOW_PASS_STRENGTH);

            try {
                configuration
                        .setDelayBeforeRedirect(Integer.parseInt(PropertyConstants.ACTIVATION_DELAY_BEFORE_REDIRECT));
            } catch (final NumberFormatException numberFormatException) {
                LOG.debug("Activation delay before direct parsing issue : {}",
                        PropertyConstants.ACTIVATION_DELAY_BEFORE_REDIRECT);
            }

            if (configuration.isSmsOtp()) {
                accountRecoveryOptions.setMobileNumber(userInfo.getMobileNumber());
                configuration.setMobileNumberRegex(PropertyConstants.GmConstants.MOBILE_NUM_REGEX);
            }
            if (configuration.isEmailOtp()) {
                accountRecoveryOptions.setEmail(userInfo.getEmailId());
                configuration.setEmailRegex(PropertyConstants.GmConstants.EMAIL_ID_REGEX);
            }

            configuration.setPassPolicy(Constants.PASS_POLICY);

            accountRecoveryOptions.setConfiguration(configuration);

            return ResponseEntity.ok(accountRecoveryOptions);

        } catch (final Exception e) {
            LOG.error("getConfigurations() : Exception", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    /**
     * Gets the configuration.
     *
     * @param request
     *            the request
     * @param response
     *            the response
     * @return the Public Key for encrypting password
     */
    @PostMapping(AccountRecoveryConstants.ACCOUNT_RECOVERY_FETCH_PUBLIC_KEY)
    public ResponseEntity<String> fetchPublicKey(final HttpServletRequest request, final HttpServletResponse response) {
        try {
            LOG.info("fetchPublicKey() : Fetching public key");
            return ResponseEntity.ok(passHandler.retrievePublicKey());
        } catch (final Exception e) {
            LOG.error("fetchPublicKey() : Exception", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(AccountRecoveryConstants.RESET_CREDENTIAL)
    public ResponseEntity<Object> resetCredential(final HttpServletRequest request, final HttpServletResponse response,
            @Valid @RequestBody final AccountRecoveryCredentialRequest accountRecoveryCredentialRequest) {
        LOG.info("resetCredential() : Request received to reset credential");

        try {
            validateResetCredentialRequest(accountRecoveryCredentialRequest);

            final boolean hasReset = accountRecoveryCredentialService
                    .resetCredentialFactor(accountRecoveryCredentialRequest);

            return new ResponseEntity<>(hasReset ? HttpStatus.OK : HttpStatus.UNPROCESSABLE_ENTITY);
        } catch (final Exception e) {
            LOG.error("resetCredential() : Exception", e);
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

    @PostMapping(AccountRecoveryConstants.SUBMIT_ARC_FORM)
    public String submitARCForm(final HttpServletRequest request, final HttpServletResponse response) {
        LOG.info("Redirecting to login after account recovery");

        final HttpSession session = AccountRecoverySessionUtils.getSession();

        // Get Redirect URI before invalidating the session
        final String redirectUri = AccountRecoverySessionUtils.getARCTokenDetails().getRedirectUri();

        final Set<String> pendingResetCredentialFactorSet = new HashSet<>(
                AccountRecoverySessionUtils.getPendingResetCredentialFactorSet());
        final Set<String> completedResetCredentialFactorSet = new HashSet<>(
                AccountRecoverySessionUtils.getCompletedResetCredentialFactorSet());
        pendingResetCredentialFactorSet.retainAll(completedResetCredentialFactorSet);

        if (CollectionUtils.isEmpty(pendingResetCredentialFactorSet)) {
            return "redirect:error";
        }

        // Set the status of token as "Success"
        // after completion of registration flow
        final String token = AccountRecoverySessionUtils.getARCToken();
        tokenHandler.updateTokenStatus(token, TokenHandlerStatus.SUCCESS);

        session.invalidate();
        return "redirect:" + redirectUri;
    }

    private AccountRecoveryTokenDetails validateARCToken(final String token) throws InvalidTokenException {
        if (Utils.isNullOrEmpty(token)) {
            throw new InvalidTokenException("Token is empty");
        }

        final String validatedTokenPayload = tokenHandler.validateToken(token);

        if (Utils.isNullOrEmpty(validatedTokenPayload)) {
            throw new InvalidTokenException("Invalid token");
        }

        final TokenHandlerDomain tokenHandlerDomain = tokenHandler.getTokenInfo(token);
        if (tokenHandlerDomain == null) {
            throw new InvalidTokenException("Invalid token");
        }

        if (Utils.isNullOrEmpty(tokenHandlerDomain.getUserId())) {
            throw new InvalidTokenException("Invalid user id");
        }

        final AccountRecoveryTokenDetails accountRecoveryTokenDetails = Utils.mapStringToObject(validatedTokenPayload,
                AccountRecoveryTokenDetails.class);

        if (accountRecoveryTokenDetails == null) {
            throw new InvalidTokenException("Invalid token payload");
        }

        if (Utils.isNullOrEmpty(accountRecoveryTokenDetails.getRedirectUri())) {
            throw new InvalidTokenException("Invalid redirect uri");
        }

        if (Utils.isNullOrEmpty(accountRecoveryTokenDetails.getFirstLevelFactor())
                && Utils.isNullOrEmpty(accountRecoveryTokenDetails.getAuthFactorNeedsToReset())) {
            throw new InvalidTokenException("Invalid Auth Factor Details Provided In Token");
        }

        final String userId = tokenHandlerDomain.getUserId();

        LOG.info("validateWebOnlyUserActivationRequest() -> User Id: {}", userId);

        final UserAuthInfoVO userInfo = this.userService.getUserAuthInfoByUserName(userId);

        if (userInfo == null) {
            throw new InvalidUserException("User not found: " + userId);
        }

        if (RelIdUserStatus.ACTIVE != userInfo.getUserStatus()) {
            throw new InvalidUserException(
                    String.format("Invalid user status for user: %s, status: %s", userId, userInfo.getUserStatus()));
        }

        // Storing token in session
        AccountRecoverySessionUtils.setARCToken(token);
        AccountRecoverySessionUtils.setARCUsername(userId);

        return accountRecoveryTokenDetails;
    }

    private void validateResetCredentialRequest(
            final AccountRecoveryCredentialRequest accountRecoveryCredentialRequest) {

        if (accountRecoveryCredentialRequest == null) {
            throw new IllegalArgumentException("Invalid Reset Credential Request");
        }

        if (StringUtils.isBlank(AccountRecoverySessionUtils.getARCUsername())) {
            throw new UsernameNotFoundException(Constants.USERNAME_NOT_FOUND_IN_SESSION_MSG);
        }

        final String username = accountRecoveryCredentialRequest.getUserName();

        if (!InputValidationUtils.isValidUserName(username)
                || !StringUtils.equals(username, AccountRecoverySessionUtils.getARCUsername())) {
            throw new IllegalArgumentException("Invalid username");
        }

        if (!AuthType.isValidElement(accountRecoveryCredentialRequest.getAuthType())) {
            throw new IllegalArgumentException("Invalid Auth Type");
        }

        if (StringUtils.isBlank(accountRecoveryCredentialRequest.getAuthValue())) {
            throw new IllegalArgumentException("Invalid Auth Value");
        }

    }

    private String invalidateTokenAndRedirectToError(final String token) {
        LOG.info("invalidateTokenAndredirectToError() -> Invalidating token and redirecting to error. Token: {}",
                token);
        if (!Utils.isNullOrEmpty(token)) {
            final boolean updatedTokenStatus = tokenHandler.updateTokenStatus(token, TokenHandlerStatus.INVALIDATED);
            LOG.debug("invalidateTokenAndredirectToError() -> Updated token status: {}", updatedTokenStatus);
        }
        AccountRecoverySessionUtils.getSession().invalidate();
        return AccountRecoveryConstants.REDIRECT_ERROR;
    }

}
