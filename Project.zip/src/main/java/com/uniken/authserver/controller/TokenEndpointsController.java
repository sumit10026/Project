package com.uniken.authserver.controller;

import java.security.Principal;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.common.exceptions.InvalidRequestException;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.error.DefaultWebResponseExceptionTranslator;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.uniken.authserver.services.api.TokenEndpointsServices;
import com.uniken.domains.auth.RevokeTokenResponse;

@Controller
@RequestMapping("/oauth/token")
public class TokenEndpointsController {

    private static final Logger LOG = LoggerFactory.getLogger(TokenEndpointsController.class);

    private final Set<HttpMethod> allowedRequestMethods = new HashSet<>(Arrays.asList(HttpMethod.POST));

    private final DefaultWebResponseExceptionTranslator exceptionTranslator = new DefaultWebResponseExceptionTranslator();

    @Autowired
    private TokenEndpointsServices endpointsServices;

    /**
     * @param principal
     * @param parameters
     * @param request
     * @param response
     * @return
     * @throws HttpRequestMethodNotSupportedException
     */
    @GetMapping(value = "/revoke")
    public ResponseEntity<RevokeTokenResponse> getRevokeToken(final HttpServletRequest request,
            final HttpServletResponse response, final Principal principal,
            @RequestParam(value = "token", required = true) final String token,
            @RequestParam(value = "token_type", required = true) final String tokenType)
            throws HttpRequestMethodNotSupportedException {
        if (!allowedRequestMethods.contains(HttpMethod.GET)) {
            throw new HttpRequestMethodNotSupportedException("GET");
        }
        return postRevokeToken(request, response, principal, token, tokenType);
    }

    /**
     * Endpoint to revoke any tokens that are issued to user/clients for
     * accessing resource. This endpoint is useful in a situation where
     * suspicious activity is found in enterprise app & require an immediate
     * block of such request
     * 
     * @title Revoke Access Token
     * @param request
     *            the request
     * @param response
     *            the response
     * @param token
     *            the token
     * @param tokenType
     *            the token type
     * @return the response entity
     */
    @PostMapping(value = "/revoke")
    public ResponseEntity<RevokeTokenResponse> postRevokeToken(final HttpServletRequest request,
            final HttpServletResponse response, final Principal principal,
            @RequestParam(value = "token", required = true) final String token,
            @RequestParam(value = "token_type", required = true) final String tokenType) {

        LOG.info("revokeToken() : Request received for revoke token. Client Id : {} ", principal.getName());

        if (!(principal instanceof Authentication)) {
            throw new InsufficientAuthenticationException(
                    "There is no client authentication. Try adding an appropriate authentication filter.");
        }

        if (!StringUtils.hasText(token)) {
            throw new InvalidRequestException("Missing token");
        }

        if (!StringUtils.hasText(tokenType)) {
            throw new InvalidRequestException("Missing token type");
        }

        final String clientId = getClientId(principal);

        endpointsServices.revokeToken(token, tokenType, clientId);

        final RevokeTokenResponse revokeTokenResponse = new RevokeTokenResponse(token, tokenType, "Success");

        return getResponse(revokeTokenResponse);
    }

    /**
     * @param principal
     *            the currently authentication principal
     * @return a client id if there is one in the principal
     */
    private String getClientId(final Principal principal) {
        final Authentication client = (Authentication) principal;
        if (!client.isAuthenticated()) {
            throw new InsufficientAuthenticationException("The client is not authenticated.");
        }
        String clientId = client.getName();
        if (client instanceof OAuth2Authentication) {
            // Might be a client and user combined authentication
            clientId = ((OAuth2Authentication) client).getOAuth2Request().getClientId();
        }
        return clientId;
    }

    private ResponseEntity<RevokeTokenResponse> getResponse(final RevokeTokenResponse accessToken) {
        final HttpHeaders headers = new HttpHeaders();
        headers.set("Cache-Control", "no-store");
        headers.set("Pragma", "no-cache");
        headers.set("Content-Type", "application/json;charset=UTF-8");
        headers.set("X-FRAME-OPTIONS", "DENY");
        return new ResponseEntity<>(accessToken, headers, HttpStatus.OK);
    }

    /**
     * Handles exception post authentication. It is assumed here that this
     * method will handle exceptions where client request has invalid input.
     *
     * @param e
     *            the e
     * @return the response entity
     * @throws Exception
     *             the exception
     */
    @ExceptionHandler(OAuth2Exception.class)
    public ResponseEntity<OAuth2Exception> handleException(final OAuth2Exception e) throws Exception {
        LOG.info("Handling error: {}, {} ", e.getClass().getSimpleName(), e.getMessage());
        // The client has already authenticated successfully with basic auth so
        // we don't want to send an unauthorized code here and we should just
        // get back the invalid token error.
        @SuppressWarnings("serial")
        final OAuth2Exception e400 = new OAuth2Exception(e.getMessage()) {

            @Override
            public String getOAuth2ErrorCode() {
                return e.getOAuth2ErrorCode();
            }

            @Override
            public int getHttpErrorCode() {
                return 400;
            }
        };
        return exceptionTranslator.translate(e400);
    }

}
