package com.uniken.authserver.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class ErrorController {

    @PostMapping("/errorHandler")
    public String getErrorPage(final HttpServletRequest request, final HttpServletResponse response) {

     //  return "redirect:/" + request.getAttribute("statusCode").toString() + ".html";

        return "redirect:/error.html";
    }

}
