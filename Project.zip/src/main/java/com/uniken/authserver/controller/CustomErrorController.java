package com.uniken.authserver.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.uniken.authserver.utility.InputValidationUtils;
import com.uniken.authserver.utility.PropertyConstants;

@Controller
public class CustomErrorController
        implements
        ErrorController {

    private static final Logger LOG = LoggerFactory.getLogger(CustomErrorController.class);

    @GetMapping("/error")
    public ModelAndView handleError(final HttpServletRequest request, final HttpServletResponse response,
            final Authentication authentication, final Model model) {

        final HttpSession session = request.getSession(false);
        if (InputValidationUtils.isRedirectToErrorPage(session)) {
            session.invalidate();
            SecurityContextHolder.clearContext();
        }

        // FIXME: Uncomment code below after having status code specific error
        // pages
        final String errorPage = "error";
        // if (request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE) !=
        // null) {
        // errorPage =
        // request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE).toString();
        // }
        //
        // if (errorPage == null && request.getAttribute("statusCode") != null)
        // {
        // errorPage = request.getAttribute("statusCode").toString();
        // }
        // return errorPage;

        model.addAttribute("errorMessage", PropertyConstants.DEFAULT_GLOBAL_ERROR_PAGE_MSG);

        return new ModelAndView(String.format("error/%s", errorPage), model.asMap());
    }

}
