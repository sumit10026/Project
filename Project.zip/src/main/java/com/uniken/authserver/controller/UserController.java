package com.uniken.authserver.controller;

import java.security.GeneralSecurityException;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.common.exceptions.InvalidClientException;
import org.springframework.security.oauth2.common.exceptions.InvalidRequestException;
import org.springframework.security.oauth2.common.exceptions.InvalidTokenException;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.error.DefaultWebResponseExceptionTranslator;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.uniken.authserver.domains.GenericResponse;
import com.uniken.authserver.domains.UserInfo;
import com.uniken.authserver.domains.ValidateUserRequest;
import com.uniken.authserver.domains.ValidateUserResponse;
import com.uniken.authserver.exception.AttemptCounterExceededException;
import com.uniken.authserver.exception.AuthGenerationAttemptCounterExceededException;
import com.uniken.authserver.exception.InvalidPendingAuthTypesException;
import com.uniken.authserver.exception.InvalidUserException;
import com.uniken.authserver.exception.RelIDNotificationRejectedException;
import com.uniken.authserver.exception.SessionConflictedException;
import com.uniken.authserver.exception.ValidateUserException;
import com.uniken.authserver.services.api.AuthenticationService;
import com.uniken.authserver.services.impl.EmailOTPServiceImpl;
import com.uniken.authserver.services.impl.GenerateRVNMessageServiceImpl;
import com.uniken.authserver.services.impl.SMSOTPServiceImpl;
import com.uniken.authserver.services.impl.UserServiceImpl;
import com.uniken.authserver.utility.AuthenticationUtils;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.InputValidationUtils;
import com.uniken.authserver.utility.MessageConstants;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.SessionConstants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.relid.device.UserLocation;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;

@Controller
@RequestMapping("/oauth")
public class UserController {

    @Autowired
    private GenerateRVNMessageServiceImpl generateRVNMessageServiceImpl;

    @Autowired
    private UserServiceImpl userServiceImpl;

    @Autowired
    private DefaultTokenServices defaultTokenServices;

    @Autowired
    private SMSOTPServiceImpl smsotpServiceImpl;

    @Autowired
    private EmailOTPServiceImpl emailotpServiceImpl;

    @Autowired
    private AuthenticationService authenticationService;

    private static final Logger LOG = LoggerFactory.getLogger(UserController.class);

    private final Set<HttpMethod> allowedRequestMethods = new HashSet<>(Arrays.asList(HttpMethod.POST));

    private final DefaultWebResponseExceptionTranslator exceptionTranslator = new DefaultWebResponseExceptionTranslator();

    /*
     * As per RFC 2616 [RFC2616], both POST and GET methods should be allowed
     * for /userInfo or /userinfo API
     */

    @GetMapping(value = { "/userInfo", "/userinfo" })
    public ResponseEntity<UserInfo> getUserInfo(final HttpServletRequest request, final HttpServletResponse response) {
        LOG.info("getUserInfo() : Request received to get user info");
        return postUserInfo(request, response);
    }

    @PostMapping(value = { "/userInfo", "/userinfo" })
    public ResponseEntity<UserInfo> postUserInfo(final HttpServletRequest request, final HttpServletResponse response) {

        LOG.info("postUserInfo() : Request received to get user info");

        final String authHeader = request.getHeader(Constants.AUTH_HEADER);
        final String[] authorizationArr = Utils.getAuthParams(authHeader);
        final String method = authorizationArr[0];
        final String accessToken = authorizationArr[1];

        if (!Constants.AUTH_HEADER_BEARER.equalsIgnoreCase(method)) {
            throw new InvalidRequestException("Invalid authorization header");
        }

        final OAuth2Authentication authentication = defaultTokenServices.loadAuthentication(accessToken);
        final UserInfo userInfo = userServiceImpl.getUserInfo(authentication.getName());

        return new ResponseEntity<>(userInfo, getFixedHeaders(), HttpStatus.OK);
    }

    @GetMapping(value = "/validateUser")
    public void getValidateUser(final HttpServletRequest request, final HttpServletResponse response,
            @RequestParam(value = Constants.REQ_PARAM_USERNAME, required = true) final String username,
            @RequestParam(value = WebDevMaster.USER_LOCATION_STR, required = false) String webDeviceLocation,
            @RequestParam(value = WebDevMaster.WEB_DEV_PARAMETERS_STR, required = true) final String webDeviceParams,
            @RequestParam(value = WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, required = false) final String browserFingerprint)
            throws HttpRequestMethodNotSupportedException, GeneralSecurityException {

        if (!allowedRequestMethods.contains(HttpMethod.GET)) {
            throw new HttpRequestMethodNotSupportedException("GET");
        }
        if (webDeviceLocation == null || webDeviceLocation.isEmpty()) {
            final UserLocation locationDefault = new UserLocation(Constants.USERLOCATION_NOT_AVAILABLE_DEFAULT_VALUE,
                    Constants.USERLOCATION_NOT_AVAILABLE_DEFAULT_VALUE);
            webDeviceLocation = Constants.GSON.toJson(locationDefault);
        }
        postValidateUser(request, response, username, webDeviceLocation, webDeviceParams, browserFingerprint);
    }

    @SuppressWarnings("unchecked")
    @PostMapping(value = "/validateUser")
    public ResponseEntity<Object> postValidateUser(final HttpServletRequest request, final HttpServletResponse response,
            @RequestParam(value = Constants.REQ_PARAM_USERNAME, required = true) final String username,
            @RequestParam(value = WebDevMaster.USER_LOCATION_STR, required = false) final String webDeviceLocation,
            @RequestParam(value = WebDevMaster.WEB_DEV_PARAMETERS_STR, required = true) final String webDeviceParams,
            @RequestParam(value = WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, required = false) final String browserFingerprint)
            throws GeneralSecurityException {

        try {
            // Validating Client Id in Request
            AuthenticationUtils.validateClientId(request);

            final HttpSession httpSession = request.getSession();

            final String userName = (String) httpSession.getAttribute(SessionConstants.CURRENT_USERNAME);
            if (StringUtils.isBlank(userName)) {
                throw new UsernameNotFoundException("Unable to get username from session for Authentication Process");
            }

            LOG.info("postValidateUser() : Request received to validateUser : {} ", userName);

            final String clientId = (String) httpSession.getAttribute(EnterpriseInfo.CLIENT_ID);

            if (clientId == null || clientId.equals("")) {
                throw new InvalidClientException("Given client ID does not match authenticated client");
            }

            final Map<String, Object> inputParameters = new HashMap<>();
            inputParameters.put(Constants.REQ_PARAM_USERNAME, userName);

            final boolean isRememberMe = InputValidationUtils
                    .validateRememberMeParam(request.getParameter(Constants.REQ_PARAM_REMEMBER_ME), false);

            if (isRememberMe) {
                EventLogger.log(EventId.RelidAuthServer.USER_REMEMBER_ME_BROWSER, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request), "User has remembered the browser");
            }

            inputParameters.put(Constants.REQ_PARAM_REMEMBER_ME, isRememberMe);

            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);

            inputParameters.put(WebDevMaster.USER_LOCATION_STR, webDeviceLocation);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, webDeviceParams);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR, browserFingerprint);
            inputParameters.put(EnterpriseInfo.SCOPE, httpSession.getAttribute(EnterpriseInfo.SCOPE));

            /*
             * Sending Second Level Auth Generators only after validating first
             * level of Authentication.
             */
            final Set<String> validatedAuthTypes = (Set<String>) request.getSession()
                    .getAttribute(SessionConstants.VALIDATED_AUTH_TYPES);
            if (!CollectionUtils.isEmpty(validatedAuthTypes) && validatedAuthTypes.size() == 1) {
                /*
                 * As per the service implementation this response will always
                 * be true, in failure case service will throw exceptions. We
                 * will generate the Notification or SMS OTP based on passed
                 * authType.
                 */
                if (StringUtils.equals(AuthType.RELID_VERIFY.getName(),
                        request.getParameter(Constants.REQ_PARAM_AUTH_TYPE))) {
                    generateRVNMessageServiceImpl.processGenerateRVNRequest(request, response, inputParameters);
                    LOG.info("postValidateUser() : Notification published for user : {} ", userName);
                } else if (StringUtils.equals(AuthType.SMSOTP.getName(),
                        request.getParameter(Constants.REQ_PARAM_AUTH_TYPE))) {
                    smsotpServiceImpl.generateOTP(request, response, inputParameters);
                    LOG.info("postValidateUser() : SMS OTP published for user : {} ", userName);
                } else if (StringUtils.equals(AuthType.EMAILOTP.getName(),
                        request.getParameter(Constants.REQ_PARAM_AUTH_TYPE))) {
                    emailotpServiceImpl.generateOTP(request, response, inputParameters);
                    LOG.info("postValidateUser() : Email OTP published for user : {} ", userName);
                }
                final Map<String, Integer> authGenerationAttemptsCounter = (HashMap<String, Integer>) httpSession
                        .getAttribute(SessionConstants.AUTH_GENERATION_ATTEMPT_COUNTER);
                return new ResponseEntity<>(authGenerationAttemptsCounter, getFixedHeaders(), HttpStatus.OK);
            } else {
                LOG.error("attemptAuthentication() : User is not authenticated for First Level.");
                return new ResponseEntity<>("Unauthorized Access", getFixedHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (final AuthGenerationAttemptCounterExceededException e) {
            return new ResponseEntity<>("Unauthorized access", getFixedHeaders(), HttpStatus.UNAUTHORIZED);
        }
    }

    @GetMapping(value = "/isUserAuthenticated")
    public ResponseEntity<Object> isUserAuthenticated(final HttpServletRequest request,
            final HttpServletResponse response) {

        final HttpSession session = request.getSession();
        final String username = (String) session.getAttribute(SessionConstants.CURRENT_USERNAME);

        LOG.info("isUserAuthenticated() : Request received to check if user is authenticated. User: {}", username);

        if (!Utils.isNullOrEmpty(username)) {
            // Validating Client Id in Request
            AuthenticationUtils.validateClientId(request);

            final String correlationID = (String) session.getAttribute(Constants.CORRELATION_ID);
            return getResponse(authenticationService.checkIfNotificationIsActed(correlationID));
        }

        // Request received after authentication is complete, username will be
        // null, send 204 in such cases.
        LOG.info("isUserAuthenticated() : Ignoring this request as user is already authenticated.");
        return new ResponseEntity<>(getFixedHeaders(), HttpStatus.NO_CONTENT);
    }

    private ResponseEntity<Object> getResponse(final HttpStatus status) {
        return new ResponseEntity<>(getFixedHeaders(), status);
    }

    /**
     * This controller validates the user & then returns the allowed
     * authentication types.
     * 
     * @param request
     * @param response
     * @param validateUserRequest
     * @return
     */
    @SuppressWarnings("unchecked")
    @PostMapping(value = "/validate-user")
    public ResponseEntity<ValidateUserResponse> validateUserBasedOnAuthType(final HttpServletRequest request,
            final HttpServletResponse response, @Valid @RequestBody final ValidateUserRequest validateUserRequest) {

        Set<String> authTypes = new HashSet<>();
        final HttpSession session = request.getSession();

        // Validating Client Id in Request
        AuthenticationUtils.validateClientId(request);

        try {

            authTypes = userServiceImpl.getUserAuthFactorsBasedOnUserValidity(request, response, validateUserRequest);

            session.setAttribute(SessionConstants.PENDING_AUTH_TYPES, authTypes);

            final Set<String> validatedAuthTypes = (Set<String>) session
                    .getAttribute(SessionConstants.VALIDATED_AUTH_TYPES);

            if (CollectionUtils.isEmpty(authTypes)
                    && !(validatedAuthTypes.size() == 1 && validatedAuthTypes.contains(AuthType.FIDO.getName()))) {
                LOG.error("validateUserBasedOnAuthType() : AuthType: {}, Getting Invalid Pending Auth Type Set",
                        validateUserRequest.getAuthType());

                request.getSession().setAttribute(SessionConstants.IS_REDIRECT_TO_ERROR_PAGE, true);
                throw new InvalidPendingAuthTypesException(String.format("Invalid Pending Auth Types For Level %s Auth",
                        validatedAuthTypes.size() > 1 ? 2 : 1));
            }

            if (!CollectionUtils.isEmpty(validatedAuthTypes) && (validatedAuthTypes.size() >= 2
                    || (validatedAuthTypes.size() == 1 && validatedAuthTypes.contains(AuthType.FIDO.getName())))) {
                if (null == session.getAttribute(SessionConstants.VALIDATED_USERNAME)) {
                    session.setAttribute(SessionConstants.VALIDATED_USERNAME, validateUserRequest.getUserName());
                }
                return new ResponseEntity<>(new ValidateUserResponse(Collections.emptySet(),
                        getNumberOfAttempts(request), getGenerationAttemptCounter(request)), getFixedHeaders(),
                        HttpStatus.OK);
            }

            final boolean isAllLevel1AuthTypesOffered = request.getSession()
                    .getAttribute(SessionConstants.IS_ALL_LEVEL1_AUTH_TYPES_OFFERED) != null
                            ? (boolean) request.getSession()
                                    .getAttribute(SessionConstants.IS_ALL_LEVEL1_AUTH_TYPES_OFFERED)
                            : false;

            final ValidateUserResponse validateUserResponse = new ValidateUserResponse(authTypes,
                    getNumberOfAttempts(request), getGenerationAttemptCounter(request));

            validateUserResponse.setAllLevel1AuthTypesOffered(isAllLevel1AuthTypesOffered);

            return new ResponseEntity<>(validateUserResponse, getFixedHeaders(), HttpStatus.ACCEPTED);

        } catch (final ValidateUserException e) {
            LOG.error("validateUserBasedOnAuthType() : AuthType: {}", validateUserRequest.getAuthType(), e);

            EventLogger.log(EventId.RelidAuthServer.VALIDATE_USER_REQ_FAILURE, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), validateUserRequest.getUserName(),
                    AuthenticationUtils.getUserAgent(request), "Request validation failed"); // FIXME
                                                                                             // Add
                                                                                             // Proper
                                                                                             // event
                                                                                             // and
                                                                                             // message

            return new ResponseEntity<>(new ValidateUserResponse(e.getMessage(), getNumberOfAttempts(request),
                    getGenerationAttemptCounter(request)), getFixedHeaders(), HttpStatus.UNPROCESSABLE_ENTITY);
        } catch (final AttemptCounterExceededException | RelIDNotificationRejectedException | SessionConflictedException
                | InvalidPendingAuthTypesException e) {
            final int attemptCounter = getNumberOfAttempts(request);
            LOG.error("validateUserBasedOnAuthType() : AuthType: {}, AttemptCounter: {}",
                    validateUserRequest.getAuthType(), attemptCounter, e);

            EventLogger.log(EventId.RelidAuthServer.VALIDATE_USER_REQ_FAILURE, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), validateUserRequest.getUserName(),
                    AuthenticationUtils.getUserAgent(request), "Request validation failed"); // FIXME
                                                                                             // Add
                                                                                             // Proper
                                                                                             // event
                                                                                             // and
                                                                                             // message

            return new ResponseEntity<>(new ValidateUserResponse(Collections.emptySet(), attemptCounter,
                    getGenerationAttemptCounter(request)), getFixedHeaders(), HttpStatus.OK);
        } catch (final Exception e) {
            LOG.error("validateUserBasedOnAuthType() : AuthType: {}", validateUserRequest.getAuthType(), e);

            if (e instanceof InvalidUserException) {
                EventLogger.log(EventId.RelidAuthServer.USER_NOT_FOUND, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), validateUserRequest.getUserName(),
                        AuthenticationUtils.getUserAgent(request), "Invalid User - User Not Found In DB");
            }

            request.getSession().setAttribute(SessionConstants.ERROR_DISPLAY_MSG,
                    PropertyConstants.DEFAULT_GLOBAL_ERROR_PAGE_MSG);

            return new ResponseEntity<>(new ValidateUserResponse("Unknown error", getNumberOfAttempts(request),
                    getGenerationAttemptCounter(request)), getFixedHeaders(), HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PostMapping(value = "/delete-account")
    public ResponseEntity<GenericResponse> deleteAccountFromChooser(final HttpServletRequest request,
            final HttpServletResponse response, @Valid @RequestBody final ValidateUserRequest validateUserRequest) {

        // Validating Client Id in Request
        AuthenticationUtils.validateClientId(request);

        final boolean isDeleted = userServiceImpl.deleteBrowserMappingForUser(request, validateUserRequest);
        if (isDeleted) {
            LOG.info("deleteAccountFromChooser() : User={}, Operation={}", validateUserRequest.getUserName(),
                    PropertyConstants.MFA_USER_DISPLAY_MESSAGES.get(MessageConstants.KEY_MSG_SUCCESS_ACCOUNT_DELETION));

            EventLogger.log(EventId.RelidAuthServer.USER_ACC_DELETION_FROM_ACC_CHOOSER,
                    Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                    AuthenticationUtils.getUsername(request), AuthenticationUtils.getUserAgent(request),
                    "User Account Deleted Successfully from Account Chooser");

            return new ResponseEntity<>(
                    new GenericResponse(PropertyConstants.MFA_USER_DISPLAY_MESSAGES
                            .get(MessageConstants.KEY_MSG_SUCCESS_ACCOUNT_DELETION), null),
                    getFixedHeaders(), HttpStatus.OK);
        }
        LOG.info("deleteAccountFromChooser() : User={}, Operation={}", validateUserRequest.getUserName(),
                PropertyConstants.MFA_USER_DISPLAY_MESSAGES.get(MessageConstants.KEY_MSG_ERROR_ACCOUNT_DELETION));

        EventLogger.log(EventId.RelidAuthServer.USER_ACC_DELETION_FROM_ACC_CHOOSER, Utils.getClientIpAddress(request),
                AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                AuthenticationUtils.getUserAgent(request), "Failed TO Delete User Account from Account Chooser");
        return new ResponseEntity<>(
                new GenericResponse(null,
                        PropertyConstants.MFA_USER_DISPLAY_MESSAGES
                                .get(MessageConstants.KEY_MSG_ERROR_ACCOUNT_DELETION)),
                getFixedHeaders(), HttpStatus.PRECONDITION_FAILED);
    }

    private HttpHeaders getFixedHeaders() {
        final HttpHeaders headers = new HttpHeaders();
        headers.set("Cache-Control", "no-store");
        headers.set("Pragma", "no-cache");
        headers.set("Content-Type", "application/json;charset=UTF-8");
        headers.set("X-FRAME-OPTIONS", "DENY");
        return headers;
    }

    @SuppressWarnings("unchecked")
    private int getNumberOfAttempts(final HttpServletRequest request) {
        final HttpSession session = request.getSession();
        final Set<String> validatedAuthTypes = (Set<String>) session
                .getAttribute(SessionConstants.VALIDATED_AUTH_TYPES);

        final List<Integer> attemptsList = (List<Integer>) session.getAttribute(SessionConstants.ATTEMPTS_COUNTER);

        // FIXME: invalid user name causes attemptsList null
        if (CollectionUtils.isEmpty(attemptsList)) {
            return 0;
        }

        return CollectionUtils.isEmpty(validatedAuthTypes)
                ? attemptsList.get(Constants.LEVEL_1_AUTH_ATTEMPT_COUNTER_INDEX)
                : attemptsList.get(Constants.LEVEL_2_AUTH_ATTEMPT_COUNTER_INDEX);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Integer> getGenerationAttemptCounter(final HttpServletRequest request) {
        return (HashMap<String, Integer>) request.getSession()
                .getAttribute(SessionConstants.AUTH_GENERATION_ATTEMPT_COUNTER);
    }

    @SuppressWarnings("unchecked")
    @PostMapping(value = "/validate-fido-cred")
    public ResponseEntity<Boolean> validateFidoCredential(final HttpServletRequest request,
            final HttpServletResponse response, @Valid @RequestBody final ValidateUserRequest validateUserRequest) {

        final boolean isValidated = userServiceImpl.validateFidoCredential(request, response, validateUserRequest);

        return new ResponseEntity<>(isValidated, getFixedHeaders(), HttpStatus.OK);

    }

    @SuppressWarnings("unchecked")
    @PostMapping(value = "/validate-fido-register-same-browser")
    public ResponseEntity<Boolean> validateFidoPlatformRegistration(final HttpServletRequest request,
            final HttpServletResponse response, @Valid @RequestBody final ValidateUserRequest validateUserRequest) {

        final boolean isValidatedFidoPlatform = userServiceImpl.validateFidoPlatformRegistration(request, response,
                validateUserRequest);

        return new ResponseEntity<>(isValidatedFidoPlatform, getFixedHeaders(), HttpStatus.OK);

    }

    // FIXME: Handle globally
    @ExceptionHandler(InvalidTokenException.class)
    public ResponseEntity<OAuth2Exception> handleException(final Exception e) throws Exception {
        LOG.info("Handling error: " + e.getClass().getSimpleName() + ", " + e.getMessage());
        // This isn't an oauth resource, so we don't want to send an
        // unauthorized code here. The client has already authenticated
        // successfully with basic auth and should just
        // get back the invalid token error.
        @SuppressWarnings("serial")
        final InvalidTokenException e400 = new InvalidTokenException(e.getMessage()) {
            @Override
            public int getHttpErrorCode() {
                return 400;
            }
        };
        return exceptionTranslator.translate(e400);
    }

}
