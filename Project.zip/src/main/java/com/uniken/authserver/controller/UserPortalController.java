package com.uniken.authserver.controller;

import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.apache.commons.lang3.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.oauth2.common.util.OAuth2Utils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.fasterxml.jackson.databind.JsonNode;
import com.mastercard.ess.fido2.certification.CertificationKeyStoreUtils;
import com.mongodb.client.result.UpdateResult;
import com.uniken.authserver.domains.RegAuthFactorRequest;
import com.uniken.authserver.domains.RegisteredAuthFactorDetails;
import com.uniken.authserver.domains.ValidatedBrowserRequest;
import com.uniken.authserver.services.api.OAuth2ClientDetailsService;
import com.uniken.authserver.services.api.SecureCookieService;
import com.uniken.authserver.services.api.SessionService;
import com.uniken.authserver.services.api.UserService;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.InputValidationUtils;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.SessionConstants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.auth.fido.FIDO2RegisteredAuthenticationModule;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.WebUserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.enums.auth.AuthTypeStatus;
import com.uniken.domains.relid.user.UserAuthInfo;
import com.uniken.domains.relid.user.UserBrowser;
import com.uniken.domains.user.vos.UserAuthInfoRegAuthModuleVo;

@Controller
public class UserPortalController {
    private static final Logger LOG = LoggerFactory.getLogger(UserPortalController.class);

    @Autowired
    private UserService userService;

    @Autowired
    private OAuth2ClientDetailsService oAuth2ClientDetailsService;

    @Autowired
    private SessionService sessionService;

    @Autowired
    SecureCookieService secureCookieService;

    @Autowired
    CertificationKeyStoreUtils certificationKeyStoreUtils;

    @GetMapping("/portal-login")
    public String getuserPortalHomePage(final Model model, final HttpServletRequest request,
            final HttpServletResponse response, final HttpSession session, final Principal principal) {

        // Here, we are preventing that authenticated user should go
        // to the user-portal page only.
        if (principal != null) {
            return "redirect:user-portal";
        }

        session.setAttribute(Constants.REQ_PARAM_REQUEST_TYPE, "UserPortal");

        if (InputValidationUtils.isRedirectToErrorPage(session)) {
            return "/error";
        }

        final boolean showLoginErrorMsg = StringUtils
                .isNotBlank((String) session.getAttribute(SessionConstants.ERROR_DISPLAY_MSG));

        model.addAttribute("showLoginErrorMsg", showLoginErrorMsg);
        model.addAttribute("login_error_msg", PropertyConstants.DEFAULT_GLOBAL_ERROR_PAGE_MSG);

        model.addAttribute("isUserPortalLogin", "true");
        model.addAttribute("isManageAccountSecurityEnabled", PropertyConstants.MANAGE_SECURITY_PREF_ENABLED);
        model.addAllAttributes(Utils.getPlatformSpecificMessages(request.getHeader(Constants.USER_AGENT_STR),
                new HashMap<>(PropertyConstants.UI_MESSAGES_PAGE_LOGIN)));
        return "login";
    }

    @GetMapping("/user-portal")
    public String getRegisterDevicePage(final Model model, final HttpServletRequest request,
            final HttpServletResponse response, final HttpSession session, final Principal principal) {

        final String username;
        try {
            username = ESAPI.validator().getValidInput("principal_username", principal.getName(), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);

            if (!InputValidationUtils.isValidUserName(username)) {
                LOG.error("validateUserByOTP() -> Invalid Characters in Username : {}", username);
                throw new IllegalArgumentException("Invalid Characters in Username");
            }

            model.addAttribute("username", username);
            model.addAttribute("clientName",
                    (((EnterpriseInfo) oAuth2ClientDetailsService
                            .loadClientByClientId((String) session.getAttribute(OAuth2Utils.CLIENT_ID)))
                                    .getClientName()));
            model.addAttribute("fidoAvailable", userService.hasFidoDeviceRegistered(username));

            /**
             * Invoke SessionService to handle secure cookie related operations
             */
            sessionService.preLogoutSecureCookieHandling(request, response);

        } catch (final Exception e) {
            LOG.error("getRegisterDevicePage() -> Exception occurred", e);
        }

        model.addAllAttributes(Utils.getPlatformSpecificMessages(request.getHeader(Constants.USER_AGENT_STR),
                new HashMap<>(PropertyConstants.UI_MESSAGES_PAGE_REGISTER)));

        /*
         * Redirecting to Auth Factor Management Page (Sign In Options) instead
         * of Register page
         */
        // return "register";
        return "redirect:user-portal/auth-factor-management";
    }

    @GetMapping("/user-portal/browser-management")
    public String getBrowserManagmentPage(final Model model, final HttpServletRequest request,
            final HttpSession session, final Principal principal) {

        final String username;
        try {
            username = ESAPI.validator().getValidInput("principal_username", principal.getName(), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);

            if (!InputValidationUtils.isValidUserName(username)) {
                LOG.error("validateUserByOTP() -> Invalid Characters in Username : {}", username);
                throw new IllegalArgumentException("Invalid Characters in Username");
            }

            model.addAttribute("browsers", userService.getBrowsers(username));
            model.addAttribute("username", username);
            model.addAttribute("clientName",
                    (((EnterpriseInfo) oAuth2ClientDetailsService
                            .loadClientByClientId((String) session.getAttribute(OAuth2Utils.CLIENT_ID)))
                                    .getClientName()));
            model.addAttribute("fidoAvailable", userService.hasFidoDeviceRegistered(username));
        } catch (final Exception e) {
            LOG.error("getRegisterDevicePage() -> Exception occurred", e);
        }
        return "browser_management";
    }

    @GetMapping("/user-portal/browser-management/list")
    public String getBrowserManagmentListFragment(final Model model, final HttpServletRequest request,
            final HttpSession session, final Principal principal) {

        final String username;

        try {
            username = ESAPI.validator().getValidInput("principal_username", principal.getName(), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);

            if (!InputValidationUtils.isValidUserName(username)) {
                LOG.error("validateUserByOTP() -> Invalid Characters in Username : {}", username);
                throw new IllegalArgumentException("Invalid Characters in Username");
            }

            model.addAttribute("browsers", userService.getBrowsers(username));
            model.addAttribute("username", username);

        } catch (final Exception e) {
            LOG.error("getRegisterDevicePage() -> Exception occurred", e);
        }
        return "fragments/browser_list_fragment :: browser_list_fragment";
    }

    @PostMapping({ "/user-portal/get-token", "/get-token" })
    public String getToken(final HttpSession session, @RequestBody final MultiValueMap<String, String> formData,
            final Principal principal, final HttpServletRequest request) {
        final StringBuilder url = new StringBuilder("redirect:/oauth/authorize?");

        try {

            if (formData.containsKey("userOptedOutForFidoReg") && formData.getFirst("userOptedOutForFidoReg") != null) {
                final String username = ESAPI.validator().getValidInput("principal_username", principal.getName(),
                        "HTTPHeaderValue", Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);

                if (!InputValidationUtils.isValidUserName(username)) {
                    LOG.error("getToken() -> Invalid Characters in Username : {}", username);
                    throw new IllegalArgumentException("Invalid Characters in Username");
                }

                secureCookieService.updateUserOptedOutForFidoRegistrationForBrowser(request, username,
                        Boolean.parseBoolean(formData.getFirst("userOptedOutForFidoReg")));
            }

            String responseType = null;
            if (session.getAttribute(OAuth2Utils.RESPONSE_TYPE) != null) {
                responseType = (String) session.getAttribute(OAuth2Utils.RESPONSE_TYPE);
                url.append("response_type=").append(responseType);
            }

            String state = null;
            if (session.getAttribute(OAuth2Utils.STATE) != null) {
                state = (String) session.getAttribute(OAuth2Utils.STATE);
                url.append("&state=").append(state);
            }

            String clientId = null;
            if (session.getAttribute(OAuth2Utils.CLIENT_ID) != null) {
                clientId = (String) session.getAttribute(OAuth2Utils.CLIENT_ID);
                url.append("&client_id=").append(clientId);
            }

            String scope = null;
            if (session.getAttribute(OAuth2Utils.SCOPE) != null) {
                scope = (String) session.getAttribute(OAuth2Utils.SCOPE);
                url.append("&scope=").append(scope);
            }

            String redirectUri = null;
            if (session.getAttribute(OAuth2Utils.REDIRECT_URI) != null) {
                redirectUri = (String) session.getAttribute(OAuth2Utils.REDIRECT_URI);
                url.append("&redirect_uri=").append(redirectUri);
            }
        } catch (final Exception e) {
            LOG.error("getToken() -> Exception occurred", e);
        }
        return url.toString();
    }

    @GetMapping(value = "/webUserBrowsers")
    public ResponseEntity<UserBrowser> getWebUserBrowers(final HttpServletRequest request,
            final HttpServletResponse response,
            @RequestParam(value = UserAuthInfo.LOGIN_ID_STR, required = true) final String loginId,
            final Pageable pageable) {

        LOG.info("getWebUserBrowsers() : Request received to get web user browsers");

        final UserBrowser browsers = (UserBrowser) userService.getListOfUserBrowsers(loginId);

        return new ResponseEntity<UserBrowser>(browsers, getFixedHeaders(), HttpStatus.OK);
    }

    @PostMapping(value = "/webUserBrowsers/{webDeviceUuid}")
    public ResponseEntity<UpdateResult> updateWebUserBrowerStatus(final HttpServletRequest request,
            final HttpServletResponse response,
            @RequestParam(value = UserAuthInfo.LOGIN_ID_STR, required = true) final String loginId,
            @RequestParam(value = UserBrowser.WEB_DEVICE_UUID_STR, required = true) final String webDeviceUuid,
            @RequestParam(value = UserBrowser.STATUS, required = true) final String status) {

        LOG.info("updateWebUserBrowser() : Request received to update web user browser");

        final WebUserStatus statusEnum = WebUserStatus.getStatus(status);

        final UpdateResult updated = userService.updateWebUserBrowserStatus(loginId, webDeviceUuid, statusEnum);

        return new ResponseEntity<UpdateResult>(updated, getFixedHeaders(), HttpStatus.OK);
    }

    @PostMapping(value = "/webUserBrowsers/unRemember")
    public ResponseEntity<UpdateResult> unRememberUserBrowser(final HttpServletRequest request,
            final HttpServletResponse response,
            @RequestParam(value = UserAuthInfo.LOGIN_ID_STR, required = true) final String loginId,
            @RequestParam(value = UserBrowser.WEB_DEVICE_UUID_STR, required = true) final String webDeviceUuid) {

        LOG.info("updateWebUserBrowser() : Request received to update web user browser");

        final UpdateResult updated = userService.unRememberWebUserBrowser(loginId, webDeviceUuid);

        return new ResponseEntity<UpdateResult>(updated, getFixedHeaders(), HttpStatus.OK);
    }

    @PostMapping(value = "/user-portal/webUserBrowsers/delete")
    public ResponseEntity<UpdateResult> deleteUserBrowser(final HttpServletRequest request,
            final HttpServletResponse response,
            @Valid @RequestBody final ValidatedBrowserRequest validatedBrowserRequest) {

        UpdateResult updated = null;

        try {
            final String loginId = validatedBrowserRequest.getLoginId();
            final String webDeviceUuid = validatedBrowserRequest.getWebDeviceUuid();

            LOG.info("deleteUserBrowser() : Request received to delete web user browser : user={} : webId={}", loginId,
                    webDeviceUuid);

            updated = userService.deleteWebUserBrowser(loginId, webDeviceUuid);

            if (updated != null && updated.getModifiedCount() > 0) {
                return new ResponseEntity<>(updated, getFixedHeaders(), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(updated, getFixedHeaders(), HttpStatus.PRECONDITION_FAILED);
            }
        } catch (final Exception e) {
            LOG.error("deleteUserBrowser() -> Exception occurred : Failed to delete browser", e);
            return new ResponseEntity<>(updated, getFixedHeaders(), HttpStatus.PRECONDITION_FAILED);
        }
    }

    @GetMapping("/user-portal/auth-factor-management")
    public String getAuthFactorManagmentPage(final Model model, final HttpServletRequest request,
            final HttpSession session, final Principal principal) {

        final String username;
        try {
            username = ESAPI.validator().getValidInput("principal_username", principal.getName(), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);

            if (!InputValidationUtils.isValidUserName(username)) {
                LOG.error("validateUserByOTP() -> Invalid Characters in Username : {}", username);
                throw new IllegalArgumentException("Invalid Characters in Username");
            }

            model.addAttribute("username", username);
            model.addAttribute("clientName",
                    (((EnterpriseInfo) oAuth2ClientDetailsService
                            .loadClientByClientId((String) session.getAttribute(OAuth2Utils.CLIENT_ID)))
                                    .getClientName()));
            model.addAttribute("fidoAvailable", userService.hasFidoDeviceRegistered(username));
            model.addAllAttributes(Utils.getPlatformSpecificMessages(request.getHeader(Constants.USER_AGENT_STR),
                    new HashMap<>(PropertyConstants.UI_MESSAGES_PAGE_REGISTER)));

        } catch (final Exception e) {
            LOG.error("getAuthFactorManagmentPage() -> Exception occurred", e);
        }
        return "authFactorManagement";
    }

    @GetMapping(value = "/user-portal/auth-factor-management/list")
    public ResponseEntity<List<RegisteredAuthFactorDetails>> getRegAuthFactorForUser(final HttpServletRequest request,
            final HttpServletResponse response, final Principal principal) {

        final String username;
        final List<RegisteredAuthFactorDetails> registeredAuthFactorDetails = new ArrayList<>();
        try {
            username = ESAPI.validator().getValidInput("principal_username", principal.getName(), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);

            if (!InputValidationUtils.isValidUserName(username)) {
                LOG.error("validateUserByOTP() -> Invalid Characters in Username : {}", username);
                throw new IllegalArgumentException("Invalid Characters in Username");
            }

            final List<FIDO2RegisteredAuthenticationModule> regModuleList = userService
                    .fetchRegisteredAuthenticationModuleFromLoginId(username);

            if (!CollectionUtils.isEmpty(regModuleList)) {
                regModuleList.stream()
                        .forEach(regModule -> registeredAuthFactorDetails.add(new RegisteredAuthFactorDetails(
                                regModule.getAuthenticatorUuid(), regModule.getCreatedTS(), regModule.getUpdatedTS(),
                                regModule.getAuthType(), regModule.getAuthTypeStatus(),
                                regModule.getAuthenticatorDescription(), regModule.getAuthenticatorName(),
                                getBase64EncodedImageByAaguid(regModule.getAuthenticatorAaguid()),
                                userService.allowedToDeleteOrDisableAuthFactor(username,
                                        regModule.getAuthenticatorUuid(), regModuleList),
                                PropertyConstants.DEFAULT_USER_RECOGNIZED_AUTHTYPE_NAME
                                        .get(regModule.getAuthType().name()))));
            }

            final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = userService
                    .fetchUserAuthInfoRegAuthModuleFromLoginId(username);
            if (userAuthInfoRegAuthModuleVo != null) {
                userAuthInfoRegAuthModuleVo.getRegAuthTypes().stream().forEach(regModule -> {
                    if (!regModule.equals(AuthType.FIDO)) {
                        registeredAuthFactorDetails.add(new RegisteredAuthFactorDetails(UUID.randomUUID().toString(),
                                null, null, regModule, AuthTypeStatus.REGISTERED, null, null, null, false,
                                PropertyConstants.DEFAULT_USER_RECOGNIZED_AUTHTYPE_NAME.get(regModule.name())));
                    }
                });

                if (!Boolean.TRUE.equals(userAuthInfoRegAuthModuleVo.isWebOnly()) && !userAuthInfoRegAuthModuleVo
                        .getRelIds().stream().filter(relid -> relid.getRelIdStatus().equals(RelIdUserStatus.ACTIVE))
                        .collect(Collectors.toList()).isEmpty()) {

                    // Adding RELID Verify Auth Factor
                    registeredAuthFactorDetails.add(new RegisteredAuthFactorDetails(UUID.randomUUID().toString(), null,
                            null, AuthType.RELID_VERIFY, AuthTypeStatus.REGISTERED, null, null, null, false,
                            PropertyConstants.DEFAULT_USER_RECOGNIZED_AUTHTYPE_NAME.get(AuthType.RELID_VERIFY.name())));

                    // Adding TOTP Verify Auth Factor
                    registeredAuthFactorDetails.add(new RegisteredAuthFactorDetails(UUID.randomUUID().toString(), null,
                            null, AuthType.TOTP, AuthTypeStatus.REGISTERED, null, null, null, false,
                            PropertyConstants.DEFAULT_USER_RECOGNIZED_AUTHTYPE_NAME.get(AuthType.TOTP.name())));
                }
            }

        } catch (final Exception e) {
            LOG.error("getRegisterDevicePage() -> Exception occurred", e);
        }
        return new ResponseEntity<>(registeredAuthFactorDetails, getFixedHeaders(), HttpStatus.OK);
    }

    private String getBase64EncodedImageByAaguid(final String aaguid) {
        String base64EncodedImage = "";

        if (StringUtils.isEmpty(aaguid)) {
            return base64EncodedImage;
        }

        try {
            final JsonNode metataDataNode = certificationKeyStoreUtils.getAuthenticatorsIconData(aaguid);
            base64EncodedImage = metataDataNode.get("icon").asText();
        } catch (final Exception e) {
            LOG.error("Error while getting base64EncodedImage for aaguid  : {}", aaguid);
        }

        return base64EncodedImage;
    }

    @PostMapping(value = "/user-portal/auth-factor-management/delete")
    public ResponseEntity<Object> deleteRegAuthFactorForUser(final HttpServletRequest request,
            final HttpServletResponse response, final Principal principal,
            @Valid @RequestBody final RegAuthFactorRequest regAuthFactorRequest) {

        final String username;
        try {
            username = ESAPI.validator().getValidInput("principal_username", principal.getName(), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);

            if (!InputValidationUtils.isValidUserName(username)) {
                LOG.error("deleteRegAuthFactorForUser() -> Invalid Characters in Username : {}", username);
                throw new IllegalArgumentException("Invalid Characters in Username");
            }

            if (StringUtils.isBlank(regAuthFactorRequest.getRegAuthTypeId())) {
                LOG.error("deleteRegAuthFactorForUser() -> Invalid Authenticator Uuid Passed : {}", username);
                throw new IllegalArgumentException("Invalid Auth Type Id Passed");
            }

            LOG.info("deleteRegAuthFactorForUser() : Request received to delete registered auth factor");

            final boolean isSuccess = userService.deleteRegisteredAuthModule(username,
                    regAuthFactorRequest.getRegAuthTypeId());

            if (isSuccess) {
                return new ResponseEntity<>("Auth Factor Deleted Successfully", getFixedHeaders(), HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Unable To Delete The Only Available Auth Factor.", getFixedHeaders(),
                        HttpStatus.PRECONDITION_FAILED);
            }

        } catch (final Exception e) {
            LOG.error("deleteRegAuthFactorForUser() -> Exception occurred", e);

            return new ResponseEntity<>("Failed to Delete Auth Factor", getFixedHeaders(),
                    HttpStatus.PRECONDITION_FAILED);

        }
    }

    @PostMapping(value = "/user-portal/auth-factor-management/update-status")
    public ResponseEntity<Object> updateRegAuthFactorStatus(final HttpServletRequest request,
            final HttpServletResponse response, final Principal principal,
            @Valid @RequestBody final RegAuthFactorRequest regAuthFactorRequest) {

        final String username;
        try {
            username = ESAPI.validator().getValidInput("principal_username", principal.getName(), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);

            if (!InputValidationUtils.isValidUserName(username)) {
                LOG.error("updateRegAuthFactorStatus() -> Invalid Characters in Username : {}", username);
                throw new IllegalArgumentException("Invalid Characters in Username");
            }

            if (StringUtils.isBlank(regAuthFactorRequest.getRegAuthTypeId())) {
                LOG.error("updateRegAuthFactorStatus() -> Invalid Auth Type Id Passed : {}", username);
                throw new IllegalArgumentException("Invalid Auth Type Status Passed");
            }

            LOG.info("updateRegAuthFactorStatus() : Request received to delete registered auth factor");

            final boolean isSuccess = userService.updateRegAuthFactorStatus(username,
                    regAuthFactorRequest.getRegAuthTypeId(), regAuthFactorRequest.isEnabledState());

            if (isSuccess) {
                return new ResponseEntity<>("Auth Factor State Changed Successfully", getFixedHeaders(), HttpStatus.OK);
            } else {
                return new ResponseEntity<>("Unable To Disable The Only Available Auth Factor.", getFixedHeaders(),
                        HttpStatus.PRECONDITION_FAILED);
            }
        } catch (final Exception e) {
            LOG.error("updateRegAuthFactorStatus() -> Exception occurred", e);

            return new ResponseEntity<>("Failed to Change Auth Factor State", getFixedHeaders(),
                    HttpStatus.PRECONDITION_FAILED);
        }
    }

    private HttpHeaders getFixedHeaders() {
        final HttpHeaders headers = new HttpHeaders();
        headers.set("Cache-Control", "no-store");
        headers.set("Pragma", "no-cache");
        headers.set("Content-Type", "application/json;charset=UTF-8");
        headers.set("X-FRAME-OPTIONS", "DENY");
        return headers;
    }

    @GetMapping("/user-portal/fido-register")
    public String getFidoRegisterPage(final Model model, final HttpServletRequest request, final HttpSession session,
            final Principal principal) {

        final String username;
        try {
            username = ESAPI.validator().getValidInput("principal_username", principal.getName(), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);

            if (!InputValidationUtils.isValidUserName(username)) {
                LOG.error("getFidoRegisterPage() -> Invalid Characters in Username : {}", username);
                throw new IllegalArgumentException("Invalid Characters in Username");
            }

            model.addAttribute("username", username);
            model.addAttribute("clientName",
                    (((EnterpriseInfo) oAuth2ClientDetailsService
                            .loadClientByClientId((String) session.getAttribute(OAuth2Utils.CLIENT_ID)))
                                    .getClientName()));
            model.addAttribute("fidoAvailable", userService.hasFidoDeviceRegistered(username));

            model.addAllAttributes(Utils.getPlatformSpecificMessages(request.getHeader(Constants.USER_AGENT_STR),
                    new HashMap<>(PropertyConstants.UI_MESSAGES_PAGE_REGISTER_FIDO_CONSENT)));

        } catch (final Exception e) {
            LOG.error("getFidoRegisterPage() -> Exception occurred", e);
        }
        return "fidoRegister";
    }

}
