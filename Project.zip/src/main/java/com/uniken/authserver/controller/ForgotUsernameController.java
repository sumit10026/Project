package com.uniken.authserver.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.uniken.authserver.domains.ForgotUsernameRequest;
import com.uniken.authserver.domains.GenericResponse;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;

@Controller
@RequestMapping("/forgot")
public class ForgotUsernameController {

    private static final Logger LOG = LoggerFactory.getLogger(ForgotUsernameController.class);

    @Autowired
    UserAuthInfoRepo authInfoRepo;

    @SuppressWarnings("unchecked")
    @PostMapping(value = "/forgot-username")
    public ResponseEntity<GenericResponse> forgotUsername(final HttpServletRequest request,
            final HttpServletResponse response, @Valid @RequestBody final ForgotUsernameRequest forgotUsernameRequest) {

        try {
            UserAuthInfoVO authInfoVO = null;
            if (forgotUsernameRequest.getOption().equals("Mobile Number")) {
                authInfoVO = authInfoRepo.fetchUserDetailsFromMobileNumber(forgotUsernameRequest.getOptionInput());
            } else if (forgotUsernameRequest.getOption().equals("Email Address")) {
                authInfoVO = authInfoRepo.fetchUserDetailsFromEmailId(forgotUsernameRequest.getOptionInput());
            }
            if (authInfoVO == null) {
                return new ResponseEntity<>(new GenericResponse("No user Found", ""), HttpStatus.OK);
            } else if (authInfoVO != null) {
                final String userId = authInfoVO.getUserId();
                // TODO: Send userId to user
                return new ResponseEntity<>(new GenericResponse("Username Sent", ""), HttpStatus.OK);
            } else {
                return new ResponseEntity<>(new GenericResponse("", "Something went wrong"),
                        HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } catch (final Exception e) {

            return new ResponseEntity<>(new GenericResponse("", "Something went wrong"),
                    HttpStatus.INTERNAL_SERVER_ERROR);
        }

    }

}
