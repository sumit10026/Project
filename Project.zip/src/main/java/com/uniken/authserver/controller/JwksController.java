package com.uniken.authserver.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uniken.authserver.services.api.JwksService;

@RestController
public class JwksController {

    @Autowired
    private JwksService jwksService;

    /**
     * Gets the JSON Web Key Set.
     *
     * @param response
     *            the response
     * @return the jwks
     */
    @GetMapping(value = "/.well-known/jwks.json", produces = MediaType.APPLICATION_JSON_VALUE)
    public String getJwks() {

        return jwksService.getJwks().toJson();
    }

}
