package com.uniken.authserver.controller;

import java.security.Principal;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.util.OAuth2Utils;
import org.springframework.security.web.savedrequest.DefaultSavedRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.uniken.authserver.exception.ValidateUserException;
import com.uniken.authserver.services.api.SessionService;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.InputValidationUtils;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.SessionConstants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.EnterpriseInfo;

@Controller
public class LoginController {

    private static final Logger LOG = LoggerFactory.getLogger(LoginController.class);

    @Autowired
    SessionService sessionService;

    @GetMapping("/login")
    public String getLoginPage(final HttpServletRequest request, final HttpSession session, final Principal principal,
            final Model model) {
        try {

            // Here, we are preventing that authenticated user should go
            // to the user-portal page only.
            if (principal != null) {
                return "redirect:user-portal";
            }

            session.setAttribute(Constants.REQ_PARAM_REQUEST_TYPE, "OIDCLogin");
            if (session.getAttribute("SPRING_SECURITY_SAVED_REQUEST") != null) {
                if (((DefaultSavedRequest) session.getAttribute("SPRING_SECURITY_SAVED_REQUEST")).getServletPath()
                        .equals("/user-portal")) {
                    session.setAttribute(Constants.REQ_PARAM_REQUEST_TYPE, "userPortal");
                    return "redirect:portal-login";
                } else if (session.getAttribute("SPRING_SECURITY_SAVED_REQUEST") != null
                        && ((DefaultSavedRequest) session.getAttribute("SPRING_SECURITY_SAVED_REQUEST"))
                                .getServletPath().equals("/oauth/authorize")) {
                    final DefaultSavedRequest defaultSavedRequest = (DefaultSavedRequest) session
                            .getAttribute("SPRING_SECURITY_SAVED_REQUEST");

                    if (defaultSavedRequest.getParameterMap().get(OAuth2Utils.RESPONSE_TYPE) != null) {
                        final String responseType;
                        responseType = ESAPI.validator().getValidInput("defaultSavedRequest_parameterMap_response_type",
                                defaultSavedRequest.getParameterMap().get(OAuth2Utils.RESPONSE_TYPE)[0],
                                "HTTPHeaderValue", Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
                        if (!InputValidationUtils.isValidResponseType(responseType)) {
                            throw new ValidateUserException("Response Type is Invalid");
                        }
                        session.setAttribute(OAuth2Utils.RESPONSE_TYPE, responseType);
                    }
                    if (defaultSavedRequest.getParameterMap().get(OAuth2Utils.STATE) != null) {
                        final String state;
                        state = ESAPI.validator().getValidInput("defaultSavedRequest_parameterMap_state",
                                defaultSavedRequest.getParameterMap().get(OAuth2Utils.STATE)[0], "HTTPHeaderValue",
                                Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
                        if (!InputValidationUtils.isValidState(state)) {
                            throw new ValidateUserException("State is Invalid");
                        }
                        session.setAttribute(OAuth2Utils.STATE, state);
                    }
                    if (defaultSavedRequest.getParameterMap().get(OAuth2Utils.REDIRECT_URI) != null) {
                        final String redirecturi;
                        redirecturi = ESAPI.validator().getValidInput("defaultSavedRequest_parameterMap_redirect_uri",
                                defaultSavedRequest.getParameterMap().get(OAuth2Utils.REDIRECT_URI)[0], "HTTPURI",
                                Constants.MAX_SIZE_HTTPHEADER_VALUE_REDIRECT_URI_DEFAULT, false);
                        if (!sessionService.isValidRedirectURI(redirecturi,
                                (String) session.getAttribute(EnterpriseInfo.CLIENT_ID))) {
                            throw new ValidateUserException("Redirect URI is Invalid");
                        }
                        session.setAttribute(OAuth2Utils.REDIRECT_URI, redirecturi);
                    }
                }
            }
        } catch (final Exception e) {
            LOG.error("getLoginPage() -> Exception occurred", e);
        }

        if (InputValidationUtils.isRedirectToErrorPage(session)) {
            return "/error";
        }

        final boolean showLoginErrorMsg = StringUtils
                .isNotBlank((String) session.getAttribute(SessionConstants.ERROR_DISPLAY_MSG));

        model.addAttribute("login_error_msg", PropertyConstants.DEFAULT_GLOBAL_ERROR_PAGE_MSG);
        model.addAttribute("showLoginErrorMsg", showLoginErrorMsg);
        model.addAttribute("isManageAccountSecurityEnabled", PropertyConstants.MANAGE_SECURITY_PREF_ENABLED);
        model.addAllAttributes(Utils.getPlatformSpecificMessages(request.getHeader(Constants.USER_AGENT_STR),
                new HashMap<>(PropertyConstants.UI_MESSAGES_PAGE_LOGIN)));

        return "login";
    }

}
