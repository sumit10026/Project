package com.uniken.authserver;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

import com.uniken.authserver.utility.Constants;

@SpringBootApplication
@ComponentScan(basePackages = { "com.uniken", "com.mastercard" })
public class RelIdAuthserverApplication {

    private static final Logger LOG = LoggerFactory.getLogger(RelIdAuthserverApplication.class);

    public static void main(final String[] args) {
        SpringApplication.run(RelIdAuthserverApplication.class, args);

        LOG.info("*******************************************************");
        LOG.info("Started AuthServer - Version Info -> {}", Constants.BUILD_VERSION_NO);
        LOG.info("*******************************************************");
    }

}
