package com.uniken.authserver.utility;

import java.util.Set;

import javax.servlet.http.HttpSession;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.uniken.authserver.domains.AccountRecoveryTokenDetails;

public class AccountRecoverySessionUtils {

    private AccountRecoverySessionUtils() {
    }

    public static HttpSession getSession() {
        return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest().getSession();
    }

    public static void resetAccountRecoverySession() {
        getSession().removeAttribute(AccountRecoveryConstants.ACCOUNT_RECOVERY_TOKEN_DETAILS);
        getSession().removeAttribute(AccountRecoveryConstants.ACCOUNT_RECOVERY_TOKEN);
        getSession().removeAttribute(AccountRecoveryConstants.ACCOUNT_RECOVERY_CREDENTIAL_USERNAME);
        getSession().removeAttribute(AccountRecoveryConstants.PENDING_RESET_CREDENTIAL_FACTOR_SET);
        getSession().removeAttribute(AccountRecoveryConstants.COMPLETED_RESET_CREDENTIAL_FACTOR_SET);
    }

    public static void setARCTokenDetails(final AccountRecoveryTokenDetails accountRecoveryTokenDetails) {
        getSession().setAttribute(AccountRecoveryConstants.ACCOUNT_RECOVERY_TOKEN_DETAILS, accountRecoveryTokenDetails);
    }

    public static AccountRecoveryTokenDetails getARCTokenDetails() {
        return (AccountRecoveryTokenDetails) getSession()
                .getAttribute(AccountRecoveryConstants.ACCOUNT_RECOVERY_TOKEN_DETAILS);
    }

    public static void setARCToken(final String arcToken) {
        getSession().setAttribute(AccountRecoveryConstants.ACCOUNT_RECOVERY_TOKEN, arcToken);
    }

    public static String getARCToken() {
        return (String) getSession().getAttribute(AccountRecoveryConstants.ACCOUNT_RECOVERY_TOKEN);
    }

    public static void setARCUsername(final String arcUsername) {
        getSession().setAttribute(AccountRecoveryConstants.ACCOUNT_RECOVERY_CREDENTIAL_USERNAME, arcUsername);
    }

    public static String getARCUsername() {
        return (String) getSession().getAttribute(AccountRecoveryConstants.ACCOUNT_RECOVERY_CREDENTIAL_USERNAME);
    }

    public static void setPendingResetCredentialFactorSet(final Set<String> pendingResetCredentialFactorSet) {
        getSession().setAttribute(AccountRecoveryConstants.PENDING_RESET_CREDENTIAL_FACTOR_SET,
                pendingResetCredentialFactorSet);
    }

    @SuppressWarnings("unchecked")
    public static Set<String> getPendingResetCredentialFactorSet() {
        return (Set<String>) getSession().getAttribute(AccountRecoveryConstants.PENDING_RESET_CREDENTIAL_FACTOR_SET);
    }

    public static void setCompletedResetCredentialFactorSet(final Set<String> completedResetCredentialFactorSet) {
        getSession().setAttribute(AccountRecoveryConstants.COMPLETED_RESET_CREDENTIAL_FACTOR_SET,
                completedResetCredentialFactorSet);
    }

    @SuppressWarnings("unchecked")
    public static Set<String> getCompletedResetCredentialFactorSet() {
        return (Set<String>) getSession().getAttribute(AccountRecoveryConstants.COMPLETED_RESET_CREDENTIAL_FACTOR_SET);
    }

}
