/**
 * 
 */
package com.uniken.authserver.utility;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.gson.reflect.TypeToken;
import com.uniken.authserver.domains.AllowedAuthenticationFactors;
import com.uniken.authserver.domains.AllowedRegistrationFactors;
import com.uniken.commons.config.AppConfigLoader;
import com.uniken.domains.enums.appconfig.CommonConfigKeys;
import com.uniken.domains.enums.appconfig.ModuleNames;
import com.uniken.domains.enums.appconfig.RelidAuthServer;
import com.uniken.encdecutils.PropertiesEncryptDecrypt;
import com.uniken.fido2.utils.FIDO2Constants;

/**
 * @author Kushal Jaiswal
 */
public class PropertyConstants {

    private static final AppConfigLoader configLoader = new AppConfigLoader(ModuleNames.AUTH_SERVER.getName());
    private static final AppConfigLoader commonConfig = new AppConfigLoader(ModuleNames.CommonConfigs.getName());
    private static final AppConfigLoader gmConfig = new AppConfigLoader(ModuleNames.GM.getName());

    /**
     * Purposely initialize the FidoConstant as it was not called in the
     * application.
     */
    @SuppressWarnings("unused")
    private static final FidoConstants fidoConstants = new PropertyConstants.FidoConstants();

    public static final String DATE_FORMAT = commonConfig.getConfigValue(CommonConfigKeys.DATE_FORMAT.getName());

    public static final String AUTH_SERVER_PORT = configLoader
            .getConfigValue(RelidAuthServer.AUTH_SERVER_PORT.getName());

    public static final String AUTH_SERVER_REQUESTOR_IP = configLoader
            .getConfigValue(RelidAuthServer.AUTH_SERVER_REQUESTOR_IP.getName());

    public static final String AUTH_SERVER_SSL_KEYSTORE_TYPE = configLoader
            .getConfigValue(RelidAuthServer.AUTH_SERVER_SSL_KEYSTORE_TYPE.getName());

    public static final String AUTH_SERVER_SSL_KEYSTORE_PASSWORD = configLoader
            .getConfigValue(RelidAuthServer.AUTH_SERVER_SSL_KEYSTORE_PASSWORD.getName());

    public static final String AUTH_SERVER_SSL_KEY_PASSWORD = configLoader
            .getConfigValue(RelidAuthServer.AUTH_SERVER_SSL_KEY_PASSWORD.getName());

    public static final String AUTH_SERVER_SSL_KEY_ALIAS = configLoader
            .getConfigValue(RelidAuthServer.AUTH_SERVER_SSL_KEY_ALIAS.getName());

    public static final String AUTH_SERVER_SSL_KEYSTORE_PROVIDER = configLoader
            .getConfigValue(RelidAuthServer.AUTH_SERVER_SSL_KEYSTORE_PROVIDER.getName());

    public static final boolean AUTH_SERVER_SSL_ENABLED = Boolean
            .parseBoolean(configLoader.getConfigValue(RelidAuthServer.AUTH_SERVER_SSL_ENABLED.getName()));

    public static final String AUTH_SERVER_SSL_KEYSTORE = configLoader
            .getConfigValue(RelidAuthServer.AUTH_SERVER_SSL_KEYSTORE.getName());

    public static final AllowedAuthenticationFactors AUTH_SERVER_ALLOWED_AUTH_FACTORS = Utils.mapStringToObject(
            configLoader.getConfigValue(RelidAuthServer.AUTH_SERVER_ALLOWED_AUTH_FACTORS.getName()),
            AllowedAuthenticationFactors.class);

    public static final AllowedRegistrationFactors AUTH_SERVER_ALLOWED_REG_FACTORS = Utils.mapStringToObject(
            configLoader.getConfigValue(RelidAuthServer.AUTH_SERVER_ALLOWED_REG_FACTORS.getName()),
            AllowedRegistrationFactors.class);

    public static final List<Integer> DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER = Utils.convertCommaSeparatedStringToIntList(
            configLoader.getConfigValue(RelidAuthServer.PROPERTY_AUTH_LEVEL_DEFAULT_ATTEMPT_COUNTER.getName()));

    public static final List<Integer> DEFAULT_COOLING_PERIOD_LIST = Utils.convertCommaSeparatedStringToIntList(
            configLoader.getConfigValue(RelidAuthServer.PROPERTY_DEFAULT_COOLING_PERIOD_LIST.getName()));

    public static final int DEFAULT_COOKIE_EXPIRY_TIME_IN_SECONDS = Integer.parseInt(
            configLoader.getConfigValue(RelidAuthServer.PROPERTY_DEFAULT_COOKIE_EXPIRY_TIME_IN_SECONDS.getName()));

    @SuppressWarnings("unchecked")
    public static final Map<String, String> MFA_USER_DISPLAY_MESSAGES = Utils.mapStringToObject(
            configLoader.getConfigValue(RelidAuthServer.PROPERTY_MFA_DISPLAY_MESSAGES.getName()), HashMap.class);

    public static final String AUTH_SERVER_DEFAULT_COOKIE_PATH = configLoader
            .getConfigValue(RelidAuthServer.PROPERTY_DEFAULT_COOKIE_PATH.getName());

    @SuppressWarnings("unchecked")
    public static final Map<String, Integer> DEFAULT_AUTH_GENERATION_ATTEMPT_COUNTER = Utils.mapStringToObject(
            configLoader.getConfigValue(RelidAuthServer.PROPERTY_DEFAULT_AUTH_GENERATION_ATTEMPT_COUNTER.getName()),
            HashMap.class);

    @SuppressWarnings("unchecked")
    public static final Map<String, Integer> DEFAULT_ACTIVATION_GENERATION_ATTEMPT_COUNTER = Utils
            .mapStringToObject(
                    configLoader.getConfigValue(
                            RelidAuthServer.PROPERTY_DEFAULT_ACTIVATION_GENERATION_ATTEMPT_COUNTER.getName()),
                    HashMap.class);

    public static final String DEFAULT_GLOBAL_ERROR_PAGE_MSG = configLoader
            .getConfigValue(RelidAuthServer.PROPERTY_DEFAULT_GLOBAL_ERROR_PAGE_MSG.getName());

    public static final boolean MANAGE_SECURITY_PREF_ENABLED = Boolean
            .parseBoolean(configLoader.getConfigValue(RelidAuthServer.PROPERTY_MANAGE_SECURITY_PREF_ENABLED.getName()));

    @SuppressWarnings("unchecked")
    public static final Map<String, Object> UI_MESSAGES_PAGE_LOGIN = Utils.mapStringToObject(
            configLoader.getConfigValue(RelidAuthServer.PROPERTY_UI_MESSAGES_PAGE_LOGIN.getName()), HashMap.class);

    public static final boolean UI_MESSAGES_PAGE_LOGIN_USERNAME_START_WITH_FIRSTNAME = Boolean.parseBoolean(configLoader
            .getConfigValue(RelidAuthServer.PROPERTY_UI_MESSAGES_PAGE_LOGIN_USERNAME_START_WITH_FIRSTNAME.getName()));

    @SuppressWarnings("unchecked")
    public static final Map<String, Object> UI_MESSAGES_PAGE_REGISTER = Utils.mapStringToObject(
            configLoader.getConfigValue(RelidAuthServer.PROPERTY_UI_MESSAGES_PAGE_REGISTER.getName()), HashMap.class);

    public static final boolean AUTOMATIC_FIDO_REGISTRATION_ENABLED = Boolean.parseBoolean(
            configLoader.getConfigValue(RelidAuthServer.PROPERTY_AUTOMATIC_FIDO_REGISTRATION_ENABLED.getName()));

    @SuppressWarnings("unchecked")
    public static final Map<String, Object> UI_MESSAGES_PAGE_REGISTER_USER = Utils.mapStringToObject(
            configLoader.getConfigValue(RelidAuthServer.PROPERTY_UI_MESSAGES_PAGE_REGISTER_USER.getName()),
            HashMap.class);

    public static final boolean SHOW_PASS_STRENGTH = Boolean
            .parseBoolean(configLoader.getConfigValue(RelidAuthServer.SHOW_PASS_STRENGTH.getName()));

    public static final String ACTIVATION_DELAY_BEFORE_REDIRECT = configLoader
            .getConfigValue(RelidAuthServer.ACTIVATION_DELAY_BEFORE_REDIRECT.getName());

    public static final int HTTP_SESSION_MAX_INACTIVE_INTERVAL_IN_SECONDS = Integer.parseInt(
            configLoader.getConfigValue(RelidAuthServer.HTTP_SESSION_MAX_INACTIVE_INTERVAL_IN_SECONDS.getName()));

    @SuppressWarnings("unchecked")
    public static final Map<String, Object> UI_MESSAGES_PAGE_REGISTER_FIDO_CONSENT = Utils.mapStringToObject(
            configLoader.getConfigValue(RelidAuthServer.PROPERTY_UI_MESSAGES_PAGE_REGISTER_FIDO_CONSENT.getName()),
            HashMap.class);

    @SuppressWarnings("unchecked")
    public static final Map<String, String> DEFAULT_USER_RECOGNIZED_AUTHTYPE_NAME = Utils.mapStringToObject(
            configLoader.getConfigValue(RelidAuthServer.PROPERTY_DEFAULT_USER_RECOGNIZED_AUTHTYPE_NAME.getName()),
            HashMap.class);

    @SuppressWarnings("unchecked")
    public static final Map<String, Object> UI_MESSAGES_PAGE_ACCOUNT_RECOVERY_CREDENTIAL = Utils
            .mapStringToObject(
                    configLoader.getConfigValue(
                            RelidAuthServer.PROPERTY_UI_MESSAGES_PAGE_ACCOUNT_RECOVERY_CREDENTIAL.getName()),
                    HashMap.class);

    public static class MongoDBConstants {

        public static final String MONGODB_TLS_VERSION = "TLSv1.2";

        public static final boolean MONGO_IS_SSL = Boolean
                .parseBoolean(commonConfig.getConfigValue(CommonConfigKeys.MONGODB_IS_SSL_ENABLED.getName()));

        public static final String MONGO_CERT_PATH = commonConfig
                .getConfigValue(CommonConfigKeys.MONGODB_KEYCERT_PATH.getName());

        public static final String MONGO_CERT_PWD = PropertiesEncryptDecrypt
                .decryptWithAES(commonConfig.getConfigValue(CommonConfigKeys.MONGODB_KEYCERT_PWD.getName()));

        public static final String MONGO_STORE_PATH = commonConfig
                .getConfigValue(CommonConfigKeys.MONGODB_STORE_PATH.getName());

        public static final String MONGO_STORE_PWD = PropertiesEncryptDecrypt
                .decryptWithAES(commonConfig.getConfigValue(CommonConfigKeys.MONGODB_STORE_PWD.getName()));

        public static final String MONGO_CONNECTION_STRING = commonConfig
                .getConfigValue(CommonConfigKeys.MONGODB_CONNECTION_STRING.getName());

        public static final String MONGO_CREDENTIALS = commonConfig
                .getConfigValue(CommonConfigKeys.MONGODB_USERNAME.getName());

        public static final int MONGO_MIN_POOL_SIZE = Integer
                .parseInt(commonConfig.getConfigValue(CommonConfigKeys.MONGODB_MIN_POOL_SIZE.getName()));

        public static final int MONGO_MAX_POOL_SIZE = Integer
                .parseInt(commonConfig.getConfigValue(CommonConfigKeys.MONGODB_MAX_POOL_SIZE.getName()));

        public static final long MONGO_MAX_WAIT_TIME_IN_MILLIS = Long
                .parseLong(commonConfig.getConfigValue(CommonConfigKeys.MONGODB_MAX_WAIT_TIME_IN_MILLIS.getName()));

        public static final long MONGO_MAX_CONNECTION_LIFETIME_IN_MILLIS = Long.parseLong(
                commonConfig.getConfigValue(CommonConfigKeys.MONGODB_MAX_CONNECTION_LIFETIME_IN_MILLIS.getName()));

        public static final long MONGO_MAX_CONNECTION_IDLETIME_IN_MILLIS = Long.parseLong(
                commonConfig.getConfigValue(CommonConfigKeys.MONGODB_MAX_CONNECTION_IDLETIME_IN_MILLIS.getName()));

        public static final long MONGO_MAINTENANCE_INITIAL_DELAY_IN_MILLIS = Long.parseLong(
                commonConfig.getConfigValue(CommonConfigKeys.MONGODB_MAINTENANCE_INITIAL_DELAY_IN_MILLIS.getName()));

        public static final long MONGO_MAINTENANCE_FREQUENCY_IN_MILLIS = Long.parseLong(
                commonConfig.getConfigValue(CommonConfigKeys.MONGODB_MAINTENANCE_FREQUENCY_IN_MILLIS.getName()));

        public static final String REL_ID_DB_NAME = commonConfig
                .getConfigValue(CommonConfigKeys.DB_NAME_RELID.getName());

        public static final String AUTH_SERVER_DB_NAME = commonConfig
                .getConfigValue(CommonConfigKeys.DB_NAME_AUTH_SERVER.getName());

        public static final String GM_DB_NAME = commonConfig.getConfigValue(CommonConfigKeys.DB_NAME_GM.getName());

        public static final String ADAPTER_DB_NAME = commonConfig
                .getConfigValue(CommonConfigKeys.DB_NAME_ADAPTER.getName());

        public static final String OOBMSG_DB_NAME = commonConfig
                .getConfigValue(CommonConfigKeys.DB_NAME_OOBMSG.getName());

        private MongoDBConstants() {
            throw new IllegalStateException("Utility class");
        }

    }

    public static class RabbitMQConstants {

        public static final String RABBITMQ_TLS_VERSION = "TLSv1.2";

        public static final boolean RABBITMQ_IS_SSL = Boolean
                .parseBoolean(commonConfig.getConfigValue(CommonConfigKeys.RABBIT_MQ_IS_SSL_ENABLED.getName()));

        public static final String RABBITMQ_USERNAME = PropertiesEncryptDecrypt
                .decryptWithAES(commonConfig.getConfigValue(CommonConfigKeys.RABBIT_MQ_USERNAME.getName()));
        public static final String RABBITMQ_PWD = PropertiesEncryptDecrypt
                .decryptWithAES(commonConfig.getConfigValue(CommonConfigKeys.RABBIT_MQ_PASSWORD.getName()));

        public static final String RABBITMQ_HOST = commonConfig
                .getConfigValue(CommonConfigKeys.RABBIT_MQ_LOCALHOST.getName());

        public static final int RABBITMQ_PORT = Integer
                .parseInt(commonConfig.getConfigValue(CommonConfigKeys.RABBIT_MQ_LOCALPORT.getName()));

        public static final String RABBITMQ_KEYCERT_PATH = commonConfig
                .getConfigValue(CommonConfigKeys.RABBIT_MQ_KEYCERT_PATH.getName());

        public static final String RABBITMQ_KEYCERT_PWD = PropertiesEncryptDecrypt
                .decryptWithAES(commonConfig.getConfigValue(CommonConfigKeys.RABBIT_MQ_KEYCERT_PWD.getName()));

        public static final String RABBITMQ_STORE_PATH = commonConfig
                .getConfigValue(CommonConfigKeys.RABBIT_MQ_STORE_PATH.getName());

        public static final String RABBITMQ_STORE_PWD = PropertiesEncryptDecrypt
                .decryptWithAES(commonConfig.getConfigValue(CommonConfigKeys.RABBIT_MQ_STORE_PWD.getName()));

        private RabbitMQConstants() {
            throw new IllegalStateException("Utility class");
        }

    }

    public static class RelIdVerifyConstants {

        public static final String NOTIFICATION_REJECT_LABEL = configLoader
                .getConfigValue(RelidAuthServer.NOTIFICATION_MSG_REJECT_LABEL.getName());

        public static final String NOTIFICATION_ACCEPT_LABEL = configLoader
                .getConfigValue(RelidAuthServer.NOTIFICATION_MSG_ACCEPT_LABEL.getName());

        public static final String NOTIFICATION_FRAUD_LABEL = configLoader
                .getConfigValue(RelidAuthServer.NOTIFICATION_MSG_FRAUD_LABEL.getName());

        public static final String GENERIC_VERIFY_MESSAGE = configLoader
                .getConfigValue(RelidAuthServer.GENERIC_VERIFY_MESSAGE.getName());

        public static final String GENERIC_VERIFY_MESSAGE_REMEMBER_ME = configLoader
                .getConfigValue(RelidAuthServer.GENERIC_VERIFY_MESSAGE_WITH_REMEMBER_ME.getName());

        private RelIdVerifyConstants() {
            throw new IllegalStateException("Utility class");
        }

    }

    public static class TOTPConstans {

        /**
         * Is TOTP enable.
         */
        public static final boolean IS_TOTP_ENABLED = Boolean
                .parseBoolean(commonConfig.getConfigValue(CommonConfigKeys.IS_TOTP_ENABLED.getName()));

        public static final String TOTP_CONFIGS = commonConfig.getConfigValue(CommonConfigKeys.TOTP_CONFIGS.getName());

        public static List<Object> totpEnabledAppAgents = Constants.GSON_BSON.fromJson(
                commonConfig.getConfigValue(CommonConfigKeys.APP_AGENTS_ENABLED_FOR_TOTP.getName()),
                new TypeToken<List<String>>() {
                }.getType());

        private TOTPConstans() {
            throw new IllegalStateException("Utility class");
        }

    }

    public static class FidoConstants {

        static {

            FIDO2Constants.rpDomain = configLoader
                    .getConfigValue(RelidAuthServer.AUTH_SERVER_FIDO2_RELYING_PARTY_DOMAIN.getName());

            FIDO2Constants.certsLocation = configLoader
                    .getConfigValue(RelidAuthServer.AUTH_SERVER_FIDO2_AUTHENTICATOR_CERT_LOCATION.getName());

            FIDO2Constants.mds3FilesFolder = configLoader
                    .getConfigValue(RelidAuthServer.AUTH_SERVER_FIDO2_MDS3_TOC_FILE_LOCATION.getName());

            FIDO2Constants.mds3TocRootFileLocation = configLoader
                    .getConfigValue(RelidAuthServer.AUTH_SERVER_FIDO2_MDS3_TOC_ROOT_FILE.getName());

            FIDO2Constants.appleWebAuthnRootCA = configLoader
                    .getConfigValue(RelidAuthServer.AUTH_SERVER_FIDO2_APPLE_WEBAUTHN_ROOT_CA_CERT_URL.getName());

            FIDO2Constants.onlineSafetyNetAPIToBeCalledByDefault = Boolean.parseBoolean(configLoader.getConfigValue(
                    RelidAuthServer.AUTH_SERVER_FIDO2_ANDROID_SAFETY_NET_API_ONLINE_BY_DEFAULT.getName()));

            FIDO2Constants.onlineSafetyNetAPIUrl = configLoader
                    .getConfigValue(RelidAuthServer.AUTH_SERVER_FIDO2_ANDROID_SAFETY_NET_API_URL.getName());

            FIDO2Constants.onlineSafetyNetAPIKey = PropertiesEncryptDecrypt.decryptWithAES(configLoader
                    .getConfigValue(RelidAuthServer.AUTH_SERVER_FIDO2_ANDROID_SAFETY_NET_API_KEY.getName()));

            FIDO2Constants.serverPort = AUTH_SERVER_PORT;

            FIDO2Constants.sslKeyStoreType = AUTH_SERVER_SSL_KEYSTORE_TYPE;

            FIDO2Constants.sslKeystorePassword = AUTH_SERVER_SSL_KEYSTORE_PASSWORD;

            FIDO2Constants.sslEnabled = AUTH_SERVER_SSL_ENABLED;

            FIDO2Constants.sslKeyStore = AUTH_SERVER_SSL_KEYSTORE;

            FIDO2Constants.DATE_FORMAT = DATE_FORMAT;

            FIDO2Constants.GSON = Constants.GSON;
        }

        private FidoConstants() {
        }

    }

    public static class GmConstants {

        public static final String MOBILE_NUM_REGEX = gmConfig.getConfigValue("mobile.number.regex");

        public static final String EMAIL_ID_REGEX = gmConfig.getConfigValue("email.id.regex");

        private GmConstants() {
        }

    }

    private PropertyConstants() {
        throw new IllegalStateException("Utility class");
    }
}
