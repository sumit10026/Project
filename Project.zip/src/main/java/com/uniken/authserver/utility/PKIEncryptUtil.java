package com.uniken.authserver.utility;

import java.io.IOException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

import com.uniken.blazepki.pki.EncCipher;
import com.uniken.blazepki.pki.EncCipherFactory;

public class PKIEncryptUtil {

    private static EncCipher encCypher;

    public static String encryptData(final String plainTextRelId) {
        String encTextRelId = "";
        try {
            if (Constants.OOBPUSHER_PUBLIC_CERTIFICATE_READ_ONCE && encCypher == null) {
                encCypher = EncCipherFactory.getInstance(Constants.OOBPUSHER_PUBLIC_CERTIFICATE_PATH,
                        Constants.OOBPUSHER_PUBLIC_CERTIFICATE_TYPE, Constants.OOBPUSHER_PUBLIC_CERTIFICATE_ALGO);
                encTextRelId = encryptData(encCypher, plainTextRelId);
            } else if (Constants.OOBPUSHER_PUBLIC_CERTIFICATE_READ_ONCE && encCypher != null) {
                encTextRelId = encryptData(encCypher, plainTextRelId);
            } else {
                final EncCipher encCypherLocal = EncCipherFactory.getInstance(
                        Constants.OOBPUSHER_PUBLIC_CERTIFICATE_PATH, Constants.OOBPUSHER_PUBLIC_CERTIFICATE_TYPE,
                        Constants.OOBPUSHER_PUBLIC_CERTIFICATE_ALGO);
                encTextRelId = encryptData(encCypherLocal, plainTextRelId);
            }
        } catch (final Exception e) {
            throw new RuntimeException("Error while encrypting server part of relid using public key", e);
        }
        return encTextRelId;
    }

    private static String encryptData(final EncCipher encCipher, final String plainTextRelId) {
        String encTextRelId = "";
        try {
            final int edLength = (Constants.OOBPUSHER_PUBLIC_CERTIFICATE_KEY_SIZE / 8) - 11;
            final int lenToEnc = plainTextRelId.length();
            int loopCount = plainTextRelId.length() / edLength;
            if (plainTextRelId.length() % edLength > 0)
                loopCount++;
            final StringBuffer sb = new StringBuffer();
            for (int i = 0; i < loopCount; i++) {
                int startIndex = (i * edLength) - 1;
                if (startIndex < 0)
                    startIndex = 0;
                int endIndex = (i * edLength) + (edLength - 1);
                if (lenToEnc < endIndex)
                    endIndex = lenToEnc;
                final String toEnc = plainTextRelId.substring(startIndex, endIndex);
                final String enc = encCipher.encrypt(toEnc);
                if (sb.length() == 0)
                    sb.append(enc);
                else
                    sb.append("\r\n").append(enc);
            }
            encTextRelId = sb.toString();
        } catch (IOException | IllegalBlockSizeException | BadPaddingException e) {
            throw new RuntimeException("Error while encrypting server part of relid using public key", e);
        }
        return encTextRelId;
    }

}
