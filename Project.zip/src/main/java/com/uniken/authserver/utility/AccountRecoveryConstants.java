package com.uniken.authserver.utility;

public class AccountRecoveryConstants {

    private AccountRecoveryConstants() {
    }

    // Auth Token Constants
    public static final String AUTH_TOKEN = "auth-token";
    public static final String ARC_TOKEN = "arc-token";

    public static final String USERNAME = "username";
    public static final String AUTH_FACTOR_NEEDS_TO_RESET = "auth_factor_needs_to_reset";

    // AR IDV Endpoints
    public static final String ACCOUNT_RECOVERY_IDV_BASE_URI = "/account-recovery-idv";
    public static final String GET_AVAILABLE_IDV_METHODS_BASE_URI = ACCOUNT_RECOVERY_IDV_BASE_URI
            + "/get-available-idv-methods";
    public static final String VALIDATE_USER_IDENTITY_BASE_URI = ACCOUNT_RECOVERY_IDV_BASE_URI
            + "/validate-user-identity";

    // ARC Endpoints
    public static final String ACCOUNT_RECOVERY_CREDENTIAL_BASE_URI = "/account-recovery-credential";
    public static final String GET_CREDENTIAL_ACTIVATION_TOKEN = ACCOUNT_RECOVERY_CREDENTIAL_BASE_URI
            + "/get-credential-activation-token";
    public static final String RESET_CREDENTIAL = ACCOUNT_RECOVERY_CREDENTIAL_BASE_URI + "/reset-credential";
    public static final String GET_RESET_CREDENTIAL_FACTOR = ACCOUNT_RECOVERY_CREDENTIAL_BASE_URI
            + "/get-reset-credential-factor";
    public static final String ACCOUNT_RECOVERY_CREDENTIAL_CONFIGS = AccountRecoveryConstants.ACCOUNT_RECOVERY_CREDENTIAL_BASE_URI
            + "/configs";
    public static final String ACCOUNT_RECOVERY_FETCH_PUBLIC_KEY = AccountRecoveryConstants.ACCOUNT_RECOVERY_CREDENTIAL_BASE_URI
            + "/fetchPublicKey";
    public static final String ACCOUNT_RECOVERY_REDIRECT_LOGIN = AccountRecoveryConstants.ACCOUNT_RECOVERY_CREDENTIAL_BASE_URI
            + "/redirect-login";
    public static final String SUBMIT_ARC_FORM = AccountRecoveryConstants.ACCOUNT_RECOVERY_CREDENTIAL_BASE_URI
            + "/submit-arc-form";

    // Session Attributes
    public static final String ACCOUNT_RECOVERY_TOKEN_DETAILS = "account_recovery_token_details";
    public static final String ACCOUNT_RECOVERY_TOKEN = "account_recovery_token";
    public static final String ACCOUNT_RECOVERY_CREDENTIAL_USERNAME = "account_recovery_credential_username";
    public static final String PENDING_RESET_CREDENTIAL_FACTOR_SET = "pending_reset_credential_factor_set";
    public static final String COMPLETED_RESET_CREDENTIAL_FACTOR_SET = "completed_reset_credential_factor_set";

    public static final String REDIRECT_ERROR = "redirect:error";

}
