/**
 * 
 */
package com.uniken.authserver.utility;

import java.security.Principal;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.bson.types.ObjectId;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.oauth2.common.DefaultExpiringOAuth2RefreshToken;
import org.springframework.security.oauth2.common.OAuth2RefreshToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.uniken.authserver.domains.PassPolicy;
import com.uniken.commons.config.AppConfigLoader;
import com.uniken.domains.enums.appconfig.CommonConfigKeys;
import com.uniken.domains.enums.appconfig.ModuleNames;
import com.uniken.domains.enums.appconfig.RelidAuthServer;
import com.uniken.domains.relid.notification.NotificationUserActionResponse;
import com.uniken.domains.util.BsonObjectIdAdapter;
import com.uniken.domains.util.InterfaceSerializer;
import com.uniken.encdecutils.PropertiesEncryptDecrypt;

/**
 * @author Kushal Jaiswal
 */
public class Constants {

    public static final String BUILD_VERSION_NO = "22.06.07";

    public static final boolean IS_CONFIG_MANDATORY = true;
    public static final String AUTH_SERVER_CONTEXT_URL = "/relid/authserver";

    public static final String GENERATE_ACCESS_TOKEN_REQ = Constants.AUTH_SERVER_CONTEXT_URL + "/oauth/token";
    public static final String REVOKE_ACCESS_TOKEN_REQ = Constants.AUTH_SERVER_CONTEXT_URL + "/oauth/token/revoke";
    public static final String CHECK_TOKEN_REQ = Constants.AUTH_SERVER_CONTEXT_URL + "/oauth/check_token";
    public static final String JWKS_URI = Constants.AUTH_SERVER_CONTEXT_URL + "/.well-known/jwks.json";

    // TODO : It is not yet configured, please add URI.
    public static final String GET_ACCESS_TOKEN_BY_REFRESH_TOKEN = Constants.AUTH_SERVER_CONTEXT_URL + "";

    // OIDC related APIs
    public static final String AUTHORIZE_REQ = Constants.AUTH_SERVER_CONTEXT_URL + "/oauth/authorize";
    public static final String VALIDATE_USER_REQ = Constants.AUTH_SERVER_CONTEXT_URL + "/oauth/validateUser";
    public static final String USER_INFO_REQ = Constants.AUTH_SERVER_CONTEXT_URL + "/oauth/userInfo";
    public static final String USER_INFO_REQ_2 = Constants.AUTH_SERVER_CONTEXT_URL + "/oauth/userinfo";
    public static final String IS_USER_REQ_AUTHENTICATED = Constants.AUTH_SERVER_CONTEXT_URL
            + "/oauth/isUserAuthenticated";

    public static final String VALIDATE_USER_BASED_ON_AUTH_TYPE_REQ = Constants.AUTH_SERVER_CONTEXT_URL
            + "/oauth/validate-user";

    public static final String AUTH_ERROR_REQ = Constants.AUTH_SERVER_CONTEXT_URL + "/error";

    public static final String GET_CONFIGURATION_REQ = Constants.AUTH_SERVER_CONTEXT_URL + "/configs";

    public static final String GET_REG_AUTH_FACTOR_FOR_USER = Constants.AUTH_SERVER_CONTEXT_URL
            + "/user-portal/auth-factor-management/list";

    public static final String DELETE_REG_AUTH_FACTOR_FOR_USER = Constants.AUTH_SERVER_CONTEXT_URL
            + "/user-portal/auth-factor-management/delete";

    public static final String UPDATE_STATUS_REG_AUTH_FACTOR_FOR_USER = Constants.AUTH_SERVER_CONTEXT_URL
            + "/user-portal/auth-factor-management/update-status";

    public static final String REG_AUTH_FACTOR_PAGE = Constants.AUTH_SERVER_CONTEXT_URL
            + "/user-portal/auth-factor-management";

    public static final String BROWSER_MANAGEMENT_PAGE = Constants.AUTH_SERVER_CONTEXT_URL
            + "/user-portal/browser-management";

    public static final String GET_BROWSER_MANAGEMENT_LIST = Constants.AUTH_SERVER_CONTEXT_URL
            + "/user-portal/browser-management/list";

    public static final String GET_WEB_USER_BROWSER = Constants.AUTH_SERVER_CONTEXT_URL + "/webUserBrowsers";

    public static final String UPDATE_WEB_USER_BROWSER_STATUS = Constants.AUTH_SERVER_CONTEXT_URL
            + "/webUserBrowsers/{webDeviceUuid}";

    public static final String UNREMEBER_WEB_USER_BROWSER = Constants.AUTH_SERVER_CONTEXT_URL
            + "/webUserBrowsers/unRemember";

    public static final String DELETE_WEB_USER_BROWSER = Constants.AUTH_SERVER_CONTEXT_URL
            + "/user-portal/webUserBrowsers/delete";

    public static final String DELETE_ACCOUNT = Constants.AUTH_SERVER_CONTEXT_URL + "/oauth/delete-account";

    public static final String REQUESTOR_ID = "RequestorId";
    public static final String CORRELATION_ID = "correlationID";

    public static final String REQ_PARAM_USERNAME = "username";
    public static final String REQ_PARAM_AUTH_TYPE = "auth_type";
    public static final String REQ_PARAM_AUTH_VALUE = "auth_value";
    public static final String REQ_PARAM_SESSION_ID = "session_id";
    public static final String REQ_PARAM_REQUEST_TYPE = "requestType";
    public static final String REQ_PARAM_REMEMBER_ME = "remember_me";
    public static final String REQ_PARAM_LAST_LOGIN_METHOD = "last_login_method";
    public static final String REQ_PARAM_FIDO_PLATFORM_AUTHENTICATOR_AVAILABLE = "fido_platform_authenticator_available";

    public static final String REQUESTOR_IP_DEFAULT_HEADER = "REQUESTORSIP";
    public static final String NOTIFICATION_REQUESTOR_NAME = "notification_requester_name";
    public static final String AUTH_SERVER_COMPONENT_NAME = "AUTH_SERVER";
    public static final String VERIFY_NODE_EXCHANGE = "zeroExchange";
    public static final String BLAZEADAPTER_NODE_EXCHANGE = "rExchange";

    public static final String AUTH_SERVER_NODE_EXCHANGE = "authServerExchange";
    public static final String AUTH_SERVER_NODE_RECEIVING_QUEUE = "authServerQueue";

    public static final String EXCEPTION_INITIAL_STR = "Handling error: {}, {} ";

    public static final String REVOKE_TOKEN_HEADER = "token";
    public static final String TOKEN_TYPE_HEADER = "token_type";
    public static final String AUTH_HEADER = "authorization";

    public static final String RELID_AUTH_TYPE = "REL-ID";

    public static final String UNAUTHORIZED_ACCESS = "Authentication Failed";

    public static final String AUTH_HEADER_BEARER = "bearer";

    public static final String RESOURCE_AUTHSERVERDB_MONGO_TEMPLATE = "authserverMongoTemplate";
    public static final String RESOURCE_RELIDDB_MONGO_TEMPLATE = "relIddbMongoTemplate";
    public static final String RESOURCE_GMDB_MONGO_TEMPLATE = "gmdbMongoTemplate";
    public static final String RESOURCE_ADAPTERDB_MONGO_TEMPLATE = "adapterdbMongoTemplate";
    public static final String RESOURCE_OOBMSGDB_MONGO_TEMPLATE = "oobMsgdbMongoTemplate";
    public static final String RESOURCE_CONFIGURATION_MONGO_TEMPLATE = "configurationMongoTemplate";

    // Secure Cookie Related Constants
    public static final String HOST_PREFIX = "__Host";
    public static final String COOKIE_NAME = "ACC_CH";
    public static final String SECURE_COOKIE_NAME = HOST_PREFIX + "-" + COOKIE_NAME;

    // MFA Related Constants
    public static final Integer LEVEL_1_AUTH_ATTEMPT_COUNTER_INDEX = 0;
    public static final Integer LEVEL_2_AUTH_ATTEMPT_COUNTER_INDEX = 1;
    public static final int COOLING_PERIOD_FIRST_INTERVAL = 0;

    private static final String PROPERTY_SEPARATOR = ",";

    // Platform Detection Related Constants
    public static final String USER_AGENT_STR = "USER-AGENT";
    public static final String OPERATING_SYSTEM_NAME_STR = "OperatingSystemName";
    public static final String PLATFORM_SPECIFIC_MSGS_STR = "platform_specific_msgs";

    // FIDO Platform Authenticator Transport Type
    public static final String FIDO_PLATFORM_TRANSPORT_TYPE = "internal";

    // FIDO Device Types
    public static final String FIDO_DEVICE_TYPE_PLATFORM = "FIDOPLATFORM";
    public static final String FIDO_DEVICE_TYPE_2FAROAMING = "FIDO2FAROAMING";
    public static final String FIDO_DEVICE_TYPE_1FAROAMING = "FIDO1FAROAMING";

    public static final String IMG_BASE64_ENCODED_PNG_TYPE = "data:image/png;base64,";

    private static final AppConfigLoader configLoader = new AppConfigLoader(ModuleNames.AUTH_SERVER.getName());
    private static final AppConfigLoader commonConfig = new AppConfigLoader(ModuleNames.CommonConfigs.getName());

    public static final boolean MONGO_IS_SSL = Boolean
            .parseBoolean(commonConfig.getConfigValue(CommonConfigKeys.MONGODB_IS_SSL_ENABLED.getName()));

    public static final String MONGO_CERT_PATH = commonConfig
            .getConfigValue(CommonConfigKeys.MONGODB_KEYCERT_PATH.getName());

    public static final String MONGO_CERT_PWD = PropertiesEncryptDecrypt
            .decryptWithAES(commonConfig.getConfigValue(CommonConfigKeys.MONGODB_KEYCERT_PWD.getName()));

    public static final String MONGO_STORE_PATH = commonConfig
            .getConfigValue(CommonConfigKeys.MONGODB_STORE_PATH.getName());

    public static final String MONGO_STORE_PWD = PropertiesEncryptDecrypt
            .decryptWithAES(commonConfig.getConfigValue(CommonConfigKeys.MONGODB_STORE_PWD.getName()));

    public static final String MONGO_CONNECTION_STRING = commonConfig
            .getConfigValue(CommonConfigKeys.MONGODB_CONNECTION_STRING.getName());

    public static final String MONGO_CREDENTIALS = commonConfig
            .getConfigValue(CommonConfigKeys.MONGODB_USERNAME.getName());

    public static final int MONGO_MIN_POOL_SIZE = Integer
            .parseInt(commonConfig.getConfigValue(CommonConfigKeys.MONGODB_MIN_POOL_SIZE.getName()));
    public static final int MONGO_MAX_POOL_SIZE = Integer
            .parseInt(commonConfig.getConfigValue(CommonConfigKeys.MONGODB_MAX_POOL_SIZE.getName()));
    public static final int MONGO_MAX_WAIT_QUEUE_SIZE = Integer
            .parseInt(commonConfig.getConfigValue(CommonConfigKeys.MONGODB_MAX_WAIT_QUEUE_SIZE.getName()));
    public static final long MONGO_MAX_WAIT_TIME_IN_MILLIS = Long
            .parseLong(commonConfig.getConfigValue(CommonConfigKeys.MONGODB_MAX_WAIT_TIME_IN_MILLIS.getName()));
    public static final long MONGO_MAX_CONNECTION_LIFETIME_IN_MILLIS = Long.parseLong(
            commonConfig.getConfigValue(CommonConfigKeys.MONGODB_MAX_CONNECTION_LIFETIME_IN_MILLIS.getName()));
    public static final long MONGO_MAX_CONNECTION_IDLETIME_IN_MILLIS = Long.parseLong(
            commonConfig.getConfigValue(CommonConfigKeys.MONGODB_MAX_CONNECTION_IDLETIME_IN_MILLIS.getName()));
    public static final long MONGO_MAINTENANCE_INITIAL_DELAY_IN_MILLIS = Long.parseLong(
            commonConfig.getConfigValue(CommonConfigKeys.MONGODB_MAINTENANCE_INITIAL_DELAY_IN_MILLIS.getName()));
    public static final long MONGO_MAINTENANCE_FREQUENCY_IN_MILLIS = Long
            .parseLong(commonConfig.getConfigValue(CommonConfigKeys.MONGODB_MAINTENANCE_FREQUENCY_IN_MILLIS.getName()));

    public static final boolean RABBITMQ_IS_SSL = Boolean
            .parseBoolean(commonConfig.getConfigValue(CommonConfigKeys.RABBIT_MQ_IS_SSL_ENABLED.getName()));

    public static final String RABBITMQ_USERNAME = PropertiesEncryptDecrypt
            .decryptWithAES(commonConfig.getConfigValue(CommonConfigKeys.RABBIT_MQ_USERNAME.getName()));
    public static final String RABBITMQ_PWD = PropertiesEncryptDecrypt
            .decryptWithAES(commonConfig.getConfigValue(CommonConfigKeys.RABBIT_MQ_PASSWORD.getName()));

    public static final String RABBITMQ_HOST = commonConfig
            .getConfigValue(CommonConfigKeys.RABBIT_MQ_LOCALHOST.getName());

    public static final int RABBITMQ_PORT = Integer
            .parseInt(commonConfig.getConfigValue(CommonConfigKeys.RABBIT_MQ_LOCALPORT.getName()));

    public static final String RABBITMQ_KEYCERT_PATH = commonConfig
            .getConfigValue(CommonConfigKeys.RABBIT_MQ_KEYCERT_PATH.getName());
    public static final String RABBITMQ_KEYCERT_PWD = PropertiesEncryptDecrypt
            .decryptWithAES(commonConfig.getConfigValue(CommonConfigKeys.RABBIT_MQ_KEYCERT_PWD.getName()));
    public static final String RABBITMQ_STORE_PATH = commonConfig
            .getConfigValue(CommonConfigKeys.RABBIT_MQ_STORE_PATH.getName());
    public static final String RABBITMQ_STORE_PWD = PropertiesEncryptDecrypt
            .decryptWithAES(commonConfig.getConfigValue(CommonConfigKeys.RABBIT_MQ_STORE_PWD.getName()));
    public static final String RABBITMQ_TLS_VERSION = "TLSv1.2";
    public static final String MONGODB_TLS_VERSION = "TLSv1.2";

    public static final String REL_ID_DB_NAME = commonConfig.getConfigValue(CommonConfigKeys.DB_NAME_RELID.getName());

    public static final String AUTH_SERVER_DB_NAME = commonConfig
            .getConfigValue(CommonConfigKeys.DB_NAME_AUTH_SERVER.getName());

    public static final String GM_DB_NAME = commonConfig.getConfigValue(CommonConfigKeys.DB_NAME_GM.getName());

    public static final String ADAPTER_DB_NAME = commonConfig
            .getConfigValue(CommonConfigKeys.DB_NAME_ADAPTER.getName());

    public static final String DATE_FORMAT = commonConfig.getConfigValue(CommonConfigKeys.DATE_FORMAT.getName());

    public static final String NOTIFICATION_REJECT_LABEL = commonConfig
            .getConfigValue(CommonConfigKeys.NOTIFICATION_MSG_REJECT_LABEL.getName());

    public static final String NOTIFICATION_ACCEPT_LABEL = commonConfig
            .getConfigValue(CommonConfigKeys.NOTIFICATION_MSG_ACCEPT_LABEL.getName());

    public static final String NOTIFICATION_FRAUD_LABEL = commonConfig
            .getConfigValue(CommonConfigKeys.NOTIFICATION_MSG_FRAUD_LABEL.getName());

    public static final String AUTH_SERVER_PORT = configLoader
            .getConfigValue(RelidAuthServer.AUTH_SERVER_PORT.getName());
    public static final String GENERIC_VERIFY_MESSAGE = configLoader
            .getConfigValue(RelidAuthServer.GENERIC_VERIFY_MESSAGE.getName());

    public static final String AUTH_SERVER_REQUESTOR_IP = configLoader
            .getConfigValue(RelidAuthServer.AUTH_SERVER_REQUESTOR_IP.getName());

    public static final Gson GSON = new GsonBuilder().setDateFormat(DATE_FORMAT).disableHtmlEscaping()
            .registerTypeAdapter(Date.class, new BsonDateAdapter())
            .registerTypeAdapter(ObjectId.class, new BsonObjectIdAdapter())
            // .registerTypeAdapter(OAuth2AccessToken.class,
            // InterfaceSerializer.interfaceSerializer(CustomOAuth2AccessToken.class))
            .registerTypeAdapter(OAuth2RefreshToken.class,
                    InterfaceSerializer.interfaceSerializer(DefaultExpiringOAuth2RefreshToken.class))
            .registerTypeAdapter(Principal.class, InterfaceSerializer.interfaceSerializer(User.class))
            .registerTypeAdapter(GrantedAuthority.class,
                    InterfaceSerializer.interfaceSerializer(SimpleGrantedAuthority.class))
            .registerTypeAdapter(Authentication.class,
                    InterfaceSerializer.interfaceSerializer(OAuth2Authentication.class))
            .registerTypeAdapter(Authentication.class,
                    InterfaceSerializer.interfaceSerializer(UsernamePasswordAuthenticationToken.class))
            .create();

    public static final Gson GSON_BSON = new GsonBuilder().setDateFormat(PropertyConstants.DATE_FORMAT)
            .registerTypeAdapter(Date.class, new BsonDateAdapter()).disableHtmlEscaping().create();

    public static final ObjectMapper JACKSON_OBJECT_MAPPER = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
            .enable(JsonParser.Feature.ALLOW_SINGLE_QUOTES);

    /**
     * Event logger related constants
     */
    public static final String BASIC_AUTH_INIT_MESSAGE = "Request Received for authentication ";
    public static final String BASIC_AUTH_SUCCESS_MESSAGE = "Authenticated successfully";
    public static final String BASIC_AUTH_FAILED_MESSAGE = "Unauthorized";
    public static final String REQUEST_SUCCESS_MESSAGE = "Request successfully completed";

    /**
     * Is TOTP enable.
     */
    public static final boolean IS_TOTP_ENABLED = Boolean
            .parseBoolean(commonConfig.getConfigValue(CommonConfigKeys.IS_TOTP_ENABLED.getName()));

    public static final String TOTP_CONFIGS = commonConfig.getConfigValue(CommonConfigKeys.TOTP_CONFIGS.getName());

    public static final PassPolicy PASS_POLICY = Utils
            .getPassPolicy(commonConfig.getConfigValue(CommonConfigKeys.PASS_POLICY.getName()));

    public static final String OOBPUSHER_PUBLIC_CERTIFICATE_PATH = configLoader
            .getConfigValue("oobpusher.public.certificate.path");

    public static final boolean OOBPUSHER_PUBLIC_CERTIFICATE_READ_ONCE = Boolean
            .parseBoolean(configLoader.getConfigValue("oobpusher.public.certificate.read.once"));
    public static final String OOBPUSHER_PUBLIC_CERTIFICATE_TYPE = configLoader
            .getConfigValue("oobpusher.public.certificate.type");
    public static final String OOBPUSHER_PUBLIC_CERTIFICATE_ALGO = configLoader
            .getConfigValue("oobpusher.public.certificate.algo");
    public static final int OOBPUSHER_PUBLIC_CERTIFICATE_KEY_SIZE = Integer
            .parseInt(configLoader.getConfigValue("oobpusher.public.certificate.key.size"));

    public static final String SPECS_FOR_ACCESS_CODE_GEN = configLoader.getConfigValue("access.code.spec");

    public static final int otpExpiry = Integer.parseInt(configLoader.getConfigValue("otp.expiry.in.seconds"));

    public static final int SECURE_RANDOM_CONTENT_LENGTH = Integer
            .parseInt(configLoader.getConfigValue("secure.random.content.length", false));

    public static final String AUTH_SERVER_LOCAL_IP = Utility.fetchAndSelectCurrentNetworkInterface();
    public static final String SECURE_COOKIE_KEY = PropertiesEncryptDecrypt
            .decryptWithAES(configLoader.getConfigValue("secure.cookie.protection.key"));
    public static final String SECURE_COOKIE_SALT = PropertiesEncryptDecrypt
            .decryptWithAES(configLoader.getConfigValue("secure.cookie.protection.salt"));
    public static final String OIDC_CONFIG_JWT_ISSUER_NAME = configLoader.getConfigValue("oidc.config.jwt.issuer.name");
    public static final String OIDC_CONFIG_JWT_KEYSTORE_PASSPHRASE = configLoader
            .getConfigValue("oidc.config.jwt.keystore.passphrase");
    public static final String OIDC_CONFIG_JWT_KEYSTORE_TYPE = configLoader
            .getConfigValue("oidc.config.jwt.keystore.type");
    public static final String OIDC_CONFIG_JWT_KEYSTORE_KEY_ALIAS = configLoader
            .getConfigValue("oidc.config.jwt.keystore.key.alias");
    public static final String OIDC_CONFIG_JWT_KEYSTORE_PATH = configLoader
            .getConfigValue("oidc.config.jwt.keystore.path");
    public static final String USERLOCATION_NOT_AVAILABLE_DEFAULT_VALUE = configLoader
            .getConfigValue("userlocation.not.available.default.value");

    // FIXME: Revisit whitelisted URIs
    public static final Set<String> AUTH_SERVER_WHITELISTED_PUBLIC_URIS = Collections
            .unmodifiableSet(new HashSet<>(Arrays.asList(Utils.split(
                    configLoader.getConfigValue(RelidAuthServer.AUTH_SERVER_WHITELISTED_PUBLIC_URIS.getName()),
                    PROPERTY_SEPARATOR))));

    public static final String WHITELISTED_RP_SERVER_IPS_DB_VALUE = Utils.isNullOrEmpty(
            configLoader.getConfigValue(RelidAuthServer.WHITELISTED_RP_SERVER_IPS.getName())) ? "127.0.0.1"
                    : configLoader.getConfigValue(RelidAuthServer.WHITELISTED_RP_SERVER_IPS.getName());

    public static final Set<String> WHITELISTED_RP_SERVER_IPS = Collections.unmodifiableSet(
            new HashSet<>(Stream.of(Arrays.asList(Utils.split(WHITELISTED_RP_SERVER_IPS_DB_VALUE, PROPERTY_SEPARATOR)))
                    .flatMap(Collection::stream).filter(ip -> !ip.isEmpty()).collect(Collectors.toList())));

    public static final Set<String> AUTH_SERVER_ALLOWED_HOSTNAMES = Collections.unmodifiableSet(new HashSet<>(
            Arrays.asList(Utils.split(configLoader.getConfigValue("allowed.hostnames"), PROPERTY_SEPARATOR))));

    public static final String AUTH_SERVER_GEOLITE_CITYFILEPATH = LocationUtils
            .validateFileWithDBPath(configLoader.getConfigValue("auth.server.geolite.cityfilepath"));

    public static final String AUTH_SERVER_LOCATION_FORMAT = configLoader.getConfigValue("auth.server.location.format");

    public static final int MAX_SIZE_HTTPHEADER_VALUE_DEFAULT = 50;
    public static final int MAX_SIZE_HTTPHEADER_VALUE_REDIRECT_URI_DEFAULT = 1500;
    public static final int MAX_SIZE_AUTHTYPE_NAME = 20;
    public static final int MAX_SIZE_WEB_DFP_PARAMETER = 5000;
    // public static String COOKIE_PATH = "/";

    public static List<Object> getTotpEnabledAppAgents() {
        return PropertyConstants.TOTPConstans.totpEnabledAppAgents;
    }

    private static final Map<String, NotificationUserActionResponse> VERIFY_NOTIFICATION_RESPONSE_MAP = new HashMap<>();

    /**
     * Gets the response map which use to hold the verify response object
     * received from the REL-ID Verify component.
     * 
     * @return VerifyNotificationResponseMap
     */
    public static final Map<String, NotificationUserActionResponse> getVerifyNotificationResponseMap() {
        return VERIFY_NOTIFICATION_RESPONSE_MAP;
    }

    private Constants() {
        throw new IllegalStateException("Utility class");
    }

    public static final String USERNAME_NOT_FOUND_IN_SESSION_MSG = "Unable to get username from session for User Activation Process";

}
