package com.uniken.authserver.utility;

import java.security.Security;
import java.util.List;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.uniken.authserver.repo.api.TOTPValidationRepo;
import com.uniken.totp.domains.TOTPConfig;

@Component
public class TotpInitializer {

    private static final Logger LOG = LoggerFactory.getLogger(TotpInitializer.class);

    @Autowired
    TOTPValidationRepo totpValidationRepo;

    @PostConstruct
    private void initTotpSp() {
        // Initializing TOTP-Service-provider
        if (PropertyConstants.TOTPConstans.IS_TOTP_ENABLED) {

            /**
             * Adding the Bouncy Castle Provider to Java Security provider list.
             * Needed for supporting ChaCha20-Poly1305 and RC4 ciphers.
             */
            Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());

            if (PropertyConstants.TOTPConstans.TOTP_CONFIGS != null) {
                com.uniken.totp.utils.Constants.initializeTOTPConfig(
                        Constants.GSON_BSON.fromJson(PropertyConstants.TOTPConstans.TOTP_CONFIGS, TOTPConfig.class));
                final List<String> uuids = totpValidationRepo.getTOTPEnabledAppUuids();
                Constants.getTotpEnabledAppAgents().clear();
                Constants.getTotpEnabledAppAgents().addAll(uuids);
            } else {
                throw new RuntimeException("TOTPConfig is null / empty");
            }
        }
    }
}
