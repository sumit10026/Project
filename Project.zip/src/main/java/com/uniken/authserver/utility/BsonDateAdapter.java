package com.uniken.authserver.utility;

import java.lang.reflect.Type;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

public class BsonDateAdapter
        implements
        JsonDeserializer<Date>,
        JsonSerializer<Date> {

    @Override
    public Date deserialize(final JsonElement json, final Type typeOfT, final JsonDeserializationContext context) {

        try {
            if (json.isJsonObject() && json.getAsJsonObject().has("$date")) {
                final long date = json.getAsJsonObject().get("$date").getAsLong();
                return new Date(date);
            } else {
                final SimpleDateFormat dateFormat = new SimpleDateFormat(PropertyConstants.DATE_FORMAT);
                return dateFormat.parse(json.getAsString());
            }
        } catch (final Exception e) {
            return null;
        }
    }

    @Override
    public JsonElement serialize(final Date date, final Type type,
            final JsonSerializationContext jsonSerializationContext) {
        final SimpleDateFormat dateFormat = new SimpleDateFormat(PropertyConstants.DATE_FORMAT);
        return new JsonPrimitive(dateFormat.format(date));
    }
}
