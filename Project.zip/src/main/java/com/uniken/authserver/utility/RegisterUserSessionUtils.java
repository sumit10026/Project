package com.uniken.authserver.utility;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.uniken.domains.enums.auth.AuthType;

public class RegisterUserSessionUtils {

    private static final String REGISTER_USER_TOKEN = "register_user_token";
    private static final String REGISTER_USER_USERNAME = "register_user_username";
    private static final String REGISTER_USER_MOBILE_NUMBER = "register_user_mobile_number";
    private static final String REGISTER_USER_EMAIL = "register_user_email";
    private static final String REGISTER_USER_VALIDATED_MOBILE_NUMBER = "register_user_validated_mobile_number";
    private static final String REGISTER_USER_VALIDATED_EMAIL = "register_user_validated_email";
    private static final String REGISTER_USER_REG_AUTH_TYPES = "register_user_reg_auth_types";
    private static final String REGISTER_USER_INPUT_PARAMS = "register_user_input_params";
    private static final String REGISTER_USER_REDIRECT_URI = "register_user_redirect_uri";
    private static final String REGISTER_USER_REMEMBER_ME = "register_user_remember_me";
    private static final String REGISTER_USER_IS_ACTIVATED_USER = "register_user_is_activated_user";
    private static final String REGISTER_USER_IS_FIDO_REG_2FA = "register_user_is_fido_reg_2fa";
    private static final String REGISTER_USER_ACTIVATION_GENERATION_ATTEMPT_COUNTER = "register_user_activation_generation_attempt_counter";

    private RegisterUserSessionUtils() {
    }

    public static HttpSession getSession() {
        return ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest().getSession();
    }

    public static void setToken(final String token) {
        final HttpSession session = getSession();

        session.setAttribute(REGISTER_USER_TOKEN, token);

        // clear session values
        session.setAttribute(REGISTER_USER_USERNAME, null);
        session.setAttribute(REGISTER_USER_MOBILE_NUMBER, null);
        session.setAttribute(REGISTER_USER_EMAIL, null);
        session.setAttribute(REGISTER_USER_VALIDATED_MOBILE_NUMBER, null);
        session.setAttribute(REGISTER_USER_VALIDATED_EMAIL, null);
        session.setAttribute(REGISTER_USER_REG_AUTH_TYPES, null);
        session.setAttribute(REGISTER_USER_INPUT_PARAMS, null);
        session.setAttribute(REGISTER_USER_REDIRECT_URI, null);
        session.setAttribute(REGISTER_USER_REMEMBER_ME, null);
        session.setAttribute(REGISTER_USER_IS_ACTIVATED_USER, null);
        session.setAttribute(REGISTER_USER_IS_FIDO_REG_2FA, false);

        // Resetting Activation Generation Attempt Counters
        session.setAttribute(REGISTER_USER_ACTIVATION_GENERATION_ATTEMPT_COUNTER,
                PropertyConstants.DEFAULT_ACTIVATION_GENERATION_ATTEMPT_COUNTER);
    }

    public static String getToken() {
        return (String) getSession().getAttribute(REGISTER_USER_TOKEN);
    }

    public static void setUsername(final String username) {
        final HttpSession session = getSession();
        session.setAttribute(REGISTER_USER_USERNAME, username);
        session.setAttribute(SessionConstants.USERNAME, username);
        session.setAttribute(SessionConstants.CURRENT_USERNAME, username);
        getInputParameters().put(SessionConstants.USERNAME, username);
    }

    public static Map<String, Object> getInputParameters() {
        final HttpSession session = getSession();
        Map<String, Object> inputParameters = (Map<String, Object>) session.getAttribute(REGISTER_USER_INPUT_PARAMS);
        if (inputParameters == null) {
            inputParameters = new HashMap<>();
            session.setAttribute(REGISTER_USER_INPUT_PARAMS, inputParameters);
            session.setAttribute(SessionConstants.REQ_PARAM_MAP, inputParameters);
        }
        return inputParameters;
    }

    public static Set<AuthType> getRegisteredAuthTypes() {
        final HttpSession session = getSession();
        Set<AuthType> registeredAuthTypes = (Set<AuthType>) session.getAttribute(REGISTER_USER_REG_AUTH_TYPES);
        if (registeredAuthTypes == null) {
            registeredAuthTypes = new LinkedHashSet<>();
            session.setAttribute(REGISTER_USER_REG_AUTH_TYPES, registeredAuthTypes);
        }
        return registeredAuthTypes;
    }

    public static void registerAuthType(final AuthType authType) {
        getRegisteredAuthTypes().add(authType);
    }

    public static boolean isUserAuthenticated() {
        return getRegisteredAuthTypes().size() == 2 || (getRegisteredAuthTypes().size() == 1
                && getRegisteredAuthTypes().contains(AuthType.FIDO) && isFidoReg2fa());
    }

    public static String getUserId() {
        return (String) getSession().getAttribute(REGISTER_USER_USERNAME);
    }

    public static void setMobileNumber(final String mobileNumber) {
        getSession().setAttribute(REGISTER_USER_MOBILE_NUMBER, mobileNumber);
    }

    public static String getMobileNumber() {
        return (String) getSession().getAttribute(REGISTER_USER_MOBILE_NUMBER);
    }

    public static void setEmail(final String email) {
        getSession().setAttribute(REGISTER_USER_EMAIL, email);
    }

    public static String getEmail() {
        return (String) getSession().getAttribute(REGISTER_USER_EMAIL);
    }

    public static void setValidatedMobileNumber(final String mobileNumber) {
        getSession().setAttribute(REGISTER_USER_VALIDATED_MOBILE_NUMBER, mobileNumber);
    }

    public static String getValidatedMobileNumber() {
        return (String) getSession().getAttribute(REGISTER_USER_VALIDATED_MOBILE_NUMBER);
    }

    public static void setValidatedEmail(final String email) {
        getSession().setAttribute(REGISTER_USER_VALIDATED_EMAIL, email);
    }

    public static String getValidatedEmail() {
        return (String) getSession().getAttribute(REGISTER_USER_VALIDATED_EMAIL);
    }

    public static void setRedirectUri(final String redirectUri) {
        getSession().setAttribute(REGISTER_USER_REDIRECT_URI, redirectUri);
        getInputParameters().put(REGISTER_USER_REDIRECT_URI, redirectUri);
    }

    public static String getRedirectUri() {
        return (String) getSession().getAttribute(REGISTER_USER_REDIRECT_URI);
    }

    public static void setIsRememberMe(final boolean isRememberMe) {
        getSession().setAttribute(REGISTER_USER_REMEMBER_ME, isRememberMe);
    }

    public static boolean getIsRememberMe() {
        return getBooleanFromSessionOrDefault(REGISTER_USER_REMEMBER_ME, false);
    }

    public static void setIsActivatedUser(final boolean isActivatedUser) {
        getSession().setAttribute(REGISTER_USER_IS_ACTIVATED_USER, isActivatedUser);
    }

    public static boolean getIsActivatedUser() {
        return getBooleanFromSessionOrDefault(REGISTER_USER_IS_ACTIVATED_USER, false);
    }

    public static void setFidoReg2fa(final boolean isFidoReg2fa) {
        getSession().setAttribute(REGISTER_USER_IS_FIDO_REG_2FA, isFidoReg2fa);
    }

    public static boolean isFidoReg2fa() {
        return getBooleanFromSessionOrDefault(REGISTER_USER_IS_FIDO_REG_2FA, false);
    }

    public static boolean getBooleanFromSessionOrDefault(final String key, final boolean defaultVal) {
        return getSession().getAttribute(key) == null ? defaultVal : (boolean) getSession().getAttribute(key);
    }

    public static void setActivationGenerationAttemptCounter(final Map<String, Integer> generationAttemptCounter) {
        getSession().setAttribute(REGISTER_USER_ACTIVATION_GENERATION_ATTEMPT_COUNTER, generationAttemptCounter);
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Integer> getActivationGenerationAttemptCounter() {
        return (Map<String, Integer>) getSession().getAttribute(REGISTER_USER_ACTIVATION_GENERATION_ATTEMPT_COUNTER);
    }

}
