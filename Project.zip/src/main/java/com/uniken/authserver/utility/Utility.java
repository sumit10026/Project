package com.uniken.authserver.utility;

import java.math.BigInteger;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Enumeration;
import java.util.Random;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.codec.digest.MessageDigestAlgorithms;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.uuid.Generators;

/**
 * @author girish
 */
public class Utility {

    private static final Logger LOG = LoggerFactory.getLogger(Utility.class);

    /**
     * Method for constructing secure random number from UUID generator that
     * generates UUID using variant 1 (time+location based) and based on that
     * UUID generate random number.
     * 
     * @return
     * @throws GeneralSecurityException
     */
    public static String generateSecureRandom(final int numChars) throws GeneralSecurityException {
        int randomBits = 0;

        if (numChars <= 4)
            randomBits = 64;
        else if (numChars <= 8)
            randomBits = 128;
        else if (numChars <= 12)
            randomBits = 192;

        String random = "";
        int cnt = 0;
        while (random.length() < numChars) {
            if (cnt >= 8) {
                throw new GeneralSecurityException(
                        "Unable to generate secure random of prescribed length after 8 attempts");
            }
            final String uuid = Generators.randomBasedGenerator(new Random()).generate().toString();
            final SecureRandom secureRandom = new SecureRandom(uuid.getBytes());
            random = new BigInteger(randomBits, secureRandom).toString(32);

            random.toLowerCase();
            random = random.replace("i", "").replace("o", "").replace("1", "").replace("0", "").replace("l", "");
            random = random.substring(0, numChars);

            cnt++;
        }

        return random;
    }

    /**
     * Method for constructing secure random number from UUID generator that
     * generates UUID using variant 1 (time+location based) and based on that
     * UUID generate random number.
     * 
     * @param numChars
     *            : no of characters required in output
     * @param typeOfRandom
     *            : type of random (Alpha-Numeric, Numeric, Alpha)
     * @return
     * @throws GeneralSecurityException
     */
    public static String generateSecureRandom(final int numChars, final String typeOfRandom)
            throws GeneralSecurityException {

        int randomBits = 0;

        if (numChars <= 4)
            randomBits = 64;
        else if (numChars <= 8)
            randomBits = 128;
        else if (numChars <= 12)
            randomBits = 192;

        String random = "";
        int cnt = 0;
        while (random.length() < numChars) {
            if (cnt >= 8) {
                throw new GeneralSecurityException(
                        "Unable to generate secure random of prescribed length after 8 attempts");
            }
            final String uuid = Generators.randomBasedGenerator(new Random()).generate().toString();

            final SecureRandom secureRandom = new SecureRandom(uuid.getBytes());
            random = new BigInteger(randomBits, secureRandom).toString(32);

            random.toLowerCase();

            // Replacing i,o,1,0,l characters with empty strings, as these
            // characters create confusions.
            random = random.replace("i", "").replace("o", "").replace("1", "").replace("0", "").replace("l", "");

            if (typeOfRandom.equals("A")) {

                // Replacing digits with empty string.y
                random = random.replaceAll("\\d", "");
            } else if (typeOfRandom.equals("N")) {
                random = Long.toString(secureRandom.nextLong());
            }

            // In case of typeOfRandom is N, there are chances that it can
            // contain the -ve values, to avoid this we are reading random from
            // 1st character instead of 0th character.

            if (random.length() >= (numChars + 1)) {

                random = random.substring(1, numChars + 1);
            }

            cnt++;
        }

        return random;
    }

    /**
     * It will generate random number using TimeBasedGenerator of type 1.
     * 
     * @return A randomly generated UUID.
     */
    public static synchronized String getUUID() {

        /** Get Ethernet address of system */
        // EthernetAddress EthernetAddr = EthernetAddress.fromInterface();

        /** Generate Random Key based on time and Ethernet address of system */
        // TimeBasedGenerator uuidGenerator =
        // Generators.timeBasedGenerator(EthernetAddr);
        return Generators.randomBasedGenerator(new SecureRandom()).generate().toString();

    }

    public static byte[] SHA256Digest(final byte[] digestByte) throws NoSuchAlgorithmException {

        final MessageDigest md = MessageDigest.getInstance(MessageDigestAlgorithms.SHA_256);
        md.update(digestByte);
        return md.digest();
    }

    /**
     * This method will convert byte array into HEX string
     * 
     * @param databyte
     * @return HEX String of byte array.
     */
    public static String generateHEX(final byte[] databyte) {
        final StringBuffer dataHEX = new StringBuffer();
        for (int i = 0; i < databyte.length; i++) {
            final String hex = Integer.toHexString(0xff & databyte[i]);
            if (hex.length() == 1)
                dataHEX.append('0');
            dataHEX.append(hex);
        }
        return dataHEX.toString();
    }

    /**
     * This method will convert byte array into Base64 encoded string
     * 
     * @param databyte
     * @return Base 64 encoded String
     */
    public static String generateBase64String(final byte[] databyte) {
        return Base64.encodeBase64String(databyte);
    }

    /**
     * This method is used to fetch the current network interfaces.
     * 
     * @return
     */
    public static String fetchAndSelectCurrentNetworkInterface() {
        LOG.info("fetchAndSelectCurrentNetworkInterface() entered.");
        String currentServerIP = null;
        try {
            final Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                final NetworkInterface iface = interfaces.nextElement();
                // filters out 127.0.0.1 and inactive interfaces
                if (iface.isLoopback() || !iface.isUp())
                    continue;

                final Enumeration<InetAddress> addresses = iface.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    final InetAddress addr = addresses.nextElement();

                    // *EDIT*
                    if (addr instanceof Inet6Address)
                        continue;

                    currentServerIP = addr.getHostAddress();
                    LOG.info("fetchCurrentNetworkInterfaces() -> {}, {}", iface.getDisplayName(), currentServerIP);
                }
            }
        } catch (final Exception e) {
            LOG.error("fetchCurrentNetworkInterfaces() -> Error while fetching network interfaces");
        }
        return currentServerIP;
    }
}
