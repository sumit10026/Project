package com.uniken.authserver.utility;

import java.util.Base64;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.CollectionUtils;

import com.google.gson.JsonParseException;
import com.uniken.domains.relid.device.UserLocation;

public class InputValidationUtils {

    private static final Logger LOG = LoggerFactory.getLogger(InputValidationUtils.class);
    private static final String userNamePattern = "(?![=+@-])[a-zA-Z0-9@.+_-]{1,50}";
    public static final String responseTypePattern = "^[a-zA-Z_]*$";
    public static final String statePattern = "^[a-zA-Z0-9-]*$";
    public static final String authTypeNamePattern = "^[a-zA-Z-]*$";

    private InputValidationUtils() {
    }

    /**
     * @param userName
     * @return
     */
    public static boolean isValidUserName(final String userName) {
        boolean isValidUserName = false;
        if (StringUtils.isNotBlank(userName)) {
            isValidUserName = matchByRegexPattern(userNamePattern, userName);
        }

        return isValidUserName;
    }

    /**
     * @param state
     * @return
     */
    public static boolean isValidState(final String state) {
        boolean isValidState = false;
        if (StringUtils.isNotBlank(state)) {
            isValidState = matchByRegexPattern(statePattern, state);
        }

        return isValidState;
    }

    /**
     * @param responseType
     * @return
     */
    public static boolean isValidResponseType(final String responseType) {
        boolean isValidResponseType = false;
        if (StringUtils.isNotBlank(responseType)) {
            isValidResponseType = matchByRegexPattern(responseTypePattern, responseType);
        }

        return isValidResponseType;
    }

    /**
     * @param regex
     * @param input
     * @return
     */
    public static boolean matchByRegexPattern(final String regex, final String input) {
        boolean isMatched = false;
        if (StringUtils.isNotBlank(regex) && StringUtils.isNotBlank(input)) {
            final Pattern pattern = Pattern.compile(regex);

            final Matcher matcher = pattern.matcher(input);
            isMatched = matcher.matches();
        }

        return isMatched;
    }

    /**
     * @param rememberMe
     * @param defaultValue
     * @return
     */
    public static boolean validateRememberMeParam(final String rememberMe, final boolean defaultValue) {
        boolean isRememberMeParamValid = defaultValue;

        if (StringUtils.isNotBlank(rememberMe)) {
            isRememberMeParamValid = Boolean.parseBoolean(rememberMe);
        }

        return isRememberMeParamValid;
    }

    /**
     * @param userLocation
     * @return
     */
    public static boolean isValidUserLocation(final String userLocation) {
        boolean isValidUserLocation = false;
        try {
            if (StringUtils.isNotBlank(userLocation)) {
                final UserLocation location = Constants.GSON_BSON.fromJson(userLocation, UserLocation.class);
                if (location != null) {

                    final String latStr = location.getLatitude();
                    final String lonStr = location.getLongitude();

                    if (StringUtils.isNotBlank(latStr) && StringUtils.isNotBlank(lonStr)) {
                        final double latitude = Double.parseDouble(latStr);
                        if (latitude < -90 || latitude > 90) {
                            return isValidUserLocation;
                        }

                        final double longitude = Double.parseDouble(latStr);
                        if (longitude < -180 || longitude > 180) {
                            return isValidUserLocation;
                        }

                        isValidUserLocation = true;
                    }

                }
            } else {
                isValidUserLocation = true;
            }
        } catch (final Exception e) {
            LOG.error("isValidUserLocation() -> Invalid User Location : {}", userLocation, e);
        }
        return isValidUserLocation;
    }

    /**
     * @param webDeviceParameters
     * @return
     */
    @SuppressWarnings("rawtypes")
    public static boolean isValidWebDevParameters(final String webDeviceParameters) {
        boolean isValidWebDevParameters = false;
        try {
            if (StringUtils.isNotBlank(webDeviceParameters)) {
                final HashMap webDeviceParametersMap = Constants.GSON.fromJson(webDeviceParameters, HashMap.class);
                if (!CollectionUtils.isEmpty(webDeviceParametersMap)) {
                    isValidWebDevParameters = true;
                }
            }
        } catch (final JsonParseException e) {
            LOG.error("isValidWebDevParameters() -> Invalid JSON String of webDeviceParameters : {}",
                    webDeviceParameters, e);
        }
        return isValidWebDevParameters;
    }

    /**
     * @param base64Str
     * @return
     */
    public static boolean isValidBase64String(final String base64Str) {
        boolean isValidBase64String = false;
        try {
            if (StringUtils.isNotBlank(base64Str)) {
                final Base64.Decoder decoder = Base64.getDecoder();
                decoder.decode(base64Str);
                isValidBase64String = true;
            }
        } catch (final Exception e) {
            LOG.error("isValidBase64String() -> Invalid Base64 String : {}", base64Str, e);
        }
        return isValidBase64String;
    }

    /**
     * @param authTypeName
     * @return
     */
    public static boolean isValidAuthTypeName(final String authTypeName) {
        boolean isValidAuthTypeName = false;
        if (StringUtils.isNotBlank(authTypeName)) {
            isValidAuthTypeName = matchByRegexPattern(authTypeNamePattern, authTypeName);
        }

        return isValidAuthTypeName;
    }

    /**
     * @param session
     * @return
     */
    public static boolean isRedirectToErrorPage(final HttpSession session) {
        if (session == null) {
            return false;
        }

        return (Boolean) session.getAttribute(SessionConstants.IS_REDIRECT_TO_ERROR_PAGE) == null ? false
                : (Boolean) session.getAttribute(SessionConstants.IS_REDIRECT_TO_ERROR_PAGE);
    }

}
