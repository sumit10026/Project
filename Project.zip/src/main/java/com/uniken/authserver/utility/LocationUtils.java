package com.uniken.authserver.utility;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.InetAddress;
import java.net.UnknownHostException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.security.oauth2.common.exceptions.InvalidRequestException;

import com.maxmind.geoip2.DatabaseReader;
import com.maxmind.geoip2.exception.GeoIp2Exception;
import com.maxmind.geoip2.model.CityResponse;
import com.maxmind.geoip2.record.City;
import com.maxmind.geoip2.record.Country;

public class LocationUtils {

    private static final Logger LOG = LoggerFactory.getLogger(LocationUtils.class);
    static File dbFile = null;
    static DatabaseReader reader = null;

    private LocationUtils() {
        throw new IllegalStateException("Utility class..!");
    }

    /**
     * Validates incoming request while generating notification in AUTH Server
     * 
     * @param request
     * @param response
     * @param inputParameters
     * @throws Exception
     */
    public static String validateFileWithDBPath(String path) throws IllegalStateException {

        LOG.info("validateFileWithDBPath() -> Path: {}", path);
        final String error = "Invalid Location database path";
        try {
            if (path != null && !path.isEmpty()) {
                dbFile = new File(path);
                if (!dbFile.exists()) {
                    throw new IllegalStateException(error);
                }
                reader = new DatabaseReader.Builder(dbFile).build();
            } else {
                path = "GeoLite2-City.mmdb";
                final ClassPathResource dbResource = new ClassPathResource(path);
                reader = new DatabaseReader.Builder(dbResource.getInputStream()).build();
            }
        } catch (final FileNotFoundException e) {
            LOG.error("validateFileWithDBPath() -> FileNotFoundException: ", e);
            throw new IllegalStateException(error);
        } catch (final IOException e) {
            LOG.error("validateFileWithDBPath() -> IOException: ", e);
            throw new IllegalStateException(error);
        }

        return path;

    }

    /**
     * Validates incoming request while generating notification in AUTH Server
     * 
     * @param request
     * @param response
     * @param inputParameters
     */
    public static String retrieveLocationFromIP(final HttpServletRequest request, final HttpServletResponse response) {

        // FIXME: null
        String retrievedLocation = "";

        LOG.info("retrieveLocationFromIP() -> Entered.");

        if (request == null) {
            throw new InvalidRequestException("HttpServletRequest is null or empty");
        }

        if (response == null) {
            throw new InvalidRequestException("HttpServletResponse is null or empty");
        }

        try {

            final String ipPublicAddress = Utils.getClientIpAddress(request);

            final InetAddress ipAddress = InetAddress.getByName(ipPublicAddress);
            final CityResponse cityResponse = reader.city(ipAddress);
            final City city = cityResponse.getCity();
            final Country country = cityResponse.getCountry();

            String format = Constants.AUTH_SERVER_LOCATION_FORMAT;

            if (format.contains("__CITY_NAME__")) {
                format = format.replace("__CITY_NAME__", city.getName());
            }

            if (format.contains("__ISO_CODE__")) {
                format = format.replace("__ISO_CODE__", country.getIsoCode());
            }

            if (format.contains("__COUNTRY_NAME__")) {
                format = format.replace("__COUNTRY_NAME__", country.getName());
            }

            retrievedLocation = format;
            LOG.debug("retrieveLocationFromIP() -> retrievedLocation from path: {}", retrievedLocation);

        } catch (final GeoIp2Exception e) {
            LOG.error("retrieveLocationFromIP() -> GeoIp2Exception : ", e);
        } catch (final UnknownHostException e) {
            LOG.error("retrieveLocationFromIP() -> UnknownHostException : ", e);
        } catch (final IOException e) {
            LOG.error("retrieveLocationFromIP() -> IOException : ", e);
        }

        return retrievedLocation;

    }

}
