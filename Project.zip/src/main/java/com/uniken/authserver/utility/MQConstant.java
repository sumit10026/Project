/**
 * 
 */
package com.uniken.authserver.utility;

/**
 * Utility class to maintain RabbitMQ related constants like routing keys, MQ
 * Config, etc..
 * 
 * @author Kushal Jaiswal
 */
public class MQConstant {

    // -----------------------------------------------------//
    // ------------------ AuthServer Keys ------------------//
    // -----------------------------------------------------//

    /**
     * The listener routing key, listen the message of Notification Action of
     * REL-ID Verify Notification. <br>
     * Key value "AUTHSERVER.NOTIFICATION.ACTION.RESPONSE"
     */
    public static final String AUTHSERVER_RECEIVING_ACTION_ROUTING_KEY = "AUTHSERVER.NOTIFICATION.ACTION.RESPONSE";

    /**
     * The listener routing key, listen the message of Blaze Adapter component
     * <br>
     * Key value "BLAZEADAPTER.GENERATE.ACCESS.TOKEN.REQUEST"
     */
    public static final String BLAZEADAPTER_GENERATE_ACCESS_TOKEN_REQUEST_KEY = "BLAZEADAPTER.GENERATE.ACCESS.TOKEN.REQUEST";

    /**
     * The listener routing key, listen the message from REL-ID Verify Server
     * component <br>
     * Key value "RELIDVERIFYSERVER.GENERATE.TOKEN.REQUEST"
     */
    public static final String RELIDVERIFYSERVER_GENERATE_TOKEN_REQUEST_KEY = "RELIDVERIFYSERVER.GENERATE.TOKEN.REQUEST";

    /**
     * The listener routing key, listen the message of Blaze Adapter component
     * <br>
     * Key value "BLAZEADAPTER.REVOKE.ACCESS.TOKEN.REQUEST"
     */
    public static final String BLAZEADAPTER_REVOKE_ACCESS_TOKEN_REQUEST_KEY = "BLAZEADAPTER.REVOKE.ACCESS.TOKEN.REQUEST";

    /**
     * The listener routing key, listen the message of Blaze Adapter component
     * <br>
     * Key value "BLAZEADAPTER.GENERATE.ACCESS.TOKEN.BY.REFRESH.TOKEN.REQUEST"
     */
    public static final String BLAZEADAPTER_GENERATE_ACCESS_TOKEN__REQUEST_BY_REFRESH_TOKEN_KEY = "BLAZEADAPTER.GENERATE.ACCESS.TOKEN.BY.REFRESH.TOKEN.REQUEST";

    // -----------------------------------------------------//
    // --------------------- Verify Keys -------------------//
    // -----------------------------------------------------//

    /**
     * The routing key to generate the REL-ID Verify Notification. <br>
     * Key value "RZNOTIFICATION.SAVE.REQUEST"
     */
    public static final String VERIFY_NODE_GENERATE_NOTIFICATION_ROUTING_KEY = "RZNOTIFICATION.SAVE.REQUEST";

    /**
     * The routing key to discard the REL-ID Verify Notification. <br>
     * Key value "RZNOTIFICATION.DISCARD.REQUEST"
     */
    public static final String VERIFY_DISCARD_NOTIFICATION_ROUTING_KEY = "RZNOTIFICATION.DISCARD.REQUEST";

    private MQConstant() {
        throw new IllegalStateException("Utility class");
    }

}
