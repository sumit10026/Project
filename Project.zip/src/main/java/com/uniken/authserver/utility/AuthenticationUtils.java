package com.uniken.authserver.utility;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.exceptions.InvalidRequestException;

import com.google.gson.JsonParseException;
import com.uniken.authserver.domains.ValidateUserRequest;
import com.uniken.authserver.domains.WebBrowserParameters;
import com.uniken.authserver.exception.ValidateUserException;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;

public class AuthenticationUtils {

    private static final Logger LOG = LoggerFactory.getLogger(AuthenticationUtils.class);

    @Autowired
    WebDevMasterService webDevMasterService;

    private AuthenticationUtils() {
        throw new IllegalStateException("Utility class..!");
    }

    /**
     * Validates incoming request while generating notification in AUTH Server
     * 
     * @param request
     * @param response
     * @param inputParameters
     */
    public static void validateRequest(final HttpServletRequest request, final HttpServletResponse response,
            final ValidateUserRequest validateUserRequest) {

        LOG.info("validateRequest() -> Entered.");

        if (request == null) {
            throw new InvalidRequestException("HttpServletRequest is null or empty");
        }

        if (response == null) {
            throw new InvalidRequestException("HttpServletResponse is null or empty");
        }

        if (validateUserRequest == null) {
            throw new InvalidRequestException("InputParameters are null or empty");
        }

        final String userName = validateUserRequest.getUserName();
        final String webDeviceParameters = validateUserRequest.getWebDeviceParameters();
        // final String webDeviceFingerprint =
        // validateUserRequest.getWebDeviceParameterChecksum();
        final String authType = validateUserRequest.getAuthType();
        final String authValue = validateUserRequest.getAuthValue();
        final String clientId = (String) request.getSession().getAttribute(EnterpriseInfo.CLIENT_ID);

        // checking for userName
        if (Utils.isNullOrEmpty(userName)) {
            throw new IllegalArgumentException("username is null or empty");
        }

        if (!InputValidationUtils.isValidUserName(userName)) {
            throw new ValidateUserException("Invalid Characters in Username");
        }

        // checking for webDeviceParameters
        if (Utils.isNullOrEmpty(webDeviceParameters)) {
            throw new IllegalArgumentException("webDeviceParameters are null or empty");
        }

        // Checking for ClientId
        if (Utils.isNullOrEmpty(clientId)) {
            throw new IllegalArgumentException("clientId is null or empty");
        }

        // checking for webDeviceFingerprint
        // if (Utils.isNullOrEmpty(webDeviceFingerprint)) {
        // LOG.error("validateRequest() -> webDeviceFingerprint is null or
        // empty");
        // throw new IllegalArgumentException("webDeviceFingerprint is null or
        // empty");
        // }

        if (StringUtils.isNotBlank(authType)) {
            if (!AuthType.isValidElement(authType)) {
                throw new IllegalArgumentException("Auth Type is not valid");
            }

            if (!isAuthTypeAllowed(authType)) {
                EventLogger.log(EventId.RelidAuthServer.AUTH_FACTOR_DISABLED, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), validateUserRequest.getUserName(),
                        AuthenticationUtils.getUserAgent(request),
                        "System has disabled the " + authType + " - Auth Factor for performing authentication.");
                throw new IllegalArgumentException(
                        "System has disabled the " + authType + " - Auth Factor for performing authentication.");
            }

            if (!authType.equals(AuthType.RELID_VERIFY.getName()) && StringUtils.isBlank(authValue)) {
                throw new IllegalArgumentException("Auth Value is not valid");
            }
        }

        try {
            Constants.GSON.fromJson(webDeviceParameters, HashMap.class);
        } catch (final JsonParseException e) {
            throw new IllegalArgumentException("web device Parameters are invalid");
        }

    }

    public static boolean isAuthTypeAllowed(final String authType) {
        boolean isAllowed = false;
        final AuthType type = AuthType.getAuthTypeByName(authType);

        switch (type) {
        case TOTP:
            isAllowed = PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isRelidTotp();
            break;

        case RELID_VERIFY:
            isAllowed = PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isRelidVerify();
            break;

        case FIDO:
            // FIXME : Handle separately in Milestone 2
            isAllowed = PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isFidoPlatform()
                    || PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isFidoRoaming();
            break;

        case SMSOTP:
            isAllowed = PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isSmsOtp();
            break;

        case EMAILOTP:
            isAllowed = PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isEmailOtp();
            break;

        case SECURE_COOKIE:
            isAllowed = PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isRememberMe();
            break;

        case PASS:
            isAllowed = PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isPassword();
            break;

        default:
            throw new IllegalArgumentException("Invalid Auth Type Provided");
        }

        return isAllowed;
    }

    public static int getNextBlockingInterval(final int currentBlockInterval) {
        int nextBlockingInterval = PropertyConstants.DEFAULT_COOLING_PERIOD_LIST
                .get(Constants.COOLING_PERIOD_FIRST_INTERVAL);
        final int currentBlockIntervalIndex = PropertyConstants.DEFAULT_COOLING_PERIOD_LIST
                .indexOf(currentBlockInterval);

        if (currentBlockIntervalIndex < PropertyConstants.DEFAULT_COOLING_PERIOD_LIST.size() - 1) {
            nextBlockingInterval = PropertyConstants.DEFAULT_COOLING_PERIOD_LIST.get(currentBlockIntervalIndex + 1);
        }

        return nextBlockingInterval;
    }

    public static String getRequestorId(final HttpServletRequest request) {
        return (String) request.getAttribute(Constants.REQUESTOR_ID);
    }

    public static String getUsername(final HttpServletRequest request) {
        return (String) request.getSession().getAttribute(SessionConstants.CURRENT_USERNAME);
    }

    public static String getUserAgent(final HttpServletRequest request) {
        return (String) request.getSession().getAttribute(SessionConstants.USER_AGENT);
    }

    public static void putUserAgentInSession(final String webDeviceParameters, final HttpServletRequest request) {
        String userAgent = "USER_AGENT_NA";
        if (StringUtils.isNotBlank(webDeviceParameters)) {
            userAgent = (String) Constants.GSON.fromJson(webDeviceParameters, HashMap.class)
                    .get(WebBrowserParameters.USERAGENT_STR.getBrowserParameterKey());
        }
        request.getSession().setAttribute(SessionConstants.USER_AGENT, userAgent);
    }

    public static void validateClientId(final HttpServletRequest request) {

        try {
            ESAPI.validator().getValidInput("clientId_key", EnterpriseInfo.CLIENT_ID, "HTTPHeaderName",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            ESAPI.validator().getValidInput("clientid_value",
                    (String) request.getSession().getAttribute(EnterpriseInfo.CLIENT_ID), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
        } catch (final Exception e) {
            throw new IllegalArgumentException("clientId is null or empty : " + e.getMessage());
        }
    }

}
