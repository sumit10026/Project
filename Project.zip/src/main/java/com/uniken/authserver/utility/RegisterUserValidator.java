package com.uniken.authserver.utility;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RegisterUserValidator {

    private static final Logger LOG = LoggerFactory.getLogger(RegisterUserValidator.class);

    private RegisterUserValidator() {
    }

    /**
     * Validate Email Id.
     *
     * @param emailId
     *            the email id
     * @param errorMsgList
     *            the error msg list
     * @return true, if successful
     */
    public static boolean validateEmailID(final String emailId, final List<String> errorMsgList) {

        // verify if emailId is not empty
        if ((null != emailId) && (!emailId.trim().isEmpty())) {

            // verify if emailId is valid
            if (!emailId.trim().matches(PropertyConstants.GmConstants.EMAIL_ID_REGEX)) {
                LOG.error("validateEmailID() -> Invalid Email Id.");
                errorMsgList.add("Invalid Email Id.");
                return false;
            }
        }
        return true;
    }

    /**
     * Validate mobile number of user.
     *
     * @param mobileNumber
     *            the mobile number
     * @param errorMsgList
     *            the error msg list
     * @return true, if successful
     */
    public static boolean validateMobileNumber(final String mobileNumber, final List<String> errorMsgList) {

        // verify if mobile number is not empty
        if ((null != mobileNumber) && (!mobileNumber.trim().isEmpty())) {

            // verify if mobile number is valid
            if (!mobileNumber.trim().matches(PropertyConstants.GmConstants.MOBILE_NUM_REGEX)) {
                if (LOG.isDebugEnabled()) {
                    LOG.debug("validateMobileNumber() -> Invalid mobile Number. ");
                }

                errorMsgList.add("Invalid mobile Number.");
                return false;
            }
        }
        return true;
    }

}
