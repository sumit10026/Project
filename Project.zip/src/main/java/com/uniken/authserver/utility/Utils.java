/**
 * 
 */
package com.uniken.authserver.utility;

import java.io.IOException;
import java.lang.reflect.Type;
import java.security.KeyPair;
import java.security.SecureRandom;
import java.security.interfaces.RSAPrivateKey;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Optional;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.bson.Document;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpCookie;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseCookie;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.jwt.crypto.sign.RsaSigner;
import org.springframework.security.jwt.crypto.sign.Signer;
import org.springframework.security.oauth2.common.ExpiringOAuth2RefreshToken;
import org.springframework.security.oauth2.common.OAuth2RefreshToken;
import org.springframework.security.oauth2.common.exceptions.InvalidRequestException;
import org.springframework.security.oauth2.provider.token.store.KeyStoreKeyFactory;
import org.springframework.util.Base64Utils;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.uuid.Generators;
import com.google.gson.JsonParseException;
import com.google.gson.reflect.TypeToken;
import com.uniken.authserver.domains.PassPolicy;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.auth.JWTConfig;
import com.uniken.domains.auth.fido.FIDO2RegisteredAuthenticationModule;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.encdecutils.PropertiesEncryptDecrypt;

import nl.basjes.parse.useragent.UserAgent.ImmutableUserAgent;
import nl.basjes.parse.useragent.UserAgentAnalyzer;

/**
 * @author Kushal Jaiswal
 */
public class Utils {

    private static final Logger LOG = LoggerFactory.getLogger(Utils.class);
    private static UserAgentAnalyzer userAgentAnalyzer = null;

    public static boolean isExpired(final OAuth2RefreshToken refreshToken) {
        if (refreshToken instanceof ExpiringOAuth2RefreshToken) {
            final ExpiringOAuth2RefreshToken expiringToken = (ExpiringOAuth2RefreshToken) refreshToken;
            return expiringToken.getExpiration() == null
                    || System.currentTimeMillis() > expiringToken.getExpiration().getTime();
        }
        return false;
    }

    private Utils() {
        throw new IllegalStateException("Utility class..!");
    }

    /**
     * Generating requestorId and putting it in MDC map to get logged in every
     * log statement and store it in request object to make it accessible
     * throughout the request
     * 
     * @param obj
     *            : instance of the caller, will be used in random generation.
     * @param request
     *            : request object to store the generated random.
     * @return : generated random
     **/
    public static void generateRequestorId(final Object obj, final HttpServletRequest request) {

        if (request.getAttribute(Constants.REQUESTOR_ID) == null) {
            final String requestorId = generateSecureRandom(obj);

            MDC.put(Constants.REQUESTOR_ID, requestorId);
            request.setAttribute(Constants.REQUESTOR_ID, requestorId);

        }
    }

    /**
     * Generating secure random.
     * 
     * @param obj
     *            : instance of the caller, will be used in random generation.
     * @return : generated random
     */
    public static String generateSecureRandom(final Object obj) {
        return String.valueOf(obj.hashCode() + new SecureRandom().nextInt());
    }

    /**
     * Convert list of mongo documents to list of given type.
     *
     * @param <T>
     *            the generic type
     * @param fromList
     *            the from list
     * @param returnListClass
     *            the return list class
     * @return the list
     */
    public static <T> List<T> convertListOfMongoDocumentsToList(final List<Document> fromList,
            final Class<T> returnListClass) {
        return Constants.GSON.fromJson(Constants.GSON.toJson(fromList),
                TypeToken.getParameterized(ArrayList.class, returnListClass).getType()

        );
    }

    /**
     * Check given argument is null or not
     * 
     * @param argument
     *            -
     * @return - return true if argument is null or false
     */
    public static boolean isNull(final Object argument) {
        return null == argument;
    }

    /**
     * Check given string argument is empty or not. This method trim the
     * argument before check.
     * 
     * @param argument
     *            -
     * @return - return true if argument is empty or false
     */
    public static boolean isEmpty(final String argument) {
        boolean ret = false;
        try {
            ESAPI.validator().getValidInput("isempty", argument, "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            ret = true;
        } catch (final Exception e) {
            LOG.error("Input value :" + argument + " is null / empty", e);
        }
        return ret;
    }

    public static boolean isNullOrEmpty(final String validateString) {
        boolean ret = false;
        if (validateString == null || validateString.trim().isEmpty()) {
            ret = true;
        }
        return ret;
    }

    /**
     * Generates UUID using secure random.
     * 
     * @return UUID
     */
    public static String secureRandomUUIDGenerator() {
        return Generators.randomBasedGenerator(new SecureRandom()).generate().toString();
    }

    /**
     * Fetch and validates username, userlocation, browserDfp and
     * browserDFPChecksum from request object
     * 
     * @param request
     * @return
     */
    @SuppressWarnings("unchecked")
    public static Map<String, Object> fetchAndValidateRequestInputParams(final HttpServletRequest request) {
        final Map<String, Object> inputParameters = new HashMap<>();
        try {
            ESAPI.validator().getValidInput("username_key", Constants.REQ_PARAM_USERNAME, "HTTPParameterName",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            final String username = ESAPI.validator().getValidInput("username_value",
                    request.getParameter(Constants.REQ_PARAM_USERNAME), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            ESAPI.validator().getValidInput("clientId_key", EnterpriseInfo.CLIENT_ID, "HTTPParameterName",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            final String clientId = ESAPI.validator().getValidInput("clientId_value",
                    (String) request.getSession().getAttribute(EnterpriseInfo.CLIENT_ID), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            ESAPI.validator().getValidInput("scope_key", EnterpriseInfo.SCOPE, "HTTPParameterName",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            final String scopeStr = ESAPI.validator().getValidInput("scope_value",
                    (String) request.getSession().getAttribute(EnterpriseInfo.SCOPE), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            ESAPI.validator().getValidInput("user_location_key", WebDevMaster.USER_LOCATION_STR, "HTTPParameterName",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            final String userLocation = ESAPI.validator().getValidInput("user_location_value",
                    request.getParameter(WebDevMaster.USER_LOCATION_STR), "USERLOCATION",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, true);
            ESAPI.validator().getValidInput("browser_dfp_key", WebDevMaster.WEB_DEV_PARAMETERS_STR, "HTTPParameterName",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            final String browserDFP = ESAPI.validator().getValidInput("browser_dfp_value",
                    request.getParameter(WebDevMaster.WEB_DEV_PARAMETERS_STR), "BROWSERDFP",
                    Constants.MAX_SIZE_WEB_DFP_PARAMETER, false);

            ESAPI.validator().getValidInput("remember_me_key", Constants.REQ_PARAM_REMEMBER_ME, "HTTPCookieName",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            final boolean rememberMe = Boolean.parseBoolean(ESAPI.validator().getValidInput("remember_me_value",
                    request.getParameter(Constants.REQ_PARAM_REMEMBER_ME), "HTTPCookieValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false));

            final Set<String> lastLoginMethod = (Set<String>) request.getSession()
                    .getAttribute(SessionConstants.VALIDATED_AUTH_TYPES);

            inputParameters.put(Constants.REQ_PARAM_USERNAME, username);
            inputParameters.put(WebDevMaster.USER_LOCATION_STR, userLocation);
            inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_STR, browserDFP);
            // inputParameters.put(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR,
            // browserDFPChecksum);
            inputParameters.put(EnterpriseInfo.CLIENT_ID, clientId);
            inputParameters.put(EnterpriseInfo.SCOPE, scopeStr);
            inputParameters.put(Constants.REQ_PARAM_REMEMBER_ME, rememberMe);
            inputParameters.put(Constants.REQ_PARAM_LAST_LOGIN_METHOD, lastLoginMethod);

            return inputParameters;
        } catch (final Exception e) {
            throw new IllegalArgumentException("unauthorized access" + e.getMessage());
        }

    }

    public static String convertObjectToJson(final Object object) throws JsonProcessingException {
        if (object == null) {
            return null;
        }
        final ObjectMapper mapper = new ObjectMapper();
        return mapper.writeValueAsString(object);
    }

    /**
     * Validates incoming request while generating notification in AUTH Server
     * 
     * @param request
     * @param response
     * @param inputParameters
     */
    public static void validateRequest(final HttpServletRequest request, final HttpServletResponse response,
            final Map<String, Object> inputParameters) {

        if (request == null) {
            throw new InvalidRequestException("HttpServletRequest is null or empty");
        }

        if (response == null) {
            throw new InvalidRequestException("HttpServletResponse is null or empty");
        }

        if (inputParameters == null || inputParameters.size() == 0) {
            throw new InvalidRequestException("InputParameters are null or empty");
        }

        final String clientId = (String) inputParameters.get(EnterpriseInfo.CLIENT_ID);
        final String userName = (String) inputParameters.get(Constants.REQ_PARAM_USERNAME);
        final String scopeStr = (String) inputParameters.get(EnterpriseInfo.SCOPE);
        final String webDeviceParameters = (String) inputParameters.get(WebDevMaster.WEB_DEV_PARAMETERS_STR);
        // final String webDeviceFingerprint = (String)
        // inputParameters.get(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR);

        // Validating client Id
        if (Utils.isNullOrEmpty(clientId)) {
            throw new InvalidRequestException("clientId is null or empty");
        }

        // Validating Scope
        if (Utils.isNullOrEmpty(scopeStr)) {
            throw new InvalidRequestException("scope is null or empty");
        }

        // checking for userName
        if (Utils.isNullOrEmpty(userName)) {
            throw new IllegalArgumentException("username is null or empty");
        }

        // checking for webDeviceParameters
        if (Utils.isNullOrEmpty(webDeviceParameters)) {
            throw new IllegalArgumentException("webDeviceParameters are null or empty");
        }

        // checking for webDeviceFingerprint
        // if (Utils.isNullOrEmpty(webDeviceFingerprint)) {
        // LOG.error("validateRequest() -> webDeviceFingerprint is null or
        // empty");
        // throw new IllegalArgumentException("webDeviceFingerprint is null or
        // empty");
        // }

        try {
            Constants.GSON.fromJson(webDeviceParameters, HashMap.class);
        } catch (final JsonParseException e) {
            throw new IllegalArgumentException("web device Parameters are invalid");
        }

    }

    /**
     * This function validates the incoming parameter.
     * 
     * @param correlationID
     * @param browserDFPChecksum
     * @param browserDFP
     */
    public static void validateRequest(final String correlationID, final String browserDFPChecksum,
            final String browserDFP) {

        if (Utils.isNullOrEmpty(correlationID)) {
            throw new IllegalArgumentException("CorrelationID is null or empty");
        }

        // if (Utils.isNullOrEmpty(browserDFPChecksum)) {
        // LOG.error("validateRequest()() : browserDFPChecksum is null or
        // empty");
        // throw new IllegalArgumentException("browserDFPChecksum is null or
        // empty");
        // }

        if (Utils.isNullOrEmpty(browserDFP)) {
            throw new IllegalArgumentException("browserDFP is null or empty");
        }

        final Type hashType = new TypeToken<HashMap<String, Object>>() {
        }.getType();

        try {
            Constants.GSON.fromJson(browserDFP, hashType);
        } catch (final JsonParseException e) {
            throw new IllegalArgumentException("browser DFP is invalid");
        }
    }

    /**
     * This method will take OAuth authHeader as parameter and returns the OAuth
     * Authentication method type.
     * 
     * @param authHeader
     *            : Authorization request header
     * @return : access token and type of
     */
    public static String[] getAuthParams(final String authHeader) {
        validateAuthHeader(authHeader);
        return authHeader.split(" ", 2);
    }

    /**
     * Validate auth header.
     *
     * @param authHeader
     *            the auth header
     */
    public static void validateAuthHeader(final String authHeader) {

        if (!isNullOrEmpty(authHeader)) {
            final String[] authorizationArr = authHeader.split(" ", 2);
            if (authorizationArr.length != 2) {
                throw new InvalidRequestException("invalid auth header provided in request");
            }
        } else {
            throw new InvalidRequestException("null or empty auth header. ");
        }
    }

    /**
     * Gets the signer.
     *
     * @param jwtConfig
     *            the jwt config
     * @return the signer
     */
    public static Signer getSigner(final JWTConfig jwtConfig) {
        final Resource certificate = new ByteArrayResource(Base64Utils.decodeFromString(jwtConfig.getRsBlob()));

        final KeyStoreKeyFactory keyStoreKeyFactory = new KeyStoreKeyFactory(certificate,
                PropertiesEncryptDecrypt.decryptWithAES(jwtConfig.getKeystorePassword()).toCharArray());

        final KeyPair keyPair = keyStoreKeyFactory.getKeyPair(jwtConfig.getCertificateAlias());
        return new RsaSigner((RSAPrivateKey) keyPair.getPrivate());
    }

    /**
     * Splits the given string around matches of the given regular expression
     * and returns an array of strings (trimmed) computed.
     * 
     * @param string
     *            the string to be split
     * @param regex
     *            the regular expression
     * @return an array of strings (trimmed) computed
     */
    public static final String[] split(final String string, final String regex) {
        final String[] splitArray = string.split(regex);
        final String[] array = new String[splitArray.length];

        int count = 0;
        for (final String str : splitArray) {
            array[count++] = str.trim();
        }

        return array;
    }

    /**
     * Gets the Username from the Spring Security Context or from the Request
     * Context Holder.
     * 
     * @return the Username.
     */
    public static String getUsernameFromSecurityContextOrRequestContext() {
        LOG.debug("getUsernameFromSecurityContextOrRequestContext() -> Entered");

        String username = null;
        final HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest();

        username = request.getParameter(Constants.REQ_PARAM_USERNAME);

        if (username == null) {
            final String usernameFromSession = (String) request.getSession()
                    .getAttribute(SessionConstants.CURRENT_USERNAME);

            LOG.debug("getUsernameFromSecurityContextOrRequestContext() -> Username from session: {}",
                    usernameFromSession);
            username = usernameFromSession;
        }

        if (username == null) {

            final Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
            if (principal instanceof UserDetails) {
                username = ((UserDetails) principal).getUsername();
            } else {
                username = principal.toString();
            }
        }
        return username;
    }

    /**
     * Gets the UserAgent from the Spring Security Context or from the Request
     * Context Holder.
     * 
     * @return the UserAgent.
     */
    public static String getUserAgentfromRequestContext() {
        LOG.debug("getUsernameFromSecurityContextOrRequestContext() -> Entered");

        String userAgent = "USER_AGENT_NA";

        final HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest();

        userAgent = (String) request.getSession().getAttribute(SessionConstants.USER_AGENT);

        return userAgent;
    }

    /**
     * Gets the secureCookie from the Spring Security Context or from the
     * Request Context Holder.
     * 
     * @return the UserAgent.
     */
    public static Cookie getSecureCookieFromRequestContext() {
        LOG.debug("getUsernameFromSecurityContextOrRequestContext() -> Entered");

        Cookie secureCookie = null;

        final HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest();

        final Optional<Cookie> optionalRequestCookie = Arrays.stream(request.getCookies())
                .filter(ck -> StringUtils.equals(Constants.SECURE_COOKIE_NAME, ck.getName())).findFirst();

        secureCookie = optionalRequestCookie.orElse(null);

        return secureCookie;
    }

    public static HttpServletRequest getHttpServletRequestFromRequestContext() {
        return ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes()).getRequest();
    }

    /**
     * Gets if secureCookie is set or not from the Spring Security Context or
     * from the Request Context Holder.
     * 
     * @return the UserAgent.
     */
    public static boolean getIsSecureCookieSetFromRequestContext() {
        LOG.debug("getIsSecureCookieSetFromRequestContext() -> Entered");

        boolean isSecureCookieSet = false;

        final HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest();

        isSecureCookieSet = Stream.of(request.getCookies()).map(Cookie::getName)
                .anyMatch(name -> name.equals(Constants.SECURE_COOKIE_NAME));

        LOG.debug("getIsSecureCookieSetFromRequestContext() -> isSecureCookieSet :{}", isSecureCookieSet);

        return isSecureCookieSet;
    }

    public static void setFidoRegistrationRecordInSession(final FIDO2RegisteredAuthenticationModule regModule) {
        LOG.info("setFidoRegistrationRecordInSession() entered");
        final HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest();
        final HttpSession session = request.getSession();
        if (session.getAttribute("FIDO2_REG_RECORDS") == null) {
            session.setAttribute("FIDO2_REG_RECORDS", regModule);
        }
        LOG.info("setFidoRegistrationRecordInSession() exiting");
    }

    public static FIDO2RegisteredAuthenticationModule getFidoRegistrationRecordInSession() {
        LOG.info("getFidoRegistrationRecordInSession() entered");
        final HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest();
        final HttpSession session = request.getSession();
        return (FIDO2RegisteredAuthenticationModule) session.getAttribute("FIDO2_REG_RECORDS");
    }

    public static void removeFidoRegistrationRecordInSession() {
        LOG.info("getFidoRegistrationRecordInSession() entered");
        final HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest();
        final HttpSession session = request.getSession();
        session.removeAttribute("FIDO2_REG_RECORDS");
        LOG.info("getFidoRegistrationRecordInSession() exiting");

    }

    private static final String[] HEADERS_TO_TRY = { "X-Forwarded-For", "Proxy-Client-IP", "WL-Proxy-Client-IP",
            "HTTP_X_FORWARDED_FOR", "HTTP_X_FORWARDED", "HTTP_X_CLUSTER_CLIENT_IP", "HTTP_CLIENT_IP",
            "HTTP_FORWARDED_FOR", "HTTP_FORWARDED", "HTTP_VIA", "REMOTE_ADDR" };

    /**
     * This method retrives the IP address from request
     * 
     * @param request
     * @return
     */
    public final static String getClientIpAddress(final HttpServletRequest request) {
        for (final String header : HEADERS_TO_TRY) {
            final String ip = request.getHeader(header);
            if (ip != null && ip.length() != 0 && !"unknown".equalsIgnoreCase(ip)) {
                return ip;
            }
        }
        return request.getRemoteAddr();
    }

    /**
     * This method maps stringified JSON to the given output class.
     * 
     * @param data
     *            String data which need to map
     * @param valueType
     *            Class type which is output for given data
     * @return Object with mapped data
     **/
    public static final <T> T mapStringToObject(final String data, final Class<T> valueType) {
        T t = null;
        try {
            t = Constants.JACKSON_OBJECT_MAPPER.readValue(data, valueType);
        } catch (final Exception e) {
            LOG.debug("Jackson Parsing failed for type : {}", valueType);
        }
        return t;
    }

    /**
     * Write unauthorized response.
     *
     * @param request
     *            the request
     * @param response
     *            the response
     * @throws IOException
     *             Signals that an I/O exception has occurred.
     */
    public static void writeUnauthorizedResponse(final HttpServletRequest request, final HttpServletResponse response)
            throws IOException {

        final Map<String, Object> error = new LinkedHashMap<>();
        error.put("timestamp", new Date());
        error.put("status", HttpStatus.UNAUTHORIZED.value());
        error.put("error", HttpStatus.UNAUTHORIZED.getReasonPhrase());
        error.put("message", HttpStatus.UNAUTHORIZED.getReasonPhrase());
        error.put("path", request.getRequestURI());

        response.setStatus(HttpStatus.UNAUTHORIZED.value());
        response.setContentType(MediaType.APPLICATION_JSON_VALUE);
        Constants.JACKSON_OBJECT_MAPPER.writeValue(response.getOutputStream(), error);
    }

    public static List<Integer> convertCommaSeparatedStringToIntList(final String elements) {
        final List<Integer> convertedList = new ArrayList<>();
        Arrays.stream(StringUtils.split(elements, ",")).forEach(e -> {
            if (StringUtils.isNotBlank(e)) {
                convertedList.add(Integer.parseInt(e));
            }
        });
        Collections.sort(convertedList);
        return convertedList;
    }

    /**
     * @param cookie
     * @return
     */
    public static String convertCookieToStringFormat(final Cookie cookie) {
        final String domain = cookie.getDomain();
        final String name = cookie.getName();
        final String value = cookie.getValue();
        final String path = cookie.getPath();
        final int maxAge = cookie.getMaxAge();
        final boolean secure = cookie.getSecure();

        final HttpCookie httpCookie = ResponseCookie.from(name, value).path(path).domain(domain).httpOnly(secure)
                .maxAge(maxAge).build();

        return httpCookie.toString();
    }

    public static String getOSFromUserAgent(final String userAgent) {
        if (StringUtils.isBlank(userAgent)) {
            return "";
        }

        if (userAgentAnalyzer == null) {
            userAgentAnalyzer = UserAgentAnalyzer.newBuilder().withField(Constants.OPERATING_SYSTEM_NAME_STR).build();
        }

        final ImmutableUserAgent agent = userAgentAnalyzer.parse(userAgent);
        return agent.getValue(Constants.OPERATING_SYSTEM_NAME_STR).trim();
    }

    public static Map<String, Object> getPlatformSpecificMessages(final String userAgent,
            final Map<String, Object> pageMessages) {

        @SuppressWarnings("unchecked")
        final Map<String, Map<String, String>> platformSpecificMessages = (Map<String, Map<String, String>>) pageMessages
                .get(Constants.PLATFORM_SPECIFIC_MSGS_STR);

        if (StringUtils.isNotBlank(userAgent) && !CollectionUtils.isEmpty(platformSpecificMessages)) {
            final String osName = Utils.getOSFromUserAgent(userAgent);

            if (StringUtils.isNotBlank(osName)) {
                final Optional<Entry<String, Map<String, String>>> optionalEntry = platformSpecificMessages.entrySet()
                        .stream().filter(e -> e.getKey().contains(osName)).findFirst();
                if (optionalEntry.isPresent()) {
                    pageMessages.putAll(optionalEntry.get().getValue());
                }
            }
        }

        pageMessages.remove(Constants.PLATFORM_SPECIFIC_MSGS_STR);

        return pageMessages;
    }

    public static PassPolicy getPassPolicy(final String passPolicy) {
        final PassPolicy policy = mapStringToObject(passPolicy, PassPolicy.class);
        if (policy != null) {
            policy.setMinLcPattern(Pattern.compile(String.format("[a-z]{%d}", policy.getMinLc())));
            policy.setMinUcPattern(Pattern.compile(String.format("[A-Z]{%d}", policy.getMinUc())));
            policy.setMinScPattern(Pattern.compile(String.format("[^a-zA-Z0-9]{%d}", policy.getMinSc())));
            policy.setMinDgPattern(Pattern.compile(String.format("\\d{%d}", policy.getMinDg())));
            policy.setRepPattern(Pattern.compile(String.format("(.)\\1{%d}", policy.getRepetition())));
        }

        return policy;
    }

    public static boolean validatePassword(final String pass, final String username) {
        final PassPolicy passPolicy = Constants.PASS_POLICY;

        return passPolicy == null || (pass.length() >= passPolicy.getMinL() && pass.length() <= passPolicy.getMaxL()
                && passPolicy.getMinLcPattern().matcher(pass).find()
                && passPolicy.getMinUcPattern().matcher(pass).find()
                && passPolicy.getMinDgPattern().matcher(pass).find()
                && passPolicy.getMinScPattern().matcher(pass).find() && !passPolicy.getRepPattern().matcher(pass).find()
                && (!passPolicy.isUserIDcheck() || !pass.contains(username)));
    }

}
