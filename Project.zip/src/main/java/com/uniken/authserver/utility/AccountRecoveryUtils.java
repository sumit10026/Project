package com.uniken.authserver.utility;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.common.exceptions.InvalidRequestException;

import com.uniken.authserver.domains.AccountRecoveryUserRequest;
import com.uniken.authserver.exception.ValidateUserException;
import com.uniken.domains.enums.auth.IDVMethod;

public class AccountRecoveryUtils {

    private static final Logger LOG = LoggerFactory.getLogger(AccountRecoveryUtils.class);

    private AccountRecoveryUtils() {
        throw new IllegalStateException("Utility class");
    }

    public static void validateRequest(final HttpServletRequest request, final HttpServletResponse response,
            final AccountRecoveryUserRequest accountRecoveryUserRequest) {

        LOG.info("validateRequest() -> Entered.");

        if (request == null) {
            throw new InvalidRequestException("HttpServletRequest is null or empty");
        }

        if (response == null) {
            throw new InvalidRequestException("HttpServletResponse is null or empty");
        }

        if (accountRecoveryUserRequest == null) {
            throw new InvalidRequestException("InputParameters are null or empty");
        }

        // checking for userName
        if (Utils.isNullOrEmpty(accountRecoveryUserRequest.getUserName())) {
            throw new IllegalArgumentException("Username is null or empty");
        }

        if (!InputValidationUtils.isValidUserName(accountRecoveryUserRequest.getUserName())) {
            throw new ValidateUserException("Invalid Characters in Username");
        }

        if (Utils.isNullOrEmpty(accountRecoveryUserRequest.getIdvMethod())
                || IDVMethod.isValidElement(accountRecoveryUserRequest.getIdvMethod())) {
            throw new IllegalArgumentException("Invalid IDV Method in request");
        }

        if (StringUtils.equals(accountRecoveryUserRequest.getIdvMethod(), IDVMethod.SECURITY_QA.getName())
                && Utils.isNullOrEmpty(accountRecoveryUserRequest.getSecurityQuestion())) {
            throw new IllegalArgumentException("Invalid IDV Method in request");
        }

        if (Utils.isNullOrEmpty(accountRecoveryUserRequest.getIdvValue())) {
            throw new IllegalArgumentException("IDV value is null or empty");
        }

    }

    private String encryptTokenDetails(final String plainTokenDetails) {
        try {
            final byte byteKey[] = Utility.SHA256Digest(Constants.SECURE_COOKIE_KEY.getBytes());
            final Cipher cipher = Cipher.getInstance("AES/CFB/PKCS5Padding");
            final SecretKeySpec secret = new SecretKeySpec(byteKey, "AES");
            final IvParameterSpec ivBytes = new IvParameterSpec(Constants.SECURE_COOKIE_SALT.getBytes());
            cipher.init(Cipher.ENCRYPT_MODE, secret, ivBytes);
            final byte[] encryptedTextBytes = cipher.doFinal(plainTokenDetails.getBytes());
            return Base64.encodeBase64String(encryptedTextBytes);
        } catch (final Exception e) {
            LOG.error("encryptTokenDetails() : Failed to encrypt the cipher text!", e);
        }
        return null;
    }

    public String decryptTokenDetails(final String encryptedTokenDetails) {
        try {
            final byte byteKey[] = Utility.SHA256Digest(Constants.SECURE_COOKIE_KEY.getBytes());
            final Cipher cipher = Cipher.getInstance("AES/CFB/PKCS5Padding");
            final SecretKeySpec secret = new SecretKeySpec(byteKey, "AES");
            final IvParameterSpec ivBytes = new IvParameterSpec(Constants.SECURE_COOKIE_SALT.getBytes());
            cipher.init(Cipher.DECRYPT_MODE, secret, ivBytes);
            final byte[] original = Base64.decodeBase64(encryptedTokenDetails.getBytes());
            final byte[] originalValue = cipher.doFinal(original);
            return new String(originalValue);
        } catch (final Exception e) {
            LOG.error("decryptTokenDetails() : Failed to decrypt the cipher text!", e);
        }
        return null;
    }

}
