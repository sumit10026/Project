package com.uniken.authserver.utility;

public interface UserRegistrationConstants {

    String WEB_ONLY_USER_ACTIVATION_BASE_URI = "/register";

    String TOKEN = "token";
    String MOBILE_NUMBER = "mobile_number";
    String EMAIL = "email";

}
