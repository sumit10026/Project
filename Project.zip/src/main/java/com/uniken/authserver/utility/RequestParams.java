package com.uniken.authserver.utility;

/**
 * Holds request parameter names for different grant types.
 */
public interface RequestParams {

    /**
     * "password" grant Parameters.
     */
    enum PasswordGrant {
        ;
        public static final String USERNAME = "username";
        public static final String SESSION_ID = "session_id";
        public static final String APP_AGENT_NAME = "app_agent_name";
        public static final String DEVICE_ID = "device_id";
        public static final String SOURCE = "source";
        public static final String FIRST_NAME = "first_name";
        public static final String LAST_NAME = "last_name";
        public static final String EMAIL_ID = "email_id";
    }

    enum AuthorizationCodeGrant {
        ;
        public static final String CODE = "code";
        public static final String CODE_CHALLENGE_METHOD = "code_challenge_method";
        public static final String CODE_CHALLENGE = "code_challenge";
        public static final String CODE_VERIFIER = "code_verifier";

    }

}
