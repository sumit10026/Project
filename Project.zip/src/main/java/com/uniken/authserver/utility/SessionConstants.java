package com.uniken.authserver.utility;

public class SessionConstants {

    private SessionConstants() {
        throw new IllegalStateException("SessionConstants class");
    }

    public static final String USERNAME = "username";

    // Validate user based on auth factor session related constants
    public static final String PENDING_AUTH_TYPES = "pending_auth_types";
    public static final String VALIDATED_AUTH_TYPES = "validated_auth_types";
    public static final String OFFERED_AUTH_TYPES = "offered_auth_types";
    public static final String INIT_PARAM = "init";
    public static final String LOGGED_IN_USING_FIDO_PLATFORM_AUTH = "logged_in_using_fido_platform_auth";
    public static final String LOGGED_IN_USING_FIDO_2FA = "logged_in_using_fido_2fa";
    public static final String CURRENT_USERNAME = "current_username";
    public static final String VALIDATED_USERNAME = "validated_username";
    public static final String OFFERED_USERNAME = "offered_username";
    public static final String AUTH_GENERATION_ATTEMPT_COUNTER = "auth_generation_attempt_counter";
    public static final String IS_ALL_LEVEL1_AUTH_TYPES_OFFERED = "is_all_level1_auth_types_offered";

    public static final String REQ_PARAM_MAP = "req_param_map";
    public static final String ATTEMPTS_COUNTER = "attempts_counter";
    public static final String EXCEPTION_ATTRS_MAP = "exception_attrs";
    public static final String USER_AGENT = "user_agent";
    public static final String IS_SECURE_COOKIE_SET = "is_secure_cookie_set";
    public static final String REGISTRATION_SECURE_COOKIE = "registration_secure_cookie";
    public static final String IS_REDIRECT_TO_ERROR_PAGE = "is_redirect_to_error_page";
    public static final String ERROR_DISPLAY_MSG = "error_display_msg";

    // Error & Success Messages
    public static final String ERR_UNMATCHED_AUTH_TYPE_WITH_PENDING_AUTH_TYPE = "Auth Type Not Matching With Pending Auth Types";
    public static final String ERR_UNSUPPORTED_AUTH_TYPE = "Unsupported Auth Type";
    public static final String ERR_INVALID_AUTH_TYPE = "Invalid Auth Type";
    public static final String ERR_INVALID_AUTH_VALUE = "Invalid Auth Value for Auth Type - ";
    public static final String ERR_INVALID_USER = "Invalid User : User is not registered in the system";

}
