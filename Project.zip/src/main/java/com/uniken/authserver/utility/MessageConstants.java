package com.uniken.authserver.utility;

public class MessageConstants {

    private MessageConstants() {
        throw new IllegalStateException("MessageConstants class");
    }

    public static final String KEY_MSG_ERROR_ACCOUNT_DELETION = "msg.error.account.deletion";
    public static final String KEY_MSG_SUCCESS_ACCOUNT_DELETION = "msg.success.account.deletion";
    public static final String KEY_MSG_ERROR_INCORRECT_TOTP = "msg.error.incorrect.totp";
    public static final String KEY_MSG_ERROR_INCORRECT_SMSOTP = "msg.error.incorrect.smsotp";
    public static final String KEY_MSG_ERROR_INCORRECT_EMAILOTP = "msg.error.incorrect.emailotp";
    public static final Object KEY_MSG_ERROR_INCORRECT_PASS = "msg.error.incorrect.pass";

}
