package com.uniken.authserver.exception;

import java.util.List;

public class InvalidInputException extends Exception {

    private static final long serialVersionUID = 1L;
    private String message;
    private List<String> errorMsgList;

    public InvalidInputException() {
        super();
    }

    /**
     * @return the message
     */
    @Override
    public String getMessage() {
        return message;
    }

    public InvalidInputException(final String message) {
        super();
        this.message = message;
    }

    public InvalidInputException(final String message, final List<String> errorMsgList) {
        super();
        this.message = message;
        this.errorMsgList = errorMsgList;
    }

    public InvalidInputException(final Throwable e) {
        super(e);
    }

    /**
     * @return the errorMsgList
     */
    public List<String> getErrorMsgList() {
        return errorMsgList;
    }
}
