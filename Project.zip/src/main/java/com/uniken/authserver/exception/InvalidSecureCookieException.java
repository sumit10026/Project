package com.uniken.authserver.exception;

public class InvalidSecureCookieException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = -8922516034466679814L;

    public InvalidSecureCookieException(final String message) {
        super(message);
    }

}
