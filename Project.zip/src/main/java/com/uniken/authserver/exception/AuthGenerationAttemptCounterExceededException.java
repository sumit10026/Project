package com.uniken.authserver.exception;

public class AuthGenerationAttemptCounterExceededException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public AuthGenerationAttemptCounterExceededException(final String message) {
        super(message);
    }

}
