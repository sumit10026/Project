package com.uniken.authserver.exception;

public class RelIDNotificationRejectedException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = 3367500602066694104L;

    public RelIDNotificationRejectedException(final String message) {
        super(message);
    }

}
