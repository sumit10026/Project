package com.uniken.authserver.exception;

public class ActivationGenerationAttemptCounterExceededException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public ActivationGenerationAttemptCounterExceededException(final String message) {
        super(message);
    }

}
