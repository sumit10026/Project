package com.uniken.authserver.exception.handler;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.common.exceptions.InvalidClientException;
import org.springframework.security.oauth2.common.exceptions.InvalidRequestException;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.springframework.security.oauth2.provider.NoSuchClientException;
import org.springframework.security.oauth2.provider.error.DefaultWebResponseExceptionTranslator;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import com.uniken.authserver.utility.Constants;

@ControllerAdvice
public class AuthServerExceptionHandler {

    private static final Logger LOG = LoggerFactory.getLogger(AuthServerExceptionHandler.class);

    private final DefaultWebResponseExceptionTranslator exceptionTranslator = new DefaultWebResponseExceptionTranslator();

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    private ResponseEntity<OAuth2Exception> handleHttpRequestMethodNotSupportedException(
            final HttpRequestMethodNotSupportedException e) throws Exception {
        LOG.error(Constants.EXCEPTION_INITIAL_STR, e.getClass().getSimpleName(), e.getMessage());
        return exceptionTranslator.translate(e);
    }

    @ExceptionHandler(UsernameNotFoundException.class)
    private ResponseEntity<OAuth2Exception> handleUsernameNotFoundException(final UsernameNotFoundException e)
            throws Exception {
        LOG.error(Constants.EXCEPTION_INITIAL_STR, e.getClass().getSimpleName(), e.getMessage());
        return exceptionTranslator.translate(e);
    }

    @ExceptionHandler(NoSuchClientException.class)
    private ResponseEntity<OAuth2Exception> handleNoSuchClientException(final NoSuchClientException e)
            throws Exception {
        LOG.error(Constants.EXCEPTION_INITIAL_STR, e.getClass().getSimpleName(), e.getMessage());
        return exceptionTranslator.translate(e);
    }

    @ExceptionHandler(InvalidRequestException.class)
    private ResponseEntity<OAuth2Exception> handleNoSuchClientException(final InvalidRequestException e)
            throws Exception {
        LOG.error(Constants.EXCEPTION_INITIAL_STR, e.getClass().getSimpleName(), e.getMessage());
        return exceptionTranslator.translate(e);
    }

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<OAuth2Exception> handleIllegalArgumentException(final IllegalArgumentException e)
            throws Exception {
        LOG.error(Constants.EXCEPTION_INITIAL_STR, e.getClass().getSimpleName(), e.getMessage());

        final OAuth2Exception e400 = new OAuth2Exception(e.getMessage()) {
            /**
             * 
             */
            private static final long serialVersionUID = -3953772681089144551L;

            @Override
            public String getOAuth2ErrorCode() {
                return "access_denied";
            }

            @Override
            public int getHttpErrorCode() {
                return 400;
            }
        };

        return exceptionTranslator.translate(e400);

    }

    // Below annotations are commented because it is not redirecting to /login
    // page

    @ExceptionHandler(MissingServletRequestParameterException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<OAuth2Exception> handleBadRequestException(final MissingServletRequestParameterException e)
            throws Exception {
        LOG.info("Handling error: {}, {} ", e.getClass().getSimpleName(), e.getMessage());

        final OAuth2Exception e400 = new OAuth2Exception(e.getMessage()) {
            /**
             * 
             */
            private static final long serialVersionUID = -3953772681089144551L;

            @Override
            public String getOAuth2ErrorCode() {
                return "invalid_request";
            }

            @Override
            public int getHttpErrorCode() {
                return 400;
            }
        };

        return exceptionTranslator.translate(e400);

    }

    @ExceptionHandler(InvalidClientException.class)
    public ResponseEntity<OAuth2Exception> handleInvalidClientException(final InvalidClientException e)
            throws Exception {
        LOG.info("Handling error: {}, {} ", e.getClass().getSimpleName(), e.getMessage());
        return exceptionTranslator.translate(e);
    }

    @ExceptionHandler(OAuth2Exception.class)
    public ResponseEntity<OAuth2Exception> handleException(final OAuth2Exception e) throws Exception {
        LOG.info("Handling error: {}, {} ", e.getClass().getSimpleName(), e.getMessage());
        return exceptionTranslator.translate(e);

    }
}
