package com.uniken.authserver.exception;

import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;

public class RelIDAuthServerOAuth2Exception extends OAuth2Exception {

    /**
     * 
     */
    private static final long serialVersionUID = -8781884958192999377L;

    public RelIDAuthServerOAuth2Exception(final String exceptionMessage) {
        super(exceptionMessage);
    }

}
