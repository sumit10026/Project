package com.uniken.authserver.exception;

public class AuthFactorException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = -2726223390229618556L;

    public AuthFactorException(final String message) {
        super(message);
    }

}
