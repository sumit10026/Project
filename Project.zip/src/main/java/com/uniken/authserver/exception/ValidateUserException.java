package com.uniken.authserver.exception;

public class ValidateUserException extends RuntimeException {

    /**
     * 
     */
    private static final long serialVersionUID = 6651975746127420443L;

    public ValidateUserException(final String msg) {
        super(msg);
    }

}
