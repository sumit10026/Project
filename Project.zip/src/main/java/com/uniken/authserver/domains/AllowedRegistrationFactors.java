package com.uniken.authserver.domains;

import lombok.Data;

@Data
public class AllowedRegistrationFactors {

    private boolean password;

    private boolean rememberMe;
    private boolean fidoPlatform;
    private boolean fidoRoaming;

    // FIXME: Enable thirdPartyTotp in Milestone 2
    // private boolean thirdPartyTotp;

    private boolean smsOtp;
    private boolean emailOtp;
    private boolean alwaysAskForPassword;

    // Disable support of Platform Authenticator
    public void setFidoPlatform(final boolean fidoPlatform) {
        this.fidoPlatform = false;
    }

    // Disable support of Platform Authenticator
    public boolean isFidoPlatform() {
        return false;
    }

}
