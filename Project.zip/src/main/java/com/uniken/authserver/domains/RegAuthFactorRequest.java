package com.uniken.authserver.domains;

public class RegAuthFactorRequest {

    private String regAuthTypeId;
    private boolean enabledState;

    public String getRegAuthTypeId() {
        return regAuthTypeId;
    }

    public void setRegAuthTypeId(final String regAuthTypeId) {
        this.regAuthTypeId = regAuthTypeId;
    }

    public boolean isEnabledState() {
        return enabledState;
    }

    public void setEnabledState(final boolean isEnabledState) {
        this.enabledState = isEnabledState;
    }

}
