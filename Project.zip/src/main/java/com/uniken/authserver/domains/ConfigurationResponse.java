package com.uniken.authserver.domains;

import java.util.List;
import java.util.Map;

public class ConfigurationResponse {

    private Configuration configuration;
    private List<Map<String, String>> accounts;

    public ConfigurationResponse(final Configuration configuration, final List<Map<String, String>> accounts) {
        super();
        this.configuration = configuration;
        this.accounts = accounts;
    }

    public Configuration getConfiguration() {
        return configuration;
    }

    public List<Map<String, String>> getAccounts() {
        return accounts;
    }

    public void setConfiguration(final Configuration configuration) {
        this.configuration = configuration;
    }

    public void setAccounts(final List<Map<String, String>> accounts) {
        this.accounts = accounts;
    }

}
