package com.uniken.authserver.domains;

import java.util.regex.Pattern;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;

@Data
@JsonInclude(Include.NON_EMPTY)
public class PassPolicy {

    private int minL;
    private int maxL;
    private int minLc;
    private int minUc;
    private int minSc;
    private int minDg;
    @JsonProperty
    private int Repetition;
    @JsonProperty
    private boolean UserIDcheck;
    private String msg;

    @JsonIgnore
    private Pattern minLcPattern;
    @JsonIgnore
    private Pattern minUcPattern;
    @JsonIgnore
    private Pattern minScPattern;
    @JsonIgnore
    private Pattern minDgPattern;
    @JsonIgnore
    private Pattern repPattern;

}
