package com.uniken.authserver.domains;

import java.util.List;

public class Acoounts {

    private List<String> users;

    public List<String> getUsers() {
        return users;
    }

    public void setUsers(final List<String> users) {
        this.users = users;
    }

}
