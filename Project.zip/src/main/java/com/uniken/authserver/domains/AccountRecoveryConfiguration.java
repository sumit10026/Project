package com.uniken.authserver.domains;

import lombok.Data;

@Data
public class AccountRecoveryConfiguration {

    private boolean password;
    private boolean smsOtp;
    private boolean emailOtp;
    private boolean fidoRoaming;

    private String mobileNumberRegex;
    private String emailRegex;

    private PassPolicy passPolicy;
    private boolean showPassStrength;

    private int delayBeforeRedirect;

}
