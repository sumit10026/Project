package com.uniken.authserver.domains;

import lombok.Data;

@Data
public class AccountRecoveryOptions {

    private String username;
    private String mobileNumber;
    private String email;
    private AccountRecoveryConfiguration configuration;

}
