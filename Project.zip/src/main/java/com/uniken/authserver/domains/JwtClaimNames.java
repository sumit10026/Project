package com.uniken.authserver.domains;

public final class JwtClaimNames {

    private JwtClaimNames() {
    }

    public static final String ACTIVE = "active";
    public static final String SCOPE = "scope";
    public static final String CLIENT_ID = "client_id";
    public static final String USER_NAME = "user_name";
    public static final String USERNAME = "username";
    public static final String EXP = "exp";
    public static final String SUB = "sub";
    public static final String AUD = "aud";
    public static final String ISS = "iss";
    public static final String JTI = "jti";

}
