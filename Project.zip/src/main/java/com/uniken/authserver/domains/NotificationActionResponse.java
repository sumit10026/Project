package com.uniken.authserver.domains;

import com.google.gson.annotations.SerializedName;

/*
 * @author Sumeet Khambe
 */
public class NotificationActionResponse {

    @SerializedName("status_code")
    private int code;

    @SerializedName("message")
    private String message;

    @SerializedName("notification_uuid")
    private String notificationUuid;

    @SerializedName("is_ds_verified")
    private boolean dsVerified;

    /**
     * @return the code
     */
    public int getCode() {
        return code;
    }

    /**
     * @param code
     *            the code to set
     */
    public void setCode(final int code) {
        this.code = code;
    }

    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message
     *            the message to set
     */
    public void setMessage(final String message) {
        this.message = message;
    }

    /**
     * @return the notificationUuid
     */
    public String getNotificationUuid() {
        return notificationUuid;
    }

    /**
     * @param notificationUuid
     *            the notificationUuid to set
     */
    public void setNotificationUuid(final String notificationUuid) {
        this.notificationUuid = notificationUuid;
    }

    /**
     * @return the dsVerified
     */
    public boolean isDsVerified() {
        return dsVerified;
    }

    /**
     * @param dsVerified
     *            the dsVerified to set
     */
    public void setDsVerified(final boolean dsVerified) {
        this.dsVerified = dsVerified;
    }

}
