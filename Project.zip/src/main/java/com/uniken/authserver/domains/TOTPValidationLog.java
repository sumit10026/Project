package com.uniken.authserver.domains;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;

public class TOTPValidationLog {

    public static final String USER_ID = "user_id";
    public static final String SEED = "seed";
    public static final String DEVICE_ID = "device_id";
    public static final String TOTP = "totp";
    public static final String VALIDATION_TS = "validation_ts";
    public static final String VALIDATION_STATUS = "validation_status";

    private String userId;
    private String seed;
    private String deviceId;
    private String totp;
    private Date validationTs;
    private String validationStatus;

    public String getUserId() {
        return userId;
    }

    public void setUserId(final String userId) {
        this.userId = userId;
    }

    public String getSeed() {
        return seed;
    }

    public void setSeed(final String seed) {
        this.seed = seed;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(final String deviceId) {
        this.deviceId = deviceId;
    }

    public String getTotp() {
        return totp;
    }

    public void setTotp(final String totp) {
        this.totp = totp;
    }

    public Date getValidationTs() {
        return validationTs;
    }

    public void setValidationTs(final Date validationTs) {
        this.validationTs = validationTs;
    }

    public String getValidationStatus() {
        return validationStatus;
    }

    public void setValidationStatus(final String validationStatus) {
        this.validationStatus = validationStatus;
    }

    public static Document getBsonDocument(final TOTPValidationLog log) {

        final Document doc = new Document();

        if (log == null) {
            return null;
        }

        if (log.getUserId() != null) {
            doc.append(USER_ID, log.getUserId());
        }
        if (log.getSeed() != null) {
            doc.append(SEED, log.getSeed());
        }
        if (log.getDeviceId() != null) {
            doc.append(DEVICE_ID, log.getDeviceId());
        }
        if (log.getTotp() != null) {
            doc.append(TOTP, log.getTotp());
        }
        if (log.getValidationTs() != null) {
            doc.append(VALIDATION_TS, log.getValidationTs());
        }
        if (log.getValidationStatus() != null) {
            doc.append(VALIDATION_STATUS, log.getValidationStatus());
        }

        return doc;
    }

    /**
     * Create Bson Document from the provided list of validation logs
     * 
     * @param devices
     *            list of Device object
     * @return
     */
    public static List<Document> getBsonDocuments(final List<TOTPValidationLog> logs) {

        final List<Document> documents = new ArrayList<Document>();

        for (final TOTPValidationLog log : logs) {
            documents.add(getBsonDocument(log));
        }

        return documents;

    }

}
