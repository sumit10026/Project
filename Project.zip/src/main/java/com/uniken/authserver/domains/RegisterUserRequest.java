package com.uniken.authserver.domains;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_EMPTY)
public class RegisterUserRequest {

    @NotBlank(message = "username is mandatory")
    @JsonProperty("username")
    private String userName;

    @JsonProperty("auth_type")
    private String authType;

    @JsonProperty("auth_value")
    private String authValue;

    @JsonProperty("is_remember_me")
    private boolean isRememberMe;

    public String getUserName() {
        return userName;
    }

    public void setUserName(final String userName) {
        this.userName = userName;
    }

    public String getAuthType() {
        return authType;
    }

    public void setAuthType(final String authType) {
        this.authType = authType;
    }

    public String getAuthValue() {
        return authValue;
    }

    public void setAuthValue(final String authValue) {
        this.authValue = authValue;
    }

    public boolean getIsRememberMe() {
        return isRememberMe;
    }

    public void setIsRememberMe(final boolean isRememberMe) {
        this.isRememberMe = isRememberMe;
    }

}
