package com.uniken.authserver.domains;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_EMPTY)
public class ConfigurationRequest {

    // @NotBlank(message = "web_device_parameter_checksum is mandatory")
    @JsonProperty("web_device_parameter_checksum")
    private String webDeviceParameterChecksum;

    @NotBlank(message = "web_device_parameters is mandatory")
    @JsonProperty("web_device_parameters")
    private String webDeviceParameters;

    public String getWebDeviceParameterChecksum() {
        return webDeviceParameterChecksum;
    }

    public void setWebDeviceParameterChecksum(final String webDeviceParameterChecksum) {
        this.webDeviceParameterChecksum = webDeviceParameterChecksum;
    }

    public String getWebDeviceParameters() {
        return webDeviceParameters;
    }

    public void setWebDeviceParameters(final String webDeviceParameters) {
        this.webDeviceParameters = webDeviceParameters;
    }

}
