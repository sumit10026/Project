package com.uniken.authserver.domains;

import com.uniken.domains.enums.auth.AuthType;

public class ValidateUserAuthDetails {

    private AuthType authType;
    private boolean isAuthenticated;

    public ValidateUserAuthDetails(final AuthType authType, final boolean isAuthenticated) {
        this.authType = authType;
        this.isAuthenticated = isAuthenticated;
    }

    public AuthType getAuthType() {
        return authType;
    }

    public void setAuthType(final AuthType authType) {
        this.authType = authType;
    }

    public boolean isAuthenticated() {
        return isAuthenticated;
    }

    public void setAuthenticated(final boolean isAuthenticated) {
        this.isAuthenticated = isAuthenticated;
    }

}
