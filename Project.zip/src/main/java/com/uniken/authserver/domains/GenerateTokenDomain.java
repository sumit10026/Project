package com.uniken.authserver.domains;

import java.io.Serializable;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

public class GenerateTokenDomain
        implements
        Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -8024499693925616237L;
    public static final String USER_ID_STR = "user_id";
    public static final String GRANT_TYPE_STR = "grant_type";
    public static final String CLIENT_ID_STR = "client_id";
    public static final String ENTERPRISE_ID_STR = "enterprise_id";

    @Field(USER_ID_STR)
    @SerializedName(USER_ID_STR)
    private String userId;

    @Field(GRANT_TYPE_STR)
    @SerializedName(GRANT_TYPE_STR)
    private String grantType;

    @Field(CLIENT_ID_STR)
    @SerializedName(CLIENT_ID_STR)
    private String clientId;

    @Field(ENTERPRISE_ID_STR)
    @SerializedName(ENTERPRISE_ID_STR)
    private String enterpriseId;

    public String getUserId() {
        return userId;
    }

    public void setUserId(final String userId) {
        this.userId = userId;
    }

    public String getGrantType() {
        return grantType;
    }

    public void setGrantType(final String grantType) {
        this.grantType = grantType;
    }

    public String getClientId() {
        return clientId;
    }

    public void setClientId(final String clientId) {
        this.clientId = clientId;
    }

    public String getEnterpriseId() {
        return enterpriseId;
    }

    public void setEnterpriseId(final String enterpriseId) {
        this.enterpriseId = enterpriseId;
    }
}
