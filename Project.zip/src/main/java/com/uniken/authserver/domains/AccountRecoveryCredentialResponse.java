package com.uniken.authserver.domains;

import java.util.Set;

public class AccountRecoveryCredentialResponse {

    private String username;
    private Set<String> resetCredentialFactor;

    public String getUsername() {
        return username;
    }

    public void setUsername(final String username) {
        this.username = username;
    }

    public Set<String> getResetCredentialFactor() {
        return resetCredentialFactor;
    }

    public void setResetCredentialFactor(final Set<String> resetCredentialFactor) {
        this.resetCredentialFactor = resetCredentialFactor;
    }

}
