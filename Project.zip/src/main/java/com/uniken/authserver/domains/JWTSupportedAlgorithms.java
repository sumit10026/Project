package com.uniken.authserver.domains;

public enum JWTSupportedAlgorithms {
    RS256("RS256");

    private String alg;

    /**
     * @param alg
     */
    private JWTSupportedAlgorithms(final String alg) {
        this.alg = alg;
    }

    public String getAlg() {
        return alg;
    }
}
