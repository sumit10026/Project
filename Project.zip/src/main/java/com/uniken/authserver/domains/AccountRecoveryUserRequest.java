package com.uniken.authserver.domains;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AccountRecoveryUserRequest {

    @NotBlank(message = "username is mandatory")
    @JsonProperty("username")
    private String userName;

    @NotBlank(message = "IDV method is mandatory")
    @JsonProperty("idv_method")
    private String idvMethod;

    @NotBlank(message = "IDV value is mandatory")
    @JsonProperty("idv_value")
    private String idvValue;

    @JsonProperty("security_question")
    private String securityQuestion;

    @NotBlank(message = "web_device_parameters is mandatory")
    @JsonProperty("web_device_parameters")
    private String webDeviceParameters;

    public String getWebDeviceParameters() {
        return webDeviceParameters;
    }

    public void setWebDeviceParameters(final String webDeviceParameters) {
        this.webDeviceParameters = webDeviceParameters;
    }

    public String getSecurityQuestion() {
        return securityQuestion;
    }

    public void setSecurityQuestion(final String securityQuestion) {
        this.securityQuestion = securityQuestion;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(final String userName) {
        this.userName = userName;
    }

    public String getIdvMethod() {
        return idvMethod;
    }

    public void setIdvMethod(final String idvMethod) {
        this.idvMethod = idvMethod;
    }

    public String getIdvValue() {
        return idvValue;
    }

    public void setIdvValue(final String idvValue) {
        this.idvValue = idvValue;
    }

}
