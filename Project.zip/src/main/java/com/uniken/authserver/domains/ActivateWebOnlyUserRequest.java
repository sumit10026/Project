package com.uniken.authserver.domains;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ActivateWebOnlyUserRequest {

    public static final String REDIRECT_STR = "redirect_uri";

    @JsonProperty(REDIRECT_STR)
    private String redirectUri;

    /**
     * @return the redirectUri
     */
    public String getRedirectUri() {
        return redirectUri;
    }

    /**
     * @param redirectUri
     *            the redirectUri to set
     */
    public void setRedirectUri(final String redirectUri) {
        this.redirectUri = redirectUri;
    }

}
