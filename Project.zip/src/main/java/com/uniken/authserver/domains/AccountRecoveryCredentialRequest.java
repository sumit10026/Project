package com.uniken.authserver.domains;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AccountRecoveryCredentialRequest {

    @NotBlank(message = "Username is mandatory")
    @JsonProperty("username")
    private String userName;

    @NotBlank(message = "Auth Type is mandatory")
    @JsonProperty("auth_type")
    private String authType;

    @NotBlank(message = "Auth Value is mandatory")
    @JsonProperty("auth_value")
    private String authValue;

    @JsonProperty("security_question")
    private String securityQuestion;

    @NotBlank(message = "web_device_parameters is mandatory")
    @JsonProperty("web_device_parameters")
    private String webDeviceParameters;

    public String getWebDeviceParameters() {
        return webDeviceParameters;
    }

    public void setWebDeviceParameters(final String webDeviceParameters) {
        this.webDeviceParameters = webDeviceParameters;
    }

    public String getSecurityQuestion() {
        return securityQuestion;
    }

    public void setSecurityQuestion(final String securityQuestion) {
        this.securityQuestion = securityQuestion;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(final String userName) {
        this.userName = userName;
    }

    public String getAuthType() {
        return authType;
    }

    public void setAuthType(final String authType) {
        this.authType = authType;
    }

    public String getAuthValue() {
        return authValue;
    }

    public void setAuthValue(final String authValue) {
        this.authValue = authValue;
    }

}
