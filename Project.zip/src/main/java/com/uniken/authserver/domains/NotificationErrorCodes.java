package com.uniken.authserver.domains;

public interface NotificationErrorCodes {

    enum RESPONSE_CODE implements ResponseCode {

        GET_NOTIFICATION_SUCCESS((short) 100, "Success"),
        GET_NOTIFICATION_INVALID_REQUEST((short) 3500, "Invalid Notification Request"),
        GET_NOTIFICATION_REQUEST_NULL_OR_EMPTY((short) 3501, "Notification Request null or empty"),
        GET_NOTIFICATION_INVALID_REQUEST_DATA((short) 3502, "Invalid Notification Request Data"),
        GET_NOTIFICATION_REQUEST_DATA_NULL_OR_EMPTY((short) 3503, "Notification Request Data null or empty"),
        GET_NOTIFICATION_REQUEST_USER_UUID_NULL_OR_EMPTY((short) 3504, "Invalid User-Id Provided"),
        GET_NOTIFICATION_REQUEST_START_INDEX_ZERO((short) 3505, "Invalid Search Range for Notification"),
        GET_NOTIFICATION_REQUEST_COUNT_NEGATIVE((short) 3506, "Invalid Search Range for Notification"),
        GET_NOTIFICATION_REQUEST_DATE_ABSENT((short) 3507, "Invalid Date for Notification"),
        GET_NOTIFICATION_REQUEST_START_DATE_MORE_THAN_END((short) 3508, "Invalid Date for Notification"),
        GET_NOTIFICATION_REQUEST_END_DATE_LESS_THAN_END((short) 3509, "Invalid Date for Notification"),
        GET_NOTIFICATION_REQUEST_USER_NOT_ACTIVE_OR_PRESENT((short) 3510, "User is not active or is not present"),
        GET_NOTIFICATION_REQUEST_FAILED_DB_ERROR((short) 3511, "Internal Server Error. Please retry."),

        GET_NOTIFICATION_HISTORY_SUCCESS((short) 100, "Success"),
        GET_NOTIFICATION_HISTORY_INVALID_REQUEST((short) 3559, "Invalid Notification History Request"),
        GET_NOTIFICATION_HISTORY_REQUEST_NULL_OR_EMPTY((short) 3560, "Notification History Request null or empty"),
        GET_NOTIFICATION_HISTORY_INVALID_REQUEST_DATA((short) 3561, "Invalid Notification History Request Data"),
        GET_NOTIFICATION_HISTORY_REQUEST_DATA_NULL_OR_EMPTY((short) 3562,
                "Notification History Request Data null or empty"),
        GET_NOTIFICATION_HISTORY_REQUEST_USER_UUID_NULL_OR_EMPTY((short) 3563, "Invalid User-Id Provided"),
        GET_NOTIFICATION_HISTORY_REQUEST_START_INDEX_ZERO((short) 3564,
                "Invalid Search Range for Notification History"),
        GET_NOTIFICATION_HISTORY_REQUEST_COUNT_NEGATIVE((short) 3565, "Invalid Search Range for Notification History"),
        GET_NOTIFICATION_HISTORY_REQUEST_DATE_ABSENT((short) 3566, "Invalid Date for Notification History"),
        GET_NOTIFICATION_HISTORY_REQUEST_START_DATE_MORE_THAN_END((short) 3567,
                "Invalid Date for Notification History"),
        GET_NOTIFICATION_HISTORY_REQUEST_END_DATE_LESS_THAN_END((short) 3568, "Invalid Date for Notification History"),
        GET_NOTIFICATION_HISTORY_REQUEST_USER_NOT_ACTIVE_OR_PRESENT((short) 3569,
                "User is not active or is not present"),
        GET_NOTIFICATION_HISTORY_REQUEST_FAILED_DB_ERROR((short) 3570, "Internal Server Error. Please retry."),
        GET_NOTIFICATION_HISTORY_NOTIFICATIONS_NULL_OR_EMPTY((short) 3571, "Notification History null or empty."),

        NOTIFICATION_ACTION_SUCCESS((short) 100, "Success"),
        NOTIFICATION_ACTION_INVALID_REQUEST((short) 3512, "Invalid Notification Update Request"),
        NOTIFICATION_ACTION_REQUEST_NULL_OR_EMPTY((short) 3513, "Notification Update Request null or empty"),
        NOTIFICATION_ACTION_UUID_NULL_OR_EMPTY((short) 3514, "Notification Identifier not found"),
        NOTIFICATION_ACTION_INVALID_REQUEST_DATA((short) 3515, "Invalid Notification Update Data"),
        NOTIFICATION_ACTION_REQUEST_DATA_NULL_OR_EMPTY((short) 3516, "Notification Action Data null or empty"),
        NOTIFICATION_ACTION_NULL_OR_EMPTY((short) 3517, "Notification Action null or empty"),
        NOTIFICATION_ACTION_USER_NOT_ACTIVE_OR_PRESENT((short) 3518, "User is not active or is not present"),
        NOTIFICATION_ACTION_EXPIRED((short) 3519, "Notification is expired"),
        NOTIFICATION_ACTION_PERFORMED_UPDATED_FAILED_DB_ERROR((short) 3520, "Internal Server Error. Please retry."),

        // Save notification error codes
        SAVE_NOTIFICATION_REQUEST_DATA_NULL_OR_EMPTY((short) 3521, "Notification Save Request null or empty"),
        SAVE_NOTIFICATION_INVALID_REQUEST_DATA((short) 3522, "Invalid JSON String request"),
        REQ_ACCEPT_TIME_NULL_OR_EMPTY((short) 3523, "Null or Empty parameter ->ACCEPT_TIME"),
        INVALID_REQ_ACCEPT_TIME((short) 3524, "Invalid parameter ->ACCEPT_TIME"),
        MSG_ID_NULL_OR_EMPTY((short) 3525, "Null or Empty parameter ->MSG_ID"),
        ENTERPRISE_ID_NULL_OR_EMPTY((short) 3526, "Null or Empty parameter ->ENTERPRISE_ID"),
        INVALID_ENTERPRISE_ID((short) 3527,
                "Invalid ENTERPRISE ID (enterprise_id provided in request body is not associated with credentials provided in authentication header OR it does not exists)"),
        USER_ID_NULL_OR_EMPTY((short) 3528, "Null or Empty parameter ->USER_ID"),
        INVALID_USER_STATE((short) 3529, "Invalid User Status"),
        INVALID_DEVICE_STATE((short) 3548, "Invalid Device Status"),
        USER_NOT_ACTIVE_OR_PRESENT((short) 3530, "User not active or present"),
        MSG_NULL_OR_EMPTY((short) 3531, "Null or Empty parameter ->MSG"),
        MSG_LNG_NULL_OR_EMPTY((short) 3586, "Null or Empty parameter ->MSG_LNG"),
        MSG_SUB_NULL_OR_EMPTY((short) 3532, "Null or Empty parameter ->MSG_SUBJECT"),
        MSG_MESSAGE_NULL_OR_EMPTY((short) 3533, "Null or Empty parameter ->MSG_MESSAGE"),
        MSG_LABEL_NULL_OR_EMPTY((short) 3587, "Null or Empty parameter ->MSG_LABEL"),
        NOTIFICATION_MSG_NULL_OR_EMPTY((short) 3534, "Null or Empty parameter ->NOTIFICATION_MSG"),
        NOTIFICATION_MSG_SUB_NULL_OR_EMPTY((short) 3535, "Null or Empty parameter ->NOTIFICATION_MSG_SUBJECT"),
        NOTIFICATION_MSG_BODY_NULL_OR_EMPTY((short) 3536, "Null or Empty parameter ->NOTIFICATION_MSG_MESSAGE"),
        EXPIRY_TIME_NULL_OR_EMPTY((short) 3537, "Null or Empty parameter ->EXPIRY_TIME"),
        INVALID_EXPIRY_TIME((short) 3538, "Invalid Expiry Time"),
        CALLBACK_URL_NULL_OR_EMPTY((short) 3539, "Null or Empty parameter ->CALLBACK_URL"),
        INVALID_CALLBACK_URL((short) 3540, "Invalid Callback URL"),
        ACTIONS_NULL_OR_EMPTY((short) 3541, "Null or Empty parameter ->ACTIONS"),
        INVALID_ACTIONS((short) 3542, "Invalid Actions provided"),
        ACTIONS_LABEL_NULL_OR_EMPTY((short) 3543, "Null or Empty parameter ->ACTIONS_LABEL"),
        ACTIONS_ACTION_NULL_OR_EMPTY((short) 3544, "Null or Empty parameter ->ACTIONS_ACTION"),
        ERROR_IN_DB_SAVE((short) 3545, "Internal Server Error. Please retry."),
        NO_DEVTOKENS_FOUND((short) 3546, "Device/s information is null or empty"),
        NOTIFICATION_EXPIRED((short) 3547, "Notification Expired"),
        ENTERPRISE_APP_AGENT_MAPPING_NOT_FOUND((short) 3591,
                "Enterprise - AppAgent mapping not found. Kindly contact admin."),

        // update notification request
        // UPDATE_NOTIFICATION_REQUEST_DATA_NULL_OR_EMPTY((short) 3548,
        // "Notification Request is null or empty"),
        // UPDATE_NOTIFICATION_INVALID_REQUEST_DATA((short) 3549, "Invalid
        // Notification Request Data"),
        UPDATE_NOTIFICATION_NOTIFICATION_UUID_NULL_EMPTY((short) 3550, "Notification Identifier is null or empty"),
        UPDATE_NOTIFICATION_STATUS_NULL_EMPTY((short) 3551, "Notification Delivery Status is null or empty"),
        UPDATE_NOTIFICATION_STATUS_INVALID((short) 3552, "Notification delivery Status is Invalid"),
        // UPDATE_NOTIFICATION_DEV_TOKEN_NULL_EMPTY((short) 3553, "Device
        // information is null or empty"),

        // POLL_NOTIFICATION_USER_ACTION_INVALID_REQUEST((short) 3554, "Invalid
        // Notification Request"),
        // POLL_NOTIFICATION_USER_ACTION_REQUEST_NULL_OR_EMPTY((short) 3555,
        // "Notification Request is null or empty"),
        POLL_NOTIFICATION_USER_ACTION_NOTIFICATION_UUID_NULL_OR_EMPTY((short) 3556,
                "Notification Identifier is null or empty"),
        POLL_NOTIFICATION_USER_ACTION_FAILED_TO_FETCH_DATA_FROM_DB_ERROR((short) 3557,
                "Internal Server Error. Please retry."),
        POLL_NOTIFICATION_USER_ACTION_NOTIFICATION_UUID_NOT_FOUND_IN_DB((short) 3558,
                "Notification Identifier is not found"),

        MOBILE_NUMBER_ASSOCIATED_WITH_MULTIPLE_USERS((short) 3559, "Mobile number associated with multiple users"),
        USER_NOT_PRESENT((short) 3560, "User not present"),
        USER_NOT_ACTIVE((short) 3561, "User not active"),
        INVALID_MODE_PREFERENCE((short) 3562, "Invalid mode preference provided"),
        INVALID_MSG_TYE((short) 3577, "Invalid message type provided"),
        INVALID_HASH_SPECIFICATION((short) 3563, "Invalid hash specification provided"),

        OTP_VALUE_NULL_OR_EMPTY((short) 3564, "OTP Value is null or empty"),
        NOTIFICATION_NOT_PRESENT_OR_EXPIRED((short) 3565, "Notification is not present or is expired"),
        UPDATE_ACTION_NOT_ALLOWED_ON_ONE_WAY_SMS_MSG((short) 3571,
                "Update action is not allowed on one way SMS Message"),
        VALIDATE_OTP_NOT_ALLOWED_ON_TWO_WAY_SMS_MSG((short) 3572,
                "Validate OTP API call is not allowed on TWO-WAY notification"),
        SMS_MSG_SHOULD_CONTAIN_OTPVALUE_PLACEHOLDER((short) 3573, "SMS Message should contain $$OTP$$ placeholder"),
        MSG_SHOULD_CONTAIN_OTPVALUE_PLACEHOLDER((short) 3574, "Message should contain $$OTP$$ placeholder"),
        VALIDATE_OTP_ATTEMPTS_EXHAUSTED((short) 3575, "Validate OTP attempts exhausted"),
        SMS_MSG_AND_CALL_MSG_BOTH_ARE_EMPTY((short) 3576,
                "sms_msg and call_msg both are empty, atleast one of them should me provided for TWO-WAY msg_type"),
        MOBILE_NUMBER_NOT_PRESENT((short) 3585, "Mobile number is null or empty for selected user"),

        NOTIFICATION_SIGN_DATA_VERIFICATION_FAILED((short) 3567, "Failed to verify sign data."),
        NOTIFICATION_CERTIFICATE_NOT_FOUND((short) 3568,
                "Certificate not found for user. Please wait application is uploading new certificate..."),
        NOTIFICATION_CERTIFICATE_EXPIRED((short) 3569,
                "Certificate expired. Please wait application is uploading new certificate..."),

        NOTIFICATION_CERTIFICATE_PARSING_ERROR((short) 3570,
                "Failed to parse certificate. Please wait application is uploading new certificate..."),

        CONTROLS_PUSH_RETRY_TYPE_IS_INVALID((short) 3578, "Invalid controls.push_retry.type"),
        CONTROLS_PUSH_RETRY_INTERVAL_IS_INVALID((short) 3579, "Invalid controls.push_retry.interval"),
        CONTROLS_PUSH_RETRY_COUNT_IS_INVALID((short) 3580, "Invalid controls.push_retry.number"),
        CONTROLS_PUSH_FALLBACK_DURATION_IS_INVALID((short) 3581, "Invalid controls.push_fallback.duration"),
        CONTROLS_PUSH_FALLBACK_DATETIME_IS_INVALID((short) 3582, "Invalid controls.push_fallback.datetime"),
        CONTROLS_PUSH_FALLBACK_FALLBACK_TYPE_IS_INVALID((short) 3583,
                "Null or Empty parameter -> controls.push_fallback.fallback_type"),
        CONTROLS_EXPIRY_FALLBACK_SMS_MSG_CALL_MSG_IS_INVALID((short) 3584,
                "sms_msg and call_msg both are null or empty"),
        CONTROLS_OTP_ATTEMPTS_IS_INVALID((short) 3588, "Invalid controls.otp.attempts"),
        CONTROLS_PUSH_FALLBACK_EXPIRY_CALCULATOR_IS_INVALID((short) 3589,
                "controls.push_fallback duration and datetime both are null or empty"),

        REL_ID_VERIFY_IS_DISABLED((short) 3590,
                "REL-ID Verify is disabled for the user. Kindly contact admin to enable REL-ID Verify."),

        NOTIFICATION_DETAILS_NOT_FOUND((short) 3598, "Notification is not present or is active."),

        MSG_ID_REGEX_VALIDATION_FAILED((short) 3592, "msg_id regex validation failed."),
        NOTIFICATION_UUID_REGEX_VALIDATION_FAILED((short) 3593, "notification-uuid regex validation failed."),
        NOTIFICATION_ACTION_WORKFLOW_EXECUTION_FAILED((short) 3594,
                "Could not process notification action workflow. Kindly contact admin."),

        NOTIFICATION_EXPIRE_INVALID_REQUEST((short) 3595, "Invalid Expire Notification Request"),
        NOTIFICATION_EXPIRE_REQUEST_NULL_OR_EMPTY((short) 3596, "Notification Expire Request null or empty"),

        NOTIFICATION_UPDATE_AS_DISCARDED((short) 3597,
                "User is already activated, by using other activation option. If you have not done this activation then please delete device or contact admin."),

        SMS_MSG_CONTAINS_MULTIPLE_OTPVALUE_PLACEHOLDER((short) 3601,
                "SMS Message contains multiple $$OTP$$ placeholder"),
        MSG_CONTAINS_MULTIPLE_OTPVALUE_PLACEHOLDER((short) 3602, "Message contains multiple $$OTP$$ placeholder"),

        UNKNOWN((short) 3599, "Internal Server Error.");

        private final short code;
        private final String message;

        RESPONSE_CODE(final short code, final String message) {
            this.code = code;
            this.message = message;
        }

        @Override
        public short getCode() {
            return this.code;
        }

        @Override
        public String getMessage() {
            return this.message;
        }

    };

    /*
     * short GET_NOTIFICATION_INVALID_REQUEST_DATA = 1900; short
     * GET_NOTIFICATION_REQUEST_DATA_NULL_OR_EMPTY = 1902; short
     * GET_NOTIFICATION_REQUEST_USER_UUID_NULL_OR_EMPTY = 1902; short
     * NOTIFICATION_ACTION_INVALID_REQUEST_DATA = 1900; short
     * NOTIFICATION_ACTION_REQUEST_DATA_NULL_OR_EMPTY = 1900; short
     * NOTIFICATION_ACTION_UUID_NULL_OR_EMPTY = 1900; short
     * NOTIFICATION_ACTION_NULL_OR_EMPTY = 1900;
     */

}
