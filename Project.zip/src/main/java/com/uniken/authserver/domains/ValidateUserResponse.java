package com.uniken.authserver.domains;

import java.util.Map;
import java.util.Set;

public class ValidateUserResponse {

    private Set<String> authTypes;
    private String error;
    private int attempts;
    private Map<String, Integer> authGenerationAttemptsCounter;
    private boolean isAllLevel1AuthTypesOffered;

    public int getAttempts() {
        return attempts;
    }

    public void setAttempts(final int attempts) {
        this.attempts = attempts;
    }

    public ValidateUserResponse(final Set<String> authTypes, final int attempts,
            final Map<String, Integer> authGenerationAttemptsCounter) {
        this.authTypes = authTypes;
        this.attempts = attempts;
        this.authGenerationAttemptsCounter = authGenerationAttemptsCounter;
    }

    public ValidateUserResponse(final String error, final int attempts,
            final Map<String, Integer> authGenerationAttemptsCounter) {
        this.error = error;
        this.attempts = attempts;
        this.authGenerationAttemptsCounter = authGenerationAttemptsCounter;
    }

    public Set<String> getAuthTypes() {
        return authTypes;
    }

    public void setAuthTypes(final Set<String> authTypes) {
        this.authTypes = authTypes;
    }

    public String getError() {
        return error;
    }

    public void setError(final String error) {
        this.error = error;
    }

    public Map<String, Integer> getAuthGenerationAttemptsCounter() {
        return authGenerationAttemptsCounter;
    }

    public void setAuthGenerationAttemptsCounter(final Map<String, Integer> authGenerationAttemptsCounter) {
        this.authGenerationAttemptsCounter = authGenerationAttemptsCounter;
    }

    public boolean isAllLevel1AuthTypesOffered() {
        return isAllLevel1AuthTypesOffered;
    }

    public void setAllLevel1AuthTypesOffered(boolean isAllLevel1AuthTypesOffered) {
        this.isAllLevel1AuthTypesOffered = isAllLevel1AuthTypesOffered;
    }

}
