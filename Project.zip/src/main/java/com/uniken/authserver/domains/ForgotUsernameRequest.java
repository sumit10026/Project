package com.uniken.authserver.domains;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_EMPTY)
public class ForgotUsernameRequest {

    @NotBlank(message = "Please choose option")
    @JsonProperty("option")
    private String option;

    @NotBlank(message = "input is mandatory")
    @JsonProperty("option_input")
    private String optionInput;

    public String getOption() {
        return option;
    }

    public void setOption(final String option) {
        this.option = option;
    }

    public String getOptionInput() {
        return optionInput;
    }

    public void setOptionInput(final String optionInput) {
        this.optionInput = optionInput;
    }

}
