package com.uniken.authserver.domains;

public class Configuration {

    private Boolean password;
    private Boolean alwaysAskForPassword;
    private Boolean passwordLess;

    public Boolean isAlwaysAskForPassword() {
        return alwaysAskForPassword;
    }

    public void setAlwaysAskForPassword(final Boolean alwaysAskForPassword) {
        this.alwaysAskForPassword = alwaysAskForPassword;
    }

    private boolean rememberMe;

    public boolean isRememberMe() {
        return rememberMe;
    }

    public void setRememberMe(final boolean rememberMe) {
        this.rememberMe = rememberMe;
    }

    public Boolean isPassword() {
        return password;
    }

    public void setPassword(final Boolean password) {
        this.password = password;
    }

    public Boolean isPasswordLess() {
        return passwordLess;
    }

    public void setPasswordLess(final Boolean passwordLess) {
        this.passwordLess = passwordLess;
    }

}
