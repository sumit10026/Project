package com.uniken.authserver.domains;

import java.io.Serializable;
import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.enums.auth.AuthType;

public class AuthenticationDetails
        implements
        Serializable {

    private static final long serialVersionUID = 1L;

    public static final String AUTHENTICATION_DETAILS_STR = "authentication_details";

    public static final String AUTHENTICATED_STATUS_STR = "authentication_status";
    public static final String AUTHENTICAED_TYPE_STR = "authentication_type";
    public static final String AUTHENTICATED_TIMESTAMP = "authenticated_timestamp";
    public static final String AUTHENTICATED_USERID = "authenticated_userid";
    public static final String AUTHENTICATED_BROWSERID = "authenticted_browser_id";

    @SerializedName(AUTHENTICATED_STATUS_STR)
    @Field(AUTHENTICATED_STATUS_STR)
    public String authenticationStatus;

    @SerializedName(AUTHENTICAED_TYPE_STR)
    @Field(AUTHENTICAED_TYPE_STR)
    public AuthType authType;

    @SerializedName(AUTHENTICATED_TIMESTAMP)
    @Field(AUTHENTICATED_TIMESTAMP)
    public Date authenticatedTS;

    @SerializedName(AUTHENTICATED_USERID)
    @Field(AUTHENTICATED_USERID)
    public String authenticatedUserId;

    @SerializedName(AUTHENTICATED_BROWSERID)
    @Field(AUTHENTICATED_BROWSERID)
    public String authenticatedBrowserID;

    public AuthenticationDetails(final String authenticationStatus, final AuthType authType, final Date authenticatedTS,
            final String authenticatedUserId, final String authenticatedBrowserID) {
        this.authenticationStatus = authenticationStatus;
        this.authType = authType;
        this.authenticatedTS = authenticatedTS;
        this.authenticatedUserId = authenticatedUserId;
        this.authenticatedBrowserID = authenticatedBrowserID;
    }
}
