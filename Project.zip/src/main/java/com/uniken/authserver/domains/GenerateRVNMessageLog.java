package com.uniken.authserver.domains;

import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.notification.NotificationUserActionResponse;

@Document(collection = "generate_rvn_message_requests")
public class GenerateRVNMessageLog {

    public static final String USER_ID_STR = "user_id";
    public static final String CORRELATION_ID_STR = "correlation_id";
    public static final String MESSAGE_STR = "notification_msg";
    public static final String CREATED_TS_STR = "created_ts";
    public static final String NOTIFICATION_USER_ACTION_RESPONSE_STR = "notification_user_action_response";

    @Id
    public ObjectId _id;

    @Field(USER_ID_STR)
    @SerializedName(USER_ID_STR)
    private String userId;

    @Field(CORRELATION_ID_STR)
    @SerializedName(CORRELATION_ID_STR)
    @Indexed
    private String correlationID;

    @Field(WebDevMaster.WEB_ID_STR)
    @SerializedName(WebDevMaster.WEB_ID_STR)
    private String webDeviceId;

    @Field(MESSAGE_STR)
    @SerializedName(MESSAGE_STR)
    private String notificationMessage;

    @Field(CREATED_TS_STR)
    @SerializedName(CREATED_TS_STR)
    private Date createdTS;

    @Field(NOTIFICATION_USER_ACTION_RESPONSE_STR)
    @SerializedName(NOTIFICATION_USER_ACTION_RESPONSE_STR)
    private NotificationUserActionResponse notificationUserActionResponse;

    /**
     * @param userId
     * @param correlationID
     * @param notificationMessage
     * @param createdTS
     */
    public GenerateRVNMessageLog(final String userId, final String correlationID, final String webDeviceId,
            final String notificationMessage, final Date createdTS) {
        this.userId = userId;
        this.correlationID = correlationID;
        this.webDeviceId = webDeviceId;
        this.notificationMessage = notificationMessage;
        this.createdTS = createdTS;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(final String userId) {
        this.userId = userId;
    }

    public String getCorrelationID() {
        return correlationID;
    }

    public void setCorrelationID(final String correlationID) {
        this.correlationID = correlationID;
    }

    public String getWebDeviceId() {
        return webDeviceId;
    }

    public void setWebDeviceId(final String webDeviceId) {
        this.webDeviceId = webDeviceId;
    }

    public String getNotificationMessage() {
        return notificationMessage;
    }

    public void setNotificationMessage(final String notificationMessage) {
        this.notificationMessage = notificationMessage;
    }

    public Date getCreatedTS() {
        return createdTS;
    }

    public void setCreatedTS(final Date createdTS) {
        this.createdTS = createdTS;
    }

    /**
     * @return the notificationUserActionResponse
     */
    public NotificationUserActionResponse getNotificationUserActionResponse() {
        return notificationUserActionResponse;
    }

    /**
     * @param notificationUserActionResponse
     *            the notificationUserActionResponse to set
     */
    public void setNotificationUserActionResponse(final NotificationUserActionResponse notificationUserActionResponse) {
        this.notificationUserActionResponse = notificationUserActionResponse;
    }
}
