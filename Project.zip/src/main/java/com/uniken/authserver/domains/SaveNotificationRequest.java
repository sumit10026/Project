/**
 * 
 */
package com.uniken.authserver.domains;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.relid.notification.Action;
import com.uniken.domains.relid.notification.Message;
import com.uniken.domains.relid.notification.NotificationControls;

/**
 * @author Chetan Patil
 */
public class SaveNotificationRequest
        implements
        NotificationErrorCodes {

    public static final String USER_ID = "user_id";
    public static final String USER_TYPE = "user_type";
    public static final String MESSAGE = "msg";
    public static final String NOTIFICATION_MESSAGE = "notification_msg";
    public static final String ACTIONS = "actions";
    public static final String ACTION_PERFORMED = "action_performed";
    public static final String ENTERPRISE_ID = "enterprise_id";
    public static final String APP_UUID = "app_uuid";
    public static final String APP_ID = "app_id";
    public static final String EXPIRES_IN = "expires_in";
    public static final String REQUEST_ACCEPT_TS = "request_accept_ts";
    public static final String CALLBACK_URL = "callback_url";
    public static final String DS_REQUIRED = "ds_required";
    public static final String MSG_TYPE_STR = "msg_type";
    public static final String MODE_PREF_STR = "mode_pref";
    public static final String SMS_MSG_STR = "sms_msg";
    public static final String CALL_MSG_STR = "call_msg";
    public static final String HASH_SPEC_STR = "hash_spec";
    public static final String MSG_ID = "msg_id";
    public static final String NOTIFICATION_REQUESTER_NAME = "notification_requester_name";
    public static final String NOTIFICATION_REQUESTER_IP = "notification_requester_ip";

    public static final String NOTIFICATION_CONTROLS = "controls";
    public static final String DEVICE_TO_BE_ACTIVATED = "device_to_be_activated";

    @SerializedName(REQUEST_ACCEPT_TS)
    @Field(REQUEST_ACCEPT_TS)
    private Date reqAcceptTime;

    @SerializedName(MSG_ID)
    @Field(MSG_ID)
    private String msgId;

    @SerializedName(ENTERPRISE_ID)
    @Field(ENTERPRISE_ID)
    private String enterpriseId;

    @SerializedName(APP_UUID)
    @Field(APP_UUID)
    private String appUuid;

    @SerializedName(APP_ID)
    @Field(APP_ID)
    private String appId;

    @SerializedName(USER_ID)
    @Field(USER_ID)
    private String userId;

    @SerializedName(USER_TYPE)
    @Field(USER_TYPE)
    private String userType;

    @SerializedName(MESSAGE)
    @Field(MESSAGE)
    private List<Message> msg;

    @SerializedName(NOTIFICATION_MESSAGE)
    @Field(NOTIFICATION_MESSAGE)
    private Message notificationMsg;

    @SerializedName(EXPIRES_IN)
    @Field(EXPIRES_IN)
    private int expiresIn;

    @SerializedName(CALLBACK_URL)
    @Field(CALLBACK_URL)
    private String callbackUrl;

    @SerializedName(ACTIONS)
    @Field(ACTIONS)
    private List<Action> actions;

    @SerializedName(DS_REQUIRED)
    @Field(DS_REQUIRED)
    private boolean dsRequired;

    @SerializedName(ACTION_PERFORMED)
    @Field(ACTION_PERFORMED)
    private boolean actionPerformed;

    @SerializedName(MSG_TYPE_STR)
    @Field(MSG_TYPE_STR)
    private String msgType;

    @SerializedName(MODE_PREF_STR)
    @Field(MODE_PREF_STR)
    private String modePref;

    @SerializedName(SMS_MSG_STR)
    @Field(SMS_MSG_STR)
    private String smsMsg;

    @SerializedName(CALL_MSG_STR)
    @Field(CALL_MSG_STR)
    private String callMsg;

    @SerializedName(NOTIFICATION_REQUESTER_NAME)
    @Field(NOTIFICATION_REQUESTER_NAME)
    private String notificationRequesterName;

    @SerializedName(NOTIFICATION_REQUESTER_IP)
    @Field(NOTIFICATION_REQUESTER_IP)
    private String notificationRequesterIP;

    @SerializedName(NOTIFICATION_CONTROLS)
    @Field(NOTIFICATION_CONTROLS)
    private NotificationControls controls;

    @SerializedName(DEVICE_TO_BE_ACTIVATED)
    @Field(DEVICE_TO_BE_ACTIVATED)
    private String deviceToBeActivated;

    /**
     * @return the msgId
     */
    public String getMsgId() {
        return msgId;
    }

    /**
     * @param msgId
     *            the msgId to set
     */
    public void setMsgId(final String msgId) {
        this.msgId = msgId;
    }

    /**
     * @return the enterpriseId
     */
    public String getEnterpriseId() {
        return enterpriseId;
    }

    /**
     * @param enterpriseId
     *            the enterpriseId to set
     */
    public void setEnterpriseId(final String enterpriseId) {
        this.enterpriseId = enterpriseId;
    }

    /**
     * @return the appUuid
     */
    public String getAppUuid() {
        return appUuid;
    }

    /**
     * @param appUuid
     *            the appUuid to set
     */
    public void setAppUuid(final String appUuid) {
        this.appUuid = appUuid;
    }

    /**
     * @return the appId
     */
    public String getAppId() {
        return appId;
    }

    /**
     * @param appId
     *            the appId to set
     */
    public void setAppId(final String appId) {
        this.appId = appId;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @return the userType
     */
    public String getUserType() {
        if (null == userType)
            userType = "";
        return userType;
    }

    /**
     * @param userType
     *            the userType to set
     */
    public void setUserType(final String userType) {
        this.userType = userType;
    }

    /**
     * @return the msg
     */
    public List<Message> getMsg() {
        return msg;
    }

    /**
     * @param msg
     *            the msg to set
     */
    public void setMsg(final List<Message> msg) {
        this.msg = msg;
    }

    /**
     * @return the notificationMsg
     */
    public Message getNotificationMsg() {
        return notificationMsg;
    }

    /**
     * @param notificationMsg
     *            the notificationMsg to set
     */
    public void setNotificationMsg(final Message notificationMsg) {
        this.notificationMsg = notificationMsg;
    }

    /**
     * @return the expiresIn
     */
    public Integer getExpiresIn() {
        return expiresIn;
    }

    /**
     * @param expiresIn
     *            the expiresIn to set
     */
    public void setExpiresIn(final Integer expiresIn) {
        this.expiresIn = expiresIn;
    }

    /**
     * @return the callbackUrl
     */
    public String getCallbackUrl() {
        return callbackUrl;
    }

    /**
     * @param callbackUrl
     *            the callbackUrl to set
     */
    public void setCallbackUrl(final String callbackUrl) {
        this.callbackUrl = callbackUrl;
    }

    /**
     * @return the actions
     */
    public List<Action> getActions() {
        return actions;
    }

    /**
     * @param actions
     *            the actions to set
     */
    public void setActions(final List<Action> actions) {
        this.actions = actions;
    }

    public boolean isActionPerformed() {
        return actionPerformed;
    }

    public void setActionPerformed(final boolean actionPerformed) {
        this.actionPerformed = actionPerformed;
    }

    public boolean isDsRequired() {
        return dsRequired;
    }

    public void setDsRequired(final boolean dsRequired) {
        this.dsRequired = dsRequired;
    }

    /**
     * @return the msgType
     */
    public String getMsgType() {
        return msgType;
    }

    /**
     * @param msgType
     *            the msgType to set
     */
    public void setMsgType(final String msgType) {
        this.msgType = msgType;
    }

    /**
     * @return the modePref
     */
    public String getModePref() {
        return modePref;
    }

    /**
     * @param modePref
     *            the modePref to set
     */
    public void setModePref(final String modePref) {
        this.modePref = modePref;
    }

    /**
     * @return the smsMsg
     */
    public String getSmsMsg() {
        return smsMsg;
    }

    /**
     * @param smsMsg
     *            the smsMsg to set
     */
    public void setSmsMsg(final String smsMsg) {
        this.smsMsg = smsMsg;
    }

    /**
     * @return the callMsg
     */
    public String getCallMsg() {
        return callMsg;
    }

    /**
     * @param callMsg
     *            the callMsg to set
     */
    public void setCallMsg(final String callMsg) {
        this.callMsg = callMsg;
    }

    /**
     * @return the reqAcceptTime
     */
    public Date getReqAcceptTime() {
        return reqAcceptTime;
    }

    /**
     * @param reqAcceptTime
     *            the reqAcceptTime to set
     */
    public void setReqAcceptTime(final Date reqAcceptTime) {
        this.reqAcceptTime = reqAcceptTime;
    }

    /**
     * @return the notificationRequesterName
     */
    public String getNotificationRequesterName() {
        return notificationRequesterName;
    }

    /**
     * @param notificationRequesterName
     *            the notificationRequesterName to set
     */
    public void setNotificationRequesterName(final String notificationRequesterName) {
        this.notificationRequesterName = notificationRequesterName;
    }

    /**
     * @return the notificationRequesterIP
     */
    public String getNotificationRequesterIP() {
        return notificationRequesterIP;
    }

    /**
     * @param notificationRequesterIP
     *            the notificationRequesterIP to set
     */
    public void setNotificationRequesterIP(final String notificationRequesterIP) {
        this.notificationRequesterIP = notificationRequesterIP;
    }

    /**
     * @return the controls
     */
    public NotificationControls getControls() {
        return controls;
    }

    /**
     * @param controls
     *            the controls to set
     */
    public void setControls(final NotificationControls controls) {
        this.controls = controls;
    }

    /**
     * @return the deviceToBeActivated
     */
    public String getDeviceToBeActivated() {
        return deviceToBeActivated;
    }

    /**
     * @param deviceToBeActivated
     *            the deviceToBeActivated to set
     */
    public void setDeviceToBeActivated(final String deviceToBeActivated) {
        this.deviceToBeActivated = deviceToBeActivated;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("NotificationRequest [msgId=").append(msgId).append(", enterpriseId=").append(enterpriseId)
                .append(", userId=").append(userId).append(", msg=").append(msg.toString()).append(", notificationMsg=")
                .append(notificationMsg).append(", expiresIn=").append(expiresIn).append(", callbackUrl=")
                .append(callbackUrl).append(", actions=").append(actions).append(", actionPerformed=")
                .append(actionPerformed).append(", dsRequired=").append(dsRequired).append(", msgType=").append(msgType)
                .append(", modePref=").append(modePref).append(", smsMsg=").append(smsMsg).append(", callMsg=")
                .append(callMsg).append(", notificationRequesterName=").append(notificationRequesterName)
                .append(", notificationRequesterIP=").append(notificationRequesterIP).append(", controls=")
                .append(controls.toString()).append("]");
        return builder.toString();
    }

}
