package com.uniken.authserver.domains;

public class GenericResponse {
    private String success;
    private String error;

    public GenericResponse() {
        this("", "");
    }

    public GenericResponse(final String success, final String error) {
        this.success = success;
        this.error = error;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(final String success) {
        this.success = success;
    }

    public String getError() {
        return error;
    }

    public void setError(final String error) {
        this.error = error;
    }
}
