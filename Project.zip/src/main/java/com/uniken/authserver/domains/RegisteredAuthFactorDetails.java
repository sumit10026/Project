package com.uniken.authserver.domains;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.enums.auth.AuthTypeStatus;

public class RegisteredAuthFactorDetails {
    private String regAuthTypeId;
    private AuthType authType;
    private AuthTypeStatus authTypeStatus;
    private String authFactorDesc;
    private String authFactorName;
    private Date createdTS;
    private Date updatedTS;
    private String base64EncodedAuthFactorLogo;
    private boolean isAllowedToDeleteOrDisableAuthFactor;
    private final String userRecognizedAuthTypeName;

    private static final String DATE_FORMAT = "dd/MM/yyyy";

    public RegisteredAuthFactorDetails(final String regAuthTypeId, final Date createdTS, final Date updatedTS,
            final AuthType authType, final AuthTypeStatus authTypeStatus, final String authFactorDesc,
            final String authFactorName, final String base64EncodedAuthFactorLogo,
            final boolean isAllowedToDeleteOrDisableAuthFactor, final String userRecognizedAuthTypeName) {
        this.regAuthTypeId = regAuthTypeId;
        this.authType = authType;
        this.authTypeStatus = authTypeStatus;
        this.authFactorDesc = authFactorDesc;
        this.authFactorName = authFactorName;
        this.createdTS = createdTS;
        this.updatedTS = updatedTS;
        this.base64EncodedAuthFactorLogo = base64EncodedAuthFactorLogo;
        this.isAllowedToDeleteOrDisableAuthFactor = isAllowedToDeleteOrDisableAuthFactor;
        this.userRecognizedAuthTypeName = userRecognizedAuthTypeName;
    }

    public Date getCreatedTS() {
        return createdTS;
    }

    public void setCreatedTS(final Date createdTS) {
        this.createdTS = createdTS;
    }

    public Date getUpdatedTS() {
        return updatedTS;
    }

    public void setUpdatedTS(final Date updatedTS) {
        this.updatedTS = updatedTS;
    }

    public AuthType getAuthType() {
        return authType;
    }

    public void setAuthType(final AuthType authType) {
        this.authType = authType;
    }

    public AuthTypeStatus getAuthTypeStatus() {
        return authTypeStatus;
    }

    public void setAuthTypeStatus(final AuthTypeStatus authTypeStatus) {
        this.authTypeStatus = authTypeStatus;
    }

    private String getFormattedDate(final Date date) {
        return date == null ? "" : new SimpleDateFormat(DATE_FORMAT).format(date);
    }

    public String getRegAuthTypeId() {
        return regAuthTypeId;
    }

    public void setregAuthTypeId(final String regAuthTypeId) {
        this.regAuthTypeId = regAuthTypeId;
    }

    public String getAuthFactorDesc() {
        return authFactorDesc;
    }

    public void setAuthFactorDesc(final String authFactorDesc) {
        this.authFactorDesc = authFactorDesc;
    }

    public String getAuthFactorName() {
        return authFactorName;
    }

    public void setAuthFactorName(final String authFactorName) {
        this.authFactorName = authFactorName;
    }

    public String getBase64EncodedAuthFactorLogo() {
        return base64EncodedAuthFactorLogo;
    }

    public void setBase64EncodedAuthFactorLogo(final String base64EncodedAuthFactorLogo) {
        this.base64EncodedAuthFactorLogo = base64EncodedAuthFactorLogo;
    }

    public boolean isAllowedToDeleteOrDisableAuthFactor() {
        return isAllowedToDeleteOrDisableAuthFactor;
    }

    public void setAllowedToDeleteOrDisableAuthFactor(final boolean isAllowedToDeleteOrDisableAuthFactor) {
        this.isAllowedToDeleteOrDisableAuthFactor = isAllowedToDeleteOrDisableAuthFactor;
    }

    public String getUserRecognizedAuthTypeName() {
        return userRecognizedAuthTypeName;
    }
}
