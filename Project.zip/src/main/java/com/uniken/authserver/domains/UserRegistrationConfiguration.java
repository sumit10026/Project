package com.uniken.authserver.domains;

import lombok.Data;

@Data
public class UserRegistrationConfiguration {

    private boolean rememberMe;

    private boolean password;
    private boolean smsOtp;
    private boolean emailOtp;
    private boolean fidoPlatform;
    private boolean fidoRoaming;

    private String mobileNumberRegex;
    private String emailRegex;

    private PassPolicy passPolicy;
    private boolean showPassStrength;

    private int delayBeforeRedirect;

    private boolean alwaysAskForPassword;
}
