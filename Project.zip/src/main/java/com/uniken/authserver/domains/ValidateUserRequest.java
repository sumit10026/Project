package com.uniken.authserver.domains;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_EMPTY)
public class ValidateUserRequest {

    // @NotBlank(message = "web_device_parameter_checksum is mandatory")
    @JsonProperty("web_device_parameter_checksum")
    private String webDeviceParameterChecksum;

    @NotBlank(message = "web_device_parameters is mandatory")
    @JsonProperty("web_device_parameters")
    private String webDeviceParameters;

    @NotBlank(message = "username is mandatory")
    @JsonProperty("username")
    private String userName;

    @JsonProperty("auth_type")
    private String authType;

    @JsonProperty("auth_value")
    private String authValue;

    public String getUserName() {
        return userName;
    }

    public void setUserName(final String userName) {
        this.userName = userName;
    }

    public String getWebDeviceParameterChecksum() {
        return webDeviceParameterChecksum;
    }

    public void setWebDeviceParameterChecksum(final String webDeviceParameterChecksum) {
        this.webDeviceParameterChecksum = webDeviceParameterChecksum;
    }

    public String getWebDeviceParameters() {
        return webDeviceParameters;
    }

    public void setWebDeviceParameters(final String webDeviceParameters) {
        this.webDeviceParameters = webDeviceParameters;
    }

    public String getAuthType() {
        return authType;
    }

    public void setAuthType(final String authType) {
        this.authType = authType;
    }

    public String getAuthValue() {
        return authValue;
    }

    public void setAuthValue(final String authValue) {
        this.authValue = authValue;
    }

}
