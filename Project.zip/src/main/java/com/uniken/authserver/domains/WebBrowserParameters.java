package com.uniken.authserver.domains;

public enum WebBrowserParameters {
    USERAGENT_STR("userAgent"),
    WEBDRIVER_STR("webdriver"),
    LANGUAGE_STR("language"),
    COLORDEPTH_STR("colorDepth"),
    DEVICEMEMORY_STR("deviceMemory"),
    PIXELRATIO_STR("pixelRatio"),
    HARDWARE_CONCURRENCY_STR("hardwareConcurrency"),
    SCREEN_RESOLUTION_STR("screenResolution"),
    AVAILABLE_SCREEN_RESOLUTION_STR("availableScreenResolution"),
    TIMEZONE_OFFSET_STR("timezoneOffset"),
    TIMEZONE_STR("timezone"),
    SCREEN_STORAGE_STR("sessionStorage"),
    LOCAL_STORAGE_STR("localStorage"),
    INDEXED_DB_STR("indexedDb"),
    ADD_BEHAVIOR_STR("addBehavior"),
    OPEN_DATABASE_STR("openDatabase"),
    CPU_CLASS_STR("cpuClass"),
    PLATFORM_STR("platform"),
    DONOTTRACK_STR("doNotTrack"),
    PLUGINS_STR("plugins"),
    WEBBGL_VENDORANDRENDERER_STR("webglVendorAndRenderer"),
    ADBLOCK_STR("adBlock"),
    HAS_TIED_LANGUAGES_STR("hasLiedLanguages"),
    HAS_LIED_RESOLUTION_STR("hasLiedResolution"),
    HAS_LIED_OS_STR("hasLiedOs"),
    HAS_LIED_BROWSER_STR("hasLiedBrowser"),
    TOUCH_SUPPORT_STR("touchSupport"),
    FONTS_STR("fonts"),
    FONTS_FLASH_STR("fontsFlash"),
    AUDIO_STR("audio"),
    ENUMERATE_DEVICES_STR("enumerateDevices");

    private String browserParameterKey;

    WebBrowserParameters(final String browserParameterKey) {
        this.browserParameterKey = browserParameterKey;
    }

    public String getBrowserParameterKey() {
        return browserParameterKey;
    }
}
