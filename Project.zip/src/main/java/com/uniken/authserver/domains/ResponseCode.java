package com.uniken.authserver.domains;

public interface ResponseCode {

    short getCode();

    String getMessage();
}
