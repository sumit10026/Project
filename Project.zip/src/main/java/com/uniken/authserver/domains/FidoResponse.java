package com.uniken.authserver.domains;

import java.util.Map;

import com.fasterxml.jackson.databind.JsonNode;

public class FidoResponse {

    private Map<String, Integer> authGenerationAttemptsCounter;
    private JsonNode jsonNode;
    private boolean isLevel1AuthenticationPending;

    public FidoResponse() {
    }

    public FidoResponse(final Map<String, Integer> authGenerationAttemptsCounter, final JsonNode jsonNode,
            final boolean isLevel1AuthenticationPending) {
        this.authGenerationAttemptsCounter = authGenerationAttemptsCounter;
        this.jsonNode = jsonNode;
        this.isLevel1AuthenticationPending = isLevel1AuthenticationPending;
    }

    public Map<String, Integer> getAuthGenerationAttemptsCounter() {
        return authGenerationAttemptsCounter;
    }

    public void setAuthGenerationAttemptsCounter(final Map<String, Integer> authGenerationAttemptsCounter) {
        this.authGenerationAttemptsCounter = authGenerationAttemptsCounter;
    }

    public JsonNode getJsonNode() {
        return jsonNode;
    }

    public void setJsonNode(final JsonNode jsonNode) {
        this.jsonNode = jsonNode;
    }

    public boolean isLevel1AuthenticationPending() {
        return isLevel1AuthenticationPending;
    }

    public void setLevel1AuthenticationPending(final boolean isLevel1AuthenticationPending) {
        this.isLevel1AuthenticationPending = isLevel1AuthenticationPending;
    }

}
