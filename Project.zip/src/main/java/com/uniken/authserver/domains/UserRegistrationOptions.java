package com.uniken.authserver.domains;

import lombok.Data;

@Data
public class UserRegistrationOptions {

    private String username;
    private String mobileNumber;
    private String email;
    private UserRegistrationConfiguration configuration;

}
