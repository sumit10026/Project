package com.uniken.authserver.domains;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonProperty;

public class AccountRecoveryTokenDetails
        implements
        Serializable {

    private static final long serialVersionUID = 7982078733700013185L;
    public static final String FIRST_LEVEL_FACTOR = "first_level_factor";
    public static final String AUTH_FACTOR_NEEDS_TO_RESET = "auth_factor_needs_to_reset";
    public static final String REDIRECT_URI = "redirect_uri";
    public static final String USER_ID = "user_id";
    public static final String GU_ID = "gu_id";

    @JsonProperty(FIRST_LEVEL_FACTOR)
    private String firstLevelFactor;

    @JsonProperty(AUTH_FACTOR_NEEDS_TO_RESET)
    private String authFactorNeedsToReset;

    @JsonProperty(REDIRECT_URI)
    private String redirectUri;

    @JsonProperty(USER_ID)
    private String userId;

    @JsonProperty(GU_ID)
    private String guId;

    public String getFirstLevelFactor() {
        return firstLevelFactor;
    }

    public void setFirstLevelFactor(final String firstLevelFactor) {
        this.firstLevelFactor = firstLevelFactor;
    }

    public String getAuthFactorNeedsToReset() {
        return authFactorNeedsToReset;
    }

    public void setAuthFactorNeedsToReset(final String authFactorNeedsToReset) {
        this.authFactorNeedsToReset = authFactorNeedsToReset;
    }

    public String getRedirectUri() {
        return redirectUri;
    }

    public void setRedirectUri(final String redirectUri) {
        this.redirectUri = redirectUri;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(final String userId) {
        this.userId = userId;
    }

    public String getGuId() {
        return guId;
    }

    public void setGuId(final String guId) {
        this.guId = guId;
    }

}
