package com.uniken.authserver.domains;

import javax.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_EMPTY)
public class ValidatedBrowserRequest {

    @NotBlank(message = "webDeviceUuid is mandatory")
    @JsonProperty("web_device_uuid")
    private String webDeviceUuid;

    @NotBlank(message = "loginId is mandatory")
    @JsonProperty("login_id")
    private String loginId;

    public String getWebDeviceUuid() {
        return webDeviceUuid;
    }

    public void setWebDeviceUuid(final String webDeviceUuid) {
        this.webDeviceUuid = webDeviceUuid;
    }

    public String getLoginId() {
        return loginId;
    }

    public void setLoginId(final String loginId) {
        this.loginId = loginId;
    }

}
