package com.uniken.authserver.config;

import java.net.UnknownHostException;
import java.time.Duration;

import javax.annotation.Resource;

import com.uniken.authserver.utility.PropertyConstants;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.ServletListenerRegistrationBean;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.MongoDatabaseFactory;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.session.data.mongo.JdkMongoSessionConverter;
import org.springframework.session.data.mongo.MongoIndexedSessionRepository;
import org.springframework.session.data.mongo.config.annotation.web.http.EnableMongoHttpSession;

import com.uniken.authserver.utility.Constants;

// FIXME
@EnableMongoHttpSession
public class HttpSessionConfig {

    public static final String COLLECTION_NAME = "web_dev_sessions";

    public static final Integer DEFAULT_MAX_INACTIVE_INTERVAL_IN_SECONDS = 60;

    private static final Logger LOG = LoggerFactory.getLogger(HttpSessionConfig.class);

    @Resource(name = Constants.RESOURCE_AUTHSERVERDB_MONGO_TEMPLATE)
    private MongoTemplate relIddbMongoTemplate;

    @Autowired
    private CustomApplicationEventPublisher customApplicationEventPublisher;

    @Bean
    public JdkMongoSessionConverter getSessionConverter() {
        LOG.info("getSessionConverter() entered");
        return new JdkMongoSessionConverter(Duration.ofMinutes(5));
    }

    @Bean
    public MongoOperations mongoOperations() throws UnknownHostException {
        LOG.info("mongoOperations is being called");
        return relIddbMongoTemplate;
    }

    @Bean
    public MongoDatabaseFactory connectionFactory() {
        LOG.info("connectionFactory is being called");
        return relIddbMongoTemplate.getMongoDbFactory();
    }

    @Bean
    public ServletListenerRegistrationBean<HttpSessionEventPublisher> httpSessionEventPublisher() {
        return new ServletListenerRegistrationBean<HttpSessionEventPublisher>(new HttpSessionEventPublisher());
    }

    @Bean
    @Primary
    public MongoIndexedSessionRepository customMongoHttpSessionRepository() throws UnknownHostException {

        CustomMongoHttpSessionRepository customMongoHttpSessionRepository = new CustomMongoHttpSessionRepository(mongoOperations());

        try {
            customMongoHttpSessionRepository.setMaxInactiveIntervalInSeconds(PropertyConstants.HTTP_SESSION_MAX_INACTIVE_INTERVAL_IN_SECONDS);
        } catch (NumberFormatException exception) {
            customMongoHttpSessionRepository.setMaxInactiveIntervalInSeconds(DEFAULT_MAX_INACTIVE_INTERVAL_IN_SECONDS);
        }

        customMongoHttpSessionRepository.setCollectionName(COLLECTION_NAME);
        customMongoHttpSessionRepository.setApplicationEventPublisher(this.customApplicationEventPublisher);
        return customMongoHttpSessionRepository;
    }

}
