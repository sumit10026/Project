package com.uniken.authserver.config;

import java.io.IOException;
import java.security.SecureRandom;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.oauth2.common.exceptions.UnauthorizedUserException;
import org.springframework.security.oauth2.provider.error.DefaultWebResponseExceptionTranslator;
import org.springframework.security.web.authentication.AbstractAuthenticationProcessingFilter;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.SavedRequestAwareAuthenticationSuccessHandler;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;
import org.springframework.util.CollectionUtils;

import com.google.api.client.util.Lists;
import com.uniken.authserver.exception.InvalidUserException;
import com.uniken.authserver.exception.SessionConflictedException;
import com.uniken.authserver.services.api.SecureCookieService;
import com.uniken.authserver.services.api.UserService;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.authserver.utility.AuthenticationUtils;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.InputValidationUtils;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.SessionConstants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.WebUserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.relid.user.UserBrowser;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.domains.user.vos.WebUserDetails;
import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;

public class OIDCAuthenticationFilter extends AbstractAuthenticationProcessingFilter {

    private static final Logger LOG = LoggerFactory.getLogger(OIDCAuthenticationFilter.class);

    private final Set<HttpMethod> allowedRequestMethods = new HashSet<>(Arrays.asList(HttpMethod.POST));

    private final DefaultWebResponseExceptionTranslator exceptionTranslator = new DefaultWebResponseExceptionTranslator();

    private UserService userService;

    private final SecureRandom rand = new SecureRandom(String.valueOf(System.currentTimeMillis()).getBytes());

    @Autowired
    private WebDevMasterService webDevMasterService;

    private SecureCookieService secureCookieService;

    protected OIDCAuthenticationFilter() {
        super(new AntPathRequestMatcher("/login", "POST"));
        setAuthenticationSuccessHandler(authenticationSuccessHandler());
        setAuthenticationFailureHandler(authenticationFailureHandler());
    }

    @SuppressWarnings("unchecked")
    @Override
    public Authentication attemptAuthentication(final HttpServletRequest request, final HttpServletResponse response) {

        Authentication authentication = null;
        final Map<String, Object> inputParameters = Utils.fetchAndValidateRequestInputParams(request);
        String username = null;

        try {

            username = ESAPI.validator().getValidInput("user_name_value",
                    request.getParameter(Constants.REQ_PARAM_USERNAME), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);

            if (allowedRequestMethods.contains(HttpMethod.GET)) {
                LOG.error("attemptAuthentication() : Invalid http method ");
                throw new AuthenticationServiceException("Authentication method not supported: " + request.getMethod());
            }

            /**
             * If there is mismatch between user name fetched from request &
             * from the request session, then terminate the flow as there might
             * be attempt of account overtaking.
             */
            final String validatedUsername = (String) request.getSession()
                    .getAttribute(SessionConstants.VALIDATED_USERNAME);

            final String currentUsername = (String) request.getSession()
                    .getAttribute(SessionConstants.CURRENT_USERNAME);

            if ((StringUtils.isNotBlank(validatedUsername) && !StringUtils.equals(validatedUsername, username))
                    || (StringUtils.isNotBlank(currentUsername) && !StringUtils.equals(currentUsername, username))) {

                // FIXME: Need to discuss
                // When user only authenticated for Level 1,
                // there will be no validated_username present in session.
                /*
                 * if (StringUtils.isBlank(validatedUsername) &&
                 * StringUtils.equals(username, (String)
                 * request.getSession().getAttribute(SessionConstants.
                 * CURRENT_USERNAME))) { // Reset the generation attempt counter
                 * userService.updateWebUserAuthGenerationAttemptCounter(
                 * username,
                 * SessionConstants.DEFAULT_AUTH_GENERATION_ATTEMPT_COUNTER); }
                 */

                throw new SessionConflictedException(
                        String.format("Session Conflicted Between Users. Expected User: %s, User from Request: %s",
                                validatedUsername, username));
            }

            LOG.info("attemptAuthentication() : Offered Auth Types to {} user: {}", currentUsername,
                    request.getSession().getAttribute(SessionConstants.OFFERED_AUTH_TYPES));

            /*
             * FIXME : Milestone 2 Checking if browser is blocked. If blocked
             * then throw exception
             */
            /*
             * if (webDevMasterService .isBrowserBlocked((String)
             * inputParameters.get(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR)
             * )) { throw new UnauthorizedUserException("unauthorized access");
             * }
             */

            // generating requuestorId and setting it in request
            Utils.generateRequestorId(request, request);

            // Validating Multi-Factor Authentication
            final Set<String> validatedAuthTypes = (Set<String>) request.getSession()
                    .getAttribute(SessionConstants.VALIDATED_AUTH_TYPES);
            final boolean loggedInUsingFido2fa = Boolean.TRUE
                    .equals(request.getSession().getAttribute(SessionConstants.LOGGED_IN_USING_FIDO_2FA));
            LOG.debug("loggedInUsingFido2fa: {}", loggedInUsingFido2fa);

            if (StringUtils.isNotBlank(validatedUsername) && !CollectionUtils.isEmpty(validatedAuthTypes)
                    && (validatedAuthTypes.size() >= 2 || (validatedAuthTypes.size() == 1
                            && validatedAuthTypes.contains(AuthType.FIDO.getName()) && loggedInUsingFido2fa))) {
                // Generate Authentication Token
                authentication = userService.generateAuthenticationTokenForUser(username);

                ESAPI.validator().getValidInput("SessionConstants.REQ_PARAM_MAP", SessionConstants.REQ_PARAM_MAP,
                        "HTTPHeaderName", Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);

                if (inputParameters.size() <= 0) {
                    throw new IllegalArgumentException("unauthorized access due to empty arguments");
                }
                request.getSession().setAttribute(SessionConstants.REQ_PARAM_MAP, inputParameters);

                final UserAuthInfoVO userAuthInfo = userService.getUserAuthInfoByUserName(username);

                if (userAuthInfo.getUserStatus() != RelIdUserStatus.ACTIVE
                        || (Boolean.FALSE.equals(userAuthInfo.isWebOnly()) && userAuthInfo.getRelIds().stream()
                                .filter(relid -> relid.getRelIdStatus().equals(RelIdUserStatus.ACTIVE))
                                .collect(Collectors.toList()).isEmpty())) {
                    throw new InvalidUserException("Unauthorized Access");
                }

                /**
                 * Unblocking the user, if it is blocked, as after the
                 * completion of cooling period, user can be authenticated in
                 * the system.
                 **/
                final WebUserDetails webUserDetails = userAuthInfo.getWebUserDetails();
                if (webUserDetails != null && webUserDetails.getWebUserStatus() != null
                        && WebUserStatus.BLOCKED.name().equals(webUserDetails.getWebUserStatus().name())) {
                    webUserDetails.setWebUserStatus(WebUserStatus.ACTIVE);
                    webUserDetails.setLastBlockedInterval(0);
                    // Set the attempt counter list as null & handle respective
                    // scenario in MFA flow
                    webUserDetails.setWebAttemptCounter(Lists.newArrayList());
                    userService.unblockWebUser(webUserDetails, userAuthInfo.getUserId());
                } else {
                    userService.updateWebUserAttemptCounter(username, Lists.newArrayList());
                }

                // Reset the generation attempt counter
                // userService.updateWebUserAuthGenerationAttemptCounter(validatedUsername,
                // PropertyConstants.DEFAULT_AUTH_GENERATION_ATTEMPT_COUNTER);
                /*
                 * request.getSession().setAttribute(SessionConstants.
                 * AUTH_GENERATION_ATTEMPT_COUNTER,
                 * PropertyConstants.DEFAULT_AUTH_GENERATION_ATTEMPT_COUNTER);
                 */

                EventLogger.log(EventId.RelidAuthServer.AUTHENTICATION_COMPLETED, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request),
                        "Authentication Successful For " + validatedAuthTypes);

            } else {
                /*
                 * if (StringUtils.isBlank(validatedUsername) &&
                 * StringUtils.equals(username, (String)
                 * request.getSession().getAttribute(SessionConstants.
                 * CURRENT_USERNAME))) { // Reset the generation attempt counter
                 * // userService.updateWebUserAuthGenerationAttemptCounter(
                 * username, //
                 * PropertyConstants.DEFAULT_AUTH_GENERATION_ATTEMPT_COUNTER);
                 * request.getSession().setAttribute(SessionConstants.
                 * AUTH_GENERATION_ATTEMPT_COUNTER,
                 * PropertyConstants.DEFAULT_AUTH_GENERATION_ATTEMPT_COUNTER); }
                 */

                request.getSession().setAttribute(SessionConstants.ERROR_DISPLAY_MSG,
                        PropertyConstants.DEFAULT_GLOBAL_ERROR_PAGE_MSG);
                LOG.info("attemptAuthentication() : Offered Auth Types to {} user: {}", currentUsername,
                        request.getSession().getAttribute(SessionConstants.OFFERED_AUTH_TYPES));
                LOG.error("attemptAuthentication() : User is not authenticated");
                throw new UnauthorizedUserException("unauthorized access");
            }
        } catch (final SessionConflictedException e) {
            request.getSession().setAttribute(SessionConstants.IS_REDIRECT_TO_ERROR_PAGE, true);

            EventLogger.log(EventId.RelidAuthServer.INIT_USER_AUTHENTICATION_FAILED, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), username, AuthenticationUtils.getUserAgent(request),
                    "Session conflicted"); // FIXME Add proper message

            throw new InternalAuthenticationServiceException("Could not authenticate the user", e);

        } catch (final Exception e) {
            // LOG.error("attemptAuthentication() : Exception occurred : ", e);
            // try {
            // final ResponseEntity<?> responseEntity =
            // exceptionTranslator.translate(e);
            // response.setStatus(responseEntity.getStatusCodeValue());
            // response.getWriter().write(Utils.convertObjectToJson(responseEntity.getBody()));
            // } catch (final Exception e1) {
            // LOG.error("attemptAuthentication() : Exception occurred while
            // parsing exception", e1.getCause());
            // response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR.value());
            // }

            EventLogger.log(EventId.RelidAuthServer.INIT_USER_AUTHENTICATION_FAILED, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), username, AuthenticationUtils.getUserAgent(request),
                    "Could not authenticate the user"); // FIXME Add proper
                                                        // message

            throw new InternalAuthenticationServiceException("Could not authenticate the user", e);

        }
        return authentication;
    }

    /**
     * Authentication success handler.
     *
     * @return the authentication success handler
     */
    private AuthenticationSuccessHandler authenticationSuccessHandler() {
        return new SavedRequestAwareAuthenticationSuccessHandler() {

            @Override
            public void onAuthenticationSuccess(final HttpServletRequest request, final HttpServletResponse response,
                    final Authentication authentication) throws IOException, ServletException {

                response.setHeader("X-FRAME-OPTIONS", "DENY");
                final String username = authentication.getName();
                LOG.info("onAuthenticationSuccess() -> Authentication Successful for user: {}", username);

                // if FIDO platform authenticator is available, ask user for
                // FIDO registration
                
                //Disable support of Platform Authenticator
                /*
                 * final String fidoPlatformAuthenticatorAvailableParam =
                 * request .getParameter(Constants.
                 * REQ_PARAM_FIDO_PLATFORM_AUTHENTICATOR_AVAILABLE); final
                 * boolean hasUserSelectedRememberMe = InputValidationUtils
                 * .validateRememberMeParam(request.getParameter(Constants.
                 * REQ_PARAM_REMEMBER_ME), false); if
                 * (!Utils.isNullOrEmpty(fidoPlatformAuthenticatorAvailableParam
                 * )) { final boolean fidoPlatformAuthenticatorAvailable =
                 * Boolean
                 * .parseBoolean(fidoPlatformAuthenticatorAvailableParam); final
                 * Object userLoggedInUsingFidoPlatformAuthAttr =
                 * request.getSession() .getAttribute(SessionConstants.
                 * LOGGED_IN_USING_FIDO_PLATFORM_AUTH); final boolean
                 * userLoggedInUsingFidoPlatformAuth = !Utils
                 * .isNull(userLoggedInUsingFidoPlatformAuthAttr) && (boolean)
                 * userLoggedInUsingFidoPlatformAuthAttr; LOG.debug(
                 * "onAuthenticationSuccess() -> Is FIDO platform authenticator is available: {}, user logged in using fido platform auth: {}. User: {}"
                 * , fidoPlatformAuthenticatorAvailable,
                 * userLoggedInUsingFidoPlatformAuth, username); final
                 * UserBrowser browser =
                 * secureCookieService.getAssociatedUserBrowserBySecureCookie(
                 * request, username); boolean userOptedInForFidoReg = true; if
                 * (browser != null && browser.isUserOptedOutForFidoReg()) {
                 * userOptedInForFidoReg = false; } if
                 * ((fidoPlatformAuthenticatorAvailable &&
                 * !userLoggedInUsingFidoPlatformAuth) &&
                 * PropertyConstants.AUTOMATIC_FIDO_REGISTRATION_ENABLED &&
                 * (PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.
                 * isRememberMe() && hasUserSelectedRememberMe) &&
                 * userOptedInForFidoReg) { if
                 * (!AuthenticationUtils.isAuthTypeAllowed(AuthType.FIDO.getName
                 * ())) { LOG.debug(
                 * "onAuthenticationSuccess() -> FIDO is disabled at the system level. Not asking the user for FIDO registration. User: {}"
                 * , username); } else { LOG.
                 * info("onAuthenticationSuccess() -> Asking user for FIDO registration. User: {}"
                 * , username);
                 * response.sendRedirect("user-portal/fido-register?r=" +
                 * rand.nextInt()); return; } } }
                 */

                super.onAuthenticationSuccess(request, response, authentication);
            }
        };
    }

    /**
     * Authentication failure handler.
     *
     * @return the authentication failure handler
     */
    private AuthenticationFailureHandler authenticationFailureHandler() {
        return new AuthenticationFailureHandler() {

            @Override
            public void onAuthenticationFailure(final HttpServletRequest request, final HttpServletResponse response,
                    final AuthenticationException exception) throws IOException, ServletException {

                final Map<String, Object> inputParams = Utils.fetchAndValidateRequestInputParams(request);
                final String username = (String) inputParams.get(Constants.REQ_PARAM_USERNAME);

                LOG.error("authenticationFailureHandler() -> Authentication Failed for user: {}", username);

                final Map<String, Object> excetpionAttributes = new HashMap<>();
                excetpionAttributes.put("exception", ExceptionUtils.getStackTrace(exception));
                request.getSession().setAttribute(SessionConstants.EXCEPTION_ATTRS_MAP, excetpionAttributes);

                if (InputValidationUtils.isRedirectToErrorPage(request.getSession())) {
                    response.sendRedirect("error");
                } else {
                    response.sendRedirect("login");
                }
            }
        };
    }

    public void setUserService(final UserService userService) {
        this.userService = userService;
    }

    public void setWebDevMasterService(final WebDevMasterService webDevMasterService) {
        this.webDevMasterService = webDevMasterService;
    }

    public void setSecureCookieService(final SecureCookieService secureCookieService) {
        this.secureCookieService = secureCookieService;
    }

}
