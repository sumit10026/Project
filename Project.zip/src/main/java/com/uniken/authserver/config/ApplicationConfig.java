/**
 * 
 */
package com.uniken.authserver.config;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeSet;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.common.util.OAuth2Utils;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.oauth2.provider.token.AuthenticationKeyGenerator;
import org.springframework.security.oauth2.provider.token.DefaultAuthenticationKeyGenerator;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.TokenStore;

import com.uniken.authserver.utility.RequestParams;
import com.uniken.domains.enums.appconfig.ModuleNames;
import com.uniken.domains.enums.auth.OAuthGrantTypes;

/**
 * @author Kushal Jaiswal
 */
@Configuration
public class ApplicationConfig {

    @Bean("authenticationKeyGenerator")
    public AuthenticationKeyGenerator getDefaultAuthenticationKeyGenerator() {
        return new DefaultAuthenticationKeyGenerator() {
            private static final String CLIENT_ID = "client_id";

            private static final String SCOPE = "scope";

            private static final String USERNAME = "username";

            @Override
            public String extractKey(final OAuth2Authentication authentication) {
                final Map<String, String> values = new LinkedHashMap<>();
                final OAuth2Request authorizationRequest = authentication.getOAuth2Request();
                if (!authentication.isClientOnly()) {
                    values.put(USERNAME, authentication.getName());
                }
                values.put(CLIENT_ID, authorizationRequest.getClientId());
                if (authorizationRequest.getScope() != null) {
                    values.put(SCOPE, OAuth2Utils.formatParameterList(new TreeSet<>(authorizationRequest.getScope())));
                }

                final Map<String, String> requestParameters = authorizationRequest.getRequestParameters();
                if (requestParameters.get(OAuth2Utils.GRANT_TYPE) != null
                        && OAuthGrantTypes.PASSWORD.getGrantType().equals(requestParameters.get(OAuth2Utils.GRANT_TYPE))
                        && ModuleNames.BlaZeServer.getName()
                                .equals(requestParameters.get(RequestParams.PasswordGrant.SOURCE))) {
                    values.put(RequestParams.PasswordGrant.APP_AGENT_NAME,
                            requestParameters.get(RequestParams.PasswordGrant.APP_AGENT_NAME));
                    values.put(RequestParams.PasswordGrant.DEVICE_ID,
                            requestParameters.get(RequestParams.PasswordGrant.DEVICE_ID));
                    values.put(RequestParams.PasswordGrant.SESSION_ID,
                            requestParameters.get(RequestParams.PasswordGrant.SESSION_ID));
                }

                return super.generateKey(values);
            }

        };
    }

    @Bean("defaultTokenServices")
    public DefaultTokenServices defaultTokenServicesBean(final TokenStore tokenStore) {

        final DefaultTokenServices tokenServices = new DefaultTokenServices();
        tokenServices.setTokenStore(tokenStore);
        return tokenServices;

    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new PasswordEncoder() {

            @Override
            public boolean matches(final CharSequence rawPassword, final String encodedPassword) {

                if (encodedPassword == null || encodedPassword.length() == 0) {
                    return false;
                }

                return rawPassword.toString().equals(encodedPassword);
            }

            @Override
            public String encode(final CharSequence rawPassword) {
                return rawPassword.toString();
            }
        };
    }
}
