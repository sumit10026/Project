package com.uniken.authserver.config;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.BigInteger;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.KeyStore;
import java.security.Security;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;

import javax.annotation.PostConstruct;
import javax.annotation.Resource;

import org.apache.commons.codec.binary.Base64;
import org.bouncycastle.asn1.x500.X500Name;
import org.bouncycastle.cert.CertIOException;
import org.bouncycastle.cert.jcajce.JcaX509CertificateConverter;
import org.bouncycastle.cert.jcajce.JcaX509v3CertificateBuilder;
import org.bouncycastle.operator.ContentSigner;
import org.bouncycastle.operator.OperatorCreationException;
import org.bouncycastle.operator.jcajce.JcaContentSignerBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import com.fasterxml.uuid.Generators;
import com.uniken.authserver.domains.JWTSupportedAlgorithms;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.auth.JWTConfig;
import com.uniken.domains.auth.OIDCConfig;
import com.uniken.domains.enums.CollectionNames;
import com.uniken.encdecutils.PropertiesEncryptDecrypt;
import com.uniken.pass.handler.library.sync.api.PassHandler;

@Configuration
public class StartupConfig {

    private static final Logger LOG = LoggerFactory.getLogger(StartupConfig.class);

    @Autowired
    private PassHandler passHandler;

    @Resource(name = Constants.RESOURCE_ADAPTERDB_MONGO_TEMPLATE)
    private MongoTemplate adapterdbMongoTemplate;

    @PostConstruct
    public void init() throws IOException {
        configureOidcConfigCollection();

        // load public key
        passHandler.retrievePublicKey();
    }

    void configureOidcConfigCollection() throws IOException {
        LOG.debug("configureOidcConfigCollection() -> Configuring OIDC Config collection");

        final long oidcConfigCount = adapterdbMongoTemplate.count(new Query(),
                CollectionNames.OIDC_CONFIG.getCollectionName());

        if (oidcConfigCount == 0) {

            String rsBlob = null;
            while (null == rsBlob) {
                LOG.info("StartupConfig() :: creating key pair");
                rsBlob = createKeyPair(JWTSupportedAlgorithms.RS256.name());
                LOG.info("StartupConfig() :: created key pair {}", rsBlob);
            }
            final OIDCConfig oidcConfig = new OIDCConfig();
            final JWTConfig jwtConfig = new JWTConfig();
            jwtConfig.setAlgorithm(JWTSupportedAlgorithms.RS256.name());
            jwtConfig.setAudience("REL-ID Default");
            jwtConfig.setIssuer(Constants.OIDC_CONFIG_JWT_ISSUER_NAME);
            jwtConfig.setKid(Generators.randomBasedGenerator(new Random()).generate().toString());
            jwtConfig.setCertificateType(Constants.OIDC_CONFIG_JWT_KEYSTORE_TYPE);
            jwtConfig.setKeystorePassword(Constants.OIDC_CONFIG_JWT_KEYSTORE_PASSPHRASE);
            jwtConfig.setCertificateAlias(Constants.OIDC_CONFIG_JWT_KEYSTORE_KEY_ALIAS);
            jwtConfig.setRsBlob(rsBlob);
            oidcConfig.setJwtConfig(jwtConfig);

            adapterdbMongoTemplate.save(oidcConfig, CollectionNames.OIDC_CONFIG.getCollectionName());
            LOG.info("configureOidcConfigCollection() -> Created OIDC Config");
        } else {
            LOG.debug("configureOidcConfigCollection() -> OIDC Config already present");
        }
    }

    private String createKeyPair(final String algorithm) {
        try {
            LOG.info("createKeyPair() entered");
            if (JWTSupportedAlgorithms.RS256.name().equals(algorithm)) {

                final char[] keyStorePswd = PropertiesEncryptDecrypt
                        .decryptWithAES(Constants.OIDC_CONFIG_JWT_KEYSTORE_PASSPHRASE).toCharArray();

                if (Security.getProvider("BC") == null) {
                    LOG.warn("createKeyPair() - BC provider is removed, adding it again");
                    Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
                }

                // --- generate a key pair (you did this already it seems)
                final KeyPairGenerator rsaGen = KeyPairGenerator.getInstance("RSA", "BC");
                rsaGen.initialize(2048);
                final KeyPair pair = rsaGen.generateKeyPair();

                // --- create the self signed cert
                final Certificate cert = createSelfSigned(pair);

                // --- create a new pkcs12 key store in memory
                final KeyStore pkcs12 = KeyStore.getInstance(Constants.OIDC_CONFIG_JWT_KEYSTORE_TYPE);
                pkcs12.load(null, null);

                // --- create entry in PKCS12
                pkcs12.setKeyEntry(Constants.OIDC_CONFIG_JWT_KEYSTORE_KEY_ALIAS, pair.getPrivate(), keyStorePswd,
                        new Certificate[] { cert });

                final ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
                pkcs12.store(outputStream, keyStorePswd);
                final byte[] fileContent = outputStream.toByteArray();
                final String base64EncodedStr = Base64.encodeBase64String(fileContent);
                LOG.info("createKeyPair() base64EncodedStr :{}", base64EncodedStr);
                return base64EncodedStr;
            }

        } catch (final Exception e) {
            LOG.error("createKeyPair(): Error while creating key pair: ", e);
        }
        return null;
    }

    private X509Certificate createSelfSigned(final KeyPair pair)
            throws OperatorCreationException, CertIOException, CertificateException {
        final X500Name dnName = new X500Name("CN=REL-ID-SERVER");
        final BigInteger certSerialNumber = BigInteger.ONE;

        final Date startDate = new Date(); // now

        final Calendar calendar = Calendar.getInstance();
        calendar.setTime(startDate);
        calendar.add(Calendar.YEAR, 10);
        final Date endDate = calendar.getTime();

        final ContentSigner contentSigner = new JcaContentSignerBuilder("SHA256WithRSA").build(pair.getPrivate());
        final JcaX509v3CertificateBuilder certBuilder = new JcaX509v3CertificateBuilder(dnName, certSerialNumber,
                startDate, endDate, dnName, pair.getPublic());

        return new JcaX509CertificateConverter().getCertificate(certBuilder.build(contentSigner));
    }
}
