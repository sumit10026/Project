package com.uniken.authserver.config;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.uniken.authserver.exception.InvalidUserException;
import com.uniken.authserver.services.api.UserService;
import com.uniken.authserver.utility.RegisterUserSessionUtils;
import com.uniken.authserver.utility.UserRegistrationConstants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.token.handler.library.TokenHandlerDomain;
import com.uniken.token.handler.library.enums.TokenHandlerStatus;
import com.uniken.token.handler.library.sync.api.TokenHandler;

@Component
public class RegisterUserTokenValidationFilter extends OncePerRequestFilter {

    private static final Logger LOG = LoggerFactory.getLogger(RegisterUserTokenValidationFilter.class);

    private final TokenHandler tokenHandler;
    private final UserService userService;

    public RegisterUserTokenValidationFilter(final TokenHandler tokenHandler, final UserService userService) {
        this.tokenHandler = tokenHandler;
        this.userService = userService;
    }

    @Override
    protected boolean shouldNotFilter(final HttpServletRequest request) throws ServletException {
        return UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI.equals(request.getServletPath());
    }

    @Override
    protected void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response,
            final FilterChain filterChain) throws ServletException, IOException {

        final String token = RegisterUserSessionUtils.getToken();

        if (!Utils.isNullOrEmpty(token)) {
            final TokenHandlerDomain tokenInfo = tokenHandler.getTokenInfo(token);

            if (!Utils.isNull(tokenInfo) && tokenInfo.getStatus() == TokenHandlerStatus.INPROGRESS) {

                final String userId = RegisterUserSessionUtils.getUserId();
                final UserAuthInfoVO userAuthInfo = userService.getUserAuthInfoByUserName(userId);

                if (userAuthInfo == null) {
                    throw new InvalidUserException(String.format("User not found: %s", userId));
                }

                final RelIdUserStatus userStatus = userAuthInfo.getUserStatus();
                final boolean isUserWebOnly = Boolean.TRUE.equals(userAuthInfo.isWebOnly());

                final List<RelIdUserStatus> validUserStatuses = Arrays.asList(RelIdUserStatus.CREATED,
                        RelIdUserStatus.RESET, RelIdUserStatus.ACTIVE);

                // If user has selected the remember me option and user has
                // already activated, then user can register the fido
                // authenticator if available. In that case we need to keep the
                // token active.
                if (!validUserStatuses.contains(userStatus) || (userStatus == RelIdUserStatus.ACTIVE && isUserWebOnly
                        && !RegisterUserSessionUtils.getIsRememberMe())) {
                    tokenHandler.updateTokenStatus(token, TokenHandlerStatus.ERROR);
                    LOG.error("Invalid user status for user: {}, status: {}, isUserWebOnly: {}", userId, userStatus,
                            isUserWebOnly);
                } else {
                    filterChain.doFilter(request, response);
                    return;
                }
            }
        }

        final String tokenInRequest = request.getParameter(UserRegistrationConstants.TOKEN);
        if (tokenInRequest != null) {
            tokenHandler.updateTokenStatus(token, TokenHandlerStatus.INVALIDATED);
        }

        request.getSession().invalidate();
        response.sendRedirect("error");
    }

}
