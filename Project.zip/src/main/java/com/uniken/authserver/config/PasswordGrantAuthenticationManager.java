package com.uniken.authserver.config;

import java.util.Collections;
import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.common.util.OAuth2Utils;
import org.springframework.stereotype.Component;

import com.uniken.authserver.repo.api.SessionTicketRepo;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.utility.RequestParams;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.SessionType;
import com.uniken.domains.enums.appconfig.ModuleNames;
import com.uniken.domains.enums.auth.OAuthGrantTypes;
import com.uniken.domains.relid.session.SessionTicket;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;

@Component
public class PasswordGrantAuthenticationManager {

    private static final Logger LOG = LoggerFactory.getLogger(PasswordGrantAuthenticationManager.class);

    private final UserAuthInfoRepo userAuthInfoRepo;
    private final SessionTicketRepo sessionTicketRepo;

    public PasswordGrantAuthenticationManager(final UserAuthInfoRepo userAuthInfoRepo,
            final SessionTicketRepo sessionTicketRepo) {
        this.userAuthInfoRepo = userAuthInfoRepo;
        this.sessionTicketRepo = sessionTicketRepo;
    }

    /**
     * Authenticates RelId User.
     *
     * @param authentication
     *            the authentication
     * @return the authentication
     */
    private Authentication authenticate(Authentication authentication) {

        LOG.info("authenticate() -> Authenticating user : {}", authentication.getName());

        @SuppressWarnings("unchecked")
        final Map<String, String> requestParameters = (Map<String, String>) authentication.getDetails();

        /** Handles requests from BlaZeServer only */
        if (requestParameters.get(OAuth2Utils.GRANT_TYPE) != null
                && OAuthGrantTypes.PASSWORD.getGrantType().equals(requestParameters.get(OAuth2Utils.GRANT_TYPE))
                && ModuleNames.BlaZeServer.getName()
                        .equals(requestParameters.get(RequestParams.PasswordGrant.SOURCE))) {
            LOG.debug("authenticate() -> Authenticating BlazeServer request");

            final String username = authentication.getName();
            validateBlazeServerRequest(username, requestParameters);

            authentication = new UsernamePasswordAuthenticationToken(username, null, Collections.emptySet());
        }

        return authentication;

    }

    /**
     * Validate blaze server request.
     *
     * @param username
     *            the username
     * @param requestParameters
     *            the request parameters
     */
    private void validateBlazeServerRequest(final String username, final Map<String, String> requestParameters) {
        LOG.debug("validateBlazeServerRequest() -> Validating BlazeServer request");

        final String usernameFromRequest = requestParameters.get(RequestParams.PasswordGrant.USERNAME);
        final String sessionId = requestParameters.get(RequestParams.PasswordGrant.SESSION_ID);
        final String appAgentName = requestParameters.get(RequestParams.PasswordGrant.APP_AGENT_NAME);
        final String deviceUuid = requestParameters.get(RequestParams.PasswordGrant.DEVICE_ID);

        /** validate request parameters */
        if (Utils.isNullOrEmpty(usernameFromRequest)) {
            throwExceptionForEmptyRequestParameter(RequestParams.PasswordGrant.USERNAME);
        }
        if (Utils.isNullOrEmpty(sessionId)) {
            throwExceptionForEmptyRequestParameter(RequestParams.PasswordGrant.SESSION_ID);
        }
        if (Utils.isNullOrEmpty(appAgentName)) {
            throwExceptionForEmptyRequestParameter(RequestParams.PasswordGrant.APP_AGENT_NAME);
        }
        if (Utils.isNullOrEmpty(deviceUuid)) {
            throwExceptionForEmptyRequestParameter(RequestParams.PasswordGrant.DEVICE_ID);
        }

        /** validate user */
        final UserAuthInfoVO user = userAuthInfoRepo.fetchUserDetailsFromLoginId(username);
        if (user == null || !RelIdUserStatus.ACTIVE.equals(user.getUserStatus())) {
            throw new BadCredentialsException("Could not authenticate user");
        }
        if (user.getRelIds().stream().noneMatch(relid -> relid.getDeviceUuid().equals(deviceUuid)
                && RelIdUserStatus.ACTIVE.equals(relid.getRelIdStatus()))) {
            throw new BadCredentialsException("Device is not ACTIVE or does not belong to the user: " + username);
        }

        /** validate session */
        final SessionTicket sessionTicket = sessionTicketRepo.findSessionTicketById(sessionId);
        if (sessionTicket == null) {
            throw new BadCredentialsException("Invalid session id provided");
        }
        if (new Date().after(sessionTicket.getExpiryTs())) {
            throw new BadCredentialsException("Session is expired");
        }
        if (!sessionTicket.getUserId().equals(username)
                || !SessionType.USER_SESSION.name().equals(sessionTicket.getSessionType())
                || !sessionTicket.getAppAgentName().equals(appAgentName)
                || !sessionTicket.getDeviceUuid().equals(deviceUuid)) {
            throw new BadCredentialsException(
                    "Session does not belong to the given user, app, device combination for the user: " + username);
        }

    }

    /**
     * Throw exception for empty request parameter.
     *
     * @param parameterName
     *            the parameter name
     */
    private void throwExceptionForEmptyRequestParameter(final String parameterName) {
        throw new BadCredentialsException(parameterName + " is null or empty");
    }

    /**
     * Gets the authentication manager.
     *
     * @return the authentication manager
     */
    public final AuthenticationManager getAuthenticationManager() {
        return this::authenticate;
    }
}
