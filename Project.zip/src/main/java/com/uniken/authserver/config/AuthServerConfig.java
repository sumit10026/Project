package com.uniken.authserver.config;

import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.boot.web.servlet.server.ConfigurableServletWebServerFactory;
import org.springframework.context.annotation.Configuration;

import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.PropertyConstants;

@Configuration
public class AuthServerConfig
        implements
        WebServerFactoryCustomizer<ConfigurableServletWebServerFactory> {

    @Override
    public void customize(final ConfigurableServletWebServerFactory factory) {
        factory.setPort(Integer.parseInt(PropertyConstants.AUTH_SERVER_PORT));
        factory.setContextPath(Constants.AUTH_SERVER_CONTEXT_URL);
        // TODO : SSL Configuragtion
        // Ssl ssl = new Ssl();
        // ssl.setEnabled(true);
        // ssl.setKeyStore("classpath:sample.jks");
        // ssl.setKeyAlias("alias");
        // ssl.setKeyPassword("password");
        // ssl.setKeyStorePassword("secret");
        // Http2 http2 = new Http2();
        // http2.setEnabled(false);
        // serverFactory.addServerCustomizers(new SslServerCustomizer(ssl,
        // http2, null));
    }
}
