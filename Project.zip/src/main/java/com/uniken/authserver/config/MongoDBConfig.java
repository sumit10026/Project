package com.uniken.authserver.config;

import java.io.FileInputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.mongodb.Block;
import com.mongodb.ConnectionString;
import com.mongodb.MongoClientSettings;
import com.mongodb.MongoCredential;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.connection.ConnectionPoolSettings;
import com.mongodb.connection.SslSettings;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.PropertyConstants;

@Configuration
public class MongoDBConfig {

    private static final Logger LOG = LoggerFactory.getLogger(MongoDBConfig.class);

    @Bean
    public MongoClient mongoClient() {

        if (!PropertyConstants.MongoDBConstants.MONGO_IS_SSL) {
            return MongoClients
                    .create(new ConnectionString(PropertyConstants.MongoDBConstants.MONGO_CONNECTION_STRING));
        }

        final MongoCredential mongoCredential = MongoCredential
                .createMongoX509Credential(PropertyConstants.MongoDBConstants.MONGO_CREDENTIALS);
        try (final FileInputStream certificateFilePath = new FileInputStream(
                PropertyConstants.MongoDBConstants.MONGO_CERT_PATH);) {

            final KeyStore ks = KeyStore.getInstance("pkcs12");
            ks.load(certificateFilePath, PropertyConstants.MongoDBConstants.MONGO_CERT_PWD.toCharArray());

            final KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
            kmf.init(ks, PropertyConstants.MongoDBConstants.MONGO_CERT_PWD.toCharArray());

            final SSLContext sslContext = SSLContext
                    .getInstance(PropertyConstants.MongoDBConstants.MONGODB_TLS_VERSION);
            if (null != PropertyConstants.MongoDBConstants.MONGO_STORE_PATH
                    && !PropertyConstants.MongoDBConstants.MONGO_STORE_PATH.trim().isEmpty()
                    && null != PropertyConstants.MongoDBConstants.MONGO_STORE_PWD
                    && !PropertyConstants.MongoDBConstants.MONGO_STORE_PWD.trim().isEmpty()) {
                final char[] trustPassphrase = PropertyConstants.MongoDBConstants.MONGO_STORE_PWD.toCharArray();
                final KeyStore trustKeyStore = KeyStore.getInstance("JKS");
                FileInputStream trustStoreStream = null;
                try {
                    trustStoreStream = new FileInputStream(PropertyConstants.MongoDBConstants.MONGO_STORE_PATH);
                    trustKeyStore.load(trustStoreStream, trustPassphrase);
                } finally {
                    if (trustStoreStream != null) {
                        trustStoreStream.close();
                        trustStoreStream = null;
                    }
                }

                final TrustManagerFactory trustManagerFactory = TrustManagerFactory.getInstance("SunX509");
                trustManagerFactory.init(trustKeyStore);

                sslContext.init(kmf.getKeyManagers(), trustManagerFactory.getTrustManagers(), null);
            } else {
                sslContext.init(kmf.getKeyManagers(), null, null);
            }

            final Block<SslSettings.Builder> sslSettingBlock = block -> block.applySettings(
                    SslSettings.builder().enabled(true).context(sslContext).invalidHostNameAllowed(true).build());

            /**
             * TODO: Configured ConnectionPoolSettings with default values. Need
             * to fine tune in our environment
             **/

            final Block<ConnectionPoolSettings.Builder> connectionPoolSettingBlock = block -> block.applySettings(
                    ConnectionPoolSettings.builder().maxSize(PropertyConstants.MongoDBConstants.MONGO_MAX_POOL_SIZE)
                            .minSize(PropertyConstants.MongoDBConstants.MONGO_MIN_POOL_SIZE)
                            .maxWaitTime(PropertyConstants.MongoDBConstants.MONGO_MAX_WAIT_TIME_IN_MILLIS,
                                    TimeUnit.MILLISECONDS)
                            .maintenanceFrequency(
                                    PropertyConstants.MongoDBConstants.MONGO_MAINTENANCE_FREQUENCY_IN_MILLIS,
                                    TimeUnit.MILLISECONDS)
                            .maintenanceInitialDelay(
                                    PropertyConstants.MongoDBConstants.MONGO_MAINTENANCE_INITIAL_DELAY_IN_MILLIS,
                                    TimeUnit.MILLISECONDS)
                            .maxConnectionIdleTime(
                                    PropertyConstants.MongoDBConstants.MONGO_MAX_CONNECTION_IDLETIME_IN_MILLIS,
                                    TimeUnit.MILLISECONDS)
                            .maxConnectionLifeTime(
                                    PropertyConstants.MongoDBConstants.MONGO_MAX_CONNECTION_LIFETIME_IN_MILLIS,
                                    TimeUnit.MILLISECONDS)
                            .build());

            final MongoClientSettings clientSettings = MongoClientSettings.builder().credential(mongoCredential)
                    .applyToSslSettings(sslSettingBlock).applyToConnectionPoolSettings(connectionPoolSettingBlock)
                    .applyConnectionString(
                            new ConnectionString(PropertyConstants.MongoDBConstants.MONGO_CONNECTION_STRING))
                    .build();

            return MongoClients.create(clientSettings);

        } catch (final IOException | GeneralSecurityException e) {
            LOG.error("Failed to establish DB Connection. Terminating Process....!", e);
            System.exit(-1);
        }
        return null;
    }

    @Primary
    @Bean(name = { "mongoTemplate", Constants.RESOURCE_AUTHSERVERDB_MONGO_TEMPLATE })
    public MongoTemplate authserverdbMongoTemplate(final MongoClient mongoClient) {
        return new MongoTemplate(mongoClient, PropertyConstants.MongoDBConstants.AUTH_SERVER_DB_NAME);
    }

    @Bean(Constants.RESOURCE_RELIDDB_MONGO_TEMPLATE)
    public MongoTemplate relIddbMongoTemplate(final MongoClient mongoClient) {
        return new MongoTemplate(mongoClient, PropertyConstants.MongoDBConstants.REL_ID_DB_NAME);
    }

    @Bean(Constants.RESOURCE_GMDB_MONGO_TEMPLATE)
    public MongoTemplate gmdbMongoTemplate(final MongoClient mongoClient) {
        return new MongoTemplate(mongoClient, PropertyConstants.MongoDBConstants.GM_DB_NAME);
    }

    @Bean(Constants.RESOURCE_ADAPTERDB_MONGO_TEMPLATE)
    public MongoTemplate adapterdbMongoTemplate(final MongoClient mongoClient) {
        return new MongoTemplate(mongoClient, PropertyConstants.MongoDBConstants.ADAPTER_DB_NAME);
    }

    @Bean(Constants.RESOURCE_OOBMSGDB_MONGO_TEMPLATE)
    public MongoTemplate oobmsgdbMongoTemplate(final MongoClient mongoClient) {
        return new MongoTemplate(mongoClient, PropertyConstants.MongoDBConstants.OOBMSG_DB_NAME);
    }

}
