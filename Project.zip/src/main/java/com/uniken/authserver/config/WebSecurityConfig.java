package com.uniken.authserver.config;

import java.util.HashSet;
import java.util.Set;
import java.util.stream.Stream;

import javax.servlet.Filter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.ClientDetailsService;
import org.springframework.security.oauth2.provider.client.ClientDetailsUserDetailsService;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.web.firewall.StrictHttpFirewall;
import org.springframework.security.web.util.matcher.AndRequestMatcher;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

import com.uniken.authserver.services.api.SecureCookieService;
import com.uniken.authserver.services.api.UserService;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.authserver.services.impl.CustomUserDetailsService;
import com.uniken.authserver.utility.AccountRecoveryConstants;
import com.uniken.authserver.utility.AuthenticationUtils;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.UserRegistrationConstants;
import com.uniken.authserver.utility.Utils;
import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;

@Configuration
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {

    @Autowired
    private ClientDetailsService clientDetailsService;

    @Autowired
    private WebDevMasterService webDevMasterService;

    @Autowired
    private CustomUserDetailsService customUserDetailsService;

    @Autowired
    private UserService userService;

    @Autowired
    SecureCookieService secureCookieService;

    @Override
    protected void configure(final HttpSecurity http) throws Exception {

        final String revokeTokenUri = "/oauth/token/revoke*";

        final Set<String> csrfIgnoredUris = new HashSet<>();
        csrfIgnoredUris.add("/oauth/token");
        csrfIgnoredUris.add(revokeTokenUri);
        csrfIgnoredUris.add("/oauth/check_token");
        csrfIgnoredUris.add("/oauth/introspect");
        csrfIgnoredUris.add("/oauth/userInfo");
        csrfIgnoredUris.add("/oauth/userinfo");
        http.csrf().ignoringAntMatchers(csrfIgnoredUris.stream().toArray(String[]::new));

        http.httpBasic();
        http.userDetailsService(new ClientDetailsUserDetailsService(clientDetailsService)).authorizeRequests()
                .antMatchers(revokeTokenUri).authenticated().and().formLogin().loginPage("/login").and().logout()
                .permitAll().and()
                .addFilterBefore(sessionInvalidationFilter(revokeTokenUri), UsernamePasswordAuthenticationFilter.class);

        // SAST fix - disabled
        http.headers().frameOptions().deny();

        // disable root
        http.authorizeRequests().antMatchers("/").denyAll();
        // disable OPTIONS and TRACE methods
        http.authorizeRequests().antMatchers(HttpMethod.OPTIONS, "/**").denyAll();
        http.authorizeRequests().antMatchers(HttpMethod.TRACE, "/**").denyAll();

        // manually opened URIs
        http.authorizeRequests().antMatchers("/login").permitAll();
        http.authorizeRequests().antMatchers("/portal-login").permitAll();
        http.authorizeRequests().antMatchers("/error").permitAll();
        http.authorizeRequests().antMatchers("/oauth/validateUser").permitAll();
        http.authorizeRequests().antMatchers("/oauth/isUserAuthenticated").permitAll();
        http.authorizeRequests().antMatchers("/.well-known/jwks.json").permitAll();
        http.authorizeRequests().antMatchers("/oauth/getUserAuthFactors").permitAll();
        http.authorizeRequests().antMatchers("/assertion/options").permitAll();
        http.authorizeRequests().antMatchers("/configs").permitAll();
        http.authorizeRequests().antMatchers("/fetchPublicKey").permitAll();
        http.authorizeRequests().antMatchers("/oauth/validate-user").permitAll();
        http.authorizeRequests().antMatchers("/validate-fido-cred").permitAll();
        http.authorizeRequests().antMatchers("/ validate-fido-register-same-browser").permitAll();
        http.authorizeRequests().antMatchers("/oauth/delete-account").permitAll();
        http.authorizeRequests().antMatchers("/forgot/forgot-username").permitAll();

        // manually opened URIs that has manually handled authentication, other
        // than spring security authentication
        http.authorizeRequests().antMatchers("/oauth/userInfo").permitAll();
        http.authorizeRequests().antMatchers("/oauth/userinfo").permitAll();

        // static resources URIs
        http.authorizeRequests().antMatchers("/webjars/**").permitAll();
        http.authorizeRequests().antMatchers("/js/**").permitAll();
        http.authorizeRequests().antMatchers("/pkijs/**").permitAll();
        http.authorizeRequests().antMatchers("/css/**").permitAll();
        http.authorizeRequests().antMatchers("/img/**", "/img2/**", "/images/**").permitAll();
        http.authorizeRequests().antMatchers("/font/**", "/font-awesome/**").permitAll();

        // user register/activation uris (see RegisterUserTokenValidationFilter)
        http.authorizeRequests().antMatchers(UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI).permitAll();
        http.authorizeRequests().antMatchers(UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI + "/configs")
                .permitAll();
        http.authorizeRequests()
                .antMatchers(UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI + "/generateOtp").permitAll();
        http.authorizeRequests()
                .antMatchers(UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI + "/validateOtp").permitAll();
        http.authorizeRequests()
                .antMatchers(UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI + "/save-password")
                .permitAll();
        http.authorizeRequests()
                .antMatchers(UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI + "/attestation/options")
                .permitAll();
        http.authorizeRequests()
                .antMatchers(UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI + "/attestation/result")
                .permitAll();
        http.authorizeRequests()
                .antMatchers(UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI + "/fetchPublicKey")
                .permitAll();

        // Account Recovery Credential URIs
        http.authorizeRequests().antMatchers(AccountRecoveryConstants.ACCOUNT_RECOVERY_CREDENTIAL_BASE_URI).permitAll();
        http.authorizeRequests().antMatchers(AccountRecoveryConstants.ACCOUNT_RECOVERY_CREDENTIAL_CONFIGS).permitAll();
        http.authorizeRequests().antMatchers(AccountRecoveryConstants.GET_RESET_CREDENTIAL_FACTOR).permitAll();
        http.authorizeRequests().antMatchers(AccountRecoveryConstants.ACCOUNT_RECOVERY_FETCH_PUBLIC_KEY).permitAll();
        http.authorizeRequests().antMatchers(AccountRecoveryConstants.RESET_CREDENTIAL).permitAll();
        http.authorizeRequests().antMatchers(AccountRecoveryConstants.ACCOUNT_RECOVERY_REDIRECT_LOGIN).permitAll();
        http.authorizeRequests().antMatchers(AccountRecoveryConstants.SUBMIT_ARC_FORM).permitAll();

        // other request needs authentication
        http.authorizeRequests().anyRequest().authenticated();

        final OIDCAuthenticationFilter authenticationFilter = new OIDCAuthenticationFilter();
        authenticationFilter.setAuthenticationManager(authenticationManagerBean());
        authenticationFilter.setUserService(userService);
        authenticationFilter.setWebDevMasterService(webDevMasterService);
        authenticationFilter.setSecureCookieService(secureCookieService);
        http.addFilterAt(authenticationFilter, UsernamePasswordAuthenticationFilter.class);
    }

    @Bean
    public StrictHttpFirewall httpFirewall() {
        final StrictHttpFirewall firewall = new StrictHttpFirewall();

        final Set<String> allowedHostNames = new HashSet<>();
        allowedHostNames.add("localhost"); // for blaze server request
        allowedHostNames.addAll(Constants.AUTH_SERVER_ALLOWED_HOSTNAMES);
        firewall.setAllowedHostnames(allowedHostNames::contains);

        final Set<String> allowedHttpMethods = new HashSet<>();
        allowedHttpMethods.add(HttpMethod.GET.name());
        allowedHttpMethods.add(HttpMethod.POST.name());
        firewall.setAllowedHttpMethods(allowedHttpMethods);

        return firewall;
    }

    @Bean
    CustomUserDetailsService customUserDetailsServiceBean() {
        return customUserDetailsService;
    }

    /**
     * Global request URI based IP whitelisting filter.
     *
     * @return the filter registration bean
     */
    @Bean
    public FilterRegistrationBean<GlobalRequestUriBasedIpWhitelistingFilter> globalRequestUriBasedIpWhitelistingFilter() {
        final FilterRegistrationBean<GlobalRequestUriBasedIpWhitelistingFilter> filterRegistrationBean = new FilterRegistrationBean<>();
        final GlobalRequestUriBasedIpWhitelistingFilter globalRequestUriBasedIpWhitelistingFilter = new GlobalRequestUriBasedIpWhitelistingFilter();
        filterRegistrationBean.setFilter(globalRequestUriBasedIpWhitelistingFilter);
        filterRegistrationBean.setOrder(Integer.MIN_VALUE);
        return filterRegistrationBean;
    }

    @Bean
    public FilterRegistrationBean<RegisterUserTokenValidationFilter> registerUserTokenValidationFilterRegistraion(
            final RegisterUserTokenValidationFilter registerUserTokenValidationFilter) {
        final FilterRegistrationBean<RegisterUserTokenValidationFilter> filterRegistrationBean = new FilterRegistrationBean<>(
                registerUserTokenValidationFilter);
        filterRegistrationBean.addUrlPatterns(UserRegistrationConstants.WEB_ONLY_USER_ACTIVATION_BASE_URI + "/*");
        return filterRegistrationBean;
    }

    /**
     * Session invalidation filter.
     * <p>
     * Use case: Invalidate session after revoking a token as revoke token API
     * is handled manually (not by spring OAuth library).
     *
     * @param antPatterns
     *            the ant patterns
     * @return the filter
     */
    @SuppressWarnings("unchecked")
    private Filter sessionInvalidationFilter(final String... antPatterns) {
        final AndRequestMatcher antPathMatcher = new AndRequestMatcher(
                Stream.of(antPatterns).map(AntPathRequestMatcher::new).toArray(AntPathRequestMatcher[]::new));

        return (request, response, chain) -> {
            chain.doFilter(request, response);

            final HttpServletRequest httpServletRequest = (HttpServletRequest) request;
            if (antPathMatcher.matches(httpServletRequest)) {
                final HttpSession session = httpServletRequest.getSession(false);
                if (session != null) {
                    EventLogger.log(EventId.RelidAuthServer.INVALID_USER_STATUS,
                            Utils.getClientIpAddress(httpServletRequest),
                            AuthenticationUtils.getRequestorId(httpServletRequest),
                            AuthenticationUtils.getUsername(httpServletRequest),
                            AuthenticationUtils.getUserAgent(httpServletRequest),
                            "Invalidating Session in WebSecurityConfig");
                    session.invalidate();
                    SecurityContextHolder.clearContext();
                }
            }
        };
    }

}
