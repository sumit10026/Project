package com.uniken.authserver.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.exceptions.InvalidScopeException;
import org.springframework.security.oauth2.provider.AuthorizationRequest;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.TokenRequest;
import org.springframework.security.oauth2.provider.request.DefaultOAuth2RequestValidator;
import org.springframework.stereotype.Component;

/**
 * Custom OAuth2RequestValidator for default and PKCE validation.
 */
@Component
public class CustomOAuth2RequestValidator extends DefaultOAuth2RequestValidator {

    @Autowired
    PKCEOAuth2Validator pkceoAuth2Validator;

    @Override
    public void validateScope(final AuthorizationRequest authorizationRequest, final ClientDetails client)
            throws InvalidScopeException {
        super.validateScope(authorizationRequest, client);

        pkceoAuth2Validator.validateScope(authorizationRequest, client);

    }

    @Override
    public void validateScope(final TokenRequest tokenRequest, final ClientDetails client)
            throws InvalidScopeException {
        super.validateScope(tokenRequest, client);

        pkceoAuth2Validator.validateScope(tokenRequest, client);
    }
}
