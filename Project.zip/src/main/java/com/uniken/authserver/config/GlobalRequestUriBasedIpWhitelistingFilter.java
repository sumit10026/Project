package com.uniken.authserver.config;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.filter.OncePerRequestFilter;

import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.Utils;

public class GlobalRequestUriBasedIpWhitelistingFilter extends OncePerRequestFilter {

    private static final Logger LOG = LoggerFactory.getLogger(GlobalRequestUriBasedIpWhitelistingFilter.class);

    @Override
    protected void doFilterInternal(final HttpServletRequest request, final HttpServletResponse response,
            final FilterChain filterChain) throws ServletException, IOException {

        final String requestURI = request.getRequestURI();
        final String clientIPAddress = Utils.getClientIpAddress(request);

        LOG.trace("doFilterInternal() -> Checking if IP: {} is allowed to access URI: {}", clientIPAddress, requestURI);

        if (Constants.AUTH_SERVER_WHITELISTED_PUBLIC_URIS.contains(requestURI)
                && !Constants.WHITELISTED_RP_SERVER_IPS.contains(clientIPAddress)) {
            LOG.error("doFilterInternal() -> IP: {} is not allowed to access URI: {}. Check if IP is whitelisted.",
                    clientIPAddress, requestURI);
            // FIXME: Add event log
            Utils.writeUnauthorizedResponse(request, response);
        } else {
            LOG.trace("doFilterInternal() -> IP: {} is allowed to access URI: {}", clientIPAddress, requestURI);
            filterChain.doFilter(request, response);
        }

    }

}
