/**
 * 
 */
package com.uniken.authserver.config;

import java.util.Arrays;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.OAuth2RequestValidator;
import org.springframework.security.oauth2.provider.token.TokenEnhancerChain;

import com.uniken.authserver.repo.api.MongoTokenStoreRepo;
import com.uniken.authserver.services.api.OAuth2ClientDetailsService;
import com.uniken.authserver.services.impl.CustomJwtAccessTokenConverter;
import com.uniken.authserver.services.impl.CustomUserDetailsService;
import com.uniken.authserver.services.impl.OAuth2AuthorizationCodeServices;
import com.uniken.authserver.services.impl.OpenIdAccessTokenEnhancer;

/**
 * A OAuth 2.0 authorization server implementation and configurations.
 * 
 * @author Kushal Jaiswal
 */
@EnableAuthorizationServer
@Configuration
public class OAuth2AuthorizationServerConfig extends AuthorizationServerConfigurerAdapter {

    private static final Logger LOG = LoggerFactory.getLogger(OAuth2AuthorizationServerConfig.class);

    @Autowired
    private OAuth2ClientDetailsService clientDetailsService;

    @Autowired
    private MongoTokenStoreRepo mongoTokenStore;

    @Autowired
    private OAuth2AuthorizationCodeServices authorizationCodeService;

    @Autowired
    private CustomJwtAccessTokenConverter jwtAccessTokenConverter;

    @Autowired
    private OpenIdAccessTokenEnhancer openIdAccessTokenEnhancer;

    @Autowired
    private PasswordGrantAuthenticationManager passwordGrantAuthenticationManager;

    @Autowired
    private CustomUserDetailsService customUserDetailsService;

    @Autowired
    private CustomExactMatchRedirectResolver customExactMatchRedirectResolver;

    @Autowired
    private OAuth2RequestValidator customOAuth2RequestValidator;

    @Override
    public void configure(final ClientDetailsServiceConfigurer clients) throws Exception {
        LOG.debug("configure() : Change default client detail service with custom implementation.");

        clients.withClientDetails(clientDetailsService);
    }

    @Override
    public void configure(final AuthorizationServerSecurityConfigurer security) throws Exception {
        security.checkTokenAccess("permitAll()");
    }

    @Override
    public void configure(final AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
        LOG.debug(
                "configure() : Added Default token store, disable approvalStoreDisabled and reuse refresh token is disabled.");

        final TokenEnhancerChain tokenEnhancerChain = new TokenEnhancerChain();
        tokenEnhancerChain.setTokenEnhancers(Arrays.asList(jwtAccessTokenConverter, openIdAccessTokenEnhancer));

        endpoints.approvalStoreDisabled();
        endpoints.authenticationManager(passwordGrantAuthenticationManager.getAuthenticationManager());
        endpoints.authorizationCodeServices(authorizationCodeService);
        endpoints.tokenEnhancer(tokenEnhancerChain);
        endpoints.tokenStore(mongoTokenStore);
        endpoints.reuseRefreshTokens(false);
        endpoints.userDetailsService(customUserDetailsService);
        endpoints.redirectResolver(customExactMatchRedirectResolver);
        endpoints.requestValidator(customOAuth2RequestValidator);
    }

}
