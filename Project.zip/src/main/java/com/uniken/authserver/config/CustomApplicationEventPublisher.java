package com.uniken.authserver.config;

import javax.servlet.http.HttpSessionEvent;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.security.web.session.HttpSessionEventPublisher;
import org.springframework.stereotype.Component;

import com.uniken.authserver.services.api.WebDevSessionService;

@Component
public class CustomApplicationEventPublisher extends HttpSessionEventPublisher
        implements
        ApplicationEventPublisher {

    @Autowired
    private WebDevSessionService webDevSessionService;

    @Override
    public void publishEvent(final ApplicationEvent event) {
        ApplicationEventPublisher.super.publishEvent(event);
    }

    @Override
    public void publishEvent(final Object event) {

    }

    @Override
    public void sessionDestroyed(final HttpSessionEvent event) {
        webDevSessionService.archiveWebDevSessionById(event.getSession().getId());

        super.sessionDestroyed(event);
    }
}
