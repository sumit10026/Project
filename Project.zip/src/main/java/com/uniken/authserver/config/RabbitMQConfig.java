package com.uniken.authserver.config;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.GeneralSecurityException;
import java.security.KeyStore;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.AmqpAdmin;
import org.springframework.amqp.core.Binding;
import org.springframework.amqp.core.BindingBuilder;
import org.springframework.amqp.core.DirectExchange;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitAdmin;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.amqp.support.converter.Jackson2JsonMessageConverter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.MQConstant;
import com.uniken.authserver.utility.PropertyConstants;

@Configuration
public class RabbitMQConfig {

    private static final Logger LOG = LoggerFactory.getLogger(RabbitMQConfig.class);

    @Bean
    public ConnectionFactory rabbitMQConnectionFactory() {

        LOG.info("connectionFactory() : Establishing rabbitmq connection with given configuration");

        final com.rabbitmq.client.ConnectionFactory factory = new com.rabbitmq.client.ConnectionFactory();

        factory.setHost(PropertyConstants.RabbitMQConstants.RABBITMQ_HOST);
        factory.setPort(PropertyConstants.RabbitMQConstants.RABBITMQ_PORT);
        factory.setUsername(PropertyConstants.RabbitMQConstants.RABBITMQ_USERNAME);
        factory.setPassword(PropertyConstants.RabbitMQConstants.RABBITMQ_PWD);
        factory.setAutomaticRecoveryEnabled(true);

        if (!PropertyConstants.RabbitMQConstants.RABBITMQ_IS_SSL) {
            return new CachingConnectionFactory(factory);
        }

        try (final InputStream keyCertStream = new FileInputStream(
                PropertyConstants.RabbitMQConstants.RABBITMQ_KEYCERT_PATH);
                final InputStream trustStoreStream = new FileInputStream(
                        PropertyConstants.RabbitMQConstants.RABBITMQ_STORE_PATH);) {

            final char[] keyPassphrase = PropertyConstants.RabbitMQConstants.RABBITMQ_KEYCERT_PWD.toCharArray();
            final KeyStore ks = KeyStore.getInstance("PKCS12");
            ks.load(keyCertStream, keyPassphrase);

            final KeyManagerFactory kmf = KeyManagerFactory.getInstance("SunX509");
            kmf.init(ks, keyPassphrase);

            final char[] trustPassphrase = PropertyConstants.RabbitMQConstants.RABBITMQ_STORE_PWD.toCharArray();
            final KeyStore tks = KeyStore.getInstance("JKS");
            tks.load(trustStoreStream, trustPassphrase);

            final TrustManagerFactory tmf = TrustManagerFactory.getInstance("SunX509");
            tmf.init(tks);

            final SSLContext c = SSLContext.getInstance(PropertyConstants.RabbitMQConstants.RABBITMQ_TLS_VERSION);

            c.init(kmf.getKeyManagers(), tmf.getTrustManagers(), null);
            factory.useSslProtocol(c);
            factory.setSocketFactory(c.getSocketFactory());

        } catch (final IOException | GeneralSecurityException e) {
            LOG.error("Error occured while connecting with RabbitMQ Server.", e);
        }

        return new CachingConnectionFactory(factory);
    }

    @Bean
    public RabbitTemplate amqpTemplate(final ConnectionFactory connectionFactory) {

        final AmqpAdmin admin = new RabbitAdmin(connectionFactory);
        admin.declareQueue(authServerQueue());

        final RabbitTemplate amqpTemplate = new RabbitTemplate(connectionFactory);

        amqpTemplate.setMessageConverter(producerJackson2MessageConverter());
        amqpTemplate.setUserCorrelationId(true);
        // amqpTemplate.setUseDirectReplyToContainer(true);
        // amqpTemplate.setUsePublisherConnection(true);
        // amqpTemplate.containerAckMode(AcknowledgeMode.AUTO);
        // amqpTemplate.setNoLocalReplyConsumer(true);
        amqpTemplate.setChannelTransacted(true);

        amqpTemplate.setDefaultReceiveQueue(Constants.AUTH_SERVER_NODE_RECEIVING_QUEUE);
        return amqpTemplate;
    }

    @Bean
    public Jackson2JsonMessageConverter producerJackson2MessageConverter() {
        return new Jackson2JsonMessageConverter();
    }

    @Bean("authServerQueue")
    public Queue authServerQueue() {
        return new Queue(Constants.AUTH_SERVER_NODE_RECEIVING_QUEUE, true, false, false);
    }

    @Bean("authServerExchange")
    public DirectExchange directExchange() {
        final boolean durable = true;
        return new DirectExchange(Constants.AUTH_SERVER_NODE_EXCHANGE, durable, false);
    }

    /**
     * Bean configuration to bind the RabbitMQ Key's with Auth Server Exchange
     * and Queue. <br>
     * More Detail : Read
     * <a>https://docs.spring.io/spring-amqp/reference/pdf/index.pdf</a>
     * 
     * @return the binding
     */
    @Bean("bindQueueWithExchange")
    public Binding bindQueueWithExchange() {
        return BindingBuilder.bind(authServerQueue()).to(directExchange())
                .with(MQConstant.AUTHSERVER_RECEIVING_ACTION_ROUTING_KEY);
    }

    @Bean("bindQueueWithExchangeForGenerateToken")
    public Binding bindQueueWithExchangeForGenerateToken() {
        return BindingBuilder.bind(authServerQueue()).to(directExchange())
                .with(MQConstant.RELIDVERIFYSERVER_GENERATE_TOKEN_REQUEST_KEY);
    }

}
