package com.uniken.authserver.config;

import com.uniken.authserver.utility.PropertyConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.mongodb.core.MongoOperations;
import org.springframework.security.web.session.HttpSessionDestroyedEvent;
import org.springframework.session.data.mongo.MongoIndexedSessionRepository;
import org.springframework.session.data.mongo.MongoSession;

import com.uniken.authserver.services.impl.WebDevSessionServiceImpl;

import javax.servlet.http.HttpSessionEvent;

public class CustomMongoHttpSessionRepository extends MongoIndexedSessionRepository {

    private String collectionName;

    private Integer maxInactiveIntervalInSeconds;

    private ApplicationEventPublisher eventPublisher;

    public CustomMongoHttpSessionRepository(MongoOperations mongoOperations) {
        super(mongoOperations);
    }

    @Override
    public void setMaxInactiveIntervalInSeconds(Integer maxInactiveIntervalInSeconds) {
        super.setMaxInactiveIntervalInSeconds(maxInactiveIntervalInSeconds);
        this.maxInactiveIntervalInSeconds = maxInactiveIntervalInSeconds;

    }

    @Override
    public void setCollectionName(String collectionName) {
        super.setCollectionName(collectionName);
        this.collectionName = collectionName;
    }

    @Override
    public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
        super.setApplicationEventPublisher(applicationEventPublisher);
        this.eventPublisher = applicationEventPublisher;
    }

}
