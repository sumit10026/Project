package com.uniken.authserver.config;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.exceptions.InvalidGrantException;
import org.springframework.security.oauth2.common.exceptions.InvalidRequestException;
import org.springframework.security.oauth2.common.exceptions.InvalidScopeException;
import org.springframework.security.oauth2.provider.AuthorizationRequest;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.oauth2.provider.OAuth2RequestValidator;
import org.springframework.security.oauth2.provider.TokenRequest;
import org.springframework.stereotype.Component;
import org.springframework.util.Base64Utils;

import com.uniken.authserver.services.api.OAuth2AuthorizationCodeServicesApi;
import com.uniken.authserver.utility.RequestParams.AuthorizationCodeGrant;
import com.uniken.authserver.utility.Utils;

/**
 * Custom OAuth2RequestValidator for default and PKCE validation.
 */
@Component
public class PKCEOAuth2Validator
        implements
        OAuth2RequestValidator {

    private static final String CODE_CHALLENGE_METHOD_PLAIN = "plain";
    private static final String CODE_CHALLENGE_METHOD_S256 = "S256";

    OAuth2AuthorizationCodeServicesApi oAuth2AuthorizationCodeServices;

    @Autowired
    public PKCEOAuth2Validator(final OAuth2AuthorizationCodeServicesApi oAuth2AuthorizationCodeServices) {
        this.oAuth2AuthorizationCodeServices = oAuth2AuthorizationCodeServices;
    }

    @Override
    public void validateScope(final AuthorizationRequest authorizationRequest, final ClientDetails client)
            throws InvalidScopeException {

        if (authorizationRequest.getRequestParameters().containsKey(AuthorizationCodeGrant.CODE_CHALLENGE)) {

            if (null == authorizationRequest.getRequestParameters().get(AuthorizationCodeGrant.CODE_CHALLENGE)
                    || authorizationRequest.getRequestParameters().get(AuthorizationCodeGrant.CODE_CHALLENGE).isEmpty())
                throw new InvalidRequestException("code challenge required");

            String method = "";
            if (authorizationRequest.getRequestParameters().containsKey(AuthorizationCodeGrant.CODE_CHALLENGE_METHOD))
                method = authorizationRequest.getRequestParameters().get(AuthorizationCodeGrant.CODE_CHALLENGE_METHOD);

            if (Utils.isNull(method))
                throw new InvalidRequestException("transform algorithm not supported");

            if (!method.isEmpty() && !(method.equalsIgnoreCase(CODE_CHALLENGE_METHOD_PLAIN)
                    || method.equalsIgnoreCase(CODE_CHALLENGE_METHOD_S256)))
                throw new InvalidRequestException("transform algorithm not supported");

        }
    }

    @Override
    public void validateScope(final TokenRequest tokenRequest, final ClientDetails client)
            throws InvalidScopeException {

        /**
         * TODO: 1st check if the authorization request has code challenge
         * validate if the token request is valid pkce request or not based on
         * the authorization request
         **/

        final String code = tokenRequest.getRequestParameters().get(AuthorizationCodeGrant.CODE);

        if (Utils.isNullOrEmpty(code))
            return;

        final OAuth2Authentication oAuth2Authentication = oAuth2AuthorizationCodeServices.getAuthenticationCode(code);

        if (Utils.isNull(oAuth2Authentication))
            throw new InvalidGrantException("Authorization request not found");

        final OAuth2Request persistedRequest = oAuth2Authentication.getOAuth2Request();

        if (Utils.isNull(persistedRequest))
            throw new InvalidGrantException("The request doesnt pass the challenge");

        if (persistedRequest.getRequestParameters().containsKey(AuthorizationCodeGrant.CODE_CHALLENGE)) {

            final String codeChallenge = persistedRequest.getRequestParameters()
                    .get(AuthorizationCodeGrant.CODE_CHALLENGE);
            final String codeChallengeMethod = persistedRequest.getRequestParameters()
                    .get(AuthorizationCodeGrant.CODE_CHALLENGE_METHOD);

            final String codeVerifier = tokenRequest.getRequestParameters().get(AuthorizationCodeGrant.CODE_VERIFIER);

            if (Utils.isNullOrEmpty(codeVerifier))
                throw new InvalidGrantException("Code verifier required");

            if (Utils.isNull(codeChallengeMethod) || Utils.isNullOrEmpty(codeChallenge))
                throw new InvalidGrantException("Code challenge not found");

            if (codeChallengeMethod.equalsIgnoreCase(CODE_CHALLENGE_METHOD_S256)) {
                try {

                    if (!makeCodeChallenge(codeVerifier).equals(codeChallenge))
                        throw new InvalidGrantException("Code challenge doest match with given challenge method");

                } catch (UnsupportedEncodingException | NoSuchAlgorithmException ex) {
                    throw new InvalidGrantException(ex.getMessage());
                }
            } else if (codeChallengeMethod.equalsIgnoreCase(CODE_CHALLENGE_METHOD_PLAIN)
                    || codeChallengeMethod.isEmpty()) {
                if (!codeVerifier.equals(codeChallenge))
                    throw new InvalidGrantException("Code challenge doest match with given challenge method");
            }

        }
    }

    private String EncodeBase64URL(final byte[] arg) {
        String encoded = new String(Base64Utils.encode(arg));

        // From https://datatracker.ietf.org/doc/html/rfc7636 Appendix A. Notes
        // on Implementing Base64url Encoding without Padding

        encoded = encoded.split("=")[0];
        encoded = encoded.replace('+', '-');
        encoded = encoded.replace('/', '_');

        return encoded;
    }

    public String makeCodeChallenge(final String codeVerifier)
            throws UnsupportedEncodingException, NoSuchAlgorithmException {

        final byte[] bytes = codeVerifier.getBytes(StandardCharsets.US_ASCII);
        final MessageDigest messageDigest = MessageDigest.getInstance("SHA-256");
        messageDigest.update(bytes, 0, bytes.length);
        final byte[] digest = messageDigest.digest();

        return EncodeBase64URL(digest);
    }

}
