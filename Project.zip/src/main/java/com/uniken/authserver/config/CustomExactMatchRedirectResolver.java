package com.uniken.authserver.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.provider.endpoint.ExactMatchRedirectResolver;

/**
 * This class is used for exact matching of registered_redirect_uri against the
 * redirect uri. Presently customization is kept open for future modification
 * hence there is no body in this class.
 * 
 * @author Uday T
 */
@Configuration
public class CustomExactMatchRedirectResolver extends ExactMatchRedirectResolver {

}
