package com.uniken.authserver.config;

import org.springframework.beans.factory.config.ServiceLocatorFactoryBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.uniken.authserver.mq.consumer.MessageProcessorFactory;

/**
 * Service Locator Facade bean used to configure the service locator
 * 
 * @author Uday T
 */
@Configuration
public class ServiceLocatorConfig {

    /**
     * Identifies and returns the service locator factory bean
     * 
     * @return
     */
    @Bean("locateServiceFactory")
    public ServiceLocatorFactoryBean serviceLocatorFactoryBean() {
        final ServiceLocatorFactoryBean factoryBean = new ServiceLocatorFactoryBean();
        factoryBean.setServiceLocatorInterface(MessageProcessorFactory.class);
        return factoryBean;
    }
}
