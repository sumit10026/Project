package com.uniken.authserver.services.impl;

import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mongodb.client.result.UpdateResult;
import com.uniken.authserver.repo.api.WebDevMasterRepo;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.user.DeviceStatus;
import com.uniken.domains.user.vos.SecureCookie;

/**
 * Service for all operations related to web device master collection.
 * 
 * @author Uday T
 */
@Service
public class WebDevMasterServiceImpl
        implements
        WebDevMasterService {

    private static final Logger LOG = LoggerFactory.getLogger(WebDevMasterServiceImpl.class);

    @Autowired
    private WebDevMasterRepo webDevMasterRepo;

    @Override
    public WebDevMaster fetchWebDeviceMaster(final String webDeviceCheckSum) {
        LOG.info("fetchWebDeviceMaster()=> fetching web device master record");

        if (Utils.isNullOrEmpty(webDeviceCheckSum)) {
            throw new IllegalArgumentException("Web Device Checksum value is null or empty");
        }

        return webDevMasterRepo.fetchWebDeviceMaster(webDeviceCheckSum);
    }

    @Override
    public void addWebDeviceMaster(final WebDevMaster webDevMaster) {
        LOG.info("addWebDeviceMaster()=> adding web device master record");
        if (webDevMaster == null) {
            throw new IllegalArgumentException("WebDevMaster is null");
        }
        webDevMasterRepo.addWebDeviceMaster(webDevMaster);
    }

    @Override
    public WebDevMaster updateWebDeviceMaster(final WebDevMaster webDevMaster) {
        LOG.info("updateWebDeviceMaster()=> updating web device master record");
        if (webDevMaster == null) {
            throw new IllegalArgumentException("WebDevMaster is null");
        }
        return webDevMasterRepo.updateWebDeviceMaster(webDevMaster);
    }

    @Override
    public void blockBrowser(final String webDeviceParameterChecksum, final Map<String, Object> webDfp) {
        LOG.info("blockBrowser() : Request recevied to block the browser");
        final WebDevMaster blockedDevice = fetchWebDeviceMaster(webDeviceParameterChecksum);
        blockedDevice.setStatus(DeviceStatus.BLOCKED.getName());
        blockedDevice.setUpdatedTS(new Date());
        webDevMasterRepo.updateWebDeviceMaster(blockedDevice);
        LOG.info("blockBrowser() : Browser blocked");
    }

    @Override
    public boolean isBrowserBlocked(final String webDeviceParameterChecksum) {
        LOG.info("isBrowserBlocked() : Request recevied to check if the browser is blocked");
        final WebDevMaster fetchedDevice = webDevMasterRepo.fetchWebDeviceMaster(webDeviceParameterChecksum);
        if (fetchedDevice != null && DeviceStatus.BLOCKED.getName().equals(fetchedDevice.getStatus())) {
            return true;
        }
        return false;
    }

    @Override
    public WebDevMaster fetchWebDeviceMasterUsingSecureCookieValue(final String secureCookieValue) {
        LOG.info("fetchWebDeviceMasterUsingSecureCookie()=> fetching web device master record");

        if (Utils.isNullOrEmpty(secureCookieValue)) {
            throw new IllegalArgumentException("Web Device Checksum value is null or empty");
        }

        return webDevMasterRepo.fetchWebDeviceMasterUsingSecureCookieValue(secureCookieValue);
    }

    @Override
    public UpdateResult addSecureCookieForWebDevMaster(final String webDeviceUuid, final SecureCookie secureCookie) {
        LOG.info("addSecureCookieForWebDevMaster()=> Updating secureCookie entry inside webDevMaster");

        if (Utils.isNullOrEmpty(webDeviceUuid)) {
            throw new IllegalArgumentException("Web Device UUID sum value is null or empty");
        }

        if (secureCookie == null) {
            throw new IllegalArgumentException("SecureCookie object is null");
        }

        return webDevMasterRepo.addSecureCookieForWebDevMaster(webDeviceUuid, secureCookie);
    }

    @Override
    public UpdateResult updateSecureCookieForWebDevMaster(final String webDeviceUuid, final SecureCookie secureCookie) {
        LOG.info("updateSecureCookieForWebDevMaster()=> Updating secureCookie entry inside webDevMaster");

        if (Utils.isNullOrEmpty(webDeviceUuid)) {
            throw new IllegalArgumentException("Web Device UUID sum value is null or empty");
        }

        if (secureCookie == null) {
            throw new IllegalArgumentException("SecureCookie object is null");
        }

        return webDevMasterRepo.updateSecureCookieForWebDevMaster(webDeviceUuid, secureCookie);
    }
}
