package com.uniken.authserver.services.impl;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.oauth2.provider.token.DefaultAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.DefaultUserAuthenticationConverter;
import org.springframework.security.oauth2.provider.token.UserAuthenticationConverter;

/**
 * Custom default access token converter for REL-ID Web Implementation.
 * 
 * @author Uday T
 */
public class CustomDefaultAccessTokenConverter extends DefaultAccessTokenConverter {

    private static final Logger LOG = LoggerFactory.getLogger(CustomDefaultAccessTokenConverter.class);

    private final UserAuthenticationConverter userTokenConverter = new DefaultUserAuthenticationConverter();

    private boolean includeGrantType;

    private final String scopeAttribute = SCOPE;

    private final String clientIdAttribute = CLIENT_ID;

    @Override
    public Map<String, ?> convertAccessToken(final OAuth2AccessToken token, final OAuth2Authentication authentication) {
        final Map<String, Object> response = new HashMap<String, Object>();
        final OAuth2Request clientToken = authentication.getOAuth2Request();

        if (!authentication.isClientOnly()) {
            response.putAll(userTokenConverter.convertUserAuthentication(authentication.getUserAuthentication()));
        } else {
            LOG.info("convertAccessToken() : do not add authorities in access token");
            // if (clientToken.getAuthorities() != null &&
            // !clientToken.getAuthorities().isEmpty()) {
            // response.put(UserAuthenticationConverter.AUTHORITIES,
            // AuthorityUtils.authorityListToSet(clientToken.getAuthorities()));
            // }
        }

        if (token.getScope() != null) {
            response.put(scopeAttribute, token.getScope());
        }
        if (token.getAdditionalInformation().containsKey(JTI)) {
            response.put(JTI, token.getAdditionalInformation().get(JTI));
        }

        if (token.getExpiration() != null) {
            response.put(EXP, token.getExpiration().getTime() / 1000);
        }

        if (includeGrantType && authentication.getOAuth2Request().getGrantType() != null) {
            response.put(GRANT_TYPE, authentication.getOAuth2Request().getGrantType());
        }

        response.putAll(token.getAdditionalInformation());

        response.put(clientIdAttribute, clientToken.getClientId());
        if (clientToken.getResourceIds() != null && !clientToken.getResourceIds().isEmpty()) {
            response.put(AUD, clientToken.getResourceIds());
        }
        return response;
    }

}
