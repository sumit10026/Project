package com.uniken.authserver.services.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uniken.authserver.domains.ValidateUserRequest;
import com.uniken.totp.exception.TOTPValidationException;

public interface AuthenticateTotpService {

    /**
     * This service validates the user entered TOTP, if it is valid then returns
     * true else returns false.
     * 
     * @param request
     * @param response
     * @param requestBody
     * @param appAgentName
     * @return
     * @throws TOTPValidationException
     */
    public boolean validateTotp(final HttpServletRequest request, final HttpServletResponse response,
            final ValidateUserRequest validateUserRequest, final String appAgentName) throws TOTPValidationException;

}
