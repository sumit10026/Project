package com.uniken.authserver.services.impl;

import java.lang.reflect.Type;
import java.net.HttpCookie;
import java.time.Instant;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.bson.types.ObjectId;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import com.google.api.client.util.Sets;
import com.google.gson.reflect.TypeToken;
import com.uniken.authserver.config.CustomExactMatchRedirectResolver;
import com.uniken.authserver.exception.InvalidSecureCookieException;
import com.uniken.authserver.exception.InvalidUserException;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.services.api.OAuth2ClientDetailsService;
import com.uniken.authserver.services.api.SecureCookieService;
import com.uniken.authserver.services.api.SessionService;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.authserver.utility.AuthenticationUtils;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.RegisterUserSessionUtils;
import com.uniken.authserver.utility.SessionConstants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.enums.UserBrowserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.relid.device.UserLocation;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.user.DeviceStatus;
import com.uniken.domains.relid.user.UserBrowser;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.domains.user.vos.SecureCookie;
import com.uniken.domains.user.vos.WebUserDetails;
import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;

@Service
public class SessionServiceImpl
        implements
        SessionService {

    private static final Logger LOG = LoggerFactory.getLogger(SessionServiceImpl.class);

    @Autowired
    private SecureCookieService secureCookieService;

    @Autowired
    private WebDevMasterService webDevMasterService;

    @Autowired
    private UserAuthInfoRepo userAuthInfoRepo;

    @Autowired
    private OAuth2ClientDetailsService customClientDetailService;

    @Autowired
    CustomExactMatchRedirectResolver customExactMatchRedirectResolver;

    @SuppressWarnings("unchecked")
    @Override
    public void preLogoutSecureCookieHandling(final HttpServletRequest request, final HttpServletResponse response)
            throws Exception {

        LOG.info("preLogoutSecureCookieHandling() -> Handling secure cookie pre logout");

        if (request.getSession().getAttribute(SessionConstants.IS_SECURE_COOKIE_SET) != null
                && (Boolean) request.getSession().getAttribute(SessionConstants.IS_SECURE_COOKIE_SET)) {
            LOG.debug("preLogoutSecureCookieHandling() -> Secure cookie already handled");
            return;
        }

        response.setHeader("X-FRAME-OPTIONS", "DENY");

        final Map<String, Object> inputParameters = (Map<String, Object>) request.getSession()
                .getAttribute(SessionConstants.REQ_PARAM_MAP);

        final String loginId = (String) inputParameters.get(Constants.REQ_PARAM_USERNAME);

        final boolean isUserSelectedRememberMe = (boolean) inputParameters.get(Constants.REQ_PARAM_REMEMBER_ME);
        final boolean isRememberMeFunctionalityEnabled = PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS
                .isRememberMe();
        final Set<String> lastLoginMethod = (Set<String>) inputParameters.get(Constants.REQ_PARAM_LAST_LOGIN_METHOD);

        /**
         * Secure Cookie Implementation : If rememberMe is enabled, then write
         * the secure cookie within the response. </br>
         * Case 1 : If request doesn't contain secure cookie & rememberMe is
         * enabled, then generate secure cookie & associate it with
         * WebDevMaster. At the end associate webDeviceUuid with UserAuthInfo.
         * Case 2 : If request contains secure cookie & if it is already mapped
         * with the WebDevMaster, then check for association of WebDeviceUuid
         * with UserAuthInfo. If it is present, then just update the updated_ts
         * in browsers of UserAuthInfo. </br>
         * Case 3 : If different user is login from the same browser, for which
         * we have created the cookie, then in that case existing cookie will be
         * discarded. After that new cookie will be created & rest of the flow
         * is same which is mentioned in case 1.
         */

        final boolean isRememberMe = isRememberMeFunctionalityEnabled && isUserSelectedRememberMe;

        final Optional<Cookie> optionalRequestCookie = Arrays.stream(request.getCookies())
                .filter(ck -> StringUtils.equals(Constants.SECURE_COOKIE_NAME, ck.getName())).findFirst();

        WebDevMaster webDevMaster = null;
        Cookie secureCookie = null;

        /**
         * FIXME : Handle in Phase 2, Need to update existing webDevMaster with
         * new cookie in case of expired cookies
         **/
        if (optionalRequestCookie.isPresent()) {
            secureCookie = optionalRequestCookie.get();
            webDevMaster = webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(secureCookie.getValue());

            if (webDevMaster == null) {
                EventLogger.log(EventId.RelidAuthServer.INVALID_SECURE_COOKIE, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request), "Request Has Invalid Secure Cookie.");
                throw new InvalidSecureCookieException("Request Has Invalid Secure Cookie.");
            }
        } else if (isRememberMe) {
            webDevMaster = createWebDevMaster(inputParameters);
        } else {
            return;
        }

        final String webDeviceUuid = webDevMaster.getWebDeviceUuid();

        final UserAuthInfoVO userAuthInfo = userAuthInfoRepo.fetchUserDetailsFromLoginId(loginId);

        if (userAuthInfo == null) {
            EventLogger.log(EventId.RelidAuthServer.USER_NOT_FOUND, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "Invalid User");
            throw new InvalidUserException("Invalid User : User is not registered in the system");
        }

        final Optional<UserBrowser> optionalBrowser = userAuthInfo.getWebUserDetails().getBrowsers().stream()
                .filter(browser -> StringUtils.equals(webDeviceUuid, browser.getWebDeviceUuid())).findFirst();

        UserBrowser browser = null;
        if (optionalBrowser.isPresent()) {
            browser = optionalBrowser.get();
            browser.setLastLoginTs(new Date());
            browser.setLastLoginMehod(lastLoginMethod);

            if (secureCookie != null) {
                final String updatedCookie = secureCookieService
                        .generateSecureCookieByGivenValue(secureCookie.getValue());
                final String canonicalUpdatedCookie = updatedCookie.replace("\n", "").replace("\r", "");

                updateSecureCookieForWebDevMaster(webDevMaster, canonicalUpdatedCookie);

                EventLogger.log(EventId.RelidAuthServer.UPDATE_SECURE_COOKIE, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request), "Secure Cookie Updated");

                // Set the cookie in header
                response.setHeader(HttpHeaders.SET_COOKIE, canonicalUpdatedCookie);
                request.getSession().setAttribute(SessionConstants.IS_SECURE_COOKIE_SET, true);
            }
        } else if (isRememberMe) {
            browser = createUserBrowser(webDeviceUuid, lastLoginMethod);
            userAuthInfo.getWebUserDetails().getBrowsers().add(browser);

            final String freshCookie = secureCookieService.generateSecureCookie();
            final String canonicalFreshCookie = freshCookie.replace("\n", "").replace("\r", "");

            associateFreshCookieWithWebDevMaster(webDevMaster, canonicalFreshCookie);

            EventLogger.log(EventId.RelidAuthServer.ADD_SECURE_COOKIE, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "Secure Cookie Added");

            // Set the cookie in header
            response.addHeader(HttpHeaders.SET_COOKIE, canonicalFreshCookie);
            request.getSession().setAttribute(SessionConstants.IS_SECURE_COOKIE_SET, true);

        } else {
            return;
        }

        userAuthInfoRepo.updateUserAuthInfoDoc(loginId,
                UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR,
                userAuthInfo.getWebUserDetails().getBrowsers());
        EventLogger.log(EventId.RelidAuthServer.ADD_USER_BROWSER, Utils.getClientIpAddress(request),
                AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                AuthenticationUtils.getUserAgent(request), "User Browser Added");

        LOG.info("webDevMaster :: {}", webDevMaster.getWebDeviceUuid());

    }

    /*
     * Adding SecureCookie
     */

    @SuppressWarnings("unchecked")
    public WebDevMaster createSecureCookieForFIDO2() {

        final HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.currentRequestAttributes())
                .getRequest();
        final HttpServletResponse response = ((ServletRequestAttributes) RequestContextHolder
                .currentRequestAttributes()).getResponse();
        final HttpSession session = request.getSession();

        final Map<String, Object> inputParameters = (Map<String, Object>) session
                .getAttribute(SessionConstants.REQ_PARAM_MAP);

        final Set<String> lastLoginMethod = (Set<String>) inputParameters.get(Constants.REQ_PARAM_LAST_LOGIN_METHOD);

        final String loginId = (String) inputParameters.get(Constants.REQ_PARAM_USERNAME);

        final UserAuthInfoVO userAuthInfo = userAuthInfoRepo.fetchUserDetailsFromLoginId(loginId);
        UserBrowser browser = null;

        final WebDevMaster webDevMaster = createWebDevMaster(inputParameters);
        final String webDeviceUuid = webDevMaster.getWebDeviceUuid();

        browser = createUserBrowser(webDeviceUuid, lastLoginMethod);
        userAuthInfo.getWebUserDetails().getBrowsers().add(browser);

        final String freshCookie = secureCookieService.generateSecureCookie();

        LOG.info("createSecureCookieForFIDO2() created fresh cookie");
        final String canonicalFreshCookie = freshCookie.replace("\n", "").replace("\r", "");

        associateFreshCookieWithWebDevMaster(webDevMaster, canonicalFreshCookie);

        userAuthInfoRepo.updateUserAuthInfoDoc(loginId,
                UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR,
                userAuthInfo.getWebUserDetails().getBrowsers());

        // Set the cookie in header
        response.addHeader(HttpHeaders.SET_COOKIE, canonicalFreshCookie);
        session.setAttribute(SessionConstants.IS_SECURE_COOKIE_SET, true);
        // request.getSession().setAttribute(SessionConstants.REGISTRATION_SECURE_COOKIE,
        // canonicalFreshCookie);

        return webDevMaster;

    }

    /**
     * @param webDevMaster
     * @param cookie
     * @param update
     */
    public void associateFreshCookieWithWebDevMaster(final WebDevMaster webDevMaster, final String cookie) {

        if (webDevMaster == null || StringUtils.isBlank(cookie)) {
            throw new IllegalArgumentException("Provided WebDevMaster or Cookie is not valid");
        }

        final SecureCookie secureCookie = new SecureCookie();

        final HttpCookie httpCookie = validateAndConvertStringCookieIntoHttpCookie(cookie);

        secureCookie.setSecureCookieValue(httpCookie.getValue());
        secureCookie.setSecureCookieInfo(cookie);
        secureCookie.setSecureCookieCreatedTs(new Date());
        secureCookie.setSecureCookieExpiryTs(
                Date.from(Instant.now().plusSeconds(PropertyConstants.DEFAULT_COOKIE_EXPIRY_TIME_IN_SECONDS)));
        secureCookie.setSecureCookieMaxAgeInSeconds(PropertyConstants.DEFAULT_COOKIE_EXPIRY_TIME_IN_SECONDS);

        webDevMaster.setSecureCookie(secureCookie);

        webDevMasterService.addSecureCookieForWebDevMaster(webDevMaster.getWebDeviceUuid(), secureCookie);

    }

    /**
     * @param webDevMaster
     * @param cookie
     */
    public void updateSecureCookieForWebDevMaster(final WebDevMaster webDevMaster, final String cookie) {
        if (webDevMaster == null || StringUtils.isBlank(cookie)) {
            throw new IllegalArgumentException("Provided WebDevMaster or Cookie is not valid");
        }

        final SecureCookie secureCookie = webDevMaster.getSecureCookie();

        secureCookie.setSecureCookieUpdatedTs(new Date());
        secureCookie.setSecureCookieExpiryTs(
                Date.from(Instant.now().plusSeconds(PropertyConstants.DEFAULT_COOKIE_EXPIRY_TIME_IN_SECONDS)));
        secureCookie.setSecureCookieMaxAgeInSeconds(PropertyConstants.DEFAULT_COOKIE_EXPIRY_TIME_IN_SECONDS);
        secureCookie.setSecureCookieInfo(cookie);

        webDevMasterService.updateSecureCookieForWebDevMaster(webDevMaster.getWebDeviceUuid(), secureCookie);
    }

    public HttpCookie validateAndConvertStringCookieIntoHttpCookie(final String cookie) {
        final List<HttpCookie> cookieList = HttpCookie.parse(cookie);

        if (CollectionUtils.isEmpty(cookieList)) {
            throw new IllegalArgumentException("Provided Cookie is not valid");
        }

        final HttpCookie httpCookie = cookieList.get(0);
        if (httpCookie == null || StringUtils.isBlank(httpCookie.getValue())) {
            throw new IllegalArgumentException("Unable to parse into the HttpCookie");
        }
        return httpCookie;
    }

    /**
     * @param webDeviceUuid
     * @return
     */
    public UserBrowser createUserBrowser(final String webDeviceUuid, final Set<String> lastLoginMethod) {
        final UserBrowser browser = new UserBrowser();
        browser.setId(new ObjectId());
        browser.setCreatedTs(new Date());
        browser.setLastLoginTs(new Date());
        browser.setLastLoginMehod(lastLoginMethod);
        browser.setStatus(UserBrowserStatus.ACTIVE.getValue());
        browser.setWebDeviceUuid(webDeviceUuid);
        browser.setUserOptedOutForFidoReg(false);
        return browser;
    }

    /**
     * This method creates the new WebDevMaster.
     * 
     * @param request
     * @return
     */
    private WebDevMaster createWebDevMaster(final Map<String, Object> inputParameters) {

        // Creating new WebDevMaster
        final String userLocationStr = (String) inputParameters.get(WebDevMaster.USER_LOCATION_STR);
        final UserLocation userLocation = Constants.GSON_BSON.fromJson(userLocationStr, UserLocation.class);

        final Type hashType = new TypeToken<HashMap<String, Object>>() {
        }.getType();
        final Map<String, Object> webDeviceParameter = Constants.GSON
                .fromJson((String) inputParameters.get(WebDevMaster.WEB_DEV_PARAMETERS_STR), hashType);

        final WebDevMaster webDevMaster = new WebDevMaster(Utils.secureRandomUUIDGenerator(),
                DeviceStatus.CREATED.getName(), userLocation, webDeviceParameter, new Date(), new Date(), null);

        LOG.info("createWebDevMaster ::: uuid :: {} ", webDevMaster.getWebDeviceUuid());

        // Create Entry of WebDevMaster in DB
        webDevMasterService.addWebDeviceMaster(webDevMaster);

        return webDevMaster;

    }

    @Override
    public void resetAuthSessionParameters(final HttpServletRequest request) {
        final HttpSession session = request.getSession();

        session.setAttribute(SessionConstants.VALIDATED_AUTH_TYPES, Sets.newHashSet());
        session.setAttribute(SessionConstants.PENDING_AUTH_TYPES, Sets.newHashSet());

        session.setAttribute(SessionConstants.CURRENT_USERNAME, "");
        session.removeAttribute(SessionConstants.VALIDATED_USERNAME);

        session.removeAttribute(SessionConstants.ATTEMPTS_COUNTER);
        session.removeAttribute(SessionConstants.AUTH_GENERATION_ATTEMPT_COUNTER);
        session.setAttribute(SessionConstants.EXCEPTION_ATTRS_MAP, new HashMap<String, Object>());

        session.setAttribute(SessionConstants.IS_REDIRECT_TO_ERROR_PAGE, false);
        session.removeAttribute(SessionConstants.ERROR_DISPLAY_MSG);
    }

    @Override
    public void resetOfferedAuthSessionParameters(final HttpServletRequest request) {
        final HttpSession session = request.getSession();

        session.setAttribute(SessionConstants.OFFERED_AUTH_TYPES, Sets.newHashSet());
        session.setAttribute(SessionConstants.OFFERED_USERNAME, "");
    }

    @Override
    public boolean isValidRedirectURI(final String redirectUri, final String clientId) {
        boolean isValidRedirecURI = false;
        if (StringUtils.isNotBlank(redirectUri) && StringUtils.isNotBlank(clientId)) {
            final EnterpriseInfo clientDetails = (EnterpriseInfo) customClientDetailService
                    .loadClientByClientId(clientId);
            try {
                customExactMatchRedirectResolver.resolveRedirect(redirectUri, clientDetails);
                isValidRedirecURI = true;
            } catch (final Exception e) {
                LOG.error("Invalid Redirect URI : {}", redirectUri, e);
            }
        }

        return isValidRedirecURI;
    }

    @Override
    public void registerUserSecureCookieHandling(final HttpServletRequest request, final HttpServletResponse response)
            throws Exception {

        LOG.info("registerUserSecureCookieHandling() -> Handling secure cookie pre logout");

        if (request.getSession().getAttribute(SessionConstants.IS_SECURE_COOKIE_SET) != null
                && (Boolean) request.getSession().getAttribute(SessionConstants.IS_SECURE_COOKIE_SET)) {
            LOG.debug("registerUserSecureCookieHandling() -> Secure cookie already handled");
            return;
        }

        response.setHeader("X-FRAME-OPTIONS", "DENY");

        @SuppressWarnings("unchecked")
        final Map<String, Object> inputParameters = (Map<String, Object>) request.getSession()
                .getAttribute(SessionConstants.REQ_PARAM_MAP);

        final String loginId = (String) inputParameters.get(Constants.REQ_PARAM_USERNAME);

        final boolean isUserSelectedRememberMe = (boolean) inputParameters.get(Constants.REQ_PARAM_REMEMBER_ME);

        final boolean isRememberMeFunctionalityEnabled = PropertyConstants.AUTH_SERVER_ALLOWED_REG_FACTORS
                .isRememberMe();
        final Set<String> lastLoginMethod = RegisterUserSessionUtils.getRegisteredAuthTypes().stream()
                .map(AuthType::getName).collect(Collectors.toSet());

        /**
         * Secure Cookie Implementation : If rememberMe is enabled, then write
         * the secure cookie within the response. </br>
         * Case 1 : If request doesn't contain secure cookie & rememberMe is
         * enabled, then generate secure cookie & associate it with
         * WebDevMaster. At the end associate webDeviceUuid with UserAuthInfo.
         * Case 2 : If request contains secure cookie & if it is already mapped
         * with the WebDevMaster, then check for association of WebDeviceUuid
         * with UserAuthInfo. If it is present, then just update the updated_ts
         * in browsers of UserAuthInfo. </br>
         * Case 3 : If different user is login from the same browser, for which
         * we have created the cookie, then in that case existing cookie will be
         * discarded. After that new cookie will be created & rest of the flow
         * is same which is mentioned in case 1.
         */

        final boolean isRememberMe = isRememberMeFunctionalityEnabled && isUserSelectedRememberMe;

        final Optional<Cookie> optionalRequestCookie = Arrays.stream(request.getCookies())
                .filter(ck -> StringUtils.equals(Constants.SECURE_COOKIE_NAME, ck.getName())).findFirst();

        WebDevMaster webDevMaster = null;
        Cookie secureCookie = null;

        /**
         * FIXME : Handle in Phase 2, Need to update existing webDevMaster with
         * new cookie in case of expired cookies
         **/
        if (optionalRequestCookie.isPresent()) {
            secureCookie = optionalRequestCookie.get();
            webDevMaster = webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(secureCookie.getValue());

            if (webDevMaster == null) {
                EventLogger.log(EventId.RelidAuthServer.INVALID_SECURE_COOKIE, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request), "Request Has Invalid Secure Cookie.");
                throw new InvalidSecureCookieException("Request Has Invalid Secure Cookie.");
            }

        } else if (isRememberMe) {
            webDevMaster = createWebDevMaster(inputParameters);
        } else {
            return;
        }

        final String webDeviceUuid = webDevMaster.getWebDeviceUuid();

        final UserAuthInfoVO userAuthInfo = userAuthInfoRepo.fetchUserDetailsFromLoginId(loginId);

        if (userAuthInfo == null) {
            EventLogger.log(EventId.RelidAuthServer.USER_NOT_FOUND, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "Invalid User");
            throw new InvalidUserException("Invalid User : User is not registered in the system");
        }

        final Optional<UserBrowser> optionalBrowser = userAuthInfo.getWebUserDetails().getBrowsers().stream()
                .filter(browser -> StringUtils.equals(webDeviceUuid, browser.getWebDeviceUuid())).findFirst();

        UserBrowser browser = null;
        if (optionalBrowser.isPresent()) {
            browser = optionalBrowser.get();
            browser.setLastLoginTs(new Date());
            browser.setLastLoginMehod(lastLoginMethod);

            if (secureCookie != null) {
                final String updatedCookie = secureCookieService
                        .generateSecureCookieByGivenValue(secureCookie.getValue());
                final String canonicalUpdatedCookie = updatedCookie.replace("\n", "").replace("\r", "");

                updateSecureCookieForWebDevMaster(webDevMaster, canonicalUpdatedCookie);

                EventLogger.log(EventId.RelidAuthServer.UPDATE_SECURE_COOKIE, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request), "Secure Cookie Updated");

                // Set the cookie in header
                response.setHeader(HttpHeaders.SET_COOKIE, canonicalUpdatedCookie);
                request.getSession().setAttribute(SessionConstants.IS_SECURE_COOKIE_SET, true);
            }
        } else if (isRememberMe) {
            browser = createUserBrowser(webDeviceUuid, lastLoginMethod);
            userAuthInfo.getWebUserDetails().getBrowsers().add(browser);

            final String freshCookie = secureCookieService.generateSecureCookie();
            final String canonicalFreshCookie = freshCookie.replace("\n", "").replace("\r", "");

            associateFreshCookieWithWebDevMaster(webDevMaster, canonicalFreshCookie);

            EventLogger.log(EventId.RelidAuthServer.ADD_SECURE_COOKIE, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "Secure Cookie Added");

            // Set the cookie in header
            response.addHeader(HttpHeaders.SET_COOKIE, canonicalFreshCookie);
            request.getSession().setAttribute(SessionConstants.IS_SECURE_COOKIE_SET, true);

        } else {
            return;
        }

        userAuthInfoRepo.updateUserAuthInfoDoc(loginId,
                UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR,
                userAuthInfo.getWebUserDetails().getBrowsers());
        EventLogger.log(EventId.RelidAuthServer.ADD_USER_BROWSER, Utils.getClientIpAddress(request),
                AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                AuthenticationUtils.getUserAgent(request), "User Browser Added");

    }

}
