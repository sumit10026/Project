package com.uniken.authserver.services.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uniken.authserver.domains.Configuration;
import com.uniken.authserver.domains.ConfigurationResponse;
import com.uniken.authserver.exception.InvalidSecureCookieException;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.services.api.ConfigurationService;
import com.uniken.authserver.services.api.SecureCookieService;
import com.uniken.authserver.services.api.SessionService;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.authserver.utility.AuthenticationUtils;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;
import com.uniken.pass.handler.library.sync.api.PassHandler;

@Service
public class ConfigurationServiceImpl
        implements
        ConfigurationService {

    private static final Logger LOG = LoggerFactory.getLogger(ConfigurationServiceImpl.class);

    @Autowired
    WebDevMasterService webDevMasterService;

    @Autowired
    UserAuthInfoRepo userAuthInfoRepo;

    @Autowired
    SecureCookieService secureCookieService;

    @Autowired
    SessionService sessionService;

    @Autowired
    private PassHandler passHandler;

    @Override
    public ConfigurationResponse getConfigurations(final HttpServletRequest request,
            final String webDeviceParameterChecksum) {
        final Configuration config = new Configuration();
        config.setRememberMe(PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isRememberMe());
        config.setAlwaysAskForPassword(PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isAlwaysAskForPassword());
        config.setPassword(PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isPassword());
        List<Map<String, String>> userIdList = new ArrayList<>();
        LOG.info("Auth Factors config: {}", config);

        if (PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isRememberMe() && request.getCookies() != null) {
            final Optional<Cookie> optionalCookie = Arrays.stream(request.getCookies())
                    .filter(ck -> StringUtils.equals(Constants.SECURE_COOKIE_NAME, ck.getName())).findFirst();

            Cookie secureCookie = null;
            WebDevMaster webDevMaster = null;

            if (optionalCookie.isPresent() && !secureCookieService.isSecureCookieExpired(request)) {
                secureCookie = optionalCookie.get();

                if (secureCookieService.decryptSecureCookie(secureCookie.getValue()) == null) {
                    EventLogger.log(EventId.RelidAuthServer.INVALID_SECURE_COOKIE, Utils.getClientIpAddress(request),
                            AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                            AuthenticationUtils.getUserAgent(request), "Request Has Invalid Secure Cookie");
                    throw new InvalidSecureCookieException("Request Has Invalid Secure Cookie");
                }

                webDevMaster = webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(secureCookie.getValue());

                if (webDevMaster != null) {
                    userIdList = userAuthInfoRepo.fetchAssociatedUserWithWebDeviceUuid(webDevMaster.getWebDeviceUuid());
                }
            }
        }

        /**
         * Reset Session Parameters Related to Auth Type, to avoid session
         * parameters clash for different user.
         **/
        sessionService.resetAuthSessionParameters(request);
        sessionService.resetOfferedAuthSessionParameters(request);

        return new ConfigurationResponse(config, userIdList);
    }

    public String fetchPublicKey(final HttpServletRequest request) {
        return passHandler.retrievePublicKey();
    }

}
