package com.uniken.authserver.services.api;

import org.jose4j.jwk.JsonWebKeySet;

/**
 * The Interface JwksService.
 */
public interface JwksService {

    /**
     * Gets the jwks.
     *
     * @return the jwks
     */
    JsonWebKeySet getJwks();
}
