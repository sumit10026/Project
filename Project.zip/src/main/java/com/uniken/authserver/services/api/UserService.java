package com.uniken.authserver.services.api;

import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.RequestBody;

import com.mongodb.client.result.UpdateResult;
import com.uniken.authserver.domains.UserInfo;
import com.uniken.authserver.domains.ValidateUserRequest;
import com.uniken.domains.auth.fido.FIDO2RegisteredAuthenticationModule;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.WebUserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.relid.user.UserBrowser;
import com.uniken.domains.relid.user.WebUserBrowserDetailsDTO;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.domains.user.vos.UserAuthInfoRegAuthModuleVo;
import com.uniken.domains.user.vos.WebUserDetails;

public interface UserService {

    /**
     * This method will check is notification is acted or not by user.
     * 
     * @param correlationID
     *            : Check notification against provided correlationID.
     * @return {@link HttpStatus#OK} when action is taken on the notification
     *         <br>
     *         {@link HttpStatus#ACCEPTED} when no action taken on the
     *         notification. <br>
     *         {@link HttpStatus#NO_CONTENT} when the notification get expired
     *         due to no action from user with in the given expiry time.
     */
    HttpStatus checkIfNotificationIsActed(final String correlationID);

    /**
     * This method will fetch the notification by using provided correlationId
     * and check weather the notification is accepted or not.</br>
     * If notification is approved then it'll return true</br>
     * If notification is rejected then it'll return false</br>
     * If notification is marked as fraud then it'll block the device and return
     * false </br>
     * 
     * @param correlationID
     *            : Use this to fetch the notification
     * @param browserDFPChecksum
     * @param browserDFP
     * @param request
     * @return : True if notification is accepted else false
     */

    boolean checkNotificationResponse(final String correlationID, final String browserDFPChecksum,
            final String browserDFP, final HttpServletRequest request);

    /**
     * This method will validate user using totp. If TOTP validated successfully
     * then it will validate following things
     * <li>If REL-ID Verify notification is acted or not. If acted</li>
     * <li>Then parse the notification response is ACCEPTED || REJECT || FRAUD.
     * If ACCEPTED then continue the flow otherwise throw
     * {@link AccessDeniedException}</li>
     * <li>If notification not acted.. Then publish Discard Notification Request
     * to REL-ID Verify.</li> <br>
     * 
     * @param request
     * @param response
     * @return {@link Authentication} object if validation success.
     * @throws AccessDeniedException
     *             if invalid TOTP or Notification Action.
     * @throws AuthenticationServiceException
     *             if TOTP Validation failed.
     */
    Authentication validateUserByTOTP(HttpServletRequest request, HttpServletResponse response,
            Map<String, Object> inputParameters);

    /**
     * /** This method will fetch the notification by using provided
     * correlationId and check weather the notification is accepted or not.</br>
     * If notification is approved then it'll return true</br>
     * If notification is rejected then it'll return false</br>
     * If notification is marked as fraud then it'll block the device and return
     * false </br>
     * 
     * @param request
     * @param response
     * @return : Authentication object
     */
    Authentication checkUserActionOnNotification(HttpServletRequest request, HttpServletResponse response,
            Map<String, Object> inputParameters);

    /**
     * This method will fetch user info using provided username.
     * 
     * @param username
     *            : username fetched from authentication's principle
     * @return : User details
     */
    UserInfo getUserInfo(String username);

    /**
     * Authenticate user using fido.
     *
     * @param request
     *            the request
     * @param response
     *            the response
     * @param inputParameters
     *            the input parameters
     * @return the authentication
     */
    Authentication authenticateUserUsingFido(HttpServletRequest request, HttpServletResponse response,
            Map<String, Object> inputParameters);

    /**
     * Checks for fido device registered.
     *
     * @param username
     *            the username
     * @return true, if successful
     */
    boolean hasFidoDeviceRegistered(String username);

    /**
     * Checks for fido device registered.
     *
     * @param username
     *            the username
     * @return set of registered transports, if successful
     */
    Set<String> hasFidoDeviceRegisteredTransport(String username);

    /**
     * This method will validate user using smsotp. If SMSOTP validated
     * successfully then it will validate following things
     * <li>If REL-ID Verify notification is acted or not. If acted</li>
     * <li>Then parse the notification response is ACCEPTED || REJECT || FRAUD.
     * If ACCEPTED then continue the flow otherwise throw
     * {@link AccessDeniedException}</li>
     * <li>If notification not acted.. Then publish Discard Notification Request
     * to REL-ID Verify.</li> <br>
     * 
     * @param request
     * @param response
     * @return {@link Authentication} object if validation success.
     * @throws AccessDeniedException
     *             if invalid SMSOTP or Notification Action.
     * @throws AuthenticationServiceException
     *             if SMSOTP Validation failed.
     */
    Authentication validateUserBySMSOTP(HttpServletRequest request, HttpServletResponse response,
            Map<String, Object> inputParameters);

    /**
     * This method will validate user using emailotp. If EMAILOTP validated
     * successfully then it will validate following things
     * <li>If REL-ID Verify notification is acted or not. If acted</li>
     * <li>Then parse the notification response is ACCEPTED || REJECT || FRAUD.
     * If ACCEPTED then continue the flow otherwise throw
     * {@link AccessDeniedException}</li>
     * <li>If notification not acted.. Then publish Discard Notification Request
     * to REL-ID Verify.</li> <br>
     * 
     * @param request
     * @param response
     * @return {@link Authentication} object if validation success.
     * @throws AccessDeniedException
     *             if invalid SMSOTP or Notification Action.
     * @throws AuthenticationServiceException
     *             if SMSOTP Validation failed.
     */
    Authentication validateUserByEmailOTP(HttpServletRequest request, HttpServletResponse response,
            Map<String, Object> inputParameters);

    /**
     * This method is used to generate the SMS OTP for a given user.
     * 
     * @param request
     * @param response
     * @param inputParameters
     * @return
     */
    boolean generateSMSOTP(HttpServletRequest request, HttpServletResponse response,
            Map<String, Object> inputParameters);

    /**
     * This method validates the user & then returns the allowed authentication
     * factors.
     * 
     * @param userName
     * @return {@link AuthType}
     * @throws NoSuchAlgorithmException
     */
    Set<String> getUserAuthFactorsBasedOnUserValidity(HttpServletRequest request, HttpServletResponse response,
            ValidateUserRequest requestBody) throws NoSuchAlgorithmException;

    /**
     * This service simply generates the authentication token for given user.
     * 
     * @param username
     * @return
     */
    Authentication generateAuthenticationTokenForUser(String username);

    /**
     * @param username
     * @return
     */
    UserAuthInfoVO getUserAuthInfoByUserName(String username);

    /**
     * Update web user attempt counter.
     *
     * @param loginId
     *            the login id
     * @param attemptCounters
     *            the attempt counters
     */
    void updateWebUserAttemptCounter(String loginId, List<Integer> attemptCounters);

    /**
     * Unblock web user.
     *
     * @param userAuthInfo
     *            the user auth info
     */
    void unblockWebUser(final WebUserDetails webUserDetails, final String loginId);

    /**
     * Block web user browser
     * 
     * @param userBrowser
     * @param loginId
     * @param webDeviceUuid
     */
    public UpdateResult updateWebUserBrowserStatus(final String loginId, final String webDeviceUuid,
            final WebUserStatus status);

    /**
     * @param loginId
     * @return
     */
    public List<UserBrowser> getListOfUserBrowsers(final String loginId);

    public List<WebUserBrowserDetailsDTO> getBrowsers(final String loginId);

    public Page<UserBrowser> getListOfUserBrowsers(final String loginId, final String search, final Pageable pageable);

    public UpdateResult deleteWebUserBrowser(final String login, final String webDeviceUuid);

    public UpdateResult unRememberWebUserBrowser(final String login, final String webDeviceUuid);

    /**
     * Deletes the browser mapping for user to remove account from account
     * chooser.
     * 
     * @param request
     * @param validateUserRequest
     * @return
     */
    boolean deleteBrowserMappingForUser(HttpServletRequest request, ValidateUserRequest validateUserRequest);

    /**
     * @param loginId
     * @param authGenerationAttemptsCounter
     */
    void updateWebUserAuthGenerationAttemptCounter(String loginId, Map<String, Integer> authGenerationAttemptsCounter);

    /**
     * This method fetches the all the details for specified user.
     * 
     * @param loginId
     * @return {@link UserAuthInfoRegAuthModuleVo}
     */
    UserAuthInfoRegAuthModuleVo fetchUserAuthInfoRegAuthModuleFromLoginId(String loginId);

    /**
     * @param loginId
     * @param authenticatorUuid
     * @return
     */
    boolean deleteRegisteredAuthModule(final String loginId, final String authenticatorUuid);

    /**
     * @param loginId
     * @param regAuthTypeId
     * @param isEnabledState
     * @return
     */
    boolean updateRegAuthFactorStatus(final String loginId, final String authenticatorUuid, boolean isEnabledState);

    /**
     * Fetch registered authentication module from login id.
     *
     * @param loginId
     *            the login id
     * @return the list
     */
    List<FIDO2RegisteredAuthenticationModule> fetchRegisteredAuthenticationModuleFromLoginId(String loginId);

    /**
     * Activate user.
     *
     * @param loginId
     *            the login id
     * @param userCurrentStatus
     *            the user current status
     * @param webOnly
     *            the web only
     * @param authTypes
     *            the auth types
     * @param mobileNumber
     *            the mobile number
     * @param email
     *            the email
     * @return the update result
     */
    UpdateResult activateUser(final String loginId, RelIdUserStatus userCurrentStatus, final boolean webOnly,
            final Set<AuthType> authTypes, String mobileNumber, String email);

    /**
     * @param loginId
     * @param authenticatorUuid
     * @param regAuthModuleList
     * @return
     */
    boolean allowedToDeleteOrDisableAuthFactor(String loginId, String authenticatorUuid,
            List<FIDO2RegisteredAuthenticationModule> regAuthModuleList);

    /**
     * @param loginId
     * @param needAlwaysAskForPasswordCheck
     * @return
     */
    boolean isFidoPlatformRegisteredByUserId(String loginId, boolean needAlwaysAskForPasswordDisabledCheck,
            String authenticatorUuid);

    public boolean validateFidoCredential(final HttpServletRequest request, final HttpServletResponse response,
            @Valid @RequestBody final ValidateUserRequest validateUserRequest);

}
