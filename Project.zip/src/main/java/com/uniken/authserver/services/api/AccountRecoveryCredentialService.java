package com.uniken.authserver.services.api;

import java.util.Set;

import com.uniken.authserver.domains.AccountRecoveryCredentialRequest;
import com.uniken.authserver.domains.AccountRecoveryTokenDetails;

public interface AccountRecoveryCredentialService {

    /**
     * @param accountRecoveryTokenDetails
     * @return
     */
    public Set<String> getResetCredentialFactor(AccountRecoveryTokenDetails accountRecoveryTokenDetails);

    /**
     * @param accountRecoveryCredentialRequest
     * @return
     */
    public boolean resetCredentialFactor(AccountRecoveryCredentialRequest accountRecoveryCredentialRequest);

}
