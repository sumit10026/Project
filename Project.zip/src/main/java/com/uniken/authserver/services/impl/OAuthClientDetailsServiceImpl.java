/**
 * 
 */
package com.uniken.authserver.services.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.security.oauth2.provider.ClientRegistrationException;
import org.springframework.security.oauth2.provider.NoSuchClientException;
import org.springframework.stereotype.Service;

import com.uniken.authserver.services.api.OAuth2ClientDetailsService;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.encdecutils.PropertiesEncryptDecrypt;
import com.uniken.fido2.utils.FIDO2Constants;

/**
 * @author Omkar
 */
@Service
public class OAuthClientDetailsServiceImpl
        implements
        OAuth2ClientDetailsService {

    private static final Logger LOG = LoggerFactory.getLogger(OAuthClientDetailsServiceImpl.class);

    @Resource(name = Constants.RESOURCE_GMDB_MONGO_TEMPLATE)
    private final MongoTemplate gmdbMongoTemplate;

    public OAuthClientDetailsServiceImpl(final MongoTemplate gmdbMongoTemplate) {
        this.gmdbMongoTemplate = gmdbMongoTemplate;
    }

    @Override
    public ClientDetails loadClientByClientId(final String clientId) throws ClientRegistrationException {

        LOG.info("loadClientByClientId() : Load client details by client id: {}", clientId);

        final Query query = new Query(Criteria.where(EnterpriseInfo.CLIENT_ID).is(clientId));
        final EnterpriseInfo details = gmdbMongoTemplate.findOne(query, EnterpriseInfo.class);

        if (details == null) {
            throw new NoSuchClientException(String.format("No client with requested id: %s", clientId));
        }

        // FIXME
        FIDO2Constants.RELYING_PARTY_NAME = details.getClientName();

        details.setClientSecret(PropertiesEncryptDecrypt.decryptWithAES(details.getClientSecret()));
        return details;
    }

}
