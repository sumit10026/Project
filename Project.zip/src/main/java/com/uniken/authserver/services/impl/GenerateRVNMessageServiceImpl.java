package com.uniken.authserver.services.impl;

import java.lang.reflect.Type;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.exceptions.UnauthorizedClientException;
import org.springframework.security.oauth2.common.util.OAuth2Utils;
import org.springframework.security.oauth2.provider.NoSuchClientException;
import org.springframework.stereotype.Service;

import com.google.gson.reflect.TypeToken;
import com.uniken.authserver.domains.GenerateRVNMessageLog;
import com.uniken.authserver.domains.SaveNotificationRequest;
import com.uniken.authserver.domains.WebBrowserParameters;
import com.uniken.authserver.exception.AuthGenerationAttemptCounterExceededException;
import com.uniken.authserver.exception.RelIDAuthServerOAuth2Exception;
import com.uniken.authserver.mq.publisher.RelIdVerifyMessagePublisher;
import com.uniken.authserver.repo.api.GenerateRVNMessageRepo;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.services.api.OAuth2ClientDetailsService;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.authserver.utility.AuthenticationUtils;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.LocationUtils;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.SessionConstants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.enums.auth.OAuthResources;
import com.uniken.domains.relid.device.UserLocation;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.user.RelId;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.domains.util.OAuthUtils;
import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;

/**
 * This service implementation is used for all methods / functions related to
 * REL-ID verify auth type flows
 * 
 * @author Uday T
 */
@Service
public class GenerateRVNMessageServiceImpl {

    private static final Logger LOG = LoggerFactory.getLogger(GenerateRVNMessageServiceImpl.class);

    @Autowired
    private OAuth2ClientDetailsService customClientDetailService;

    @Autowired
    private UserAuthInfoRepo userAuthInfoRepo;

    @Autowired
    private RelIdVerifyMessagePublisher publisher;

    @Autowired
    private GenerateRVNMessageRepo generateRVNMessageRepo;

    @Autowired
    private WebDevMasterService webDevMasterService;

    /**
     * This method processes generate RVN Request message
     * 
     * @param request
     * @param response
     * @param inputParameters
     * @return
     */
    public boolean processGenerateRVNRequest(final HttpServletRequest request, final HttpServletResponse response,
            final Map<String, Object> inputParameters) {

        LOG.info("processGenerateRVNRequest() entered");

        // SAST - fix
        response.setHeader("X-FRAME-OPTIONS", "DENY");

        // validating incoming request
        Utils.validateRequest(request, response, inputParameters);

        final String clientId = (String) inputParameters.get(EnterpriseInfo.CLIENT_ID);
        final String userName = (String) inputParameters.get(Constants.REQ_PARAM_USERNAME);
        final String scopeStr = (String) inputParameters.get(EnterpriseInfo.SCOPE);
        final boolean rememberMe = (boolean) inputParameters.get(Constants.REQ_PARAM_REMEMBER_ME);

        final HttpSession httpSession = request.getSession();

        final String webDeviceParametersString = (String) inputParameters.get(WebDevMaster.WEB_DEV_PARAMETERS_STR);

        LOG.info("processGenerateRVNRequest() : Generate RVN Request received for client Id : {} and Username : {}.",
                clientId, userName);

        final Type hashType = new TypeToken<HashMap<String, Object>>() {
        }.getType();

        final Map<String, Object> webDeviceParameter = Constants.GSON.fromJson(webDeviceParametersString, hashType);

        final EnterpriseInfo clientDetails = (EnterpriseInfo) customClientDetailService.loadClientByClientId(clientId);

        // Validating enterprise id details
        validateEnterpriseIDDetails(clientDetails, clientId, scopeStr);

        final UserAuthInfoVO userAuthInfoVO = userAuthInfoRepo.fetchUserDetailsFromLoginId(userName);

        // Validating UserAuthInfoVO details
        validateUserAuthInfoVO(userAuthInfoVO, userName);

        @SuppressWarnings("unchecked")
        final Map<String, Integer> authGenerationAttemptsCounter = (HashMap<String, Integer>) httpSession
                .getAttribute(SessionConstants.AUTH_GENERATION_ATTEMPT_COUNTER);

        // Validation of RELID Verify Notification Generation Attempt Counter
        final String relidVerifyName = AuthType.RELID_VERIFY.name();
        if (authGenerationAttemptsCounter.get(relidVerifyName) < 1) {
            throw new AuthGenerationAttemptCounterExceededException(
                    "RELID-Verify Notification Generation Attempt Counter Exhausted");
        }

        LOG.debug(
                "processGenerateRVNRequest() : Building notification message that to be sent to REL-ID Verify server");

        final String enterpriseID = clientDetails.getEnterprise_id();
        final String correlationID = Utils.secureRandomUUIDGenerator();
        final String webDeviceUuid = "N/A";
        String retrievedLocation = "";

        /**
         * Store Corelation ID into the Session.
         */
        httpSession.setAttribute(Constants.CORRELATION_ID, correlationID);

        UserLocation location = Constants.GSON.fromJson((String) inputParameters.get(WebDevMaster.USER_LOCATION_STR),
                UserLocation.class);

        final String clientIPAddress = Utils.getClientIpAddress(request);

        if (location == null) {

            location = new UserLocation(Constants.USERLOCATION_NOT_AVAILABLE_DEFAULT_VALUE,
                    Constants.USERLOCATION_NOT_AVAILABLE_DEFAULT_VALUE);

            retrievedLocation = LocationUtils.retrieveLocationFromIP(request, response);

        }

        // Formulating notification message that to be sent to end user
        String verifyMessageToBeSent = String.format(PropertyConstants.RelIdVerifyConstants.GENERIC_VERIFY_MESSAGE,
                correlationID, enterpriseID, userName, clientDetails.getMapped_appagent_uuid(),
                clientDetails.getMapped_appagent_name(), userName, clientIPAddress, retrievedLocation,
                webDeviceParameter.get(WebBrowserParameters.PLATFORM_STR.getBrowserParameterKey()) != null
                        ? webDeviceParameter.get(WebBrowserParameters.PLATFORM_STR.getBrowserParameterKey())
                        : "",
                webDeviceParameter.get(WebBrowserParameters.USERAGENT_STR.getBrowserParameterKey()) != null
                        ? webDeviceParameter.get(WebBrowserParameters.USERAGENT_STR.getBrowserParameterKey())
                        : "",
                location == null ? Constants.USERLOCATION_NOT_AVAILABLE_DEFAULT_VALUE
                        : location.getLatitude() + "," + location.getLongitude());

        if (rememberMe) {
            verifyMessageToBeSent = String.format(
                    PropertyConstants.RelIdVerifyConstants.GENERIC_VERIFY_MESSAGE_REMEMBER_ME, correlationID,
                    enterpriseID, userName, clientDetails.getMapped_appagent_uuid(),
                    clientDetails.getMapped_appagent_name(), userName, clientIPAddress, retrievedLocation,
                    webDeviceParameter.get(WebBrowserParameters.PLATFORM_STR.getBrowserParameterKey()) != null
                            ? webDeviceParameter.get(WebBrowserParameters.PLATFORM_STR.getBrowserParameterKey())
                            : "",
                    webDeviceParameter.get(WebBrowserParameters.USERAGENT_STR.getBrowserParameterKey()) != null
                            ? webDeviceParameter.get(WebBrowserParameters.USERAGENT_STR.getBrowserParameterKey())
                            : "",
                    location == null ? Constants.USERLOCATION_NOT_AVAILABLE_DEFAULT_VALUE
                            : location.getLatitude() + "," + location.getLongitude());
        }

        final SaveNotificationRequest notificationRequest = Constants.GSON.fromJson(verifyMessageToBeSent,
                SaveNotificationRequest.class);
        notificationRequest.setDeviceToBeActivated(webDeviceUuid);

        verifyMessageToBeSent = Constants.GSON.toJson(notificationRequest);

        publisher.sendGenerateRVNRequestToVerify(verifyMessageToBeSent, correlationID);

        EventLogger.log(EventId.RelidAuthServer.VERIFY_AUTH_INITIATED_RAS, Utils.getClientIpAddress(request),
                request.getAttribute(Constants.REQUESTOR_ID).toString(), userName, "regex validation for TOTP failed");

        final GenerateRVNMessageLog message = new GenerateRVNMessageLog(userName, correlationID, webDeviceUuid,
                verifyMessageToBeSent, new Date());

        generateRVNMessageRepo.insertLog(message);

        LOG.debug("processGenerateRVNRequest() : Archived request {}", correlationID);

        // Decrementing the RELID Verify generation attempt counter & updating
        // it into the session & DB
        if (authGenerationAttemptsCounter.get(relidVerifyName) > 1) {
            final int decrementedCounter = authGenerationAttemptsCounter.get(relidVerifyName) - 1;
            authGenerationAttemptsCounter.put(relidVerifyName, decrementedCounter);

            // Updating the generation attempt counter in Session & DB
            httpSession.setAttribute(SessionConstants.AUTH_GENERATION_ATTEMPT_COUNTER, authGenerationAttemptsCounter);
            // userAuthInfoRepo.updateWebUserAuthGenerationAttemptCounter(userName,
            // authGenerationAttemptsCounter);

            EventLogger.log(EventId.RelidAuthServer.DECREMENT_AUTH_GENERATION_ATTMEPT_COUNTER,
                    Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                    AuthenticationUtils.getUsername(request), AuthenticationUtils.getUserAgent(request),
                    "Auth Generation Attempt Counter Decremented For " + relidVerifyName
                            + " & current Auth Generation Attempt Counter is " + decrementedCounter);
        } else {
            authGenerationAttemptsCounter.put(relidVerifyName, 0);

            // Updating the generation attempt counter in Session & DB
            httpSession.setAttribute(SessionConstants.AUTH_GENERATION_ATTEMPT_COUNTER, authGenerationAttemptsCounter);
            // userAuthInfoRepo.updateWebUserAuthGenerationAttemptCounter(userName,
            // authGenerationAttemptsCounter);

            EventLogger.log(EventId.RelidAuthServer.EXHAUSTED_AUTH_GENERATION_ATTMEPT_COUNTER,
                    Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                    AuthenticationUtils.getUsername(request), AuthenticationUtils.getUserAgent(request),
                    "Auth Generation Attempt Counter Exhausted For " + relidVerifyName);
        }

        return true;
    }

    /**
     * This method validates UserAuthInfo object necessary details
     * 
     * @param userAuthInfoVO
     * @param userName
     */
    private void validateUserAuthInfoVO(final UserAuthInfoVO userAuthInfoVO, final String userName) {
        if (userAuthInfoVO == null) {
            throw new IllegalArgumentException(String.format("User : %s is doesnot exist in RELID system", userName));
        }

        if (!RelIdUserStatus.ACTIVE.equals(userAuthInfoVO.getUserStatus())) {
            throw new RelIDAuthServerOAuth2Exception(
                    String.format("User [%s] has invalid status in RELID system", userName));
        }

        if (Boolean.FALSE.equals(userAuthInfoVO.isRelIdZeroEnabled())) {
            throw new RelIDAuthServerOAuth2Exception(String
                    .format("User [%s] is not enabled for REL-ID Verify notifications in RELID system", userName));
        }

        boolean deviceFound = false;
        final List<RelId> devices = userAuthInfoVO.getRelIds();
        for (final RelId device : devices) {
            if (RelIdUserStatus.ACTIVE.equals(device.getRelIdStatus())) {
                deviceFound = true;
                break;
            }
        }

        if (!deviceFound) {
            throw new RelIDAuthServerOAuth2Exception(
                    String.format("User [%s] has no valid device in RELID system to generate notification", userName));
        }

    }

    /**
     * This function validates EnterpriseID Details
     * 
     * @param clientDetails
     * @param clientId
     * @param scopeStr
     */
    private void validateEnterpriseIDDetails(final EnterpriseInfo clientDetails, final String clientId,
            final String scopeStr) {

        if (clientDetails == null) {
            throw new NoSuchClientException(String.format("client record with id: %s is null", clientId));
        }

        final Set<String> scopes = OAuth2Utils.parseParameterList(scopeStr);

        OAuthUtils.validateScope(scopes, clientDetails.getScope());

        if (clientDetails.getResourceIds() == null) {
            throw new IllegalArgumentException(
                    String.format("OIDC resource is null for client with id: %s ", clientId));
        }

        if (!clientDetails.getResourceIds().contains(OAuthResources.OIDC.getResourceId())) {
            throw new UnauthorizedClientException(
                    String.format("client with id: %s does not have the OIDC privileges", clientId));
        }
    }

}
