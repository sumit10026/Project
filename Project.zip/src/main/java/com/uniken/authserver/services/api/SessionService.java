package com.uniken.authserver.services.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uniken.domains.relid.device.WebDevMaster;

/**
 * This class will handle the operations related to user session & cookies.
 * 
 * @author Rupesh Chaudhari
 */
public interface SessionService {

    /**
     * Handles Secure Cookie Related Operations Prior to Login/Logout.
     * 
     * @param request
     *            request object
     * @param response
     *            response object
     * @throws Exception
     */
    void preLogoutSecureCookieHandling(HttpServletRequest request, HttpServletResponse response) throws Exception;

    /**
     * @param request
     */
    void resetAuthSessionParameters(HttpServletRequest request);

    /**
     * @param redirectUri
     * @param clientId
     * @return
     */
    boolean isValidRedirectURI(String redirectUri, String clientId);

    /**
     * Handles Secure Cookie Related Operations for Register User operation.
     * 
     * @param request
     *            request object
     * @param response
     *            response object
     * @throws Exception
     */
    void registerUserSecureCookieHandling(HttpServletRequest request, HttpServletResponse response) throws Exception;

    /**
     * @return
     */
    WebDevMaster createSecureCookieForFIDO2();

    /**
     * @param request
     */
    void resetOfferedAuthSessionParameters(HttpServletRequest request);

}
