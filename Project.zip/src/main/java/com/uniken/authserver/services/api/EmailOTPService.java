package com.uniken.authserver.services.api;

import java.security.GeneralSecurityException;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.uniken.authserver.exception.InvalidInputException;

public interface EmailOTPService {

    /**
     * This method generates Email OTP and make a provision to deliver it to the
     * end user
     * 
     * @param request
     * @param response
     * @param inputParameters
     * @return
     * @throws GeneralSecurityException
     */

    public boolean generateOTP(final HttpServletRequest request, final HttpServletResponse response,
            final Map<String, Object> inputParameters) throws GeneralSecurityException;

    /**
     * This method validates Email OTP and returns true / false
     * 
     * @param request
     * @param response
     * @param inputParameters
     * @return
     */
    public boolean validateUserByOTP(final HttpServletRequest request, final HttpServletResponse response,
            final Map<String, Object> inputParameters);

    /**
     * Save email and generate OTP.
     *
     * @param request
     *            the request
     * @param response
     *            the response
     * @param inputParameters
     *            the input parameters
     * @return true, if successful
     * @throws GeneralSecurityException
     *             the general security exception
     * @throws InvalidInputException
     *             the invalid input exception
     */
    public boolean saveEmailAndGenerateOTP(final HttpServletRequest request, final HttpServletResponse response,
            final Map<String, Object> inputParameters) throws GeneralSecurityException, InvalidInputException;

    /**
     * This method validates Email OTP for user registration process and returns
     * true / false
     * 
     * @param request
     * @param response
     * @param inputParameters
     * @return
     */
    public boolean validateUserRegistrationByOTP(final HttpServletRequest request, final HttpServletResponse response,
            final Map<String, Object> inputParameters);
}
