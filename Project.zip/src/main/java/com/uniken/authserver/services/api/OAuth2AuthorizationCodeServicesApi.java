/**
 * 
 */
package com.uniken.authserver.services.api;

import org.springframework.security.oauth2.provider.OAuth2Authentication;

/**
 * Implementation for authorization code services that stores authorization
 * code.
 * 
 * @author Kushal Jaiswal
 */
public interface OAuth2AuthorizationCodeServicesApi {
    OAuth2Authentication getAuthenticationCode(final String code);
}
