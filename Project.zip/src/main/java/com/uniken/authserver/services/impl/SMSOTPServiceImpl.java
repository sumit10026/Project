package com.uniken.authserver.services.impl;

import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.common.exceptions.UnauthorizedUserException;
import org.springframework.stereotype.Service;

import com.uniken.authserver.domains.AuthenticationDetails;
import com.uniken.authserver.exception.AuthGenerationAttemptCounterExceededException;
import com.uniken.authserver.exception.InvalidInputException;
import com.uniken.authserver.exception.ValidateUserException;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.repo.api.WebUserOTPRepo;
import com.uniken.authserver.services.api.SMSOTPService;
import com.uniken.authserver.services.api.UserService;
import com.uniken.authserver.utility.AuthenticationUtils;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.InputValidationUtils;
import com.uniken.authserver.utility.PKIEncryptUtil;
import com.uniken.authserver.utility.RegisterUserValidator;
import com.uniken.authserver.utility.SessionConstants;
import com.uniken.authserver.utility.UserRegistrationConstants;
import com.uniken.authserver.utility.Utility;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.enums.AlertType;
import com.uniken.domains.enums.OTPType;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.relid.user.Message;
import com.uniken.domains.relid.user.OTP;
import com.uniken.domains.relid.user.OTP_STATUS;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;

@Service
public class SMSOTPServiceImpl
        implements
        SMSOTPService {

    private static final Logger LOG = LoggerFactory.getLogger(SMSOTPServiceImpl.class);

    @Autowired
    private WebUserOTPRepo webUserOTPRepo;

    @Autowired
    private UserAuthInfoRepo userAuthInfoRepo;

    @Autowired
    UserService userService;

    @Override
    public boolean generateOTP(final HttpServletRequest request, final HttpServletResponse response,
            final Map<String, Object> inputParameters) throws GeneralSecurityException {
        boolean ret = false;

        LOG.info("generateOTP() -> Entering.");

        // SAST - fix
        response.setHeader("X-FRAME-OPTIONS", "DENY");

        // validating incoming request
        Utils.validateRequest(request, response, inputParameters);

        final HttpSession session = request.getSession();

        final String userId = (String) inputParameters.get(Constants.REQ_PARAM_USERNAME);
        final String clientId = (String) inputParameters.get(EnterpriseInfo.CLIENT_ID);

        LOG.info("generateOTP() : Generate OTP request received for client Id : {} and Username : {}.", clientId,
                userId);

        final UserAuthInfoVO user = userAuthInfoRepo.fetchUserDetailsFromLoginId(userId);

        if (user == null) {
            EventLogger.log(EventId.RelidAuthServer.SMS_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), userId, "User not found in db.");
            throw new UsernameNotFoundException(Constants.UNAUTHORIZED_ACCESS);
        }

        // Validation of SMS OTP Generation Attempt Counter
        @SuppressWarnings("unchecked")
        final Map<String, Integer> authGenerationAttemptsCounter = (HashMap<String, Integer>) session
                .getAttribute(SessionConstants.AUTH_GENERATION_ATTEMPT_COUNTER);

        final String smsOtpName = AuthType.SMSOTP.name();
        if (authGenerationAttemptsCounter.get(smsOtpName) < 1) {
            throw new AuthGenerationAttemptCounterExceededException("SMSOTP Generation Attempt Counter Exhausted");
        }

        if (user.getUserStatus() != RelIdUserStatus.ACTIVE) {
            EventLogger.log(EventId.RelidAuthServer.SMS_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), userId, "user is not ACTIVE");
            throw new UnauthorizedUserException(Constants.UNAUTHORIZED_ACCESS);
        }
        if (user.getMobileNumber() == null || user.getMobileNumber().isEmpty()) {
            EventLogger.log(EventId.RelidAuthServer.SMS_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), userId,
                    "user do not have mobiler number registered");
            throw new UnauthorizedUserException(Constants.UNAUTHORIZED_ACCESS);
        }
        if (Boolean.FALSE.equals(user.isWebOnly())
                && user.getRelIds().stream().filter(relid -> relid.getRelIdStatus().equals(RelIdUserStatus.ACTIVE))
                        .collect(Collectors.toList()).isEmpty()) {
            EventLogger.log(EventId.RelidAuthServer.SMS_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), userId,
                    "user do not have any active devices.");
            throw new UnauthorizedUserException(Constants.UNAUTHORIZED_ACCESS);
        }

        try {

            final String otpID = Utility.generateSecureRandom(6, Constants.SPECS_FOR_ACCESS_CODE_GEN);
            final String otpValue = Utility.generateSecureRandom(6, Constants.SPECS_FOR_ACCESS_CODE_GEN);
            final String webDeviceUuid = "N/A";

            LOG.info("generateOTP() -> Otp generated. Otp id : {}", otpID);

            // otpValue SHA-256Digest
            final byte[] digest = Utility.SHA256Digest(otpValue.getBytes());

            // otpValue's digest, Base64
            // encoded
            final String base64EncodedOtpValue = Utility.generateBase64String(digest);
            final Date createdTs = new Date();

            final Calendar expiryTime = Calendar.getInstance();
            expiryTime.setTime(createdTs);
            expiryTime.add(Calendar.SECOND, Constants.otpExpiry);

            final OTP otp = new OTP(userId, user.getUserUuid(), clientId, webDeviceUuid, otpID, base64EncodedOtpValue,
                    createdTs, expiryTime.getTime(), OTP_STATUS.ACTIVE.name(), OTPType.SMS);

            final String encryptedOTPValue = PKIEncryptUtil.encryptData(otpValue);
            final Message message = new Message();
            message.setCreatedTS(createdTs);
            message.setActivationCode(encryptedOTPValue);
            message.setVerificationKey(otpID);
            message.setExpiryTS(expiryTime.getTime());

            message.setFirstName(user.getFirstName());
            message.setLastName(user.getLastName());
            message.setPrimaryGroupName(user.getPrimaryGroupName());
            message.setSecondaryGroupNames(user.getSecondaryGroupNames());
            message.setMessageProcessed(false);
            message.setUserId(userId);
            message.setMessageType(AlertType.RELID_AUTH_SMS);

            if (user.getMobileNumber() != null && !(user.getMobileNumber().trim().isEmpty())) {
                message.setMobileNumber(user.getMobileNumber());
            }

            message.setDispatchAttemptsCounter(0);

            LOG.info("generateOTP() -> Exiting.");

            webUserOTPRepo.sendAndPersistOTP(otp, message);
            ret = true;

        } catch (final Exception e) {
            LOG.error("Error while processing generation of SMS OTP", e);
            ret = false;
        }

        // Decrementing the SMS OTP generation attempt counter & updating it
        // into the session & DB
        if (ret) {
            if (authGenerationAttemptsCounter.get(smsOtpName) > 1) {
                final int decrementedCounter = authGenerationAttemptsCounter.get(smsOtpName) - 1;
                authGenerationAttemptsCounter.put(smsOtpName, decrementedCounter);

                // Updating the generation attempt counter in Session & DB
                session.setAttribute(SessionConstants.AUTH_GENERATION_ATTEMPT_COUNTER, authGenerationAttemptsCounter);
                // userService.updateWebUserAuthGenerationAttemptCounter(userId,
                // authGenerationAttemptsCounter);

                EventLogger.log(EventId.RelidAuthServer.DECREMENT_AUTH_GENERATION_ATTMEPT_COUNTER,
                        Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                        AuthenticationUtils.getUsername(request), AuthenticationUtils.getUserAgent(request),
                        "Auth Generation Attempt Counter Decremented For " + AuthType.SMSOTP
                                + " & current Auth Generation Attempt Counter is " + decrementedCounter);
            } else {
                authGenerationAttemptsCounter.put(smsOtpName, 0);

                // Updating the generation attempt counter in Session & DB
                session.setAttribute(SessionConstants.AUTH_GENERATION_ATTEMPT_COUNTER, authGenerationAttemptsCounter);
                // userService.updateWebUserAuthGenerationAttemptCounter(userId,
                // authGenerationAttemptsCounter);

                EventLogger.log(EventId.RelidAuthServer.EXHAUSTED_AUTH_GENERATION_ATTMEPT_COUNTER,
                        Utils.getClientIpAddress(request), AuthenticationUtils.getRequestorId(request),
                        AuthenticationUtils.getUsername(request), AuthenticationUtils.getUserAgent(request),
                        "Auth Generation Attempt Counter Exhausted For " + smsOtpName);
            }
        }

        return ret;
    }

    @Override
    public boolean validateUserByOTP(final HttpServletRequest request, final HttpServletResponse response,
            final Map<String, Object> inputParameters) {
        boolean ret = false;

        // SAST -fix
        response.setHeader("X-FRAME-OPTIONS", "DENY");

        // validating incoming request
        Utils.validateRequest(request, response, inputParameters);
        final String userId;
        final String smsOTP;
        try {
            ESAPI.validator().getValidInput("username_key", Constants.REQ_PARAM_USERNAME, "HTTPParameterName",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            userId = ESAPI.validator().getValidInput("username_value",
                    request.getParameter(Constants.REQ_PARAM_USERNAME), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            ESAPI.validator().getValidInput("sms_otp_key", "SMSOTP", "HTTPParameterName",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            smsOTP = ESAPI.validator().getValidInput("sms_otp_value", request.getParameter("SMSOTP"), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
        } catch (final Exception e) {
            throw new IllegalArgumentException("Invalid Characters found" + e.getMessage());
        }
        final String clientId = (String) inputParameters.get(EnterpriseInfo.CLIENT_ID);

        if (!InputValidationUtils.isValidUserName(userId)) {
            throw new ValidateUserException("Invalid username");
        }

        if (smsOTP == null || smsOTP.trim().isEmpty()) {
            EventLogger.log(EventId.RelidAuthServer.SMS_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), userId,
                    "SMS OTP not found in incoming request.");
            throw new UsernameNotFoundException(Constants.UNAUTHORIZED_ACCESS);
        }

        if (!InputValidationUtils.isValidBase64String(smsOTP)) {
            LOG.error("validateUserByOTP() -> Invalid Base64 String : {}", smsOTP);
            throw new ValidateUserException("Invalid Base64 String");
        }

        LOG.info("validateUserByOTP() : Generate OTP request received for client Id : {} and Username : {}.", clientId,
                userId);

        final UserAuthInfoVO user = userAuthInfoRepo.fetchUserDetailsFromLoginId(userId);

        if (user == null) {
            EventLogger.log(EventId.RelidAuthServer.SMS_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), userId, "User not found in db.");
            throw new UsernameNotFoundException(Constants.UNAUTHORIZED_ACCESS);
        }

        if (user.getUserStatus() != RelIdUserStatus.ACTIVE) {
            EventLogger.log(EventId.RelidAuthServer.SMS_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), userId, "user is not ACTIVE");
            throw new UnauthorizedUserException(Constants.UNAUTHORIZED_ACCESS);
        }

        final OTP matchedOTP = webUserOTPRepo.validateWebUserOTP(smsOTP, OTPType.SMS, userId);

        if (matchedOTP == null) {
            EventLogger.log(EventId.RelidAuthServer.INVALID_OTP, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), userId, "otp mismatch!");
            throw new UnauthorizedUserException(Constants.UNAUTHORIZED_ACCESS);

        }

        LOG.info("validateUserByOTP() -> OTP successfully matched for user :{}", userId);
        EventLogger.log(EventId.RelidAuthServer.OTP_VALIDATED_RAS, Utils.getClientIpAddress(request),
                request.getAttribute(Constants.REQUESTOR_ID).toString(), userId, "otp matched!");

        final AuthenticationDetails authDetails = new AuthenticationDetails("Authenticated", AuthType.SMSOTP,
                new Date(), userId, matchedOTP.getDev_uuid());

        request.getSession().setAttribute(AuthenticationDetails.AUTHENTICATION_DETAILS_STR, authDetails);

        webUserOTPRepo.archiveWebUserOTP(matchedOTP);

        ret = true;

        return ret;
    }

    @Override
    public boolean saveMobileNumberAndGenerateOTP(final HttpServletRequest request, final HttpServletResponse response,
            final Map<String, Object> inputParameters) throws GeneralSecurityException, InvalidInputException {

        LOG.info("saveMobileNumberAndGenerateOTP() -> Entering.");

        boolean ret = true;

        response.setHeader("X-FRAME-OPTIONS", "DENY");

        final String userId = (String) inputParameters.get(Constants.REQ_PARAM_USERNAME);

        // checking for userName
        if (Utils.isNullOrEmpty(userId)) {
            throw new IllegalArgumentException("Username is null or empty");
        }

        final String clientId = "N/A";
        final String mobileNumber = (String) inputParameters.get(UserRegistrationConstants.MOBILE_NUMBER);

        // validate mobile number
        final List<String> errorMsgList = new ArrayList<>();
        RegisterUserValidator.validateMobileNumber(mobileNumber, errorMsgList);
        if (!errorMsgList.isEmpty()) {
            LOG.error("Error occurred while validating user details. Error message is {}", errorMsgList);
            throw new InvalidInputException("Error occurred while validating user mobile number.", errorMsgList);
        }

        LOG.info(
                "saveMobileNumberAndGenerateOTP() : Save mobile number and Generate OTP request received for Username : {}.",
                userId);

        final UserAuthInfoVO user = userAuthInfoRepo.fetchUserDetailsFromLoginId(userId);

        if (user == null) {
            EventLogger.log(EventId.RelidAuthServer.SMS_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), userId, "User not found in db.");
            throw new UsernameNotFoundException(Constants.UNAUTHORIZED_ACCESS);
        }

        user.setMobileNumber(mobileNumber);

        try {

            final String otpID = Utility.generateSecureRandom(6, Constants.SPECS_FOR_ACCESS_CODE_GEN);
            final String otpValue = Utility.generateSecureRandom(6, Constants.SPECS_FOR_ACCESS_CODE_GEN);
            final String webDeviceUuid = "N/A";

            LOG.info("saveMobileNumberAndGenerateOTP() -> Otp generated. Otp id : {}", otpID);

            // otpValue SHA-256Digest
            final byte[] digest = Utility.SHA256Digest(otpValue.getBytes());

            // otpValue's digest, Base64
            // encoded
            final String base64EncodedOtpValue = Utility.generateBase64String(digest);
            final Date createdTs = new Date();

            final Calendar expiryTime = Calendar.getInstance();
            expiryTime.setTime(createdTs);
            expiryTime.add(Calendar.SECOND, Constants.otpExpiry);

            final OTP otp = new OTP(userId, user.getUserUuid(), clientId, webDeviceUuid, otpID, base64EncodedOtpValue,
                    createdTs, expiryTime.getTime(), OTP_STATUS.ACTIVE.name(), OTPType.SMS);

            final String encryptedOTPValue = PKIEncryptUtil.encryptData(otpValue);
            final Message message = new Message();
            message.setCreatedTS(createdTs);
            message.setActivationCode(encryptedOTPValue);
            message.setVerificationKey(otpID);
            message.setExpiryTS(expiryTime.getTime());

            message.setFirstName(user.getFirstName());
            message.setLastName(user.getLastName());
            message.setPrimaryGroupName(user.getPrimaryGroupName());
            message.setSecondaryGroupNames(user.getSecondaryGroupNames());
            message.setMessageProcessed(false);
            message.setUserId(userId);
            message.setMessageType(AlertType.RELID_AUTH_SMS);

            if (user.getMobileNumber() != null && !(user.getMobileNumber().trim().isEmpty())) {
                message.setMobileNumber(user.getMobileNumber());
            }

            message.setDispatchAttemptsCounter(0);

            LOG.info("saveMobileNumberAndGenerateOTP() -> Exiting.");

            webUserOTPRepo.sendAndPersistOTP(otp, message);
            ret = true;

        } catch (final Exception e) {
            LOG.error("Error while processing generation of SMS OTP", e);
            ret = false;
        }

        return ret;
    }

    @Override
    public boolean validateUserRegistrationByOTP(final HttpServletRequest request, final HttpServletResponse response,
            final Map<String, Object> inputParameters) {
        boolean ret = false;

        // SAST -fix
        response.setHeader("X-FRAME-OPTIONS", "DENY");

        final String userId;
        final String smsOTP;
        try {
            ESAPI.validator().getValidInput("username_key", Constants.REQ_PARAM_USERNAME, "HTTPParameterName",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            userId = ESAPI.validator().getValidInput("username_value",
                    (String) inputParameters.get(Constants.REQ_PARAM_USERNAME), "HTTPHeaderValue",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            ESAPI.validator().getValidInput("sms_otp_key", "SMSOTP", "HTTPParameterName",
                    Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
            smsOTP = ESAPI.validator().getValidInput("sms_otp_value", (String) inputParameters.get("SMSOTP"),
                    "HTTPHeaderValue", Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
        } catch (final Exception e) {
            throw new IllegalArgumentException("Invalid Characters found" + e.getMessage());
        }
        final String clientId = "N/A";

        if (!InputValidationUtils.isValidUserName(userId)) {
            throw new ValidateUserException("Invalid username");
        }

        if (smsOTP == null || smsOTP.trim().isEmpty()) {
            EventLogger.log(EventId.RelidAuthServer.SMS_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), userId,
                    "SMS OTP not found in incoming request.");
            throw new UsernameNotFoundException(Constants.UNAUTHORIZED_ACCESS);
        }

        if (!InputValidationUtils.isValidBase64String(smsOTP)) {
            LOG.error("validateUserRegistrationByOTP() -> Invalid Base64 String : {}", smsOTP);
            throw new ValidateUserException("Invalid Base64 String");
        }

        LOG.info(
                "validateUserRegistrationByOTP() : Generate OTP request received for client Id : {} and Username : {}.",
                clientId, userId);

        final UserAuthInfoVO user = userAuthInfoRepo.fetchUserDetailsFromLoginId(userId);

        if (user == null) {
            EventLogger.log(EventId.RelidAuthServer.SMS_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), userId, "User not found in db.");
            throw new UsernameNotFoundException(Constants.UNAUTHORIZED_ACCESS);
        }

        final OTP matchedOTP = webUserOTPRepo.validateWebUserOTP(smsOTP, OTPType.SMS, userId);

        if (matchedOTP == null) {
            EventLogger.log(EventId.RelidAuthServer.INVALID_OTP, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), userId, "otp mismatch!");
            return false;

        }

        LOG.info("validateUserRegistrationByOTP() -> OTP successfully matched for user :{}", userId);
        EventLogger.log(EventId.RelidAuthServer.OTP_VALIDATED_RAS, Utils.getClientIpAddress(request),
                request.getAttribute(Constants.REQUESTOR_ID).toString(), userId, "otp matched!");

        final AuthenticationDetails authDetails = new AuthenticationDetails("Authenticated", AuthType.SMSOTP,
                new Date(), userId, matchedOTP.getDev_uuid());

        request.getSession().setAttribute(AuthenticationDetails.AUTHENTICATION_DETAILS_STR, authDetails);

        webUserOTPRepo.archiveWebUserOTP(matchedOTP);

        ret = true;

        return ret;
    }
}
