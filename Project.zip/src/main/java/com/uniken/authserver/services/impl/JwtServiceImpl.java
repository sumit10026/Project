package com.uniken.authserver.services.impl;

import java.util.Collections;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.jwt.Jwt;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.jwt.crypto.sign.Signer;
import org.springframework.security.oauth2.common.util.JsonParser;
import org.springframework.security.oauth2.common.util.JsonParserFactory;
import org.springframework.stereotype.Service;

import com.uniken.authserver.services.api.JwtService;
import com.uniken.authserver.utility.Utils;

/**
 * @author Omkar
 */
@Service
public class JwtServiceImpl
        implements
        JwtService {

    private static final Logger LOG = LoggerFactory.getLogger(JwtServiceImpl.class);

    private final JsonParser objectMapper = JsonParserFactory.create();

    @Override
    public String generateEncodedJwt(final Map<String, Object> claims, final Signer signer) {
        return generateEncodedJwt(Collections.emptyMap(), claims, signer);
    }

    @Override
    public String generateEncodedJwt(final Map<String, String> headers, final Map<String, Object> claims,
            final Signer signer) {
        LOG.info("generateEncodedJwt() -> Generating JWT");

        if (Utils.isNull(claims) || claims.isEmpty()) {
            throw new IllegalArgumentException("Invalid claims");
        }

        if (Utils.isNull(signer)) {
            throw new IllegalArgumentException("Invalid signer");
        }

        final String content = objectMapper.formatMap(claims);

        return JwtHelper.encode(content, signer, headers).getEncoded();
    }

    @Override
    public Map<String, Object> getJwtClaims(final String jwt) {
        LOG.info("getJwtClaims() -> Getting JWT Claims");

        if (Utils.isNullOrEmpty(jwt)) {
            throw new IllegalArgumentException("Invalid jwt");
        }

        final Jwt jwToken = JwtHelper.decode(jwt);
        final String claimsStr = jwToken.getClaims();
        return objectMapper.parseMap(claimsStr);
    }

}
