package com.uniken.authserver.services.api;

import javax.servlet.http.HttpServletRequest;

import com.uniken.domains.relid.user.UserBrowser;

/**
 * This class will handle the operations related secure cookies.
 * 
 * @author Rupesh Chaudhari
 */
public interface SecureCookieService {

    /**
     * Generates the secure cookie & returns it into the string format.
     * 
     * @return cookie in string format
     */
    String generateSecureCookie();

    /**
     * Decrypt the secure cookie and returns plain secure cookie into the string
     * format
     * 
     * @param secureCookieEncrypted
     * @return
     */
    String decryptSecureCookie(String secureCookieEncrypted);

    /**
     * @param cookieValue
     * @return
     */
    String generateSecureCookieByGivenValue(String cookieValue);

    /**
     * @param request
     * @return
     */
    boolean isSecureCookieExpired(HttpServletRequest request);

    /**
     * @param request
     * @param loginId
     * @param userOptedOutForFidoReg
     * @return
     */
    boolean updateUserOptedOutForFidoRegistrationForBrowser(HttpServletRequest request, String loginId,
            boolean userOptedOutForFidoReg);

    /**
     * @param request
     * @param loginId
     * @return
     */
    UserBrowser getAssociatedUserBrowserBySecureCookie(HttpServletRequest request, String loginId);
}
