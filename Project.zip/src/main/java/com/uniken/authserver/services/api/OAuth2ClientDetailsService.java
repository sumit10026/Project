/**
 * 
 */
package com.uniken.authserver.services.api;

import org.springframework.security.oauth2.provider.ClientDetailsService;

/**
 * @author Kushal Jaiswal
 */
public interface OAuth2ClientDetailsService
        extends
        ClientDetailsService {

}
