package com.uniken.authserver.services.impl;

import static com.uniken.authserver.domains.JwtClaimNames.ACTIVE;
import static com.uniken.authserver.domains.JwtClaimNames.AUD;
import static com.uniken.authserver.domains.JwtClaimNames.CLIENT_ID;
import static com.uniken.authserver.domains.JwtClaimNames.EXP;
import static com.uniken.authserver.domains.JwtClaimNames.ISS;
import static com.uniken.authserver.domains.JwtClaimNames.JTI;
import static com.uniken.authserver.domains.JwtClaimNames.SCOPE;
import static com.uniken.authserver.domains.JwtClaimNames.SUB;
import static com.uniken.authserver.domains.JwtClaimNames.USERNAME;
import static com.uniken.authserver.domains.JwtClaimNames.USER_NAME;

import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.Map;

import org.jose4j.jwa.AlgorithmConstraints;
import org.jose4j.jwa.AlgorithmConstraints.ConstraintType;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.jose4j.jwt.consumer.InvalidJwtException;
import org.jose4j.jwt.consumer.JwtConsumer;
import org.jose4j.jwt.consumer.JwtConsumerBuilder;
import org.jose4j.jwt.consumer.JwtContext;
import org.jose4j.keys.resolvers.JwksVerificationKeyResolver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2RefreshToken;
import org.springframework.security.oauth2.common.exceptions.InvalidClientException;
import org.springframework.security.oauth2.common.exceptions.InvalidTokenException;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.endpoint.FrameworkEndpoint;
import org.springframework.security.oauth2.provider.token.DefaultTokenServices;
import org.springframework.security.oauth2.provider.token.ResourceServerTokenServices;

import com.uniken.authserver.repo.api.MongoTokenStoreRepo;
import com.uniken.authserver.services.api.JwksService;
import com.uniken.authserver.services.api.TokenEndpointsServices;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.CustomOAuth2RefreshToken;
import com.uniken.domains.enums.auth.OAuthTokenTypes;

@FrameworkEndpoint
public class TokenEndpointsServicesImpl
        implements
        TokenEndpointsServices {

    private static final Logger LOG = LoggerFactory.getLogger(TokenEndpointsServicesImpl.class);

    @Autowired
    private DefaultTokenServices tokenServices;

    @Autowired
    private MongoTokenStoreRepo mongoTokenStoreRepo;

    @Autowired
    private ResourceServerTokenServices resourceServerTokenServices;

    @Autowired
    private JwksService jwksService;

    @Override
    public boolean revokeToken(final String token, final String tokenType, final String clientId) {

        LOG.info("revokeToken() -> Revoking access token.");

        boolean isTokenRevoked = false;

        if (OAuthTokenTypes.REFRESH_TOKEN.name().equalsIgnoreCase(tokenType)) {

            final OAuth2RefreshToken refreshToken = mongoTokenStoreRepo.readRefreshToken(token);

            if (refreshToken == null) {
                throw new InvalidTokenException("Token was not recognised");
            }

            final OAuth2Authentication oAuth2Authentication = mongoTokenStoreRepo
                    .readAuthenticationForRefreshToken(refreshToken);

            validateIfTokenIsGeneratedByRequestedClient(clientId, oAuth2Authentication);

            final CustomOAuth2RefreshToken removedRefreshToken = mongoTokenStoreRepo.readAndRemoveRefreshToken(token);
            if (removedRefreshToken == null) {
                throw new InvalidTokenException("Invalid refresh token: " + token);
            }

            mongoTokenStoreRepo.removeAccessTokenUsingRefreshToken(removedRefreshToken);
            isTokenRevoked = true;

        } else if (OAuthTokenTypes.ACCESS_TOKEN.name().equalsIgnoreCase(tokenType)) {

            final OAuth2AccessToken accessToken = mongoTokenStoreRepo.readAccessToken(token);

            if (accessToken == null) {
                throw new InvalidTokenException("Token was not recognised");
            }

            final OAuth2Authentication oAuth2AuthenticationFromDB = mongoTokenStoreRepo.readAuthentication(token);

            validateIfTokenIsGeneratedByRequestedClient(clientId, oAuth2AuthenticationFromDB);

            isTokenRevoked = tokenServices.revokeToken(token);

            if (!isTokenRevoked) {
                throw new InvalidTokenException("Invalid access token: " + token);
            }

        } else {
            throw new InvalidTokenException("Invalid token type: " + tokenType);
        }

        LOG.info("revokeAccessToken() -> Token revoked successfully");

        return isTokenRevoked;
    }

    @Override
    public boolean revokeRefreshToken(final String tokenValue) {
        LOG.info("revokeRefreshToken() -> Revoking refresh token");
        boolean isTokenRevoked = false;

        isTokenRevoked = tokenServices.revokeToken(tokenValue);

        if (isTokenRevoked) {
            LOG.info("revokeRefreshToken() -> Token revoked");
        } else {
            LOG.info("revokeRefreshToken() -> Failed to revoke");
        }

        return isTokenRevoked;
    }

    @Override
    public Map<String, Object> instrospectToken(final Authentication authentication, final String value,
            final String tokenTypeHint) {
        LOG.info("instrospectToken() -> Introspecting a token. Token type hint: {}", tokenTypeHint);
        final Map<String, Object> response = new LinkedHashMap<>();

        if (!authentication.isAuthenticated()) {
            LOG.info("The client is not authenticated.");
            response.put(ACTIVE, false);
            return response;
        }

        // check if we can identify the token using token type hint
        if ("access_token".equals(tokenTypeHint)) {
            final OAuth2AccessToken token = resourceServerTokenServices.readAccessToken(value);
            if (token != null) {
                return getAccessTokenIntrospectionResponse(authentication, value, response, token);
            }
        } else if ("refresh_token".equals(tokenTypeHint)) {
            final OAuth2RefreshToken token = mongoTokenStoreRepo.readRefreshToken(value);
            if (token != null) {
                return getRefreshTokenIntrospectionResponse(authentication, value, response, token);
            }
        }

        // we coudn't identify token using token type hint, extend search
        // don't check for access token again if already checked
        if (!"access_token".equals(tokenTypeHint)) {
            final OAuth2AccessToken token = resourceServerTokenServices.readAccessToken(value);
            if (token != null) {
                return getAccessTokenIntrospectionResponse(authentication, value, response, token);
            }
        }
        // don't check for refresh token again if already checked
        if (!"refresh_token".equals(tokenTypeHint)) {
            final OAuth2RefreshToken token = mongoTokenStoreRepo.readRefreshToken(value);
            if (token != null) {
                return getRefreshTokenIntrospectionResponse(authentication, value, response, token);
            }
        }

        LOG.info("Token was not recognised");
        response.put(ACTIVE, false);
        return response;

    }

    /**
     * Validate if token is generated by requested client.
     *
     * @param clientIdInRequest
     *            the client id in request
     * @param oAuth2Authentication
     *            the OAuth2 authentication
     */
    private void validateIfTokenIsGeneratedByRequestedClient(final String clientIdInRequest,
            final OAuth2Authentication oAuth2Authentication) {
        /**
         * Check if authenticate client id matches with the token client ID,
         * otherwise throw exception.
         */
        if (!clientIdInRequest.equals(oAuth2Authentication.getOAuth2Request().getClientId())) {

            throw new InvalidClientException("Given client ID does not match with the token client");
        }
    }

    private Map<String, Object> getAccessTokenIntrospectionResponse(final Authentication authentication,
            final String value, final Map<String, Object> response, final OAuth2AccessToken token) {
        if (token.isExpired()) {
            LOG.info("Access Token is expired");
            response.put(ACTIVE, false);
            return response;
        }

        return getTokenIntrospectionResponse(authentication, value, response);
    }

    private Map<String, Object> getRefreshTokenIntrospectionResponse(final Authentication authentication,
            final String value, final Map<String, Object> response, final OAuth2RefreshToken token) {
        if (Utils.isExpired(token)) {
            LOG.info("Refresh Token is expired");
            response.put(ACTIVE, false);
            return response;
        }

        return getTokenIntrospectionResponse(authentication, value, response);
    }

    private Map<String, Object> getTokenIntrospectionResponse(final Authentication authentication, final String value,
            final Map<String, Object> response) {

        try {
            final JwtContext process = getJwtConsumer().process(value);
            final Map<String, Object> claims = process.getJwtClaims().getClaimsMap();

            if (claims.get(CLIENT_ID) != null && !authentication.getName().equals(claims.get(CLIENT_ID))) {
                LOG.info("Given client ID does not match authenticated client");
                response.put(ACTIVE, false);
                return response;
            }

            response.putAll(claims);

            // gh-1070
            response.put(ACTIVE, true); // Always true if token exists
                                        // and not expired

            return getTokenIntrospectionClaims(response);

        } catch (final InvalidJwtException e) {
            LOG.error("Could not verify token", e);
            response.put(ACTIVE, false);
            return response;
        }
    }

    private Map<String, Object> getTokenIntrospectionClaims(final Map<String, Object> response) {
        final Map<String, Object> claims = new LinkedHashMap<>();

        claims.put(ACTIVE, response.get(ACTIVE));

        final Object scope = response.get(SCOPE);
        if (scope != null) {
            if (scope instanceof String) {
                claims.put(SCOPE, scope);
            } else if (scope instanceof Collection) {
                claims.put(SCOPE, String.join(" ", (Collection<String>) scope));
            }
        }

        if (response.get(CLIENT_ID) != null) {
            claims.put(CLIENT_ID, response.get(CLIENT_ID));
        }

        // TODO: add token_type

        if (response.get(EXP) != null) {
            claims.put(EXP, response.get(EXP));
        }

        // TODO: add iat, nbf

        if (response.get(SUB) != null) {
            claims.put(SUB, response.get(SUB));
        }

        if (response.get(USER_NAME) != null) {
            claims.put(USERNAME, response.get(USER_NAME));
            claims.computeIfAbsent(SUB, k -> response.get(USER_NAME));
        }

        if (response.get(USERNAME) != null) {
            claims.put(USERNAME, response.get(USERNAME));
            claims.computeIfAbsent(SUB, k -> response.get(USERNAME));
        }

        if (response.get(AUD) != null) {
            claims.put(AUD, response.get(AUD));
        }

        if (response.get(ISS) != null) {
            claims.put(ISS, response.get(ISS));
        }

        if (response.get(JTI) != null) {
            claims.put(JTI, response.get(JTI));
        }

        return claims;

    }

    private JwtConsumer getJwtConsumer() {
        // TODO: cache
        final JwksVerificationKeyResolver resolver = new JwksVerificationKeyResolver(
                jwksService.getJwks().getJsonWebKeys());
        return new JwtConsumerBuilder().setVerificationKeyResolver(resolver).setRequireExpirationTime()
                .setAllowedClockSkewInSeconds(30)
                .setJwsAlgorithmConstraints(
                        new AlgorithmConstraints(ConstraintType.WHITELIST, AlgorithmIdentifiers.RSA_USING_SHA256))
                .setSkipDefaultAudienceValidation().build();
    }

}
