package com.uniken.authserver.services.api;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.core.Authentication;

import com.uniken.authserver.domains.ValidateUserRequest;

public interface AuthenticationService {

    /**
     * This method will check is notification is acted or not by user.
     * 
     * @param correlationID
     *            : Check notification against provided correlationID.
     * @return {@link HttpStatus#OK} when action is taken on the notification
     *         <br>
     *         {@link HttpStatus#ACCEPTED} when no action taken on the
     *         notification. <br>
     *         {@link HttpStatus#NO_CONTENT} when the notification get expired
     *         due to no action from user with in the given expiry time.
     */
    HttpStatus checkIfNotificationIsActed(final String correlationID);

    /**
     * This method will fetch the notification by using provided correlationId
     * and check weather the notification is accepted or not.</br>
     * If notification is approved then it'll return true</br>
     * If notification is rejected then it'll return false</br>
     * If notification is marked as fraud then it'll block the device and return
     * false </br>
     * 
     * @param correlationID
     *            : Use this to fetch the notification
     * @param browserDFPChecksum
     * @param browserDFP
     * @param request
     * @return : True if notification is accepted else false
     */

    boolean checkNotificationResponse(final String correlationID, final String browserDFPChecksum,
            final String browserDFP, final HttpServletRequest request);

    /**
     * This method will validate user using totp. If TOTP validated successfully
     * then it will validate following things
     * <li>If REL-ID Verify notification is acted or not. If acted</li>
     * <li>Then parse the notification response is ACCEPTED || REJECT || FRAUD.
     * If ACCEPTED then continue the flow otherwise throw
     * {@link AccessDeniedException}</li>
     * <li>If notification not acted.. Then publish Discard Notification Request
     * to REL-ID Verify.</li> <br>
     * 
     * @param request
     * @param response
     * @return {@link Authentication} object if validation success.
     * @throws AccessDeniedException
     *             if invalid TOTP or Notification Action.
     * @throws AuthenticationServiceException
     *             if TOTP Validation failed.
     */
    boolean validateUserByTOTP(HttpServletRequest request, HttpServletResponse response,
            ValidateUserRequest validateUserRequest);

    /**
     * /** This method will fetch the notification by using provided
     * correlationId and check weather the notification is accepted or not.</br>
     * If notification is approved then it'll return true</br>
     * If notification is rejected then it'll return false</br>
     * If notification is marked as fraud then it'll block the device and return
     * false </br>
     * 
     * @param request
     * @param response
     * @return : Authentication object
     */
    boolean checkUserActionOnNotification(HttpServletRequest request, HttpServletResponse response,
            ValidateUserRequest validateUserRequest);

    /**
     * Authenticate user using fido.
     *
     * @param request
     *            the request
     * @param response
     *            the response
     * @param inputParameters
     *            the input parameters
     * @return the authentication
     */
    boolean authenticateUserUsingFido(HttpServletRequest request, HttpServletResponse response,
            ValidateUserRequest validateUserRequest);

    /**
     * This method validates SMS OTP and returns true / false
     * 
     * @param request
     * @param response
     * @param requestBody
     * @return
     */
    boolean validateUserBySMSOTP(HttpServletRequest request, HttpServletResponse response,
            ValidateUserRequest requestBody);

    /**
     * Validate user by password.
     *
     * @param request
     *            the request
     * @param response
     *            the response
     * @param validateUserRequest
     *            the validate user request
     * @return true, if successful
     */
    boolean validateUserByPassword(HttpServletRequest request, HttpServletResponse response,
            ValidateUserRequest validateUserRequest);

    /**
     * This method validates Email OTP and returns true / false
     * 
     * @param request
     * @param response
     * @param requestBody
     * @return
     */
    boolean validateUserByEmailOTP(HttpServletRequest request, HttpServletResponse response,
            ValidateUserRequest requestBody);

}
