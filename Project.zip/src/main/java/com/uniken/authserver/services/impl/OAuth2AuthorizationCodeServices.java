/**
 * 
 */
package com.uniken.authserver.services.impl;

import java.util.Date;

import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.code.RandomValueAuthorizationCodeServices;
import org.springframework.stereotype.Service;

import com.uniken.authserver.services.api.OAuth2AuthorizationCodeServicesApi;
import com.uniken.authserver.utility.Constants;
import com.uniken.domains.auth.CustomOAuth2AuthorizationCode;
import com.uniken.domains.auth.CustomOAuth2AuthorizationCodeLog;
import com.uniken.domains.enums.CollectionNames;

/**
 * Implementation for authorization code services that stores authorization
 * code.
 * 
 * @author Kushal Jaiswal
 */
@Service
public class OAuth2AuthorizationCodeServices extends RandomValueAuthorizationCodeServices
        implements
        OAuth2AuthorizationCodeServicesApi {

    private static final Logger LOG = LoggerFactory.getLogger(OAuth2AuthorizationCodeServices.class);

    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    protected void store(final String code, final OAuth2Authentication authentication) {

        LOG.info("store() : Entered.");

        final CustomOAuth2AuthorizationCode authorizationCode = new CustomOAuth2AuthorizationCode(code, authentication,
                new Date(), MDC.get(Constants.REQUESTOR_ID));

        mongoTemplate.save(authorizationCode);

    }

    @Override
    protected OAuth2Authentication remove(final String code) {

        LOG.info("remove() : Entered.");

        final Document authorizationCodeDoc = mongoTemplate.findAndRemove(
                Query.query(Criteria.where(CustomOAuth2AuthorizationCode.CODE_KEY).is(code)), Document.class,
                CollectionNames.OAUTH_AUTHORIZATION_CODE.getCollectionName());

        if (authorizationCodeDoc == null) {
            return null;
        }

        final CustomOAuth2AuthorizationCode auth2AuthorizationCode = Constants.GSON
                .fromJson(Constants.GSON.toJson(authorizationCodeDoc), CustomOAuth2AuthorizationCode.class);

        logAuthorizationCode(auth2AuthorizationCode);

        return auth2AuthorizationCode != null ? auth2AuthorizationCode.getAuthentication() : null;
    }

    public void logAuthorizationCode(final CustomOAuth2AuthorizationCode customOAuth2AuthorizationCode) {

        LOG.info("logAuthorizationCode() : Entered. Log authorization code into DB.");
        mongoTemplate.save(new CustomOAuth2AuthorizationCodeLog(customOAuth2AuthorizationCode, new Date()));

    }

    @Override
    public OAuth2Authentication getAuthenticationCode(final String code) {

        LOG.info("getAuthenticationCode() : Entered.");

        final Document authorizationCodeDoc = mongoTemplate.findOne(
                Query.query(Criteria.where(CustomOAuth2AuthorizationCode.CODE_KEY).is(code)), Document.class,
                CollectionNames.OAUTH_AUTHORIZATION_CODE.getCollectionName());

        if (authorizationCodeDoc == null) {
            return null;
        }

        final CustomOAuth2AuthorizationCode auth2AuthorizationCode = Constants.GSON
                .fromJson(Constants.GSON.toJson(authorizationCodeDoc), CustomOAuth2AuthorizationCode.class);

        return auth2AuthorizationCode != null ? auth2AuthorizationCode.getAuthentication() : null;
    }
}
