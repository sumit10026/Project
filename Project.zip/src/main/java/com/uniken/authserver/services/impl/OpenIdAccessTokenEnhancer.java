package com.uniken.authserver.services.impl;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.exceptions.InvalidClientException;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.TokenEnhancer;
import org.springframework.stereotype.Service;

import com.uniken.authserver.repo.api.EnterpriseRepo;
import com.uniken.authserver.repo.api.OidcConfigRepo;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.services.api.JwtService;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.auth.JWTConfig;
import com.uniken.domains.auth.OIDCConfig;
import com.uniken.domains.enums.OIDCConstants;
import com.uniken.domains.enums.auth.OAuthGrantTypes;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;

@Service
public class OpenIdAccessTokenEnhancer
        implements
        TokenEnhancer {

    private static final Logger LOG = LoggerFactory.getLogger(OpenIdAccessTokenEnhancer.class);
    private static final String OPENID_SCOPE_NAME = "openid";
    private static final String ID_TOKEN_ATTR_NAME = "id_token";

    private final JwtService jwtService;
    private final OidcConfigRepo oidcConfigRepo;
    private final UserAuthInfoRepo userAuthInfoRepo;
    private final EnterpriseRepo enterpriseRepo;

    public OpenIdAccessTokenEnhancer(final JwtService jwtService, final OidcConfigRepo oidcConfigRepo,
            final UserAuthInfoRepo userAuthInfoRepo, final EnterpriseRepo enterpriseRepo) {
        this.jwtService = jwtService;
        this.oidcConfigRepo = oidcConfigRepo;
        this.userAuthInfoRepo = userAuthInfoRepo;
        this.enterpriseRepo = enterpriseRepo;
    }

    @Override
    public OAuth2AccessToken enhance(final OAuth2AccessToken accessToken, final OAuth2Authentication authentication) {

        if (accessToken instanceof DefaultOAuth2AccessToken && accessToken.getScope().contains(OPENID_SCOPE_NAME)
                && (OAuthGrantTypes.AUTHORIZATION_CODE.getGrantType()
                        .equals(authentication.getOAuth2Request().getGrantType())
                        || OAuthGrantTypes.CIBA.getGrantType()
                                .equals(authentication.getOAuth2Request().getGrantType()))) {

            final String userId = authentication.getName();

            LOG.info("enhance() -> Generating Id Token for user : {}", userId);

            final DefaultOAuth2AccessToken token = (DefaultOAuth2AccessToken) accessToken;

            final String clientId = authentication.getOAuth2Request().getClientId();

            final OIDCConfig oidcConfig = oidcConfigRepo.getAllOidcConfigs().stream().findFirst().orElse(null);

            if (oidcConfig != null && oidcConfig.getJwtConfig() != null) {
                final JWTConfig jwtConfig = oidcConfig.getJwtConfig();
                final EnterpriseInfo enterpriseInfo = enterpriseRepo.getEnterpriseByClientId(clientId);

                final UserAuthInfoVO userAuthInfoVO = userAuthInfoRepo.fetchUserDetailsFromLoginId(userId);

                final long issuedAt = new Date().getTime() / 1000;

                // set claims
                final Map<String, Object> claims = new LinkedHashMap<>();
                claims.put("aud", clientId);
                claims.put("sub", userId);
                claims.put("iss", Constants.OIDC_CONFIG_JWT_ISSUER_NAME);
                claims.put("iat", issuedAt);
                claims.put("exp", issuedAt + enterpriseInfo.getAccessTokenValiditySeconds());
                claims.put(UserAuthInfoVO.FIRST_NAME_STR, userAuthInfoVO.getFirstName());
                claims.put(UserAuthInfoVO.LAST_NAME_STR, userAuthInfoVO.getLastName());
                // TODO: claims.put(OIDCConstants.JWT_CLAIM_JTI.getValue(),
                // "");

                // set headers
                final Map<String, String> headers = new LinkedHashMap<>();
                headers.put(OIDCConstants.JWT_HEADER_KID.getValue(), jwtConfig.getKid());

                // generate JWT
                final String jwt = jwtService.generateEncodedJwt(headers, claims, Utils.getSigner(jwtConfig));

                final Map<String, Object> additionalInformation = new LinkedHashMap<>(token.getAdditionalInformation());

                // set id_token
                additionalInformation.put(ID_TOKEN_ATTR_NAME, jwt);

                token.setAdditionalInformation(additionalInformation);

            } else {
                LOG.error("enhance() -> Could not generate id_token. OIDC Config not found");
                throw new InvalidClientException("OIDC Config not found");
            }

        }

        return accessToken;
    }
}
