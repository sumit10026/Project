package com.uniken.authserver.services.impl;

import java.util.Date;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.jwt.crypto.sign.Signer;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.exceptions.InvalidClientException;
import org.springframework.security.oauth2.common.util.JsonParser;
import org.springframework.security.oauth2.common.util.JsonParserFactory;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.security.oauth2.provider.token.DefaultAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.DefaultUserAuthenticationConverter;
import org.springframework.security.oauth2.provider.token.TokenEnhancer;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.stereotype.Service;

import com.uniken.authserver.repo.api.OidcConfigRepo;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.RequestParams;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.JWTConfig;
import com.uniken.domains.auth.OIDCConfig;
import com.uniken.domains.enums.OIDCConstants;
import com.uniken.domains.enums.appconfig.ModuleNames;
import com.uniken.domains.enums.auth.OAuthGrantTypes;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;

/**
 * Custom JwtAccessTokenConverter to convert access_token into JWT using custom
 * claims.
 */
@Service
public class CustomJwtAccessTokenConverter
        implements
        TokenEnhancer {

    private static final Logger LOG = LoggerFactory.getLogger(CustomJwtAccessTokenConverter.class);

    private final JsonParser objectMapper = JsonParserFactory.create();

    private final OidcConfigRepo oidcConfigRepo;
    final UserAuthInfoRepo userAuthInfoRepo;

    public CustomJwtAccessTokenConverter(final OidcConfigRepo oidcConfigRepo, final UserAuthInfoRepo userAuthInfoRepo) {
        this.oidcConfigRepo = oidcConfigRepo;
        this.userAuthInfoRepo = userAuthInfoRepo;
    }

    @Override
    public OAuth2AccessToken enhance(final OAuth2AccessToken accessToken, final OAuth2Authentication authentication) {
        LOG.debug("enhance() -> Converting access_token to JWT");

        final DefaultOAuth2AccessToken token = (DefaultOAuth2AccessToken) accessToken;
        OAuth2AccessToken enhancedToken = null;

        final OIDCConfig oidcConfig = oidcConfigRepo.getAllOidcConfigs().stream().findFirst().orElseThrow(() -> {
            return new InvalidClientException(
                    "enhance() -> Could not create access_token. Please contact administrator.");
        });

        final JWTConfig jwtConfig = oidcConfig.getJwtConfig();
        final OAuth2Request oAuth2Request = authentication.getOAuth2Request();

        if (OAuthGrantTypes.PASSWORD.getGrantType().equals(authentication.getOAuth2Request().getGrantType())
                && ModuleNames.BlaZeServer.getName()
                        .equals(oAuth2Request.getRequestParameters().get(RequestParams.PasswordGrant.SOURCE))) {

            final UserAuthInfoVO user = userAuthInfoRepo.fetchUserDetailsFromLoginId(authentication.getName());

            /**
             * set resourceIds as null, otherwise resourceIds will be used in
             * "aud" claim
             */
            final Set<String> resourceIds = null;
            final OAuth2Request storedRequest = new OAuth2Request(oAuth2Request.getRequestParameters(),
                    oAuth2Request.getClientId(), oAuth2Request.getAuthorities(), oAuth2Request.isApproved(),
                    oAuth2Request.getScope(), resourceIds, oAuth2Request.getRedirectUri(),
                    oAuth2Request.getResponseTypes(), oAuth2Request.getExtensions());
            final OAuth2Authentication oAuth2Authentication = new OAuth2Authentication(storedRequest, authentication);

            final Map<String, Object> actualAdditionalInformationBeforeCustomClaims = new LinkedHashMap<>(
                    token.getAdditionalInformation());

            final Map<String, Object> claims = new LinkedHashMap<>(token.getAdditionalInformation());

            claims.put("aud", storedRequest.getRequestParameters().get(RequestParams.PasswordGrant.APP_AGENT_NAME));
            claims.put("sub", storedRequest.getRequestParameters().get(RequestParams.PasswordGrant.USERNAME));
            claims.put("iss", Constants.OIDC_CONFIG_JWT_ISSUER_NAME);
            claims.put("iat", new Date().getTime() / 1000);
            claims.put("first_name", user.getFirstName());
            claims.put("last_name", user.getLastName());
            claims.put("email", user.getEmailId());
            claims.put("sid", storedRequest.getRequestParameters().get(RequestParams.PasswordGrant.SESSION_ID));
            claims.put("username", storedRequest.getRequestParameters().get(RequestParams.PasswordGrant.USERNAME));
            claims.put("biometric_enabled", !Utils.isNullOrEmpty(user.getServerBioTemplateHash()));
            claims.put("device_id", storedRequest.getRequestParameters().get(RequestParams.PasswordGrant.DEVICE_ID));

            token.setAdditionalInformation(claims);

            // set headers
            final Map<String, String> headers = new LinkedHashMap<>();
            headers.put(OIDCConstants.JWT_HEADER_KID.getValue(), jwtConfig.getKid());

            final JwtAccessTokenConverter converter = getJwtAccessTokenConverterWithCustomHeadersAndCustomUserTokenConverter(
                    Utils.getSigner(jwtConfig), headers);

            final DefaultOAuth2AccessToken enhancedTokenPswdGrant = (DefaultOAuth2AccessToken) converter.enhance(token,
                    oAuth2Authentication);
            /**
             * reset additional info so that custom added claims won't appear in
             * response of access token call response, only add "jti" from
             * generated token.
             */
            actualAdditionalInformationBeforeCustomClaims.put(OIDCConstants.JWT_CLAIM_JTI.getValue(),
                    enhancedTokenPswdGrant.getAdditionalInformation().get(OIDCConstants.JWT_CLAIM_JTI.getValue()));
            enhancedTokenPswdGrant.setAdditionalInformation(actualAdditionalInformationBeforeCustomClaims);
            enhancedToken = enhancedTokenPswdGrant;

        } else {
            final Map<String, String> headers = new LinkedHashMap<>();
            headers.put(OIDCConstants.JWT_HEADER_KID.getValue(), jwtConfig.getKid());
            final JwtAccessTokenConverter converter = getJwtAccessTokenConverterWithCustomHeaders(
                    Utils.getSigner(jwtConfig), headers);
            enhancedToken = converter.enhance(accessToken, authentication);
        }

        return enhancedToken;
    }

    /**
     * Gets the jwt access token converter with custom headers and custom user
     * token converter.
     *
     * @param signer
     *            the signer
     * @param headers
     *            the headers
     * @return the jwt access token converter with headers
     */
    private JwtAccessTokenConverter getJwtAccessTokenConverterWithCustomHeadersAndCustomUserTokenConverter(
            final Signer signer, final Map<String, String> headers) {
        final DefaultAccessTokenConverter defaultAccessTokenConverter = new DefaultAccessTokenConverter();
        final JwtAccessTokenConverter jwtAccessTokenConverterWithCustomHeaders = new JwtAccessTokenConverter() {
            @Override
            protected String encode(final OAuth2AccessToken accessToken, final OAuth2Authentication authentication) {
                String content;
                try {
                    content = objectMapper
                            .formatMap(defaultAccessTokenConverter.convertAccessToken(accessToken, authentication));
                } catch (final Exception e) {
                    throw new IllegalStateException("Cannot convert access token to JSON", e);
                }
                return JwtHelper.encode(content, signer, headers).getEncoded();
            }
        };
        defaultAccessTokenConverter.setUserTokenConverter(new DefaultUserAuthenticationConverter() {
            @Override
            public Map<String, ?> convertUserAuthentication(final Authentication authentication) {
                // FIXME: Remove this code block as below comment is not valid
                // anymore
                /**
                 * Do not add user_name to access_token as it is a combination
                 * of username:app:device;session and we want only username to
                 * be included in the access_token JWT.
                 */
                return new LinkedHashMap<>();
            }

        });
        jwtAccessTokenConverterWithCustomHeaders.setAccessTokenConverter(defaultAccessTokenConverter);
        jwtAccessTokenConverterWithCustomHeaders.setSigner(signer);
        return jwtAccessTokenConverterWithCustomHeaders;
    }

    /**
     * Gets the jwt access token converter with custom headers.
     *
     * @param signer
     *            the signer
     * @param headers
     *            the headers
     * @return the jwt access token converter with custom headers
     */
    private JwtAccessTokenConverter getJwtAccessTokenConverterWithCustomHeaders(final Signer signer,
            final Map<String, String> headers) {

        final CustomDefaultAccessTokenConverter defaultAccessTokenConverter = new CustomDefaultAccessTokenConverter();
        final JwtAccessTokenConverter jwtAccessTokenConverterWithCustomHeaders = new JwtAccessTokenConverter() {
            @Override
            protected String encode(final OAuth2AccessToken accessToken, final OAuth2Authentication authentication) {
                String content;
                try {
                    content = objectMapper
                            .formatMap(defaultAccessTokenConverter.convertAccessToken(accessToken, authentication));
                } catch (final Exception e) {
                    throw new IllegalStateException("Cannot convert access token to JSON", e);
                }
                return JwtHelper.encode(content, signer, headers).getEncoded();
            }
        };
        jwtAccessTokenConverterWithCustomHeaders.setAccessTokenConverter(defaultAccessTokenConverter);
        jwtAccessTokenConverterWithCustomHeaders.setSigner(signer);
        return jwtAccessTokenConverterWithCustomHeaders;

    }
}
