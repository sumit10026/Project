package com.uniken.authserver.services.impl;

import java.lang.reflect.Type;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.common.exceptions.UnauthorizedUserException;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.gson.reflect.TypeToken;
import com.mastercard.ess.fido2.assertion.AssertionService;
import com.mastercard.ess.fido2.database.FIDO2RegistrationEntity;
import com.mastercard.ess.fido2.database.FIDO2RegistrationRepository;
import com.mastercard.ess.fido2.service.Fido2RPRuntimeException;
import com.uniken.authserver.domains.AuthenticationDetails;
import com.uniken.authserver.domains.ValidateUserRequest;
import com.uniken.authserver.exception.InvalidSecureCookieException;
import com.uniken.authserver.exception.InvalidUserException;
import com.uniken.authserver.exception.RelIDAuthServerOAuth2Exception;
import com.uniken.authserver.exception.RelIDNotificationAcceptedException;
import com.uniken.authserver.exception.RelIDNotificationRejectedException;
import com.uniken.authserver.mq.publisher.RelIdVerifyMessagePublisher;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.repo.api.WebUserOTPRepo;
import com.uniken.authserver.services.api.AuthenticationService;
import com.uniken.authserver.services.api.OAuth2ClientDetailsService;
import com.uniken.authserver.services.api.SecureCookieService;
import com.uniken.authserver.services.api.SessionService;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.authserver.utility.AuthenticationUtils;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.SessionConstants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.auth.fido.AuthenticatorAttestationResponse;
import com.uniken.domains.auth.fido.FIDO2RegisteredAuthenticationModule;
import com.uniken.domains.enums.OTPType;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.relid.device.UserLocation;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.notification.ExpireNotificationRequest;
import com.uniken.domains.relid.notification.NotificationUserActionResponse;
import com.uniken.domains.relid.user.DeviceStatus;
import com.uniken.domains.relid.user.OTP;
import com.uniken.domains.relid.user.UserBrowser;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.domains.user.vos.SecureCookie;
import com.uniken.domains.user.vos.WebUserDetails;
import com.uniken.fido2.utils.FidoUtils;
import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;
import com.uniken.pass.handler.library.sync.api.PassHandler;
import com.uniken.totp.exception.TOTPValidationException;

@Service
public class AuthenticationServiceImpl
        implements
        AuthenticationService {

    private static final Logger LOG = LoggerFactory.getLogger(AuthenticationServiceImpl.class);

    @Autowired
    private WebDevMasterService webDevMasterService;

    @Autowired
    private CustomUserDetailsService customUserDetailsService;

    @Autowired
    private AuthenticateTotpServiceImpl authenticateTotpServiceImpl;

    @Autowired
    private WebUserOTPRepo webOTPRepo;

    @Autowired
    private UserAuthInfoRepo userAuthInfoRepo;

    @Autowired
    private FIDO2RegistrationRepository fido2RegistrationRepository;

    @Autowired
    private OAuth2ClientDetailsService customClientDetailService;

    @Autowired
    private RelIdVerifyMessagePublisher verifyPublisher;

    @Autowired
    private AssertionService assertionService;

    @Autowired
    private PassHandler passHandler;

    @Autowired
    SecureCookieService secureCookieService;

    @Autowired
    private SessionService sessionService;

    public boolean validateUserByTOTP(final HttpServletRequest request, final HttpServletResponse response,
            final ValidateUserRequest validateUserRequest) {

        LOG.info("validateUserByTOTP() -> Entered.");

        boolean isTotpValid = false;
        try {

            // validating incoming request
            AuthenticationUtils.validateRequest(request, response, validateUserRequest);

            EventLogger.log(EventId.RelidAuthServer.INIT_VALIDATE_USER_REQ, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), validateUserRequest.getUserName(),
                    "authenticating user through totp");

            final String correlationId = (String) request.getSession().getAttribute(Constants.CORRELATION_ID);
            final String webIdCheckSum = validateUserRequest.getWebDeviceParameterChecksum();

            // FIXME: demo
            // final HttpStatus notificationStatus =
            // checkIfNotificationIsActed(correlationId);
            //
            // if (notificationStatus == HttpStatus.OK &&
            // !checkNotificationResponse(correlationId, webIdCheckSum,
            // validateUserRequest.getWebDeviceParameters(), request)) {
            // LOG.info("validateUserByTOTP() : REL-ID verify Notification is
            // not accepted");
            // return isTotpValid;
            // }

            final String clientId = (String) request.getSession().getAttribute(EnterpriseInfo.CLIENT_ID);
            final EnterpriseInfo clientDetails = (EnterpriseInfo) customClientDetailService
                    .loadClientByClientId(clientId);

            isTotpValid = authenticateTotpServiceImpl.validateTotp(request, response, validateUserRequest,
                    clientDetails.getMapped_appagent_name());

        } catch (final TOTPValidationException | Exception e) {
            LOG.error("validateUserByTOTP() : Could Not Validate TOTP", e);
        }

        return isTotpValid;
    }

    public boolean validateUserByPassword(final HttpServletRequest request, final HttpServletResponse response,
            final ValidateUserRequest validateUserRequest) {

        LOG.info("validateUserByPassword() -> Entered.");

        boolean isPassValid = false;
        try {

            // validating incoming request
            AuthenticationUtils.validateRequest(request, response, validateUserRequest);

            EventLogger.log(EventId.RelidAuthServer.INIT_VALIDATE_USER_REQ, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), validateUserRequest.getUserName(),
                    "authenticating user through password");

            isPassValid = passHandler.validatePassword(validateUserRequest.getUserName(),
                    validateUserRequest.getAuthValue());

            final UserAuthInfoVO user = userAuthInfoRepo.fetchUserDetailsFromLoginId(validateUserRequest.getUserName());

            if (user == null) {
                EventLogger.log(EventId.RelidAuthServer.PASS_VALIDATION_FAILED, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request), "User not found in db.");
                throw new UsernameNotFoundException(Constants.UNAUTHORIZED_ACCESS);
            }
            if (user.getUserStatus() != RelIdUserStatus.ACTIVE) {
                EventLogger.log(EventId.RelidAuthServer.PASS_VALIDATION_FAILED, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request), "user is not ACTIVE");
                throw new UnauthorizedUserException(Constants.UNAUTHORIZED_ACCESS);
            }
            if (isPassValid) {
                return isPassValid;
            } else {
                throw new UnauthorizedUserException(Constants.UNAUTHORIZED_ACCESS);
            }

        } catch (final Exception e) {
            LOG.error("validateUserByPassword() : Could Not Validate Pass", e);
        }

        return isPassValid;
    }

    @Override
    public HttpStatus checkIfNotificationIsActed(final String correlationID) {

        LOG.info(
                "checkIfNotificationIsActed() : received request to check if notification is acted for correlationID : {}",
                correlationID);

        if (Utils.isNullOrEmpty(correlationID)) {
            LOG.error("CorrelationID is null or empty");
            throw new IllegalArgumentException("CorrelationID is null or empty");
        }

        final boolean isNotificationActed = Constants.getVerifyNotificationResponseMap().containsKey(correlationID);

        if (!isNotificationActed) {
            LOG.debug("checkIfNotificationIsActed() : Notification not yet acted for correlationID : {}",
                    correlationID);
            return HttpStatus.ACCEPTED;
        } else {
            LOG.info("checkIfNotificationIsActed() : Action taken on notification for correlationID : {}",
                    correlationID);

            final NotificationUserActionResponse actionResponse = Constants.getVerifyNotificationResponseMap()
                    .get(correlationID);

            if (actionResponse.getResponseCode() == 100) {
                return HttpStatus.OK;
            } else {
                return HttpStatus.NO_CONTENT;
            }
        }
    }

    @Override
    public boolean checkNotificationResponse(final String correlationID, final String browserDFPChecksum,
            final String browserDFP, final HttpServletRequest request) {

        LOG.info(
                "checkNotificationResponse() : received request to fetch and check notification for correlationID : {}",
                correlationID);

        // Validate incoming parameters
        Utils.validateRequest(correlationID, browserDFPChecksum, browserDFP);

        final NotificationUserActionResponse userActionResponse = Constants.getVerifyNotificationResponseMap()
                .get(correlationID);

        if (userActionResponse == null) {

            LOG.error(
                    "checkNotificationResponse() : Either invalid correlation ID provided or notification is NOT still acted");

            throw new RelIDAuthServerOAuth2Exception(
                    "Either invalid correlation ID provided or notification is NOT still acted");

        }

        if (Utils.isNullOrEmpty(userActionResponse.getActionResponse())) {

            LOG.error("checkNotificationResponse() : Notification is NOT still acted");

            throw new RelIDAuthServerOAuth2Exception("Notification is NOT still acted");

        }

        final String actionTaken = userActionResponse.getActionResponse();

        boolean isNotificationAccepted = false;

        if (PropertyConstants.RelIdVerifyConstants.NOTIFICATION_ACCEPT_LABEL.equalsIgnoreCase(actionTaken)) {

            LOG.info("checkNotificationResponse() : User accepted the notification Notification uuid: {}",
                    userActionResponse.getNotificationUuid());

            isNotificationAccepted = true;

            // EventLogger.log(EventId.RelidAuthServer.VERIFY_AUTH_ACCEPTED,
            // Utils.getClientIpAddress(request),
            // correlationID, userActionResponse.getUserId(),
            // "web_device_uuid : "
            // +
            // webDevMasterService.fetchWebDeviceMaster(browserDFPChecksum).getWebDeviceUuid()
            // + ", user_location : "
            // +
            // webDevMasterService.fetchWebDeviceMaster(browserDFPChecksum).getUserLocation());

            // adding simple event log as request will not contain
            // browserDFPChecksum as checksum is removed (Milestone 1)
            EventLogger.log(EventId.RelidAuthServer.VERIFY_AUTH_ACCEPTED_RAS, Utils.getClientIpAddress(request),
                    correlationID, userActionResponse.getUserId());

        } else if (PropertyConstants.RelIdVerifyConstants.NOTIFICATION_REJECT_LABEL.equalsIgnoreCase(actionTaken)) {

            LOG.info("checkNotificationResponse() : User rejected the notification, Notification uuid: {}",
                    userActionResponse.getNotificationUuid());

            // EventLogger.log(EventId.RelidAuthServer.VERIFY_AUTH_REJECTED,
            // Utils.getClientIpAddress(request),
            // correlationID, userActionResponse.getUserId(),
            // "web_device_uuid : "
            // +
            // webDevMasterService.fetchWebDeviceMaster(browserDFPChecksum).getWebDeviceUuid()
            // + ", user_location : "
            // +
            // webDevMasterService.fetchWebDeviceMaster(browserDFPChecksum).getUserLocation());

            // adding simple event log as request will not contain
            // browserDFPChecksum as checksum is removed (Milestone 1)
            EventLogger.log(EventId.RelidAuthServer.VERIFY_AUTH_REJECTED_RAS, Utils.getClientIpAddress(request),
                    correlationID, userActionResponse.getUserId());

        } else if (PropertyConstants.RelIdVerifyConstants.NOTIFICATION_FRAUD_LABEL.equalsIgnoreCase(actionTaken)) {

            LOG.error("checkNotificationResponse() : User marked this notification as fraud. Notification uuid: {}",
                    userActionResponse.getNotificationUuid());

            final Type hashType = new TypeToken<HashMap<String, Object>>() {
            }.getType();

            final Map<String, Object> webDeviceParameter = Constants.GSON.fromJson(browserDFP, hashType);

            /**
             * The following line blocks the browser built with an intention to
             * use browser fingerprinting to uniquely identify the browser and
             * device. In product roadmap it would change to : secure cookie
             * would ultimate method to identify the browser + device uniquely.
             * It's implementation is not still planned hence being commented
             * the below line
             */
            // webDevMasterService.blockBrowser(browserDFPChecksum,
            // webDeviceParameter);

            // EventLogger.log(EventId.RelidAuthServer.USER_DEVICE_BLOCKED_VERIFY_AUTH_FRAUD,
            // Utils.getClientIpAddress(request), correlationID,
            // userActionResponse.getUserId(),
            // "Browser blocked; web_device_uuid : "
            // +
            // webDevMasterService.fetchWebDeviceMaster(browserDFPChecksum).getWebDeviceUuid()
            // + ", user_location : "
            // +
            // webDevMasterService.fetchWebDeviceMaster(browserDFPChecksum).getUserLocation());

            // adding simple event log as request will not contain
            // browserDFPChecksum as checksum is removed (Milestone 1)
            EventLogger.log(EventId.RelidAuthServer.USER_DEVICE_BLOCKED_VERIFY_AUTH_FRAUD_RAS,
                    Utils.getClientIpAddress(request), correlationID, userActionResponse.getUserId());
        } else {

            LOG.error("Incorrect action response {} found : notification_uuid : {}, correlationId : {}", actionTaken,
                    userActionResponse.getNotificationUuid(), correlationID);
            throw new RelIDAuthServerOAuth2Exception("Incorrect action response found");

        }
        return isNotificationAccepted;
    }

    @Override
    public boolean checkUserActionOnNotification(final HttpServletRequest request, final HttpServletResponse response,
            final ValidateUserRequest validateUserRequest) {
        boolean isAuthenticated = false;

        final String correlationId = (String) request.getSession().getAttribute(Constants.CORRELATION_ID);
        if (correlationId == null) {
            LOG.error("checkUserActionOnNotification() : Notification not yet acted");
            EventLogger.log(EventId.RelidAuthServer.VERIFY_AUTH_NOT_ACTED, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "REL-ID verify Notification not yet acted ");
            return isAuthenticated;
        }

        if (checkIfNotificationIsActed(correlationId) == HttpStatus.OK
                && !checkNotificationResponse(correlationId, validateUserRequest.getWebDeviceParameterChecksum(),
                        validateUserRequest.getWebDeviceParameters(), request)) {

            LOG.info("checkUserActionOnNotification() : REL-ID verify Notification is rejected");

            EventLogger.log(EventId.RelidAuthServer.VERIFY_AUTH_REJECTED_RAS, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "REL-ID verify Notification is rejected ");
            throw new RelIDNotificationRejectedException("REL-ID Notification is rejected.");
        }

        isAuthenticated = true;

        return isAuthenticated;
    }

    @Override
    public boolean authenticateUserUsingFido(final HttpServletRequest request, final HttpServletResponse response,
            final ValidateUserRequest validateUserRequest) {
        LOG.info("authenticateUserUsingFido() -> Entered.");

        boolean isAuthenticated = false;

        try {

            // validating incoming request
            AuthenticationUtils.validateRequest(request, response, validateUserRequest);

            LOG.debug("authenticateUserUsingFido() : request validated");

            EventLogger.log(EventId.RelidAuthServer.INIT_VALIDATE_USER_REQ, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "authenticating user through fido assertion");

            if (validateUserRequest.getAuthValue() == null) {
                LOG.error("authenticateUserUsingFido() -> auth value is null.");

                EventLogger.log(EventId.RelidAuthServer.FIDO_AUTH_FAILED, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request), "FIDO Auth Value IS Null");
                return isAuthenticated;
            }

            final String assertion = validateUserRequest.getAuthValue();
            final JsonNode params = Constants.JACKSON_OBJECT_MAPPER.readTree(assertion);
            final JsonNode assertionResponse = assertionService.verify(params);

            if (assertionResponse.hasNonNull("status") && assertionResponse.get("status").textValue().equals("ok")) {
                isAuthenticated = true;

                final String fidoRegistrationKeyId = params.get("id").textValue();

                if (!Utils.isNullOrEmpty(fidoRegistrationKeyId)) {
                    final Optional<FIDO2RegistrationEntity> publicKeyId = fido2RegistrationRepository
                            .findByPublicKeyId(fidoRegistrationKeyId);

                    if (publicKeyId.isPresent()) {
                        final FIDO2RegistrationEntity fido2RegistrationEntity = publicKeyId.get();

                        final HttpSession session = request.getSession();
                        final AuthenticatorAttestationResponse authenticatorAttestationResponse = Constants.GSON
                                .fromJson(fido2RegistrationEntity.getW3cAuthenticatorAttenstationResponse(),
                                        AuthenticatorAttestationResponse.class);

                        // TODO: check assertion response to identify 2FA
                        // instead of attestation response
                        final boolean loggedInUsingFido2fa = FidoUtils
                                .is2FaAuthenticator(authenticatorAttestationResponse.getAttestationObject());
                        session.setAttribute(SessionConstants.LOGGED_IN_USING_FIDO_2FA, loggedInUsingFido2fa);

                        LOG.debug("loggedInUsingFido2fa: {}", loggedInUsingFido2fa);

                        if (fido2RegistrationEntity.getAuthenticatorTransports().stream()
                                .anyMatch(transport -> "internal".equals(transport.getValue()))) {
                            LOG.debug("Logged in using fido platform auth");
                            session.setAttribute(SessionConstants.LOGGED_IN_USING_FIDO_PLATFORM_AUTH, true);

                            final Authentication authentication = SecurityContextHolder.getContext()
                                    .getAuthentication();
                            if (authentication != null && authentication.isAuthenticated()
                                    && !(authentication instanceof AnonymousAuthenticationToken)) {

                                // Setting secure cookies start

                                SecureCookie secureCookie = null;
                                Cookie sCookie = null;
                                WebDevMaster webDevMaster = null;
                                boolean addedForAuthenticator = false;
                                UserAuthInfoVO userAuthInfo = null;

                                LOG.info("Adding secure cookies");

                                final boolean isSecureCookiePresent = Utils.getIsSecureCookieSetFromRequestContext();
                                boolean createNewSecureCookie = true;

                                if (isSecureCookiePresent && !secureCookieService.isSecureCookieExpired(request)) {
                                    sCookie = Utils.getSecureCookieFromRequestContext();

                                    LOG.info("Secure cookies is present and not expird");

                                    if (secureCookieService.decryptSecureCookie(sCookie.getValue()) == null) {
                                        EventLogger.log(EventId.RelidAuthServer.INVALID_SECURE_COOKIE,
                                                Utils.getClientIpAddress(request),
                                                AuthenticationUtils.getRequestorId(request),
                                                AuthenticationUtils.getUsername(request),
                                                AuthenticationUtils.getUserAgent(request),
                                                "Request Has Invalid Secure Cookie");
                                        throw new InvalidSecureCookieException("Request Has Invalid Secure Cookie");
                                    }

                                    webDevMaster = webDevMasterService
                                            .fetchWebDeviceMasterUsingSecureCookieValue(sCookie.getValue());

                                    if (webDevMaster != null) {
                                        final List<Map<String, String>> userIdList = userAuthInfoRepo
                                                .fetchAssociatedUserWithWebDeviceUuid(webDevMaster.getWebDeviceUuid());

                                        createNewSecureCookie = userIdList.isEmpty();
                                    }
                                }

                                if (createNewSecureCookie) {

                                    LOG.info("authenticateUserUsingFido() tie secureCookie inside");
                                    webDevMaster = sessionService.createSecureCookieForFIDO2();
                                    addedForAuthenticator = true;
                                    secureCookie = webDevMaster.getSecureCookie();
                                } else {
                                    sCookie = Utils.getSecureCookieFromRequestContext();
                                    LOG.info("authenticateUserUsingFido() existing secureCookie");
                                    webDevMaster = webDevMasterService
                                            .fetchWebDeviceMasterUsingSecureCookieValue(sCookie.getValue());
                                    LOG.info("webDevMaster.getWebDeviceUuid(): {} ", webDevMaster.getWebDeviceUuid());
                                }

                                userAuthInfo = userAuthInfoRepo
                                        .fetchUserDetailsFromLoginId(validateUserRequest.getUserName());
                                if (userAuthInfo == null) {
                                    throw new InvalidUserException(
                                            "Invalid User : User is not registered in the system");
                                }

                                final String webDeviceUuid = webDevMaster.getWebDeviceUuid();
                                final Optional<UserBrowser> optionalBrowser = userAuthInfo.getWebUserDetails()
                                        .getBrowsers().stream().filter(browser -> StringUtils.equals(webDeviceUuid,
                                                browser.getWebDeviceUuid()))
                                        .findFirst();
                                UserBrowser browser = null;
                                if (optionalBrowser.isPresent()) {
                                    browser = optionalBrowser.get();

                                    // FIXME. Need to check if we can use
                                    // FIDO2RegistrationRepositoryImpl to get
                                    // FIDO2RegisteredAuthenticationModule
                                    // instance.

                                    final List<FIDO2RegisteredAuthenticationModule> authList = userAuthInfoRepo
                                            .getListOFIDO2fRegAuthModuleLoginId(validateUserRequest.getUserName());

                                    LOG.info("Getting List of available regsistered FIDO2 Authenticators");

                                    for (final FIDO2RegisteredAuthenticationModule authenticationModule : authList) {
                                        if (authenticationModule.getRegistrationKeyId().equals(fidoRegistrationKeyId)) {
                                            browser.setAuthenticatorUuid(authenticationModule.getAuthenticatorUuid());
                                        }
                                    }

                                    browser.setAddedForAuthenticator(addedForAuthenticator);

                                    if (userAuthInfo.getWebUserDetails() != null) {
                                        userAuthInfoRepo.updateUserAuthInfoDoc(validateUserRequest.getUserName(),
                                                UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR,
                                                userAuthInfo.getWebUserDetails().getBrowsers());

                                        LOG.info("Updating existing user's authentication info");
                                    }

                                }

                                // Setting secure cookies end

                            }

                        }
                    }
                }
            }

        } catch (final JsonProcessingException | IllegalArgumentException | Fido2RPRuntimeException e) {
            LOG.error("authenticateUserUsingFido() -> Exception", e);
            return isAuthenticated;
        }

        return isAuthenticated;
    }

    /**
     * This method validates SMS OTP and returns true / false
     * 
     * @param request
     * @param response
     * @param validateUserRequest
     * @return
     */
    @Override
    public boolean validateUserBySMSOTP(final HttpServletRequest request, final HttpServletResponse response,
            final ValidateUserRequest validateUserRequest) {
        boolean isValidOTP = false;

        LOG.info("validateUserByOTP() : Validating SMS OTP");

        // validating incoming request
        AuthenticationUtils.validateRequest(request, response, validateUserRequest);

        LOG.debug("validateUserByOTP() : request validated");

        final String correlationId = (String) request.getSession().getAttribute(Constants.CORRELATION_ID);
        final String webIdCheckSum = validateUserRequest.getWebDeviceParameterChecksum();
        final String webIdParameters = validateUserRequest.getWebDeviceParameters();
        final String clientId = (String) request.getSession().getAttribute(EnterpriseInfo.CLIENT_ID);

        HttpStatus notificationStatus = HttpStatus.NO_CONTENT;
        if (!Utils.isNullOrEmpty(correlationId)) {
            notificationStatus = checkIfNotificationIsActed(correlationId);

            if (notificationStatus == HttpStatus.OK) {
                if (checkNotificationResponse(correlationId, webIdCheckSum, webIdParameters, request)) {
                    LOG.info("validateUserByOTP() : REL-ID verify Notification is accepted");
                    throw new RelIDNotificationAcceptedException("REL-ID Notification is already accepted.");
                } else {
                    LOG.info("validateUserByOTP() : REL-ID verify Notification is rejected");
                    throw new RelIDNotificationRejectedException("REL-ID Notification is rejected.");
                }
            }
        }

        final String userId = validateUserRequest.getUserName();
        final String smsOTP = validateUserRequest.getAuthValue();

        if (smsOTP == null || smsOTP.trim().isEmpty()) {
            LOG.error("validateUserByOTP() -> sms otp not found in db for userId :{}.", userId);
            EventLogger.log(EventId.RelidAuthServer.SMS_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "SMS OTP not found in incoming request.");
            throw new UsernameNotFoundException(Constants.UNAUTHORIZED_ACCESS);
        }

        LOG.info("validateUserByOTP() : Generate OTP request received for Username : {}.", userId);

        final UserAuthInfoVO user = userAuthInfoRepo.fetchUserDetailsFromLoginId(userId);

        if (user == null) {
            LOG.error("validateUserByOTP() -> User {} not found in db.", userId);
            EventLogger.log(EventId.RelidAuthServer.SMS_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "User not found in db.");
            throw new UsernameNotFoundException(Constants.UNAUTHORIZED_ACCESS);
        }

        if (user.getUserStatus() != RelIdUserStatus.ACTIVE) {
            LOG.error("validateUserByOTP() -> user {} is not ACTIVE", userId);
            EventLogger.log(EventId.RelidAuthServer.SMS_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "user is not ACTIVE.");
            throw new UnauthorizedUserException(Constants.UNAUTHORIZED_ACCESS);
        }

        final OTP matchedOTP = webOTPRepo.validateWebUserOTP(smsOTP, OTPType.SMS, userId);

        if (matchedOTP == null) {

            LOG.error("validateUserByOTP() -> OTP mismatched for user : {}", userId);
            EventLogger.log(EventId.RelidAuthServer.INVALID_OTP, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "otp mismatch!");
            return isValidOTP;

        }

        /**
         * Send Discard notification request to REL-ID Verify as User is not
         * acted on the Notification and the SMS OTP validation is completed.
         */
        if (notificationStatus == HttpStatus.ACCEPTED) {
            // FIXME : Pass actual client id & remove dependency of webChecksum
            constructAndPublishDiscardNotificationRequest(clientId, userId, "N/A", correlationId);
        }

        LOG.info("validateUserByOTP() -> OTP successfully matched for user :{}", userId);
        EventLogger.log(EventId.RelidAuthServer.OTP_VALIDATED_RAS, Utils.getClientIpAddress(request),
                AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                AuthenticationUtils.getUserAgent(request), "otp matched!");

        final AuthenticationDetails authDetails = new AuthenticationDetails("Authenticated", AuthType.SMSOTP,
                new Date(), userId, matchedOTP.getDev_uuid());

        request.getSession().setAttribute(AuthenticationDetails.AUTHENTICATION_DETAILS_STR, authDetails);

        webOTPRepo.archiveWebUserOTP(matchedOTP);

        isValidOTP = true;

        return isValidOTP;
    }

    /**
     * This method validates Email OTP and returns true / false
     * 
     * @param request
     * @param response
     * @param validateUserRequest
     * @return
     */
    @Override
    public boolean validateUserByEmailOTP(final HttpServletRequest request, final HttpServletResponse response,
            final ValidateUserRequest validateUserRequest) {
        boolean isValidOTP = false;

        LOG.info("validateUserByEmailOTP() : Validating Email OTP");

        // validating incoming request
        AuthenticationUtils.validateRequest(request, response, validateUserRequest);

        LOG.debug("validateUserByEmailOTP() : request validated");

        final String correlationId = (String) request.getSession().getAttribute(Constants.CORRELATION_ID);
        final String webIdCheckSum = validateUserRequest.getWebDeviceParameterChecksum();
        final String webIdParameters = validateUserRequest.getWebDeviceParameters();
        final String clientId = (String) request.getSession().getAttribute(EnterpriseInfo.CLIENT_ID);

        HttpStatus notificationStatus = HttpStatus.NO_CONTENT;
        if (!Utils.isNullOrEmpty(correlationId)) {
            notificationStatus = checkIfNotificationIsActed(correlationId);

            if (notificationStatus == HttpStatus.OK) {
                if (checkNotificationResponse(correlationId, webIdCheckSum, webIdParameters, request)) {
                    LOG.info("validateUserByEmailOTP() : REL-ID verify Notification is accepted");
                    throw new RelIDNotificationAcceptedException("REL-ID Notification is already accepted.");
                } else {
                    LOG.info("validateUserByEmailOTP() : REL-ID verify Notification is rejected");
                    throw new RelIDNotificationRejectedException("REL-ID Notification is rejected.");
                }
            }
        }

        final String userId = validateUserRequest.getUserName();
        final String emailOTP = validateUserRequest.getAuthValue();

        if (emailOTP == null || emailOTP.trim().isEmpty()) {
            LOG.error("validateUserByEmailOTP() -> email otp not found in db for userId :{}.", userId);
            EventLogger.log(EventId.RelidAuthServer.EMAIL_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "SMS OTP not found in incoming request.");
            throw new UsernameNotFoundException(Constants.UNAUTHORIZED_ACCESS);
        }

        LOG.info("validateUserByEmailOTP() : Generate OTP request received for Username : {}.", userId);

        final UserAuthInfoVO user = userAuthInfoRepo.fetchUserDetailsFromLoginId(userId);

        if (user == null) {
            LOG.error("validateUserByEmailOTP() -> User {} not found in db.", userId);
            EventLogger.log(EventId.RelidAuthServer.EMAIL_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "User not found in db.");
            throw new UsernameNotFoundException(Constants.UNAUTHORIZED_ACCESS);
        }

        if (user.getUserStatus() != RelIdUserStatus.ACTIVE) {
            LOG.error("validateUserByEmailOTP() -> user {} is not ACTIVE", userId);
            EventLogger.log(EventId.RelidAuthServer.EMAIL_OTP_PREREQUISITES_FAILED, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "user is not ACTIVE.");
            throw new UnauthorizedUserException(Constants.UNAUTHORIZED_ACCESS);
        }

        final OTP matchedOTP = webOTPRepo.validateWebUserOTP(emailOTP, OTPType.EMAIL, userId);

        if (matchedOTP == null) {

            LOG.error("validateUserByEmailOTP() -> OTP mismatched for user : {}", userId);
            EventLogger.log(EventId.RelidAuthServer.INVALID_OTP, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "otp mismatch!");
            return isValidOTP;

        }

        /**
         * Send Discard notification request to REL-ID Verify as User is not
         * acted on the Notification and the SMS OTP validation is completed.
         */
        if (notificationStatus == HttpStatus.ACCEPTED) {
            // FIXME : Pass actual client id & remove dependency of webChecksum
            constructAndPublishDiscardNotificationRequest(clientId, userId, "N/A", correlationId);
        }

        LOG.info("validateUserByEmailOTP() -> OTP successfully matched for user :{}", userId);
        EventLogger.log(EventId.RelidAuthServer.OTP_VALIDATED_RAS, Utils.getClientIpAddress(request),
                AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                AuthenticationUtils.getUserAgent(request), "otp matched!");

        final AuthenticationDetails authDetails = new AuthenticationDetails("Authenticated", AuthType.EMAILOTP,
                new Date(), userId, matchedOTP.getDev_uuid());

        request.getSession().setAttribute(AuthenticationDetails.AUTHENTICATION_DETAILS_STR, authDetails);

        webOTPRepo.archiveWebUserOTP(matchedOTP);

        isValidOTP = true;

        return isValidOTP;
    }

    /**
     * Construct the discard notification request and publish request on the
     * REL-ID Verify.
     * 
     * @param inputParameters
     * @param username
     * @param webIdCheckSum
     * @param correlationId
     */
    private void constructAndPublishDiscardNotificationRequest(final String clientId, final String username,
            final String webIdCheckSum, final String correlationId) {
        final EnterpriseInfo clientDetails = (EnterpriseInfo) customClientDetailService.loadClientByClientId(clientId);

        final ExpireNotificationRequest expireNotificationRequest = new ExpireNotificationRequest(username, "N/A",
                clientDetails.getMapped_appagent_uuid());

        verifyPublisher.sendDiscardRVNRequestToVerify(Constants.GSON.toJson(expireNotificationRequest), correlationId);
    }

    /**
     * This function adds / update the web device master depending on
     * availability in the web_dev_master collection
     * 
     * @param inputParameters
     * @return
     */
    private WebDevMaster addORUpdateWebMasterDevice(final ValidateUserRequest validateUserRequest) {
        LOG.info("addORUpdateWebMasterDevice()-> entered");

        final String webDeviceParametersString = validateUserRequest.getWebDeviceParameters();
        final String webDeviceParameterChecksumString = validateUserRequest.getWebDeviceParameterChecksum();

        // FIXME : We will need user location in case of validate user API
        // final String userLocationStr = (String)
        // inputParameters.get(WebDevMaster.USER_LOCATION_STR);
        final String userLocationStr = null;
        final UserLocation userLocation = Constants.GSON_BSON.fromJson(userLocationStr, UserLocation.class);

        final Type hashType = new TypeToken<HashMap<String, Object>>() {
        }.getType();

        final Map<String, Object> webDeviceParameter = Constants.GSON.fromJson(webDeviceParametersString, hashType);

        WebDevMaster retrievedDevice = webDevMasterService.fetchWebDeviceMaster(webDeviceParameterChecksumString);

        if (retrievedDevice == null) {

            LOG.info("addOrUpdateIntoWebDevMaster() => adding into web device master collection");

            retrievedDevice = new WebDevMaster(Utils.secureRandomUUIDGenerator(), DeviceStatus.CREATED.getName(),
                    userLocation, webDeviceParameter, new Date(), new Date(), webDeviceParameterChecksumString);

            webDevMasterService.addWebDeviceMaster(retrievedDevice);

        } else if (retrievedDevice.getStatus() != null
                && (retrievedDevice.getStatus().equalsIgnoreCase(DeviceStatus.CREATED.getName())
                        || retrievedDevice.getStatus().equalsIgnoreCase(DeviceStatus.ACTIVE.getName()))) {

            LOG.info("addOrUpdateIntoWebDevMaster() => updating into web device master collection");
            retrievedDevice.setUpdatedTS(new Date());

            retrievedDevice.setWebDeviceParameters(webDeviceParameter);
            webDevMasterService.updateWebDeviceMaster(retrievedDevice);

        } else {

            LOG.error("addOrUpdateIntoWebDevMaster() : WebDeviceMaster is BLOCKED , UUID = {}",
                    retrievedDevice.getWebDeviceUuid());
            throw new IllegalArgumentException(
                    String.format("WebDevMaster device is BLOCKED for UUID = %s", retrievedDevice.getWebDeviceUuid()));
        }

        LOG.info("addORUpdateWebMasterDevice()-> exiting");

        return retrievedDevice;
    }

}
