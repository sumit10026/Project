package com.uniken.authserver.services.impl;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Type;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.owasp.esapi.ESAPI;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.authentication.AuthenticationServiceException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.common.exceptions.UnauthorizedUserException;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.Sets;
import com.google.gson.reflect.TypeToken;
import com.mastercard.ess.fido2.service.Fido2RPRuntimeException;
import com.mongodb.client.result.UpdateResult;
import com.uniken.authserver.domains.UserInfo;
import com.uniken.authserver.domains.ValidateUserAuthDetails;
import com.uniken.authserver.domains.ValidateUserRequest;
import com.uniken.authserver.exception.AttemptCounterExceededException;
import com.uniken.authserver.exception.InvalidSecureCookieException;
import com.uniken.authserver.exception.InvalidUserException;
import com.uniken.authserver.exception.RelIDAuthServerOAuth2Exception;
import com.uniken.authserver.exception.RelIDNotificationAcceptedException;
import com.uniken.authserver.exception.SessionConflictedException;
import com.uniken.authserver.exception.ValidateUserException;
import com.uniken.authserver.mq.publisher.RelIdVerifyMessagePublisher;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.services.api.AuthenticationService;
import com.uniken.authserver.services.api.OAuth2ClientDetailsService;
import com.uniken.authserver.services.api.SecureCookieService;
import com.uniken.authserver.services.api.SessionService;
import com.uniken.authserver.services.api.UserService;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.authserver.utility.AuthenticationUtils;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.InputValidationUtils;
import com.uniken.authserver.utility.MessageConstants;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.SessionConstants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.auth.RegisteredAuthenticationModule;
import com.uniken.domains.auth.fido.FIDO2RegisteredAuthenticationModule;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.WebUserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.enums.auth.AuthTypeStatus;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.notification.ExpireNotificationRequest;
import com.uniken.domains.relid.notification.NotificationUserActionResponse;
import com.uniken.domains.relid.user.UserBrowser;
import com.uniken.domains.relid.user.WebUserBrowserDetailsDTO;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.domains.user.vos.UserAuthInfoRegAuthModuleVo;
import com.uniken.domains.user.vos.WebUserDetails;
import com.uniken.fido2.utils.FidoUtils;
import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;
import com.uniken.totp.exception.TOTPValidationException;

/**
 * @author Kushal Jaiswal
 */
@Service
public class UserServiceImpl
        implements
        UserService {

    private static final Logger LOG = LoggerFactory.getLogger(UserServiceImpl.class);

    @Autowired
    private WebDevMasterService webDevMasterService;

    @Autowired
    private CustomUserDetailsService customUserDetailsService;

    @Autowired
    private OAuth2ClientDetailsService customClientDetailService;

    @Autowired
    private ValidateTotpServiceImpl validateTotpServiceImpl;

    @Autowired
    private SMSOTPServiceImpl smsOTPServiceImpl;

    @Autowired
    private EmailOTPServiceImpl emailOTPServiceImpl;

    @Autowired
    private RelIdVerifyMessagePublisher verifyPublisher;

    @Autowired
    private UserAuthInfoRepo userAuthInfoRepoImpl;

    @Autowired
    private AuthenticationService authenticationService;

    @Autowired
    private SecureCookieService secureCookieService;

    @Autowired
    SessionService sessionService;

    private final Object assertionService;
    private final Method assertionServiceVerifyMethod;

    public UserServiceImpl(final ApplicationContext applicationContext) {
        super();
        try {
            assertionService = applicationContext.getBean("assertionService");
            assertionServiceVerifyMethod = assertionService.getClass().getDeclaredMethod("verify", JsonNode.class);
            if (!assertionServiceVerifyMethod.isAccessible()) {
                assertionServiceVerifyMethod.setAccessible(true);
            }
        } catch (NoSuchMethodException | SecurityException e) {
            throw new Fido2RPRuntimeException("Could not load assertion service.");
        }
    }

    // FIXME : We can use AuthenticationServiceImpl's method instead of this
    @Deprecated
    @Override
    public HttpStatus checkIfNotificationIsActed(final String correlationID) {

        LOG.info(
                "checkIfNotificationIsActed() : received request to check if notification is acted for correlationID : {}",
                correlationID);

        if (Utils.isNullOrEmpty(correlationID)) {
            LOG.error("CorrelationID is null or empty");
            throw new IllegalArgumentException("CorrelationID is null or empty");
        }

        final boolean isNotificationActed = Constants.getVerifyNotificationResponseMap().containsKey(correlationID);

        if (!isNotificationActed) {
            LOG.debug("checkIfNotificationIsActed() : Notification not yet acted for correlationID : {}",
                    correlationID);
            return HttpStatus.ACCEPTED;
        } else {
            LOG.info("checkIfNotificationIsActed() : Action taken on notification for correlationID : {}",
                    correlationID);

            final NotificationUserActionResponse actionResponse = Constants.getVerifyNotificationResponseMap()
                    .get(correlationID);

            if (actionResponse.getResponseCode() == 100) {
                return HttpStatus.OK;
            } else {
                return HttpStatus.NO_CONTENT;
            }
        }
    }

    // FIXME: Unused
    @Deprecated
    @Override
    public boolean checkNotificationResponse(final String correlationID, final String browserDFPChecksum,
            final String browserDFP, final HttpServletRequest request) {

        LOG.info(
                "checkNotificationResponse() : received request to fetch and check notification for correlationID : {}",
                correlationID);

        // Validate incoming parameters
        Utils.validateRequest(correlationID, browserDFPChecksum, browserDFP);

        final NotificationUserActionResponse userActionResponse = Constants.getVerifyNotificationResponseMap()
                .get(correlationID);

        if (userActionResponse == null) {

            LOG.error(
                    "checkNotificationResponse() : Either invalid correlation ID provided or notification is NOT still acted");

            throw new RelIDAuthServerOAuth2Exception(
                    "Either invalid correlation ID provided or notification is NOT still acted");

        }

        if (Utils.isNullOrEmpty(userActionResponse.getActionResponse())) {

            LOG.error("checkNotificationResponse() : Notification is NOT still acted");

            throw new RelIDAuthServerOAuth2Exception("Notification is NOT still acted");

        }

        final String actionTaken = userActionResponse.getActionResponse();

        boolean isNotificationAccepted = false;

        if (PropertyConstants.RelIdVerifyConstants.NOTIFICATION_ACCEPT_LABEL.equalsIgnoreCase(actionTaken)) {

            LOG.info("checkNotificationResponse() : User accepted the notification Notification uuid: {}",
                    userActionResponse.getNotificationUuid());

            isNotificationAccepted = true;

            EventLogger.log(EventId.RelidAuthServer.VERIFY_AUTH_ACCEPTED_RAS, Utils.getClientIpAddress(request),
                    correlationID, userActionResponse.getUserId(),
                    "web_device_uuid : "
                            + webDevMasterService.fetchWebDeviceMaster(browserDFPChecksum).getWebDeviceUuid()
                            + ", user_location : "
                            + webDevMasterService.fetchWebDeviceMaster(browserDFPChecksum).getUserLocation());

        } else if (PropertyConstants.RelIdVerifyConstants.NOTIFICATION_REJECT_LABEL.equalsIgnoreCase(actionTaken)) {

            LOG.info("checkNotificationResponse() : User rejected the notification, Notification uuid: {}",
                    userActionResponse.getNotificationUuid());

            EventLogger.log(EventId.RelidAuthServer.VERIFY_AUTH_REJECTED_RAS, Utils.getClientIpAddress(request),
                    correlationID, userActionResponse.getUserId(),
                    "web_device_uuid : "
                            + webDevMasterService.fetchWebDeviceMaster(browserDFPChecksum).getWebDeviceUuid()
                            + ", user_location : "
                            + webDevMasterService.fetchWebDeviceMaster(browserDFPChecksum).getUserLocation());

        } else if (PropertyConstants.RelIdVerifyConstants.NOTIFICATION_FRAUD_LABEL.equalsIgnoreCase(actionTaken)) {

            LOG.error("checkNotificationResponse() : User marked this notification as fraud. Notification uuid: {}",
                    userActionResponse.getNotificationUuid());

            final Type hashType = new TypeToken<HashMap<String, Object>>() {
            }.getType();

            final Map<String, Object> webDeviceParameter = Constants.GSON.fromJson(browserDFP, hashType);

            /**
             * The following line blocks the browser built with an intention to
             * use browser fingerprinting to uniquely identify the browser and
             * device. In product roadmap it would change to : secure cookie
             * would ultimate method to identify the browser + device uniquely.
             * It's implementation is not still planned hence being commented
             * the below line
             */
            // webDevMasterService.blockBrowser(browserDFPChecksum,
            // webDeviceParameter);

            EventLogger.log(EventId.RelidAuthServer.USER_DEVICE_BLOCKED_VERIFY_AUTH_FRAUD_RAS,
                    Utils.getClientIpAddress(request), correlationID, userActionResponse.getUserId(),
                    "Browser blocked; web_device_uuid : "
                            + webDevMasterService.fetchWebDeviceMaster(browserDFPChecksum).getWebDeviceUuid()
                            + ", user_location : "
                            + webDevMasterService.fetchWebDeviceMaster(browserDFPChecksum).getUserLocation());
        } else {

            LOG.error("Incorrect action response {} found : notification_uuid : {}, correlationId : {}", actionTaken,
                    userActionResponse.getNotificationUuid(), correlationID);
            throw new RelIDAuthServerOAuth2Exception("Incorrect action response found");

        }
        return isNotificationAccepted;
    }

    // FIXME : Unused
    @Deprecated
    @Override
    public Authentication validateUserByTOTP(final HttpServletRequest request, final HttpServletResponse response,
            final Map<String, Object> inputParameters) {

        LOG.info("validateUserByTOTP() -> Entered.");

        Authentication authentication = null;
        try {

            // validating incoming request
            Utils.validateRequest(request, response, inputParameters);

            EventLogger.log(EventId.RelidAuthServer.INIT_VALIDATE_USER_REQ, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(),
                    request.getParameter(Constants.REQ_PARAM_USERNAME), "authenticating user through totp validation");

            final String correlationId = (String) request.getSession().getAttribute(Constants.CORRELATION_ID);
            final String webIdCheckSum = (String) inputParameters.get(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR);

            final HttpStatus notificationStatus = checkIfNotificationIsActed(correlationId);

            if (notificationStatus == HttpStatus.OK && !checkNotificationResponse(correlationId, webIdCheckSum,
                    (String) inputParameters.get(WebDevMaster.WEB_DEV_PARAMETERS_STR), request)) {
                LOG.info("validateUserByTOTP() : REL-ID verify Notification is not accepted");
                throw new AccessDeniedException(Constants.UNAUTHORIZED_ACCESS);
            }

            final boolean isTotpValid = validateTotpServiceImpl.validateTotp(request, response, inputParameters);

            if (isTotpValid) {

                final UserDetails user = customUserDetailsService
                        .loadUserByUsername((String) inputParameters.get(Constants.REQ_PARAM_USERNAME));
                authentication = new UsernamePasswordAuthenticationToken(user.getUsername(), null,
                        user.getAuthorities());

                /**
                 * Send Discard notification request to REL-ID Verify as User is
                 * not acted on the Notification and the TOTP validation is
                 * completed.
                 */
                if (notificationStatus == HttpStatus.ACCEPTED) {
                    constructAndPublishDiscardNotificationRequest(inputParameters, user.getUsername(), webIdCheckSum,
                            correlationId);

                }

            } else {

                LOG.error("Invalid totp entered by user : {} ", inputParameters.get(Constants.REQ_PARAM_USERNAME));
                throw new AccessDeniedException(Constants.UNAUTHORIZED_ACCESS);
            }

        } catch (final TOTPValidationException e) {

            LOG.error("validateUserByTOTP() : TOTPValidationException occurred", e);
            throw new AuthenticationServiceException(e.getMessage());

        }
        return authentication;
    }

    // FIXME : Unused
    @Deprecated
    @Override
    public Authentication validateUserBySMSOTP(final HttpServletRequest request, final HttpServletResponse response,
            final Map<String, Object> inputParameters) {

        LOG.info("validateUserBySMSOTP() -> Entered.");

        Authentication authentication = null;
        try {

            // validating incoming request
            Utils.validateRequest(request, response, inputParameters);

            EventLogger.log(EventId.RelidAuthServer.INIT_VALIDATE_USER_REQ, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(),
                    request.getParameter(Constants.REQ_PARAM_USERNAME),
                    "authenticating user through smsotp validation");

            final String correlationId = (String) request.getSession().getAttribute(Constants.CORRELATION_ID);
            final String webIdCheckSum = (String) inputParameters.get(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR);

            final HttpStatus notificationStatus = checkIfNotificationIsActed(correlationId);

            if (notificationStatus == HttpStatus.OK && !checkNotificationResponse(correlationId, webIdCheckSum,
                    (String) inputParameters.get(WebDevMaster.WEB_DEV_PARAMETERS_STR), request)) {
                throw new AccessDeniedException(Constants.UNAUTHORIZED_ACCESS);
            }

            final boolean isSMSotpValid = smsOTPServiceImpl.validateUserByOTP(request, response, inputParameters);

            if (isSMSotpValid) {

                final UserDetails user = customUserDetailsService
                        .loadUserByUsername((String) inputParameters.get(Constants.REQ_PARAM_USERNAME));
                authentication = new UsernamePasswordAuthenticationToken(user.getUsername(), null,
                        user.getAuthorities());

                /**
                 * Send Discard notification request to REL-ID Verify as User is
                 * not acted on the Notification and the TOTP validation is
                 * completed.
                 */
                if (notificationStatus == HttpStatus.ACCEPTED) {
                    constructAndPublishDiscardNotificationRequest(inputParameters, user.getUsername(), webIdCheckSum,
                            correlationId);

                }

            } else {
                throw new AccessDeniedException(Constants.UNAUTHORIZED_ACCESS);
            }

        } catch (final Exception e) {
            throw new AuthenticationServiceException(e.getMessage());
        }
        return authentication;
    }

    // FIXME : Unused
    @Deprecated
    @Override
    public Authentication validateUserByEmailOTP(final HttpServletRequest request, final HttpServletResponse response,
            final Map<String, Object> inputParameters) {

        LOG.info("validateUserByEmailOTP() -> Entered.");

        Authentication authentication = null;
        try {

            // validating incoming request
            Utils.validateRequest(request, response, inputParameters);

            EventLogger.log(EventId.RelidAuthServer.INIT_VALIDATE_USER_REQ, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(),
                    request.getParameter(Constants.REQ_PARAM_USERNAME),
                    "authenticating user through emailotp validation");

            final String correlationId = (String) request.getSession().getAttribute(Constants.CORRELATION_ID);
            final String webIdCheckSum = (String) inputParameters.get(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR);

            final HttpStatus notificationStatus = checkIfNotificationIsActed(correlationId);

            if (notificationStatus == HttpStatus.OK && !checkNotificationResponse(correlationId, webIdCheckSum,
                    (String) inputParameters.get(WebDevMaster.WEB_DEV_PARAMETERS_STR), request)) {
                throw new AccessDeniedException(Constants.UNAUTHORIZED_ACCESS);
            }

            final boolean isEmailotpValid = emailOTPServiceImpl.validateUserByOTP(request, response, inputParameters);

            if (isEmailotpValid) {

                final UserDetails user = customUserDetailsService
                        .loadUserByUsername((String) inputParameters.get(Constants.REQ_PARAM_USERNAME));
                authentication = new UsernamePasswordAuthenticationToken(user.getUsername(), null,
                        user.getAuthorities());

                /**
                 * Send Discard notification request to REL-ID Verify as User is
                 * not acted on the Notification and the TOTP validation is
                 * completed.
                 */
                if (notificationStatus == HttpStatus.ACCEPTED) {
                    constructAndPublishDiscardNotificationRequest(inputParameters, user.getUsername(), webIdCheckSum,
                            correlationId);

                }

            } else {
                throw new AccessDeniedException(Constants.UNAUTHORIZED_ACCESS);
            }

        } catch (final Exception e) {
            throw new AuthenticationServiceException(e.getMessage());
        }
        return authentication;
    }

    // FIXME: Unused
    @Deprecated
    @Override
    public Authentication checkUserActionOnNotification(final HttpServletRequest request,
            final HttpServletResponse response, final Map<String, Object> inputParameters) {

        Authentication authentication = null;
        final String correlationId = (String) request.getSession().getAttribute(Constants.CORRELATION_ID);
        if (correlationId == null) {
            LOG.error("attemptAuthentication() : Notification not yet acted");
            throw new UnauthorizedUserException(Constants.UNAUTHORIZED_ACCESS);
        }
        if (checkIfNotificationIsActed(correlationId) == HttpStatus.OK && !checkNotificationResponse(correlationId,
                (String) inputParameters.get(WebDevMaster.WEB_DEV_PARAMETERS_CHECKSUM_STR),
                (String) inputParameters.get(WebDevMaster.WEB_DEV_PARAMETERS_STR), request)) {

            LOG.error("attemptAuthentication() : Notification not approved");
            throw new UnauthorizedUserException(Constants.UNAUTHORIZED_ACCESS);
        }

        final UserDetails user = customUserDetailsService
                .loadUserByUsername((String) inputParameters.get(Constants.REQ_PARAM_USERNAME));
        authentication = new UsernamePasswordAuthenticationToken(user.getUsername(), null, user.getAuthorities());

        return authentication;
    }

    @Override
    public UserInfo getUserInfo(final String username) {

        LOG.info("getUserInfo() : Fetching user info for user : {} ", username);

        if (username == null) {
            LOG.error("getUserInfo() : Null username provided ");
            throw new IllegalArgumentException("Invalid username provided");
        }

        final UserAuthInfoVO userAuthInfoVo = userAuthInfoRepoImpl.fetchUserDetailsFromLoginId(username);

        if (userAuthInfoVo == null) {
            LOG.error("User not found in database : {} ", username);
            throw new UsernameNotFoundException("User not found.");
        }

        final UserInfo userInfo = new UserInfo();
        userInfo.setSub(userAuthInfoVo.getUserId());
        userInfo.setUserId(userAuthInfoVo.getUserId());
        userInfo.setFirstName(userAuthInfoVo.getFirstName());
        userInfo.setLastName(userAuthInfoVo.getLastName());
        userInfo.setMobileNumber(userAuthInfoVo.getMobileNumber());
        userInfo.setEmailId(userAuthInfoVo.getEmailId());

        return userInfo;
    }

    /**
     * Construct the discard notification request and publish request on the
     * REL-ID Verify.
     * 
     * @param inputParameters
     * @param username
     * @param webIdCheckSum
     * @param correlationId
     */
    // FIXME : Unused
    @Deprecated
    private void constructAndPublishDiscardNotificationRequest(final Map<String, Object> inputParameters,
            final String username, final String webIdCheckSum, final String correlationId) {

        final String clientId = (String) inputParameters.get(EnterpriseInfo.CLIENT_ID);

        final EnterpriseInfo clientDetails = (EnterpriseInfo) customClientDetailService.loadClientByClientId(clientId);
        final WebDevMaster webDevice = webDevMasterService.fetchWebDeviceMaster(webIdCheckSum);

        final ExpireNotificationRequest expireNotificationRequest = new ExpireNotificationRequest(username,
                webDevice.getWebDeviceUuid(), clientDetails.getMapped_appagent_uuid());

        verifyPublisher.sendDiscardRVNRequestToVerify(Constants.GSON.toJson(expireNotificationRequest), correlationId);
    }

    public void setUserDetailsService(final CustomUserDetailsService customUserDetailsService) {
        this.customUserDetailsService = customUserDetailsService;
    }

    @Override
    public boolean hasFidoDeviceRegistered(final String username) {
        return userAuthInfoRepoImpl.hasFidoDeviceRegistered(username);
    }

    @Override
    public Set<String> hasFidoDeviceRegisteredTransport(final String username) {
        return userAuthInfoRepoImpl.hasFidoDeviceRegisteredTransport(username);
    }

    // FIXME: Unused
    @Deprecated
    @Override
    public Authentication authenticateUserUsingFido(final HttpServletRequest request,
            final HttpServletResponse response, final Map<String, Object> inputParameters) {

        LOG.info("authenticateUserUsingFido() -> Entered.");

        Authentication authentication = null;
        try {

            // validating incoming request
            Utils.validateRequest(request, response, inputParameters);

            EventLogger.log(EventId.RelidAuthServer.INIT_VALIDATE_USER_REQ, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(),
                    request.getParameter(Constants.REQ_PARAM_USERNAME), "authenticating user through fido assertion");

            if (request.getParameter("assertion") == null) {
                LOG.error(
                        "authenticateUserUsingFido() -> Fido creds not found for user : {}, assertion is null or empty",
                        inputParameters.get(Constants.REQ_PARAM_USERNAME));
                throw new IllegalArgumentException("assertion is null or empty");
            }

            final String assertion = request.getParameter("assertion");
            final JsonNode params = Constants.JACKSON_OBJECT_MAPPER.readTree(assertion);
            final Object assertionResponseObject = assertionServiceVerifyMethod.invoke(assertionService, params);
            final JsonNode assertionResponse = Constants.JACKSON_OBJECT_MAPPER.convertValue(assertionResponseObject,
                    JsonNode.class);

            if (assertionResponse.hasNonNull("status") && assertionResponse.get("status").textValue().equals("ok")) {
                final UserDetails user = customUserDetailsService
                        .loadUserByUsername((String) inputParameters.get(Constants.REQ_PARAM_USERNAME));
                authentication = new UsernamePasswordAuthenticationToken(user.getUsername(), null,
                        user.getAuthorities());
            } else {
                LOG.error("authenticateUserUsingFido() -> Invalid fido creds provided by user : {} ",
                        inputParameters.get(Constants.REQ_PARAM_USERNAME));
                throw new AccessDeniedException(Constants.UNAUTHORIZED_ACCESS);
            }

        } catch (final JsonProcessingException | IllegalAccessException | IllegalArgumentException
                | InvocationTargetException | Fido2RPRuntimeException e) {
            LOG.error("authenticateUserUsingFido() -> Invalid fido creds provided by user : {} ",
                    inputParameters.get(Constants.REQ_PARAM_USERNAME), e);
            throw new AccessDeniedException(Constants.UNAUTHORIZED_ACCESS);
        }

        return authentication;
    }

    @SuppressWarnings("unchecked")
    @Override
    public Set<String> getUserAuthFactorsBasedOnUserValidity(final HttpServletRequest request,
            final HttpServletResponse response, final ValidateUserRequest validateUserRequest)
            throws NoSuchAlgorithmException {
        LOG.info("getUserAuthFactorsBasedOnUserValidity() -> Entered.");

        // Validating Request Parameters
        AuthenticationUtils.validateRequest(request, response, validateUserRequest);

        final Set<String> validatedAuthTypeSet = new LinkedHashSet<>();
        final Set<String> pendingAuthTypeSet = new LinkedHashSet<>();
        final Set<String> offeredAuthTypeSet = new LinkedHashSet<>();

        final HttpSession session = request.getSession();

        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = userAuthInfoRepoImpl
                .fetchUserAuthInfoRegAuthModuleFromLoginId(validateUserRequest.getUserName());

        if (userAuthInfoRegAuthModuleVo == null) {
            throw new InvalidUserException("Invalid User : User is not registered in the system");
        }

        boolean webOnlyUser = false;
        webOnlyUser = (userAuthInfoRegAuthModuleVo.isWebOnly() != null ? userAuthInfoRegAuthModuleVo.isWebOnly()
                : false);
        LOG.info("getUserAuthFactorsBasedOnUserValidity() -> Web Only user: {}", webOnlyUser);

        if (!CollectionUtils.isEmpty((Set<String>) session.getAttribute(SessionConstants.VALIDATED_AUTH_TYPES))) {
            validatedAuthTypeSet.addAll((Set<String>) session.getAttribute(SessionConstants.VALIDATED_AUTH_TYPES));
        }

        if (!CollectionUtils.isEmpty((Set<String>) session.getAttribute(SessionConstants.PENDING_AUTH_TYPES))) {
            pendingAuthTypeSet.addAll((Set<String>) session.getAttribute(SessionConstants.PENDING_AUTH_TYPES));
        }

        if (!CollectionUtils.isEmpty((Set<String>) session.getAttribute(SessionConstants.OFFERED_AUTH_TYPES))) {
            offeredAuthTypeSet.addAll((Set<String>) session.getAttribute(SessionConstants.OFFERED_AUTH_TYPES));
        }

        List<Integer> attemptsCounter = new ArrayList<>();
        final boolean isAllLevel1AuthTypesOffered = request.getSession()
                .getAttribute(SessionConstants.IS_ALL_LEVEL1_AUTH_TYPES_OFFERED) != null
                        ? (boolean) request.getSession().getAttribute(SessionConstants.IS_ALL_LEVEL1_AUTH_TYPES_OFFERED)
                        : false;

        /**
         * In case username is different than previous authentication level,
         * then reset the validatedAuthTypeSet, to prevent the sharing of auth
         * types for different user.
         **/
        if (StringUtils.isBlank(validateUserRequest.getAuthType())) {
            sessionService.resetAuthSessionParameters(request);
            session.setAttribute(SessionConstants.CURRENT_USERNAME, validateUserRequest.getUserName());
            pendingAuthTypeSet.clear();
            validatedAuthTypeSet.clear();

            // Reset the offeredAuth related params, if user initiating the
            // login flow or all Level 1 auth offered then user clicks on the
            // "Go Back" to re-initiate the flow
            final String offeredUsername = (String) session.getAttribute(SessionConstants.OFFERED_USERNAME);
            if (!StringUtils.equals(offeredUsername, validateUserRequest.getUserName())
                    || isAllLevel1AuthTypesOffered) {
                session.setAttribute(SessionConstants.OFFERED_USERNAME, validateUserRequest.getUserName());
                offeredAuthTypeSet.clear();
                session.setAttribute(SessionConstants.OFFERED_AUTH_TYPES, offeredAuthTypeSet);

                if (isAllLevel1AuthTypesOffered) {
                    request.getSession().setAttribute(SessionConstants.IS_ALL_LEVEL1_AUTH_TYPES_OFFERED, false);
                }
            }
        }

        if (pendingAuthTypeSet.isEmpty() && validateUserRequest.getAuthType() != null
                && validateUserRequest.getAuthType().equals(AuthType.PASS.getName())) {
            LOG.info("getUserAuthFactorsBasedOnUserValidity() -> pendingAuthTypeSet is empty. Auth type is pass");

            // validatedAuthTypeSet.add(validateUserRequest.getAuthType());

            attemptsCounter = getInitialAttemptCounter(
                    userAuthInfoRegAuthModuleVo.getWebUserDetails().getWebAttemptCounter());
            session.setAttribute(SessionConstants.CURRENT_USERNAME, validateUserRequest.getUserName());
            pendingAuthTypeSet.add(AuthType.PASS.getName());
            session.setAttribute(SessionConstants.AUTH_GENERATION_ATTEMPT_COUNTER,
                    PropertyConstants.DEFAULT_AUTH_GENERATION_ATTEMPT_COUNTER);
            session.setAttribute(SessionConstants.ATTEMPTS_COUNTER, attemptsCounter);

            // Reset the offeredAuth related params, if user initiating the
            // login flow through Password or all Level 1 auth offered then user
            // clicks on the "Go Back" to re-initiate the flow
            final String offeredUsername = (String) session.getAttribute(SessionConstants.OFFERED_USERNAME);
            if (!StringUtils.equals(offeredUsername, validateUserRequest.getUserName())
                    || isAllLevel1AuthTypesOffered) {
                session.setAttribute(SessionConstants.OFFERED_USERNAME, validateUserRequest.getUserName());
                offeredAuthTypeSet.clear();
                session.setAttribute(SessionConstants.OFFERED_AUTH_TYPES, offeredAuthTypeSet);

                if (isAllLevel1AuthTypesOffered) {
                    request.getSession().setAttribute(SessionConstants.IS_ALL_LEVEL1_AUTH_TYPES_OFFERED, false);
                }
            }

        }

        final String currentUserName = (String) session.getAttribute(SessionConstants.CURRENT_USERNAME);

        if (StringUtils.isNotBlank(currentUserName)
                && !StringUtils.equals(currentUserName, validateUserRequest.getUserName())) {
            LOG.error("Session Conflicted Between Session User:{} & Request User:{}", currentUserName,
                    validateUserRequest.getUserName());
            throw new SessionConflictedException(
                    "Session Conflicted Between Different Users, terminating the session for User: "
                            + validateUserRequest.getUserName());
        }

        /**
         * Validate user status, if user web status is blocked then calculate
         * the unblock time, if locking period is completed, then unblock the
         * user else discard the flow.
         **/
        validateUserStatus(userAuthInfoRegAuthModuleVo, request, validateUserRequest, webOnlyUser);

        Set<String> authTypes = null;

        final List<String> level1AllowedAuthType = Arrays.asList(AuthType.TOTP.getName());
        // We will support Password in Milestone 2.
        /* , AuthType.PASS.getName() */

        // Disable support of Platform Authenticator
        /*
         * final boolean isFidoPlatformRegistered =
         * checkForSecureCookieMappingWithPlatformAuth(request,
         * validateUserRequest);
         */

        if (!webOnlyUser && !StringUtils.equals(validateUserRequest.getAuthType(), AuthType.PASS.getName())
                && StringUtils.isBlank(validateUserRequest.getAuthValue())
        // Disable support of Platform Authenticator
        /*
         * && (!isFidoPlatformRegistered ||
         * offeredAuthTypeSet.contains(Constants.FIDO_DEVICE_TYPE_PLATFORM))
         */)
            checkForSecureCookieMappingWithUser(request, validateUserRequest, validatedAuthTypeSet, pendingAuthTypeSet);

        ValidateUserAuthDetails details = null;
        if (AuthType.isValidElement(validateUserRequest.getAuthType())
                && !CollectionUtils.isEmpty(pendingAuthTypeSet)) {
            if (!CollectionUtils.contains(pendingAuthTypeSet.iterator(), validateUserRequest.getAuthType())) {
                throw new IllegalArgumentException(SessionConstants.ERR_UNMATCHED_AUTH_TYPE_WITH_PENDING_AUTH_TYPE);
            }

            // Authenticate the auth value for specific auth type
            details = performAuthenticationByAuthType(request, response, validateUserRequest, validatedAuthTypeSet,
                    userAuthInfoRegAuthModuleVo);
        }

        if (details != null && !details.isAuthenticated()) {
            throw new ValidateUserException(SessionConstants.ERR_INVALID_AUTH_VALUE + details.getAuthType());
        }

        if (/* webOnlyUser && */StringUtils.equals(validateUserRequest.getAuthType(), AuthType.PASS.getName())
                && validatedAuthTypeSet.size() == 1 && validatedAuthTypeSet.contains(AuthType.PASS.getName())) {
            checkForSecureCookieMappingForWebOnlyUser(request, validateUserRequest, validatedAuthTypeSet,
                    pendingAuthTypeSet);
        }

        if (validatedAuthTypeSet.isEmpty()) {

            // Fetching Level 1 Auth Types
            authTypes = getAuthTypesForLevel1(validateUserRequest, level1AllowedAuthType, webOnlyUser, request);

            // Enabling attempts counter for Level 1 Authentication
            attemptsCounter = getInitialAttemptCounter(
                    userAuthInfoRegAuthModuleVo.getWebUserDetails().getWebAttemptCounter());

            // Commented for Handling the oldest default attempt counter should
            // get reseted by the latest one.
            // userAuthInfoRepoImpl.updateWebUserAttemptCounter(validateUserRequest.getUserName(),
            // attemptsCounter);

            // Storing current user in session
            session.setAttribute(SessionConstants.CURRENT_USERNAME, validateUserRequest.getUserName());

            // Enabling the Generation Attempt Counter
            session.setAttribute(SessionConstants.AUTH_GENERATION_ATTEMPT_COUNTER,
                    PropertyConstants.DEFAULT_AUTH_GENERATION_ATTEMPT_COUNTER);
            // updateWebUserAuthGenerationAttemptCounter(validateUserRequest.getUserName(),
            // PropertyConstants.DEFAULT_AUTH_GENERATION_ATTEMPT_COUNTER);

        } else {
            if (details != null
                    && StringUtils.equals(details.getAuthType().getName(), AuthType.SECURE_COOKIE.getName())) {
                // Enabling the Generation Attempt Counter
                session.setAttribute(SessionConstants.AUTH_GENERATION_ATTEMPT_COUNTER,
                        PropertyConstants.DEFAULT_AUTH_GENERATION_ATTEMPT_COUNTER);
                // updateWebUserAuthGenerationAttemptCounter(validateUserRequest.getUserName(),
                // PropertyConstants.DEFAULT_AUTH_GENERATION_ATTEMPT_COUNTER);

                // Enabling attempts counter for Level 2 Authentication
                attemptsCounter = getInitialAttemptCounter(
                        userAuthInfoRegAuthModuleVo.getWebUserDetails().getWebAttemptCounter());

                // Commented for Handling the oldest default attempt counter
                // should get resetted by the latest one.
                // userAuthInfoRepoImpl.updateWebUserAttemptCounter(validateUserRequest.getUserName(),
                // attemptsCounter);
            }
            // if
            // (!validatedAuthTypeSet.contains(AuthType.SECURE_COOKIE.getName()))
            // {
            authTypes = getAuthTypesForLevel2(request, validateUserRequest, details, validatedAuthTypeSet,
                    pendingAuthTypeSet, webOnlyUser);
            // }
        }

        session.setAttribute(SessionConstants.VALIDATED_AUTH_TYPES, validateAuthTypeNames(validatedAuthTypeSet));

        if (!CollectionUtils.isEmpty(attemptsCounter)) {
            session.setAttribute(SessionConstants.ATTEMPTS_COUNTER, attemptsCounter);
        }

        return authTypes;

    }

    /**
     * @param webAttemptCounterList
     * @return
     */
    private List<Integer> getInitialAttemptCounter(final List<Integer> webAttemptCounterList) {
        final List<Integer> attemptsCounter = new ArrayList<>();

        if (CollectionUtils.isEmpty(webAttemptCounterList)) {
            attemptsCounter.addAll(PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER);
        } else {
            final int level1DefaultAuthAttemptCounter = PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER
                    .get(Constants.LEVEL_1_AUTH_ATTEMPT_COUNTER_INDEX);
            final int level1PendingAuthAttemptCounter = webAttemptCounterList
                    .get(Constants.LEVEL_1_AUTH_ATTEMPT_COUNTER_INDEX);
            if (level1PendingAuthAttemptCounter < 1
                    || level1PendingAuthAttemptCounter > level1DefaultAuthAttemptCounter) {
                attemptsCounter.add(level1DefaultAuthAttemptCounter);
            } else {
                attemptsCounter.add(level1PendingAuthAttemptCounter);
            }

            final int level2DefaultAuthAttemptCounter = PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER
                    .get(Constants.LEVEL_2_AUTH_ATTEMPT_COUNTER_INDEX);
            final int level2PendingAuthAttemptCounter = webAttemptCounterList
                    .get(Constants.LEVEL_2_AUTH_ATTEMPT_COUNTER_INDEX);
            if (level2PendingAuthAttemptCounter < 1
                    || level2PendingAuthAttemptCounter > level2DefaultAuthAttemptCounter) {
                attemptsCounter.add(level2DefaultAuthAttemptCounter);
            } else {
                attemptsCounter.add(level2PendingAuthAttemptCounter);
            }
        }

        LOG.info("getInitialAttemptCounter() : Initial Attempt Counter={}", attemptsCounter);
        return attemptsCounter;
    }

    /**
     * This method will identify whether user can bypass the first level of
     * authentication or not, based on the secure cookie is present for that
     * specific user.
     * 
     * @param request
     * @param validateUserRequest
     * @return
     */
    public boolean checkForSecureCookieMappingWithUser(final HttpServletRequest request,
            final ValidateUserRequest validateUserRequest, final Set<String> validatedAuthTypeSet,
            final Set<String> pendingAuthTypeSet) {
        LOG.info("checkForSecureCookieMappingWithUser() -> Entered.");

        boolean shouldFollow = true;

        if (!PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isRememberMe()) {
            return shouldFollow;
        }

        WebDevMaster webDevMaster = null;

        if (request.getCookies() == null) {
            return shouldFollow;
        }
        final Optional<Cookie> optionalCookie = Arrays.stream(request.getCookies())
                .filter(ck -> StringUtils.equals(Constants.SECURE_COOKIE_NAME, ck.getName())).findFirst();

        final HttpSession session = request.getSession();

        Cookie secureCookie = null;
        if (optionalCookie.isPresent() && validatedAuthTypeSet.isEmpty()
                && !secureCookieService.isSecureCookieExpired(request)) {
            secureCookie = optionalCookie.get();
            webDevMaster = webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(secureCookie.getValue());

            if (webDevMaster != null) {
                final String webDeviceUuid = webDevMaster.getWebDeviceUuid();

                final UserAuthInfoVO userAuthInfo = userAuthInfoRepoImpl
                        .fetchUserDetailsFromLoginId(validateUserRequest.getUserName());

                if (userAuthInfo == null)
                    throw new InvalidUserException("Invalid User : User is not registered in the system");

                final Optional<UserBrowser> optionalBrowser = userAuthInfo.getWebUserDetails().getBrowsers().stream()
                        .filter(browser -> StringUtils.equals(webDeviceUuid, browser.getWebDeviceUuid())).findFirst();

                if (optionalBrowser.isPresent()) {
                    shouldFollow = false;

                    if (!InputValidationUtils.isValidAuthTypeName(AuthType.SECURE_COOKIE.getName())) {
                        throw new ValidateUserException("Auth Type Name Is Not Valid");
                    }

                    try {
                        ESAPI.validator().getValidInput("secure_cookie_name", AuthType.SECURE_COOKIE.getName(),
                                "HTTPCookieValue", Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
                    } catch (final Exception e) {
                        throw new IllegalArgumentException("Request Has Invalid Secure Cookie." + e.getMessage());
                    }
                    validatedAuthTypeSet.add(AuthType.SECURE_COOKIE.getName());
                    session.setAttribute(SessionConstants.VALIDATED_AUTH_TYPES,
                            validateAuthTypeNames(validatedAuthTypeSet));

                    pendingAuthTypeSet.add(AuthType.SECURE_COOKIE.getName());
                    session.setAttribute(SessionConstants.PENDING_AUTH_TYPES,
                            validateAuthTypeNames(pendingAuthTypeSet));

                    validateUserRequest.setAuthType(AuthType.SECURE_COOKIE.getName());
                }
            } else {
                throw new InvalidSecureCookieException("Request Has Invalid Secure Cookie.");
            }
        }

        return shouldFollow;
    }

    public boolean checkForSecureCookieMappingForWebOnlyUser(final HttpServletRequest request,
            final ValidateUserRequest validateUserRequest, final Set<String> validatedAuthTypeSet,
            final Set<String> pendingAuthTypeSet) {
        LOG.info("checkForSecureCookieMappingForWebOnlyUser() -> Entered.");

        boolean shouldFollow = true;

        /*
         * if
         * (!PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isRememberMe()
         * || (validateUserRequest.getAuthType() != null &&
         * validateUserRequest.getAuthType().equals("pass"))) { return
         * shouldFollow; }
         */

        if (!PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isRememberMe()) {
            return shouldFollow;
        }
        WebDevMaster webDevMaster = null;

        if (request.getCookies() == null) {
            return shouldFollow;
        }
        final Optional<Cookie> optionalCookie = Arrays.stream(request.getCookies())
                .filter(ck -> StringUtils.equals(Constants.SECURE_COOKIE_NAME, ck.getName())).findFirst();

        final HttpSession session = request.getSession();

        Cookie secureCookie = null;
        if (optionalCookie.isPresent() && !secureCookieService.isSecureCookieExpired(request)) {
            secureCookie = optionalCookie.get();
            webDevMaster = webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(secureCookie.getValue());

            if (webDevMaster != null) {
                final String webDeviceUuid = webDevMaster.getWebDeviceUuid();

                final UserAuthInfoVO userAuthInfo = userAuthInfoRepoImpl
                        .fetchUserDetailsFromLoginId(validateUserRequest.getUserName());

                if (userAuthInfo == null)
                    throw new InvalidUserException("Invalid User : User is not registered in the system");

                final Optional<UserBrowser> optionalBrowser = userAuthInfo.getWebUserDetails().getBrowsers().stream()
                        .filter(browser -> StringUtils.equals(webDeviceUuid, browser.getWebDeviceUuid())).findFirst();

                if (optionalBrowser.isPresent()) {
                    shouldFollow = false;

                    if (!InputValidationUtils.isValidAuthTypeName(AuthType.SECURE_COOKIE.getName())) {
                        throw new ValidateUserException("Auth Type Name Is Not Valid");
                    }

                    try {
                        ESAPI.validator().getValidInput("secure_cookie_name", AuthType.SECURE_COOKIE.getName(),
                                "HTTPCookieValue", Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
                    } catch (final Exception e) {
                        throw new IllegalArgumentException("Request Has Invalid Secure Cookie." + e.getMessage());
                    }
                    validatedAuthTypeSet.add(AuthType.SECURE_COOKIE.getName());
                    session.setAttribute(SessionConstants.VALIDATED_AUTH_TYPES,
                            validateAuthTypeNames(validatedAuthTypeSet));

                    pendingAuthTypeSet.add(AuthType.SECURE_COOKIE.getName());
                    session.setAttribute(SessionConstants.PENDING_AUTH_TYPES,
                            validateAuthTypeNames(pendingAuthTypeSet));

                    // validateUserRequest.setAuthType(AuthType.SECURE_COOKIE.getName());
                }
            } else {
                throw new InvalidSecureCookieException("Request Has Invalid Secure Cookie.");
            }
        }

        return shouldFollow;
    }

    private Set<String> validateAuthTypeNames(final Set<String> authTypeNames) {
        final Set<String> ret = new LinkedHashSet<>();
        final Iterator<String> value = authTypeNames.iterator();
        while (value.hasNext()) {
            final String inputValue = value.next();
            final String canonical = ESAPI.encoder().canonicalize(inputValue).trim();
            if (!ESAPI.validator().isValidInput("Validating auth names", canonical, "AuthTypeNames",
                    Constants.MAX_SIZE_AUTHTYPE_NAME, false)) {
                LOG.error("AuthType: {} is invalid, so was not added to the list of auth type for this Rule.",
                        canonical);
            } else {
                if (AuthType.isValidElement(canonical)) {
                    ret.add(canonical.trim());
                }
            }
        }
        return ret;
    }

    @Override
    public boolean deleteBrowserMappingForUser(final HttpServletRequest request,
            final ValidateUserRequest validateUserRequest) {

        LOG.info("deleteBrowserMappingForUser() -> Entered.");
        WebDevMaster webDevMaster = null;
        boolean isDeleted = false;

        if (request.getCookies() == null) {
            return isDeleted;
        }

        final Optional<Cookie> optionalCookie = Arrays.stream(request.getCookies())
                .filter(ck -> StringUtils.equals(Constants.SECURE_COOKIE_NAME, ck.getName())).findFirst();

        Cookie secureCookie = null;
        if (optionalCookie.isPresent() && !secureCookieService.isSecureCookieExpired(request)) {
            secureCookie = optionalCookie.get();
            webDevMaster = webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(secureCookie.getValue());

            if (webDevMaster != null) {
                final String webDeviceUuid = webDevMaster.getWebDeviceUuid();

                final UserAuthInfoVO userAuthInfo = userAuthInfoRepoImpl
                        .fetchUserDetailsFromLoginId(validateUserRequest.getUserName());

                if (userAuthInfo == null)
                    throw new InvalidUserException("Invalid User : User is not registered in the system");

                WebUserDetails webUserDetails = userAuthInfo.getWebUserDetails();

                if (webUserDetails == null) {
                    webUserDetails = new WebUserDetails();
                }

                deleteWebUserBrowser(validateUserRequest.getUserName(), webDeviceUuid);

                isDeleted = true;
            }
        }

        return isDeleted;
    }

    /**
     * @param validateUserRequest
     * @param allowedAuthType
     * @return
     * @throws NoSuchAlgorithmException
     */
    @SuppressWarnings({ "unchecked" })
    public Set<String> getAuthTypesForLevel1(final ValidateUserRequest validateUserRequest,
            final List<String> allowedAuthType, final boolean webOnlyUser, final HttpServletRequest request)
            throws NoSuchAlgorithmException {

        LOG.info("getAuthTypesForLevel1() -> Entered.");

        final Set<String> nextSetAuthTypes = new LinkedHashSet<>();
        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = userAuthInfoRepoImpl
                .fetchUserAuthInfoRegAuthModuleFromLoginId(validateUserRequest.getUserName());

        if (userAuthInfoRegAuthModuleVo != null) {
            Set<AuthType> registeredAuthTypes = new LinkedHashSet<>();

            if (userAuthInfoRegAuthModuleVo.getRegAuthTypes() != null) {
                registeredAuthTypes = userAuthInfoRegAuthModuleVo.getRegAuthTypes();
            }

            final List<RegisteredAuthenticationModule> moduleList = userAuthInfoRegAuthModuleVo.getRegAuthModule();
            boolean isFiDO2FARoaming = false;
            boolean isFiDO1FARoaming = false;
            final boolean isBrowserRememberedByUser = isBrowserRememberedByUser(request,
                    validateUserRequest.getUserName());
            final boolean isUserRegisteredWithPassword = registeredAuthTypes.contains(AuthType.PASS);
            Set<String> offeredAuthTypeSet = (Set<String>) request.getSession()
                    .getAttribute(SessionConstants.OFFERED_AUTH_TYPES);
            if (offeredAuthTypeSet == null) {
                offeredAuthTypeSet = Sets.newHashSet();
            }

            boolean isPassAllowedForWebOnlyUser = false;

            if (registeredAuthTypes.contains(AuthType.FIDO)
                    && AuthenticationUtils.isAuthTypeAllowed(AuthType.FIDO.getName())
                    && !CollectionUtils.isEmpty(moduleList)) {
                final List<FIDO2RegisteredAuthenticationModule> fido2moduleList = fetchRegisteredAuthenticationModuleFromLoginId(
                        validateUserRequest.getUserName());

                isFiDO2FARoaming = fido2moduleList.stream().anyMatch(f -> f.getAuthType().equals(AuthType.FIDO)
                        && f.getAuthTypeStatus().equals(AuthTypeStatus.REGISTERED)
                        && !f.getTransport().equals(Constants.FIDO_PLATFORM_TRANSPORT_TYPE) && FidoUtils
                                .is2FaAuthenticator(f.getAuthenticatorAttestationResponse().getAttestationObject()));

                isFiDO1FARoaming = fido2moduleList.stream().anyMatch(f -> f.getAuthType().equals(AuthType.FIDO)
                        && f.getAuthTypeStatus().equals(AuthTypeStatus.REGISTERED)
                        && !f.getTransport().equals(Constants.FIDO_PLATFORM_TRANSPORT_TYPE) && !FidoUtils
                                .is2FaAuthenticator(f.getAuthenticatorAttestationResponse().getAttestationObject()));
            }

            isPassAllowedForWebOnlyUser = webOnlyUser && registeredAuthTypes.contains(AuthType.PASS)
                    && !offeredAuthTypeSet.contains(AuthType.PASS.getName())
                    && isPassAllowedForWebOnlyUser(registeredAuthTypes, isFiDO1FARoaming, isFiDO2FARoaming);

            try {

                // FIDO Platform Authenticator,
                // if registered & tied with secure cookie

                // Disable support of Platform Authenticator
                /*
                 * if (checkForSecureCookieMappingWithPlatformAuth(request,
                 * validateUserRequest) &&
                 * !offeredAuthTypeSet.contains(Constants.
                 * FIDO_DEVICE_TYPE_PLATFORM)) {
                 * nextSetAuthTypes.add(AuthType.FIDO.getName());
                 * offeredAuthTypeSet.add(Constants.FIDO_DEVICE_TYPE_PLATFORM);
                 * return nextSetAuthTypes; }
                 */

                if (webOnlyUser) {
                    if ((!isBrowserRememberedByUser || !isUserRegisteredWithPassword) && isFiDO2FARoaming
                            && !offeredAuthTypeSet.contains(Constants.FIDO_DEVICE_TYPE_2FAROAMING)) {
                        nextSetAuthTypes.add(AuthType.FIDO.getName());
                        offeredAuthTypeSet.add(Constants.FIDO_DEVICE_TYPE_2FAROAMING);
                        return nextSetAuthTypes;
                    }

                    if (isPassAllowedForWebOnlyUser) {
                        nextSetAuthTypes.add(AuthType.PASS.getName());
                        offeredAuthTypeSet.add(AuthType.PASS.getName());
                        return nextSetAuthTypes;
                    }
                } else {
                    if (!isBrowserRememberedByUser) {
                        if (isFiDO2FARoaming && !offeredAuthTypeSet.contains(Constants.FIDO_DEVICE_TYPE_2FAROAMING)) {
                            nextSetAuthTypes.add(AuthType.FIDO.getName());
                            offeredAuthTypeSet.add(Constants.FIDO_DEVICE_TYPE_2FAROAMING);
                            return nextSetAuthTypes;
                        }

                        if (registeredAuthTypes.contains(AuthType.PASS)
                                && !offeredAuthTypeSet.contains(AuthType.PASS.getName())) {
                            nextSetAuthTypes.add(AuthType.PASS.getName());
                            offeredAuthTypeSet.add(AuthType.PASS.getName());
                            return nextSetAuthTypes;
                        } else if (!offeredAuthTypeSet.contains(AuthType.TOTP.getName())) {
                            nextSetAuthTypes.add(AuthType.TOTP.getName());
                            offeredAuthTypeSet.add(AuthType.TOTP.getName());
                            return nextSetAuthTypes;
                        }
                    }
                }
            } finally {
                request.getSession().setAttribute(SessionConstants.OFFERED_AUTH_TYPES, offeredAuthTypeSet);

                final Set<AuthType> offeredAuthTypes = Sets.newHashSet();
                final Set<AuthType> availableRegisteredAuthTypes = Sets.newHashSet(registeredAuthTypes);
                boolean isLevel1FidoAuthAvailable = false;

                for (final String auth : offeredAuthTypeSet) {
                    if (auth.startsWith("FIDO")) {
                        offeredAuthTypes.add(AuthType.FIDO);
                        isLevel1FidoAuthAvailable = true;
                    } else {
                        offeredAuthTypes.add(AuthType.getAuthTypeByName(auth));
                    }
                }

                if (!webOnlyUser && !isUserRegisteredWithPassword) {
                    // Adding default Level 1 Auth Factors
                    // for Level 1 Auth Validation
                    availableRegisteredAuthTypes.add(AuthType.TOTP);
                }

                // Removing Level 2 Auth Factors
                // For Level 1 Auth Validation
                availableRegisteredAuthTypes.remove(AuthType.SMSOTP);
                availableRegisteredAuthTypes.remove(AuthType.EMAILOTP);

                // For Level 1, FIDO Platform Auth or Roaming 2FA can be
                // available for authentication,
                // if not then remove it from available set.
                if (!isLevel1FidoAuthAvailable) {
                    availableRegisteredAuthTypes.remove(AuthType.FIDO);
                }

                if (isAllLevel1AuthTypesOffered(registeredAuthTypes, isFiDO2FARoaming, offeredAuthTypeSet,
                        offeredAuthTypes, availableRegisteredAuthTypes, webOnlyUser, isPassAllowedForWebOnlyUser)) {
                    request.getSession().setAttribute(SessionConstants.IS_ALL_LEVEL1_AUTH_TYPES_OFFERED, true);
                } else {
                    request.getSession().setAttribute(SessionConstants.IS_ALL_LEVEL1_AUTH_TYPES_OFFERED, false);
                }

                LOG.info("attemptAuthentication() : Level 1 Offered Auth Types to {} user: {}",
                        validateUserRequest.getUserName(), offeredAuthTypeSet);
            }

        } else {
            throw new ValidateUserException("Invalid User");
        }

        // FIXME : Will Use This Flow in Milestone 2.
        /*
         * final Random random = SecureRandom.getInstanceStrong(); final
         * UserAuthInfoVO user =
         * userAuthInfoRepoImpl.fetchUserDetailsFromLoginId(validateUserRequest.
         * getUserName()); if (user == null) { final int index =
         * random.nextInt(allowedAuthType.size());
         * authTypes.add(allowedAuthType.get(index)); } else if
         * (user.getUserStatus() != RelIdUserStatus.ACTIVE ||
         * user.getRelIds().stream().filter(relid ->
         * relid.getRelIdStatus().equals(RelIdUserStatus.ACTIVE))
         * .collect(Collectors.toList()).isEmpty()) { // FIXME : We will support
         * Password in Milestone 2. authTypes.add(AuthType.PASS.getName());
         * authTypes.add(AuthType.TOTP.getName()); } else {
         * authTypes.add(AuthType.TOTP.getName()); }
         */

        return nextSetAuthTypes;

    }

    public boolean isAllLevel1AuthTypesOffered(final Set<AuthType> registeredAuthTypes, final boolean isFiDO2FARoaming,
            final Set<String> offeredAuthTypeSet, final Set<AuthType> offeredAuthTypes,
            final Set<AuthType> availableRegisteredAuthTypes, final boolean webOnlyUser,
            final boolean isPassAllowedForWebOnlyUser) {

        // Disable support of Platform Authenticator
        // TODO: Platform auth should fallback to 2FA, if cancelled
        /*
         * if ((registeredAuthTypes.size() == 1 && isFiDO2FARoaming &&
         * offeredAuthTypeSet.containsAll(
         * Sets.newHashSet(Constants.FIDO_DEVICE_TYPE_PLATFORM,
         * Constants.FIDO_DEVICE_TYPE_2FAROAMING)))) { return true; }
         */

        if (offeredAuthTypes.containsAll(availableRegisteredAuthTypes)) {
            return true;
        }

        if (webOnlyUser && !isPassAllowedForWebOnlyUser) {
            return true;
        }

        // Disable support of Platform Authenticator
        // Old Handling
        /*
         * if ((registeredAuthTypes.size() == 1 && isFiDO2FARoaming &&
         * offeredAuthTypeSet.containsAll(Sets.newHashSet(Constants.
         * FIDO_DEVICE_TYPE_PLATFORM, Constants.FIDO_DEVICE_TYPE_2FAROAMING)))
         * || offeredAuthTypes.containsAll(availableRegisteredAuthTypes) ||
         * (webOnlyUser && !isPassAllowedForWebOnlyUser)) {
         * request.getSession().setAttribute(SessionConstants.
         * IS_ALL_LEVEL1_AUTH_TYPES_OFFERED, true); } else {
         * request.getSession().setAttribute(SessionConstants.
         * IS_ALL_LEVEL1_AUTH_TYPES_OFFERED, false); }
         */

        return false;

    }

    public boolean isPassAllowedForWebOnlyUser(final Set<AuthType> registeredAuthTypes, final boolean isFiDO1FARoaming,
            final boolean isFiDO2FARoaming) {
        if (registeredAuthTypes.size() > 2 || isFiDO1FARoaming
                || (isFiDO2FARoaming && PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isAlwaysAskForPassword())
                || CollectionUtils.containsAny(registeredAuthTypes,
                        Sets.newHashSet(AuthType.SMSOTP, AuthType.EMAILOTP))) {
            return true;
        }
        return false;
    }

    /**
     * @param request
     * @param response
     * @param validateUserRequest
     * @param authType
     * @return
     */
    public Set<String> getAuthTypesForLevel2(final HttpServletRequest request,
            final ValidateUserRequest validateUserRequest, final ValidateUserAuthDetails details,
            final Set<String> validatedAuthTypeSet, final Set<String> pendingAuthTypesList, final boolean webOnlyUser) {
        LOG.info("getAuthTypesForLevel2() -> Entered.");

        final Set<String> authTypes = new LinkedHashSet<>();

        // Here we are sending the list of authTypes based on priority.
        authTypes.addAll(getNextSetAuthTypesBasedOnPriority(request, validateUserRequest.getUserName(), webOnlyUser));

        // if (webOnlyUser &&
        // !validatedAuthTypeSet.contains(AuthType.SECURE_COOKIE.getName())) {
        // authTypes.remove(AuthType.RELID_VERIFY.getName());
        // }

        return authTypes;
    }

    @Override
    public Authentication generateAuthenticationTokenForUser(final String username) {
        LOG.info("generateAuthenticationTokenForUser() -> Entered.");
        final UserDetails user = customUserDetailsService.loadUserByUsername(username);
        return new UsernamePasswordAuthenticationToken(user.getUsername(), null, user.getAuthorities());
    }

    /**
     * @param request
     * @param response
     * @param validateUserRequest
     * @param validatedAuthTypeSet
     * @return
     */
    @SuppressWarnings("unchecked")
    private ValidateUserAuthDetails performAuthenticationByAuthType(final HttpServletRequest request,
            final HttpServletResponse response, final ValidateUserRequest validateUserRequest,
            final Set<String> validatedAuthTypeSet, final UserAuthInfoVO userAuthInfo) {

        LOG.info("performAuthenticationByAuthType() -> Performing Authentication for Auth Type : {}",
                validateUserRequest.getAuthType());

        final String authType = validateUserRequest.getAuthType();
        LOG.debug("performAuthenticationByAuthType() -> authType:{}", authType);

        EventLogger.log(EventId.RelidAuthServer.AUTHENTICATION_STARTED, Utils.getClientIpAddress(request),
                AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                AuthenticationUtils.getUserAgent(request), "Performing Authentication For " + authType);

        ValidateUserAuthDetails details = null;

        if (AuthType.PASS.getName().equals(authType)) {
            /*
             * details = new ValidateUserAuthDetails(AuthType.PASS,
             * authenticationService.validateUserByPassword(request, response,
             * validateUserRequest));
             */
            details = new ValidateUserAuthDetails(AuthType.PASS, true);
        } else if (AuthType.RELID_VERIFY.getName().equals(authType)) {
            /*
             * details = new ValidateUserAuthDetails(AuthType.RELID_VERIFY,
             * authenticationService.checkUserActionOnNotification(request,
             * response, validateUserRequest));
             */
            details = new ValidateUserAuthDetails(AuthType.RELID_VERIFY, true);
        } else if (AuthType.TOTP.getName().equals(authType)) {
            /*
             * details = new ValidateUserAuthDetails(AuthType.TOTP,
             * authenticationService.validateUserByTOTP(request, response,
             * validateUserRequest));
             */
            details = new ValidateUserAuthDetails(AuthType.TOTP, true);
        } else if (AuthType.FIDO.getName().equals(authType)) {

            details = new ValidateUserAuthDetails(AuthType.FIDO,
                    authenticationService.authenticateUserUsingFido(request, response, validateUserRequest));

            // details = new ValidateUserAuthDetails(AuthType.FIDO, true);
        } else if (AuthType.SMSOTP.getName().equals(authType)) {
            try {

                /*
                 * details = new ValidateUserAuthDetails(AuthType.SMSOTP,
                 * authenticationService.validateUserBySMSOTP(request, response,
                 * validateUserRequest));
                 */
                details = new ValidateUserAuthDetails(AuthType.SMSOTP, true);
            } catch (final RelIDNotificationAcceptedException e) {
                // REL-ID Notification is already accepted,
                // hence no need to do SMS OTP Authentication.
                details = new ValidateUserAuthDetails(AuthType.RELID_VERIFY, true);
            }
        } else if (AuthType.EMAILOTP.getName().equals(authType)) {
            try {
                /*
                 * details = new ValidateUserAuthDetails(AuthType.EMAILOTP,
                 * authenticationService.validateUserByEmailOTP(request,
                 * response, validateUserRequest));
                 */
                details = new ValidateUserAuthDetails(AuthType.EMAILOTP, true);
            } catch (final RelIDNotificationAcceptedException e) {
                // REL-ID Notification is already accepted,
                // hence no need to do Email OTP Authentication.
                details = new ValidateUserAuthDetails(AuthType.RELID_VERIFY, true);
            }
        } else if (AuthType.SECURE_COOKIE.getName().equals(authType)) {
            details = new ValidateUserAuthDetails(AuthType.SECURE_COOKIE, true);
        } else {
            LOG.error("performAuthenticationByAuthType() : Invalid auth type provided");
            throw new IllegalArgumentException(SessionConstants.ERR_UNSUPPORTED_AUTH_TYPE);
        }

        if (details.isAuthenticated()) {
            validatedAuthTypeSet.add(details.getAuthType().getName());
        } else {
            final List<Integer> attemptsList = (List<Integer>) request.getSession()
                    .getAttribute(SessionConstants.ATTEMPTS_COUNTER);

            List<Integer> attemptsCounter = null;
            if (CollectionUtils.isEmpty(attemptsList)) {
                attemptsCounter = new ArrayList<>(PropertyConstants.DEFAULT_AUTH_LEVEL_ATTEMPT_COUNTER);
            } else {
                attemptsCounter = new ArrayList<>(attemptsList);
            }

            int authAttemptCounterIndex;
            if (validatedAuthTypeSet.isEmpty() || details.getAuthType().equals(AuthType.PASS)) {
                authAttemptCounterIndex = Constants.LEVEL_1_AUTH_ATTEMPT_COUNTER_INDEX;
            } else {
                authAttemptCounterIndex = Constants.LEVEL_2_AUTH_ATTEMPT_COUNTER_INDEX;
            }

            final int currentCount = attemptsCounter.get(authAttemptCounterIndex);
            if (currentCount > 1) {
                final int decrementedCounter = currentCount - 1;
                attemptsCounter.set(authAttemptCounterIndex, decrementedCounter);

                // Updating Attempt Counters
                userAuthInfoRepoImpl.updateWebUserAttemptCounter(validateUserRequest.getUserName(), attemptsCounter);
                request.getSession().setAttribute(SessionConstants.ATTEMPTS_COUNTER, attemptsCounter);

                EventLogger.log(EventId.RelidAuthServer.DECREMENT_ATTMEPT_COUNTER, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request),
                        "Attempt Counter Decremented For " + details.getAuthType().getName()
                                + " & current attempt counter is " + decrementedCounter);
            } else {
                attemptsCounter.set(authAttemptCounterIndex, 0);
                // Block the User for Specific Period
                final WebUserDetails webUserDetails = userAuthInfo.getWebUserDetails();
                webUserDetails.setBlockedTs(new Date());
                webUserDetails.setLastBlockedInterval(
                        AuthenticationUtils.getNextBlockingInterval(webUserDetails.getLastBlockedInterval()));
                webUserDetails.setLastBlockedMethod(details.getAuthType().getName());
                webUserDetails.setWebUserStatus(WebUserStatus.BLOCKED);

                // Updating Attempt Counters
                webUserDetails.setWebAttemptCounter(attemptsCounter);
                request.getSession().setAttribute(SessionConstants.ATTEMPTS_COUNTER, attemptsCounter);

                userAuthInfoRepoImpl.blockWebUser(webUserDetails, userAuthInfo.getUserId());
                EventLogger.log(EventId.RelidAuthServer.EXHAUSTED_ATTMEPT_COUNTER, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request),
                        "Attempt Counter Exhausted For " + details.getAuthType().getName());
                throw new AttemptCounterExceededException(
                        "Level " + (authAttemptCounterIndex + 1) + " Authentication Attempt Count Exceeded.");
            }

            EventLogger.log(EventId.RelidAuthServer.AUTHENTICATION_FAILED, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request),
                    "Authentication Failed For " + details.getAuthType().getName());
            throw new ValidateUserException(prepareAuthMessages(details.getAuthType()));
        }

        return details;
    }

    private String prepareAuthMessages(final AuthType authType) {
        String msg = "";

        switch (authType) {
        case TOTP:
            msg = PropertyConstants.MFA_USER_DISPLAY_MESSAGES.get(MessageConstants.KEY_MSG_ERROR_INCORRECT_TOTP);
            break;

        case RELID_VERIFY:
            msg = SessionConstants.ERR_INVALID_AUTH_VALUE + authType.getName();
            break;

        case FIDO:
            msg = SessionConstants.ERR_INVALID_AUTH_VALUE + authType.getName();
            break;

        case SMSOTP:
            msg = PropertyConstants.MFA_USER_DISPLAY_MESSAGES.get(MessageConstants.KEY_MSG_ERROR_INCORRECT_SMSOTP);
            break;

        case PASS:
            msg = PropertyConstants.MFA_USER_DISPLAY_MESSAGES.get(MessageConstants.KEY_MSG_ERROR_INCORRECT_PASS);
            break;

        case EMAILOTP:
            msg = PropertyConstants.MFA_USER_DISPLAY_MESSAGES.get(MessageConstants.KEY_MSG_ERROR_INCORRECT_EMAILOTP);
            break;

        case SECURE_COOKIE:
            msg = SessionConstants.ERR_INVALID_AUTH_VALUE + authType.getName();
            break;

        default:
            throw new IllegalArgumentException("Invalid Auth Type Provided");
        }

        return msg;
    }

    /**
     * @param request
     * @param username
     * @param webOnlyUser
     * @return
     */
    @SuppressWarnings("unchecked")
    private Set<String> getNextSetAuthTypesBasedOnPriority(final HttpServletRequest request, final String username,
            final boolean webOnlyUser) {

        LOG.info("getNextSetAuthTypesBasedOnPriority()-> username: {}", username);

        final Set<String> nextSetAuthTypes = new LinkedHashSet<>();
        final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = userAuthInfoRepoImpl
                .fetchUserAuthInfoRegAuthModuleFromLoginId(username);

        Set<String> offeredAuthTypeSet = (Set<String>) request.getSession()
                .getAttribute(SessionConstants.OFFERED_AUTH_TYPES);
        if (offeredAuthTypeSet == null) {
            offeredAuthTypeSet = Sets.newHashSet();
        }

        if (userAuthInfoRegAuthModuleVo != null) {
            Set<AuthType> registeredAuthTypes = new LinkedHashSet<>();

            if (userAuthInfoRegAuthModuleVo.getRegAuthTypes() != null) {
                registeredAuthTypes = userAuthInfoRegAuthModuleVo.getRegAuthTypes();
            }

            final List<RegisteredAuthenticationModule> moduleList = userAuthInfoRegAuthModuleVo.getRegAuthModule();

            // Disable support of Platform Authenticator
            // boolean isFiDOPlatform = false;

            boolean isFiDO1FARoaming = false;
            boolean isFiDO2FARoaming = false;

            if (registeredAuthTypes.contains(AuthType.FIDO)
                    && AuthenticationUtils.isAuthTypeAllowed(AuthType.FIDO.getName())
                    && !CollectionUtils.isEmpty(moduleList)) {
                final List<FIDO2RegisteredAuthenticationModule> fido2moduleList = fetchRegisteredAuthenticationModuleFromLoginId(
                        username);

                // Disable support of Platform Authenticator
                /*
                 * isFiDOPlatform = fido2moduleList.stream() .anyMatch(f ->
                 * f.getAuthType().equals(AuthType.FIDO) &&
                 * f.getAuthTypeStatus().equals(AuthTypeStatus.REGISTERED) &&
                 * f.getTransport().equals(Constants.
                 * FIDO_PLATFORM_TRANSPORT_TYPE));
                 */

                isFiDO1FARoaming = fido2moduleList.stream().anyMatch(f -> f.getAuthType().equals(AuthType.FIDO)
                        && f.getAuthTypeStatus().equals(AuthTypeStatus.REGISTERED)
                        && !f.getTransport().equals(Constants.FIDO_PLATFORM_TRANSPORT_TYPE) && !FidoUtils
                                .is2FaAuthenticator(f.getAuthenticatorAttestationResponse().getAttestationObject()));
                isFiDO2FARoaming = fido2moduleList.stream().anyMatch(f -> f.getAuthType().equals(AuthType.FIDO)
                        && f.getAuthTypeStatus().equals(AuthTypeStatus.REGISTERED)
                        && !f.getTransport().equals(Constants.FIDO_PLATFORM_TRANSPORT_TYPE) && FidoUtils
                                .is2FaAuthenticator(f.getAuthenticatorAttestationResponse().getAttestationObject()));
            }

            if (webOnlyUser) {

                if (isFiDO2FARoaming && PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isAlwaysAskForPassword()) {
                    nextSetAuthTypes.add(AuthType.FIDO.getName());
                    offeredAuthTypeSet.add(Constants.FIDO_DEVICE_TYPE_2FAROAMING);
                }

                if (isFiDO1FARoaming) {
                    nextSetAuthTypes.add(AuthType.FIDO.getName());
                    offeredAuthTypeSet.add(Constants.FIDO_DEVICE_TYPE_1FAROAMING);
                }

            } else {

                // Disable support of Platform Authenticator
                /*
                 * if (isFiDOPlatform &&
                 * PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.
                 * isAlwaysAskForPassword()) { // Tie Secure cookie to FIDO
                 * platform // Change authentication flow to consider FIDO
                 * platform // authenticator only when the user is trying to //
                 * authenticate using a remembered browser (secure cookie is //
                 * present) and it has a authenticator_uuid mapped. final
                 * UserBrowser ub =
                 * secureCookieService.getAssociatedUserBrowserBySecureCookie(
                 * request, username); if (ub != null &&
                 * ub.getAuthenticatorUuid() != null) {
                 * nextSetAuthTypes.add(AuthType.FIDO.getName());
                 * offeredAuthTypeSet.add(Constants.FIDO_DEVICE_TYPE_PLATFORM);
                 * } }
                 */

                // RELID-Verify Always available
                nextSetAuthTypes.add(AuthType.RELID_VERIFY.getName());
                offeredAuthTypeSet.add(AuthType.RELID_VERIFY.getName());

                if (isFiDO2FARoaming && PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isAlwaysAskForPassword()) {
                    nextSetAuthTypes.add(AuthType.FIDO.getName());
                    offeredAuthTypeSet.add(Constants.FIDO_DEVICE_TYPE_2FAROAMING);
                }

                if (isFiDO1FARoaming) {
                    nextSetAuthTypes.add(AuthType.FIDO.getName());
                    offeredAuthTypeSet.add(Constants.FIDO_DEVICE_TYPE_1FAROAMING);
                }

            }

            if (registeredAuthTypes.contains(AuthType.SMSOTP)
                    && AuthenticationUtils.isAuthTypeAllowed(AuthType.SMSOTP.getName())
                    && StringUtils.isNotBlank(userAuthInfoRegAuthModuleVo.getMobileNumber())) {
                nextSetAuthTypes.add(AuthType.SMSOTP.getName());
                offeredAuthTypeSet.add(AuthType.SMSOTP.getName());
            }

            if (registeredAuthTypes.contains(AuthType.EMAILOTP)
                    && AuthenticationUtils.isAuthTypeAllowed(AuthType.EMAILOTP.getName())
                    && StringUtils.isNotBlank(userAuthInfoRegAuthModuleVo.getEmailId())) {
                nextSetAuthTypes.add(AuthType.EMAILOTP.getName());
                offeredAuthTypeSet.add(AuthType.EMAILOTP.getName());
            }

        } else {
            throw new ValidateUserException("Invalid User");
        }

        request.getSession().setAttribute(SessionConstants.OFFERED_AUTH_TYPES, offeredAuthTypeSet);
        LOG.info("attemptAuthentication() : Level 2 Offered Auth Types to {} user: {}", username, offeredAuthTypeSet);
        return nextSetAuthTypes;

    }

    @Override
    public boolean generateSMSOTP(final HttpServletRequest request, final HttpServletResponse response,
            final Map<String, Object> inputParameters) {
        LOG.debug("generateSMSOTP() entered");
        boolean ret = false;
        try {
            final String userName = (String) request.getSession().getAttribute(SessionConstants.CURRENT_USERNAME);
            if (StringUtils.isBlank(userName)) {
                throw new UsernameNotFoundException("Unable to get username from session for Authentication Process");
            }
            inputParameters.put(Constants.REQ_PARAM_USERNAME, userName);
            ret = smsOTPServiceImpl.generateOTP(request, response, inputParameters);
        } catch (final Exception e) {
            LOG.error("Error while generating sms otp", e);
        }
        LOG.debug("generateSMSOTP() exiting");
        return ret;
    }

    /**
     * @param userAuthInfo
     * @param webOnlyUser
     */
    private void validateUserStatus(final UserAuthInfoVO userAuthInfo, final HttpServletRequest request,
            final ValidateUserRequest validateUserRequest, final boolean webOnlyUser) {
        LOG.info("validateUserStatus() -> Entered.");

        if (userAuthInfo.getUserStatus() != RelIdUserStatus.ACTIVE || (!webOnlyUser && userAuthInfo.getRelIds().stream()
                .filter(relid -> relid.getRelIdStatus().equals(RelIdUserStatus.ACTIVE)).collect(Collectors.toList())
                .isEmpty())) {
            EventLogger.log(EventId.RelidAuthServer.INVALID_USER_STATUS, Utils.getClientIpAddress(request),
                    AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                    AuthenticationUtils.getUserAgent(request), "Inactive User Status");
            throw new InvalidUserException("Unauthorized Access");
        }

        final WebUserDetails webUserDetails = userAuthInfo.getWebUserDetails();
        if (StringUtils.equals(
                webUserDetails.getWebUserStatus() != null ? webUserDetails.getWebUserStatus().getValue() : null,
                WebUserStatus.BLOCKED.getValue())) {
            final Date blockTs = webUserDetails.getBlockedTs();
            final Calendar calendar = Calendar.getInstance();
            calendar.setTime(blockTs);
            calendar.add(Calendar.MINUTE, webUserDetails.getLastBlockedInterval());
            final Long unblockTs = calendar.getTime().getTime();
            final Long currentTs = new Date().getTime();
            final long diff = unblockTs - currentTs;

            if (diff > 0) {
                EventLogger.log(EventId.RelidAuthServer.INVALID_WEB_USER_STATUS, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request),
                        "User Is Blocked - As Cooling Period Is Not Yet Completed");

                throw new AttemptCounterExceededException("User is blocked");
            }
        }
    }

    @Override
    public UserAuthInfoVO getUserAuthInfoByUserName(final String username) {
        LOG.info("getUserAuthInfoByUserName() -> Fetch UserAuthInfor: {}", username);
        final UserAuthInfoVO userAuthInfo = userAuthInfoRepoImpl.fetchUserDetailsFromLoginId(username);

        if (userAuthInfo == null)
            throw new InvalidUserException(SessionConstants.ERR_INVALID_USER);

        return userAuthInfo;
    }

    @Override
    public void unblockWebUser(final WebUserDetails webUserDetails, final String loginId) {
        LOG.info("unblockWebUser() -> Unblocking web user: {}", loginId);
        userAuthInfoRepoImpl.unblockWebUser(webUserDetails, loginId);
    }

    @Override
    public void updateWebUserAttemptCounter(final String loginId, final List<Integer> attemptCounters) {
        LOG.info("updateWebUserAttemptCounter() -> Updating user atttempt counter: {}", loginId);
        userAuthInfoRepoImpl.updateWebUserAttemptCounter(loginId, attemptCounters);
    }

    @Override
    public UpdateResult updateWebUserBrowserStatus(final String loginId, final String webDeviceUuid,
            final WebUserStatus status) {
        LOG.info("blockWebUserBrowser() -> {} web user browser: {}", status, loginId);
        return userAuthInfoRepoImpl.updateWebUserBrowserStatus(loginId, webDeviceUuid, status);
    }

    @Override
    public List<UserBrowser> getListOfUserBrowsers(final String loginId) {
        LOG.info("getListOfWebUserBrowsers() -> Get a list of web user browser: {}", loginId);
        return userAuthInfoRepoImpl.getListOfUserBrowsers(loginId);
    }

    @Override
    public List<WebUserBrowserDetailsDTO> getBrowsers(final String loginId) {
        LOG.info("getListOfWebUserBrowsers() -> Get a web user browser: {}", loginId);
        return userAuthInfoRepoImpl.getListOfBrowsers(loginId);
    }

    @Override
    public Page<UserBrowser> getListOfUserBrowsers(final String loginId, final String search, final Pageable pageable) {
        LOG.info("getListOfWebUserBrowsers() -> Get a list of web user browser: {}", loginId);
        return userAuthInfoRepoImpl.getListOfUserBrowsers(loginId, search, pageable);
    }

    @Override
    public UpdateResult deleteWebUserBrowser(final String loginId, final String webDeviceUuid) {
        LOG.info("deleteWebUserBrowser() -> deleteWebUserBrowser : {}", loginId);
        return userAuthInfoRepoImpl.deleteWebUserBrowser(loginId, webDeviceUuid);
    }

    @Override
    public UpdateResult unRememberWebUserBrowser(final String loginId, final String webDeviceUuid) {
        LOG.info("unRememberWebUserBrowser() -> unRememberWebUserBrowser: {}", loginId);
        return userAuthInfoRepoImpl.unRememberWebUserBrowser(loginId, webDeviceUuid);
    }

    @Override
    public void updateWebUserAuthGenerationAttemptCounter(final String loginId,
            final Map<String, Integer> authGenerationAttemptsCounter) {
        LOG.info("updateWebUserAttemptCounter() -> Updating auth generation atttempt counter: {}", loginId);
        userAuthInfoRepoImpl.updateWebUserAuthGenerationAttemptCounter(loginId, authGenerationAttemptsCounter);
    }

    @Override
    public UserAuthInfoRegAuthModuleVo fetchUserAuthInfoRegAuthModuleFromLoginId(final String loginId) {
        UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = null;
        if (StringUtils.isNotBlank(loginId)) {
            userAuthInfoRegAuthModuleVo = userAuthInfoRepoImpl.fetchUserAuthInfoRegAuthModuleFromLoginId(loginId);
        }
        return userAuthInfoRegAuthModuleVo;
    }

    @Override
    public boolean deleteRegisteredAuthModule(final String loginId, final String authenticatorUuid) {
        if (StringUtils.isNotBlank(loginId) && StringUtils.isNotBlank(authenticatorUuid)
                && allowedToDeleteOrDisableAuthFactor(loginId, authenticatorUuid, null)) {
            return userAuthInfoRepoImpl.deleteRegisteredAuthModule(loginId, authenticatorUuid);
        }
        return false;
    }

    @Override
    public boolean allowedToDeleteOrDisableAuthFactor(final String loginId, final String authenticatorUuid,
            final List<FIDO2RegisteredAuthenticationModule> registerAuthModuleList) {
        boolean isAllowedToDeleteOrDisableAuthFactor = true;
        final List<RegisteredAuthenticationModule> regAuthModuleWith2FA = new ArrayList<>();
        final List<RegisteredAuthenticationModule> disabledRegAuthModule = new ArrayList<>();
        FIDO2RegisteredAuthenticationModule registeredModule = null;
        List<FIDO2RegisteredAuthenticationModule> regAuthModuleList = null;

        if (CollectionUtils.isEmpty(regAuthModuleList)) {
            regAuthModuleList = fetchRegisteredAuthenticationModuleFromLoginId(loginId);
        } else {
            regAuthModuleList = new ArrayList<>(registerAuthModuleList);
        }

        if (!CollectionUtils.isEmpty(regAuthModuleList)) {
            final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = userAuthInfoRepoImpl
                    .fetchUserAuthInfoRegAuthModuleFromLoginId(loginId);

            for (final FIDO2RegisteredAuthenticationModule module : regAuthModuleList) {
                if (module == null) {
                    continue;
                }

                if (module.getAuthenticatorUuid().equals(authenticatorUuid)) {
                    registeredModule = module;
                }

                if (module.getAuthTypeStatus().equals(AuthTypeStatus.DISABLED)) {
                    disabledRegAuthModule.add(module);
                } else if (is2FAFidoDevice(module)) {
                    regAuthModuleWith2FA.add(module);
                }
            }

            final boolean webOnlyUser = (userAuthInfoRegAuthModuleVo.isWebOnly() != null
                    ? userAuthInfoRegAuthModuleVo.isWebOnly()
                    : false);

            if (webOnlyUser && registeredModule != null) {
                // Passwordless User Flow
                if (is2FAFidoDevice(registeredModule) // Use
                                                      // Utility
                                                      // method
                                                      // using
                                                      // transport
                                                      // field
                        && userAuthInfoRegAuthModuleVo.getRegAuthTypes().size() == 1
                        && userAuthInfoRegAuthModuleVo.getRegAuthTypes().contains(AuthType.FIDO)) {

                    if (registeredModule.getAuthTypeStatus().equals(AuthTypeStatus.DISABLED)
                            && regAuthModuleWith2FA.size() == 1) {
                        return isAllowedToDeleteOrDisableAuthFactor;
                    }

                    if (regAuthModuleWith2FA.size() <= 1) {
                        isAllowedToDeleteOrDisableAuthFactor = false;
                    }

                } // Password User Flow
                else if (userAuthInfoRegAuthModuleVo.getRegAuthTypes().size() == 2 && userAuthInfoRegAuthModuleVo
                        .getRegAuthTypes().containsAll(Sets.newHashSet(AuthType.PASS, AuthType.FIDO))) {

                    regAuthModuleList.removeAll(disabledRegAuthModule);

                    if (registeredModule.getAuthTypeStatus().equals(AuthTypeStatus.DISABLED)
                            && regAuthModuleList.size() == 1) {
                        return isAllowedToDeleteOrDisableAuthFactor;
                    }

                    if (regAuthModuleList.size() <= 1) {
                        isAllowedToDeleteOrDisableAuthFactor = false;
                    }

                }
            }
        }

        return isAllowedToDeleteOrDisableAuthFactor;
    }

    private boolean is2FAFidoDevice(final FIDO2RegisteredAuthenticationModule module) {
        if (StringUtils.equalsIgnoreCase(module.getTransport(), "internal")
                || FidoUtils.is2FaAuthenticator(module.getAuthenticatorAttestationResponse().getAttestationObject())) {
            return true;
        }
        return false;
    }

    @Override
    public boolean updateRegAuthFactorStatus(final String loginId, final String authenticatorUuid,
            final boolean isEnabledState) {
        if (StringUtils.isNotBlank(loginId) && StringUtils.isNotBlank(authenticatorUuid)
                && (isEnabledState || allowedToDeleteOrDisableAuthFactor(loginId, authenticatorUuid, null))) {
            return userAuthInfoRepoImpl.updateRegAuthFactorStatus(loginId, authenticatorUuid, isEnabledState);
        }
        return false;
    }

    @Override
    public UpdateResult activateUser(final String loginId, final RelIdUserStatus userCurrentStatus,
            final boolean webOnly, final Set<AuthType> authTypes, final String mobileNumber, final String email) {

        if (StringUtils.isNotBlank(loginId)) {
            return userAuthInfoRepoImpl.activateUser(loginId, userCurrentStatus, webOnly, authTypes, mobileNumber,
                    email);
        }
        return null;
    }

    @Override
    public List<FIDO2RegisteredAuthenticationModule> fetchRegisteredAuthenticationModuleFromLoginId(
            final String loginId) {
        List<FIDO2RegisteredAuthenticationModule> regAuthModuleList = null;
        if (StringUtils.isNotBlank(loginId)) {
            regAuthModuleList = userAuthInfoRepoImpl.fetchRegisteredAuthenticationModuleFromLoginId(loginId);
        }
        return regAuthModuleList;
    }

    @Override
    public boolean isFidoPlatformRegisteredByUserId(final String loginId,
            final boolean needAlwaysAskForPasswordDisabledCheck, final String authenticatorUuid) {
        if (StringUtils.isNotBlank(loginId) && StringUtils.isNotBlank(authenticatorUuid)) {
            boolean isAlwaysAskForPassword = true;
            if (needAlwaysAskForPasswordDisabledCheck) {
                isAlwaysAskForPassword = !PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isAlwaysAskForPassword();
            }

            return isAlwaysAskForPassword && userAuthInfoRepoImpl.isFidoDeviceRegisteredByTypeFromUserId(loginId,
                    Constants.FIDO_PLATFORM_TRANSPORT_TYPE, authenticatorUuid);
        }
        return false;
    }

    public boolean checkForSecureCookieMappingWithPlatformAuth(final HttpServletRequest request,
            final ValidateUserRequest validateUserRequest) {
        LOG.info("checkForSecureCookieMappingWithUser() -> Entered.");

        boolean isFidoPlatformAuthRegistered = false;

        if (!PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isRememberMe()) {
            return isFidoPlatformAuthRegistered;
        }

        WebDevMaster webDevMaster = null;

        if (request.getCookies() == null) {
            return isFidoPlatformAuthRegistered;
        }
        final Optional<Cookie> optionalCookie = Arrays.stream(request.getCookies())
                .filter(ck -> StringUtils.equals(Constants.SECURE_COOKIE_NAME, ck.getName())).findFirst();

        Cookie secureCookie = null;
        if (optionalCookie.isPresent() && !secureCookieService.isSecureCookieExpired(request)) {
            secureCookie = optionalCookie.get();
            webDevMaster = webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(secureCookie.getValue());

            if (webDevMaster != null) {
                final String webDeviceUuid = webDevMaster.getWebDeviceUuid();

                final UserAuthInfoVO userAuthInfo = userAuthInfoRepoImpl
                        .fetchUserDetailsFromLoginId(validateUserRequest.getUserName());

                if (userAuthInfo == null)
                    throw new InvalidUserException("Invalid User : User is not registered in the system");

                final Optional<UserBrowser> optionalBrowser = userAuthInfo.getWebUserDetails().getBrowsers().stream()
                        .filter(browser -> StringUtils.equals(webDeviceUuid, browser.getWebDeviceUuid())).findFirst();

                if (optionalBrowser.isPresent()) {
                    if (!InputValidationUtils.isValidAuthTypeName(AuthType.SECURE_COOKIE.getName())) {
                        throw new ValidateUserException("Auth Type Name Is Not Valid");
                    }

                    try {
                        ESAPI.validator().getValidInput("secure_cookie_name", AuthType.SECURE_COOKIE.getName(),
                                "HTTPCookieValue", Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
                    } catch (final Exception e) {
                        throw new IllegalArgumentException("Request Has Invalid Secure Cookie." + e.getMessage());
                    }

                    final UserBrowser browser = optionalBrowser.get();
                    isFidoPlatformAuthRegistered = isFidoPlatformRegisteredByUserId(validateUserRequest.getUserName(),
                            true, browser.getAuthenticatorUuid());
                }
            } else {
                throw new InvalidSecureCookieException("Request Has Invalid Secure Cookie.");
            }
        }

        return isFidoPlatformAuthRegistered;
    }

    public boolean isBrowserRememberedByUser(final HttpServletRequest request, final String loginId) {
        LOG.info("checkForSecureCookieMappingWithUser() -> Entered.");

        boolean isBrowserRememberedByUser = false;

        if (!PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isRememberMe()) {
            return isBrowserRememberedByUser;
        }

        WebDevMaster webDevMaster = null;

        if (request.getCookies() == null) {
            return isBrowserRememberedByUser;
        }
        final Optional<Cookie> optionalCookie = Arrays.stream(request.getCookies())
                .filter(ck -> StringUtils.equals(Constants.SECURE_COOKIE_NAME, ck.getName())).findFirst();

        Cookie secureCookie = null;
        if (optionalCookie.isPresent() && !secureCookieService.isSecureCookieExpired(request)) {
            secureCookie = optionalCookie.get();
            webDevMaster = webDevMasterService.fetchWebDeviceMasterUsingSecureCookieValue(secureCookie.getValue());

            if (webDevMaster != null) {
                final String webDeviceUuid = webDevMaster.getWebDeviceUuid();

                final UserAuthInfoVO userAuthInfo = userAuthInfoRepoImpl.fetchUserDetailsFromLoginId(loginId);

                if (userAuthInfo == null)
                    throw new InvalidUserException("Invalid User : User is not registered in the system");

                final Optional<UserBrowser> optionalBrowser = userAuthInfo.getWebUserDetails().getBrowsers().stream()
                        .filter(browser -> StringUtils.equals(webDeviceUuid, browser.getWebDeviceUuid())).findFirst();

                if (optionalBrowser.isPresent()) {
                    if (!InputValidationUtils.isValidAuthTypeName(AuthType.SECURE_COOKIE.getName())) {
                        throw new ValidateUserException("Auth Type Name Is Not Valid");
                    }

                    try {
                        ESAPI.validator().getValidInput("secure_cookie_name", AuthType.SECURE_COOKIE.getName(),
                                "HTTPCookieValue", Constants.MAX_SIZE_HTTPHEADER_VALUE_DEFAULT, false);
                    } catch (final Exception e) {
                        throw new IllegalArgumentException("Request Has Invalid Secure Cookie." + e.getMessage());
                    }

                    isBrowserRememberedByUser = true;
                }
            } else {
                throw new InvalidSecureCookieException("Request Has Invalid Secure Cookie.");
            }
        }

        return isBrowserRememberedByUser;
    }

    public boolean validateFidoCredential(final HttpServletRequest request, final HttpServletResponse response,
            final ValidateUserRequest validateUserRequest) {

        return authenticationService.authenticateUserUsingFido(request, response, validateUserRequest);

    }

    public boolean validateFidoPlatformRegistration(final HttpServletRequest request,
            final HttpServletResponse response, final ValidateUserRequest validateUserRequest) {

        return checkForSecureCookieMappingWithPlatformAuth(request, validateUserRequest);

    }
}
