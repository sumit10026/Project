package com.uniken.authserver.services.api;

import javax.servlet.http.HttpServletRequest;

import com.uniken.authserver.domains.ConfigurationResponse;

/**
 * This service will handle operations related to configuration.
 * 
 * @author Kiran Borhade
 **/
public interface ConfigurationService {

    /**
     * This method will fetch the configurations related to password /
     * rememberMe parameters & then returns it along with user account list.
     * 
     * @return configuration response contains Configuration & Account details.
     **/
    ConfigurationResponse getConfigurations(HttpServletRequest request, String webDeviceParameterChecksum);

}
