package com.uniken.authserver.services.api;

import org.springframework.session.Session;

/**
 * The service that is used to manage mongo session
 * 
 * @author Uday T
 */
public interface WebDevSessionService {

    /**
     * This method archives the mongo session
     * 
     * @param session
     */
    public void archiveWebDevSession(Session session);

    /**
     * Archive web dev session by id.
     *
     * @param id
     *            the id
     */
    public void archiveWebDevSessionById(final String id);
}
