package com.uniken.authserver.services.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.session.Session;
import org.springframework.stereotype.Service;

import com.uniken.authserver.repo.api.WebDevSessionRepo;
import com.uniken.authserver.services.api.WebDevSessionService;

@Service
public class WebDevSessionServiceImpl
        implements
        WebDevSessionService {

    private static final Logger LOG = LoggerFactory.getLogger(WebDevSessionServiceImpl.class);

    @Autowired
    private WebDevSessionRepo webDevSessionRepo;

    @Override
    public void archiveWebDevSession(final Session session) {
        LOG.info("archiveWebDevSession() entered");
        webDevSessionRepo.archiveWebDevSession(session);
    }

    @Override
    public void archiveWebDevSessionById(final String id) {
        LOG.info("archiveWebDevSessionById() entered");
        webDevSessionRepo.archiveWebDevSessionById(id);
    }

}
