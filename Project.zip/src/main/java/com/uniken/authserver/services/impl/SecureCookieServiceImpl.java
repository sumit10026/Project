package com.uniken.authserver.services.impl;

import java.util.Arrays;
import java.util.Date;
import java.util.Optional;
import java.util.UUID;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpCookie;
import org.springframework.http.ResponseCookie;
import org.springframework.stereotype.Service;

import com.mongodb.client.result.UpdateResult;
import com.uniken.authserver.exception.InvalidSecureCookieException;
import com.uniken.authserver.exception.InvalidUserException;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.services.api.SecureCookieService;
import com.uniken.authserver.services.api.WebDevMasterService;
import com.uniken.authserver.utility.AuthenticationUtils;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.Utility;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.relid.device.WebDevMaster;
import com.uniken.domains.relid.user.UserBrowser;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.domains.user.vos.SecureCookie;
import com.uniken.domains.user.vos.WebUserDetails;
import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;

@Service
public class SecureCookieServiceImpl
        implements
        SecureCookieService {

    private static final Logger LOG = LoggerFactory.getLogger(SecureCookieServiceImpl.class);

    @Autowired
    WebDevMasterService webDevMasterService;

    @Autowired
    private UserAuthInfoRepo userAuthInfoRepo;

    @Override
    public String generateSecureCookie() {

        final String cookieValue = encryptSecureCookie(UUID.randomUUID().toString());
        final Boolean useSecureCookie = true;
        final Boolean isHttpOnly = true;
        final int expiryTime = PropertyConstants.DEFAULT_COOKIE_EXPIRY_TIME_IN_SECONDS;
        final String cookiePath = PropertyConstants.AUTH_SERVER_DEFAULT_COOKIE_PATH;
        final String sameSiteValue = "Strict";
        final String domain = "";

        final HttpCookie httpCookie = ResponseCookie.from(Constants.SECURE_COOKIE_NAME, cookieValue).path(cookiePath)
                .secure(useSecureCookie).httpOnly(isHttpOnly).domain(domain).maxAge(expiryTime).sameSite(sameSiteValue)
                .build();

        final String cookie = httpCookie.toString() + "; priority=HIGH";

        return cookie;

    }

    @Override
    public String generateSecureCookieByGivenValue(final String cookieValue) {

        final String encryptedCookie = cookieValue;
        if (decryptSecureCookie(cookieValue) == null) {
            throw new InvalidSecureCookieException("Invalid Secure Cookie");
        }

        final Boolean useSecureCookie = true;
        final Boolean isHttpOnly = true;
        final int expiryTime = PropertyConstants.DEFAULT_COOKIE_EXPIRY_TIME_IN_SECONDS;
        final String cookiePath = PropertyConstants.AUTH_SERVER_DEFAULT_COOKIE_PATH;
        final String sameSiteValue = "Strict";
        final String domain = "";

        final HttpCookie httpCookie = ResponseCookie.from(Constants.SECURE_COOKIE_NAME, encryptedCookie)
                .path(cookiePath).secure(useSecureCookie).httpOnly(isHttpOnly).domain(domain).maxAge(expiryTime)
                .sameSite(sameSiteValue).build();

        final String cookie = httpCookie.toString() + "; priority=HIGH";

        return cookie;

    }

    private String encryptSecureCookie(final String secureCookiePlain) {
        try {
            final byte byteKey[] = Utility.SHA256Digest(Constants.SECURE_COOKIE_KEY.getBytes());
            final Cipher cipher = Cipher.getInstance("AES/CFB/PKCS5Padding");
            final SecretKeySpec secret = new SecretKeySpec(byteKey, "AES");
            final IvParameterSpec ivBytes = new IvParameterSpec(Constants.SECURE_COOKIE_SALT.getBytes());
            cipher.init(Cipher.ENCRYPT_MODE, secret, ivBytes);
            final byte[] encryptedTextBytes = cipher.doFinal(secureCookiePlain.getBytes());
            return Base64.encodeBase64String(encryptedTextBytes);
        } catch (final Exception e) {
            LOG.error("encryptSecureCookie() : Failed to encrypt the cipher text!", e);
        }
        return null;
    }

    @Override
    public String decryptSecureCookie(final String secureCookieEncrypted) {
        try {
            final byte byteKey[] = Utility.SHA256Digest(Constants.SECURE_COOKIE_KEY.getBytes());
            final Cipher cipher = Cipher.getInstance("AES/CFB/PKCS5Padding");
            final SecretKeySpec secret = new SecretKeySpec(byteKey, "AES");
            final IvParameterSpec ivBytes = new IvParameterSpec(Constants.SECURE_COOKIE_SALT.getBytes());
            cipher.init(Cipher.DECRYPT_MODE, secret, ivBytes);
            final byte[] original = Base64.decodeBase64(secureCookieEncrypted.getBytes());
            final byte[] originalValue = cipher.doFinal(original);
            return new String(originalValue);
        } catch (final Exception e) {
            LOG.error("decryptSecureCookie() : Failed to decrypt the cipher text!", e);
        }
        return null;
    }

    @Override
    public boolean isSecureCookieExpired(final HttpServletRequest request) {

        boolean isExpired = true;

        // Secure Cookie Expiration validation
        final Optional<Cookie> optionalCookie = Arrays.stream(request.getCookies())
                .filter(ck -> StringUtils.equals(Constants.SECURE_COOKIE_NAME, ck.getName())).findFirst();
        if (optionalCookie.isPresent()) {
            final Cookie cookie = optionalCookie.get();
            final WebDevMaster webDevMaster = webDevMasterService
                    .fetchWebDeviceMasterUsingSecureCookieValue(cookie.getValue());

            if (webDevMaster == null) {
                throw new InvalidSecureCookieException("Request Has Invalid Secure Cookie.");
            }

            final SecureCookie secureCookie = webDevMaster.getSecureCookie();
            final long expiryTs = secureCookie.getSecureCookieExpiryTs().getTime();
            final long currentTs = new Date().getTime();
            final long diff = expiryTs - currentTs;

            if (diff > 0) {
                isExpired = false;
            } else {
                isExpired = true;
                EventLogger.log(EventId.RelidAuthServer.INVALID_SECURE_COOKIE, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request), "Request Has Expired Secure Cookie");
            }
        }

        return isExpired;

    }

    @Override
    public boolean updateUserOptedOutForFidoRegistrationForBrowser(final HttpServletRequest request,
            final String loginId, final boolean userOptedOutForFidoReg) {

        final Optional<Cookie> optionalCookie = Arrays.stream(request.getCookies())
                .filter(ck -> StringUtils.equals(Constants.SECURE_COOKIE_NAME, ck.getName())).findFirst();
        if (optionalCookie.isPresent()) {
            final Cookie cookie = optionalCookie.get();
            final WebDevMaster webDevMaster = webDevMasterService
                    .fetchWebDeviceMasterUsingSecureCookieValue(cookie.getValue());

            if (webDevMaster == null) {
                EventLogger.log(EventId.RelidAuthServer.INVALID_SECURE_COOKIE, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request), "Request Has Invalid Secure Cookie.");
                throw new InvalidSecureCookieException("Request Has Invalid Secure Cookie.");
            }

            final UserAuthInfoVO userAuthInfo = userAuthInfoRepo.fetchUserDetailsFromLoginId(loginId);

            if (userAuthInfo == null) {
                EventLogger.log(EventId.RelidAuthServer.USER_NOT_FOUND, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request), "Invalid User");
                throw new InvalidUserException("Invalid User : User is not registered in the system");
            }

            final Optional<UserBrowser> optionalBrowser = userAuthInfo.getWebUserDetails().getBrowsers().stream()
                    .filter(browser -> StringUtils.equals(webDevMaster.getWebDeviceUuid(), browser.getWebDeviceUuid()))
                    .findFirst();

            if (optionalBrowser.isPresent()) {
                final UserBrowser browser = optionalBrowser.get();
                browser.setUserOptedOutForFidoReg(userOptedOutForFidoReg);

                final UpdateResult result = userAuthInfoRepo.updateUserAuthInfoDoc(loginId,
                        UserAuthInfoVO.WEB_USER_DETAILS + "." + WebUserDetails.BROWSERS_STR,
                        userAuthInfo.getWebUserDetails().getBrowsers());

                return result.getModifiedCount() > 0;
            }

        }
        return false;

    }

    @Override
    public UserBrowser getAssociatedUserBrowserBySecureCookie(final HttpServletRequest request, final String loginId) {

        final Optional<Cookie> optionalCookie = Arrays.stream(request.getCookies())
                .filter(ck -> StringUtils.equals(Constants.SECURE_COOKIE_NAME, ck.getName())).findFirst();
        if (optionalCookie.isPresent()) {
            final Cookie cookie = optionalCookie.get();
            final WebDevMaster webDevMaster = webDevMasterService
                    .fetchWebDeviceMasterUsingSecureCookieValue(cookie.getValue());

            if (webDevMaster == null) {
                EventLogger.log(EventId.RelidAuthServer.INVALID_SECURE_COOKIE, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request), "Request Has Invalid Secure Cookie.");
                throw new InvalidSecureCookieException("Request Has Invalid Secure Cookie.");
            }

            final UserAuthInfoVO userAuthInfo = userAuthInfoRepo.fetchUserDetailsFromLoginId(loginId);

            if (userAuthInfo == null) {
                EventLogger.log(EventId.RelidAuthServer.USER_NOT_FOUND, Utils.getClientIpAddress(request),
                        AuthenticationUtils.getRequestorId(request), AuthenticationUtils.getUsername(request),
                        AuthenticationUtils.getUserAgent(request), "Invalid User");
                throw new InvalidUserException("Invalid User : User is not registered in the system");
            }

            final Optional<UserBrowser> optionalBrowser = userAuthInfo.getWebUserDetails().getBrowsers().stream()
                    .filter(browser -> StringUtils.equals(webDevMaster.getWebDeviceUuid(), browser.getWebDeviceUuid()))
                    .findFirst();

            if (optionalBrowser.isPresent()) {
                return optionalBrowser.get();
            }

        }
        return null;
    }

}
