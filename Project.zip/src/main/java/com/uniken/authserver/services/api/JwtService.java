package com.uniken.authserver.services.api;

import java.util.Map;

import org.springframework.security.jwt.crypto.sign.Signer;

public interface JwtService {

    /**
     * Generates jwt.
     *
     * @param claims
     *            the claims
     * @param signer
     *            the signer
     * @return the string
     * @throws IllegalArgumentException
     *             the illegal argument exception
     */
    String generateEncodedJwt(Map<String, Object> claims, Signer signer) throws IllegalArgumentException;

    /**
     * Generate encoded jwt.
     *
     * @param headers
     *            the headers
     * @param claims
     *            the claims
     * @param signer
     *            the signer
     * @return the string
     * @throws IllegalArgumentException
     *             the illegal argument exception
     */
    String generateEncodedJwt(Map<String, String> headers, Map<String, Object> claims, Signer signer)
            throws IllegalArgumentException;

    /**
     * Gets the jwt claims.
     *
     * @param jwt
     *            the jwt
     * @return the jwt claims
     * @throws IllegalArgumentException
     *             the illegal argument exception
     */
    Map<String, Object> getJwtClaims(final String jwt) throws IllegalArgumentException;

}
