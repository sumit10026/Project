package com.uniken.authserver.services.api;

import java.util.Map;

import org.springframework.security.core.Authentication;

/**
 * @author Akash S
 */
public interface TokenEndpointsServices {

    /**
     * To revoke access token
     * 
     * @param token
     *            : token value
     * @param tokenType
     *            TODO
     * @param clientId
     *            TODO
     * @return boolean :True - if token revoked. False - If failed to revoke the
     *         token
     */
    // TODO: Should return Revoke Token Response object:
    boolean revokeToken(String token, String tokenType, String clientId);

    /**
     * To revoke refresh token
     * 
     * @param tokenValue
     *            : Access token value
     * @return boolean :True - if token revoked. False - If failed to revoke the
     *         token
     */
    boolean revokeRefreshToken(String tokenValue);

    /**
     * Instrospect a token.
     *
     * @param authentication
     *            the authentication
     * @param value
     *            the token
     * @param tokenTypeHint
     *            the token type hint
     * @return the map
     */
    Map<String, Object> instrospectToken(final Authentication authentication, final String value,
            final String tokenTypeHint);

}
