package com.uniken.authserver.services.impl;

import java.util.HashSet;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;

import com.google.common.collect.Sets;
import com.uniken.authserver.domains.AccountRecoveryCredentialRequest;
import com.uniken.authserver.domains.AccountRecoveryTokenDetails;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.services.api.AccountRecoveryCredentialService;
import com.uniken.authserver.utility.AccountRecoverySessionUtils;
import com.uniken.authserver.utility.PropertyConstants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.user.vos.UserAuthInfoRegAuthModuleVo;
import com.uniken.pass.handler.library.sync.api.PassHandler;

@Service
public class AccountRecoveryCredentialServiceImpl
        implements
        AccountRecoveryCredentialService {

    private static final Logger LOG = LoggerFactory.getLogger(AccountRecoveryCredentialServiceImpl.class);

    @Autowired
    private PassHandler passHandler;

    @Autowired
    UserAuthInfoRepo userAuthInfoRepo;

    @Override
    public Set<String> getResetCredentialFactor(final AccountRecoveryTokenDetails accountRecoveryTokenDetails) {

        final Set<String> resetCredentialFactorSet = new HashSet<>();
        try {
            if (accountRecoveryTokenDetails != null) {

                final String authenticatedFirstLevelFactor = accountRecoveryTokenDetails.getFirstLevelFactor();
                final String authFactorNeedsToReset = accountRecoveryTokenDetails.getAuthFactorNeedsToReset();
                final UserAuthInfoRegAuthModuleVo userAuthInfoRegAuthModuleVo = userAuthInfoRepo
                        .fetchUserAuthInfoRegAuthModuleFromLoginId(accountRecoveryTokenDetails.getUserId());

                if (StringUtils.isBlank(authenticatedFirstLevelFactor) && StringUtils.isBlank(authFactorNeedsToReset)) {
                    return resetCredentialFactorSet;
                }

                if (StringUtils.isNotBlank(authenticatedFirstLevelFactor)
                        && AuthType.isValidElement(authenticatedFirstLevelFactor)) {
                    resetCredentialFactorSet.add(AuthType.SMSOTP.getName());
                    resetCredentialFactorSet.add(AuthType.EMAILOTP.getName());
                    resetCredentialFactorSet.add(AuthType.FIDO.getName());
                } else if (StringUtils.isNotBlank(authFactorNeedsToReset)
                        && AuthType.isValidElement(authFactorNeedsToReset)) {
                    if (authFactorNeedsToReset.equals(AuthType.PASS.getName())) {
                        // Check if password is enabled at system level and if
                        // user has already registered with the password
                        if (PropertyConstants.AUTH_SERVER_ALLOWED_AUTH_FACTORS.isPassword()
                                && userAuthInfoRegAuthModuleVo.getRegAuthTypes().contains(AuthType.PASS)) {
                            resetCredentialFactorSet.add(authFactorNeedsToReset);
                        }
                    }
                }

                if (!CollectionUtils.isEmpty(resetCredentialFactorSet)) {
                    AccountRecoverySessionUtils.setPendingResetCredentialFactorSet(resetCredentialFactorSet);
                }

            }
        } catch (final Exception e) {
            LOG.error("getResetCredentialFactor() : ", e);
            return resetCredentialFactorSet;
        }
        return resetCredentialFactorSet;
    }

    @Override
    public boolean resetCredentialFactor(final AccountRecoveryCredentialRequest accountRecoveryCredentialRequest) {
        boolean hasReset = false;
        if (accountRecoveryCredentialRequest.getAuthType().equals(AuthType.PASS.getName())) {
            final String password = accountRecoveryCredentialRequest.getAuthValue();
            final String username = AccountRecoverySessionUtils.getARCUsername();
            final Set<String> resetCredentialFactor = AccountRecoverySessionUtils.getPendingResetCredentialFactorSet();

            if (!resetCredentialFactor.contains(accountRecoveryCredentialRequest.getAuthType())) {
                LOG.error("resetCredentialFactor() : Not allowed to reset {}. User: {}",
                        accountRecoveryCredentialRequest.getAuthType(), username);
                return hasReset;
            }

            if (Utils.isNullOrEmpty(password)
                    || !Utils.validatePassword(passHandler.decryptReceivedPassword(password), username)) {
                LOG.error("resetCredentialFactor() : Invalid password entered. User: {}", username);
                return hasReset;
            }

            hasReset = this.passHandler.storePassword(username, password);
            if (hasReset) {
                AccountRecoverySessionUtils.setCompletedResetCredentialFactorSet(
                        Sets.newHashSet(accountRecoveryCredentialRequest.getAuthType()));
            }
            LOG.info("resetCredentialFactor() : Password Reset: {}", hasReset);

        }
        return hasReset;
    }

}
