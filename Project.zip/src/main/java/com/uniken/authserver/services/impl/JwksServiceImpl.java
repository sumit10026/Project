package com.uniken.authserver.services.impl;

import java.io.ByteArrayInputStream;
import java.security.Key;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.interfaces.RSAPublicKey;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.jose4j.jwk.JsonWebKey;
import org.jose4j.jwk.JsonWebKeySet;
import org.jose4j.jwk.RsaJsonWebKey;
import org.jose4j.jwk.Use;
import org.jose4j.jws.AlgorithmIdentifiers;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uniken.authserver.repo.api.OidcConfigRepo;
import com.uniken.authserver.services.api.JwksService;
import com.uniken.domains.auth.JWTConfig;
import com.uniken.domains.auth.OIDCConfig;
import com.uniken.encdecutils.PropertiesEncryptDecrypt;

@Service
public class JwksServiceImpl
        implements
        JwksService {

    private static final Logger LOGGER = LoggerFactory.getLogger(JwksServiceImpl.class);

    @Autowired
    private OidcConfigRepo oidcConfigRepo;

    @Override
    public JsonWebKeySet getJwks() {

        LOGGER.info("getJwks() -> Getting JWKS.");

        LOGGER.debug("getJwks() -> Getting all OIDC configs.");

        final List<JsonWebKey> jsonWebKeys = new ArrayList<>();

        final List<OIDCConfig> oidcConfigs = oidcConfigRepo.getAllOidcConfigs();

        for (final OIDCConfig oidcConfig : oidcConfigs) {

            final JWTConfig jwtConfig = oidcConfig.getJwtConfig();

            if (jwtConfig != null && AlgorithmIdentifiers.RSA_USING_SHA256.equals(jwtConfig.getAlgorithm())) {
                try (ByteArrayInputStream keyStoreStream = new ByteArrayInputStream(
                        Base64.decodeBase64(jwtConfig.getRsBlob()))) {

                    final KeyStore keyStore = KeyStore.getInstance(jwtConfig.getCertificateType());
                    final char[] decryptedKeystorePswd = PropertiesEncryptDecrypt
                            .decryptWithAES(jwtConfig.getKeystorePassword()).toCharArray();
                    keyStore.load(keyStoreStream, decryptedKeystorePswd);
                    final Key key = keyStore.getKey(jwtConfig.getCertificateAlias(), decryptedKeystorePswd);

                    if (key instanceof PrivateKey) {
                        // Get certificate of public key
                        final Certificate cert = keyStore.getCertificate(jwtConfig.getCertificateAlias());

                        // Get public key
                        final PublicKey publicKey = cert.getPublicKey();

                        final RsaJsonWebKey jsonWebKey = new RsaJsonWebKey((RSAPublicKey) publicKey);
                        jsonWebKey.setKeyId(jwtConfig.getKid());
                        jsonWebKey.setAlgorithm(AlgorithmIdentifiers.RSA_USING_SHA256);
                        jsonWebKey.setUse(Use.SIGNATURE);

                        jsonWebKeys.add(jsonWebKey);
                    }
                } catch (final Exception e) {
                    LOGGER.error("Could not load certificate", e);
                }
            }
        }

        return new JsonWebKeySet(jsonWebKeys);
    }

}
