package com.uniken.authserver.services.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.oauth2.common.exceptions.InvalidClientException;
import org.springframework.security.oauth2.common.exceptions.InvalidScopeException;
import org.springframework.security.oauth2.common.exceptions.UnauthorizedUserException;
import org.springframework.security.oauth2.common.util.OAuth2Utils;
import org.springframework.security.oauth2.provider.ClientDetails;
import org.springframework.stereotype.Service;

import com.uniken.authserver.domains.TOTPValidationLog;
import com.uniken.authserver.repo.api.TOTPValidationRepo;
import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.authserver.services.api.OAuth2ClientDetailsService;
import com.uniken.authserver.utility.Constants;
import com.uniken.authserver.utility.Utils;
import com.uniken.domains.auth.EnterpriseInfo;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.auth.OAuthResources;
import com.uniken.domains.relid.user.RelId;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.domains.util.OAuthUtils;
import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;
import com.uniken.totp.domains.SeedDetails;
import com.uniken.totp.domains.TOTPValidationRequest;
import com.uniken.totp.domains.TOTPValidationResponse;
import com.uniken.totp.enums.TOTPHmacSpecs;
import com.uniken.totp.exception.TOTPValidationException;
import com.uniken.totp.service.impl.TOTPServices;

@Service
public class ValidateTotpServiceImpl {

    private static final Logger LOG = LoggerFactory.getLogger(ValidateTotpServiceImpl.class);

    @Autowired
    private OAuth2ClientDetailsService clientDetailsService;

    @Autowired
    private UserAuthInfoRepo userAuthInfoRepo;

    @Autowired
    private TOTPValidationRepo totpValidationLogRepo;

    @Deprecated
    public boolean validateTotp(final HttpServletRequest request, final HttpServletResponse response,
            final java.util.Map<String, Object> params) throws TOTPValidationException {

        LOG.info("validateTotp() -> Entering.");
        // TODO: sanitize this request validation as incoming request has
        // already been validated in UserServiceImpl > line #198
        // validating incoming request
        validateRequest(request);

        final String username = request.getParameter(Constants.REQ_PARAM_USERNAME);
        final String totp = request.getParameter(TOTPValidationLog.TOTP);

        final long validationTs = new Date().getTime() / 1000;
        Boolean isTOTPValidated = false;

        EventLogger.log(EventId.RelidAuthServer.INIT_TOTP_VALIDATION, Utils.getClientIpAddress(request),
                request.getAttribute(Constants.REQUESTOR_ID).toString(), username,
                "Authenticationg user via TOTP validation");

        final UserAuthInfoVO user = userAuthInfoRepo.fetchUserDetailsFromLoginId(username);

        if (user == null) {
            EventLogger.log(EventId.RelidAuthServer.TOTP_VALIDATION_FAILED, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), username, "User not found in db.");
            throw new UsernameNotFoundException(Constants.UNAUTHORIZED_ACCESS);
        }
        if (user.getUserStatus() != RelIdUserStatus.ACTIVE) {
            EventLogger.log(EventId.RelidAuthServer.TOTP_VALIDATION_FAILED, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), username, "user is not ACTIVE");
            throw new UnauthorizedUserException(Constants.UNAUTHORIZED_ACCESS);
        }
        if (user.getRelIds().stream().filter(relid -> relid.getRelIdStatus().equals(RelIdUserStatus.ACTIVE))
                .collect(Collectors.toList()).isEmpty()) {
            EventLogger.log(EventId.RelidAuthServer.TOTP_VALIDATION_FAILED, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), username,
                    "user does not have any active devices.");
            throw new UnauthorizedUserException(Constants.UNAUTHORIZED_ACCESS);
        }

        // Extracting seeds to generate and validate totp from UserAuthInfoVO
        final List<SeedDetails> listofSeeds = getSeedsForUser(user, request);

        final TOTPValidationRequest totpValidationReq = TOTPValidationRequest.getTOTPInstanceWithDefaulConfigs(totp,
                validationTs, listofSeeds);

        LOG.info("validateTotp() -> initiating TOTP validation for user : {}", username);

        final TOTPValidationResponse totpValidationResponse = TOTPServices.getInstance()
                .validateTOTP(totpValidationReq);

        if (totpValidationResponse.isTOTPMached()
                && !totpValidationLogRepo.isTOTPConsumed(username, totp, totpValidationResponse.getDeviceId())) {

            isTOTPValidated = true;
        }

        final TOTPValidationLog log = new TOTPValidationLog();
        log.setDeviceId(totpValidationResponse.getDeviceId());
        log.setUserId(username);
        log.setValidationStatus(totpValidationResponse.getValidationStatus().name());
        log.setValidationTs(totpValidationResponse.getValidationTs());
        log.setTotp(totpValidationResponse.getTotp());
        log.setSeed(totpValidationResponse.getSeed());
        totpValidationLogRepo.insertLog(log);

        response.setHeader("X-FRAME-OPTIONS", "DENY");
        return isTOTPValidated;
    }

    /**
     * @param relId
     * @return
     */
    private boolean totpSeedDetailsValidation(final RelId relId) {

        if (relId.getTotpSeed() == null || relId.getTotpSeed().isEmpty()) {
            LOG.error("totpSeedDetailsValidation() -> TOTP Seed is not registred for this device : {} ",
                    relId.getDeviceUuid());
            return false;
        }

        if (relId.getHmac() == null || relId.getHmac().trim().equals("")) {
            LOG.error("totpSeedDetailsValidation() -> HMAC value not found for this device : {} ",
                    relId.getDeviceUuid());
            return false;
        }

        if (relId.getHmacIndexVal() <= 0) {
            LOG.error("totpSeedDetailsValidation() -> HmacIndexValue is invalid for this device : {} ",
                    relId.getDeviceUuid());
            return false;
        }

        return true;
    }

    @Deprecated
    private List<SeedDetails> getSeedsForUser(final UserAuthInfoVO user, final HttpServletRequest request) {

        final List<SeedDetails> seeds = new ArrayList<>();
        for (final RelId relid : user.getRelIds()) {

            // checking if user is allowed to authenticate using TOTP
            if (Constants.getTotpEnabledAppAgents().contains(relid.getAppUuid())) {

                if (totpSeedDetailsValidation(relid)) {

                    final SeedDetails seedDetails = new SeedDetails();
                    seedDetails.setDeviceSeed(relid.getTotpSeed());
                    seedDetails.setDeviceUuid(relid.getDeviceUuid());
                    seedDetails.setHashIndexVal(relid.getHmacIndexVal());
                    seedDetails.setHmacSpec(TOTPHmacSpecs.valueOf(relid.getHmac()));
                    seedDetails.setUserActivationTs(relid.getRelIdCreatedTs().getTime() / 1000);
                    seeds.add(seedDetails);

                    LOG.info("getSeedsForUser() -> device added for TOTP validation : {} ", relid.getDeviceUuid());
                } else {
                    EventLogger.log(EventId.RelidAuthServer.TOTP_VALIDATION_FAILED, Utils.getClientIpAddress(request),
                            request.getAttribute(Constants.REQUESTOR_ID).toString(), user.getUserId(),
                            "Service Unavailable");
                    throw new AccessDeniedException("Service Unavailable");

                }
            } else {
                EventLogger.log(EventId.RelidAuthServer.TOTP_VALIDATION_FAILED, Utils.getClientIpAddress(request),
                        request.getAttribute(Constants.REQUESTOR_ID).toString(), user.getUserId(),
                        "App Agent is not enabled for TOTP.");
                throw new UnauthorizedUserException("App Agent is not enabled for TOTP.");
            }
        }
        return seeds;
    }

    private void validateRequest(final HttpServletRequest request) {

        final HttpSession session = request.getSession();
        final String clientId = (String) session.getAttribute(EnterpriseInfo.CLIENT_ID);
        final String scopeStr = (String) session.getAttribute(EnterpriseInfo.SCOPE);
        final String username = request.getParameter(Constants.REQ_PARAM_USERNAME);
        final String totp = request.getParameter(TOTPValidationLog.TOTP);

        // Validating client Id
        if (Utils.isNullOrEmpty(clientId)) {
            throw new InvalidClientException("clientId is null or empty");
        }

        // looking for client details
        final ClientDetails clientDetails = clientDetailsService.loadClientByClientId(clientId);

        // Validating Scope
        if (Utils.isNullOrEmpty(scopeStr)) {
            throw new InvalidScopeException("scope is null or empty");

        } else {
            final Set<String> scopes = OAuth2Utils.parseParameterList(scopeStr);
            OAuthUtils.validateScope(scopes, clientDetails.getScope());
        }

        // Validating Resource Id
        if (!clientDetails.getResourceIds().contains(OAuthResources.OIDC.getResourceId())) {
            throw new AccessDeniedException(
                    String.format("client with id: %s does not have access to the requested resource", clientId));
        }

        // checking for username
        if (Utils.isNullOrEmpty(username)) {
            throw new UsernameNotFoundException("unauthorized access");
        }

        // validating TOTP against regex
        if (Utils.isNullOrEmpty(totp)) {
            EventLogger.log(EventId.RelidAuthServer.TOTP_VALIDATION_FAILED, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), username, "totp is null or empty");
            throw new IllegalArgumentException("totp is null or empty");
        } else if (!totp.matches("^[0-9]+$") || totp.length() != com.uniken.totp.utils.Constants.TOTP_LENGTH) {
            EventLogger.log(EventId.RelidAuthServer.TOTP_VALIDATION_FAILED, Utils.getClientIpAddress(request),
                    request.getAttribute(Constants.REQUESTOR_ID).toString(), username,
                    "regex validation for TOTP failed");
            throw new IllegalArgumentException("regex validation for TOTP failed");
        }

    }
}
