package com.uniken.authserver.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.uniken.authserver.repo.api.UserAuthInfoRepo;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;

@Component
public class CustomUserDetailsService
        implements
        UserDetailsService {

    private static final Logger LOG = LoggerFactory.getLogger(CustomUserDetailsService.class);

    @Autowired
    private UserAuthInfoRepo userAuthInfoRepoImpl;

    @Override
    public UserDetails loadUserByUsername(final String username) throws UsernameNotFoundException {

        LOG.info("loadUserByUsername() :  Load user details by Username: {} ", username);

        if (username == null || username.trim().length() == 0) {
            throw new UsernameNotFoundException("Null / empty username provided : " + username);
        }

        final UserAuthInfoVO userInfoVO = userAuthInfoRepoImpl.fetchUserDetailsFromLoginId(username);

        return getUserDetails(userInfoVO);
    }

    /**
     * This method will take UserAuthInfoVO object to convert in into
     * userDetails object
     * 
     * @param userVo
     *            : UserAuthInfoVO's object
     * @return : UserDetail's object
     */
    private UserDetails getUserDetails(final UserAuthInfoVO userVo) {

        if (userVo == null) {
            throw new UsernameNotFoundException("User not found in database");
        }

        final List<GrantedAuthority> authorities = new ArrayList<>();
        authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
        return new User(userVo.getUserId(), "", authorities);
    }

}
