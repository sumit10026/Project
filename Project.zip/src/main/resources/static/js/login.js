//FIXME: demo
var globalUsername = "";
var level2AttemptCounter = 0;
var isAlwaysAskForPassword = false;

var Constants = {
	AUTH_TYPE_RELID_VERIFY: "relid-verify",
	AUTH_TYPE_FIDO: "fido",
	AUTH_TYPE_FIDO_PLATFORM: "fido",
	AUTH_TYPE_TOTP: "totp",
	AUTH_TYPE_SMS_OTP: "smsotp",
	AUTH_TYPE_EMAIL_OTP: "emailotp",
	AUTH_TYPE_PASS: "pass"
};

var authPassType;

function userPortalLogin() {
	window.location = "user-portal";
}

function submitForgotUsername(){
	
	$("#forgotUserNameLoader").removeClass("d-none");
	$("#forgotUsernameError").addClass("d-none");
	var option = $("#forgotUsernameOption").val().trim();
	var optionInput = $("#forgotUserNameInput").val().trim();
	
	if(option === "Mobile Number" &&  !validateMobileNumber(optionInput)){
		$("#forgotUserNameLoader").addClass("d-none");
		$("#forgotUsernameError").text("Enter valid mobile number").removeClass("d-none");
		return;
	}else if(option === "Email Address" && !validateEmailAddress(optionInput)){
		$("#forgotUserNameLoader").addClass("d-none");
		$("#forgotUsernameError").text("Enter valid Email Address").removeClass("d-none");
		return;
	}
	
	var data = {
		option: option,
		optionInput: optionInput,
		success: successForgotUser,
		error: handleForgotUserError
	}
	SDK.submitForgotUsernameData(data);
}

function successForgotUser(response){
	$("#forgotUserNameLoader").addClass("d-none");
	if(response === "Username Sent"){
		changeForgotUsernameInputField();
		$("#forgotUsernameDiv").addClass("d-none");
		$("#successSentUserNameDiv").removeClass("d-none");
	}else{
		$("#forgotUsernameError").text(response).removeClass("d-none");
	}
}

function handleForgotUserError(response){
	$("#forgotUserNameLoader").addClass("d-none");
	$("#forgotUsernameError").text(response).removeClass("d-none");
}

function validateMobileNumber(mobNo){
	if(mobNo.length == 10){
		const reg = new RegExp('^[0-9]+$');
		return reg.test(mobNo);
	}else{
		return false;
	}
}

function validateEmailAddress(emaiId){
	const reg = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9])+$/;
  	return reg.test(emaiId);
}

function forgotUsernamePortol() {
	$("#SignIn_Div").addClass("d-none");
	$("#forgotUsernameDiv").removeClass("d-none");
	$("#successSentUserNameDiv").addClass("d-none");
	changeForgotUsernameInputField();
}

function navigateToLoginPage(){
	$("#successSentUserNameDiv").addClass("d-none");
	$("#forgotUsernameDiv").addClass("d-none");
	$("#SignIn_Div").removeClass("d-none");
}

function changeForgotUsernameInputField(){
	$("#forgotUserNameInput").val("");
	$("#forgotUsernameError").text("").addClass("d-none");
    var forgotUsernameOption = $("#forgotUsernameOption option:selected").text();
    if($("#forgotUsernameOption").val() === "Mobile Number"){
		$("#forgotUserNameInput").attr("maxLength", "10");
	}else{
		$("#forgotUserNameInput").removeAttr("maxLength");
	}
    $("#fogotUsernameInputLable").text(forgotUsernameOption);
    $("#forgotUserNameInput").attr("placeholder","Enter "+forgotUsernameOption);
}

$('#forgotUsernameOption').change(
        function () {
			changeForgotUsernameInputField();
        });

jQuery(document).ready(function () {

	/*if ("" !== window.location.search && (errors = decodeURIComponent(window.location.search).match(
		"error_description=([\\w ]+)")) !== undefined) {

	if(errors.length > 0) {
		error = errors[1];        		
	}
	if (error) {
		// reset URL
		window.history.replaceState(null, null, window.location.pathname);
	}
}

if (typeof error !== "undefined") {
	$("#errorDiv").text(error).removeClass("d-none");
}*/
	var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
	SDK.init({Token: token, Header: header}); 
    
	getConfigs();

	function userPortalLogin() {
		var url = "user-portal";
		window.location.href = url;
	}

	function pending(state) {
		// console.log('Pending:' + state)
		jQuery('.spinner').removeClass('red')

		//jQuery('.spinner-text.pending').fadeIn(400)
		jQuery('.spinner-text.error').hide()
		jQuery('.spinner-text.success').hide()
		jQuery('#testmodal').modal(state)
	}

	function error(err) {
		// console.log('Err: ' + JSON.stringify(err))
		jQuery('.spinner').addClass('red')
		jQuery('.spinner-text.pending').hide()

		console.log(jQuery('.spinner-text.error'));
		console.log(jQuery('.spinner-text.error')[0]);
		console.log(jQuery('.spinner-text.error')[0].innerHTML);
		console.log(jQuery('.spinner-text.error').outerText);
		if (err.error === 'Fradulent login attempt recorded!')
			jQuery('.spinner-text.error')[0].innerHTML = err.error + ", please click to continue";
		jQuery('.spinner-text.error').fadeIn(400)
		jQuery('.spinner-text.success').hide()
		jQuery('#testmodal').one("click", function () {
			console.log('error')
			pending('hide')
		})
	}


	function success(result, status, xhr) {
		console.log('Success: ' + JSON.stringify(result))
		if (result.type === 'error') {
			error(result);
			return;
		}
		jQuery('.spinner-text.pending').hide()
		jQuery('.spinner-text.error').hide()
		jQuery('.spinner-text.success').fadeIn(400)
		setTimeout(function () {
			pending('hide')
			var url = document.URL;
			var shortUrl = url.substring(0, url.lastIndexOf("/"));
			window.location.href = shortUrl + '/' + result.redirect + '?' + jQuery('#username').val();
		}, 1000)
	}

	// jQuery('#username').keypress(function (e) {
	// 	if (e.which == 13 || event.keyCode == 13) {
	// 		jQuery("#submit-to-demo").trigger("click");
	// 		return false;
	// 	}
	// });

	$("#totp_auth_form").keypress(function (e){
		if (e.which == 13 || event.keyCode == 13) {
			jQuery("#totpSubmitButton").trigger("click");
			return false;
		}
	})

	$("#password_sign_in_form").keypress(function (e){
		if (e.which == 13 || event.keyCode == 13) {
			jQuery("#signin").trigger("click");
			return false;
		}
	})

	$("#fido_submit_form").keypress(function (e){
		if (e.which == 13 || event.keyCode == 13) {
			jQuery("#fidoSubmit").trigger("click");
			return false;
		}
	})

	$("#two_factor_auth_form").keypress(function (e){
		if (e.which == 13 || event.keyCode == 13) {
			jQuery("#just_load_please").trigger("click");
			return false;
		}
	})

	$("#two_factor_auth_sms_form").keypress(function (e){
		if (e.which == 13 || event.keyCode == 13) {
			jQuery("#two_factor_auth_sms_submit").trigger("click");
			return false;
		}
	})

	$("#two_factor_auth_email_form").keypress(function (e){
		if (e.which == 13 || event.keyCode == 13) {
			jQuery("#two_factor_auth_email_submit").trigger("click");
			return false;
		}
	});
	
	$("#forgot_username_form_id").keypress(function (e){
		if (e.which == 13 || event.keyCode == 13) {
			jQuery("#forgotUsernameSubmit").trigger("click");
			return false;
		}
	});
	
})

$(document).ready(function () {
	$(':input:enabled:visible:first').focus();
})

function getConfigs() {
	var configObj = { success: configSuccess, error: configError }
	SDK.getConfigs(configObj);
}

var accounts = [];
var isRememberMeEnabled = false;
function configSuccess(data) {
	
	$(".body-spinner").addClass("hide");
	$(".bodybg .container1").removeClass("hide");

	isRememberMeEnabled = data.configuration.rememberMe;
	
	if (data.configuration.rememberMe === false) {
		$('.rememberMeIdDiv').remove();
	} else {
		//$('.rememberMeIdDiv').removeClass("d-none");
	}
	
	isAlwaysAskForPassword = data.configuration.alwaysAskForPassword;
	if (data.configuration.alwaysAskForPassword === false) {
		$('#passwordDiv').addClass("d-none");
		$('#forgotPasswordLink').addClass("d-none");
			$('.rememberMeIdDiv').addClass("d-none");
	} else {
		$('#passwordDiv').removeClass("d-none");
		$('#forgotPasswordLink').removeClass("d-none");
			$('.rememberMeIdDiv').removeClass("d-none");
	}

	if (typeof data.accounts !== 'undefined' && data.accounts.length > 0) {
		$('#SignIn_Div').addClass("d-none");
		$('#LoginWithSelectAccountDiv').removeClass("d-none");
		accounts = data.accounts;
		$(':input:enabled:visible:first').focus();
		var ul = $('<ul id="accList"/>');
		$.each(data.accounts, function (index, value) {
			var username = data.accounts[index].userName;
			var userId = data.accounts[index].userId;
			// var email = data.accounts[index].email;
			
			var onclickForAcc = 'handleClickOnUserName("' + userId + '")';
			ul.append(`<li><a href="#" style="background-color: #f3f7f9;">
                                                    <p class="cursor-pointer" onclick="handleClickOnUserName('${userId}')">${username}</p>
                                                    <p class="cursor-pointer" onclick="handleClickOnUserName('${userId}')">${userId}</p>
                                                    <div class="actiondiv">
                                                        <i class="fa fa-angle-right" aria-hidden="true" onclick="handleClickOnUserName('${userId}')"></i>
                                                        <i class="fa fa-trash-o" aria-hidden="true" onclick="deleteAccountFromChooser('${userId}')"></i>
                                                    </div>
                                                </a></li>`);
		});
		$("#useraccount").prepend(ul);
	} else {
		accounts = [];
		navigateToSignIn();
	}
}

function configError() {
	console.log("Error ::: ");
}

var isUserSelectedRememberMe = false;
$('input.rememberMe').on('change', function () {
	$('input.rememberMe').prop('checked', this.checked);
	isUserSelectedRememberMe = this.checked;
});


function handleClickOnUserName(name) {
	$("#accountErrorMsg").text("").addClass("d-none");
	$("#loginErrorMsg").text("").addClass("d-none");
	$("#accountMsg").text("").addClass("d-none");

	if (accounts.length > 0) {
		$('#go-back-signin').removeClass("d-none");
		$(':input:enabled:visible:first').focus();
	}

	if(isAlwaysAskForPassword){

		$('#LoginWithSelectAccountDiv').addClass("d-none");
		$('#SignIn_Div').removeClass("d-none");
		$('#username').val(name).attr("disabled", true);
		username = name;
		if (isProcessUsernameClick) {
			$('.rememberMeIdDiv').addClass("d-none");
		}

		$('#go-back-signin').addClass("d-none");
		$('#pwdGoBack').removeClass("d-none");
		$('#pwdGoBack').attr("onclick", 'navigateBackToUserSelection()');
		
		return false;
	}
	
	if (isProcessUsernameClick) {
		$('#LoginWithSelectAccountDiv').addClass("d-none");
		$('#username').val(name);
		username = name;
		$('.rememberMeIdDiv').addClass("d-none");
		submitUserInfo();
		$('#totpGoBack').attr("onclick", 'goBack("LoginWithSelectAccountDiv")');
		$('#pwdGoBack').attr("onclick", 'goBack("LoginWithSelectAccountDiv")');
		return false;
	} else {
		isProcessUsernameClick = true;
	}
}

function navigateToSignIn() {
	$('#LoginWithSelectAccountDiv').addClass("d-none");
	$('#SignIn_Div').removeClass("d-none");

	if (accounts.length > 0) {
		$('#go-back-signin').removeClass("d-none");
	}

	$('#username').val("").attr("disabled", false);
	//$('.rememberMeIdDiv').removeClass("d-none");
	$(':input:enabled:visible:first').focus();
}

function navigateBackToSignIn() {
	$("#accountErrorMsg").text("").addClass("d-none");
	$("#loginErrorMsg").text("").addClass("d-none");
	$("#accountMsg").text("").addClass("d-none");

	navigateToSignIn();
	/*$('#LoginWithSelectAccountDiv').addClass("d-none");
	$('#SignIn_Div').removeClass("d-none");

	if (accounts.length > 0) {
		$('#go-back-signin').removeClass("d-none");
	}

	$('#username').val("");*/
}

function navigateBackToUserSelection() {
	$("#loginErrorMsg").text("").addClass("d-none");
	$("#accountErrorMsg").text("").addClass("d-none");
	$("#signInError").text("").addClass("d-none");
	$("#accountMsg").text("").addClass("d-none");

	$('#SignIn_Div').addClass("d-none");
	$('#LoginWithSelectAccountDiv').removeClass("d-none");
	$('#pwdGoBack').addClass("d-none");
}

var username = '';
var password;
function handleUserNameSubmit() {
	$("#loginErrorMsg").text("").addClass("d-none");
	$("#accountErrorMsg").text("").addClass("d-none");
	$("#accountMsg").text("").addClass("d-none");

	username = $('#username').val();
	password = $('#password').val();
	$.each(accounts, function (index, value) {
		if( username == accounts[index].userId){
			$('.rememberMeIdDiv').addClass("d-none");
		}
		});
	if(authPassType == "pass" || (isAlwaysAskForPassword && password.trim())  )
		{ submitPASS(); }
	else
		{ 
			submitUserInfo();
			if(isRememberMeEnabled){
				$('.rememberMeIdDiv').removeClass("d-none");
			}
		}
	
	$('#totpGoBack').attr("onclick", 'goBack("SignIn_Div")');
	$('#pwdGoBack').attr("onclick", 'goBack("SignIn_Div")');
}

var authType;
function submitUserInfo() {
	
	if((isAlwaysAskForPassword && password.trim() == "") || authPassType=="pass"){
		if (! password.trim()) {
			$("#signInError").text("Enter valid password").removeClass("d-none");
		}
		authType='pass';
		}
	
	if (username.trim()) {
		var data = {
			username: username,
			authValue: password,
			authType: authType,
			success: successValidateUser,
			error: handleValidateUserError
		}
		SDK.submitUserInfo(data);
		globalUsername = username;
	} else {
		$("#signInError").text("Enter valid username").removeClass("d-none");
	}
}

var isAllLevel1AuthTypesOffered = false;
function successValidateUser(response) {
	$("#signInError").text("").addClass("d-none");

	validatedAuthTypes = response.authTypes;
	updateValidationAttemptCounter(response.attempts);
	updateGenerationAttemptCounter(response.authGenerationAttemptsCounter)
	isAllLevel1AuthTypesOffered = response.allLevel1AuthTypesOffered;

	switch (validatedAuthTypes[0]) {
		case Constants.AUTH_TYPE_TOTP:
			$('#SignIn_Div').addClass("d-none");
			$('#MobileLogInDiv').removeClass("d-none");
			$('#totpUsername').val(username).attr("disabled", true);
			$("#totpAttemptCount").text("Attempts Left : " + response.attempts).removeClass("d-none");
			$(':input:enabled:visible:first').focus();
			break;
		
		case Constants.AUTH_TYPE_PASS:
			$('#MobileLogInDiv').addClass("d-none");
			$('#SignIn_Div').removeClass("d-none");
			$('#username').val(globalUsername).attr("disabled", true);
			$('#passwordDiv').removeClass("d-none");
			$('#forgotPasswordLink').removeClass("d-none");
			$("#passAttemptCount").text("Attempts Left : " + response.attempts).removeClass("d-none");
			authPassType='pass';
			$("#go-back-signin").addClass("d-none");
			$('#pwdGoBack').removeClass("d-none");
			$('#userPortalDiv').addClass("d-none");
			$(':input:enabled:visible:first').focus();
			break;

		case Constants.AUTH_TYPE_RELID_VERIFY:
			authenticateRelIdVerify('SignIn_Div');
			$(':input:enabled:visible:first').focus();
			break;

		case Constants.AUTH_TYPE_FIDO:
			navigateToFido('SignIn_Div');
			break;

		case Constants.AUTH_TYPE_FIDO_PLATFORM:
			navigateToFido('SignIn_Div');
			break;	

		case Constants.AUTH_TYPE_SMS_OTP:
			navigateToSmsOtp('SignIn_Div');
			break;

		case Constants.AUTH_TYPE_EMAIL_OTP:
			navigateToEmailOtp('SignIn_Div');
			break;
	}
}

function submitPASS() {
	
	if((isAlwaysAskForPassword && password.trim()) || authPassType=="pass"){
		if (!password.trim()) {
			$("#passError").text("Enter valid password").removeClass("d-none");
		}
		authType='pass';
		}
	
	if (username.trim()) {
		var data = {
			username: username,
			authValue: password,
			authType: authType,
			success: successValidateUser,
			error: handlePassError
		}
		SDK.submitUserInfo(data);
		globalUsername = username;
	} else {
		$("#passError").text("Enter valid username").removeClass("d-none");
	}
}


function handlePassError(response) {
	$("#passError").text(response.error).removeClass("d-none");
	$("#passError").text(response.error).show();
	 setTimeout(function() {
		 $("#passError").fadeOut();}, 3000);
	 
	updateValidationAttemptCounter(response.attempts);
	$('#password').val("");

	$("#passAttemptCount").text("Attempts Left : " + response.attempts).removeClass("d-none");
}

function updateValidationAttemptCounter(validationCounter){
	if(validationCounter !== undefined){
		level2AttemptCounter = validationCounter;
	}
}

function updateGenerationAttemptCounter(generationCounter){
	if(generationCounter !== undefined){
		generationAttemptCounter = generationCounter;
	}
}

function needOtherSignInButtonDisabled(){
	var totalAuthType = 0;
	Object.keys(generationAttemptCounter).forEach(function (entry) {
        if(generationAttemptCounter[entry] > 0){
            totalAuthType = totalAuthType + 1;
        }
    });
	return totalAuthType == 1 ? true : false;
}

function evalCurrentAuthTypeForOtherSignIn(authType){
	if(generationAttemptCounter[authType] > 0 && needOtherSignInButtonDisabled()){
		return true;
	}
	return false;
}

function needOtherSignInButtonEnabled(authType){
	var totalAuthType = 0;
	Object.keys(generationAttemptCounter).forEach(function (entry) {
        if(generationAttemptCounter[entry] > 0){
            totalAuthType = totalAuthType + 1;
        }
    });

	if(totalAuthType > 1){
		return true;
	}else if(totalAuthType == 1 && generationAttemptCounter[authType] < 1){
		return true;
	}

	return false;
}

function navigateToAuthFactorScreen(validateAuthType){
	switch (validateAuthType) {
		case Constants.AUTH_TYPE_TOTP:
			navigateToTotp('SignInoptionDiv', 0);
			break;

		case Constants.AUTH_TYPE_RELID_VERIFY:
			authenticateRelIdVerify('SignInoptionDiv');
			break;

		case Constants.AUTH_TYPE_FIDO:
			navigateToFido('SignInoptionDiv');
			break;

		case Constants.AUTH_TYPE_SMS_OTP:
			navigateToSmsOtp('SignInoptionDiv');
			break;

		case Constants.AUTH_TYPE_EMAIL_OTP:
			navigateToEmailOtp('SignInoptionDiv');
			break;
	}
}

function navigateToTotp(hideElementId, attempts) {
	$('#' + hideElementId).addClass("d-none");
	$('#MobileLogInDiv').removeClass("d-none");
	$('#totpUsername').val(username).attr("disabled", true);
	$("#totpAttemptCount").text("Attempts Left : " + attempts).removeClass("d-none");
}

function handleValidateUserError(response) {
	$("#signInError").text(response.error).removeClass("d-none");
}

function submitTOTP() {
	var username = $('#totpUsername').val();

	//Clear Error Messages
	$('#totpError').text("").removeClass("d-none");
	$('#totpUserError').text("").removeClass("d-none");
	$('#smsOtpError').text("").removeClass("d-none");
	$('#emailOtpError').text("").removeClass("d-none");

	if (!username.trim()) {
		$("#totpUserError").text("Enter valid username").removeClass("d-none");
		return;
	}

	var totp = $('#exampleInputPassword1').val();
	if (!totp.trim()) {
		$("#totpError").text("Enter valid TOTP").removeClass("d-none");
		return;
	}

	var data = {
		username: username,
		totp: totp,
		success: successValidateOTP,
		error: handleTotpError
	}
	SDK.submitTOTP(data);
}

function handleTotpError(response) {
	$("#totpError").text(response.error).removeClass("d-none");
	$("#totpError").text(response.error).show();
	 setTimeout(function() {
		 $("#totpError").fadeOut();}, 3000);
	 
	updateValidationAttemptCounter(response.attempts);
	$('#exampleInputPassword1').val("");

	$("#totpAttemptCount").text("Attempts Left : " + response.attempts).removeClass("d-none");
}

var validatedAuthTypes = [];
var generationAttemptCounter;
function successValidateOTP(response) {
	validatedAuthTypes = response.authTypes;
	updateValidationAttemptCounter(response.attempts);

	$("#totpError").text("").addClass("d-none");
	$("#totpAttemptCount").text("").addClass("d-none");

	switch (response.authTypes[0]) {
		case Constants.AUTH_TYPE_RELID_VERIFY:
			authenticateRelIdVerify('MobileLogInDiv');
			$(':input:enabled:visible:first').focus();
			break;

		case Constants.AUTH_TYPE_FIDO:
			navigateToFido('MobileLogInDiv');
			$(':input:enabled:visible:first').focus();
			break;

		case Constants.AUTH_TYPE_SMS_OTP:
			navigateToSmsOtp('MobileLogInDiv');
			$(':input:enabled:visible:first').focus();
			break;

		case Constants.AUTH_TYPE_EMAIL_OTP:
			navigateToEmailOtp('MobileLogInDiv');
			$(':input:enabled:visible:first').focus();
			break;
	}

}

function hideVerifyLoader() {
	$('.spinner').removeClass('red');
	$('.spinner-text.error').hide();
	$('.spinner-text.success').hide();
	$('#loaderModal').hide();
	$('#userPortal').show();
	$('.spinner-text.notificationExpired').hide();
	$('#resendNotification').hide();
	$('.spinner-text.or').hide();
	$('.modal-backdrop').hide();
}

function showVerifyLoader() {
	$('.empty-div').addClass('d-none');
	$('.spinner').removeClass('d-none');
	$('.spinner-text.error').hide();
	$('.spinner-text.success').hide();
	$('.spinner-text.fido.pending,.choseVerify').hide();
	$('.spinner-text.verify.pending,.choseTotp').show();
	$('#loaderModal').show()
	$('.close').addClass('d-none');
	$('.spinner-text.notificationExpired').hide();
	$('#resendNotification').hide();
	$('.spinner-text.or').hide();
	$('.modal-backdrop').show();
	$('#userPortal').hide();
	$('#username').attr("disabled", "disabled");
}

function verifyError(errorData) {
	errorData = JSON.parse(errorData);
	$('.modal-backdrop').show();
	$('#loaderModal').show()
	$('.spinner').addClass('d-none');
	$('.empty-div').removeClass('d-none');
	$('.spinner-text.pending').hide();
	$('.spinner-text.success').hide();
	$('.spinner-text.notificationExpired').hide();
	$('#resendNotification').hide();
	$('.spinner-text.or').hide();
	if (errorData.error_description) {
		$('.spinner-text.error').html("");
		$('.spinner-text.error').html(errorData.error_description);
	}
	$('.spinner-text.error').show();

	updateValidationAttemptCounter(errorData.attempts);
	$("#relidVerifyAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");
}

function timeOut() {
	$('#loaderModal').show()
	$('.spinner').addClass('d-none');
	$('.empty-div').removeClass('d-none');
	$('.spinner-text.pending').hide();
	$('.spinner-text.success').hide();
	$('.spinner-text.notificationExpired').show();
	$('.spinner-text.or').show();
	$('.close').removeClass('d-none');
	$('.modal-backdrop').show();
	
	if(!isRVNGenerationCounterExceeded){
		$('#resendNotification').show();
	}
}

function authenticateRelIdVerify(hideElementId) {
	$('#' + hideElementId).addClass("d-none");
	$('#RelidVerifyLogInDiv').removeClass("d-none");
	$('#relIdSubmit').prop('disabled', true);
	$('#relidUsername').val(globalUsername);
	$('#relidUsername').prop('disabled', true);
	$('#relidMsgDiv').removeClass("d-none");
	
	$.each(accounts, function (index, value) {
		if( username == accounts[index].userId){
			$('.rememberMeIdDiv').addClass("d-none");
		}
		});

	if (typeof validatedAuthTypes !== 'undefined' && validatedAuthTypes.length > 1 
		&& needOtherSignInButtonEnabled("RELID_VERIFY")) {
			$('#relidGoBack').removeClass("d-none");
			$('#otherSignInLink').removeClass("d-none");
	}else{
		$('#relidGoBack').addClass("d-none");
		$('#otherSignInLink').addClass("d-none");
	}

	$("#relidVerifyAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");

	var verifyLoginArg = {
		username: globalUsername,
		beforeStart: showVerifyLoader,
		onUserAction: hideVerifyLoader,
		error: verifyError,
		onTimeout: timeOut,
		remember_me: isUserSelectedRememberMe,
		onRVNGeneration: onRVNGeneration
	};
	SDK.verifyLogin(verifyLoginArg);
}

function navigateToRelIdVerifyBack(hideElementId) {
	$('#' + hideElementId).addClass("d-none");
	$('#RelidVerifyLogInDiv').removeClass("d-none");
	$('#relIdSubmit').prop('disabled', true);
	$('#relidUsername').val(globalUsername);
	$('#relidUsername').prop('disabled', true);
	$('#relidMsgDiv').removeClass("d-none");

	if (typeof validatedAuthTypes !== 'undefined' && validatedAuthTypes.length > 1 
		&& needOtherSignInButtonEnabled("RELID_VERIFY")) {
			$('#relidGoBack').removeClass("d-none");
			$('#otherSignInLink').removeClass("d-none");
	}else{
		$('#relidGoBack').addClass("d-none");
		$('#otherSignInLink').addClass("d-none");
	}

	$("#relidVerifyAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");
}	

var isRVNGenerationCounterExceeded = false;
function onRVNGeneration(response){
	updateGenerationAttemptCounter(response);
	if(evalCurrentAuthTypeForOtherSignIn("RELID_VERIFY")){
		$('#relidGoBack').addClass("d-none");
		$('#otherSignInLink').addClass("d-none");
	}

	if(response.RELID_VERIFY <= 0){
		$("#resendNotification").hide();
		isRVNGenerationCounterExceeded = true;
	}
}

function goBack(displayElementId) {
	if(displayElementId === "SignIn_Div"){
		$('.rememberMeIdDiv').addClass("d-none");
	}
	else
		$('#SignIn_Div').addClass("d-none");
	
	$('#MobileLogInDiv').addClass("d-none");
	$('#' + displayElementId).removeClass("d-none");
	$('#username').val("").attr("disabled", false);
	$('#totpError').text("").removeClass("d-none");
	$('#totpUserError').text("").removeClass("d-none");
	$('#smsOtpError').text("").removeClass("d-none");
	$('#emailOtpError').text("").removeClass("d-none");
	$('#exampleInputPassword1').val('');	
	$("#passAttemptCount").text("").addClass("d-none");
	
	if (accounts.length > 0) {
		$('#go-back-signin').removeClass("d-none");
	}
	
	$('#pwdGoBack').addClass("d-none");
	$('#userPortalDiv').removeClass("d-none");
	$('#passwordDiv').addClass("d-none");
	$('#forgotPasswordLink').addClass("d-none");
	$('#passError').text("").removeClass("d-none");
	authPassType = '';
}

function navigateToOtherSignInOption(hideElementId, authType, onclickAction) {

	$('#' + hideElementId).addClass("d-none");
	$('#SignInoptionDiv').removeClass("d-none");

	$('#SignInOptionsGoBack').attr("onclick", onclickAction);

	resetOtherSignInOptions(); 

	validatedAuthTypes.forEach((entry) => {
		if (authType !== entry) {
			switch (entry) {
				case Constants.AUTH_TYPE_FIDO:
					if(generationAttemptCounter.FIDO > 0){
						$('#fidoSignIn').removeClass("d-none");
						$("#fidoAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");
					}
					$(':input:enabled:visible:first').focus();
					break;
				case Constants.AUTH_TYPE_RELID_VERIFY:
					if(generationAttemptCounter.RELID_VERIFY > 0){
						$('#relidVerifySignIn').removeClass("d-none");
						$("#relidVerifyAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");
					}
					$(':input:enabled:visible:first').focus();
					break;
				case Constants.AUTH_TYPE_SMS_OTP:
					if(generationAttemptCounter.SMSOTP > 0){
						$('#smsOtpSignIn').removeClass("d-none");
						$("#smsOtpAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");
					}
					$(':input:enabled:visible:first').focus();
					break;
				case Constants.AUTH_TYPE_EMAIL_OTP:
					if(generationAttemptCounter.EMAILOTP > 0){
						$('#emailOtpSignIn').removeClass("d-none");
						$("#emailOtpAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");
					}
					$(':input:enabled:visible:first').focus();
					break;
				default:
					console.log("Unsupported Auth Type : " + entry);
			}
		}
	});
}

function resetOtherSignInOptions() {
	$('#fidoSignIn').addClass("d-none");
	$('#relidVerifySignIn').addClass("d-none");
	$('#smsOtpSignIn').addClass("d-none");
	$('#emailOtpSignIn').addClass("d-none");
	$('#totpError').text("");
	$('#totpUserError').text("");
	$('#smsOtpError').text("");
	$('#emailOtpError').text("");
}

function navigateToFido(hideElementId) {
	$('#' + hideElementId).addClass("d-none");
	$('#LoginWithSecurityDiv').removeClass("d-none");
	$('#fidoUsername').val(globalUsername);
	$('#fidoUsername').prop('disabled', true);
	$('#fidoSubmit').prop('disabled', true);
	$('#retryFido').hide();

	if (typeof validatedAuthTypes !== 'undefined' && validatedAuthTypes.length > 1 
		&& needOtherSignInButtonEnabled("FIDO")) {
			$('#fidoGoBack').removeClass("d-none");
	}else{
		$('#fidoGoBack').addClass("d-none");
	}

	$("#fidoAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");

	var username = $('#fidoUsername').val();
	var fidoLoginArg = {
		username: username,
		success: fidoSuccess,
		error: fidoError,
		onFidoGeneration: onFidoGeneration, 
		remember_me: isUserSelectedRememberMe,
		level1AuthProcessor: level1AuthProcessor
	};

	showFidoLoader();
	SDK.fidoLogin(fidoLoginArg);
	$(':input:enabled:visible:first').focus();
}

function level1AuthProcessor(){
	// Only fallback, if there are any auth types are available
	if(!isAllLevel1AuthTypesOffered){
		$('#LoginWithSecurityDiv').addClass("d-none");
		submitUserInfo();
	}
}

function navigateToFidoBack(hideElementId) {
	$('#' + hideElementId).addClass("d-none");
	$('#LoginWithSecurityDiv').removeClass("d-none");
	$('#fidoUsername').val(globalUsername);
	$('#fidoUsername').prop('disabled', true);
	$('#fidoSubmit').prop('disabled', false);
	$('#retryFido').show();

	if (typeof validatedAuthTypes !== 'undefined' && validatedAuthTypes.length > 1 
		&& needOtherSignInButtonEnabled("FIDO")) {
			$('#fidoGoBack').removeClass("d-none");
	}else{
		$('#fidoGoBack').addClass("d-none");
	}

	$("#fidoAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");
}

function onFidoGeneration(generationCounter){
	updateGenerationAttemptCounter(generationCounter);
	if(evalCurrentAuthTypeForOtherSignIn("FIDO")){
		$('#fidoGoBack').addClass("d-none");
	}
}

function fidoSuccess() {
	alert("FIDO Authentication Successful");
	$("#fidoAttemptCount").text("").addClass("d-none");
}

function hideFidoLoader() {
	$('.spinner').removeClass('red');
	$('.spinner-text.error').hide();
	$('.spinner-text.success').hide();
	$('#loaderModal').hide()
	$('.spinner-text.notificationExpired').hide();
	$('#resendNotification').hide();
	$('.spinner-text.or').hide();
	$('.modal-backdrop').hide();
}

function showFidoLoader() {
	$('.empty-div').addClass('d-none');
	$('.spinner').removeClass('d-none');
	$('.spinner-text.error').hide();
	$('.spinner-text.success').hide();
	$('.spinner-text.verify.pending,.choseTotp').hide();
	$('.spinner-text.fido.pending').show();
	$(".choseVerify").hide()
	$('#loaderModal').show()
	$('.close').addClass('d-none');
	$('.spinner-text.notificationExpired').hide();
	$('#resendNotification').hide();
	$('.spinner-text.or').hide();
	$('.modal-backdrop').show();
}

function fidoError(errorData) {
	$('.spinner-text.fido.pending').hide();
	$('.spinner').addClass('d-none');
	$('.empty-div').removeClass('d-none');
	$('.spinner-text.error').html("Could not perform FIDO login.");
	$('.spinner-text.error').show();
	setTimeout(function() {
		 $('.spinner-text.error').fadeOut();}, 3000);
	$(".choseVerify").show();
	$('#fidoSubmit').prop('disabled', false);

	updateValidationAttemptCounter(errorData.attempts);
	$("#fidoAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");
	$("#retryFido").show();
}

function navigateToSmsOtp(hideElementId) {
	$('#' + hideElementId).addClass("d-none");
	$('#TwofactorAuthenticationSMSDiv').removeClass("d-none");
	$('#smsOtpUsername').val(globalUsername);
	$('#smsOtpUsername').prop('disabled', true);
	$('#smsOtpValue').val("");

	if (typeof validatedAuthTypes !== 'undefined' && validatedAuthTypes.length > 1
		&& needOtherSignInButtonEnabled("SMSOTP")) {
			$('#smsOtpGoBack').removeClass("d-none");
	}else{
		$('#smsOtpGoBack').addClass("d-none");
	}

	$("#smsOtpAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");

	generateSmsOtp($('#smsOtpUsername').val());
	$(':input:enabled:visible:first').focus();
}

function navigateToSmsOtpBack(hideElementId) {
	$('#' + hideElementId).addClass("d-none");
	$('#TwofactorAuthenticationSMSDiv').removeClass("d-none");
	$('#smsOtpUsername').val(globalUsername);
	$('#smsOtpUsername').prop('disabled', true);
	$('#smsOtpValue').val("");

	if (typeof validatedAuthTypes !== 'undefined' && validatedAuthTypes.length > 1
		&& needOtherSignInButtonEnabled("SMSOTP")) {
			$('#smsOtpGoBack').removeClass("d-none");
	}else{
		$('#smsOtpGoBack').addClass("d-none");
	}

	$("#smsOtpAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");
}

function generateSmsOtp(username) {
	//$('#resendSmsOtp').hide();

	var smsUsername = globalUsername;
	if (username) {
		smsUsername = username
	}

	var generateOtpParam = {
		username: smsUsername,
		success: successGenerateSmsOTP,
		error: errorGenerateSmsOTP
	}

	SDK.generateSmsOtp(generateOtpParam);
}

//FIXME : Will Use it in Milestone 2
/*var smsOtpTimeoutConfig = {
	isResendSmsOtpEnabled: true,
	interval: 10000,
	maxRetries: 5
}
var totalRetries = 0;
function handleResendSmsOtp() {
	if (!$('#TwofactorAuthenticationSMSDiv').hasClass("d-none")) {
		if (smsOtpTimeoutConfig.isResendSmsOtpEnabled && totalRetries < smsOtpTimeoutConfig.maxRetries) {
			if ($('#resendSmsOtp').is(":hidden")) {
				console.log('Show resend sms otp');
				console.log(new Date());
				$('#resendSmsOtp').show();
				totalRetries = totalRetries + 1;
			}
			smsOtpTimeoutFn = setTimeout(handleResendSmsOtp, smsOtpTimeoutConfig.interval);
		} else {
			clearInterval(smsOtpTimeoutFn);
			console.log("Retry Exceeded");
			console.log(new Date());
			$('#resendSmsOtp').hide();
		}
	}
}*/

//var smsOtpTimeoutFn;
function successGenerateSmsOTP(response) {
	updateGenerationAttemptCounter(response);
	if(evalCurrentAuthTypeForOtherSignIn("SMSOTP")){
		$('#smsOtpGoBack').addClass("d-none");
	}

	if(response.SMSOTP > 0){
		$("#resendSmsOtpMsg").text("SMS OTP generated successfully.").css("display", "").css("color", "#0093d1").removeClass("d-none");
    	fadeResendSmsOtpMsg();
		$("#resendSmsOtp").hide();
		$("#resendSmsOtpTimeoutMessage").show();
		setTimeout(() => {
			$("#resendSmsOtpTimeoutMessage").hide();
			$("#resendSmsOtp").show();
		}, 10000);
		//smsOtpTimeoutFn = setTimeout(handleResendSmsOtp, smsOtpTimeoutConfig.interval);
	}else{
		$("#resendSmsOtp").hide();
		$("#resendSmsOtpTimeoutMessage").hide();
		$("#resendSmsOtpMsg").addClass("d-none");
	}
}

function errorGenerateSmsOTP(response) {
	console.log("Generate SMS OTP Error : " + response.authTypes);
	$("#resendSmsOtpMsg").text("Failed to generate SMS OTP.").css("display", "").css("color", "red").removeClass("d-none");
	fadeResendSmsOtpMsg();
}

function fadeResendSmsOtpMsg(){
	$("#resendSmsOtpMsg").delay(2000).fadeOut();
}

function authenticateSmsOtp() {
	//Clear Error Messages
	$('#totpError').text("");
	$('#totpUserError').text("");
	$('#smsOtpError').text("");

	var username = $('#smsOtpUsername').val();
	var otp = $('#smsOtpValue').val();
	if (!otp.trim()) {
		$("#smsOtpError").text(response.error).removeClass("d-none");
		$("#smsOtpError").text(response.error).show();
		 setTimeout(function() {
			 $("#totpError").fadeOut();}, 3000);
		 return;
	}

	var data = {
		username: username,
		smsOtp: otp,
		success: successValidateSmsOTP,
		error: handleSmsOtpError,
		remember_me: isUserSelectedRememberMe
	}
	SDK.submitSmsOtp(data);
}

function successValidateSmsOTP(response) {
	updateValidationAttemptCounter(response.attempts);

	$("#smsOtpError").text("").addClass("d-none");
	$("#smsOtpAttemptCount").text("").addClass("d-none");
}

function handleSmsOtpError(response) {
	$("#smsOtpError").text(response.error).removeClass("d-none");
	$("#smsOtpError").text(response.error).show();
	 setTimeout(function() {
		 $("#smsOtpError").fadeOut();}, 3000);
	$('#smsOtpValue').val("");

	updateValidationAttemptCounter(response.attempts);
	$("#smsOtpAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");
}

function navigateToEmailOtp(hideElementId) {
	$('#' + hideElementId).addClass("d-none");
	$('#TwofactorAuthenticationEmailDiv').removeClass("d-none");
	$('#emailOtpUsername').val(globalUsername);
	$('#emailOtpUsername').prop('disabled', true);
	$('#emailOtpValue').val("");

	if (typeof validatedAuthTypes !== 'undefined' && validatedAuthTypes.length > 1
		&& needOtherSignInButtonEnabled("EMAILOTP")) {
			$('#emailOtpGoBack').removeClass("d-none");
	}else{
		$('#emailOtpGoBack').addClass("d-none");
	}

	$("#emailOtpAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");

	generateEmailOtp($('#emailOtpUsername').val());
	$(':input:enabled:visible:first').focus();
}

function navigateToEmailOtpBack(hideElementId) {
	$('#' + hideElementId).addClass("d-none");
	$('#TwofactorAuthenticationEmailDiv').removeClass("d-none");
	$('#emailOtpUsername').val(globalUsername);
	$('#emailOtpUsername').prop('disabled', true);
	$('#emailOtpValue').val("");

	if (typeof validatedAuthTypes !== 'undefined' && validatedAuthTypes.length > 1
		&& needOtherSignInButtonEnabled("EMAILOTP")) {
			$('#emailOtpGoBack').removeClass("d-none");
	}else{
		$('#emailOtpGoBack').addClass("d-none");
	}

	$("#emailOtpAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");
	$(':input:enabled:visible:first').focus();
}

function generateEmailOtp(username) {
	//$('#resendEmailOtp').hide();

	var emailUsername = globalUsername;
	if (username) {
		emailUsername = username
	}

	var generateOtpParam = {
		username: emailUsername,
		success: successGenerateEmailOTP,
		error: errorGenerateEmailOTP
	}

	SDK.generateEmailOtp(generateOtpParam);
}

function successGenerateEmailOTP(response) {
	updateGenerationAttemptCounter(response);
	if(evalCurrentAuthTypeForOtherSignIn("EMAILOTP")){
		$('#emailOtpGoBack').addClass("d-none");
	}

	if(response.EMAILOTP > 0){
		$("#resendEmailOtpMsg").text("Email OTP generated successfully.").css("display", "").css("color", "#0093d1").removeClass("d-none");
    	fadeResendEmailOtpMsg();
		$("#resendEmailOtp").hide();
		$("#resendEmailOtpTimeoutMessage").show();
		setTimeout(() => {
			$("#resendEmailOtpTimeoutMessage").hide();
			$("#resendEmailOtp").show();
		}, 10000);
		//emailOtpTimeoutFn = setTimeout(handleResendEmailOtp, emailOtpTimeoutConfig.interval);
	}else{
		$("#resendEmailOtp").hide();
		$("#resendEmailOtpTimeoutMessage").hide();
		$("#resendEmailOtpMsg").addClass("d-none");
	}
}

function errorGenerateEmailOTP(response) {
	$("#resendEmailOtpMsg").text("Failed to generate EMAIL OTP.").css("display", "").css("color", "red").removeClass("d-none");
	fadeResendEmailOtpMsg();
}

function fadeResendEmailOtpMsg(){
	$("#resendEmailOtpMsg").delay(2000).fadeOut();
}

function authenticateEmailOtp() {
	//Clear Error Messages
	$('#totpError').text("");
	$('#totpUserError').text("");
	$('#emailOtpError').text("");

	var username = $('#emailOtpUsername').val();
	var otp = $('#emailOtpValue').val();
	if (!otp.trim()) {
		$("#emailOtpError").text("Enter valid EMAIL OTP").removeClass("d-none");
		return;
	}

	var data = {
		username: username,
		emailOtp: otp,
		success: successValidateEmailOTP,
		error: handleEmailOtpError,
		remember_me: isUserSelectedRememberMe
	}
	SDK.submitEmailOtp(data);
}

function successValidateEmailOTP(response) {
	updateValidationAttemptCounter(response.attempts);

	$("#emailOtpError").text("").addClass("d-none");
	$("#emailOtpAttemptCount").text("").addClass("d-none");
}

function handleEmailOtpError(response) {
	$("#emailOtpError").text(response.error).removeClass("d-none");
	$("#emailOtpError").text(response.error).show();
	 setTimeout(function() {
		 $("#emailOtpError").fadeOut();}, 3000);
	 
	$('#emailOtpValue').val("");

	updateValidationAttemptCounter(response.attempts);
	$("#emailOtpAttemptCount").text("Attempts Left : " + level2AttemptCounter).removeClass("d-none");
}

var isProcessUsernameClick = true;
function deleteAccountFromChooser(accountName) {
	$("#accList").remove();
	SDK.deleteAccFromChooser({
		username: accountName,
		success: handleDeleteAccSuccess,
		error: function (response) { console.log(response.error); }
	});

	isProcessUsernameClick = false;
}

var deleteAccMsg = "";
function handleDeleteAccSuccess(response) {
	getConfigs();
	$("#accountMsg").text(response.success).removeClass("d-none").css("color", "blue");
}

function handleDeleteAccError(response) {
	$("#accountMsg").text(response.error).removeClass("d-none").css("color", "red");
}