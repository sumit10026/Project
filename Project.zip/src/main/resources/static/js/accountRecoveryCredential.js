var configs = {};
var mobileNumberRegex;
var emailRegex;
var passPolicy;
var jspenc;
var waitingDelayBeforeRedirect;
var browserAndLocationInfo;
let user = {
    mobileNumber: "",
    emailId: "",
};

var Constants = {
	AUTH_TYPE_FIDO: "fido",
	AUTH_TYPE_SMS_OTP: "smsotp",
	AUTH_TYPE_EMAIL_OTP: "emailotp",
	AUTH_TYPE_PASS: "pass"
};

$(document).ready(function () {
    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    SDK.init({
        Token: token,
        Header: header,
        fidoConfig: {
            attestationOptionUri: "register/attestation/options",
            attestationResultUri: "register/attestation/result"
        }
    });

    var obj = {
        success: getConfigs
    };
    SDK.invokeRegisterConfigs(obj);

    fetchPublicKey();

    // Enable and disable register button
    $("#rp_confirm_password, #rp_password").keyup(function () {
        enableRpPasswordButton();
    });

    // Reset User Password
    $("#rp_register_button").click(() => {

        $("#rp_password_error_div").addClass("d-none");

        var password = $("#rp_password").val();

        if (!isValidPassword(password)) {
            $("#rp_password_error_div").removeClass("d-none");
            $("#rp_password_error_div label").text(passPolicy.msg)
            $("#rp_password").val("");
            $("#rp_confirm_password").val("");

            return;
        }

        let data = {
            username: $("#rp_username").val(),
            auth_type: Constants.AUTH_TYPE_PASS,
            auth_value: getPass(password),
            web_device_parameters: JSON.stringify(browserAndLocationInfo.browser)
        };

        resetCredential(data);
    });

});

function resetCredential(data) {
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "account-recovery-credential/reset-credential",
        data: JSON.stringify(data),
        success: (res) => {
            $("#password-reset").addClass("d-none");
            submitARCForm();
        },
        error: (err) => {
            if (err.status == "422") {
                $("#rp_password_error_div").removeClass("d-none");
                $("#rp_password_error_div label").text(passPolicy.msg)
                $("#rp_password").val("");
                $("#rp_confirm_password").val("");
            } else {
                window.location = "error";
            }
        },
    });
}

function fetchPublicKey() {

    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "account-recovery-credential/fetchPublicKey",
        success: (res) => {
            jspenc = new JSEncrypt();
            jspenc.setPublicKey("-----BEGIN PUBLIC KEY-----\n" + res + "\n-----END PUBLIC KEY-----");
        },
        error: (err) => {
            window.location = "error";
        },
    });

}

function getResetCredentialFactor(){
    $.ajax({
        type: "GET",
        contentType: "application/json",
        url: "account-recovery-credential/get-reset-credential-factor?arc-token="+arcToken,
        success: (res) => {
            var resetCredentialFactor = res.resetCredentialFactor;
            var username = res.username;
            showResetCredentialFactor(resetCredentialFactor, username);
        },
        error: (err) => {
            window.location = "error";
        },
    })
}

function submitARCForm(){
    $("#account-recovery-success").removeClass("d-none");
    setTimeout(() => { $("#submitARC").submit(); }, waitingDelayBeforeRedirect);
}

function showResetCredentialFactor(resetCredentialFactor, username){
    if(resetCredentialFactor && resetCredentialFactor.size > 1){
        window.location = "error";
    }else if(resetCredentialFactor.length == 1 && resetCredentialFactor[0] == Constants.AUTH_TYPE_PASS){
        $("#rp_username").val(username);
        $("#password-reset").removeClass("d-none");
    }      
}

function enableRpPasswordButton() {

    let password = $("#rp_password").val();
    let confirmPassword = $("#rp_confirm_password").val();

	if (password.length == 0 || password != confirmPassword || !isValidPassword(password))
		$("#rp_register_button").prop("disabled", true);
	else $("#rp_register_button").prop("disabled", false);
}

function showRpPasswordStrength() {
	
    let password = $("#rp_password").val();

	$(".progress-bar").parent().removeClass("d-none");

	if (!isValidPassword(password)) {
		$(".progress-bar").attr("aria-valuenow", 100);
		$(".progress-bar").addClass("bg-danger");
		$(".progress-bar").prop("style").width = '100%';
		return;
	} else {
		let l = (passPolicy.maxL - passPolicy.minL) / 3;
		if (password.length <= (passPolicy.minL + l + 1)) {
			$(".progress-bar").attr("aria-valuenow", 33);
			$(".progress-bar").removeClass("bg-danger bg-success bg-info");
			$(".progress-bar").addClass("bg-warning");
			$(".progress-bar").prop("style").width = '33%';
			return;
		}
		if (password.length <= (passPolicy.minL + (l * 2))) {
			$(".progress-bar").attr("aria-valuenow", 66);
			$(".progress-bar").removeClass("bg-danger bg-success bg-warning");
			$(".progress-bar").addClass("bg-info");
			$(".progress-bar").prop("style").width = '66%';
			return;
		}
		$(".progress-bar").attr("aria-valuenow", 100);
		$(".progress-bar").removeClass("bg-danger bg-warning bg-info");
		$(".progress-bar").addClass("bg-success");
		$(".progress-bar").prop("style").width = '100%';
		return;

	}

}

function isValidPassword(val, u) {
    if (!passPolicy) {
        return true;
    }

    return val.length >= passPolicy.minL && val.length <= passPolicy.maxL && passPolicy.minLc.test(val) && passPolicy.minUc.test(val) && passPolicy.minDg.test(val) && passPolicy.minSc.test(val) && !passPolicy.rep.test(val) && (!passPolicy.userIdcheck || val.indexOf(u) < 0)
}

function getConfigs() {

    browserAndLocationInfo = SDK.getBrowserAndLocationInfo();

    var data = {
        "web_device_parameters": JSON.stringify(browserAndLocationInfo.browser)
    };

    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "account-recovery-credential/configs",
        data: JSON.stringify(data),
        success: (res) => {
            configs = res;

            if (!configs) {
                return;
            }

            username = configs.username;
            $("#rp_username").val(username);
            user.mobileNumber = configs.mobileNumber;
            user.emailId = configs.email;

            if (configs.configuration) {
                if (configs.configuration.mobileNumberRegex) {
                    mobileNumberRegex = new RegExp("^" + configs.configuration.mobileNumberRegex + "$");
                }

                if (configs.configuration.emailRegex) {
                    emailRegex = new RegExp("^" + configs.configuration.emailRegex + "$");
                }

                waitingDelayBeforeRedirect = configs.configuration.delayBeforeRedirect;											

                if (configs.configuration.passPolicy) {
                    passPolicy = {
                        minL: configs.configuration.passPolicy.minL,
                        maxL: configs.configuration.passPolicy.maxL,
                        minLc: getReg('[a-z]', configs.configuration.passPolicy.minLc),
                        minUc: getReg('[A-Z]', configs.configuration.passPolicy.minUc),
                        minSc: getReg('[^a-zA-Z0-9]', configs.configuration.passPolicy.minSc),
                        minDg: getReg('\\d', configs.configuration.passPolicy.minDg),
                        rep: getReg('(.)\\1', configs.configuration.passPolicy.Repetition),
                        userIdcheck: configs.configuration.passPolicy.UserIDcheck,
                        msg: configs.configuration.passPolicy.msg
                    }

                    $("#pass-policy-tooltip").prop("title", passPolicy.msg).removeClass("d-none");
                        
                    $(function () {
                        $('[data-toggle="tooltip"]').tooltip();
                    });

                   if (configs.configuration.showPassStrength) {
                        $("#rp_password").keyup(function () {
                            showRpPasswordStrength();
                        });
                    }
                }

            }

            //Getting list of resetCredentialFactors
            getResetCredentialFactor();

        },
        error: (err) => {
            window.location = "error";
        },
    });

}

function getReg(reg, len) {
    return new RegExp(reg + "{" + len + "}");
}

function getPass(pass) {
    if (!jspenc) {
        return;
    }

    return jspenc.encrypt(pass);
}