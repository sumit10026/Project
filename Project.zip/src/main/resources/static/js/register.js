$(document).ready(function () {
	
  $('#fidoIcon').attr('src', getFidoIconByPlatform());
  
  	var isNonResidentFlow = false;

    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    
	SDK.init({Token: token, Header: header});
	
	var fidoRegistrationInfo = {

		username: $("#username").val(),
		success: () => {
			$("#fidoPending").hide();
			$("#fidoStatus").removeClass("d-none")
			$("#fidoStatus h3").text(isNonResidentFlow ? deviceRoamingRegistrationSuccessMsg : deviceRegistrationSuccessMsg);
		},
		error: (error) => {

			if (!isNonResidentFlow) {
				fidoAuthentication($("#username").val());
			} else {
				$("#fidoPending").hide();
				$("#fidoStatus,#fidoRetry").removeClass("d-none");
				$("#fidoStatus h3").text(error + ". " + deviceRegistrationNotRegisterMsg);
			}
		}
	};
    
	function validateFidoRegistrationSameBrowser(username) {
		var fidoValdationArg = {
			username: username,
			success: fidoRegistrationSucess
		};
		SDK.validateFidoRegistrationSameBrowser(fidoValdationArg);
	}    
    
	function fidoAuthentication(username) {

		var fidoLoginArg = {
			username: username,
			success: fidoSuccess,
			error: fidoError,
			remember_me: false

		};
		$("#fidoStatus h3").text(deviceAuthenticationMsg);
		SDK.validateFidoCredential(fidoLoginArg);
	}

	function fidoRegistrationSucess(data) {
		if (data == "true") {
			$("#fidoAuthSelection").modal();
			$('#fidoPlatformAuthBtn').prop('disabled', true);
		}
		else {
			$("#fidoAuthSelection").modal();
			$('#fidoPlatformAuthBtn').removeAttr('disabled');
		}
	}

function fidoError(error) {
	console.log("fidoError function.");
	$("#fidoPending").hide();
	$("#fidoStatus,#fidoRetry").removeClass("d-none");
	$("#fidoStatus h3").text(unableToPerformFIDORgistrationMsg+" "+deviceRegistrationNotRegisterMsg);
}

function fidoSuccess() {
	console.log("fidoSuccess function.");
	$("#fidoPending").hide();
	$("#fidoStatus").removeClass("d-none")
	$("#fidoStatus h3").text(deviceEnrollmentSuccessMsg);
}

	$("#register").click(function() {
		//Disable support of Platform Authenticator
		/*if (SDK.isFidoPlatformAuthenticatorAvailable()) {
			validateFidoRegistrationSameBrowser($("#username").val());
		} else {
			$("#fidoNonPlatformAuthBtn").click();
		}*/
		$("#fidoNonPlatformAuthBtn").click();
	});

    $("#fidoPlatformAuthBtn").click(function () {
		isNonResidentFlow = false;
        $("#fidoPending").hide();
        $("#fidoStatus").removeClass("d-none")
        $("#fidoStatus h3").text(deviceRegistrationWaitMsg);
        fidoRegistrationInfo.registrationOptions = {
			userVerification: "required",
			requireResidentKey: true
		};
        SDK.registerFidoPlatformAuthenticator(fidoRegistrationInfo);
    });

    $("#fidoNonPlatformAuthBtn").click(function () {
		isNonResidentFlow = true;
        $("#fidoPending").hide();
        $("#fidoStatus").removeClass("d-none")
        $("#fidoStatus h3").text(deviceRegistrationWaitMsg);
        fidoRegistrationInfo.registrationOptions = {
			userVerification: "preferred",
			requireResidentKey: false
		};
        SDK.registerFIDO(fidoRegistrationInfo);
    });

});


/**
* Moves element in FORWARD direction
* elementId: id of the element to be moved
* totalDistance: total width of the container of the element
*/
function moveElementForward(elementId, totalDistance) {
  var element = document.getElementById(elementId);   
  var elementWidth = element.style.width;
  var elementPositionLeft = 0;
  var id = setInterval(frame, 10);
  
  function frame() {
      if (elementPositionLeft == totalDistance - elementWidth) {
        clearInterval(id);
      } else {
        elementPositionLeft++;
        element.style.left = elementPositionLeft + 'px'; 
      }
  }
}

/**
* Moves element in REVERSE direction
* elementId: id of the element to be moved
* totalDistance: total width of the container of the element
*/
function moveElementReverse(elementId, totalDistance) {
  var element = document.getElementById(elementId);   
  var elementWidth = element.style.width;
  var elementPositionLeft = totalDistance;
  var id = setInterval(frame, 10);
  
  function frame() {
      if (elementPositionLeft == 0) {
        clearInterval(id);
      } else {
        elementPositionLeft--;
        element.style.left = elementPositionLeft + 'px'; 
      }
  }
}

function submitGetTokenForm(){
  $("#getTokenForm").submit();
}

function updateUserOptedOutForFidoRegistrationForBrowser(userOptedOutForFidoReg){
  var updateUserOptedOutForFidoData = $('<input />').attr('type', 'hidden').attr('name', 'userOptedOutForFidoReg').attr('value', userOptedOutForFidoReg);
  $("#getTokenForm").append(updateUserOptedOutForFidoData);
  submitGetTokenForm();
}

function getFidoIconByPlatform(){
  let parsed = new UAParser();
  let platform = parsed.getOS().name;
  var iconPath = '';

  switch(platform){

    case 'Windows':
      iconPath = "../images/fido_icon_windows.png";
      break;

    case 'Mac OS':
      iconPath = "../images/fido_icon_mac.png";
      break;
      
    case 'iOS':
      iconPath = "../images/fido_icon_ios.png";
      break;  

    case 'Android':
      iconPath = "../images/fido_icon_android.png";
      break;

    default:
      //For Linux and other types of OS
      iconPath = "../images/fido_icon_default.png";
      break;  

  }

  return iconPath;
}