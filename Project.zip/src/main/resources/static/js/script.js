$(document).ready(function() {
            // SmartWizard 初始化
            $('#smartwizard').smartWizard({
                selected: 0, // 開始位置，最小為 0
                theme: 'default', // 決定 CSS 主題，請記得引入相關 CSS 
                autoAdjustHeight: true, // 自動調整高度
                backButtonSupport: true, // 後退一步功能啟用
                transition: {
                    animation: 'none', // none/fade/slide-horizontal/slide-vertical/slide-swing
                    speed: '400', // Transion animation speed
                },
                toolbarSettings: { // 按鈕相關
                    toolbarPosition: 'bottom', // none, top, bottom, both
                    toolbarButtonPosition: 'right', // left, right, center
                    showNextButton: true, // show/hide a Next button
                    showPreviousButton: true, // show/hide a Previous button
                    toolbarExtraButtons: [] // Extra buttons to show on toolbar, array of jQuery input/buttons elements
                }
            });
        });


