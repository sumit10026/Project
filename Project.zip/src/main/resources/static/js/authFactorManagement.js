$(document).ready(function () {

    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    SDK.init({
        Token: token,
        Header: header,
        fidoConfig: {
            attestationOptionUri: "../register/../attestation/options",
            attestationResultUri: "../register/../attestation/result"
        }
    });
    getUserRegisteredAuthFactors();

});

function getUserRegisteredAuthFactors() {
    getUserRegisteredAuthFactorsUri = "auth-factor-management/list";

    /*var request = {
        success: handleGetUserRegisteredAuthFactorsSuccess,
        error: handleGetUserRegisteredAuthFactorsError
    }
    SDK.getUserRegisteredAuthFactors(request);*/

    $.get(getUserRegisteredAuthFactorsUri, function(data, status){
        if (status === "success") {
            handleGetUserRegisteredAuthFactorsSuccess(data);
        } else {
            handleGetUserRegisteredAuthFactorsError(data);
        }
    });
}

function handleGetUserRegisteredAuthFactorsSuccess(response) {

    var fidoAuthFactorCount = 0;
    var otherAuthFactorCount = 0;
    if (response && response.length > 0) {
        response.forEach(function (obj, index) {
            var authType = obj.authType;
            var authTypeStatus = obj.authTypeStatus;
            var createdTS = obj.createdTS;
            var updatedTS = obj.updatedTS;
            var regAuthTypeId = obj.regAuthTypeId;
            var authFactorDesc = obj.authFactorDesc;
            var authFactorName = obj.authFactorName;
            var authFactorIcon = obj.base64EncodedAuthFactorLogo ? obj.base64EncodedAuthFactorLogo : getIconPathByAuthType(authType) ;
            var isAllowedToDeleteOrDisableAuthFactor = obj.allowedToDeleteOrDisableAuthFactor;

            var isFidoAuthFactor = false;
            if(authType == 'FIDO'){
                isFidoAuthFactor = true;
                fidoAuthFactorCount++;
            }else{
                otherAuthFactorCount++;
            }
            var userRecognizedAuthTypeName = obj.userRecognizedAuthTypeName;

            var divAfmContainer = $('<div/>').attr('class', 'col-md-3 auth-display-tile');

            var divAfmView = $('<div/>').attr('class', 'bm-view');

            var ulAuthDetail = $('<ul/>').attr('class', 'bmdetail');

            var liAuthType = $('<li/>').html('Auth Type:');
            var liAuthTypeVal = $('<li/>').html(userRecognizedAuthTypeName);
            var liStatus = $('<li/>').html('Status:');
            var liStatusVal = $('<li/>').html(authTypeStatus);
            var liCreatedTs = $('<li/>').html('Created TS:');
            var liCreatedTsVal = $('<li/>').html(new Date(createdTS).toLocaleDateString("en-US"));
            // var liUpdatedTs = $('<li/>').html('Last Accessed:');
            // var liUpdatedTsVal = $('<li/>').html(updatedTS);
            var liEnableAuthFactor = $('<li/>').html('Enable Auth Factor:');

            var liEnableAuthFactorVal = $('<li/>').attr('id', 'afm-enabledAuthType-' + regAuthTypeId);
            var authFactorToggle = $('<input />').attr('type', 'checkbox').attr('id', regAuthTypeId)
                                                 .attr('class', 'authFactorToggle').attr('data-toggle', 'toggle')
                                                 .attr('data-style', 'ios').attr('data-size', 'xs')
                                                 .attr('data-width', '40').attr('data-height', '10')
                                                 .attr('data-on', 'Yes').attr('data-off', 'No')
                                                 .attr('checked', true).attr('onchange', 'updateAuthTypeStatus("'+ regAuthTypeId +'")');

            liEnableAuthFactorVal.append(authFactorToggle);

            ulAuthDetail.append(liAuthType).append(liAuthTypeVal)
                .append(liStatus).append(liStatusVal);
                //.append(liUpdatedTs).append(liUpdatedTsVal)

            if(isFidoAuthFactor){
                ulAuthDetail.append(liCreatedTs).append(liCreatedTsVal)
                            .append(liEnableAuthFactor).append(liEnableAuthFactorVal);
            }

            var divClearFix1 = $('<div/>').attr('class', 'clearfix');
            var divClearFix2 = $('<div/>').attr('class', 'clearfix');

            var divAfmAction = $('<div/>').attr('class', 'bm-action');

            var ulIcon = $('<ul/>');
            var liIcon1 = $('<li/>');
            
            var imgIcon = $('<img/>').attr('id', 'icon'+index).attr('src', authFactorIcon);
            if(!isFidoAuthFactor && authType != 'TOTP' && authType != "RELID_VERIFY"){
                imgIcon.attr('style', 'background-color: #114355; border: 1px #FF1493; padding: 0.5em; border-radius: 5px;');
            }
            
            var liIcon2 = $('<li/>');
            var infoLink = $('<a/>').attr('href', '#info-modal').attr('class', 'infoLink').attr('data-toggle', 'modal')
                                    .attr('data-authtype', authType).attr('data-authtypestatus', authTypeStatus)
                                    .attr('data-createdts', createdTS).attr('data-updatedts', updatedTS)
                                    .attr('data-regauthtypeid', regAuthTypeId).attr('data-target', '#info-modal')
                                    .attr('data-authfactordesc', authFactorDesc).attr('data-authfactorname', authFactorName)
                                    .attr('data-authfactoricon', authFactorIcon).attr('data-userrecognizedauthtypename', userRecognizedAuthTypeName);
            var infoIcon = $('<i/>').attr('class', "fa fa-info").attr('aria-hidden', 'true');
            var deleteLink = $('<a/>').attr('href', '#delete-modal').attr('class', 'deleteLink').attr('data-toggle', 'modal')
                                    .attr('data-authtype', authType).attr('data-authtypestatus', authTypeStatus)
                                    .attr('data-createdts', createdTS).attr('data-updatedts', updatedTS)
                                    .attr('data-regauthtypeid', regAuthTypeId).attr('data-target', '#delete-modal')
                                    .attr('data-userrecognizedauthtypename', userRecognizedAuthTypeName);
            var deleteIcon = $('<i/>').attr('class', "fa fa-trash").attr('aria-hidden', 'true');                     

            if(isFidoAuthFactor){
                $("#regAuthFactorDiv").removeClass('d-none');
                $("#regAuthFactorDiv").append(divAfmContainer);
            }else{
                $("#otherAuthFactorParentDiv").removeClass('d-none');
                $("#otherAuthFactorDiv").removeClass('d-none');
                $("#otherAuthFactorDiv").append(divAfmContainer);
            }

            divAfmContainer.append(divAfmView);
            divAfmView.append(ulAuthDetail);
            divAfmView.append(divClearFix1);
            divAfmView.append(divAfmAction);

            divAfmAction.append(ulIcon);
            divAfmAction.append(divClearFix2);

            ulIcon.append(liIcon1);
            ulIcon.append(liIcon2);

            liIcon1.append(imgIcon);

            liIcon2.append(infoLink);
            infoLink.append(infoIcon);

            if(isAllowedToDeleteOrDisableAuthFactor){
                liIcon2.append(deleteLink);
                deleteLink.append(deleteIcon);
            }else{
                $('#'+regAuthTypeId).bootstrapToggle('disable');
            }

            if (authTypeStatus === "DISABLED") {
                $('#'+regAuthTypeId).bootstrapToggle('off', true);
            } else {
                $('#'+regAuthTypeId).bootstrapToggle('on', true);
            }
            
        });
    } else {
        $("#noRegAuthFactorDiv").removeClass('d-none');
        $("#regAuthFactorDiv").addClass('d-none');
        $("#otherAuthFactorParentDiv").addClass('d-none');
        $("#otherAuthFactorDiv").addClass('d-none');
    }

    if(fidoAuthFactorCount <= 0){
        $("#noRegAuthFactorDiv").removeClass('d-none');
        $("#regAuthFactorDiv").addClass('d-none');
    }else{
        $("#noRegAuthFactorDiv").addClass('d-none');
        $("#regAuthFactorDiv").removeClass('d-none');
    }

    if(otherAuthFactorCount <= 0){
        $("#otherAuthFactorParentDiv").addClass('d-none');
        $("#otherAuthFactorDiv").addClass('d-none');
    }else{
        $("#otherAuthFactorParentDiv").removeClass('d-none');
        $("#otherAuthFactorDiv").removeClass('d-none');
    }
}

function handleGetUserRegisteredAuthFactorsError(response) {
    console.log("handleGetUserRegisteredAuthFactorsError : ");
    console.log(response);
}

var currentRegAuthTypeId = '';
$(document).on("click", ".infoLink", function () {
    var authType = $(this).data('authtype');
    var authTypeStatus = $(this).data('authtypestatus');
    var createdTS = $(this).data('createdts') ? new Date($(this).data('createdts')).toUTCString() : null;
    var updatedTS = $(this).data('updatedts') ? new Date($(this).data('updatedts')).toLocaleDateString("en-US") : null;
    var regAuthTypeId = $(this).data('regauthtypeid');
    var authFactorDesc = $(this).data('authfactordesc');
    var authFactorName = $(this).data('authfactorname');
    var authFactorIcon = $(this).data('authfactoricon');
    var userRecognizedAuthTypeName = $(this).data('userrecognizedauthtypename');

    $("#afm-authType").html(userRecognizedAuthTypeName);
    $("#afm-authTypeStatus").html(authTypeStatus);

    if(createdTS){
        $("#afm-createdTSLabel").show();
        $("#afm-createdTS").show();
        $("#afm-createdTS").html(createdTS);
    }else{
        $("#afm-createdTSLabel").hide();
        $("#afm-createdTS").hide();
    }
    //$("#afm-updatedTS").html(updatedTS);
    
    $("#info-icon").attr('src', authFactorIcon);
    if(authType != 'FIDO' && authType != 'TOTP' && authType != "RELID_VERIFY"){
        $("#info-icon").attr('style', 'background-color: #114355; border: 1px #FF1493; padding: 0.5em; border-radius: 5px;');
    }else{
        $("#info-icon").attr('style', '');
    }
    
    currentRegAuthTypeId = regAuthTypeId;

    if(authFactorDesc){
        $("#afm-authFactorDescLabel").show();
        $("#afm-authFactorDesc").show();
        $("#afm-authFactorDesc").html(authFactorDesc);
    }else{
        $("#afm-authFactorDescLabel").hide();
        $("#afm-authFactorDesc").hide();
    }
    if(authFactorName){
        $("#afm-authFactorNameLabel").show();
        $("#afm-authFactorName").show();
        $("#afm-authFactorName").html(authFactorName);
    }else{
        $("#afm-authFactorNameLabel").hide();
        $("#afm-authFactorName").hide();
    }
    $("#afm-enabledAuthType").html(authTypeStatus === "DISABLED" ? 'No' : 'Yes');
});

$(document).on("click", ".deleteLink", function () {
    var regAuthTypeId = $(this).data('regauthtypeid');

    $("#delete-btn").attr('onclick', 'deleteRegisteredAuthFactor("' + regAuthTypeId + '")');
});

$(function() {
    $('#afm-enabledAuthTypeVal').change(function() {
        var isEnabledAuthFactor = $(this).prop('checked');
        $('#changestate-modal').modal('toggle');
        $('#info-modal').modal('toggle');
        $("#changestate-btn").attr('onclick', 'handleChangeStateConfirmBtnClick("' + currentRegAuthTypeId + '", ' + isEnabledAuthFactor + ')');
        $("#changestatecancel-btn").attr('onclick', 'handleChangeStateCancelBtnClick()');
        $("#changestateclose-btn").attr('onclick', 'handleChangeStateCancelBtnClick()');
        $("#changestateclose-btn-delete").attr('onclick', 'handleChangeStateCancelBtnClick()');
    })
});

var changedToggleId = "";
var isChangeStateModalEnabled = false;
function updateAuthTypeStatus(toggleId) {
    if (!hasChangeStateOperationCancelled) {
        var isEnabledAuthFactor = $('#' + toggleId).prop('checked');
        $('#changestate-modal').modal('toggle');
        $("#changestate-btn").attr('onclick', 'handleChangeStateConfirmBtnClick("' + toggleId + '", ' + isEnabledAuthFactor + ')');

        changedToggleId = toggleId;
    }else{
        hasChangeStateOperationCancelled = false;
    }
}

function handleChangeStateConfirmBtnClick(currentRegAuthTypeId, isEnabledAuthFactor) {
    changeRegisteredAuthFactorStateForUser(currentRegAuthTypeId, isEnabledAuthFactor);
    $('#changestate-modal').modal('toggle');
    hasChangeStateOperationPerformed = true;
}

function handleChangeStateCancelBtnClick(){
    $('#afm-enabledAuthTypeVal').bootstrapToggle('toggle');
}

var hasChangeStateOperationCancelled = false;
var hasChangeStateOperationPerformed = false;
$('#changestate-modal').on("hidden.bs.modal", function () {
    if(!hasChangeStateOperationPerformed){
        hasChangeStateOperationCancelled = true;
        $('#' + changedToggleId).bootstrapToggle('toggle');
    }else{
        hasChangeStateOperationPerformed = false;
    }
});

function deleteRegisteredAuthFactor(regAuthTypeId){
    var deleteRegisteredAuthFactorForUserUri = "auth-factor-management/delete";

    var data = {
        "regAuthTypeId" : regAuthTypeId
    }

    $.ajax({
        type: "POST",
        beforeSend: function(request) {
          request.setRequestHeader("Content-type", "application/json");
        },
        url: deleteRegisteredAuthFactorForUserUri,
        data: JSON.stringify(data),
        processData: false,
        dataType: 'text',
        success: function(msg) {
            $('#delete-modal').modal('hide');
            reloadFidoAndOtherAuthFactors();
        },
        error: function(msg) {
            if (msg.status != "412") {
				window.location = "login";
			} else {
                $("#failedoperationclose-btn").attr('onclick', 'reloadFidoAndOtherAuthFactors();');
                $("#failedoperationModalCenterTitle").html('Auth Factor Delete Operation Failure');
                $("#failedoperationMsg").html(msg.responseText);
                $('#failedoperation-modal').modal('toggle');
            }
        }
      });
}

function reloadFidoAndOtherAuthFactors(){
    $("#regAuthFactorDiv").empty();
    $("#otherAuthFactorDiv").empty();
    getUserRegisteredAuthFactors();
}

$('#failedoperation-modal').on("hidden.bs.modal", function () {
    reloadFidoAndOtherAuthFactors();
});

function changeRegisteredAuthFactorStateForUser(regAuthTypeId, isEnabledAuthFactor){
    var changeRegAuthFactorStateUri = "auth-factor-management/update-status";

    var data = {
        "regAuthTypeId" : regAuthTypeId,
        "enabledState" : isEnabledAuthFactor ? "true" : "false"
    }

    $.ajax({
        type: "POST",
        beforeSend: function(request) {
          request.setRequestHeader("Content-type", "application/json");
        },
        url: changeRegAuthFactorStateUri,
        data: JSON.stringify(data),
        processData: false,
        dataType: 'text',
        success: function(msg,result,response) {
            reloadFidoAndOtherAuthFactors();
        },
       error: function(msg,result,response) {
			if (response.status != "412") {
				window.location = "login";
			} else {
				console.log("Failed to Change Auth Factor State");
				$("#failedoperationclose-btn").attr('onclick', 'reloadFidoAndOtherAuthFactors();');
				$("#failedoperationModalCenterTitle").html('Auth Factor Change State Operation Failure');
				$("#failedoperationMsg").html(msg.responseText);
				$('#failedoperation-modal').modal('toggle');
			}

        }
      });
}

function getIconPathByAuthType(authType){
    var iconPath = "";

    switch(authType){

        case 'FIDO':
            iconPath = '../img2/device.png';
            break;

        case 'EMAILOTP':
            iconPath = '../img2/emailotp.png';
            break;
                
        case 'SMSOTP':
            iconPath = '../img2/smsotp.png';
            break;
          
        case 'PASS':
            iconPath = '../img2/password.png';
            break;
            
        case 'RELID_VERIFY':
            iconPath = '../images/bell.png';
            break;
                
        case 'TOTP':
            iconPath = '../img2/mobile.png';
            break;
        
        default:
            iconPath = '';
            break;
    }

    return iconPath;
}

var fidoAuthKeyFidoRegistrationInfo = {
    username: username,
    success: () => {
        $("#fidoAuthKeyFidoPending").hide();
        $("#fidoAuthKeyFidoStatus").removeClass("d-none");
        $("#fidoAuthKeyFidoStatus h3").text(deviceRoamingRegistrationSuccessMsg);
        $("#noRegAuthFactorDiv").addClass('d-none');

	    // FIXME: Handle spacing
        $(".fidoAuthKeyFido_back_button")
        	.removeClass("d-none w-75")
        	.addClass("w-25")
        	.parent()
        		.removeClass("col-md-6")
        		.addClass("col-md-12");

	    // FIXME: Handle spacing
       	$(".fido-reg-btn-div")
	    	.addClass("col-md-12")
	       	.removeClass("col-md-6");
        
        /*setTimeout(() => { 
                            $("#noRegAuthFactorDiv").addClass('d-none');
                            backToPrevious('authFactorContent', 'fidoAuthKeySetup');
                            reloadFidoAndOtherAuthFactors();
                        }, 1000);*/
    },
    error: (error) => {
        $("#fidoAuthKeyFidoPending").hide();
        $("#fidoAuthKeyFidoStatus,#fidoAuthKeyFidoRetry").removeClass("d-none");

	    // FIXME: Handle spacing
        $(".fidoAuthKeyFido_back_button")
        	.removeClass("d-none w-25")
        	.addClass("w-75")
        	.parent()
        		.removeClass("col-md-12")
        		.addClass("col-md-6");
	    // FIXME: Handle spacing
       	$(".fido-reg-btn-div")
	    	.removeClass("col-md-12")
	       	.addClass("col-md-6");
        $("#fidoAuthKeyFidoStatus h3").text(
            error + ". " + deviceRegistrationNotRegisterMsg
        );
    },
};

$("#fidoAuthKeyFido_authenticate,#fidoAuthKeyFidoRetry").click(function () {
    $("#fidoAuthKeyFidoRetry,.fidoAuthKeyFido_back_button").addClass("d-none");

    $("#fidoAuthKeyFidoPending").hide();
    $("#fidoAuthKeyFidoStatus").removeClass("d-none");
    $("#fidoAuthKeyFidoStatus h3").text(deviceRegistrationWaitMsg);
    fidoAuthKeyFidoRegistrationInfo.username = username;
    fidoAuthKeyFidoRegistrationInfo.registrationOptions = {
        userVerification: "preferred",
		requireResidentKey: false
    };
    SDK.registerFIDO(fidoAuthKeyFidoRegistrationInfo);
});

function gotoFidoAuthKeyFidoRegisterFlow(currentDiv){
    $("#"+currentDiv).addClass("d-none");
    $("#fidoAuthKeySetup").removeClass("d-none");
    $("#fidoAuthKeyFidoPending").show();
    $("#fidoAuthKeyFidoStatus").addClass("d-none");
    $("#fidoAuthKeyFidoStatus h3").text('');
    
    // FIXME: Handle spacing
    $(".fidoAuthKeyFido_back_button")
        	.removeClass("d-none w-25")
        	.addClass("w-75")
        	.parent()
        		.removeClass("col-md-12")
        		.addClass("col-md-6");
    // FIXME: Handle spacing
    $(".fido-reg-btn-div")
    	.removeClass("col-md-12")
       	.addClass("col-md-6");

    //$(".fidoAuthKeyFido_back_button").attr("onclick", "backToPrevious('" + currentDiv + "', 'fidoAuthKeySetup')");
}

function backToPrevious(showElement, hideElement) {
    $(`#${showElement}`).removeClass("d-none");
    $(`#${hideElement}`).addClass("d-none");
}