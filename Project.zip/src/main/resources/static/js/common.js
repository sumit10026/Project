// prevent back button
history.pushState(null, document.title, location.href);
window.addEventListener('popstate', function (event) {
	history.pushState(null, document.title, location.href);
});

$(document).ready(function(){

	// Disable develper options
	// https://stackoverflow.com/a/28575776
	$(document).keydown(function (event) {
	    if (event.keyCode == 123) { // Prevent F12
	        return false;
	    } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) { // Prevent Ctrl+Shift+I        
	        return false;
	    }
	});
	
	$(document).on("dragstart", function() {
	     return false;
	});
	
	// Disable right click
	$(document).on("contextmenu", function (e) {        
	    e.preventDefault();
	});
		
	//disable copy-paste starts
	var ctrlDown = false;
    var ctrlKey = 17, vKey = 86, cKey = 67;
    $(document).keydown(function(e)
    {
        if (e.keyCode == ctrlKey){
        	ctrlDown = true;
        }
    }).keyup(function(e)
    {
        if (e.keyCode == ctrlKey){
        	ctrlDown = false;
        }
    });
    $(document).keydown(function(e)
    {
        if (ctrlDown && (e.keyCode == vKey || e.keyCode == cKey)) 
        	return false;
    });
    //disable copy-paste ends

	/**	Add tokens to ajax request header*/
	$.ajaxPrefilter(function(options, originalOptions, jqXHR) {
		var token = $('#_csrf').attr('content');
		var header = $('#_csrf_header').attr('content');
		if (token) {
			return jqXHR.setRequestHeader(header, token);
		}
	});
	
	$('#href-continue-id').click(function(){
	     $("#theForm").submit();
	});


});