var SDK = function () {

    "use strict";

    var initialized = false,
        DEBUG = false,
        publicKey,
        fingerprintCalculated = false,
        onFingerprintCalculated = function () {return;},
        loginUri = "login",
        forgotUsernameUri = "forgot/forgot-username",
        token,
		header,
        validateUserUri = "oauth/validateUser",
        pollerConfig = {
            interval: 2 * 1000,
            pollUri: "oauth/isUserAuthenticated",
            timeout: 190 * 1000
        },
        fidoConfig = {
            attestationOptionUri: "attestation/options",
            attestationResultUri: "attestation/result",
            assertionOptionUri: "assertion/options",
            assertionResultUri: "assertion/result"
        },
        fidoAvailable = false,
        fidoPlatformAuthenticatorAvailable = false,
        userLocation,
        fingerprint,
        pollCount,
        maxPollCount,
        pollerActive = false,
        pollValidateUserTimeoutID,
        fetchUserAuthFactorsUri = "oauth/getUserAuthFactors",
        getConfigsUri = "configs",
        validateUserBasedOnAuthTypeUri = "oauth/validate-user",
        deleteAccountFromChooserUri = "oauth/delete-account",
        getUserRegisteredAuthFactorsUri = "getRegAuthFactorForUser",
         validateFidoCredentialUri = "oauth/validate-fido-cred",
         validateFidoRegisterSameBrowserUri = "oauth/validate-fido-register-same-browser",
		jspenc;

    var publicKey;
    
    var Constants = {
        GEOLOCATION_OPTIONS: {
            enableHighAccuracy: false,
            maximumAge: 0
        },
        AUTH_TYPE_PASS: "pass",
        AUTH_TYPE_RELID_VERIFY: "relid-verify",
        AUTH_TYPE_FIDO: "fido",
        AUTH_TYPE_FIDO_PLATFORM: "fido-platorm",
        AUTH_TYPE_FIDO_ROAMING: "fido-roaming",
        AUTH_TYPE_TOTP: "totp",
        AUTH_TYPE_SMS_OTP: "smsotp",
        AUTH_TYPE_EMAIL_OTP: "emailotp",
        AUTH_TYPES: ["pass", "relid-verify", "fido",  "fido-platorm", "fido-roaming", "totp", "smsotp", "emailotp"]
    };

    var Errors = {
        NOT_INITIALIZED: "Please initialize SDK first",
        INVALID_PROTOCOL: "Invalid protocol",
        FINGERPRINTJS_NOT_FOUND: "FingerprintJS not found : Make sure you have imported FingerprintJS2 before using SDK",
        INVALID_USERNAME: "Please enter valid user name",
        INVALID_AUTH_TYPE: "Please enter valid authentication type",
        FUNCTION_REQUIRED: "function must be provided: ",
        INVALID_AUTH_VALUE: "Please enter a valid value",
        SJCLJS_NOT_FOUND: "sjcl js not found : Make sure you have imported sjcl js before using SDK",
        JSENCRYPT_JS_NOT_FOUND: "jsencrypt js not found : Make sure you have imported jsencrypt js before using SDK"
    };

    /* private functions start */
    var log = function () {
        DEBUG && console.log.apply(console, Array.prototype.slice.call(arguments));
    }

    var logError = function () {
        console.error.apply(console, Array.prototype.slice.call(arguments));
    }

    var error = function (errorMessage, userErrorFunction) {
        logError(errorMessage);
        if (userErrorFunction === undefined) {
            throw new Error(errorMessage);
        } else {
            userErrorFunction(errorMessage);
        }
    };
    
    var redirectToLogin = function () {
        window.location = "login";
    };

    var checkPrerequisites = function () {

        // check protocol
        var protocol = location.protocol;
        if ("https:" !== protocol.toLocaleLowerCase()) {
            error(Errors.INVALID_PROTOCOL + " : expected https:, found " + protocol);
        }

        // check Fingerprint2 js availability
        if (typeof Fingerprint2 === "undefined") {
            error(Errors.FINGERPRINTJS_NOT_FOUND);
        }
        
        // check sjcl js availability
        if (typeof sjcl === "undefined") {
            error(Errors.SJCLJS_NOT_FOUND);
        }

        // check JSEncrypt js availability
        if (typeof JSEncrypt === "undefined") {
            error(Errors.JSENCRYPT_JS_NOT_FOUND);
        }

        fidoAvailable = navigator && navigator.credentials &&
            typeof (navigator.credentials.create) === "function" &&
            typeof (navigator.credentials.get) === "function";

        if (fidoAvailable && typeof (PublicKeyCredential) === "function") {
            PublicKeyCredential.isUserVerifyingPlatformAuthenticatorAvailable().then(function (platformAuthenticatorAvailable) {
                fidoPlatformAuthenticatorAvailable = platformAuthenticatorAvailable;
            });
        }
    };

    var checkInitialized = function () {
        if (!initialized) {
            error(Errors.NOT_INITIALIZED);
        }
    };

    var validAjaxStatuses = [200, 202, 204, 422];
    var ajax = {};
    ajax.x = function () {
        if (typeof XMLHttpRequest !== "undefined") {
            return new XMLHttpRequest();
        }
        var versions = [
            "MSXML2.XmlHttp.6.0",
            "MSXML2.XmlHttp.5.0",
            "MSXML2.XmlHttp.4.0",
            "MSXML2.XmlHttp.3.0",
            "MSXML2.XmlHttp.2.0",
            "Microsoft.XmlHttp"
        ];

        var xhr;
        for (var i = 0; i < versions.length; i++) {
            try {
                xhr = new ActiveXObject(versions[i]);
                break;
            } catch (e) {}
        }

        //CORS
        //xhr.withCredentials = true;

        return xhr;
    };

    ajax.send = function (url, callback, method, data, headers, async) {
        if (async ===undefined) {
            async = true;
        }
        var x = ajax.x();
        x.open(method, url, async);
        x.onreadystatechange = function () {
            if (x.readyState == 4) {
            	if (validAjaxStatuses.indexOf(x.status) == -1) {
                    redirectToLogin();
		    	} else {
                	callback(x.responseText, x.status, x);
		    	}
            }
        };
        if (method == "POST" && headers === undefined) {
            x.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
        }
        x.setRequestHeader(header, token);
        if (headers !== undefined) {
            for (var key in headers) {
                x.setRequestHeader(key, headers[key]);
            }
        }

        x.send(data);
    };

    ajax.get = function (url, data, callback, async) {
        var query = [];
        for (var key in data) {
            query.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
        }
        ajax.send(url + (query.length ? "?" + query.join("&") : ""), callback, "GET", null, async)
    };

    ajax.post = function (url, data, callback, async) {
        var query = [];
        for (var key in data) {
            query.push(encodeURIComponent(key) + "=" + encodeURIComponent(data[key]));
        }
        ajax.send(url, callback, "POST", query.join("&"), async);
    };

    ajax.postJson = function (url, data, callback, async) {
        ajax.send(url, callback, "POST", JSON.stringify(data), {
            "Content-type": "application/json"
        }, async);
    };
    
    var sha256 = function (value) {
    	return sjcl.hash.sha256.hash(value);
    };

    var base64 = function (value) {
    	return sjcl.codec.base64.fromBits(value);
    };

	var enc = function (value) {
		return jspenc.encrypt(value);
	}

    var validateString = function (value, errorMessage, userErrorFunction) {
        if (value === undefined || value.trim() === "") {
            error(errorMessage, userErrorFunction);
        }
    };

    var validateFunction = function (fn, errorMessage, userErrorFunction) {
        if (fn === undefined || typeof fn !== "function") {
            error(errorMessage, userErrorFunction);
        }
    };

    var validateAuthType = function (value, errorMessage, userErrorFunction) {
        validateString(value, errorMessage, userErrorFunction);

        if (Constants.AUTH_TYPES.indexOf(value) === -1) {
            error(errorMessage, userErrorFunction);
        }

    };

    var createDomInputElement = function (name, type, value) {
        var element = document.createElement("input");
        element.name = name;
        element.type = type;
        element.value = value;
        return element;
    };

    var initializeCallback = function (fn) {
        return fn !== undefined ? fn : function () {return;}
    };

    var validateAndInitializeConfig = function (initializationConfig) {

        if (initializationConfig === undefined || initializationConfig === null) {
            return;
        }

        if (initializationConfig.loginUri !== undefined && initializationConfig.loginUri.trim() !== "") {
            loginUri = initializationConfig.loginUri;
        }
        
        if (initializationConfig.Token !== undefined && initializationConfig.Token.trim() !== "") {
            token = initializationConfig.Token;
        }
        
        if (initializationConfig.Header !== undefined && initializationConfig.Header.trim() !== "") {
        	header = initializationConfig.Header;
        }

        if (initializationConfig.validateUserUri !== undefined && initializationConfig.validateUserUri.trim() !== "") {
            validateUserUri = initializationConfig.validateUserUri;
        }

        if (initializationConfig.pollerConfig !== undefined) {

            if (initializationConfig.pollerConfig.interval !== undefined && parseInt(initializationConfig.pollerConfig.interval) > 0) {
                pollerConfig.interval = initializationConfig.pollerConfig.interval;
            }

            if (initializationConfig.pollerConfig.timeout !== undefined && parseInt(initializationConfig.pollerConfig.timeout) > 0) {
                pollerConfig.timeout = initializationConfig.pollerConfig.timeout;
            }

            if (initializationConfig.pollerConfig.pollUri !== undefined && initializationConfig.pollerConfig.pollUri !== "") {
                pollerConfig.pollUri = initializationConfig.pollerConfig.pollUri;
            }
        }

        if (initializationConfig.fidoConfig !== undefined) {

            if (initializationConfig.fidoConfig.attestationOptionUri !== undefined && initializationConfig.fidoConfig.attestationOptionUri !== "") {
                fidoConfig.attestationOptionUri = initializationConfig.fidoConfig.attestationOptionUri;
            }

            if (initializationConfig.fidoConfig.attestationResultUri !== undefined && initializationConfig.fidoConfig.attestationResultUri !== "") {
                fidoConfig.attestationResultUri = initializationConfig.fidoConfig.attestationResultUri;
            }

            if (initializationConfig.fidoConfig.assertionOptionUri !== undefined && initializationConfig.fidoConfig.assertionOptionUri !== "") {
                fidoConfig.assertionOptionUri = initializationConfig.fidoConfig.assertionOptionUri;
            }

            if (initializationConfig.fidoConfig.assertionResultUri !== undefined && initializationConfig.fidoConfig.assertionResultUri !== "") {
                fidoConfig.assertionResultUri = initializationConfig.fidoConfig.assertionResultUri;
            }
        }

        if (initializationConfig.fetchUserAuthFactorsUri !== undefined && initializationConfig.fetchUserAuthFactorsUri.trim() !== "") {
            fetchUserAuthFactorsUri = initializationConfig.fetchUserAuthFactorsUri;
        }

        if (initializationConfig.getConfigsUri !== undefined && initializationConfig.getConfigsUri.trim() !== "") {
            getConfigsUri = initializationConfig.getConfigsUri;
        }

        if (initializationConfig.validateUserBasedOnAuthTypeUri !== undefined && initializationConfig.validateUserBasedOnAuthTypeUri.trim() !== "") {
            validateUserBasedOnAuthTypeUri = initializationConfig.validateUserBasedOnAuthTypeUri;
        }
        
        if (initializationConfig.validateFidoCredentialUri !== undefined && initializationConfig.validateFidoCredentialUri.trim() !== "") {
            validateFidoCredentialUri = initializationConfig.validateFidoCredentialUri;
        } 
        
        if (initializationConfig.validateFidoRegisterSameBrowserUri !== undefined && initializationConfig.validateFidoRegisterSameBrowserUri.trim() !== "") {
            validateFidoRegisterSameBrowserUri = initializationConfig.validateFidoRegisterSameBrowserUri;
        }              

        if (initializationConfig.deleteAccountFromChooserUri !== undefined && initializationConfig.deleteAccountFromChooserUri.trim() !== "") {
            deleteAccountFromChooserUri = initializationConfig.deleteAccountFromChooserUri;
        }

        if (initializationConfig.getUserRegisteredAuthFactorsUri !== undefined && initializationConfig.getUserRegisteredAuthFactorsUri.trim() !== "") {
            getUserRegisteredAuthFactorsUri = initializationConfig.getUserRegisteredAuthFactorsUri;
        }

        
    };

    var getUserLocation = function () {
        if (navigator.geolocation) {
            var getUserLocationStartTime = new Date().getTime();
            navigator.geolocation.getCurrentPosition(function showPosition(position) {
                userLocation = {
                    latitude: position.coords.latitude.toFixed(7),
                    longitude: position.coords.longitude.toFixed(7)
                    // altitude: position.coords.altitude
                };
                log("Time taken to fetch location: ", (new Date().getTime() - getUserLocationStartTime) / 1000, "sec");
                log("user location", userLocation, position.coords);
            }, null, Constants.GEOLOCATION_OPTIONS);
        }
    };

    var calculateFingerprint = function () {
        var calculateFingerprintStartTime = new Date().getTime();

        /** below paramemetrs are captured from browser */
        var options = {
            excludes: {
                adBlock: false,
                addBehavior: false,
                audio: false,
                availableScreenResolution: false,
                canvas: true, //excluded from capturing due to large value and processing time
                colorDepth: false,
                cpuClass: false,
                // customEntropyFunction: false, // removed from new lib version, 
                deviceMemory: false,
                doNotTrack: false,
                enumerateDevices: false,
                fonts: false,
                fontsFlash: false,
                hardwareConcurrency: false,
                hasLiedBrowser: false,
                hasLiedLanguages: false,
                hasLiedOs: false,
                hasLiedResolution: false,
                indexedDb: false,
                language: false,
                localStorage: false,
                openDatabase: false,
                pixelRatio: false,
                platform: false,
                plugins: false,
                screenResolution: false,
                sessionStorage: false,
                timezone: false,
                timezoneOffset: false,
                touchSupport: false,
                userAgent: false,
                webdriver: false,
                webgl: true, //excluded from capturing due to large value and processing time
                webglVendorAndRenderer: false
            }
        };

        /** below paramemetrs are NOT considered for fingerprint */
        var excludedFingerprintParameters = {
            doNotTrack: true,
            enumerateDevices: true,
            fontsFlash: true,
            pixelRatio: true,
            canvas: true, //excluded from capturing due to large value and processing time
            webgl: true //excluded from capturing due to large value and processing time
        };

        var fingerprintCallback = function (components) {

			/*
            var values = components
                .filter(function (component) {
                    return excludedFingerprintParameters[component.key] === undefined;
                })
                .map(function (component) {
                    return component.value;
                });
            var murmur = Fingerprint2.x64hash128(values.join(""), 31);
            */

            var browserAttributes = {};
            components
                .filter(function (component) {
                    return excludedFingerprintParameters[component.key] === undefined;
                })
                .forEach(function (component) {
                    browserAttributes[component.key] = component.value;
                });

            fingerprint = {
                browserAttributes: browserAttributes,
                /*browserFingerprint: murmur,*/
                browserUserAgent: navigator.userAgent
            };
            log("Time taken to calculate fingerprint: ", (new Date().getTime() - calculateFingerprintStartTime) / 1000, "sec");
            log("calculated fingerprint", fingerprint);
            fingerprintCalculated = true;
            onFingerprintCalculated();
        };

        if (window.requestIdleCallback) {
            requestIdleCallback(function () {
                Fingerprint2.get(options, fingerprintCallback);
            });
        } else {
            setTimeout(function () {
                Fingerprint2.get(options, fingerprintCallback);
            }, 500);
        }
    };

    var pollValidateUser = function (username, onUserAction, onTimeout, err, isUserSelectedRememberMe, isGenerationCounterExceededForOtherAuthType) {
        if (pollerActive) {
            if (pollCount <= maxPollCount) {
                log("sending poll request. pollCount:", pollCount, ", maxPollCount:", maxPollCount);
                pollValidateUserTimeoutID = setTimeout(function () {
                    ajax.get(pollerConfig.pollUri, {}, function (data, status) {
                        if (status === 200) {
                            onUserAction();
                            validateUser({
                                username: username,
                                auth_type: Constants.AUTH_TYPE_RELID_VERIFY,
                                success: onUserAction,
                                remember_me: isUserSelectedRememberMe
                            });
                        } else if (status === 202) {
                            pollValidateUser(username, onUserAction, onTimeout, err, isUserSelectedRememberMe, isGenerationCounterExceededForOtherAuthType);
                        } else if (status === 204) {
                            onTimeout();
                            // FIXME : Need to move at common location
                            // If RVN generation attempt counter exceeds,
                            // then at the timeout of last notification terminate the flow.
                            if(isGenerationCounterExceededForOtherAuthType){
                                var data = {
                                    username: username,
                                    remember_me: isUserSelectedRememberMe
                                }
                                submitLogin(data);
                            }
                        } else {
                            error(data, err);
                        }
                    })
                }, pollerConfig.interval);
                pollCount++;
            } else {
                onTimeout();
                if(isGenerationCounterExceededForOtherAuthType){
                    // If RVN generation attempt counter exceeds,
                    // then at the timeout of last notification terminate the flow.
                    var data = {
                        username: username,
                        remember_me: isUserSelectedRememberMe
                    }
                    submitLogin(data);
                }
            }
        }
    };

	var excludeCredentialFunction = function credentialListConversion(list) {
	    var credList = [];
	    for (var i=0; i < list.length; i++) {
	        var cred = {
	            type: list[i].type,
	            id: base64url.decode(list[i].id)
	        };
	        if (list[i].transports) {
	            cred.transports = list[i].transports;
	        }
	        credList.push(cred);
	    }
	    return credList;
	};
	
	var successFetchPublicKey = function(response) {
      	//updateGenerationAttemptCounter(response);
      	publicKey=response;
		jspenc = new JSEncrypt();
        jspenc.setPublicKey("-----BEGIN PUBLIC KEY-----\n" + publicKey + "\n-----END PUBLIC KEY-----");
      };

    var errorFetchPublicKey= function(response) {
      	console.log("Error Fetch PublicKey : " + response);
      	
      };
      
    var fetchPublicKeyFunction = function(response) {
    	var publicKeyParam = {
           		success: successFetchPublicKey,
           		error: errorFetchPublicKey
           	}
    	SDK.getPublicKey(publicKeyParam);
        };
	
    var performFidoRegistration = function (username, registerUsingPlatformAuthenticator, registrationOptions, success, err) {
        if (fidoAvailable) {
	
			var authenticatorSelection = {
                'authenticatorAttachment': registerUsingPlatformAuthenticator ? "platform" : "cross-platform",
                // possible values: preferred, required, discouraged (default)
                'userVerification': "required",
                // possible values: true, false (default)
                'requireResidentKey': true
			};
	
			if (registrationOptions) {
				if (registrationOptions.authenticatorAttachment) {
					authenticatorSelection.authenticatorAttachment = registrationOptions.authenticatorAttachment;
				}
				if (registrationOptions.userVerification) {
					authenticatorSelection.userVerification = registrationOptions.userVerification;
				}
				if (registrationOptions.requireResidentKey != undefined) {
					authenticatorSelection.requireResidentKey = registrationOptions.requireResidentKey;
				}
			}

            var attestationOptions = {
                username: username,
                displayName: username,
                attestation: "direct",
                authenticatorSelection: authenticatorSelection
            };

            try {
                var domain = document.domain;
                ajax.postJson(fidoConfig.attestationOptionUri, attestationOptions, function (data, status) {
                    var errorMessage = "";
                    try {
                        log("Received attestationOptionUri response from server");
                        if (status === 200) {
                            var makeCredReq = JSON.parse(data);
								makeCredReq.excludeCredentials = excludeCredentialFunction(makeCredReq.excludeCredentials);
                                makeCredReq.challenge = base64url.decode(makeCredReq.challenge);
                                makeCredReq.user.id = base64url.decode(makeCredReq.user.id);
                                makeCredReq.rp.id = domain;
                                navigator.credentials.create({
                                        publicKey: makeCredReq
                                    })
                                    .then(function (cred) {
                                        log("Created credentials on Fido device");
                                        //alert("Created credentials on Fido device");
                                        var response = publicKeyCredentialToJSON(cred);
                                        ajax.postJson(fidoConfig.attestationResultUri, response, function (data, status) {
                                            log("Received attestationResultUri response from server");
                                            if (status === 200) {
                                                log("Fido registration successful");
                                                //alert("Fido registration successful"+status);
                                                success("Fido registration successful");
                                            } else {
                                                error("Could not perform FIDO registration", err);
                                                //alert("Could not perform FIDO registration"+status);
                                            }
                                        })
                                    }).catch(function (e) {
                                        logError(e);
                                        //alert("Could not perform FIDO registration"+ e);
                                        error("Could not perform FIDO registration", err);
                                    })
                        } else {
                                errorMessage = "Could not perform FIDO registration";
								error(errorMessage, err);
                                //alert("Could not perform FIDO registration");
                        }
                    } catch (e) {
                        logError(e);
                        error("Could not register FIDO device. Please contact administrator.", err);
                        //alert("Could not register FIDO device. Please contact administrator." + err);
                    }
                    if (errorMessage.length) {
                        error(errorMessage, err);
                    }
                });
            } catch (e) {
                logError(e);
                error("Could not register FIDO device. Please contact administrator.", err);
                //alert("FIDO is not supported by your browser" + err);
            }
        } else {
            error("FIDO is not supported by your browser", err);
        }
    };

    var performFidoLogin = function (username, success, err, remember_me, onFidoGeneration, level1AuthProcessor) {
        if (fidoAvailable) {
            try {
                var domain = document.domain;
                ajax.postJson(fidoConfig.assertionOptionUri, {
                    username: username,
                    documentDomain: domain
                }, function (data, status) {
                    var errorMessage = "";
                    try {
                        //alert("Received assertionOptionUri response from server"+JSON.stringify(data));
                        log("Received assertionOptionUri response from server");
                        var fidoResponse = JSON.parse(data);
                        var getAssertionRes = fidoResponse.jsonNode;

                        if (status === 200) {
                            
                            if(onFidoGeneration !== undefined){
                                onFidoGeneration(fidoResponse.authGenerationAttemptsCounter);
                            }

                            //alert("Received assertionOptionUri response from server"+status);
                            getAssertionRes.challenge = base64url.decode(getAssertionRes.challenge);
                            for (var i = 0; i < getAssertionRes.allowCredentials.length; i++) {
                                getAssertionRes.allowCredentials[i].id = base64url.decode(getAssertionRes.allowCredentials[i].id);
                            }
                            navigator.credentials.get({
                                    publicKey: getAssertionRes
                                })
                                .then(function (assertion) {
                                    //alert("Received Assertion response from Fido device");
                                    log("Received Assertion response from Fido device");
                                    var response = publicKeyCredentialToJSON(assertion);
                                    
                                    validateUser({
                                        username: username,
                                        auth_type: Constants.AUTH_TYPE_FIDO,
                                        auth_value: JSON.stringify(response),
                                        success: success,
                                        remember_me: remember_me
                                    });
                                }).catch(function (e) {
                                    //alert("Could not perform FIDO login"+e);
                                    logError(e);
                                    if (e instanceof DOMException) {
                                        logError("User cancelled");
                                        errorMessage ="User cancelled the FIDO login";
                                        
                                        //Need to fallback to other auth type, 
                                        //if FIDO is the first option for authentication
                                        if(fidoResponse.level1AuthenticationPending){
                                            level1AuthProcessor();
                                        }
                                    }else {
                                        errorMessage = "Could not perform FIDO login "+e;
                                    }
                                    error(errorMessage, err);
                                })
                        } else {
                            errorMessage = "Could not perform login. ";
							if (getAssertionRes) {
								errorMessage += getAssertionRes.errorMessage;
							}
							error(errorMessage, err);
                            //alert(errorMessage);
                        }
                    } catch (e) {
                        //alert("Could not perform FIDO login. Please contact administrator."+ e);
                        logError(e);
                        error("Could not perform FIDO login. Please contact administrator.", err);
                    }
                    if (errorMessage.length) {
                        error(errorMessage, err);
                    }
                });
            } catch (e) {
                //alert("Could not perform FIDO login. Please contact administrator."+ e);
                logError(e);
                error("Could not perform FIDO login. Please contact administrator.", err);
            }
        } else {
            //alert("FIDO is not supported by your browser"+ err);
            error("FIDO is not supported by your browser", err);
        }
    };

	var performValidateFidoRegistrationSameBrowser = function(username, success) {

		var postData = {
			username: username,
			web_device_parameters: JSON.stringify(fingerprint.browserAttributes),
			web_device_parameter_checksum: fingerprint.browserFingerprint,
			auth_type: Constants.AUTH_TYPE_FIDO,
			auth_value: Constants.AUTH_TYPE_RELID_VERIFY
		};

		ajax.postJson(validateFidoRegisterSameBrowserUri, postData,
			function(data, status) {
				if (status === 200) {
					success(data);
				} else {
					error(data);
				}
			});
	};

    var performValidateFidoCredential = function (username, success, err, remember_me) {

        if (fidoAvailable) {
            try {
                var domain = document.domain;
                ajax.postJson(fidoConfig.assertionOptionUri, {
                    username: username,
                    documentDomain: domain
                }, function (data, status) {
                    var errorMessage = "";
                    try {
                        //alert("Received assertionOptionUri response from server"+JSON.stringify(data));
                        log("Received assertionOptionUri response from server");
                        var fidoResponse = JSON.parse(data);
                        var getAssertionRes = fidoResponse.jsonNode;

                        if (status === 200) {

                            //alert("Received assertionOptionUri response from server"+status);
                            getAssertionRes.challenge = base64url.decode(getAssertionRes.challenge);
                            for (var i = 0; i < getAssertionRes.allowCredentials.length; i++) {
                                getAssertionRes.allowCredentials[i].id = base64url.decode(getAssertionRes.allowCredentials[i].id);
                            }
                            navigator.credentials.get({
                                    publicKey: getAssertionRes
                                })
                                .then(function (assertion) {
                                    //alert("Received Assertion response from Fido device");
                                    log("Received Assertion response from Fido device");
                                    var response = publicKeyCredentialToJSON(assertion);
                                    
                                    invokeValidateFidoCredentialAPI({
                                        username: username,
                                        auth_type: Constants.AUTH_TYPE_FIDO,
                                        auth_value: JSON.stringify(response),
                                        success: success,
                                        remember_me: remember_me
                                    });
                                    
                                    
                              /*      validateUser({
                                        username: username,
                                        auth_type: Constants.AUTH_TYPE_FIDO,
                                        auth_value: JSON.stringify(response),
                                        success: success,
                                        remember_me: remember_me
                                    });*/                                    
                                }).catch(function (e) {
                                    //alert("Could not perform FIDO login"+e);
                                    logError(e);
                                    if (e instanceof DOMException) {
                                        logError("User cancelled");
                                        errorMessage ="User cancelled the FIDO login";

                                    }else {
                                        errorMessage = "Could not perform FIDO login "+e;
                                    }
                                    error(errorMessage, err);
                                })
                        } else {
                            errorMessage = "Could not perform login. ";
							if (getAssertionRes) {
								errorMessage += getAssertionRes.errorMessage;
							}
							error(errorMessage, err);
                            //alert(errorMessage);
                        }
                    } catch (e) {
                        //alert("Could not perform FIDO login. Please contact administrator."+ e);
                        logError(e);
                        error("Could not perform FIDO login. Please contact administrator.", err);
                    }
                    if (errorMessage.length) {
                        error(errorMessage, err);
                    }
                });
            } catch (e) {
                //alert("Could not perform FIDO login. Please contact administrator."+ e);
                logError(e);
                error("Could not perform FIDO login. Please contact administrator.", err);
            }
        } else {
            //alert("FIDO is not supported by your browser"+ err);
            error("FIDO is not supported by your browser", err);
        }
    };





    var submitLogin = function (data, userErrorFunction) {

        var submitLoginRequest = function () {
            var form = document.createElement("form");
            form.action = loginUri;
            form.method = "POST";

            // create input elements as per data
            for (var key in data) {
                var element = createDomInputElement(key, "hidden", data[key]);
                form.appendChild(element);
            }

            if (userLocation !== undefined) {
                // create user location element
                var userLocationElement = createDomInputElement("user_location", "hidden", JSON.stringify(userLocation));
                form.appendChild(userLocationElement);
            }

            var element = createDomInputElement("_csrf", "hidden", token);
            form.appendChild(element);
            var element = createDomInputElement("_csrf_header", "hidden", header);
            form.appendChild(element);

            // create web device parameters element
            var webDeviceParametersElement = createDomInputElement("web_device_parameters", "hidden", JSON.stringify(fingerprint.browserAttributes));
            form.appendChild(webDeviceParametersElement);

            // create web device parameter checksum element
            /*var webDeviceParameterChecksumElement = createDomInputElement("web_device_parameter_checksum", "hidden", fingerprint.browserFingerprint);
            form.appendChild(webDeviceParameterChecksumElement);*/

            // create fido platform authenticator available element
            var fidoPlatformAuthenticatorAvailableElement = createDomInputElement("fido_platform_authenticator_available", "hidden", fidoPlatformAuthenticatorAvailable);
            form.appendChild(fidoPlatformAuthenticatorAvailableElement);

            document.getElementsByTagName("body")[0].appendChild(form);

            log("submitting form");
            form.submit();
        };

        if (!fingerprintCalculated) {
            onFingerprintCalculated = submitLoginRequest;
        } else {
            submitLoginRequest();
        }
    };

	var invokeValidateFidoCredentialAPI = function(obj) {

		checkInitialized();

		var username = obj.username;
		var success = obj.success;
		var err = obj.error;
		var authType = obj.auth_type;
		var authValue = obj.auth_value;

		validateString(username, Errors.INVALID_USERNAME);
		validateFunction(success, Errors.FUNCTION_REQUIRED + "success");

		if (authType) {
			validateAuthType(authType, Errors.INVALID_AUTH_TYPE);
			if (authType != Constants.AUTH_TYPE_RELID_VERIFY) {
				validateString(authValue, Errors.INVALID_AUTH_VALUE);
			}

			if (authType == Constants.AUTH_TYPE_PASS) {
				authValue = enc(authValue);
			}
		}

		var postData = {
			username: username,
			web_device_parameters: JSON.stringify(fingerprint.browserAttributes),
			web_device_parameter_checksum: fingerprint.browserFingerprint,
			auth_type: authType,
			auth_value: authValue
		};

		ajax.postJson(validateFidoCredentialUri, postData,
			function(data, status) {
				if (status === 200) {
					success(JSON.parse(data));
				} else {
					error(JSON.parse(data), err);
				}
			});
	};

    var validateUser = function(obj){
        checkInitialized();

        var username = obj.username;
        var success = obj.success;
        var err = obj.error;
        var authType = obj.auth_type;
        var authValue = obj.auth_value;

        validateString(username, Errors.INVALID_USERNAME);
        validateFunction(success, Errors.FUNCTION_REQUIRED + "success");

        if (authType) {
            validateAuthType(authType, Errors.INVALID_AUTH_TYPE);
            if(authType != Constants.AUTH_TYPE_RELID_VERIFY){
                validateString(authValue, Errors.INVALID_AUTH_VALUE);
            }

			if (authType == Constants.AUTH_TYPE_PASS) {
				authValue = enc(authValue);
			}
        }

        var postData = {
                    username: username,
                    web_device_parameters: JSON.stringify(fingerprint.browserAttributes),
                    web_device_parameter_checksum: fingerprint.browserFingerprint,
                    auth_type: authType,
                    auth_value: authValue
                };

        ajax.postJson(validateUserBasedOnAuthTypeUri, postData,
                    function (data, status) {
            if (status === 200) {
                //Need to handle
                var isUserSelectedRememberMe = false;
                if(obj.remember_me){
                    isUserSelectedRememberMe = true;
                }

                var data = {
                    username: username,
                    remember_me: isUserSelectedRememberMe
                }
                submitLogin(data);
            } else if(status === 202) {
                success(JSON.parse(data));
            }else{
                error(JSON.parse(data), err);
            }
        });

    }
    
    var submitForgorUsername = function(obj){
        checkInitialized();

        var option = obj.option;
        var optionInput = obj.optionInput;
        var success = obj.success;
        var error = obj.error;

        var postData = {
                    option: obj.option,
        			option_input: obj.optionInput
                };

        ajax.postJson(forgotUsernameUri, postData,
                    function (data,status) {
            if (status === 200) {
                 success(JSON.parse(data).success);
            }else if(status === 500){
				error(JSON.parse(data).error);
			}
        });

    }
    
    /* private functions end */

    return {

        /* public functions start */
        init: function (initializationConfig) {

            if (initializationConfig !== undefined && initializationConfig !== null && initializationConfig.debug !== undefined) {
                DEBUG = initializationConfig.debug;
            }

            log("initializing");

            if (initialized) {
                error("Already initialized");
            }

            checkPrerequisites();

            validateAndInitializeConfig(initializationConfig);

            getUserLocation();

            calculateFingerprint();

            initialized = true;
            log("initialized");
        },

        verifyLogin: function (obj) {
            checkInitialized();
            this.cancelVerifyLogin();

            var username = obj.username;
            var beforeStart = obj.beforeStart;
            var onUserAction = obj.onUserAction;
            var onTimeout = obj.onTimeout;
            var err = obj.error;
			var rememberMe = obj.remember_me ? obj.remember_me : false;
            var onRVNGeneration = obj.onRVNGeneration;

            beforeStart = initializeCallback(beforeStart);
            onUserAction = initializeCallback(onUserAction);
            onTimeout = initializeCallback(onTimeout);

            validateString(username, Errors.INVALID_USERNAME);

            beforeStart();

            var sendVerifyRequest = function () {
                var postData = {
                    username: username,
                    web_device_parameters: JSON.stringify(fingerprint.browserAttributes),
                    web_device_parameter_checksum: fingerprint.browserFingerprint,
                    auth_type: Constants.AUTH_TYPE_RELID_VERIFY,
					remember_me: rememberMe
                };

                if (userLocation !== undefined) {
                    postData["user_location"] = JSON.stringify(userLocation);
                }

                ajax.post(validateUserUri, postData,
                    function (data, status) {
                        if (status === 200) {
                            //Disable notification generation if generation attempt counter is exceeded
                            var generationAttemptCounter = JSON.parse(data);

                            if(onRVNGeneration !== undefined){
                                onRVNGeneration(generationAttemptCounter);    
                            }

                            var isGenerationCounterExceededForOtherAuthType = true; 
                            Object.keys(generationAttemptCounter).forEach(function (entry) {
                                if(generationAttemptCounter[entry] > 0){
                                    isGenerationCounterExceededForOtherAuthType = false;
                                }
                            });

                            pollerActive = true;
                            pollCount = 1;
                            maxPollCount = pollerConfig.timeout / pollerConfig.interval;
                            pollValidateUser(username, onUserAction, onTimeout, err, obj.remember_me, isGenerationCounterExceededForOtherAuthType);
                        } else {
                            error(data, err);
                        }
                    });
            };

            if (!fingerprintCalculated) {
                onFingerprintCalculated = sendVerifyRequest;
            } else {
                sendVerifyRequest();
            }
        },

        cancelVerifyLogin: function () {
            checkInitialized();
            clearTimeout(pollValidateUserTimeoutID);
            pollerActive = false;
        },

        login: function (obj) {
            checkInitialized();

            if (obj === undefined || obj === null) {
                error("Arguments cannot be empty");
            } else {
                var username = obj.username;
                var authType = obj.auth_type;
                var data = obj;

                validateString(username, Errors.INVALID_USERNAME);
                validateAuthType(authType, Errors.INVALID_AUTH_TYPE);

                submitLogin(data);
            }
        },

        isFidoPlatformAuthenticatorAvailable: function () {
            return fidoPlatformAuthenticatorAvailable;
        },

        registerFIDO: function (obj) {
            checkInitialized();

            var username = obj.username;
            var registrationOptions = obj.registrationOptions;
            var success = obj.success;
            var err = obj.error;

            validateString(username, Errors.INVALID_USERNAME);
            validateFunction(success, Errors.FUNCTION_REQUIRED + "success");

            var registerUsingPlatformAuthenticator = false;
            performFidoRegistration(username, registerUsingPlatformAuthenticator, registrationOptions, success, err);

        },

        registerFidoPlatformAuthenticator: function (obj) {
            checkInitialized();

            var username = obj.username;
            var registrationOptions = obj.registrationOptions;
            var success = obj.success;
            var err = obj.error;

            validateString(username, Errors.INVALID_USERNAME);
            validateFunction(success, Errors.FUNCTION_REQUIRED + "success");

            var registerUsingPlatformAuthenticator = true;
            performFidoRegistration(username, registerUsingPlatformAuthenticator, registrationOptions, success, err);

        },

        fidoLogin: function (obj) {
            checkInitialized();

            var username = obj.username;
            var err = obj.error;
            var success = obj.success;
            var onFidoGeneration = obj.onFidoGeneration;
            var level1AuthProcessor = obj.level1AuthProcessor;

            validateString(username, Errors.INVALID_USERNAME);
            validateFunction(success, Errors.FUNCTION_REQUIRED + "success");
            validateFunction(level1AuthProcessor, Errors.FUNCTION_REQUIRED + "level1AuthProcessor");

            performFidoLogin(username, success, err, obj.remember_me, onFidoGeneration, level1AuthProcessor);

        },


		validateFidoRegistrationSameBrowser: function(obj) {
			checkInitialized();

			var username = obj.username;
			var success = obj.success;

			validateString(username, Errors.INVALID_USERNAME);
			validateFunction(success, Errors.FUNCTION_REQUIRED + "success");

			performValidateFidoRegistrationSameBrowser(username, success);
		},

        validateFidoCredential: function (obj) {
            checkInitialized();

            var username = obj.username;
            var err = obj.error;
            var success = obj.success;
            //var onFidoGeneration = obj.onFidoGeneration;
            //var level1AuthProcessor = obj.level1AuthProcessor;

            validateString(username, Errors.INVALID_USERNAME);
            validateFunction(success, Errors.FUNCTION_REQUIRED + "success");
            //validateFunction(level1AuthProcessor, Errors.FUNCTION_REQUIRED + "level1AuthProcessor");

            performValidateFidoCredential(username, success, err, obj.remember_me);

        },

        getConfigs: function (obj) {
            checkInitialized();

            var success = obj.success;
            var err = obj.error;

            validateFunction(success, Errors.FUNCTION_REQUIRED + "success");

            var sendGetConfigsRequest = function () {
                var postData = {
                    web_device_parameters: JSON.stringify(fingerprint.browserAttributes),
                    web_device_parameter_checksum: fingerprint.browserFingerprint
                };

                ajax.postJson(getConfigsUri, postData,
                    function (data, status) {
                        if (status === 200) {
                        	data=JSON.parse(data);
                        	//if (data.configuration.alwaysAskForPassword === true) {
                        		 
                        		//fetchPublicKeyFunction(data);
                        		
                        		var publicKeyParam = {
                                   		success: successFetchPublicKey,
                                   		error: errorFetchPublicKey
                                   	}
                            	SDK.getPublicKey(publicKeyParam);
                    	//}
                            success(data);
                        } else {
                            error(JSON.parse(data), err);
                        }
                    });
            };

            if (!fingerprintCalculated) {
                onFingerprintCalculated = sendGetConfigsRequest;
            } else {
                sendGetConfigsRequest();
            }
        },
        
        getPublicKey: function (obj) {
            checkInitialized();
            var success = obj.success;
            var err = obj.error;
        
            var pKey = function () {
            	 var postData = {};
                ajax.postJson("fetchPublicKey", postData,
                    function (data, status) {
                        if (status === 200) {
                        	success(data);
                        } else {
                        	err(data);
                    
                        }
                    });
            };
            pKey();
        },
        
        submitUserInfo: function (obj) {
            checkInitialized();

            var username = obj.username;
            var success = obj.success;
            var err = obj.error;
            var authType =obj.authType;
            var authValue =obj.authValue;
            
            if(authType == "pass" && authValue !== "")
            	{
//            	console.log("submitUserInfo password::::: " +authValue);
  //      		console.log("submitUserInfo ::::: " +authType);
        	                
    //        		console.log("public key 3::::: " +publicKey);
            	//	var encryptedPassword= sjcl.encrypt(authValue, publicKey) ;
            		//console.log("submitUserInfo password::::: encryptedPassword :: " +encryptedPassword.ct);
            		//authValue=encryptedPassword;
            	}
            	
            validateString(username, Errors.INVALID_USERNAME);
            validateFunction(success, Errors.FUNCTION_REQUIRED + "success");

            var params = {
                username: username,
                success: success,
                error: err,
                auth_type: authType,
                auth_value: authValue
            }

            validateUser(params);
        },

        submitTOTP: function (obj) {
            checkInitialized();

            var username = obj.username;
            var totp = obj.totp;
            var success = obj.success;
            var err = obj.error;

            validateString(username, Errors.INVALID_USERNAME);
            validateFunction(success, Errors.FUNCTION_REQUIRED + "success");
            validateString(totp, Errors.INVALID_AUTH_VALUE);

            var params = {
                username: username,
                auth_type: Constants.AUTH_TYPE_TOTP,
                auth_value: base64(sha256(totp)),
                success: success,
                error: err
            }

            validateUser(params);
        },

        submitSmsOtp: function (obj) {
            checkInitialized();

            var username = obj.username;
            var smsOtp = obj.smsOtp;
            var success = obj.success;
            var err = obj.error;

            validateString(username, Errors.INVALID_USERNAME);
            validateFunction(success, Errors.FUNCTION_REQUIRED + "success");
            validateString(smsOtp, Errors.INVALID_AUTH_VALUE);

            var params = {
                username: username,
                auth_type: Constants.AUTH_TYPE_SMS_OTP,
                auth_value: base64(sha256(smsOtp)),
                success: success,
                error: err,
                remember_me: obj.remember_me
            }

            validateUser(params);
        },

        generateSmsOtp: function (obj) {
            checkInitialized();

            var username = obj.username;
            var success = obj.success;
            var err = obj.error;

            validateString(username, Errors.INVALID_USERNAME);
            validateFunction(success, Errors.FUNCTION_REQUIRED + "success");

            var sendGenerateOtpRequest = function () {
                var postData = {
                    username: username,
                    web_device_parameters: JSON.stringify(fingerprint.browserAttributes),
                    web_device_parameter_checksum: fingerprint.browserFingerprint,
                    auth_type: Constants.AUTH_TYPE_SMS_OTP
                };

                if (userLocation !== undefined) {
                    postData["user_location"] = JSON.stringify(userLocation);
                }

                ajax.post(validateUserUri, postData,
                    function (data, status) {
                        if (status === 200) {
                            success(JSON.parse(data));
                        } else {
                            error(data, err);
                        }
                    });
            };

            if (!fingerprintCalculated) {
                onFingerprintCalculated = sendGenerateOtpRequest;
            } else {
                sendGenerateOtpRequest();
            }
        },

        submitEmailOtp: function (obj) {
            checkInitialized();

            var username = obj.username;
            var emailOtp = obj.emailOtp;
            var success = obj.success;
            var err = obj.error;

            validateString(username, Errors.INVALID_USERNAME);
            validateFunction(success, Errors.FUNCTION_REQUIRED + "success");
            validateString(emailOtp, Errors.INVALID_AUTH_VALUE);

            var params = {
                username: username,
                auth_type: Constants.AUTH_TYPE_EMAIL_OTP,
                auth_value: base64(sha256(emailOtp)),
                success: success,
                error: err,
                remember_me: obj.remember_me
            }

            validateUser(params);
        },

        generateEmailOtp: function (obj) {
            checkInitialized();

            var username = obj.username;
            var success = obj.success;
            var err = obj.error;

            validateString(username, Errors.INVALID_USERNAME);
            validateFunction(success, Errors.FUNCTION_REQUIRED + "success");

            var sendGenerateOtpRequest = function () {
                var postData = {
                    username: username,
                    web_device_parameters: JSON.stringify(fingerprint.browserAttributes),
                    web_device_parameter_checksum: fingerprint.browserFingerprint,
                    auth_type: Constants.AUTH_TYPE_EMAIL_OTP
                };

                if (userLocation !== undefined) {
                    postData["user_location"] = JSON.stringify(userLocation);
                }

                ajax.post(validateUserUri, postData,
                    function (data, status) {
                        if (status === 200) {
                            success(JSON.parse(data));
                        } else {
                            error(data, err);
                        }
                    });
            };

            if (!fingerprintCalculated) {
                onFingerprintCalculated = sendGenerateOtpRequest;
            } else {
                sendGenerateOtpRequest();
            }
        },

        deleteAccFromChooser: function (obj) {
            checkInitialized();

            var username = obj.username;
            var success = obj.success;
            var err = obj.error;

            validateString(username, Errors.INVALID_USERNAME);
            validateFunction(success, Errors.FUNCTION_REQUIRED + "success");

            var deleteAccFromChooserRequest = function () {
                var postData = {
                    username: username,
                    web_device_parameters: JSON.stringify(fingerprint.browserAttributes),
                    web_device_parameter_checksum: fingerprint.browserFingerprint,
                };

                ajax.postJson(deleteAccountFromChooserUri, postData,
                    function (data, status) {
                        if (status === 200) {
                            success(JSON.parse(data));
                        } else {
                            error(JSON.parse(data), err);
                        }
                    });
            };

            if (!fingerprintCalculated) {
                onFingerprintCalculated = deleteAccFromChooserRequest;
            } else {
                deleteAccFromChooserRequest();
            }
        },

		getBrowserAndLocationInfo: function () {
            return {
                browser: fingerprint.browserAttributes,
                location: userLocation
            }
		},

        invokeRegisterConfigs: function (obj) {
            checkInitialized();

            var success = obj.success;

            validateFunction(success, Errors.FUNCTION_REQUIRED + "success");

            if (!fingerprintCalculated) {
                onFingerprintCalculated = success;
            } else {
                success();
            }
		},
		submitForgotUsernameData: function (obj) {
            checkInitialized();

            var option = obj.option;
            var optionInput = obj.optionInput;
            var success = obj.success;
            var error = obj.error;
            
            var params = {
                option: option,
                optionInput: optionInput,
                success: success,
                error: error
            }

            submitForgorUsername(params);
        }

        // FIXME : Call this API from client lib
        /*
        getUserRegisteredAuthFactors: function(obj){
            checkInitialized();

            var success = obj.success;
            var err = obj.error;

            validateFunction(success, Errors.FUNCTION_REQUIRED + "success");

            ajax.get(getUserRegisteredAuthFactorsUri, {}, function (data, status) {
                if (status === 200) {
                    success(JSON.parse(data));
                } else {
                    error(JSON.parse(data), err);
                }
            })
        }
        */
        /* public functions end */
    }
}();