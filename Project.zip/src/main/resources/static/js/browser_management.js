var browserIconsNames = {
	chrome: "chrome",
	firefox: "firefox",
	safari: "safari",
	edge: "edge"
};

function getBrowserIcon(browserName) {
	browserName = browserName.toLowerCase();
	return "../img/" + (browserIconsNames[browserName] != undefined ? browserIconsNames[browserName] : "browser") + ".png";
}

function populateListItemDetails(browsers) {

    browsers.forEach(el => {
        let parsed = new UAParser(el.webDevMaster.webDeviceParameters.userAgent);
        let brName = parsed.getBrowser().name;
        let platform = parsed.getOS().name;

        $("#name" + el.userBrowser.webDeviceUuid).text(brName)
        $("#icon" + el.userBrowser.webDeviceUuid).attr("src",  getBrowserIcon(brName));
        $("#os" + el.userBrowser.webDeviceUuid).text(platform);
        $("#cdate" + el.userBrowser.webDeviceUuid).text(new Date(el.userBrowser.createdTs).toLocaleDateString("en-US"));
        $("#ldate" + el.userBrowser.webDeviceUuid).text(new Date(el.userBrowser.lastLoginTs).toLocaleDateString("en-US"));
    });
}

$(document).ready(function() {

        populateListItemDetails(browsers)
		
	    $('#info-modal').on("hidden.bs.modal", function(){
	    	 $(this).removeData();
	    });

        $('#delete-modal').on("hidden.bs.modal", function(){
	    	 $(this).removeData();
	    });
	    
	});
	
    $('#info-modal').on('show.bs.modal',function() {
	    var createdTs = $("#info-modal").data('bs.modal')._config.createdts;
        var lastTs = $("#info-modal").data('bs.modal')._config.lastts;
        var status = $("#info-modal").data('bs.modal')._config.status;
        var parsed = new UAParser($("#info-modal").data('bs.modal')._config.browsername);
        var brName = parsed.getBrowser().name;
	    var platform =parsed.getOS().name;

        $("#br-created").text(createdTs);
        $("#br-last").text(lastTs);
        $("#br-platform").text(platform);
        $("#br-name").text(brName);
        $("#br-version").text(parsed.getBrowser().major);
        $("#info-icon").attr("src",  getBrowserIcon(brName));
        $("#br-status").text(status)
    });

    $('#delete-modal').on('show.bs.modal',function() {

        var parsed = new UAParser($("#delete-modal").data('bs.modal')._config.browsername);
        var brName = parsed.getBrowser().name;
        $("#delete-icon").attr("src",  getBrowserIcon(brName));
    });

   function deleteBrowser() {
	   
     var loginId = $("#delete-modal").data('bs.modal')._config.name;
     var webDeviceUuid = $("#delete-modal").data('bs.modal')._config.uuid;

	 var url = 'webUserBrowsers/delete'
	   
     let reqData = {
        web_device_uuid: webDeviceUuid,
        login_id: loginId
     }
	 $.ajax({
		type: "POST", 
        dataType: 'json', 
        contentType: 'application/json', 
		url: url,   
		data: JSON.stringify(reqData),   
		success: function(res) {   
           $("#delete-modal").modal('hide');
           $.get("browser-management/list").done(function (fragment) {
               $("#browser_list_fragment").replaceWith(fragment);
               populateListItemDetails(browsers);
           })
        },   
        error: function(err) {
            if (err.status != "412") {
				window.location = "login";
			}else{
                console.log(err);
            }
        }   
	});

   }
    


