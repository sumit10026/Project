var username;
var configs = {};
var mobileNumberRegex;
var emailRegex;
var passPolicy;
var jspenc;
var waitingDelayBeforeRedirect;
let user = {
    mobileNumber: "",
    emailId: "",
};

function createDomInputElement(name, type, value) {
    var element = document.createElement("input");
    element.name = name;
    element.type = type;
    element.value = value;
    return element;
}

function buildFormElement() {}

/**
 * Moves element in FORWARD direction
 * elementId: id of the element to be moved
 * totalDistance: total width of the container of the element
 */
function moveElementForward(elementId, totalDistance) {
    var element = document.getElementById(elementId);
    var elementWidth = element.style.width;
    var elementPositionLeft = 0;
    var id = setInterval(frame, 10);

    function frame() {
        if (elementPositionLeft == totalDistance - elementWidth) {
            clearInterval(id);
        } else {
            elementPositionLeft++;
            element.style.left = elementPositionLeft + "px";
        }
    }
}

/**
 * Moves element in REVERSE direction
 * elementId: id of the element to be moved
 * totalDistance: total width of the container of the element
 */
function moveElementReverse(elementId, totalDistance) {
    var element = document.getElementById(elementId);
    var elementWidth = element.style.width;
    var elementPositionLeft = totalDistance;
    var id = setInterval(frame, 10);

    function frame() {
        if (elementPositionLeft == 0) {
            clearInterval(id);
        } else {
            elementPositionLeft--;
            element.style.left = elementPositionLeft + "px";
        }
    }
}

function enableRpPasswordButton() {

    let password = $("#rp_password").val();
    let confirmPassword = $("#rp_confirm_password").val();

	if (password.length == 0 || password != confirmPassword || !isValidPassword(password))
		$("#rp_register_button").prop("disabled", true);
	else $("#rp_register_button").prop("disabled", false);
}

function showRpPasswordStrength() {
	
    let password = $("#rp_password").val();

	$(".progress-bar").parent().removeClass("d-none");

	if (!isValidPassword(password)) {
		$(".progress-bar").attr("aria-valuenow", 100);
		$(".progress-bar").addClass("bg-danger");
		$(".progress-bar").prop("style").width = '100%';
		return;
	} else {
		let l = (passPolicy.maxL - passPolicy.minL) / 3;
		if (password.length <= (passPolicy.minL + l + 1)) {
			$(".progress-bar").attr("aria-valuenow", 33);
			$(".progress-bar").removeClass("bg-danger bg-success bg-info");
			$(".progress-bar").addClass("bg-warning");
			$(".progress-bar").prop("style").width = '33%';
			return;
		}
		if (password.length <= (passPolicy.minL + (l * 2))) {
			$(".progress-bar").attr("aria-valuenow", 66);
			$(".progress-bar").removeClass("bg-danger bg-success bg-warning");
			$(".progress-bar").addClass("bg-info");
			$(".progress-bar").prop("style").width = '66%';
			return;
		}
		$(".progress-bar").attr("aria-valuenow", 100);
		$(".progress-bar").removeClass("bg-danger bg-warning bg-info");
		$(".progress-bar").addClass("bg-success");
		$(".progress-bar").prop("style").width = '100%';
		return;

	}

}

function registerUser(data) {
    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "register/save-password",
        data: JSON.stringify(data),
        success: (res) => {
            $("#password-register").addClass("d-none");
            $("#authentication-options").removeClass("d-none");
            
            if (configs.configuration.fidoRoaming) {
                $(".faq2").removeClass("d-none");
            }

            if (configs.configuration.smsOtp) {
                $(".faq3").removeClass("d-none");
            }

            if (configs.configuration.emailOtp) {
                $(".faq4").removeClass("d-none");
            }

            $(".card-header:visible:first").next('.collapse').addClass('show');
        },
        error: (err) => {
            if (err.status == "422") {
                $("#rp_password_error_div").removeClass("d-none");
                $("#rp_password_error_div label").text(passPolicy.msg)
                $("#rp_password").val("");
                $("#rp_confirm_password").val("");
            } else {
                window.location = "error";
            }
        },
    });
}

function generateOtp(authType) {

    var authValue;

    let validate_button = "ea_validate_otp_button";
    let generate_button = "ea_generate_otp_button";

    $(`#pa_code_input_error_div`).addClass("d-none");
    $(`#ea_code_input_error_div`).addClass("d-none");

    if (authType === "smsotp") {
        validate_button = "pa_validate_otp_button";
        generate_button = "pa_generate_otp_button";
        authValue = $("#pa_mobile_input").val().trim();

        // vallidate
        $(`#pa_mobile_input_invalid_div`).addClass("d-none");
        if (!mobileNumberRegex.test(authValue)) {
            $(`#pa_mobile_input_invalid_div`).removeClass("d-none");
            return;
        }
    } else if (authType === "emailotp") {
        validate_button = "ea_validate_otp_button";
        generate_button = "ea_generate_otp_button";
        authValue = $("#ea_email_input").val().trim();

        // vallidate
        $(`#ea_email_input_invalid_div`).addClass("d-none");
        if (!emailRegex.test(authValue)) {
            $(`#ea_email_input_invalid_div`).removeClass("d-none");
            return;
        }
    }

    $.ajax({
        url: "register/generateOtp",
        type: "POST",
        contentType: 'application/json',
        data: JSON.stringify({
            username: username,
            auth_type: authType,
            auth_value: authValue
        }),
        success: function (response) {
            handleSuccessGenerateOtp(authType, response, validate_button, generate_button);
        },
        error: (err) => {
            if (err.status == "422") {
                if (authType === "smsotp") {
                    $("#pa_mobile_input_error_div").removeClass("d-none");
                } else if (authType === "emailotp") {
                    $("#ea_email_input_error_div").removeClass("d-none");
                }
            } else if (err.status == "401") {
                handleSuccessGenerateOtp(authType, err.responseText, validate_button, generate_button);
            } else {
                window.location = "error";
            }
        }
    });

}

function handleSuccessGenerateOtp(authType, response, validate_button, generate_button){
    if (authType === "smsotp") {
        $("#pa_code_input_div").removeClass("d-none")
        $("#pa_code_input").focus()
        $("#successOtpMsg").text(smsOTPGenerateSuccessMsg).css("display", "").css("color", "#0093d1").removeClass("d-none");
        fadeSuccessOtpMsg();
    } else if (authType === "emailotp") {
        $("#ea_email_input_div").removeClass("d-none")
        $("#ea_code_input").focus()
        $("#successEmailOtpMsg").text(emailOTPGenerateSuccessMsg).css("display", "").css("color", "#0093d1").removeClass("d-none");
        fadeSuccessEmailOtpMsg();
    }

    $(`#${validate_button}_div`).removeClass("d-none");
    $(`#${generate_button}_div`).addClass("d-none");
    if (response) {
        $(`#${validate_button}_div`).removeClass("d-none");
        $(`#${generate_button}_div`).addClass("d-none");
    }
}

function fadeSuccessOtpMsg(){
	$("#successOtpMsg").delay(2000).fadeOut();
}

function fadeSuccessEmailOtpMsg(){
	$("#successEmailOtpMsg").delay(2000).fadeOut();
}

var sha256 = function (value) {
    return sjcl.hash.sha256.hash(value);
};

var base64 = function (value) {
    return sjcl.codec.base64.fromBits(value);
};

function submitToRegister(hideId) {
    var browserAndLocationInfo = SDK.getBrowserAndLocationInfo();

    $("#remember_me").val($("#defaultCheck1").is(":checked"));

    if (browserAndLocationInfo.location) {
        $("#user_location").val(JSON.stringify(browserAndLocationInfo.location));
    }

    if (browserAndLocationInfo.browser) {
        $("#web_device_parameters").val(JSON.stringify(browserAndLocationInfo.browser));
    }

    $(`#${hideId}`).addClass("d-none")

    //Disable support of Platform Authenticator
    /*if (SDK.isFidoPlatformAuthenticatorAvailable() && $("#remember_me").val() === 'true') {
        $("#passwordFlowPlatformRegConsent").removeClass("d-none");
    }else{
        submitRegisterForm();
    }*/
    submitRegisterForm();
}

function submitToPasswordLessRegister(hideId) {
    var browserAndLocationInfo = SDK.getBrowserAndLocationInfo();

    $("#remember_me").val($("#defaultCheck1").is(":checked"));

    if (browserAndLocationInfo.location) {
        $("#user_location").val(JSON.stringify(browserAndLocationInfo.location));
    }

    if (browserAndLocationInfo.browser) {
        $("#web_device_parameters").val(JSON.stringify(browserAndLocationInfo.browser));
    }

    $(`#${hideId}`).addClass("d-none")
    $("#activation-success").removeClass("d-none")

    setTimeout(() => { $("#submitRegister").submit(); }, waitingDelayBeforeRedirect);

}

function validateSmsOtp(authType) {

    var authValue = $("#pa_code_input").val().trim();

    $(`#pa_code_input_error_div`).addClass("d-none");
    if (authValue == "") {
        $(`#pa_code_input_error_div`).removeClass("d-none");
        $("#pa_code_input").val("");
        return;
    }

    $.ajax({
        url: "register/validateOtp",
        type: "POST",
        contentType: 'application/json',
        data: JSON.stringify({
            username: username,
            auth_type: "smsotp",
            auth_value: base64(sha256(authValue))
        }),
        success: function (response) {
            submitToRegister('phone-authentication');
        },
        error: (err) => {
            if (err.status == "422") {
                $(`#pa_code_input_error_div`).removeClass("d-none");
                $(`#pa_validate_otp_button_div`).removeClass("d-none");
                $(`#pa_generate_otp_button_div`).addClass("d-none");
                $("#pa_code_input").val("");
            } else {
                window.location = "error";
            }
        }
    });

}

function validateEmailOtp(authType) {

    var authValue = $("#ea_code_input").val().trim();

    $(`#ea_code_input_error_div`).addClass("d-none");
    if (authValue == "") {
        $(`#ea_code_input_error_div`).removeClass("d-none");
        $("#ea_code_input").val("");
        return;
    }

    $.ajax({
        url: "register/validateOtp",
        type: "POST",
        contentType: 'application/json',
        data: JSON.stringify({
            username: username,
            auth_type: "emailotp",
            auth_value: base64(sha256(authValue))
        }),
        success: function (response) {
            submitToRegister('email-authentication');
        },
        error: (err) => {
            if (err.status == "422") {
                $(`#ea_code_input_error_div`).removeClass("d-none");
                $(`#ea_validate_otp_button_div`).removeClass("d-none");
                $(`#ea_generate_otp_button_div`).addClass("d-none");
                $("#ea_code_input").val("");
            } else {
                window.location = "error";
            }
        }
    });

}

function backToPrevious(showElement, hideElement) {
    $(`#${showElement}`).removeClass("d-none");
    $(`#${hideElement}`).addClass("d-none");
}

function continueAuthentication(selectedElement) {
    $("#authentication-options").addClass("d-none");

    if (selectedElement == "phone-authentication") {
        $("#pa_mobile_input").val(user.mobileNumber);
        $(`#pa_mobile_input_invalid_div`).addClass("d-none");
        $(`#pa_code_input_error_div`).addClass("d-none");
        $(`#pa_code_input_div`).addClass("d-none");
        $(`#pa_generate_otp_button_div`).removeClass("d-none");
        $(`#pa_validate_otp_button_div`).addClass("d-none");
    } else if (selectedElement == "email-authentication") {
        $("#ea_email_input").val(user.emailId);
        $(`#ea_email_input_invalid_div`).addClass("d-none");
        $(`#ea_code_input_error_div`).addClass("d-none");
        $("#ea_email_input_div").addClass("d-none")
        $(`#ea_generate_otp_button_div`).removeClass("d-none");
        $(`#ea_validate_otp_button_div`).addClass("d-none");
    } else if (selectedElement == "fido-authentication") {
        $("#fidoPending").show();
        $("#fidoStatus,#fidoRetry").addClass("d-none");
        $(".fido_back_button").removeClass("d-none");
    }

    $(`#${selectedElement}`).removeClass("d-none");

    $(':input:enabled:visible:first').focus();
}

function fetchPublicKey() {

    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "register/fetchPublicKey",
        success: (res) => {
            jspenc = new JSEncrypt();
            jspenc.setPublicKey("-----BEGIN PUBLIC KEY-----\n" + res + "\n-----END PUBLIC KEY-----");
        },
        error: (err) => {
            window.location = "error";
        },
    });

}

function getConfigs() {

    var browserAndLocationInfo = SDK.getBrowserAndLocationInfo();

    var data = {
        "web_device_parameters": JSON.stringify(browserAndLocationInfo.browser)
    };

    $.ajax({
        type: "POST",
        contentType: "application/json",
        url: "register/configs",
        data: JSON.stringify(data),
        success: (res) => {
            configs = res;

            if (!configs) {
                return;
            }

            username = configs.username;
            $("#rp_username").val(username);
            user.mobileNumber = configs.mobileNumber;
            user.emailId = configs.email;

            if (configs.configuration) {
                if(!configs.configuration.alwaysAskForPassword){
                    //Disable support of Platform Authenticator
                    /*if (SDK.isFidoPlatformAuthenticatorAvailable()) {
                        $("#passwordLessWithPlatformAuth").removeClass("d-none");
                        $("#platformIcon").attr("src", getFidoIconByPlatform());
                    } else {
                        $("#passwordLessWithSelectedAuth").removeClass("d-none");
                    }*/
                    
                    // Changes for new screen for User Registration
                    // $("#passwordLessWithSelectedAuth").removeClass("d-none");
                    $("#setupSignInOptionsScreen").removeClass("d-none");
                }else{
                    $("#password-register").removeClass("d-none");
                }

                if (configs.configuration.mobileNumberRegex) {
                    mobileNumberRegex = new RegExp("^" + configs.configuration.mobileNumberRegex + "$");
                }

                if (configs.configuration.emailRegex) {
                    emailRegex = new RegExp("^" + configs.configuration.emailRegex + "$");
                }

                waitingDelayBeforeRedirect = configs.configuration.delayBeforeRedirect;
                
				if (!configs.configuration.rememberMe) {
					$("#registerUserScreenRememberMeDiv").addClass("d-none");
				}
				if (!configs.configuration.smsOtp) {
					$("#faqhead3").addClass("d-none");
				}
				if (!configs.configuration.emailOtp) {
					$("#faqhead4").addClass("d-none");
				}												

                if (configs.configuration.passPolicy) {
                    passPolicy = {
                        minL: configs.configuration.passPolicy.minL,
                        maxL: configs.configuration.passPolicy.maxL,
                        minLc: getReg('[a-z]', configs.configuration.passPolicy.minLc),
                        minUc: getReg('[A-Z]', configs.configuration.passPolicy.minUc),
                        minSc: getReg('[^a-zA-Z0-9]', configs.configuration.passPolicy.minSc),
                        minDg: getReg('\\d', configs.configuration.passPolicy.minDg),
                        rep: getReg('(.)\\1', configs.configuration.passPolicy.Repetition),
                        userIdcheck: configs.configuration.passPolicy.UserIDcheck,
                        msg: configs.configuration.passPolicy.msg
                    }

                    $("#pass-policy-tooltip").prop("title", passPolicy.msg).removeClass("d-none");
                        
                    $(function () {
                        $('[data-toggle="tooltip"]').tooltip();
                    });

                   if (configs.configuration.showPassStrength) {
                        $("#rp_password").keyup(function () {
                            showRpPasswordStrength();
                        });
                    }
                }

            }

        },
        error: (err) => {
            window.location = "error";
        },
    });

}

function getPass(pass) {
    if (!jspenc) {
        return;
    }

    return jspenc.encrypt(pass);
}

function getReg(reg, len) {
    return new RegExp(reg + "{" + len + "}");
}

function isValidPassword(val, u) {
    if (!passPolicy) {
        return true;
    }

    return val.length >= passPolicy.minL && val.length <= passPolicy.maxL && passPolicy.minLc.test(val) && passPolicy.minUc.test(val) && passPolicy.minDg.test(val) && passPolicy.minSc.test(val) && !passPolicy.rep.test(val) && (!passPolicy.userIdcheck || val.indexOf(u) < 0)
}

$(document).ready(function () {

    var token = $('#_csrf').attr('content');
    var header = $('#_csrf_header').attr('content');
    SDK.init({
        Token: token,
        Header: header,
        fidoConfig: {
            attestationOptionUri: "register/attestation/options",
            attestationResultUri: "register/attestation/result"
        }
    });

    var obj = {
        success: getConfigs
    };
    SDK.invokeRegisterConfigs(obj);

    //Platform Specific Fido Consent Page Logo
    $('#fidoIcon').attr('src', getFidoIconByPlatform());

    fetchPublicKey();

    // Enable and disable register button
    $("#rp_confirm_password, #rp_password").keyup(function () {
        enableRpPasswordButton();
    });

    // Register the password on register button clicked

    $("#rp_register_button").click(() => {

        $("#rp_password_error_div").addClass("d-none");

        var password = $("#rp_password").val();

        if (!isValidPassword(password)) {
            $("#rp_password_error_div").removeClass("d-none");
            $("#rp_password_error_div label").text(passPolicy.msg)
            $("#rp_password").val("");
            $("#rp_confirm_password").val("");

            return;
        }

        let data = {
            username: $("#rp_username").val(),
            auth_value: getPass(password),
            is_remember_me: $("#defaultCheck1").is(":checked")
        };

        registerUser(data);
    });

    var fidoRegistrationInfo = {
        username: username,
        success: () => {
            $("#fidoPending").hide();
            $("#fidoStatus").removeClass("d-none");
            $("#fidoStatus h3").text(userDeviceRegistrationSuccessMsg);
            // FIXME add delay
            submitToRegister('fido-authentication');
        },
        error: (error) => {
            $("#fidoPending").hide();
            $("#fidoStatus,#fidoRetry").removeClass("d-none");
            $(".fido_back_button").removeClass("d-none");
            $("#fidoStatus h3").text(
                error + userDeviceCheckNotAlreadyRegistered
            );
        },
    };
    
    var passwordLessSecurityKeyFidoRegistrationInfo = {
        username: username,
        success: () => {
            $("#passwordLessSecurityKeyFidoPending").hide();
            $("#passwordLessSecurityKeyFidoStatus").removeClass("d-none");
            $("#passwordLessSecurityKeyFidoStatus h3").text(userDeviceRegistrationSuccessMsg);
            // FIXME add delay
            submitToPasswordLessRegister('passwordLessSecurityKeySetup');
        },
        error: (error) => {
            $("#passwordLessSecurityKeyFidoPending").hide();
            $("#passwordLessSecurityKeyFidoStatus,#passwordLessSecurityKeyFidoRetry").removeClass("d-none");
            $(".passwordLessSecurityKeyFido_back_button").removeClass("d-none");
            $("#passwordLessSecurityKeyFidoStatus h3").text(
                error + userDeviceCheckNotAlreadyRegistered
            );
        },
    };

    var passwordLessPlatformAuthFidoRegistrationInfo = {
        username: username,
        success: () => {
            $("#passwordLessPlatformAuthFidoPending").hide();
            $("#passwordLessPlatformAuthFidoStatus").removeClass("d-none");
            $("#passwordLessPlatformAuthFidoStatus h3").text(userDeviceRegistrationSuccessMsg);
            // FIXME add delay
            submitToPasswordLessRegister('passwordLessPlatformAuthSetup');
        },
        error: (error) => {
            $("#passwordLessPlatformAuthFidoPending").hide();
            $("#passwordLessPlatformAuthFidoStatus,#passwordLessPlatformAuthFidoRetry").removeClass("d-none");
            $(".passwordLessPlatformAuthFido_back_button").removeClass("d-none");
            $("#passwordLessPlatformAuthFidoStatus h3").text(
                error + userDeviceCheckNotAlreadyRegistered
            );
        },
    };

    var passwordFlowPlatformAuthFidoRegistrationInfo = {
        username: username,
        success: () => {
            $("#passwordFlowPlatformAuthFidoPending").hide();
            $("#passwordFlowPlatformAuthFidoStatus").removeClass("d-none");
            $("#passwordFlowPlatformAuthFidoStatus h3").text(userDeviceRegistrationSuccessMsg);
            
            $("#passwordFlowPlatformAuthSetup").addClass("d-none");
            submitRegisterForm();
        },
        error: (error) => {
            $("#passwordFlowPlatformAuthFidoPending").hide();
            $("#passwordFlowPlatformAuthFidoStatus,#passwordFlowPlatformAuthFidoRetry").removeClass("d-none");
            $(".passwordFlowPlatformAuthFido_back_button").removeClass("d-none");
            $("#passwordFlowPlatformAuthFidoStatus h3").text(
                error + userDeviceCheckNotAlreadyRegistered
            );
        },
    };

    $("#fido_authenticate,#fidoRetry").click(function () {
        // if (SDK.isFidoPlatformAuthenticatorAvailable()) {
        //     $("#fidoAuthSelection").modal();
        // } else {
            $("#fidoRetry,.fido_back_button").addClass("d-none");
            $("#fidoNonPlatformAuthBtn").click();
        // }
    });

    //Passwordless Security Key Setup Registration
    $("#passwordLessSecurityKeyFido_authenticate,#passwordLessSecurityKeyFidoRetry").click(function () {
        $("#passwordLessSecurityKeyFidoRetry,.passwordLessSecurityKeyFido_back_button").addClass("d-none");

        $("#passwordLessSecurityKeyFidoPending").hide();
        $("#passwordLessSecurityKeyFidoStatus").removeClass("d-none");
        $("#passwordLessSecurityKeyFidoStatus h3").text(userDeviceRegistrationWaitMsg);
        passwordLessSecurityKeyFidoRegistrationInfo.username = username;
        passwordLessSecurityKeyFidoRegistrationInfo.registrationOptions = {
            requireResidentKey: false
        };
        SDK.registerFIDO(passwordLessSecurityKeyFidoRegistrationInfo);
    });

    //Passwordless Platform Authenticator Setup Registration
    $("#passwordLessPlatformAuthFido_authenticate,#passwordLessPlatformAuthFidoRetry").click(function () {
        $("#passwordLessPlatformAuthFidoRetry,.passwordLessPlatformAuthFido_back_button").addClass("d-none");

        $("#passwordLessPlatformAuthFidoPending").hide();
        $("#passwordLessPlatformAuthFidoStatus").removeClass("d-none");
        $("#passwordLessPlatformAuthFidoStatus h3").text(userDeviceRegistrationWaitMsg);
        passwordLessPlatformAuthFidoRegistrationInfo.username = username;
        SDK.registerFidoPlatformAuthenticator(passwordLessPlatformAuthFidoRegistrationInfo);
    });

    //Password Flow Platform Authenticator Setup Registration
    $("#passwordFlowPlatformAuthFido_authenticate,#passwordFlowPlatformAuthFidoRetry").click(function () {
        $("#passwordFlowPlatformAuthFidoRetry,.passwordFlowPlatformAuthFido_back_button").addClass("d-none");

        $("#passwordFlowPlatformAuthFidoPending").hide();
        $("#passwordFlowPlatformAuthFidoStatus").removeClass("d-none");
        $("#passwordFlowPlatformAuthFidoStatus h3").text(userDeviceRegistrationWaitMsg);
        passwordFlowPlatformAuthFidoRegistrationInfo.username = username;
        SDK.registerFidoPlatformAuthenticator(passwordFlowPlatformAuthFidoRegistrationInfo);
    });

    $("#fidoPlatformAuthBtn").click(function () {
        $("#fidoPending").hide();
        $("#fidoStatus").removeClass("d-none");
        $("#fidoStatus h3").text(userDeviceRegistrationWaitMsg);
        fidoRegistrationInfo.username = username;
        SDK.registerFidoPlatformAuthenticator(fidoRegistrationInfo);
    });

    $("#fidoNonPlatformAuthBtn").click(function () {
        $("#fidoPending").hide();
        $("#fidoStatus").removeClass("d-none");
        $("#fidoStatus h3").text(userDeviceRegistrationWaitMsg);
        fidoRegistrationInfo.username = username;
        fidoRegistrationInfo.registrationOptions = {
            userVerification: "preferred",
            requireResidentKey: false
        };
        SDK.registerFIDO(fidoRegistrationInfo);
    });

    $("#password_register_form").keypress(function (e){
        if (e.which == 13 || event.keyCode == 13) {
		    let password = $("#rp_password").val();
	    	let confirmPassword = $("#rp_confirm_password").val();

			if (password == confirmPassword && isValidPassword(password)) {
	            jQuery("#rp_register_button").trigger("click");
			}
            return false;
        }
    })

    $("#pa_form").keypress(function (e){
        if (e.which == 13 || event.keyCode == 13) {
            jQuery("#pa_validate_otp_button").trigger("click");
            return false;
        }
    })

    $("#ea_form").keypress(function (e){
        if (e.which == 13 || event.keyCode == 13) {
            jQuery("#ea_validate_otp_button").trigger("click");
            return false;
        }
    })

    $(':input:enabled:visible:first').focus();
});

function gotoPasswordFlow(currentDiv){
    $("#"+currentDiv).addClass("d-none");
    $("#password-register").removeClass("d-none");
    $(".passwordLessSecurityKeyFido_back_button").removeAttr("onclick");
    $(".passwordLessSecurityKeyFido_back_button").attr("onclick", "backToPrevious('passwordLessWithSelectedAuth', 'passwordLessSecurityKeySetup')");
}

function gotoPasswordLessSecurityKeyFidoRegisterFlow(currentDiv){
    $("#"+currentDiv).addClass("d-none");
    $("#passwordLessSecurityKeySetup").removeClass("d-none");
    $(".passwordLessSecurityKeyFido_back_button").removeAttr("onclick");
    $(".passwordLessSecurityKeyFido_back_button").attr("onclick", "backToPrevious('" + currentDiv + "', 'passwordLessSecurityKeySetup')");
}

function gotoPasswordLessPlatformAuthFidoRegisterFlow(currentDiv){
    $("#"+currentDiv).addClass("d-none");
    $("#passwordLessPlatformAuthSetup").removeClass("d-none");
    $("#passwordLessPlatformAuthIcon").removeAttr('src');
    $("#passwordLessPlatformAuthIcon").attr('src', $('#platformIcon').attr('src'));
}

function gotoPasswordFlowPlatformAuthFidoRegisterFlow(currentDiv){
    $("#"+currentDiv).addClass("d-none");
    $("#passwordFlowPlatformAuthSetup").removeClass("d-none");
    $("#passwordFlowPlatformAuthIcon").removeAttr('src');
    $("#passwordFlowPlatformAuthIcon").attr('src', getFidoIconByPlatform());
}

  function submitRegisterForm(){
    $("#activation-success").removeClass("d-none");
    setTimeout(() => { $("#submitRegister").submit(); }, waitingDelayBeforeRedirect);
  }
  
  function getFidoIconByPlatform(){
    let parsed = new UAParser();
    let platform = parsed.getOS().name;
    var iconPath = '';
  
    switch(platform){
  
      case 'Windows':
        iconPath = "images/fido_icon_windows.png";
        break;
  
      case 'Mac OS':
        iconPath = "images/fido_icon_mac.png";
        break;
        
      case 'iOS':
        iconPath = "images/fido_icon_ios.png";
        break;  
  
      case 'Android':
        iconPath = "images/fido_icon_android.png";
        break;
  
      default:
        //For Linux and other types of OS
        iconPath = "images/fido_icon_default.png";
        break;  
  
    }
  
    return iconPath;
  }