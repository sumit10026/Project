package com.uniken.custom.appender;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.LinkedBlockingQueue;

import org.bson.Document;
import org.slf4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.mongodb.async.SingleResultCallback;
import com.uniken.utils.Constants;
import com.uniken.utils.MongoDBUtils;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.AppenderBase;

@SuppressWarnings("deprecation")
public class MongodbAppender extends AppenderBase<ILoggingEvent> {

    private static final LoggerContext LOGGER_CONTEXT = new LoggerContext();
    private static final Logger LOG = LOGGER_CONTEXT.getLogger(MongodbAppender.class);

    private static LinkedBlockingQueue<Document> LOGS_IN_DB_BUFFER = new LinkedBlockingQueue<Document>();

    static {
        try {
            if (Constants.LOG_DB_NAME == null) {
                Constants.init();
            }
            if (MongoDBUtils.LOG_DATABASE == null) {
                MongoDBUtils.init();
            }
            if (Constants.INTERVAL_FOR_DB_LOGGING > 0) {
                final MongodbAppender appender = new MongodbAppender();

                TimerTask timerTask = new TimerTask() {
                    @Override
                    public void run() {
                        if (LOGS_IN_DB_BUFFER.isEmpty())
                            return;
                        appender.insertLog();
                    }
                };

                Timer timer = new Timer();

                timer.schedule(timerTask, 0, Constants.INTERVAL_FOR_DB_LOGGING);
            }
        } catch (NoSuchAlgorithmException e) {
            LOG.error("Exception occurred : ", e);
            throw new RuntimeException("Filed to initialize constants", e);
        } catch (GeneralSecurityException e) {
            LOG.error("Exception occurred : ", e);
            throw new RuntimeException("Filed to initialize constants", e);
        } catch (IOException e) {
            LOG.error("Exception occurred : ", e);
            throw new RuntimeException("Filed to initialize constants", e);
        } catch (Exception e) {
            LOG.error("Exception occurred : ", e);
            throw new RuntimeException("Filed to initialize constants", e);
        }
    }

    @Override
    protected void append(final ILoggingEvent event) {
        if (event == null)
            return; // just in case

        try {
            Document eventLog = prepareLogFormatMessage(event);
            if (eventLog == null)
                return;

            LOGS_IN_DB_BUFFER.add(eventLog);

            if (LOGS_IN_DB_BUFFER.size() >= Constants.LOG_IN_DB_THRESHOLD) {
                insertLog();
            }
        } catch (Exception e) {
            LOG.error("Exception occurred while inserting log in database", e);
        }
    }

    /**
     * Insert log in the database
     */
    void insertLog() {

        List<Document> list = new ArrayList<Document>();
        LOGS_IN_DB_BUFFER.drainTo(list);
        MongoDBUtils.EVENT_LOG.insertMany(list, new SingleResultCallback<Void>() {

            @Override
            public void onResult(final Void data, final Throwable t) {

                if (t != null) {
                    LOG.error("Exception occurred while inserting log in database. ", t);
                    LOG.error("Unable to store following logs.", list);

                    // TODO : Akash - Code commented because it may
                    // hamper
                    // performance
                    // and memory utilization. Rewrite and fix below

                    /*
                    LOG.info("Adding logs back to the buffer");
                    if (!LOGS_IN_DB_BUFFER.isEmpty()) {
                        LOGS_IN_DB_BUFFER.addAll(list);
                    }
                    */
                }
            }
        });
    }

    /**
     * This method will prepare loggingEvent into a desired log format
     * 
     * @param event
     * @return : returns bson document which is to be inserted in database
     */
    private Document prepareLogFormatMessage(final ILoggingEvent event) {

        Map<String, String> mdcValues = event.getMDCPropertyMap();
        if (mdcValues.isEmpty()) {
            return null;
        }

        mdcValues.put("msg", event.getFormattedMessage());

        Gson gson = new Gson();
        JsonElement log = gson.toJsonTree(mdcValues);

        // Setting createdTs in db document
        Document dbLogDocument = Document.parse(gson.toJson(log));
        dbLogDocument.append("createdTs", new Date());

        return dbLogDocument;
    }
}
