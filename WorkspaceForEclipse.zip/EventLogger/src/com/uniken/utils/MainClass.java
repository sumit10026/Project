package com.uniken.utils;

import com.uniken.logging.EventId;
import com.uniken.logging.EventLogger;

public class MainClass {

    public static void main(final String[] args) {

        int i = 10;
        while (i > 0) {
            EventLogger.log(EventId.BlazeServer.APP_INIT_FAILURE, "127.0.0.1", String.valueOf(i), "test" + i,
                    "dasdasdd|Asdsda");
            i--;
        }
    }

}
