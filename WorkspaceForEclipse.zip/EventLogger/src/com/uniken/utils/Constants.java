package com.uniken.utils;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.NoSuchAlgorithmException;

import com.uniken.commons.config.AppConfigLoader;
import com.uniken.domains.enums.appconfig.CommonConfigKeys;
import com.uniken.domains.enums.appconfig.ModuleNames;
import com.uniken.encdecutils.PropertiesEncryptDecrypt;

public class Constants {

    public static boolean MONGO_IS_SSL;
    public static String MONGODB_KEY_CERTIFICATE_PASSWORD;
    public static String MONGODB_CERTIFICATE_PATH;
    public static String MONGODB_KEY_STORE_PASSWORD;
    public static String MONGODB_KEY_STORE_PATH;
    public static String CONNECTION_STRING;
    public static String MONGODB_USER_NAME;
    public static String LOG_DB_NAME;
    public static String MONGODB_HOST_PORT_INFO;
    public static String MONGODB_SOURCE;

    public static boolean IS_TIMER_BASED_DB_LOGGING_ENABLED;
    public static int INTERVAL_FOR_DB_LOGGING;
    public static int LOG_IN_DB_THRESHOLD;

    public static final String LOG_COLLECTION_NAME = "event_logs";

    public static void init() throws NoSuchAlgorithmException, GeneralSecurityException, IOException {
        final AppConfigLoader appConfigLoader = new AppConfigLoader(ModuleNames.EventLogger.getName());
        final AppConfigLoader COMMON_CONFIG_LOADER = new AppConfigLoader(ModuleNames.CommonConfigs.getName());

        Constants.MONGO_IS_SSL = Boolean.parseBoolean(COMMON_CONFIG_LOADER.getConfigValue(CommonConfigKeys.MONGODB_IS_SSL_ENABLED.getName()));
        Constants.LOG_DB_NAME = COMMON_CONFIG_LOADER.getConfigValue(CommonConfigKeys.DB_NAME_RELID.getName());
        Constants.CONNECTION_STRING = COMMON_CONFIG_LOADER.getConfigValue(CommonConfigKeys.MONGODB_CONNECTION_STRING.getName());

        Constants.MONGODB_CERTIFICATE_PATH = COMMON_CONFIG_LOADER.getConfigValue(CommonConfigKeys.MONGODB_KEYCERT_PATH.getName());
        Constants.MONGODB_KEY_CERTIFICATE_PASSWORD = PropertiesEncryptDecrypt.decryptWithAES(COMMON_CONFIG_LOADER.getConfigValue(CommonConfigKeys.MONGODB_KEYCERT_PWD.getName()));
        Constants.MONGODB_KEY_STORE_PATH = COMMON_CONFIG_LOADER.getConfigValue(CommonConfigKeys.MONGODB_STORE_PATH.getName());
        Constants.MONGODB_KEY_STORE_PASSWORD = PropertiesEncryptDecrypt.decryptWithAES(COMMON_CONFIG_LOADER.getConfigValue(CommonConfigKeys.MONGODB_STORE_PWD.getName()));

        Constants.MONGODB_USER_NAME = COMMON_CONFIG_LOADER.getConfigValue(CommonConfigKeys.MONGODB_USERNAME.getName());
        Constants.MONGODB_SOURCE = COMMON_CONFIG_LOADER.getConfigValue(CommonConfigKeys.MONGODB_SOURCE.getName());

        Constants.LOG_IN_DB_THRESHOLD = Integer.parseInt(appConfigLoader.getConfigValue("log.in.db.threshold"));
        Constants.IS_TIMER_BASED_DB_LOGGING_ENABLED = Boolean
                .parseBoolean(appConfigLoader.getConfigValue("is.timer.based.db.logging.enabled"));
        Constants.INTERVAL_FOR_DB_LOGGING = Integer.parseInt(appConfigLoader.getConfigValue("interval.for.db.logging"));

    }

}
