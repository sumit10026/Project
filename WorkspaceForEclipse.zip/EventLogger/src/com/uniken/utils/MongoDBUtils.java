package com.uniken.utils;

import org.bson.Document;
import org.slf4j.Logger;

import com.mongodb.WriteConcern;
import com.mongodb.async.client.MongoClient;
import com.mongodb.async.client.MongoCollection;
import com.mongodb.async.client.MongoDatabase;
import com.uniken.commons.factory.DBConnectionFactoryProvider;

import ch.qos.logback.classic.LoggerContext;

public class MongoDBUtils {

    @SuppressWarnings("deprecation")
    private static MongoClient client;

    @SuppressWarnings("deprecation")
    public static MongoDatabase LOG_DATABASE;

    @SuppressWarnings("deprecation")
    public static MongoCollection<Document> EVENT_LOG;

    private static final LoggerContext LOGGER_CONTEXT = new LoggerContext();
    private static final Logger LOG = LOGGER_CONTEXT.getLogger(MongoDBUtils.class);

    public static void init() {

        final DBConnectionFactoryProvider dbcfp = new DBConnectionFactoryProvider();

        try {
            client = dbcfp.createMongoClient(Constants.MONGO_IS_SSL, Constants.MONGODB_KEY_CERTIFICATE_PASSWORD,
                    Constants.MONGODB_CERTIFICATE_PATH, Constants.MONGODB_KEY_STORE_PASSWORD,
                    Constants.MONGODB_KEY_STORE_PATH, Constants.CONNECTION_STRING, Constants.MONGODB_USER_NAME, null);

            if (null != client) {
                LOG_DATABASE = client.getDatabase(Constants.LOG_DB_NAME);
                LOG_DATABASE.withWriteConcern(WriteConcern.ACKNOWLEDGED);

                EVENT_LOG = LOG_DATABASE.getCollection(Constants.LOG_COLLECTION_NAME);

            } else {
                LOG.error("Exception occurred in DBConnectionFactoryException while creating MongoClient");
                throw new RuntimeException(
                        "Exception occurred in DBConnectionFactoryException while creating MongoClient");
            }

        } catch (Exception e) {
            LOG.error("Exception occurred in while creating database connection", e);
            throw new RuntimeException("Filed to initialize database", e);
        }
    }

    public void destroy() {
        this.client.close();
    }
}
