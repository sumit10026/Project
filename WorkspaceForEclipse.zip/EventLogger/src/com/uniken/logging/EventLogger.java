package com.uniken.logging;

import java.lang.management.ManagementFactory;
import java.net.Inet6Address;
import java.net.InetAddress;
import java.net.MalformedURLException;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.nio.file.Paths;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.MDC;

import ch.qos.logback.classic.LoggerContext;
import ch.qos.logback.classic.util.ContextInitializer;
import ch.qos.logback.core.joran.spi.JoranException;

/**
 * Class for logging events. Make sure have EVENT_LOGGER_FILE_PATH set which
 * specifies event logging configuration file.
 */
public class EventLogger {

    private static final String MESSAGES_SEPARATOR = "|";
    private static final String EMPTY_VALUE_REPLACEMENT_STRING = "";
    private static final LoggerContext LOGGER_CONTEXT = new LoggerContext();
    /** logging configuration start */
    static {
        final String eventLoggerFilePath = System.getenv("EVENT_LOGGER_FILE_PATH");
        if (eventLoggerFilePath == null) {
            throw new RuntimeException("Make sure EVENT_LOGGER_FILE_PATH environment variable is set");
        }
        try {
            new ContextInitializer(LOGGER_CONTEXT).configureByResource(Paths.get(eventLoggerFilePath).toUri().toURL());
        } catch (MalformedURLException | JoranException e) {
            throw new RuntimeException(e);
        }
    }
    private static final Logger LOG = LOGGER_CONTEXT.getLogger(EventLogger.class);
    /** logging configuration end */

    private static final String PROCESS_ID = getProcessId("<PID>");
    private static final String SERVER_IPADDRESSES = getServerIPAddresses();

    /**
     * Logs the event.
     *
     * @param eventId
     *            the event id
     * @param sourceIP
     *            the source IP
     * @param requesterId
     *            the requester id
     * @param userId
     *            the user id
     * @param messages
     *            the messages
     */
    public static void log(final EventId eventId, final String sourceIP, final String requesterId, final String userId,
            final String... messages) {
        MDC.put("processId", PROCESS_ID);
        MDC.put("moduleName", eventId.getClass().getSimpleName());
        MDC.put("serverIP", SERVER_IPADDRESSES);
        MDC.put("sourceIP", getText(sourceIP));
        MDC.put("eventCode", mapOfEventNameVsCode.get(eventId.toString()));
        MDC.put("eventId", eventId.toString());
        MDC.put("requesterId", getText(requesterId));
        MDC.put("userId", getText(userId));

        LOG.error(getMessaages(messages));
    }

    /**
     * Gets the process id.
     *
     * @param fallback
     *            the fallback
     * @return the process id
     */
    private static String getProcessId(final String fallback) {
        // Note: may fail in some JVM implementations
        // therefore fallback has to be provided

        // something like '<pid>@<hostname>', at least in SUN / Oracle JVMs
        final String jvmName = ManagementFactory.getRuntimeMXBean().getName();
        final int index = jvmName.indexOf('@');

        if (index < 1) {
            // part before '@' empty (index = 0) / '@' not found (index = -1)
            return fallback;
        }

        try {
            return Long.toString(Long.parseLong(jvmName.substring(0, index)));
        } catch (NumberFormatException e) {
            // ignore
        }
        return fallback;
    }

    /**
     * Gets the server IP addresses.
     *
     * @return the server IP addresses
     */
    private static String getServerIPAddresses() {
        String ip = "";
        try {
            Enumeration<NetworkInterface> interfaces = NetworkInterface.getNetworkInterfaces();
            while (interfaces.hasMoreElements()) {
                NetworkInterface iface = interfaces.nextElement();
                // filters out 127.0.0.1 and inactive interfaces
                if (iface.isLoopback() || !iface.isUp())
                    continue;

                Enumeration<InetAddress> addresses = iface.getInetAddresses();
                while (addresses.hasMoreElements()) {
                    InetAddress addr = addresses.nextElement();

                    if (addr instanceof Inet6Address)
                        continue;

                    if (ip != "") {
                        ip += ",";
                    }

                    ip += addr.getHostAddress();
                    // System.out.println(iface.getDisplayName() + " " + ip);
                }
            }
        } catch (SocketException e) {
            throw new RuntimeException(e);
        }
        return ip;
    }

    /**
     * Returns blank for null, passed value otherwise.
     *
     * @param value
     *            the value
     * @return the text
     */
    private static String getText(final String value) {
        return (value == null || value.trim().isEmpty()) ? EMPTY_VALUE_REPLACEMENT_STRING : value;
    }

    /**
     * Gets the {@link EventLogger#MESSAGES_SEPARATOR} separated messages.
     *
     * @param value
     *            the value
     * @return the message
     */
    private static String getMessaages(final String... values) {
        for (int i = 0; i < values.length; i++) {
            values[i] = getText(values[i]);
        }

        return String.join(MESSAGES_SEPARATOR, values);
    }
    
    public static final Map<String, String> mapOfEventNameVsCode = new HashMap<String, String>();
    
    static {
        for (final EventId.BlazeServer type : EventId.BlazeServer.values()) {
            mapOfEventNameVsCode.put(type.toString(), type.getCode());
        }
        for (final EventId.BlaZeAdapter type : EventId.BlaZeAdapter.values()) {
            mapOfEventNameVsCode.put(type.toString(), type.getCode());
        }
        for (final EventId.AccessServer type : EventId.AccessServer.values()) {
            mapOfEventNameVsCode.put(type.toString(), type.getCode());
        }
        for (final EventId.IdvServer type : EventId.IdvServer.values()) {
            mapOfEventNameVsCode.put(type.toString(), type.getCode());
        }
        for (final EventId.RelIdVerifyServer type : EventId.RelIdVerifyServer.values()) {
            mapOfEventNameVsCode.put(type.toString(), type.getCode());
        }
        for (final EventId.IdentityAdapter type : EventId.IdentityAdapter.values()) {
            mapOfEventNameVsCode.put(type.toString(), type.getCode());
        }
        for (final EventId.RelidAuthServer type : EventId.RelidAuthServer.values()) {
            mapOfEventNameVsCode.put(type.toString(), type.getCode());
        }
        for (final EventId.GatewayManager type : EventId.GatewayManager.values()) {
            mapOfEventNameVsCode.put(type.toString(), type.getCode());
        }
        for (final EventId.UserAPIServer type : EventId.UserAPIServer.values()) {
            mapOfEventNameVsCode.put(type.toString(), type.getCode());
        }
        for (final EventId.DBArchiver type : EventId.DBArchiver.values()) {
            mapOfEventNameVsCode.put(type.toString(), type.getCode());
        }
        for (final EventId.ModulesManager type : EventId.ModulesManager.values()) {
            mapOfEventNameVsCode.put(type.toString(), type.getCode());
        }
        for (final EventId.GMAPIServer type : EventId.GMAPIServer.values()) {
            mapOfEventNameVsCode.put(type.toString(), type.getCode());
        }
    }

}
