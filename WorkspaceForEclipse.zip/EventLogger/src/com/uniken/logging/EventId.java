package com.uniken.logging;

/**
 * Specifies Event Ids that can be logged.
 */
public interface EventId {

    /**
     * The Enum BlazeServer.
     */
    enum BlazeServer implements EventId {
    	USER_LOGIN_FAILURE("101"),
    	USER_LOGGED_OUT("102"),
        CHECK_CREDENTIALS_FAILURE("103"),
        APP_INIT_FAILURE("104"),
        INVALID_DEVICE_STATUS("105"),
        INVALID_RELID_STATUS("106"),
        INVALID_SERVER("107"),
        TUNNEL_CREATION_FAILURE("108");

        private String code;
        BlazeServer(final String code) {
            this.code = code;
        }
        public String getCode() {
            return code;
        }
    }

    enum BlaZeAdapter implements EventId {
        APP_INIT_STARTED("121"),
        APP_INIT_SUCCESSFUL("122"),
        USER_LOGIN_SUCCESSFUL("123"),
        APP_SESSION_KNOCKED_OFF("124"),
        USER_SESSION_KNOCKED_OFF("125"),
        USER_RMAK_SUCCESSFUL("126"),
        SESSION_POLICY_KNOCKED_OFF_USER_SESSION("127"),
        GET_NOTIFICATION_REQUEST_SUCCESSFUL("128"),
        GET_NOTIFICATION_REQUEST_FAILURE("129"),
        UPDATE_NOTIFICATION_REQUEST_SUCCESSFUL("130"),
        UPDATE_NOTIFICATION_REQUEST_FAILURE("131"),
        UPDATE_NOTIFICATION_RESPONSE_SUCCESSFUL("132"),
        UPDATE_NOTIFICATION_RESPONSE_FAILURE("133"),
        APP_INIT_USING_BLOCKED_DEVICE("134"),
        USER_SESSIONS_LIMIT_EXHAUSTED("135"),
        SDK_AUTHENTICATOR_EVENT_LOGGED("136"),
        IDV_GENERATE_TRANSACTION_ID("137"),
        IDV_REGULA_RECORD_TRANSACTION("138");

        private String code;
        BlaZeAdapter(final String code) {
            this.code = code;
        }
        public String getCode() {
            return code;
        }
    }

    enum AccessServer implements EventId {
    	APP_SESSION_VALIDATE_SUCCESS("171"),
    	USER_SESSION_VALIDATE_SUCCESS("172"),
    	APP_SESSION_VALIDATE_FAILURE("173"),
    	USER_SESSION_VALIDATE_FAILURE("174"),
    	APP_SESSION_EXPIRED_ACCESS_SERVER("175"),
    	USER_SESSION_EXPIRED_ACCESS_SERVER("176"),
    	MTLS_TUNNEL_SUCCESS("177"),
    	MTLS_TUNNEL_FAILURE("178");

        private String code;
        AccessServer(final String code) {
            this.code = code;
        }
        public String getCode() {
            return code;
        }
    }
    
    enum IdvServer implements EventId {
    	IS_USER_TEMPLATED_AVAILABLE("181"),
    	INIT_SELFIE_BIOMETRIC_MATCH_REQUEST("182"),
    	COMPLETE_SELFIE_BIOMETRIC_MATCH_REQUEST("183"),
    	LIVENESS_AND_COMPARE_REQUEST("184"),
    	SUBMIT_KYC_INFO_REQUEST("185"),
    	BIOMETRIC_OPT_IN_REQUEST("186"),
    	KYC_API_INVALID_RESPONSE("187"),
    	KYC_UPDATE_USER_ID_SUCCESS("188"),
    	KYC_UPDATE_USER_ID_FAILED("189");

        private String code;
        IdvServer(final String code) {
            this.code = code;
        }
        public String getCode() {
            return code;
        }
    }
    
    enum IdvWebServer implements EventId {
    	IS_USER_TEMPLATED_AVAILABLE("151"),
    	INIT_SELFIE_BIOMETRIC_MATCH_REQUEST("152"),
    	COMPLETE_SELFIE_BIOMETRIC_MATCH_REQUEST("153"),
    	LIVENESS_AND_COMPARE_REQUEST("154"),
    	SUBMIT_KYC_INFO_REQUEST("155"),
    	BIOMETRIC_OPT_IN_REQUEST("156"),
    	KYC_API_INVALID_RESPONSE("157"),
    	KYC_UPDATE_USER_ID_SUCCESS("158"),
    	KYC_UPDATE_USER_ID_FAILED("159");

        private String code;
        IdvWebServer(final String code) {
            this.code = code;
        }
        public String getCode() {
            return code;
        }
    }

    /**
     * The Enum RelIdVerifyServer.
     */
    enum RelIdVerifyServer implements EventId {
        UPDATE_NOTIFICATION_SUCCESSFUL("191"),
        UPDATE_NOTIFICATION_FAILURE("192");

        private String code;
        RelIdVerifyServer(final String code) {
            this.code = code;
        }
        public String getCode() {
            return code;
        }
    }

    /**
     * The Enum IdentityAdapter.
     */
    enum IdentityAdapter implements EventId {
        INVALID_USER_LOGIN_ATTEMPT("201"),
        NEW_DEVICE_ACTIVATION("202"),
        INVALID_PASSWORD_ENTERED("203"),
        FIRST_DEVICE_ACTIVATION("204"),
        NEW_USER_ACTIVATION("205"),
        USER_BLOCKED("206"),
        INCORRECT_ACTIVATION_CODE("207"),
        INCORRECT_OTP("208"),
        USER_PASSWORD_UPDATE_SUCCESSFUL("209"),
        USER_PASSWORD_UPDATE_FAILURE("210"),
        USER_SECQA_UPDATE_SUCCESSFUL("211"),
        USER_SECQA_UPDATE_FAILURE("212"),
        USER_PASSWORD_VALIDATE_SUCCESSFUL("213"),
        USER_PASSWORD_VALIDATE_FAILURE("214"),
        USER_SECQA_VALIDATE_SUCCESSFUL("215"),
        USER_SECQA_VALIDATE_FAILURE("216"),
        NEW_AD_USER("217"),
        DEVICE_LIMIT_EXCEEDED("218"),
        RESET_DEVICE("219"),
        RESEND_ACTIVATION_CODE("220"),
        RESEND_ACCESS_CODE("221"),
        ACTIVATION_CODE_EXPIRED("222"),
        ENROLL_NEW_DEVICE_REQUEST("223"),
        DISCARD_ACTIVE_VERIFYAUTH("224"),
        DEVICE_IS_WHITELISTED("225"),
        DEVICE_IS_NOT_WHITELISTED("226"),
        ACTIVATION_CODE_VALIDATED("227"),
        OTP_VALIDATED("228"),
        EXT_NID_VALIDATION_SUCCESS("229"),
        EXT_NID_VALIDATION_FAILURE("230"),
        EXT_SERVER_BIO_VALIDATION_SUCCESS("231"),
        EXT_SERVER_BIO_VALIDATION_FAILURE("232"),
        PASSWORD_MATCHED("233"),
        VERIFY_AUTH_INITIATED("234"),
        VERIFY_AUTH_ACCEPTED("235"),
        VERIFY_AUTH_REJECTED("236"),
        USER_DEVICE_BLOCKED_VERIFY_AUTH_FRAUD("237"),
        VERIFY_AUTH_FAILED("238"),
        ATTEMPTS_EXHAUSTED("239"),
        USER_DEVICE_BLOCKED_LOGIN_ATTEMPTS_EXHAUSTED("240"),
        USER_DEVICE_BLOCKED_FIRST_DEVICE_ATTEMPTS_EXHAUSTED("241"),
        USER_DEVICE_BLOCKED_NEW_DEVICE_ATTEMPTS_EXHAUSTED("242"),
        USER_DEVICE_DELETED("243"),
        USER_DEVICE_UPDATED("244"),
        PASSWORD_UPDATED("245"),
        PASSWORD_UPDATE_FAILED("246"),
        CHECK_USER_SUCCESS("247"),
        DEVICE_UPDATED("248"),
        UPDATE_DEVICE_NAME_REGEX_FAILURE("249"),
        DEVICE_MANAGEMENT_COOLING_PERIOD_POLICY_NOT_MET("250"),
        APP_REINSTALLATION("251"),
        FORGOT_PASSWORD("252"),
        LOGIN_ATTEMPT_BY_BLOCKED_USER("253"),
        LOGIN_ATTEMPT_BY_BLOCKED_DEVICE("254");

        private String code;
        IdentityAdapter(final String code) {
            this.code = code;
        }
        public String getCode() {
            return code;
        }
    }
    
    enum RelidAuthServer implements EventId {
    	INIT_AUTHENTICATION_REQ("301"),
    	AUTHENTICATION_SUCCESS("302"),
    	AUTHENTICATION_FAILED("303"),
    	INIT_GENERATE_ACCESS_TOKEN_REQ("304"),
    	GENERATE_ACCESS_TOKEN_FAILED("305"),
        GENERATE_ACCESS_TOKEN_SUCCESS("306"),
        INIT_REVOKE_ACCESS_TOKEN_REQ("307"),
        REVOKE_ACCESS_TOKEN_FAILED("308"),
        REVOKE_ACCESS_TOKEN_SUCCESS("309"),
        GET_ACCESS_TOKEN_BY_REFRESH_TOKEN("310"),
        INIT_GENERATE_AUTH_CODE_REQ("311"),
        GENERATE_AUTH_CODE_SUCCESS("312"),
        GENERATE_AUTH_CODE_FAILED("313"),
        INIT_USER_AUTHENTICATION_REQ("314"),
        INIT_USER_AUTHENTICATION_SUCCESS("315"),
        INIT_USER_AUTHENTICATION_FAILED("316"),
        INVALID_REQ_URI("317"),
        INIT_VALIDATE_USER_REQ("318"),
        VALIDATE_USER_REQ_SUCCESS("319"),
        VALIDATE_USER_REQ_FAILURE("320"),
        INIT_USER_INFO_REQ("321"),
        USER_INFO_REQ_SUCCESS("322"),
        USER_INFO_REQ_FAILURE("323"),
        VERIFY_AUTH_INITIATED_RAS("324"),
        VERIFY_AUTH_ACCEPTED_RAS("325"),
        VERIFY_AUTH_REJECTED_RAS("326"),
        USER_DEVICE_BLOCKED_VERIFY_AUTH_FRAUD_RAS("327"),
        VERIFY_AUTH_FAILED_RAS("328"),
        INIT_TOTP_VALIDATION("329"),
        TOTP_VALIDATION_FAILED("330"),
        INVALID_TOTP("331"),
        REPLAYED_TOTP("332"),
        SMS_OTP_PREREQUISITES_FAILED("333"),
        INVALID_OTP("334"),
        OTP_VALIDATED_RAS("335"),
        AUTHENTICATION_STARTED("336"),
        AUTHENTICATION_COMPLETED("337"),
        USER_ACC_DELETION_FROM_ACC_CHOOSER("338"),
        USER_REMEMBER_ME_BROWSER("339"),
        EXHAUSTED_ATTMEPT_COUNTER("340"),
        INVALID_WEB_USER_STATUS("341"),
        INVALID_USER_STATUS("342"),
        DECREMENT_ATTMEPT_COUNTER("343"),
        SESSION_INVALIDATED("344"),
        USER_NOT_FOUND("345"),
        AUTH_FACTOR_DISABLED("346"),
        INVALID_SECURE_COOKIE("347"),
        VERIFY_AUTH_NOT_ACTED("348"),
        FIDO_AUTH_FAILED("349"),
        UPDATE_SECURE_COOKIE("350"),
        ADD_SECURE_COOKIE("351"),
        ADD_USER_BROWSER("352"),
        DECREMENT_AUTH_GENERATION_ATTMEPT_COUNTER("353"),
        EXHAUSTED_AUTH_GENERATION_ATTMEPT_COUNTER("354"),
        EMAIL_OTP_PREREQUISITES_FAILED("355"),
        INVALID_EMAIL("356"),
        EMAIL_VALIDATED_RAS("357"),
        USER_ACTIVATION_OTP_GENERATION_STARTED("358"),
        USER_ACTIVATION_OTP_GENERATION_SUCCESS("359"),
        USER_ACTIVATION_OTP_GENERATION_FAILED("360"),
        USER_ACTIVATION_OTP_VALIDATION_STARTED("361"),
        USER_ACTIVATION_OTP_VALIDATION_SUCCESS("362"),
        USER_ACTIVATION_OTP_VALIDATION_FAILED("363"),
        USER_ACTIVATION_SAVE_PASSWORD_STARTED("364"),
        USER_ACTIVATION_SAVE_PASSWORD_SUCCESS("365"),
        USER_ACTIVATION_SAVE_PASSWORD_FAILED("366"),
        USER_ACTIVATION_FIDO_REG_STEP1_STARTED("367"),
        USER_ACTIVATION_FIDO_REG_STEP1_SUCCESS("368"),
        USER_ACTIVATION_FIDO_REG_STEP1_FAILED("369"),
        USER_ACTIVATION_FIDO_REG_STEP2_STARTED("370"),
        USER_ACTIVATION_FIDO_REG_STEP2_SUCCESS("371"),
        USER_ACTIVATION_FIDO_REG_STEP2_FAILED("372"),
        PASS_VALIDATION_FAILED("373"),
        USER_ACTIVATION_DECREMENT_AUTH_GENERATION_ATTMEPT_COUNTER("374"),
        USER_ACTIVATION_EXHAUSTED_AUTH_GENERATION_ATTMEPT_COUNTER("375");

        private String code;
        RelidAuthServer(final String code) {
            this.code = code;
        }
        public String getCode() {
            return code;
        }
    }

    /**
     * The Enum GatewayManager.
     */
    enum GatewayManager implements EventId {
        USER_ADDED("401"), 
        USER_BLOCKED_GM("402"), 
        USER_UNBLOCKED("403"), 
        USER_RESET("404"), 
        USER_UNENROLLED("405"), 
        NEW_RELID_ENROLLMENT("406"), 
        USER_UPDATE_STATUS("407"),
        USER_UPDATE_DETAILS("408"),
        USER_UPDATE_PRIMARY_GROUP("409"),
        USER_UPDATE_SECONDARY_GROUPS("410"),
        USER_DELETED("411"),
        USER_PAUSED("412"),
        USER_UNPAUSED("413"),
        USER_DEVICE_BLOCKED("414"),
        USER_DEVICE_UNBLOCKED("415"),
        USER_DEVICE_DELETED_GM("416"),
        DEVICE_MASTER_BLOCKED("417"),
        DEVICE_MASTER_UNBLOCKED("418"),
        RELID_LICENSE_REQUEST_SUCCESSFUL("419"),
        RELID_LICENSE_REQUEST_FAILURE("420"),
        RELID_LICENSE_UPLOAD_SUCCESSFUL("421"),
        RELID_LICENSE_UPLOAD_FAILURE("422"),
        RELID_LICENSE_ACTIVATE_SUCCESSFUL("423"),
        RELID_LICENSE_ACTIVATE_FAILURE("424"),
        RELID_LICENSE_DEACTIVATE_SUCCESSFUL("425"),
        RELID_LICENSE_DEACTIVATE_FAILURE("426"),
        RELID_LICENSE_SERVERID_UPDATE_SUCCESSFUL("427"),
        RELID_LICENSE_SERVERID_UPDATE_FAILURE("428"),
        RELID_GEN_EXCEPTION("429"),
        MODULE_CONFIGS_BACKUP_STARTED("430"),
        MODULE_CONFIGS_BACKUP_SUCCESS("431"),
        MODULE_CONFIGS_RESTORE_STARTED("432"),
        MODULE_CONFIGS_RESTORE_SUCCESS("433"),
        MODULE_CONFIGS_BACKUP_FAILURE("434"),
        MODULE_CONFIGS_RESTORE_FAILURE("435"),
        CHALLENGE_CONFIGS_BACKUP_STARTED("436"),
        CHALLENGE_CONFIGS_BACKUP_SUCCESS("437"),
        CHALLENGE_CONFIGS_RESTORE_STARTED("438"),
        CHALLENGE_CONFIGS_RESTORE_SUCCESS("439"),
        CHALLENGE_CONFIGS_BACKUP_FAILURE("440"),
        CHALLENGE_CONFIGS_RESTORE_FAILURE("441"),
        NOTIFICATION_CONFIGS_BACKUP_STARTED("442"),
        NOTIFICATION_CONFIGS_BACKUP_SUCCESS("443"),
        NOTIFICATION_CONFIGS_RESTORE_STARTED("444"),
        NOTIFICATION_CONFIGS_RESTORE_SUCCESS("445"),
        NOTIFICATION_CONFIGS_BACKUP_FAILURE("446"),
        NOTIFICATION_CONFIGS_RESTORE_FAILURE("447"),
        CRED_STORE_BACKUP_STARTED("448"),
        CRED_STORE_BACKUP_SUCCESS("449"),
        CRED_STORE_RESTORE_STARTED("450"),
        CRED_STORE_RESTORE_SUCCESS("451"),
        CRED_STORE_BACKUP_FAILURE("452"),
        CRED_STORE_RESTORE_FAILURE("453"),
        RESTART_MODULE_INITIATED("454");

        private String code;
        GatewayManager(final String code) {
            this.code = code;
        }
        public String getCode() {
            return code;
        }
    }

    /**
     * The Enum UserAPIServer.
     */
    enum UserAPIServer implements EventId {
        USER_UPDATE_STATUS_UAS("501"),
        USER_UPDATE_DETAILS_UAS("502"),
        USER_UPDATE_PRIMARY_GROUP_UAS("503"),
        USER_UPDATE_SECONDARY_GROUPS_UAS("504"),
        USER_UNENROLLED_UAS("505"),
        USER_DELETED_UAS("506"),
        USER_PAUSED_UAS("507"),
        USER_UNPAUSED_UAS("508"),
        USER_RESET_UAS("509"),
        USER_BLOCKED_UAS("510"),
        USER_UNBLOCKED_UAS("511"),
        TOTP_VALIDATION_REPLAYED("512"),
        TOTP_VALIDATION_SUCCESS("513"),
        TOTP_VALIDATION_FAILURE("514"),
        TOTP_VALIDATION_FAILURE_TOTP_DISABLED("515"),
        SET_PREDEFINED_CODE("516"),
    	USER_CREATED_UAS("517");

        private String code;
        UserAPIServer(final String code) {
            this.code = code;
        }
        public String getCode() {
            return code;
        }
    }
    
    enum DBArchiver implements EventId {
        APP_SESSION_EXPIRED("540"),
        USER_SESSION_EXPIRED("541"),
        USER_INACTIVITY_WARNING("542"),
        USER_INACTIVITY_USER_INACTIVE("543"),
        USER_PASSWORD_EXPIRY_WARNING("544"),
        DEVICE_INACTIVITY_WARNING("545"),
        DEVICE_INACTIVITY_DEVICE_INACTIVE("546");

        private String code;
        DBArchiver(final String code) {
            this.code = code;
        }
        public String getCode() {
            return code;
        }
    }

    enum ModulesManager implements EventId {
    	MONITORING_MODULES("601"),
    	RESTART_MODULE_PROCESSED("602");

        private String code;
        ModulesManager(final String code) {
            this.code = code;
        }
        public String getCode() {
            return code;
        }
    }
    
    /**
     * The Enum Gateway Manager Web Service.
     */
    enum GMAPIServer implements EventId {
        USER_ADDED_GMAPI("701"), 
        USER_BLOCKED_GMAPI("702"), 
        USER_UNBLOCKED_GMAPI("703"), 
        USER_RESET_GMAPI("704"), 
        USER_UNENROLLED_GMAPI("705"), 
        NEW_RELID_ENROLLMENT_GMAPI("706"), 
        USER_UPDATE_STATUS_GMAPI("707"),
        USER_UPDATE_DETAILS_GMAPI("708"),
        USER_UPDATE_PRIMARY_GROUP_GMAPI("709"),
        USER_UPDATE_SECONDARY_GROUPS_GMAPI("710"),
        USER_DELETED_GMAPI("711"),
        USER_PAUSED_GMAPI("712"),
        USER_UNPAUSED_GMAPI("713"),
        USER_DEVICE_BLOCKED_GMAPI("714"),
        USER_DEVICE_UNBLOCKED_GMAPI("715"),
        USER_DEVICE_DELETED_GMAPI("716"),
        DEVICE_MASTER_BLOCKED_GMAPI("717"),
        DEVICE_MASTER_UNBLOCKED_GMAPI("718"),
        RELID_LICENSE_REQUEST_SUCCESSFUL_GMAPI("719"),
        RELID_LICENSE_REQUEST_FAILURE_GMAPI("720"),
        RELID_LICENSE_UPLOAD_SUCCESSFUL_GMAPI("721"),
        RELID_LICENSE_UPLOAD_FAILURE_GMAPI("722"),
        RELID_LICENSE_ACTIVATE_SUCCESSFUL_GMAPI("723"),
        RELID_LICENSE_ACTIVATE_FAILURE_GMAPI("724"),
        RELID_LICENSE_DEACTIVATE_SUCCESSFUL_GMAPI("725"),
        RELID_LICENSE_DEACTIVATE_FAILURE_GMAPI("726"),
        RELID_LICENSE_SERVERID_UPDATE_SUCCESSFUL_GMAPI("727"),
        RELID_LICENSE_SERVERID_UPDATE_FAILURE_GMAPI("728"),
        RELID_GEN_EXCEPTION_GMAPI("729");

        private String code;
        GMAPIServer(final String code) {
            this.code = code;
        }
        public String getCode() {
            return code;
        }
    }
    
    /**
     * The Enum CIBAServer.
     */
    enum CIBAServer implements EventId {
    	CIBA_SERVER_RESTARTED("161");
    	private String code;
        CIBAServer(final String code) {
            this.code = code;
        }
        public String getCode() {
            return code;
        }
    }

}
