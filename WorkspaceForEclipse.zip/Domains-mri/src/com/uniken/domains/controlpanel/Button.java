package com.uniken.domains.controlpanel;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.relid.LogDomain;

@Document(collection = "button_config")
public class Button extends LogDomain {

    public static final String BUTTON_BTID = "btid";
    public static final String BUTTON_NAME = "name";
    public static final String BUTTON_IMG = "img";
    public static final String BUTTON_PARAMS = "params";
    public static final String BUTTON_ACTION = "action";
    public static final String BUTTON_EXECUTABLE = "exe";
    public static final String BUTTON_DISPLAY_ORDER = "displayorder";
    public static final String BUTTON_AUTO_LAUNCH = "autolaunch";

    @SerializedName(value = BUTTON_BTID)
    @Indexed(unique = true)
    private String btid;

    @SerializedName(value = BUTTON_NAME)
    private String name;

    @SerializedName(value = BUTTON_IMG)
    private ButtonImage img;

    @SerializedName(value = BUTTON_PARAMS)
    private ButtonParams params;

    @SerializedName(value = BUTTON_ACTION)
    private String action;

    @SerializedName(value = BUTTON_EXECUTABLE)
    private String exe;

    @SerializedName(value = BUTTON_DISPLAY_ORDER)
    private String displayorder;

    @SerializedName(value = BUTTON_AUTO_LAUNCH)
    private String autolaunch;

    public String getBtid() {
        return btid;
    }

    public void setBtid(final String btid) {
        this.btid = btid;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public ButtonImage getImg() {
        return img;
    }

    public void setImg(final ButtonImage img) {
        this.img = img;
    }

    public ButtonParams getParams() {
        return params;
    }

    public void setParams(final ButtonParams params) {
        this.params = params;
    }

    public String getAction() {
        return action;
    }

    public void setAction(final String action) {
        this.action = action;
    }

    public String getExe() {
        return exe;
    }

    public void setExe(final String exe) {
        this.exe = exe;
    }

    public String getDisplayorder() {
        return displayorder;
    }

    public void setDisplayorder(final String displayorder) {
        this.displayorder = displayorder;
    }

    public String getAutolaunch() {
        return autolaunch;
    }

    public void setAutolaunch(final String autolaunch) {
        this.autolaunch = autolaunch;
    }

}
