package com.uniken.domains.controlpanel;

import com.google.gson.annotations.SerializedName;

public class ButtonParams {

    public static final String PARAM_PATH = "path";
    public static final String PARAM_ARGS = "args";

    @SerializedName(value = PARAM_PATH)
    private String path;

    @SerializedName(value = PARAM_ARGS)
    private String args;

    public String getPath() {
        return path;
    }

    public void setPath(final String path) {
        this.path = path;
    }

    public String getArgs() {
        return args;
    }

    public void setArgs(final String args) {
        this.args = args;
    }

}
