package com.uniken.domains.controlpanel;

import com.google.gson.annotations.SerializedName;

public class ButtonImage {

    public static final String IMAGE_TYPE = "type";
    public static final String IMAGE_DATA = "data";

    @SerializedName(value = IMAGE_TYPE)
    private String type;

    @SerializedName(value = IMAGE_DATA)
    private String data;

    public String getType() {
        return type;
    }

    public void setType(final String type) {
        this.type = type;
    }

    public String getData() {
        return data;
    }

    public void setData(final String data) {
        this.data = data;
    }

}
