package com.uniken.domains.enums;

public enum RelIdType {

    SYSTEM("System"), APP_AGENT("App Agent"), USER("User");

    private String value;

    RelIdType(final String value) {
        this.value = value;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

}
