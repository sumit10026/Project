package com.uniken.domains.enums;

public enum ValidateSessionPolicyRequestName {

    GEN_HNDLR_CHECK_CREDS_REQ, ACTIVATE_USER_REQ, USER_SESSION_REQUEST

}
