
/**
 * 
 */
package com.uniken.domains.enums;

/**
 * This will contains the database collection name.
 * 
 * @author Uniken Inc.
 */
public enum CollectionNames {

    RELID_AUTH_INFO("relid_auth_info"),
    RELID_AUTH_INFO_ARC("relid_auth_info_arc"),
    USER_AUTH_INFO("user_auth_info"),
    USER_AUTH_INFO_ARC("user_auth_info_arc"),
    DEV_MASTER("dev_master"),
    SESSION_TICKET("session_ticket"),
    SESSION_TICKET_LOG("session_ticket_log"),
    SESSION_TICKET_LOG_USER("session_ticket_log_user"),
    SESSION_TICKET_LOG_APP("session_ticket_log_app"),
    LOGIN_DETAIL("login_detail"),
    STATE_CHALLENGE_MAPPING("stateChallengeMapping"),
    TCP_CONCURRENCY("tcp_concurrency"),
    USER_CONCURRENCY("user_concurrency"),
    DIGITAL_CERTIFICATE("digital_certificate"),
    NOTIFICATION("notification"),
    NOTIFICATION_LOG("notification_log"),
    COMMON_KEY_ASSOCIATION("common_key_association"),
    USER_ACTIVITY_LOG("user_activity_log"),
    POLICY("policy"),
    COMMON_CONFIG("common_config"),
    BUTTON_CONFIG("button_config"),
    RVN_REMINDER("rvn_reminder"),
    RVN_REMINDER_LOG("rvn_reminder_log"),
    RVN_FALLBACK("rvn_fallback"),
    RVN_FALLBACK_LOG("rvn_fallback_log"),
    USER_STATUS_PUBLISH_LOG("user_status_publish_log"),
    CLUSTER("cluster"),
    NODE_DETAILS("node_details"),
    SYSTEM_CONFIG("system_config"),
    PARAM("param"),
    MTLS_LOG("mtls_log"),
    TUNNEL_LOG("tunnel_log"),
    MESSAGE("message"),
    MESSAGE_ARC("message_arc"),
    LOGIN_DETAILS_ARC("login_details_arc"),
    USER("user"),
    ADMIN_ACTIVITY_LOG("adminActivityLog"),
    OIDC_CONFIG("oidc_config"),
    USERID_LOGINID_MAPPING("userid_loginid_mapping"),
    TOTP_VALIDATION_LOG("totp_validation_log"),
    APP_AGENT("appAgent"),
    DFP_POLICY("dfp_policy"),
    USER_OTP("user_otp"),
    USER_OTP_ARC("user_otp_arc"),
    WEB_USER_OTP("web_user_otp"),
    WEB_USER_OTP_ARC("web_user_otp_arc"),
    MTD_LOGS("mtd_logs"),
    EVENT_LOGS("event_logs"),
    GROUP("group"),
    USER_DEVICE_APP_MAPPING("user_device_app_mapping"),
    OAUTH_AUTHENTICATION_LOG("oauth_authentication_log"),
    OAUTH_ACCESS_TOKEN("oauth_access_token"),
    OAUTH_ACCESS_TOKEN_LOG("oauth_access_token_log"),
    OAUTH_REFRESH_TOKEN("oauth_refresh_token"),
    OAUTH_REFRESH_TOKEN_LOG("oauth_refresh_token_log"),
    OAUTH_AUTHORIZATION_CODE("oauth_authorization_code"),
    ENTERPRISE_INFO("enterpriseInfo"),
    GENERATE_RVN_MSG_LOGS("generate_rvn_message_requests"),
    WEB_DEV_MASTER("web_dev_master"),
    OAUTH_AUTHORIZATION_CODE_LOG("oauth_authorization_code_log"),
    // Camel casing collection name to be used and followed here onwards
    WEB_SESSION_TICKET("webSessionTicket"),
    WEB_SESSION_TICKET_ARC("webSessionTicketArc"),
    AUTH_FACTOR_CONFIG("authFactorConfig"),
    AUTH_FACTOR_MAPPING("authFactorMapping"),
    FIDO2_AUTHN_DB_RECORDS("fido2AuthRecords"),
    FIDO2_AUTHN_DB_RECORDS_ARCHIVED("fido2AuthRecordsArchived"),
    AUTHENTICATION_INFO("authentication_info"),
    REQUEST_RESPONSE_LOG("request_response_log"),
    WEB_DEV_SESSIONS("web_dev_sessions"),
    WEB_DEV_SESSIONS_ARC("web_dev_sessions_arc"),
    IDV_WEB_SESSIONS("idv_web_sessions"),
    IDV_WEB_SESSIONS_ARC("idv_web_sessions_arc");

    private String collectionName;

    private CollectionNames(final String collectionName) {
        this.collectionName = collectionName;
    }

    /**
     * Get collection name.
     * 
     * @return Collection name.
     */
    public String getCollectionName() {
        return collectionName;
    }

}
