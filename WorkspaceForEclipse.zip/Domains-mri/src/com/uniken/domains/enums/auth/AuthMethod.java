package com.uniken.domains.enums.auth;

import java.util.ArrayList;
import java.util.List;

public enum AuthMethod {

    BASIC("Basic"), BEARER("Bearer");

    private String name;

    AuthMethod(final String name) {
        this.name = name;
    }

    public String getAuthMethod() {
        return name;
    }

    private static final List<String> authMethods = new ArrayList<>();

    static {
        for (final AuthMethod authMethod : values()) {
            authMethods.add(authMethod.getAuthMethod());
        }
    }

    public static List<String> getAuthMethods() {
        return new ArrayList<>(authMethods);
    }

}
