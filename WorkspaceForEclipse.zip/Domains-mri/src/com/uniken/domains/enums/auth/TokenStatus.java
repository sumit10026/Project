/**
 * 
 */
package com.uniken.domains.enums.auth;

/**
 * @author Kushal Jaiswal
 */
public enum TokenStatus {
    EXPIRED, REVOKED;
}
