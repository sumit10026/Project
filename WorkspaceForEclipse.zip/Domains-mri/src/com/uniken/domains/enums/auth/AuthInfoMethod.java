package com.uniken.domains.enums.auth;

import java.util.ArrayList;
import java.util.List;

public enum AuthInfoMethod {

    BASIC("Basic"), OAUTH2("OAuth2");

    private String name;

    AuthInfoMethod(final String name) {
        this.name = name;
    }

    public String getAuthInfoMethod() {
        return name;
    }

    private static final List<String> authInfoMethods = new ArrayList<>();

    static {
        for (final AuthInfoMethod authMethod : values()) {
            authInfoMethods.add(authMethod.getAuthInfoMethod());

        }
    }

    public static List<String> getAuthInfoMethods() {
        return new ArrayList<>(authInfoMethods);
    }

}
