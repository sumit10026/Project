package com.uniken.domains.enums.auth;

import java.util.Arrays;
import java.util.List;

public enum OAuthScopes {

    ALL(Arrays.asList("all")), OIDC(Arrays.asList("all", "openid"));

    private List<String> scope;

    OAuthScopes(final List<String> scope) {
        this.scope = scope;
    }

    /**
     * @returns scope
     */
    public List<String> getScope() {
        return scope;
    }

}
