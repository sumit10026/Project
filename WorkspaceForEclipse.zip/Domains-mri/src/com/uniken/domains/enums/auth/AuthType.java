package com.uniken.domains.enums.auth;

import java.util.HashMap;
import java.util.Map;

public enum AuthType {

    PASS("pass"),
    RELID_VERIFY("relid-verify"),
    TOTP("totp"),
    FIDO("fido"),
    FIDO_PLATFORM("fido-platorm"),
    FIDO_ROAMING("fido-roaming"),
    SMSOTP("smsotp"),
    SECURE_COOKIE("secure-cookie"),
    EMAILOTP("emailotp");

    private static final Map<String, AuthType> values = new HashMap<>();

    static {
        for (final AuthType authType : values()) {
            values.put(authType.getName(), authType);
        }
    }

    private String name;

    AuthType(final String name) {
        this.name = name;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    public static boolean isValidElement(final String authType) {
        return values.containsKey(authType);
    }

    public static AuthType getAuthTypeByName(final String authType) {
        return values.get(authType);
    }
}
