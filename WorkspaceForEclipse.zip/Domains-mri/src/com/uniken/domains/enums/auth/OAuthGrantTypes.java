package com.uniken.domains.enums.auth;

public enum OAuthGrantTypes {

    CLIENT_CREDENTIALS("client_credentials"),
    AUTHORIZATION_CODE("authorization_code"),
    REFRESH_TOKEN("refresh_token"),
    PASSWORD("password"),
    CIBA("ciba");

    private final String grantType;

    OAuthGrantTypes(final String grantType) {
        this.grantType = grantType;

    }

    /**
     * Gets the grant type.
     *
     * @return the grant type
     */
    public String getGrantType() {
        return grantType;
    }

}
