package com.uniken.domains.enums.auth;

import static java.util.Arrays.asList;

import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public enum OAuthResources {

    RELID_VERIFY_SERVER("relid-verify-server",
            "REL-ID Verify",
            asList(OAuthGrantTypes.CLIENT_CREDENTIALS),
            new HashSet<String>(OAuthScopes.ALL.getScope())),

    USER_API_SERVER("user-api-server",
            "User API Server",
            asList(OAuthGrantTypes.CLIENT_CREDENTIALS),
            new HashSet<String>(OAuthScopes.ALL.getScope())),

    OIDC("OIDC",
            "OIDC",
            asList(OAuthGrantTypes.AUTHORIZATION_CODE, OAuthGrantTypes.REFRESH_TOKEN),
            new HashSet<String>(OAuthScopes.OIDC.getScope())),

    GM_API_SERVER("gm-api-server",
            "GM API Server",
            asList(OAuthGrantTypes.CLIENT_CREDENTIALS),
            new HashSet<String>(OAuthScopes.ALL.getScope())),

    BLAZE_SERVER("blaze-server",
            "Blaze Server",
            asList(OAuthGrantTypes.PASSWORD, OAuthGrantTypes.REFRESH_TOKEN),
            new HashSet<String>(OAuthScopes.ALL.getScope())),

    CIBA_SERVER("ciba-server",
            "CIBA Server",
            asList(OAuthGrantTypes.CLIENT_CREDENTIALS),
            new HashSet<String>(OAuthScopes.ALL.getScope())),

    IDV_WEB_SERVER("idv-web-server",
            "IDV Web Server",
            asList(OAuthGrantTypes.CLIENT_CREDENTIALS),
            new HashSet<String>(OAuthScopes.ALL.getScope()));

    private static final Map<String, String> resourceIdIdentifier_vs_resourceId_map = new HashMap<>();
    private static final Map<String, OAuthResources> resourceIdIdentifier_vs_resource_map = new HashMap<>();
    private static final Map<String, Set<String>> resourceIdIdentifier_vs_OAuthScopes_map = new HashMap<>();

    static {

        for (final OAuthResources resource : values()) {
            resourceIdIdentifier_vs_resourceId_map.put(resource.getResourceIdIdentifier(), resource.getResourceId());
            resourceIdIdentifier_vs_resource_map.put(resource.getResourceIdIdentifier(), resource);
            resourceIdIdentifier_vs_OAuthScopes_map.put(resource.getResourceIdIdentifier(), resource.getScopes());
        }
    }

    private String resourceId;
    private String resourceIdIdentifier;
    private final List<OAuthGrantTypes> grantTypes;
    private final Set<String> scopes;

    OAuthResources(final String resourceIdIdentifier, final String resourceId, final List<OAuthGrantTypes> grantTypes,
            final Set<String> scopes) {
        this.resourceIdIdentifier = resourceIdIdentifier;
        this.resourceId = resourceId;
        this.grantTypes = grantTypes;
        this.scopes = scopes;
    }

    public String getResourceId() {
        return resourceId;
    }

    public String getResourceIdIdentifier() {
        return resourceIdIdentifier;
    }

    public List<OAuthGrantTypes> getGrantTypes() {
        return grantTypes;
    }

    public static Map<String, String> getAllesources() {
        return new HashMap<>(resourceIdIdentifier_vs_resourceId_map);
    }

    public Set<String> getScopes() {
        return scopes;
    }

    public static Set<String> getAuthorizedGrantTypesForResourceIds(final Collection<String> resourceIds) {
        Set<String> grantTypesForResourceIds = null;

        if (resourceIds != null && !resourceIds.isEmpty()) {
            grantTypesForResourceIds = new HashSet<>();
            for (final String resource : resourceIds) {
                final List<OAuthGrantTypes> resourceGrantTypes = resourceIdIdentifier_vs_resource_map.get(resource)
                        .getGrantTypes();
                grantTypesForResourceIds.addAll(
                        resourceGrantTypes.stream().map(OAuthGrantTypes::getGrantType).collect(Collectors.toSet()));
            }
        }

        return grantTypesForResourceIds;
    }

    public static String getResourceId(final String resourceIdIdentifier) {
        return resourceIdIdentifier_vs_resourceId_map.get(resourceIdIdentifier);
    }

    public static Set<String> getScopes(final Collection<String> resourceIds) {
        Set<String> scopesForResourceIds = null;

        if (resourceIds != null && !resourceIds.isEmpty()) {
            scopesForResourceIds = new HashSet<>();
            for (final String resource : resourceIds) {
                scopesForResourceIds.addAll(resourceIdIdentifier_vs_OAuthScopes_map.get(resource));
            }
        }

        return scopesForResourceIds;
    }
}
