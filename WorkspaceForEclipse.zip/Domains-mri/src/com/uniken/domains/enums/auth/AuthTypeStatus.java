package com.uniken.domains.enums.auth;

public enum AuthTypeStatus {
    CREATED("CREATED"),
    REGISTERED("REGISTERED"),
    BLOCKED("BLOCKED"),
    DELETED("DELETED"),
    PENDING("PENDING"),
    DISABLED("DISABLED");

    private String name;

    AuthTypeStatus(final String name) {
        this.name = name;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
}
