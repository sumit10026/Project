package com.uniken.domains.enums.auth;

import java.util.HashMap;
import java.util.Map;

public enum IDVMethod {

    ACCESS_CODE("access-code"),
    RELID_VERIFY("relid-verify"),
    SECURITY_QA("security-qa"),
    SERVER_SIDE_BIOMETRIC("server-side-biometric"),
    WEB_IDV_KYC("web-idv-kyc"),
    FIDO("fido");

    private static final Map<String, IDVMethod> values = new HashMap<>();
    private String name;

    static {
        for (final IDVMethod idvMethod : values()) {
            values.put(idvMethod.getName(), idvMethod);
        }
    }

    IDVMethod(final String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public static boolean isValidElement(final String idvMethod) {
        return values.containsKey(idvMethod);
    }

    public static IDVMethod getAuthTypeByName(final String idvMethod) {
        return values.get(idvMethod);
    }

}
