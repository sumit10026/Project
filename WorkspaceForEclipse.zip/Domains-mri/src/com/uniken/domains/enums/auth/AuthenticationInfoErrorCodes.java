package com.uniken.domains.enums.auth;

import com.uniken.domains.enums.ResponseCode;

public interface AuthenticationInfoErrorCodes {

    enum RESPONSE_CODE implements ResponseCode {
        SUCCESS((short) 100, "Success"),
        AUTHENTICATION_INFO_REQUEST_INVALID((short) 3800, "Invalid Authentication Info Request"),
        AUTHENTICATION_INFO_REQUEST_NULL_OR_EMPTY((short) 3801, "Authentication Info Request null or empty"),
        GET_AUTHENTICATION_INFO_REPLY_KEY_NULL((short) 3802,
                "Get Authentication Info Reply routing key is null or empty"),
        INTERNAL_ERROR((short) 3899, "Internal Server error");

        private final short code;
        private final String message;

        RESPONSE_CODE(final short code, final String message) {
            this.code = code;
            this.message = message;
        }

        @Override
        public short getCode() {
            return this.code;
        }

        @Override
        public String getMessage() {
            return this.message;
        }

    };

}
