package com.uniken.domains.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Uniken Inc.
 */
public enum AuthenticatedWith {
    USER_PSWD("USER_PSWD"), DEVICE_LDA("DEVICE_LDA");

    private String name;

    private AuthenticatedWith(final String name) {
        this.name = name;
    }

    private static final Map<String, AuthenticatedWith> authenticatedWithMap = new HashMap<String, AuthenticatedWith>();

    static {

        for (final AuthenticatedWith type : values()) {
            authenticatedWithMap.put(type.getName(), type);
        }
    }

    public static AuthenticatedWith getAuthenticatedWithFromMap(final String authenticatedName) {
        return authenticatedWithMap.get(authenticatedName);
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

}
