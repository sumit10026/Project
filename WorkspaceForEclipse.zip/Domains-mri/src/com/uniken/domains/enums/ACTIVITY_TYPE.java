package com.uniken.domains.enums;

import java.util.HashMap;
import java.util.Map;

public enum ACTIVITY_TYPE {

    REGISTER("Register",
            "Registering user with username " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1, role "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2 and status "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "3"),
    PROFILE_UPDATE("Profile Update",
            "Updating user profile with username " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1, role "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),
    RESET_PASSWORD("Reset Password",
            "Resetting password for user with username " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER
                    + "1 and status is " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),
    UPDATE_STATUS("Update status",
            "Updating status for user with username " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER
                    + "1 and status is " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),
    ADD_GM_USER("Add GM User",
            "Adding a GM user with username " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 and role "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),
    UPDATE_GM_USER("Update GM User",
            "Updating user details for username " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 and role "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),
    LOGIN_ATTEMPT_FAILURE("Login attempt failure count",
            "Login attempt failed for user " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER
                    + "1 and attempt count is " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),
    RESET_FAILURE_ATTEMPT("Reset failure attempt count", "Resetting failure attempt count to 0"),
    LOGIN_ATTEMPT_SUCCESS("Login attempt successful",
            "Login attempt successful for user " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),
    FORGOT_PASSWORD_FAILURE_COUNT("Reset password failure count",
            "Forgot password attempt failed for user " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER
                    + "1 and attempt count is " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),
    ADD_APP_AGENT("Add App agent",
            "Adding app agent with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),
    UPDATE_APP_AGENT("Update App agent",
            "Updating app agent with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),
    ADD_DEFAULT_SYSTEM_POLICY("Add default system policy",
            "Adding default system policy with level identifier " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER
                    + "1"),
    UPDATE_POLICY("Update policy",
            "Updating policy with level identifier " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),
    DELETE_POLICY("Delete policy",
            "Deleting policy with level identifier " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),
    UPDATE_SETTINGS("Update Settings", "Updating settings for " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),
    ADD_CLUSTER("Add Cluster",
            "Adding cluster with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 and type "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),
    UPDATE_CLUSTER("Update Cluster",
            "Updating cluster with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 and type "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),
    DELETE_CLUSTER("Delete Cluster",
            "Deleting Cluster with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),
    ADD_BUTTON("Add Button", "Adding button with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 "),
    UPDATE_BUTTON("Update Button",
            "Updating button with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 "),
    DELETE_BUTTON("Delete Button", "Deleting Button with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    DELETE_APP_AGENT("Delete App Agent",
            "Deleting App Agent with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    ADD_ALERT("Add Alert",
            "Adding alert with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 and type "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),

    UPDATE_ALERT("Update Alert",
            "Updating alert with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 and type "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),

    DELETE_ALERT("Delete Alert", "Deleting Alert with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),
    LOG_OUT("Log out user",
            "User with username " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 has logged out"),

    UPDATE_INITAL_CREDS_GM_USER("Update Inital Creds GM User",
            "Updating Inital Creds details for username " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    ADD_GROUP("Add Group", "Adding group with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    UPDATE_GROUP("Update Group", "Updating group with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    DELETE_GROUP("Delete Group", "Deleting group with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    DELETE_TUNNEL("Delete Tunnel", "Deleting Tunnel with UUID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    DELETE_NON_TUNNEL("Delete Non Tunnel",
            "Deleting Non Tunnel with UUID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    ADD_USER("Add User", "Adding user with user ID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    BULK_ADD_USER("Bulk Add User",
            "Adding user by bulk file upload with user ID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    UPDATE_USER("Update User", "Updating user ID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    UPDATE_USER_STATUS("Update User",
            "Updating user ID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 with status as "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),

    UPDATE_USER_GROUP("Update User",
            "Updating user ID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 with group as "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),

    UPDATE_USER_PRIMARY_GROUP("Update User Primary Group",
            "Updating user ID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 with New Primary Group Value as "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2 and Old Primary Group Value was "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "3"),

    UPDATE_USER_SECONDARY_GROUPS("Update User Secondary Group",
            "Updating user ID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER
                    + "1 with New Secondary Group Value as " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER
                    + "2 and Old Secondary Group Value was " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "3"),

    UPDATE_USER_DETAILS("Update User Details",
            "Updating user details for user ID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    RESET_USER("Reset User", "Reseting user with user ID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    BLOCK_ALL_DEVICE_BINDINGS("Block All Device Bindings",
            "Block all device bindings for user ID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    BLOCK_DEVICE_BINDING("Block Device Binding",
            "Block device binding for user ID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    UNBLOCK_DEVICE_BINDING("Unblock Device Binding",
            "Unblock device binding for user ID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    USER_CREATED("User Created", "User Created " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    BLOCK_USER("Block User", "Block User " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    UNBLOCK_USER("Unblock User", "Unblock User " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    ENROLL_USER_DEVICE("Enroll User Device",
            "Enrolling device for user ID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    MAP_DEPARTMENT_TO_GROUP("Mapping AD Department to GM Group",
            "Mapping AD Department '" + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1' to GM group '"
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2'"),

    DELETE_DEPARTMENT_TO_GROUP_MAPPING("Deleting AD Department to GM Group mapping",
            "Deleting AD Department to Group Mapping for Department '" + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER
                    + "1'"),

    ADD_CREDENTIAL_STORE_INFO("Add Credential Store Info",
            "Adding Credential Store with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    UPDATE_CREDENTIAL_STORE_INFO("Update Credential Store Info",
            "Updating Credential Store Info with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    ADD_ENTERPRISE("Add Enterprise",
            "Adding Enterprise with Enterprise Id " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    UPDATE_ENTERPRISE("Update Enterprise",
            "Updating Enterprise with Enterprise Id " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    ADD_ROLE("Add Role", "Adding role with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    UPDATE_STATE_CHALLENGE_MAPPING("Update State Challenge Mapping",
            "Updating State Challenge Mapping for state " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    ADD_CHALLENGE("Add Challenge",
            "Adding Challenge with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    UPDATE_CHALLENGE("Update Challenge",
            "Updating Challenge with name " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    SECONDARY_CHANNEL_INITIATION_REQUEST("SecondaryChannelInitiationRequest",
            "Secondary channel initiation requested for user"),

    LOGIN_REQUEST_FROM_ACTIVATED_DEVICE("LoginRequestFromActivatedDevice",
            "Login request initiated from activated device of user"),

    SECONDARY_DEVICE_ACTIVATION_REQUEST("SecondaryDeviceActivationRequest",
            "Secondary device activation requested for user"),

    FIRST_TIME_ACTIVATION_REQUEST("FirstTimeActivationRequest", "First time activation request initiated"),

    SET_CREDENTIALS_REQUEST("SetCredentialsRequest", "Set credentials requested for user"),

    UPDATE_CREDENTIALS_REQUEST("UpdateCredentialsRequest", "Update credentials requested for user"),

    UPDATE_CRED_RESPONSE_SUCCESS("UpdateCredSuccessResponse", "Credentials updated successfully for user"),

    UPDATE_CRED_RESPONSE_FAILURE("UpdateCredFailureResponse", "Failure in updating credentials for user "),

    NON_ACTIVE_USER_REQUEST_FAILURE("NonActiveUserRequestFailure",
            "Request failed as the user status is either blocked, unenrolled or reset for user"),

    GET_CRED_REQUEST("GetCredRequest", "Fetching credentials for user"),

    REQUEST_FROM_BOUND_DEVCIE("RequestFromBoundDevice", "Request is from bound device for user"),

    REQUEST_FROM_UNBOUND_DEVCIE("RequestFromUnboundDevice", "Request is from unbound device for user"),

    CHECK_CRED_REQUEST("CheckCredRequest", "Checking credentials for user"),

    DEV_BIND_REQUEST("DevBindRequest", "Device bindind request received for user"),

    DEV_NAME_REQUEST("DevNameRequest", "Change Device Name request received for user "),

    DEV_BIND_PERMANANT("DeviceBindingPermanant", "Permanent device binded for user"),

    DEV_BIND_TEMPORARY("DeviceBindingTemporary", "Temporary device bind for the user"),

    CHECK_CRED_RESPONSE_FAILURE("CheckCredFailureResponse", "Failed to validate user credentials"),

    CHECK_CRED_RESPONSE_ERROR("CheckCredErrorResponse",
            "Suspending User due to number of attempts are exhausted of user"),

    BLOCK_USER_DUE_TO_RESPONSE_ERROR("BlockUserDueToCheckCredsErrorResponse",
            "Blocking User due to error in checking credentials and number of attempts exhausted for user."),

    CHECK_CRED_RESPONSE_SUCCESS("CheckCredSuccessResponse", "Credentials validated successfully"),

    CREATED_USER_RESPONSE_SUCCESS("CreatedUserResponseSuccess", "Sending response for user"),

    ACTIVE_USER_RESPONSE_SUCCESS("ActiveUserResponseSuccess", "Sending response for user "),

    CREATED_APP_SESSION_SUCCESS("CreatedAppSessionSuccess", "Creating app session for user"),

    AUTO_RESET_USER_SUCCESS("CreatedAppSessionSuccess", "Resetting user credentials"),

    NO_USER_ENROLLMENT("NoUserEnrollment", "No such user present"),

    /***********************
     * Below activity types are not in use now......may be removed later;
     ************************/

    WHITELISTING_REQUEST("WhitelistRequest", "Checking device whitelisting for user"),

    WHITELISTING_RESPONSE_SUCCESS("WhitelistSuccessResponse", "Successful device whitelisting for user"),

    WHITELISTING_RESPONSE_FAILURE("WhitelistFailureResponse", "Device whitelisting failed for user"),

    WHITELISTING_RESPONSE_ERROR("WhitelistErrorResponse", "Error in Device whitelisting for user "),

    REMOVE_PERMANANT_DEV_BIND("RemovePermanantDeviceBinding", "Remove permanant device binding for the device."),

    UPDATE_CRED_RESPONSE_ERROR("UpdateCredErrorResponse", "Error in updating credentials for user "),

    GET_CRED_RESPONSE_SUCCESS("GetCredSuccessResponse", "Credentials fetched by user "),

    GET_CRED_RESPONSE_FAILURE("GetCredFailureResponse", "Failure in fetching credentials for user "),

    GET_CRED_RESPONSE_ERROR("GetCredErrorResponse", "Error in fetching credentials for user "),

    RELID_LICENSE_REQUEST_SUCCESSFUL("RelidLicenseRequestSuccessful",
            "License request generation successfully. SERVER-ID: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER
                    + "1"),

    RELID_LICENSE_REQUEST_FAILURE("RelidLicenseRequestFailure",
            "License request generation failure. SERVER-ID: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER
                    + "1 Exception: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),

    RELID_LICENSE_UPLOAD_SUCCESSFUL("RelidLicenseUploadSuccessful",
            "License Uploaded successfully. SERVER-ID: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    RELID_LICENSE_UPLOAD_FAILURE("RelidLicenseUploadFailure",
            "Failure occurred while uploading the license. SERVER-ID: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER
                    + "1 Exception: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),

    RELID_LICENSE_ACTIVATE_SUCCESSFUL("RelidLicenseActivateSuccessful",
            "License Activated successfully. SERVER-ID: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    RELID_LICENSE_ACTIVATE_FAILURE("RelidLicenseActivateFailure",
            "Failure occurred while activating the license. SERVER-ID: "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 Exception: "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),

    RELID_LICENSE_DEACTIVATE_SUCCESSFUL("RelidLicenseDeactivateSuccessful",
            "License Deactivated successfully. SERVER-ID: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    RELID_LICENSE_DEACTIVATE_FAILURE("RelidLicenseDeactivateFailure",
            "Failure occurred while deactivating the license. SERVER-ID: "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 Exception: "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),

    RELID_LICENSE_SERVERID_UPDATE_SUCCESSFUL("RelidLicenseServerIdUpdateSuccessful",
            "License Server-Id Updated successfully. SERVER-ID: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER
                    + "1 OLD-SERVER-ID: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),

    RELID_LICENSE_SERVERID_UPDATE_FAILURE("RelidLicenseServerIdUpdateFailure",
            "Failure occurred while updating Server-Id. SERVER-ID: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER
                    + "1 Exception: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),

    RELID_GEN_EXCEPTION("RelidGenException",
            "An exception generated by REL-ID Gen Utility: SERVER-ID: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER
                    + "1 Exception: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2"),

    RELID_DEVICE_BLOCKED("RelidDeviceBlocked",
            "Device blocked. Device Uuid: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    RELID_DEVICE_UNBLOCKED("RelidDeviceUnblocked",
            "Device unblocked. Device Uuid: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1"),

    RELID_USER_UNENROLLED("RelidUserUnenrolled",
            "RelId User " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 unenrolled"),

    RELID_USER_PAUSED("RelidUserPaused", "RelId User " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 paused"),

    RELID_USER_UNPAUSED("RelidUserUnpaused",
            "RelId User " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 unpaused"),

    DELETE_DEVICE_BINDING("DeleteDeviceBinding", "Delete device binding"),

    RELID_USER_DELETED("RelidUserDeleted",
            "RelId User " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 deleted"),

    MODULE_CONFIGS_BACKUP_STARTED("ModuleConfigsBackupStarted", "Module Configs backup started"),
    MODULE_CONFIGS_BACKUP_SUCCESS("ModuleConfigsBackupSuccess", "Module Configs backup completed succesfully"),
    MODULE_CONFIGS_BACKUP_FAILURE("ModuleConfigsBackupFailure", "Module Configs backup failed"),
    MODULE_CONFIGS_RESTORE_STARTED("ModuleConfigsBackupStarted", "Module Configs backup started"),
    MODULE_CONFIGS_RESTORE_SUCCESS("ModuleConfigsBackupSuccess", "Module Configs backup completed succesfully"),
    MODULE_CONFIGS_RESTORE_FAILURE("ModuleConfigsBackupFailure", "Module Configs backup failed"),

    CHALLENGE_CONFIGS_BACKUP_STARTED("ChallengeConfigsBackupStarted", "Challenge Configs backup started"),
    CHALLENGE_CONFIGS_BACKUP_SUCCESS("ChallengeConfigsBackupSuccess", "Challenge Configs backup completed succesfully"),
    CHALLENGE_CONFIGS_BACKUP_FAILURE("ChallengeConfigsBackupFailure", "Challenge Configs backup failed"),
    CHALLENGE_CONFIGS_RESTORE_STARTED("ChallengeConfigsBackupStarted", "Challenge Configs backup started"),
    CHALLENGE_CONFIGS_RESTORE_SUCCESS("ChallengeConfigsBackupSuccess",
            "Challenge Configs backup completed succesfully"),
    CHALLENGE_CONFIGS_RESTORE_FAILURE("ChallengeConfigsBackupFailure", "Challenge Configs backup failed"),

    NOTIFICATION_CONFIGS_BACKUP_STARTED("NotificationConfigsBackupStarted", "Notification Configs backup started"),
    NOTIFICATION_CONFIGS_BACKUP_SUCCESS("NotificationConfigsBackupSuccess",
            "Notification Configs backup completed succesfully"),
    NOTIFICATION_CONFIGS_BACKUP_FAILURE("NotificationConfigsBackupFailure", "Notification Configs backup failed"),
    NOTIFICATION_CONFIGS_RESTORE_STARTED("NotificationConfigsBackupStarted", "Notification Configs backup started"),
    NOTIFICATION_CONFIGS_RESTORE_SUCCESS("NotificationConfigsBackupSuccess",
            "Notification Configs backup completed succesfully"),
    NOTIFICATION_CONFIGS_RESTORE_FAILURE("NotificationConfigsBackupFailure", "Notification Configs backup failed"),

    CRED_STORE_BACKUP_STARTED("CredStoreBackupStarted", "Credential Store backup started"),
    CRED_STORE_BACKUP_SUCCESS("CredStoreBackupSuccess", "Credential Store backup completed succesfully"),
    CRED_STORE_BACKUP_FAILURE("CredStoreBackupFailure", "Credential Store backup failed"),
    CRED_STORE_RESTORE_STARTED("CredStoreBackupStarted", "Credential Store backup started"),
    CRED_STORE_RESTORE_SUCCESS("CredStoreBackupSuccess", "Credential Store backup completed succesfully"),
    CRED_STORE_RESTORE_FAILURE("CredStoreBackupFailure", "Credential Store backup failed"),

    RESTART_MODULE_INITIATED("RestartModuleRequestInitiated",
            "InitiatedBy: " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1 NodeHNIP: "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "2 ModuleName: "
                    + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "3"),

    SET_PREDEFINED_CODE("SetPredefinedCode",
            "SetPredefinedCode for user ID " + ACTIVITY_TYPE.ACTIVITY_DESCRIPTION_PLACEHOLDER + "1");

    public static final String ACTIVITY_DESCRIPTION_PLACEHOLDER = "%l";

    private String activityName;
    private String description;

    private static final Map<ACTIVITY_TYPE, String> mapOfActivityTypeVsDescription = new HashMap<ACTIVITY_TYPE, String>();

    static {
        for (final ACTIVITY_TYPE type : values()) {
            mapOfActivityTypeVsDescription.put(type, type.getDescription());
        }
    }

    private ACTIVITY_TYPE(final String activityName, final String description) {
        this.activityName = activityName;
        this.description = description;
    }

    /**
     * @return the description
     */
    public String getDescription() {
        return description;
    }

    /**
     * @return the activityName
     */
    public String getActivityName() {
        return activityName;
    }

}
