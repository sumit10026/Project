/**
 * 
 */
package com.uniken.domains.enums.codecs;

import org.bson.BsonReader;
import org.bson.BsonWriter;
import org.bson.codecs.Codec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.codecs.configuration.CodecRegistry;

import com.uniken.domains.enums.RelIdUserStatus;

/**
 * @author Uniken Inc.
 */
public class RelIdStatusCodec
        implements Codec<RelIdUserStatus> {

    private final CodecRegistry codecRegistry;

    /**
     * @param codecRegistry
     */
    public RelIdStatusCodec(final CodecRegistry codecRegistry) {
        System.out
                .println("****************************************************** Kushal Codec **********************");
        this.codecRegistry = codecRegistry;
    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Encoder#encode(org.bson.BsonWriter,
     * java.lang.Object, org.bson.codecs.EncoderContext)
     */
    @Override
    public void encode(final BsonWriter bsonWriter, final RelIdUserStatus relIdStatus,
            final EncoderContext encoderContext) {

        bsonWriter.writeStartDocument();

        System.out.println("****************************************************** Kushal Codec **********************"
                + relIdStatus);
    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Encoder#getEncoderClass()
     */
    @Override
    public Class<RelIdUserStatus> getEncoderClass() {
        return RelIdUserStatus.class;
    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Decoder#decode(org.bson.BsonReader,
     * org.bson.codecs.DecoderContext)
     */
    @Override
    public RelIdUserStatus decode(final BsonReader arg0, final DecoderContext arg1) {
        // TODO Auto-generated method stub
        return null;
    }

}
