package com.uniken.domains.enums;

/**
 * <H4>DfpPolicyStatus</h4> : This ENUM is having device finger printing status
 * </br>
 * <i> ACTIVE, INACTIVE </i>
 * 
 * @author Akash
 */
public enum DfpPolicyStatus {
    ACTIVE("ACTIVE"), INACTIVE("INACTIVE");

    private String status;

    DfpPolicyStatus(final String status) {
        this.status = status;
    }

    public String getStatus() {
        return this.status;
    }

}
