package com.uniken.domains.enums;

public enum MESSAGE_COLLECTION {

    MESSAGE_TYPE("messageType"),
    MOBILE("mobileNumber"),
    EMAIL("emailId"),
    CREATED_TS("createdTS"),
    IS_MESSAGE_ENCRYPTED("isMessageEncrpyted"),
    IS_MESSAGE_PROCESSED("isMessageProcessed"),
    USER_ID("userId"),
    STATUS("status"),
    IS_EMAIL_SENT("isEmailSent"),
    IS_SMS_SENT("isSmsSent"),
    VERIFICATION_KEY("verificationKey"),
    PRIMARY_GROUP_NAME("primaryGroupName"),
    ACTIVATION_CODE("activationCode");

    private String key;

    private MESSAGE_COLLECTION(final String key) {
        this.key = key;
    }

    /**
     * @return
     */
    public String getKey() {
        return key;
    }

}
