/**
 * 
 */
package com.uniken.domains.enums;

/**
 * @author Uniken Inc.
 */
public enum SessionType {
    USER_SESSION, APP_SESSION;
}
