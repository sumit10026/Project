package com.uniken.domains.enums;

public enum BiometricTemplateSource {

    RDNA, WEB

}
