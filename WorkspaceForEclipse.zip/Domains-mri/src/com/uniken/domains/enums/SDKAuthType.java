package com.uniken.domains.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * SDK Auth types
 * 
 * @author Uniken Inc.
 */
public enum SDKAuthType {
    REL_ID_PASSWORDLESS("REL_ID_PASSWORDLESS"),
    REL_ID_MANUAL_ONLY("REL_ID_MANUAL_ONLY"),
    REL_ID_MANUAL_LDA("REL_ID_MANUAL_LDA");

    private String name;

    private SDKAuthType(final String name) {
        this.name = name;
    }

    private static final Map<String, SDKAuthType> sdkAuthTypeWithMap = new HashMap<String, SDKAuthType>();

    static {

        for (final SDKAuthType type : values()) {
            sdkAuthTypeWithMap.put(type.getName(), type);
        }
    }

    public static SDKAuthType getAuthenticatedWithFromMap(final String authTypeNameStr) {
        return sdkAuthTypeWithMap.get(authTypeNameStr);
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
}
