package com.uniken.domains.enums;

public interface GenericErrorCodes {

    enum RESPONSE_CODE implements ResponseCode {

        SUCCESS((short) 00, "Success"), ERROR((short) 01, "Error");

        private final short code;
        private final String message;

        RESPONSE_CODE(final short code, final String message) {
            this.code = code;
            this.message = message;
        }

        @Override
        public short getCode() {
            return this.code;
        }

        @Override
        public String getMessage() {
            return this.message;
        }

    };

}
