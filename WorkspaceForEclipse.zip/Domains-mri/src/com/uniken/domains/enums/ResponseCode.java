package com.uniken.domains.enums;

public interface ResponseCode {

    short getCode();

    String getMessage();
}
