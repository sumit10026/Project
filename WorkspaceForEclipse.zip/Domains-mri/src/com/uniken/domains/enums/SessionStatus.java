/**
 * 
 */
package com.uniken.domains.enums;

/**
 * @author Uniken Inc.
 */
public enum SessionStatus {
    CREATED, TERMINATED;
}
