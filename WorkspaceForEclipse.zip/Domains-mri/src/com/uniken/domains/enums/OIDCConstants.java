package com.uniken.domains.enums;

public enum OIDCConstants {

    // Headers
    JWT_HEADER_KID("kid"),
    JWT_HEADER_TYP("typ"),

    // Header values
    JWT_HEADER_TYP_VALUE("JWT"),

    // JWT claims
    JWT_CLAIM_JTI("jti");

    private String value;

    OIDCConstants(final String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
