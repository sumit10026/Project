package com.uniken.domains.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * Enum for User Browser Status
 */
public enum UserBrowserStatus {

    CREATED("CREATED"),
    ACTIVE("ACTIVE"),
    BLOCKED("BLOCKED"),
    UNENROLLED("UNENROLLED"),
    DISABLE("DISABLE"),
    RESET("RESET"),
    PAUSED("PAUSED"),
    DELETED("DELETED"),
    INACTIVE("INACTIVE"),
    MIGRATED("MIGRATED");

    private static final Map<String, UserBrowserStatus> userStatusMap = new HashMap<String, UserBrowserStatus>();

    static {

        for (final UserBrowserStatus status : values()) {
            userStatusMap.put(status.getValue(), status);
        }

    }

    private String value;

    /**
     * @param value
     */
    private UserBrowserStatus(final String value) {
        this.value = value;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @return
     */
    public static Map<String, UserBrowserStatus> getUserStatusMap() {
        return userStatusMap;
    }

    /**
     * @param status
     * @return
     */
    public static UserBrowserStatus getStatus(final String status) {

        return userStatusMap.get(status);
    }
}
