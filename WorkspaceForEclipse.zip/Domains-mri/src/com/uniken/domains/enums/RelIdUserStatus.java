package com.uniken.domains.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * Enum for REL-ID user status
 */
public enum RelIdUserStatus {

    CREATED("CREATED"),
    ACTIVE("ACTIVE"),
    BLOCKED("BLOCKED"),
    UNENROLLED("UNENROLLED"),
    DISABLE("DISABLE"),
    RESET("RESET"),
    PAUSED("PAUSED"),
    DELETED("DELETED"),
    INACTIVE("INACTIVE"),
    MIGRATED("MIGRATED"),
    ONBOARDING("ONBOARDING");

    private static final Map<String, RelIdUserStatus> userStatusMap = new HashMap<String, RelIdUserStatus>();

    static {

        for (final RelIdUserStatus status : values()) {
            userStatusMap.put(status.getValue(), status);
        }

    }

    private String value;

    /**
     * @param value
     */
    private RelIdUserStatus(final String value) {
        this.value = value;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @return
     */
    public static Map<String, RelIdUserStatus> getUserStatusMap() {
        return userStatusMap;
    }

    /**
     * @param status
     * @return
     */
    public static RelIdUserStatus getStatus(final String status) {

        return userStatusMap.get(status);
    }
}
