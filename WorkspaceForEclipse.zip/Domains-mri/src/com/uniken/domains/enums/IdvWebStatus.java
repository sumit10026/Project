/**
 * 
 */
package com.uniken.domains.enums;

/**
 * @author Uniken Inc.
 */
public enum IdvWebStatus {
    PENDING, INPROGRESS, COMPLETE, EXPIRED, SUCCESS, FAILED;
}
