/**
 * 
 */
package com.uniken.domains.enums.appconfig;

/**
 * @author Kushal Jaiswal
 */
public enum AdapterConfigKeys {

    AUTH_SERVER_URL("auth.server.url"), IDV_MQ_PRODUCER_COUNT("idvmq.producer.count");

    private String name;

    private AdapterConfigKeys(final String name) {
        this.name = name;
    }

    /**
     * @return the name of the enum
     */
    public String getName() {
        return name;
    }
}
