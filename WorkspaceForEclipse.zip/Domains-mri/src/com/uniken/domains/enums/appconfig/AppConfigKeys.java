/**
 * 
 */
package com.uniken.domains.enums.appconfig;

/**
 * @author Kushal Jaiswal
 */
public interface AppConfigKeys {

}
