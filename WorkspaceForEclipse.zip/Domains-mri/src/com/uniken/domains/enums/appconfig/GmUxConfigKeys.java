package com.uniken.domains.enums.appconfig;

public enum GmUxConfigKeys {

    SERVER_PORT("gm.ux.server.port"),
    SERVER_SSL_ENABLED("gm.ux.server.ssl.enabled"),
    SERVER_SSL_KEYSTORE_TYPE("gm.ux.server.ssl.keystore.type"),
    SERVER_SSL_KEY_ALIAS("gm.ux.server.ssl.key.alias"),
    SERVER_SSL_KEYSTORE_PASSWORD("gm.ux.server.ssl.keystore.password"),
    SERVER_SSL_KEYSTORE("gm.ux.server.ssl.keystore"),
    SERVER_SSL_KEYSTORE_PROVIDER("gm.ux.server.ssl.keystore.provider"),
    SERVER_IP("gm.ux.server.ip"),

    GM_API_SERVER_BASE_URL("gm.api.server.base.url"),
    ENTERPRISE_ID("enterprise.id"),
    CLIENT_ID("client.id"),
    CLIENT_SECRET("client.secret"),
    ACCESS_TOKE_URI("auth.server.access.toke.uri"),
    USER_AUTHORIZATION_URI("auth.server.user.authorization.uri"),
    JWK_URI("auth.server.jwk.uri");

    private String name;

    private GmUxConfigKeys(final String name) {
        this.name = name;
    }

    /**
     * @return the name of the enum
     */
    public String getName() {
        return name;
    }

}
