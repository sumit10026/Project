package com.uniken.domains.enums.appconfig;

public enum RelidAuthServer implements AppConfigKeys {

    AUTH_SERVER_PORT("auth.server.port"),
    GENERIC_VERIFY_MESSAGE("generic.verify.message"),
    GENERIC_VERIFY_MESSAGE_WITH_REMEMBER_ME("generic.verify.message.remember.me"),
    AUTH_SERVER_REQUESTOR_IP("auth.server.ip"),
    AUTH_SERVER_SSL_ENABLED("auth.server.ssl.enabled"),
    AUTH_SERVER_SSL_KEYSTORE_TYPE("auth.server.ssl.keystore.type"),
    AUTH_SERVER_SSL_KEY_ALIAS("auth.server.ssl.key.alias"),
    AUTH_SERVER_SSL_KEY_PASSWORD("auth.server.ssl.key.password"),
    AUTH_SERVER_SSL_KEYSTORE_PASSWORD("auth.server.ssl.keystore.password"),
    AUTH_SERVER_SSL_KEYSTORE("auth.server.ssl.keystore"),
    AUTH_SERVER_SSL_KEYSTORE_PROVIDER("auth.server.ssl.keystore.provider"),
    AUTH_SERVER_FIDO2_ANDROID_SAFETY_NET_API_KEY("auth.server.fido2.android.safety.net.api.key"),
    AUTH_SERVER_FIDO2_ANDROID_SAFETY_NET_API_URL("auth.server.fido2.android.safety.net.api.url"),
    AUTH_SERVER_FIDO2_ANDROID_SAFETY_NET_API_ONLINE_BY_DEFAULT(
            "auth.server.fido2.android.safety.net.api.online.by.default"),
    AUTH_SERVER_FIDO2_APPLE_WEBAUTHN_ROOT_CA_CERT_URL("auth.server.fido2.apple.webauthn.root.ca.cert.url"),
    AUTH_SERVER_FIDO2_MDS3_TOC_FILE_LOCATION("auth.server.fido2.mds3.toc.file.location"),
    AUTH_SERVER_FIDO2_MDS3_TOC_ROOT_FILE("auth.server.fido2.mds3.toc.root.file"),
    AUTH_SERVER_FIDO2_AUTHENTICATOR_CERT_LOCATION("auth.server.fido2.authenticator.certs.location"),
    AUTH_SERVER_FIDO2_RELYING_PARTY_DOMAIN("auth.server.fido2.rp.domain"),
    AUTH_SERVER_TOMCAT_ACCESSLOG_ENABLED("auth.server.tomcat.accesslog.enabled"),
    AUTH_SERVER_TOMCAT_ACCESSLOG_REQUES_ATTRIBUTES("auth.server.tomcat.accesslog.request-attributes-enabled"),
    AUTH_SERVER_SPRING_LOG_LEVEL_CONFIG("auth.server.logging.level.org.springframework"),
    AUTH_SERVER_UNIKEN_LOG_LEVEL_CONFIG("auth.server.logging.level.com.uniken"),
    AUTH_SERVER_LOGFILE_NAME("auth.server.logging.file"),
    AUTH_SERVER_SECURITY_BASIC_ENABLED("auth.server.security.basic.enabled"),
    AUTH_SERVER_ENDPOINTS_TRACE_SENSITIVE("auth.server.endpoints.trace.sensitive"),
    AUTH_SERVER_ENDPOINTS_TRACE_ENABLED("auth.server.endpoints.trace.enabled"),
    AUTH_SERVER_MANAGEMENT_ENDPOINTS_WEB_EXPOSURE_INCLUDE("auth.server.management.endpoints.web.exposure.include"),
    AUTH_SERVER_WEB_SESSION_VALIDITY("auth.server.web.session.timeout"),
    AUTH_SERVER_WHITELISTED_PUBLIC_URIS("auth.server.whitelisted.public.uris"),
    WHITELISTED_RP_SERVER_IPS("whitelisted.rp.server.ips"),
    NOTIFICATION_MSG_ACCEPT_LABEL("notification.msg.accept.label"),
    NOTIFICATION_MSG_REJECT_LABEL("notification.msg.reject.label"),
    NOTIFICATION_MSG_FRAUD_LABEL("notification.msg.fraud.label"),
    AUTH_SERVER_ALLOWED_AUTH_FACTORS("allowed.auth.factors"),
    PROPERTY_AUTH_LEVEL_DEFAULT_ATTEMPT_COUNTER("auth.level.default.attempt.counter"),
    PROPERTY_DEFAULT_COOLING_PERIOD_LIST("default.cooling.period.list"),
    PROPERTY_DEFAULT_COOKIE_EXPIRY_TIME_IN_SECONDS("default.cookie.expiry.time.in.seconds"),
    PROPERTY_MFA_DISPLAY_MESSAGES("mfa.user.display.messages"),
    PROPERTY_DEFAULT_COOKIE_PATH("default.cookie.path"),
    PROPERTY_DEFAULT_AUTH_GENERATION_ATTEMPT_COUNTER("default.auth.generation.attempt.counter"),
    PROPERTY_DEFAULT_GLOBAL_ERROR_PAGE_MSG("default.global.error.page.msg"),
    PROPERTY_MANAGE_SECURITY_PREF_ENABLED("manage.security.pref.enabled"),
    PROPERTY_UI_MESSAGES_PAGE_LOGIN("ui.messages.page.login"),
    PROPERTY_UI_MESSAGES_PAGE_LOGIN_USERNAME_START_WITH_FIRSTNAME(
            "ui.messages.page.login.username.start.with.firstname"),
    PROPERTY_UI_MESSAGES_PAGE_REGISTER("ui.messages.page.register"),
    PROPERTY_AUTOMATIC_FIDO_REGISTRATION_ENABLED("automatic.fido.registration.enabled"),
    AUTH_SERVER_ALLOWED_REG_FACTORS("allowed.reg.factors"),
    PROPERTY_UI_MESSAGES_PAGE_REGISTER_USER("ui.messages.page.register.user"),
    SHOW_PASS_STRENGTH("show.password.strength"),
    ACTIVATION_DELAY_BEFORE_REDIRECT("activation.delay.before.redirect"),
    HTTP_SESSION_MAX_INACTIVE_INTERVAL_IN_SECONDS("http.session.max.inactive.interval"),
    PROPERTY_UI_MESSAGES_PAGE_REGISTER_FIDO_CONSENT("ui.messages.page.register.fido.consent"),
    PROPERTY_DEFAULT_ACTIVATION_GENERATION_ATTEMPT_COUNTER("default.activation.generation.attempt.counter"),
    PROPERTY_DEFAULT_USER_RECOGNIZED_AUTHTYPE_NAME("default.user.recognized.authtype.name"),
    PROPERTY_UI_MESSAGES_PAGE_ACCOUNT_RECOVERY_CREDENTIAL("ui.messages.page.account.recovery.credential");

    private String name;

    private RelidAuthServer(final String name) {
        this.name = name;
    }

    /**
     * @return the name of the enum
     */
    public String getName() {
        return name;
    }

}
