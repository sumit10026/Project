package com.uniken.domains.enums.appconfig;

public enum IdvWebConfigKeys {

    SERVER_PORT("idv.web.server.port"),
    SERVER_SSL_ENABLED("idv.web.server.ssl.enabled"),
    SERVER_SSL_KEYSTORE_TYPE("idv.web.server.ssl.keystore.type"),
    SERVER_SSL_KEY_ALIAS("idv.web.server.ssl.key.alias"),
    SERVER_SSL_KEY_PASSWORD("idv.web.server.ssl.key.password"),
    SERVER_SSL_KEYSTORE_PASSWORD("idv.web.server.ssl.keystore.password"),
    SERVER_SSL_KEYSTORE("idv.web.server.ssl.keystore"),
    SERVER_SSL_KEYSTORE_PROVIDER("idv.web.server.ssl.keystore.provider"),
    MQ_REPLY_TIMEOUT_SECONDS("mq.reply.timeout.seconds"),
    OPT_IN_ENABLE("opt.in.enable"),
    KYC_ENABLE("kyc.enable"),
    AWARE_PREFACE_API("aware.preface.api"),
    IDV_WEB_INFORMATION("idv.web.information"),
    DOC_UPLOAD_VIA_BROWSE("doc.upload.via.browse"),
    IDV_WEB_OPT_IN_INFORMATION("idv.web.opt.in.information"),
    IDV_WEB_ENABLE_RESCAN_DOC("idv.web.enable.rescan.doc"),
    IDV_WEB_ENABLE_RECAPTURE_SELFIE("idv.web.enable.recapture.selfie"),
    IDV_WEB_BTN_NAME_CONTINUE_FLOW("idv.web.btn.name.continue.flow"),
    IDV_WEB_BTN_NAME_CONTINUE_ANYWAY_FLOW("idv.web.btn.name.continue.anyway.flow"),
    IDV_WEB_BTN_NAME_RESCAN_DOCUMENT("idv.web.btn.name.rescan.document"),
    IDV_WEB_BTN_NAME_RECAPTURE_SELFIE("idv.web.btn.name.recapture.selfie"),
    ARCHIVE_IDV_WEB_SESSIONS_POLLING_TIME_INTERVAL("archive.idv.web.sessions.polling.time.interval"),
    TIME_OUT_FOR_UNUSED_IDV_WEB_SESSIONS("time.out.for.unused.idv.web.sessions"),
    WHITELISTED_IPS("whitelisted.ips");

    private String name;

    private IdvWebConfigKeys(final String name) {
        this.name = name;
    }

    /**
     * @return the name of the enum
     */
    public String getName() {
        return name;
    }

}
