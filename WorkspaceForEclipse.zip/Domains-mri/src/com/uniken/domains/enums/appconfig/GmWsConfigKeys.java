package com.uniken.domains.enums.appconfig;

public enum GmWsConfigKeys {

    SERVER_PORT("gm.ws.server.port"),
    SERVER_SSL_ENABLED("gm.ws.server.ssl.enabled"),
    SERVER_SSL_KEYSTORE_TYPE("gm.ws.server.ssl.keystore.type"),
    SERVER_SSL_KEY_ALIAS("gm.ws.server.ssl.key.alias"),
    SERVER_SSL_KEYSTORE_PASSWORD("gm.ws.server.ssl.keystore.password"),
    SERVER_SSL_KEYSTORE("gm.ws.server.ssl.keystore"),
    SERVER_SSL_KEYSTORE_PROVIDER("gm.ws.server.ssl.keystore.provider");

    private String name;

    private GmWsConfigKeys(final String name) {
        this.name = name;
    }

    /**
     * @return the name of the enum
     */
    public String getName() {
        return name;
    }

}
