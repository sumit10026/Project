/**
 * 
 */
package com.uniken.domains.enums.appconfig;

/**
 * Application Configuration keys that are common across all the projects.
 * 
 * @author Kushal Jaiswal
 */
public enum CommonConfigKeys {

    // -----------------------------------------------------//
    // -----------------Keys for DB Name -------------------//
    // -----------------------------------------------------//

    DB_NAME_RELID("relid.db.name"),
    DB_NAME_VERIFY("verify.db.name"),
    DB_NAME_GM("gm.db.name"),
    DB_NAME_ISA("isa.db.name"),
    DB_NAME_ADAPTER("adapter.db.name"),
    DB_NAME_OOBMSG("oobmsg.db.name"),
    DB_NAME_AUTH_SERVER("auth.server.db.name"),
    DB_NAME_IDV("idv.db.name"),

    // -----------------------------------------------------//
    // ------------- Keys for MongoDB Config ---------------//
    // -----------------------------------------------------//

    MONGODB_IS_SSL_ENABLED("mongodb.is.ssl.enabled"),
    MONGODB_USERNAME("mongodb.username"),
    MONGODB_SOURCE("mongodb.source"),
    MONGODB_STORE_PATH("mongodb.store.path"),
    MONGODB_STORE_PWD("mongodb.store.pwd"),
    MONGODB_KEYCERT_PATH("mongodb.keycert.path"),
    MONGODB_KEYCERT_PWD("mongodb.keycert.pwd"),
    MONGODB_CONNECTION_STRING("mongodb.connection.string"),
    MONGODB_SYNC_CONN_PER_HOST("mongodb.sync.conn.per.host"),
    MONGODB_MAX_POOL_SIZE("mongodb.max.pool.size"),
    MONGODB_MIN_POOL_SIZE("mongodb.min.pool.size"),
    MONGODB_MAX_WAIT_QUEUE_SIZE("mongodb.max.wait.queue.size"),
    MONGODB_MAX_WAIT_TIME_IN_MILLIS("mongodb.max.wait.time.in.millis"),
    MONGODB_MAX_CONNECTION_LIFETIME_IN_MILLIS("mongodb.max.connection.life.time.in.millis"),
    MONGODB_MAX_CONNECTION_IDLETIME_IN_MILLIS("mongodb.max.connection.idle.time.in.millis"),
    MONGODB_MAINTENANCE_INITIAL_DELAY_IN_MILLIS("mongodb.maintenance.initial.delay.in.millis"),
    MONGODB_MAINTENANCE_FREQUENCY_IN_MILLIS("mongodb.maintenance.frequency.in.millis"),

    // -----------------------------------------------------//
    // ------------- Keys for RabbitMQ Config ---------------//
    // -----------------------------------------------------//
    RABBIT_MQ_IS_SSL_ENABLED("mq.is.ssl.enabled"),
    RABBIT_MQ_USERNAME("mq.username"),
    RABBIT_MQ_PASSWORD("mq.password"),
    RABBIT_MQ_LOCALPORT("mq.localport"),
    RABBIT_MQ_LOCALHOST("mq.localhost"),
    RABBIT_MQ_STORE_PATH("mq.store.path"),
    RABBIT_MQ_STORE_PWD("mq.store.pwd"),
    RABBIT_MQ_KEYCERT_PATH("mq.keycert.path"),
    RABBIT_MQ_KEYCERT_PWD("mq.keycert.pwd"),

    // -----------------------------------------------------//
    // ------------- Keys for TOTP Configs -----------------//
    // -----------------------------------------------------//

    IS_TOTP_ENABLED("is.totp.enabled"),
    TOTP_CONFIGS("totp.config"),
    APP_AGENTS_ENABLED_FOR_TOTP("app.agents.enabled.for.totp"),

    // -----------------------------------------------------//
    // ------------- Keys for General Configs --------------//
    // -----------------------------------------------------//

    DATE_FORMAT("date.format"),
    NOTIFICATION_MSG_ACCEPT_LABEL("notification.msg.accept.label"),
    NOTIFICATION_MSG_REJECT_LABEL("notification.msg.reject.label"),
    NOTIFICATION_MSG_FRAUD_LABEL("notification.msg.fraud.label"),
    PASS_POLICY("pass.policy"),

    // -----------------------------------------------------//
    // ------------- Keys for HTTP Configs --------------//
    // -----------------------------------------------------//

    HTTP_CONNECTION_TIMEOUT("http.connection.timeout"),
    HTTP_READ_TIMEOUT("http.read.timeout"),
    SESSION_TIMEOUT("session.timeout"),
    SESSION_IDLE_TIMEOUT("session.idle.timeout"),

    // -----------------------------------------------------//
    // ------------- Keys for Access Server Configs --------------//
    // -----------------------------------------------------//

    ACCESS_SERVER_HOSTNAME("access.server.hostname"),
    ACCESS_SERVER_PORT("access.server.port"),

    // -----------------------------------------------------//
    // ------------- Keys for IdvWebServer Configs --------------//
    // -----------------------------------------------------//
    IDV_WEB_TOKEN_CRYPTO_KEY("idv.web.token.crypto.key"),

    // -----------------------------------------------------//
    // ------------- Keys for IDV Configs --------------//
    // -----------------------------------------------------//
    IDV_AGENT_KYC_GROUP_NAMES("idv.agent.kyc.group.names");

    private String name;

    private CommonConfigKeys(final String name) {
        this.name = name;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

}
