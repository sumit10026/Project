package com.uniken.domains.enums.appconfig;

/**
 * This enum contains the list of all module names in REL-ID server
 * 
 * @author Uday T
 */
public enum ModuleNames {

    CommonConfigs("Common-Configs"),
    GM("GM"),
    FallbackHandler("Fallback Handler"),
    RELIDVerifyServer("Rel-ID Verify Server"),
    IdentityAdapter("Identity Adapter"),
    DBArchiver("DB-Archiver"),
    CSCMongo("CSC-Mongo"),
    CSCAPI("CSC-API"),
    CSCAD("CSC-AD"),
    UserAPIServer("User API Server"),
    BlaZeServer("BlaZe-Server"),
    BlaZeAdapter("BlaZe-Adapter"),
    BWAdapter("BWAdapter"),
    OOBPusher("OOBPusher"),
    EventLogger("Event-Logger"),
    AUTH_SERVER("Auth Server"),
    OAUTH_AUTHENTICATOR("OAuth Authenticator"),
    GMAPIServer("GM API Server"),
    AccessServer("Access-Server"),
    IDVConnector("IDVConnector"),
    IdvServer("IDV Server"),
    IdvWebServer("IDV Web Server"),
    CIBAServer("CIBA Server"),
    GMUXServer("GM UX Server");

    private String moduleName;

    private ModuleNames(final String moduleName) {
        this.moduleName = moduleName;
    }

    public String getName() {
        return moduleName;
    }
}
