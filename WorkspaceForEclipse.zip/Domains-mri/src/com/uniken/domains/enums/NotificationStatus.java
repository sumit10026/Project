package com.uniken.domains.enums;

public enum NotificationStatus {

    ACTIVE, EXPIRED, UPDATED, NOTIFIED, PARTIALLY_NOTIFIED, FAILED_TO_NOTIFY, TAMPERED, DISCARDED, DISMISSED;

}
