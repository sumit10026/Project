/**
 * 
 */
package com.uniken.domains.enums.web;

/**
 * @author Kushal Jaiswal
 */
public enum WebIdUserStatus {

    CREATED, ACTIVE, BLOCKED;

}
