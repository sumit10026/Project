package com.uniken.domains.enums;

public enum RelIdVersion {

    v1("v1"), v6("v6");

    private String value;

    RelIdVersion(final String value) {
        this.value = value;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

}
