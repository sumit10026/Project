/**
 * 
 */
package com.uniken.domains.enums;

/**
 * @author Uniken India.
 */
public enum DeviceType {
    SECURED, NON_SECURED
}
