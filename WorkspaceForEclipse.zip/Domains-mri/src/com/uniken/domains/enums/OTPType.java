/**
 * 
 */
package com.uniken.domains.enums;

/**
 * @author Uniken Inc.
 */
public enum OTPType {
    EMAIL, SMS
}
