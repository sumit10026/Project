/**
 * 
 */
package com.uniken.domains.web.user.vo;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.relid.user.UserAuthInfo;
import com.uniken.domains.web.user.WebId;

/**
 * @author Kushal Jaiswal
 */
public class UserAuthInfoWebVo extends UserAuthInfo {

    public static final String LAST_ACCESSED_WEB_TS_STR = "last_accessed_web_ts";
    public static final String LAST_ACCESSED_WEB_DEVICE_UUID_STR = "last_accessed_web_dev_uuid";
    public static final String WEBIDS_STR = "webids";

    @SerializedName(WEBIDS_STR)
    @Field(WEBIDS_STR)
    public List<WebId> webids;

    @SerializedName(LAST_ACCESSED_WEB_TS_STR)
    @Field(LAST_ACCESSED_WEB_TS_STR)
    public Date lastAccessedWebTS;

    @SerializedName(LAST_ACCESSED_WEB_DEVICE_UUID_STR)
    @Field(LAST_ACCESSED_WEB_DEVICE_UUID_STR)
    public String lastAccessedWebDevUUID;

    /**
     * 
     */
    public UserAuthInfoWebVo() {
        super();
    }

    /**
     * @param userAuthInfo
     * @param webids
     * @param lastAccessedWebTS
     * @param lastAccessedWebDevUUID
     * @param userUpdatedTS
     */
    private UserAuthInfoWebVo(final UserAuthInfo userAuthInfo, final WebId webids, final Date lastAccessedWebTS,
            final String lastAccessedWebDevUUID, final Date userUpdatedTS) {

        userAuthInfo.setId(userAuthInfo.getId());

        userAuthInfo.setUserUuid(userAuthInfo.getUserUuid());
        userAuthInfo.setUserId(userAuthInfo.getUserId());
        userAuthInfo.setPrivacyKey(userAuthInfo.getPrivacyKey());
        userAuthInfo.setLoginId(userAuthInfo.getLoginId());
        userAuthInfo.setCreatedTs(userAuthInfo.getCreatedTs());
        userAuthInfo.setSourceType(userAuthInfo.getSourceType());
        userAuthInfo.setCounter(userAuthInfo.getCounter());
        userAuthInfo.setRelIdZeroEnabled(userAuthInfo.isRelIdZeroEnabled());
        userAuthInfo.setPreviousStatus(userAuthInfo.getPreviousStatus());
        userAuthInfo.setUserStatus(userAuthInfo.getUserStatus());

        userAuthInfo.setPrimaryGroupUuid(userAuthInfo.getPrimaryGroupUuid());
        userAuthInfo.setFirstName(userAuthInfo.getFirstName());
        userAuthInfo.setLastName(userAuthInfo.getLastName());
        userAuthInfo.setGmUserId(userAuthInfo.getGmUserId());
        userAuthInfo.setPrimaryGroupName(userAuthInfo.getPrimaryGroupName());
        userAuthInfo.setSecondaryGroupUuids(userAuthInfo.getSecondaryGroupUuids());
        userAuthInfo.setSecondaryGroupNames(userAuthInfo.getSecondaryGroupNames());
        userAuthInfo.setUpdatedTs(userUpdatedTS);

        final List<WebId> newWebIds = new ArrayList<>(this.webids);
        newWebIds.add(webids);

        this.webids = newWebIds;
        this.lastAccessedWebTS = lastAccessedWebTS;
        this.lastAccessedWebDevUUID = lastAccessedWebDevUUID;
    }

    /**
     * Get Instance of {@link UserAuthInfo} for web devices.
     * 
     * @param userAuthInfo
     * @param webids
     * @param lastAccessedWebTS
     * @param lastAccessedWebDevUUID
     * @param userUpdatedTS
     * @return
     */
    public static UserAuthInfo getInstanceOfUserAuthInfoForWeb(final UserAuthInfo userAuthInfo, final WebId webids,
            final Date lastAccessedWebTS, final String lastAccessedWebDevUUID, final Date userUpdatedTS) {

        return new UserAuthInfoWebVo(userAuthInfo, webids, lastAccessedWebTS, lastAccessedWebDevUUID, userUpdatedTS);

    }
}
