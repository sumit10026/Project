/**
 * 
 */
package com.uniken.domains.web.user;

import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.enums.web.WebIdUserStatus;

/**
 * @author Kushal Jaiswal
 */
@Document(collection = "webids")
public class WebId {

    public static final String ID_STR = "_id";
    public static final String WEBID_UUID_STR = "webid_uuid";
    public static final String WEBID_STATUS_STR = "webid_status";
    public static final String WEBID_CREATED_TS_STR = "webid_created_ts";
    public static final String WEBID_UPDATED_TS_STR = "webid_updated_ts";
    public static final String WEBID_DEV_UUID_STR = "web_dev_uuid";
    public static final String WEBID_DEV_PLATFORM_STR = "web_dev_platform";
    public static final String WEB_DEV_LAST_ACCESSED_TS_STR = "web_dev_last_accessed_ts";

    @Field(ID_STR)
    @SerializedName(ID_STR)
    @Id
    private ObjectId id;

    @Field(WEBID_UUID_STR)
    @SerializedName(WEBID_UUID_STR)
    @Indexed(unique = true)
    private final String webIdUUID;

    @Field(WEBID_STATUS_STR)
    @SerializedName(WEBID_STATUS_STR)
    private final WebIdUserStatus webIdStatus;

    @Field(WEBID_CREATED_TS_STR)
    @SerializedName(WEBID_CREATED_TS_STR)
    private final Date webIdCreatedTS;

    @Field(WEBID_UPDATED_TS_STR)
    @SerializedName(WEBID_UPDATED_TS_STR)
    private Date webIdUpdatedTS;

    @Field(WEBID_DEV_UUID_STR)
    @SerializedName(WEBID_DEV_UUID_STR)
    private final String webDevUUID;

    @Field(WEBID_DEV_PLATFORM_STR)
    @SerializedName(WEBID_DEV_PLATFORM_STR)
    private final String webDevPlatform;

    @Field(WEB_DEV_LAST_ACCESSED_TS_STR)
    @SerializedName(WEB_DEV_LAST_ACCESSED_TS_STR)
    private Date webDevLastAccessedTS;

    /**
     * @param id
     * @param webIdUUID
     * @param webIdStatus
     * @param webIdCreatedTS
     * @param webIdUpdatedTS
     * @param webDevUUID
     * @param webDevPlatform
     * @param webDevLastAccessedTS
     */
    public WebId(final ObjectId id, final String webIdUUID, final WebIdUserStatus webIdStatus,
            final Date webIdCreatedTS, final Date webIdUpdatedTS, final String webDevUUID, final String webDevPlatform,
            final Date webDevLastAccessedTS) {

        this.id = id;
        this.webIdUUID = webIdUUID;
        this.webIdStatus = webIdStatus;
        this.webIdCreatedTS = webIdCreatedTS;
        this.webIdUpdatedTS = webIdUpdatedTS;
        this.webDevUUID = webDevUUID;
        this.webDevPlatform = webDevPlatform;
        this.webDevLastAccessedTS = webDevLastAccessedTS;
    }

    /**
     * @param webIdUUID
     * @param webIdStatus
     * @param webIdCreatedTS
     * @param webIdUpdatedTS
     * @param webDevUUID
     * @param webDevPlatform
     * @param webDevLastAccessedTS
     */
    public WebId(final String webIdUUID, final WebIdUserStatus webIdStatus, final Date webIdCreatedTS,
            final Date webIdUpdatedTS, final String webDevUUID, final String webDevPlatform,
            final Date webDevLastAccessedTS) {

        this.webIdUUID = webIdUUID;
        this.webIdStatus = webIdStatus;
        this.webIdCreatedTS = webIdCreatedTS;
        this.webIdUpdatedTS = webIdUpdatedTS;
        this.webDevUUID = webDevUUID;
        this.webDevPlatform = webDevPlatform;
        this.webDevLastAccessedTS = webDevLastAccessedTS;
    }

    /**
     * @return the webIdUUID
     */
    public String getWebIdUUID() {
        return webIdUUID;
    }

    /**
     * @return the webIdStatus
     */
    public WebIdUserStatus getWebIdStatus() {
        return webIdStatus;
    }

    /**
     * @return the webIdCreatedTS
     */
    public Date getWebIdCreatedTS() {
        return webIdCreatedTS;
    }

    /**
     * @return the webIdUpdatedTS
     */
    public Date getWebIdUpdatedTS() {
        return webIdUpdatedTS;
    }

    /**
     * Set the WebId updated time stamp
     * 
     * @param webIdUpdatedTS
     */
    public void setWebIdUpdatedTS(final Date webIdUpdatedTS) {
        this.webIdUpdatedTS = webIdUpdatedTS;
    }

    /**
     * @return the webDevUUID
     */
    public String getWebDevUUID() {
        return webDevUUID;
    }

    /**
     * @return the webDevPlatform
     */
    public String getWebDevPlatform() {
        return webDevPlatform;
    }

    /**
     * @return the webDevLastAccessedTS
     */
    public Date getWebDevLastAccessedTS() {
        return webDevLastAccessedTS;
    }

    /**
     * Set the WebId last access time stamp
     * 
     * @param webDevLastAccessedTS
     */
    public void setWebDevLastAccessedTS(final Date webDevLastAccessedTS) {
        this.webDevLastAccessedTS = webDevLastAccessedTS;
    }
}
