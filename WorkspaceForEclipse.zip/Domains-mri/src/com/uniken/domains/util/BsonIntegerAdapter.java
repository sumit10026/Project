package com.uniken.domains.util;

import java.lang.reflect.Type;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

public class BsonIntegerAdapter
        implements JsonSerializer<Integer> {

    @Override
    public JsonElement serialize(final Integer arg0, final Type arg1, final JsonSerializationContext arg2) {
        try {
            return new JsonPrimitive(arg0.toString());
        } catch (Exception e) {
            return null;
        }
    }

    // @Override
    // public String deserialize(final JsonElement jsonElement, final Type arg1,
    // final JsonDeserializationContext arg2)
    // throws JsonParseException {
    //
    // try {
    //
    // if (jsonElement.isJsonPrimitive()) {
    // Number num = null;
    // num = NumberFormat.getInstance().parse(jsonElement.getAsString());
    // return num.toString();
    // }
    //
    // } catch (Exception e) {
    // return null;
    // }
    // return null;
    // }

}
