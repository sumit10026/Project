package com.uniken.domains.util;

import java.lang.reflect.Type;

import org.bson.types.ObjectId;

import com.google.gson.JsonDeserializationContext;
import com.google.gson.JsonDeserializer;
import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import com.google.gson.JsonSerializationContext;
import com.google.gson.JsonSerializer;

public class BsonObjectIdAdapter
        implements
        JsonDeserializer<ObjectId>,
        JsonSerializer<ObjectId> {

    @Override
    public ObjectId deserialize(final JsonElement arg0, final Type arg1, final JsonDeserializationContext arg2) {

        try {
            return new ObjectId(arg0.getAsJsonObject().get("$oid").getAsString());
        } catch (final Exception e) {
            return null;
        }
    }

    @Override
    public JsonElement serialize(final ObjectId arg0, final Type arg1, final JsonSerializationContext arg2) {
        return new JsonPrimitive(arg0.toString());
    }
}
