/**
 * 
 */
package com.uniken.domains.util;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Set;

import org.springframework.security.oauth2.common.exceptions.InvalidScopeException;

/**
 * A basic utility class.
 * 
 * @author Kushal Jaiswal
 */
public class OAuthUtils {

    /**
     * Utility method to extract OAuth token from the string.
     * 
     * @param value
     *            the plain string value.
     * @return the MD5 Digest String
     */
    public static String extractTokenKey(final String value) {
        if (value == null) {
            return null;
        } else {
            MessageDigest digest;
            try {
                digest = MessageDigest.getInstance("MD5");
            } catch (final NoSuchAlgorithmException var5) {
                throw new IllegalStateException("MD5 algorithm not available.  Fatal (should be in the JDK).");
            }

            final byte[] e = digest.digest(value.getBytes(StandardCharsets.UTF_8));
            return String.format("%032x", new BigInteger(1, e));
        }
    }

    /**
     * Utility Service to validate the Scope, if not validate then Throw
     * {@link InvalidScopeException}.
     * 
     * @param requestScopes
     *            the scope received in the request.
     * @param clientScopes
     *            the user/client scopes.
     */
    public static void validateScope(final Set<String> requestScopes, final Set<String> clientScopes) {

        if (clientScopes != null && !clientScopes.isEmpty()) {
            for (final String scope : requestScopes) {
                if (!clientScopes.contains(scope)) {
                    throw new InvalidScopeException("Invalid scope: " + scope, clientScopes);
                }
            }
        }

        if (requestScopes.isEmpty()) {
            throw new InvalidScopeException(
                    "Empty scope (either the client or the user is not allowed the requested scopes)");
        }
    }

    private OAuthUtils() {
        throw new IllegalStateException("Utility class");
    }

}
