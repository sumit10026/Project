package com.uniken.domains.idv;

import com.google.gson.annotations.SerializedName;

public class Button {

    @SerializedName("key")
    private final String key;

    @SerializedName("button_text")
    private final String buttonText;

    public Button(final String key, final String buttonText) {
        super();
        this.key = key;
        this.buttonText = buttonText;
    }

    public String getKey() {
        return key;
    }

    public String getButtonText() {
        return buttonText;
    }

}
