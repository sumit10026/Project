package com.uniken.domains.idv;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class ChallengePromptActionButton {

    @SerializedName("success_button")
    private List<Button> successButton;

    @SerializedName("failure_button")
    private List<Button> failureButton;

    public List<Button> getSuccessButton() {
        return successButton;
    }

    public void setSuccessButton(final List<Button> successButton) {
        this.successButton = successButton;
    }

    public List<Button> getFailureButton() {
        return failureButton;
    }

    public void setFailureButton(final List<Button> failureButton) {
        this.failureButton = failureButton;
    }

}
