package com.uniken.domains.idv.kyc.request;

import com.google.gson.annotations.SerializedName;

public class KycRequestData {

    @SerializedName("kyc_info")
    private final String kycInfo;

    public KycRequestData(final String data) {
        super();
        this.kycInfo = data;
    }

    /**
     * @return the kycInfo
     */
    public String getKycInfo() {
        return kycInfo;
    }

}
