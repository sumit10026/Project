package com.uniken.domains.idv.web;

import java.io.Serializable;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.enums.IdvWebStatus;

public class IdvWebToken
        implements
        Serializable {
    private static final long serialVersionUID = 1L;

    public static final String USER_ID_STR = "userId";
    public static final String CALLBACK_URL_STR = "callBackURL";
    public static final String REFERENCE_NUMBER_STR = "reference_number";
    public static final String IDV_STATUS_STR = "idv_status";
    public static final String MESSAGE_STR = "message";

    @SerializedName(USER_ID_STR)
    @Field(USER_ID_STR)
    private String userId;

    @SerializedName(CALLBACK_URL_STR)
    @Field(CALLBACK_URL_STR)
    private String callBackURL;

    @SerializedName(REFERENCE_NUMBER_STR)
    @Field(REFERENCE_NUMBER_STR)
    private String reference_number;

    @SerializedName(IDV_STATUS_STR)
    @Field(IDV_STATUS_STR)
    private IdvWebStatus idv_status;

    @SerializedName(MESSAGE_STR)
    @Field(MESSAGE_STR)
    private String message;

    public IdvWebToken() {

    }

    public IdvWebToken(final String userId, final String callBackURL, final String reference_number,
            final IdvWebStatus idv_status, final String message) {
        super();
        this.userId = userId;
        this.callBackURL = callBackURL;
        this.reference_number = reference_number;
        this.idv_status = idv_status;
        this.message = message;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(final String userId) {
        this.userId = userId;
    }

    public String getCallBackURL() {
        return callBackURL;
    }

    public void setCallBackURL(final String callBackURL) {
        this.callBackURL = callBackURL;
    }

    public String getReference_number() {
        return reference_number;
    }

    public void setReference_number(final String reference_number) {
        this.reference_number = reference_number;
    }

    public IdvWebStatus getIdv_status() {
        return idv_status;
    }

    public void setIdv_status(final IdvWebStatus idv_status) {
        this.idv_status = idv_status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(final String message) {
        this.message = message;
    }

    public static Document getBsonDocument(final IdvWebToken idvWebToken) {

        if (idvWebToken == null) {
            return null;
        }

        final Document document = new Document();

        if (idvWebToken.getUserId() != null) {
            document.append(USER_ID_STR, idvWebToken.getUserId());
        }

        if (idvWebToken.getCallBackURL() != null) {
            document.append(CALLBACK_URL_STR, idvWebToken.getCallBackURL());
        }

        if (idvWebToken.getIdv_status() != null) {
            document.append(IDV_STATUS_STR, idvWebToken.getIdv_status().name());
        }

        if (idvWebToken.getMessage() != null) {
            document.append(MESSAGE_STR, idvWebToken.getMessage());
        }

        if (idvWebToken.getReference_number() != null) {
            document.append(REFERENCE_NUMBER_STR, idvWebToken.getReference_number());
        }

        return document;
    }
}
