package com.uniken.domains.idv.web;

import java.util.Date;

import org.bson.Document;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.enums.IdvWebStatus;

public class IdvWebSession {

    private static final long serialVersionUID = 1L;
    public static final String WEB_SESSION_ID = "webSessionId";
    public static final String IDV_WEB_TOKEN = "idvWebToken";
    public static final String CREATED_TS = "createdTS";
    public static final String UPDATED_TS = "updatedTS";
    public static final String EXPIRY_TS = "expiryTS";
    public static final String SESSION_STATUS = "sessionStatus";
    public static final String DOC_SCAN_RESPONSE = "docScanResponse";
    public static final String LIVENESS_COMPARE_RESPONSE = "livenessCompareResponse";
    public static final String KYC_RESPONSE = "kycResponse";
    public static final String OPT_IN_RESPONSE = "optInResponse";
    public static final String IDV_AUDIT_TRANSACTION_ID = "idvAuditTransactionId";

    @Id
    private String id;

    @SerializedName(WEB_SESSION_ID)
    @Field(WEB_SESSION_ID)
    private String webSessionId;

    @SerializedName(IDV_WEB_TOKEN)
    @Field(IDV_WEB_TOKEN)
    private String idvWebToken;

    @SerializedName(CREATED_TS)
    @Field(CREATED_TS)
    private Date createdTS;

    @SerializedName(UPDATED_TS)
    @Field(UPDATED_TS)
    private Date updatedTS;

    @SerializedName(EXPIRY_TS)
    @Field(EXPIRY_TS)
    private Date expiryTS;

    @SerializedName(SESSION_STATUS)
    @Field(SESSION_STATUS)
    private IdvWebStatus sessionStatus; // PENDING, INPROGRESS, COMPLETE

    @SerializedName(DOC_SCAN_RESPONSE)
    @Field(DOC_SCAN_RESPONSE)
    private String docScanResponse; // response received from IDVServer
    // private String docScanDerivedData;// raw data + derived data. Required
    // for
    // kyc

    @SerializedName(LIVENESS_COMPARE_RESPONSE)
    @Field(LIVENESS_COMPARE_RESPONSE)
    private String livenessCompareResponse; // response received from IDVServer

    @SerializedName(KYC_RESPONSE)
    @Field(KYC_RESPONSE)
    private String kycResponse; // response received from IDVServer

    @SerializedName(OPT_IN_RESPONSE)
    @Field(OPT_IN_RESPONSE)
    private String optInResponse; // response received from IDVServer

    @SerializedName(IDV_AUDIT_TRANSACTION_ID)
    @Field(IDV_AUDIT_TRANSACTION_ID)
    private String idvAuditTransactionId; // response received from IDVServer

    public String getWebSessionId() {
        return webSessionId;
    }

    public void setWebSessionId(final String webSessionId) {
        this.webSessionId = webSessionId;
    }

    public String getIdvWebToken() {
        return idvWebToken;
    }

    public void setIdvWebToken(final String idvWebToken) {
        this.idvWebToken = idvWebToken;
    }

    public Date getCreatedTS() {
        return createdTS;
    }

    public void setCreatedTS(final Date createdTS) {
        this.createdTS = createdTS;
    }

    public Date getUpdatedTS() {
        return updatedTS;
    }

    public void setUpdatedTS(final Date updatedTS) {
        this.updatedTS = updatedTS;
    }

    public Date getExpiryTS() {
        return expiryTS;
    }

    public void setExpiryTS(final Date expiryTS) {
        this.expiryTS = expiryTS;
    }

    public IdvWebStatus getSessionStatus() {
        return sessionStatus;
    }

    public void setSessionStatus(final IdvWebStatus sessionStatus) {
        this.sessionStatus = sessionStatus;
    }

    public String getDocScanResponse() {
        return docScanResponse;
    }

    public void setDocScanResponse(final String docScanResponse) {
        this.docScanResponse = docScanResponse;
    }

    public String getLivenessCompareResponse() {
        return livenessCompareResponse;
    }

    public void setLivenessCompareResponse(final String livenessCompareResponse) {
        this.livenessCompareResponse = livenessCompareResponse;
    }

    public String getKycResponse() {
        return kycResponse;
    }

    public void setKycResponse(final String kycResponse) {
        this.kycResponse = kycResponse;
    }

    public String getOptInResponse() {
        return optInResponse;
    }

    public void setOptInResponse(final String optInResponse) {
        this.optInResponse = optInResponse;
    }

    public String getIdvAuditTransactionId() {
        return idvAuditTransactionId;
    }

    public void setIdvAuditTransactionId(final String idvAuditTransactionId) {
        this.idvAuditTransactionId = idvAuditTransactionId;
    }

    public static Document getBsonDocument(final IdvWebSession idvWebSession) {

        if (idvWebSession == null) {
            return null;
        }

        final Document document = new Document();

        if (idvWebSession.getWebSessionId() != null) {
            document.append(IdvWebSession.WEB_SESSION_ID, idvWebSession.getWebSessionId());
        }

        if (idvWebSession.getIdvWebToken() != null) {
            document.append(IdvWebSession.IDV_WEB_TOKEN, idvWebSession.getIdvWebToken());
        }

        if (idvWebSession.getCreatedTS() != null) {
            document.append(IdvWebSession.CREATED_TS, idvWebSession.getCreatedTS());
        }

        if (idvWebSession.getUpdatedTS() != null) {
            document.append(IdvWebSession.UPDATED_TS, idvWebSession.getUpdatedTS());
        }

        if (idvWebSession.getExpiryTS() != null) {
            document.append(IdvWebSession.EXPIRY_TS, idvWebSession.getExpiryTS());
        }

        if (idvWebSession.getSessionStatus() != null) {
            document.append(IdvWebSession.SESSION_STATUS, idvWebSession.getSessionStatus().name());
        }

        if (idvWebSession.getDocScanResponse() != null) {
            document.append(IdvWebSession.DOC_SCAN_RESPONSE, idvWebSession.getDocScanResponse());
        }

        if (idvWebSession.getIdvAuditTransactionId() != null) {
            document.append(IdvWebSession.IDV_AUDIT_TRANSACTION_ID, idvWebSession.getIdvAuditTransactionId());
        }

        if (idvWebSession.getKycResponse() != null) {
            document.append(IdvWebSession.KYC_RESPONSE, idvWebSession.getKycResponse());
        }

        if (idvWebSession.getLivenessCompareResponse() != null) {
            document.append(IdvWebSession.LIVENESS_COMPARE_RESPONSE, idvWebSession.getLivenessCompareResponse());
        }

        if (idvWebSession.getOptInResponse() != null) {
            document.append(IdvWebSession.OPT_IN_RESPONSE, idvWebSession.getOptInResponse());
        }

        return document;
    }
}
