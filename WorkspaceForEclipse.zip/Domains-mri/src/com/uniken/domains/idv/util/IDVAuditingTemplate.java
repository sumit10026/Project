package com.uniken.domains.idv.util;

import java.util.Date;

import org.bson.Document;

import com.google.gson.annotations.SerializedName;

public class IDVAuditingTemplate {

    private static final String IDV_TRANSACTION_ID = "idv_audit_transaction_id";
    private static final String IDV_ORCHESTRATION_ID = "orchestration_use_case";
    private static final String CREATED_TS = "created_ts";

    @SerializedName(value = IDV_TRANSACTION_ID)
    private String idvTransactionId;

    @SerializedName(value = IDV_ORCHESTRATION_ID)
    private String idvOrchestrationId;

    @SerializedName(value = CREATED_TS)
    private Date createdTs;

    public String getIdvTransactionId() {
        return idvTransactionId;
    }

    public void setIdvTransactionId(final String idvTransactionId) {
        this.idvTransactionId = idvTransactionId;
    }

    public String getIdvOrchestrationId() {
        return idvOrchestrationId;
    }

    public void setIdvOrchestrationId(final String idvOrchestrationId) {
        this.idvOrchestrationId = idvOrchestrationId;
    }

    public Date getCreatedTs() {
        return createdTs;
    }

    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }

    /**
     * * @param idv_auditing_info
     * 
     * @return
     */
    public static Document getBsonDocumentFromIDVAuditingTemplateObject(final IDVAuditingTemplate idvAuditingTemplate) {

        if (null == idvAuditingTemplate) {
            return null;
        }

        final Document idvAuditingTemplateDoc = new Document();

        if (idvAuditingTemplate.getIdvOrchestrationId() != null) {
            idvAuditingTemplateDoc.append(IDVAuditingTemplate.IDV_ORCHESTRATION_ID,
                    idvAuditingTemplate.getIdvOrchestrationId());
        }

        if (idvAuditingTemplate.getIdvTransactionId() != null) {
            idvAuditingTemplateDoc.append(IDVAuditingTemplate.IDV_TRANSACTION_ID,
                    idvAuditingTemplate.getIdvTransactionId());
        }

        if (idvAuditingTemplate.getCreatedTs() != null) {
            idvAuditingTemplateDoc.append(IDVAuditingTemplate.CREATED_TS, idvAuditingTemplate.getCreatedTs());
        }

        return idvAuditingTemplateDoc;
    }
}
