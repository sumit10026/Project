package com.uniken.domains.idv.util;

public class IDVCommonConstants {

    private IDVCommonConstants() {

    }

    public static final String BTN_KEY_CONTINUE_FLOW_STR = "continue-flow";
    public static final String BTN_KEY_REINIT_IDV_DOCUMENT_SCAN_STR = "reinit-idv-document-scan";
    public static final String BTN_KEY_REINIT_IDV_SELFIE_STR = "reinit-idv-selfie";

}
