/**
 * 
 */
package com.uniken.domains.relid;

import java.util.List;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * @author Sumeet Khambe
 */
public class ComparableData {

    @Expose
    @SerializedName("param")
    private String param;

    @Expose
    @SerializedName("value")
    private List<String> value;

    @Expose
    @SerializedName("type")
    private String type;

    /**
     * @return the param
     */
    public String getParam() {
        return param;
    }

    /**
     * @param param
     *            the param to set
     */
    public void setParam(final String param) {
        this.param = param;
    }

    /**
     * @return the value
     */
    public List<String> getValue() {
        return value;
    }

    /**
     * @param value
     *            the value to set
     */
    public void setValue(final List<String> value) {
        this.value = value;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type
     *            the type to set
     */
    public void setType(final String type) {
        this.type = type;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("ComparableData [param=");
        builder.append(param);
        builder.append(", value=");
        builder.append(value);
        builder.append(", type=");
        builder.append(type);
        builder.append("]");
        return builder.toString();
    }

}
