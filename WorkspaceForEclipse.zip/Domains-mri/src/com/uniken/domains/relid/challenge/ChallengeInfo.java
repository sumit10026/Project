package com.uniken.domains.relid.challenge;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.google.gson.annotations.SerializedName;

public class ChallengeInfo {

    @SerializedName(value = "key")
    private String key;

    @SerializedName(value = "value")
    private String value;

    /**
     * @return the key
     */
    public String getKey() {
        return key;
    }

    /**
     * @param key
     *            the key to set
     */
    public void setKey(final String key) {
        this.key = key;
    }

    /**
     * @return the value
     */
    public String getValue() {
        return value;
    }

    /**
     * @param value
     *            the value to set
     */
    public void setValue(final String value) {
        this.value = value;
    }

    /**
     * @param challengeInfo
     * @return
     */
    public static Document getBsonDocument(final ChallengeInfo challengeInfo) {

        if (null == challengeInfo) {
            return null;
        }

        final Document logDoc = new Document();

        if (null != challengeInfo.getKey()) {
            logDoc.append("key", challengeInfo.getKey());
        }

        if (null != challengeInfo.getValue()) {
            logDoc.append("value", challengeInfo.getValue());
        }

        return logDoc;
    }

    /**
     * @param challengeInfo
     * @return
     */
    public static List<Document> getBsonDocumentList(final List<ChallengeInfo> challengeInfoList) {

        if (null == challengeInfoList) {
            return null;
        }

        final List<Document> logDocList = new ArrayList<>();
        for (final ChallengeInfo challengeInfo : challengeInfoList) {
            logDocList.add(getBsonDocument(challengeInfo));
        }
        return logDocList;
    }
}
