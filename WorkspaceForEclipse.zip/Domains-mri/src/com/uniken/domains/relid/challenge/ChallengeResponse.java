package com.uniken.domains.relid.challenge;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.google.gson.annotations.SerializedName;

public class ChallengeResponse {

    @SerializedName(value = "challenge")
    private String challenge = "";

    @SerializedName(value = "response")
    private String response = "";

    /**
     * @return the challenge
     */
    public String getChallenge() {
        return challenge;
    }

    /**
     * @param challenge
     *            the challenge to set
     */
    public void setChallenge(final String challenge) {
        this.challenge = challenge;
    }

    /**
     * @return the response
     */
    public String getResponse() {
        return response;
    }

    /**
     * @param response
     *            the response to set
     */
    public void setResponse(final String response) {
        this.response = response;
    }

    /**
     * @param challengeResponse
     * @return
     */
    public static Document getBsonDocument(final ChallengeResponse challengeResponse) {

        if (null == challengeResponse) {
            return null;
        }

        final Document logDoc = new Document();

        if (null != challengeResponse.getChallenge()) {
            logDoc.append("challenge", challengeResponse.getChallenge());
        }

        if (null != challengeResponse.getResponse()) {
            logDoc.append("response", challengeResponse.getResponse());
        }

        return logDoc;
    }

    /**
     * @param challengeResponse
     * @return
     */
    public static List<Document> getBsonDocumentList(final List<ChallengeResponse> challengeResponseList) {

        if (null == challengeResponseList) {
            return null;
        }

        final List<Document> logDocList = new ArrayList<>();
        for (final ChallengeResponse challengeResponse : challengeResponseList) {
            logDocList.add(getBsonDocument(challengeResponse));
        }
        return logDocList;
    }
}
