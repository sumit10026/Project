package com.uniken.domains.relid.challenge;

public enum ChallengeName {

    ACTIVATION_CODE("actcode"),
    CRED("pass"),
    SECRET_Q_AND_A("secqa"),
    CHECK_USER("checkuser"),
    DEV_NAME("devname"),
    VERIFY_AUTH("verifyauth"),
    NATIONAL_ID("NationalID"),
    OTP("otp"),
    SERVER_BIOMETRIC("serverbiometric"),
    RELID_IDV_DOCSCAN("RELID-IDV-DocScan"),
    RELID_IDV_SELFIE_BIOMETRIC("RELID-IDV-SelfieBiometric"),
    RELID_IDV_SELFIE_BIOMETRIC_TEMPLATE("RELID-IDV-SelfieBiometricTemplate"),
    RELID_IDV_CONFIRM_SELFIE_BIOMETRIC("RELID-IDV-ConfirmSelfieBiometric"),
    RELID_IDV_KYC("RELID-IDV-KYC"),
    RELID_IDV_BIOMETRIC_OPT_IN("RELID-IDV-BiometricOptIn");

    private String name;

    private ChallengeName(final String name) {
        this.name = name;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
}
