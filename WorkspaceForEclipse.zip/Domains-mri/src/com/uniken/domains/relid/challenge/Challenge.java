package com.uniken.domains.relid.challenge;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.idv.util.IDVAuditingTemplate;
import com.uniken.domains.relid.LogDomain;

public class Challenge extends LogDomain {

    public static final String CHALLENGE_NAME_STR = "chlng_name";
    public static final String CHALLENGE_INDEX_STR = "chlng_idx";
    public static final String CHALLENGE_INFO_STR = "chlng_info";
    public static final String ATTEMPTS_LEFT_STR = "attempts_left";
    public static final String MAX_ATTEMPTS_COUNT_STR = "max_attempts_count";
    public static final String CHALLENGE_RESPONSE_STR = "chlng_resp";
    public static final String CHALLENGE_TYPE_STR = "chlng_type";
    public static final String CHALLENGE_PROMPT_STR = "chlng_prompt";
    public static final String CHALLENGE_RESPONSE_VALIDATION_STR = "chlng_response_validation";
    public static final String CHALLENGE_RESPONSE_POLICY_STR = "challenge_response_policy";
    public static final String CHALLENGE_CIPHER_SPEC_STR = "chlng_cipher_spec";
    public static final String CHALLENGE_CIPHER_SALT_STR = "chlng_cipher_salt";
    public static final String SUB_CHALLENGE_COUNT_STR = "sub_chlng_count";
    public static final String CHALLENGES_PER_BATCH_STR = "chlngs_per_batch";
    public static final String CHALLENGES_PROPERTY_STR = "chlng_property";
    // Added following to support IDV Auditing metrices
    public static final String IDV_AUDIT_INFO = "idv_audit_info";
    // Added following to support true passwordless flows
    public static final String AUTHENTICATED_WITH_STR = "authenticated_with";

    @SerializedName(value = CHALLENGE_NAME_STR)
    private String challengeName;

    @SerializedName(value = IDV_AUDIT_INFO)
    private IDVAuditingTemplate idvAuditingInfo;

    @SerializedName(value = CHALLENGE_INDEX_STR)
    private int challengeIndex;

    @SerializedName(value = CHALLENGE_INFO_STR)
    private List<ChallengeInfo> challengeInfo;

    @SerializedName(value = ATTEMPTS_LEFT_STR)
    private int numberOfAttemptsLeft;

    @SerializedName(value = MAX_ATTEMPTS_COUNT_STR)
    private int maxAttemptsCount;

    @SerializedName(value = CHALLENGE_RESPONSE_STR)
    private List<ChallengeResponse> challengeResponse;

    @SerializedName(value = CHALLENGE_TYPE_STR)
    private int ChallengeType;

    @SerializedName(value = CHALLENGE_PROMPT_STR)
    private List<List<String>> challengePrompt;

    @SerializedName(value = CHALLENGE_RESPONSE_VALIDATION_STR)
    private boolean challengeResponseValidation;

    @SerializedName(value = CHALLENGE_RESPONSE_POLICY_STR)
    private List<String> challengeResponsePolicy;

    @SerializedName(value = CHALLENGE_CIPHER_SPEC_STR)
    private List<String> challengeCipherSpec;

    @SerializedName(value = CHALLENGE_CIPHER_SALT_STR)
    private String challengeCipherSalt;

    @SerializedName(value = SUB_CHALLENGE_COUNT_STR)
    private int subChallengeCount;

    @SerializedName(value = CHALLENGES_PER_BATCH_STR)
    private int challengesPerBatch;

    @SerializedName(value = AUTHENTICATED_WITH_STR)
    private String authenticatedWith;

    @SerializedName(value = CHALLENGES_PROPERTY_STR)
    private ChallengeProperty challengesProperty;

    public IDVAuditingTemplate getIdvAuditingInfo() {
        return idvAuditingInfo;
    }

    public void setIdvAuditingInfo(final IDVAuditingTemplate idvAuditingInfo) {
        this.idvAuditingInfo = idvAuditingInfo;
    }

    /**
     * @return the challengeName
     */
    public String getChallengeName() {
        return challengeName;
    }

    /**
     * @param challengeName
     *            the challengeName to set
     */
    public void setChallengeName(final String challengeName) {
        this.challengeName = challengeName;
    }

    /**
     * @return the challengeIndex
     */
    public int getChallengeIndex() {
        return challengeIndex;
    }

    /**
     * @param challengeIndex
     *            the challengeIndex to set
     */
    public void setChallengeIndex(final int challengeIndex) {
        this.challengeIndex = challengeIndex;
    }

    /**
     * @return the chalengeInfo
     */
    public List<ChallengeInfo> getChallengeInfo() {
        return challengeInfo;
    }

    /**
     * @param chalengeInfo
     *            the chalengeInfo to set
     */
    public void setChalengeInfo(final List<ChallengeInfo> chalengeInfo) {
        this.challengeInfo = chalengeInfo;
    }

    /**
     * @return the numberOfAttempts
     */
    public int getNumberOfAttemptsLeft() {
        return numberOfAttemptsLeft;
    }

    /**
     * @param numberOfAttempts
     *            the numberOfAttempts to set
     */
    public void setNumberOfAttemptsLeft(final int numberOfAttempts) {
        this.numberOfAttemptsLeft = numberOfAttempts;
    }

    /**
     * @return the challengeResponse
     */
    public List<ChallengeResponse> getChallengeResponse() {
        return challengeResponse;
    }

    /**
     * @param challengeResponse
     *            the challengeResponse to set
     */
    public void setChallengeResponse(final List<ChallengeResponse> challengeResponse) {
        this.challengeResponse = challengeResponse;
    }

    /**
     * @return the challengeType
     */
    public int getChallengeType() {
        return ChallengeType;
    }

    /**
     * @param challengeType
     *            the challengeType to set
     */
    public void setChallengeType(final int challengeType) {
        ChallengeType = challengeType;
    }

    /**
     * @return the challengePrompt
     */
    public List<List<String>> getChallengePrompt() {
        return challengePrompt;
    }

    /**
     * @param challengePrompt
     *            the challengePrompt to set
     */
    public void setChallengePrompt(final List<List<String>> challengePrompt) {
        this.challengePrompt = challengePrompt;
    }

    /**
     * @return the challengeResponseValidation
     */
    public boolean isChallengeResponseValidation() {
        return challengeResponseValidation;
    }

    /**
     * @param challengeResponseValidation
     *            the challengeResponseValidation to set
     */
    public void setChallengeResponseValidation(final boolean challengeResponseValidation) {
        this.challengeResponseValidation = challengeResponseValidation;
    }

    /**
     * @return the challengeResponsePolicy
     */
    public List<String> getChallengeResponsePolicy() {
        return challengeResponsePolicy;
    }

    /**
     * @param challengeResponsePolicy
     *            the challengeResponsePolicy to set
     */
    public void setChallengeResponsePolicy(final List<String> challengeResponsePolicy) {
        this.challengeResponsePolicy = challengeResponsePolicy;
    }

    /**
     * @return the challengeCipherSpec
     */
    public List<String> getChallengeCipherSpec() {
        return challengeCipherSpec;
    }

    /**
     * @param challengeCipherSpec
     *            the challengeCipherSpec to set
     */
    public void setChallengeCipherSpec(final List<String> challengeCipherSpec) {
        this.challengeCipherSpec = challengeCipherSpec;
    }

    /**
     * @return the challengeCipherSalt
     */
    public String getChallengeCipherSalt() {
        return challengeCipherSalt;
    }

    /**
     * @param challengeCipherSalt
     *            the challengeCipherSalt to set
     */
    public void setChallengeCipherSalt(final String challengeCipherSalt) {
        this.challengeCipherSalt = challengeCipherSalt;
    }

    /**
     * @return the maxAttemptsCount
     */
    public int getMaxAttemptsCount() {
        return maxAttemptsCount;
    }

    /**
     * @param maxAttemptsCount
     *            the maxAttemptsCount to set
     */
    public void setMaxAttemptsCount(final int maxAttemptsCount) {
        this.maxAttemptsCount = maxAttemptsCount;
    }

    /**
     * @return the subChallengeCount
     */
    public int getSubChallengeCount() {
        return subChallengeCount;
    }

    /**
     * @param subChallengeCount
     *            the subChallengeCount to set
     */
    public void setSubChallengeCount(final int subChallengeCount) {
        this.subChallengeCount = subChallengeCount;
    }

    /**
     * @return the challengesPerBatch
     */
    public int getChallengesPerBatch() {
        return challengesPerBatch;
    }

    /**
     * @param challengesPerBatch
     *            the challengesPerBatch to set
     */
    public void setChallengesPerBatch(final int challengesPerBatch) {
        this.challengesPerBatch = challengesPerBatch;
    }

    public ChallengeProperty getChallengesProperty() {
        return challengesProperty;
    }

    public void setChallengesProperties(final ChallengeProperty challengesProperty) {
        this.challengesProperty = challengesProperty;
    }

    public String getAuthenticatedWith() {
        return authenticatedWith;
    }

    public void setAuthenticatedWith(final String authenticatedWith) {
        this.authenticatedWith = authenticatedWith;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("Challenge [challengeName=");
        builder.append(challengeName);
        builder.append(", challengeIndex=");
        builder.append(challengeIndex);
        builder.append(", challengeInfo=");
        builder.append(challengeInfo);
        builder.append(", numberOfAttemptsLeft=");
        builder.append(numberOfAttemptsLeft);
        builder.append(", maxAttemptsCount=");
        builder.append(maxAttemptsCount);
        builder.append(", challengeResponse=");
        builder.append(challengeResponse);
        builder.append(", ChallengeType=");
        builder.append(ChallengeType);
        builder.append(", challengePrompt=");
        builder.append(challengePrompt);
        builder.append(", challengeResponseValidation=");
        builder.append(challengeResponseValidation);
        builder.append(", challengeResponsePolicy=");
        builder.append(challengeResponsePolicy);
        builder.append(", challengeCipherSpec=");
        builder.append(challengeCipherSpec);
        builder.append(", challengeCipherSalt=");
        builder.append(challengeCipherSalt);
        builder.append(", subChallengeCount=");
        builder.append(subChallengeCount);
        builder.append(challengesPerBatch);
        builder.append(", authenticatedWith");
        builder.append(authenticatedWith);
        builder.append("]");
        return builder.toString();
    }

    /**
     * Create Bson Document document from the provided Challenge object
     * 
     * @param Challenge
     *            Challenge to be converted to a Bson Document
     * @return A Bson document
     */
    public static Document getBsonDocument(final Challenge challenge) {

        final Document challengeDoc = new Document();

        if (null == challenge) {
            return null;
        }

        if (challenge.getChallengeName() != null) {
            challengeDoc.append(CHALLENGE_NAME_STR, challenge.getChallengeName());
        }

        if (challenge.getChallengeInfo() != null) {
            challengeDoc.append(CHALLENGE_INFO_STR, ChallengeInfo.getBsonDocumentList(challenge.getChallengeInfo()));
        }

        if (challenge.getChallengeResponse() != null) {
            challengeDoc.append(CHALLENGE_RESPONSE_STR,
                    ChallengeResponse.getBsonDocumentList(challenge.getChallengeResponse()));
        }

        if (challenge.getChallengePrompt() != null) {
            challengeDoc.append(CHALLENGE_PROMPT_STR, challenge.getChallengePrompt());
        }

        if (challenge.getChallengeResponsePolicy() != null) {
            challengeDoc.append(CHALLENGE_RESPONSE_POLICY_STR, challenge.getChallengeResponsePolicy());
        }

        if (challenge.getChallengeCipherSpec() != null) {
            challengeDoc.append(CHALLENGE_CIPHER_SPEC_STR, challenge.getChallengeCipherSpec());
        }
        if (challenge.getChallengeCipherSalt() != null) {
            challengeDoc.append(CHALLENGE_CIPHER_SALT_STR, challenge.getChallengeCipherSalt());
        }

        if (challenge.getChallengesProperty() != null) {
            challengeDoc.append(CHALLENGES_PROPERTY_STR,
                    ChallengeProperty.getBsonDocument(challenge.getChallengesProperty()));
        }
        /*
         * if (challenge.getIdvAuditingInfo() != null) {
         * challengeDoc.append(IDV_AUDIT_INFO,
         * IDVAuditingTemplate.getBsonDocumentFromIDVAuditingTemplateObject(
         * challenge.getIdvAuditingInfo())); }
         */

        challengeDoc.append(CHALLENGE_INDEX_STR, challenge.getChallengeIndex());
        challengeDoc.append(ATTEMPTS_LEFT_STR, challenge.getNumberOfAttemptsLeft());
        challengeDoc.append(MAX_ATTEMPTS_COUNT_STR, challenge.getMaxAttemptsCount());
        challengeDoc.append(CHALLENGE_TYPE_STR, challenge.getChallengeType());
        challengeDoc.append(CHALLENGE_RESPONSE_VALIDATION_STR, challenge.isChallengeResponseValidation());
        challengeDoc.append(SUB_CHALLENGE_COUNT_STR, challenge.getSubChallengeCount());
        challengeDoc.append(CHALLENGES_PER_BATCH_STR, challenge.getChallengesPerBatch());

        return challengeDoc;
    }

    /**
     * * @param challenges
     * 
     * @return
     */
    public static List<Document> getBsonDocumentFromList(final List<Challenge> challenges) {

        if (null == challenges) {
            return null;
        }

        final List<Document> listOfChallengeDoc = new ArrayList<Document>();

        for (final Challenge challenge : challenges) {
            listOfChallengeDoc.add(getBsonDocument(challenge));
        }
        return listOfChallengeDoc;
    }

}
