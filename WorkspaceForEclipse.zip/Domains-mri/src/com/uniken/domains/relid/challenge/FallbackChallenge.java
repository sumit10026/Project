/**
 * 
 */
package com.uniken.domains.relid.challenge;

/**
 * Need to define implementation
 * 
 * @author Kushal.Jaiswal
 */
public class FallbackChallenge {

}
