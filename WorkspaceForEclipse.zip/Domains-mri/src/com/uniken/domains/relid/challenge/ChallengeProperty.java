/**
 * 
 */
package com.uniken.domains.relid.challenge;

import java.util.List;

import org.bson.Document;

import com.google.gson.annotations.SerializedName;

/**
 * @author Kushal.Jaiswal
 */
// TODO: Challenge fallback use case can be achieve through adding fallback
// property here as well.
public class ChallengeProperty {

    /**
     * Property is to check is challenge is registered the system of with the
     * user or not. If the value is true then check the respective challenge is
     * registered with user or not.
     */
    @SerializedName(value = "check_applicability")
    private boolean checkApplicability;

    /**
     * Property is use to instruct the system that, if this challenge the
     * property is set to true then skip the subsequent challenges that are in
     * the pipeline.
     */
    @SerializedName(value = "skip_subsequent_chlngs")
    private boolean skipSubsequentChlngs;

    // TODO: Need to define implementation specification for fallback.
    private List<FallbackChallenge> fallbackChallenge;

    /**
     * @return
     */
    public boolean isApplicabilityCheckRequiredForGivenChlng() {
        return checkApplicability;
    }

    /**
     * @param checkApplicability
     */
    public void setVerifyChlngRegistrationFlag(final boolean checkApplicability) {
        this.checkApplicability = checkApplicability;
    }

    /**
     * Flag to instruct the system that, if this challenge the property is set
     * to true then skip the subsequent challenges that are in the pipeline.
     * 
     * @return true or false
     */
    public boolean skipSubsequentChlngs() {
        return skipSubsequentChlngs;
    }

    public void setSkipSubsequentChlngs(final boolean skipSubsequentChlngs) {
        this.skipSubsequentChlngs = skipSubsequentChlngs;
    }

    /**
     * @param challengeProperty
     * @return
     */
    public static Document getBsonDocument(final ChallengeProperty challengeProperty) {

        if (null == challengeProperty) {
            return null;
        }

        final Document logDoc = new Document();

        logDoc.append("check_applicability", challengeProperty.isApplicabilityCheckRequiredForGivenChlng());
        logDoc.append("skip_subsequent_chlngs", challengeProperty.skipSubsequentChlngs());

        return logDoc;
    }

}
