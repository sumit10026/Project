package com.uniken.domains.relid.user;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.google.gson.annotations.SerializedName;

/**
 * @author Uniken INC
 */
public class SecQueAns {

    public final static String QUE = "que";
    public final static String ANS = "ans";

    @SerializedName(QUE)
    private String question;

    @SerializedName(ANS)
    private String answer;

    /**
     * @return the question
     */
    public String getQuestion() {
        return question;
    }

    /**
     * @param question
     *            the question to set
     */
    public void setQuestion(final String question) {
        this.question = question;
    }

    /**
     * @return the answer
     */
    public String getAnswer() {
        return answer;
    }

    /**
     * @param answer
     *            the answer to set
     */
    public void setAnswer(final String answer) {
        this.answer = answer;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "SecQueAns [question=" + question + ", answer=" + answer + "]";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((answer == null) ? 0 : answer.hashCode());
        result = prime * result + ((question == null) ? 0 : question.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final SecQueAns other = (SecQueAns) obj;
        if (answer == null) {
            if (other.answer != null)
                return false;
        } else if (!answer.equals(other.answer))
            return false;
        if (question == null) {
            if (other.question != null)
                return false;
        } else if (!question.equals(other.question))
            return false;
        return true;
    }

    /**
     * Create Bson Document document from the provided list of Device object
     * 
     * @param secQueAns
     *            list of Device object
     * @return
     */
    public static List<Document> getBsonDocuments(final SecQueAns... secQueAnswer) {

        final List<Document> documents = new ArrayList<Document>();

        for (final SecQueAns secQueAns : secQueAnswer) {
            documents.add(getBsonDocument(secQueAns));
        }

        return documents;

    }

    /**
     * Create Bson Document document from the provided User object
     * 
     * @param User
     *            the User to be converted to a Bson Document
     * @return A Bson document
     */
    public static Document getBsonDocument(final SecQueAns secQa) {
        if (null == secQa) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != secQa.getQuestion()) {
            logsDoc.append(QUE, secQa.getQuestion());
        }

        if (null != secQa.getAnswer()) {
            logsDoc.append(ANS, secQa.getAnswer());
        }

        return logsDoc;
    }

}
