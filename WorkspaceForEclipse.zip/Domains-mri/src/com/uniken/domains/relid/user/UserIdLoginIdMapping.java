package com.uniken.domains.relid.user;

import java.util.Date;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.relid.LogDomain;

public class UserIdLoginIdMapping extends LogDomain {

    public static final String ID_STR = "_id";
    public static final String USER_UUID_STR = "user_uuid";
    public static final String USER_ID_STR = "user_id";
    public static final String LOGIN_ID_STR = "login_id";
    public static final String CREATE_TS_STR = "created_ts";
    public static final String UPDATED_TS_STR = "updated_ts";
    public static final String IS_DEFAULT_STR = "is_default";
    public static final String STATUS_STR = "status";

    @SerializedName(value = ID_STR)
    private ObjectId id;

    @Indexed(unique = true)
    @SerializedName(USER_UUID_STR)
    @Field(USER_UUID_STR)
    private String userUuid;

    @SerializedName(value = USER_ID_STR)
    @Field(USER_ID_STR)
    private String userId;

    @Indexed(unique = true)
    @SerializedName(value = LOGIN_ID_STR)
    @Field(LOGIN_ID_STR)
    private String loginId;

    @SerializedName(value = CREATE_TS_STR)
    @Field(CREATE_TS_STR)
    private Date createdTs;

    @SerializedName(value = UPDATED_TS_STR)
    @Field(UPDATED_TS_STR)
    private Date updatedTs;

    @SerializedName(IS_DEFAULT_STR)
    @Field(IS_DEFAULT_STR)
    private Boolean isDefault;

    @SerializedName(value = STATUS_STR)
    @Field(STATUS_STR)
    private String status;

    /**
     */
    public UserIdLoginIdMapping() {
        super();
    }

    /**
     * @param userUuid
     * @param userId
     * @param loginId
     * @param createdTs
     * @param updatedTs
     * @param status
     * @param isDefault
     */
    public UserIdLoginIdMapping(final String userUuid, final String userId, final String loginId, final Date createdTs,
            final Date updatedTs, final Boolean isDefault, final String status) {
        super();
        this.userUuid = userUuid;
        this.userId = userId;
        this.loginId = loginId;
        this.createdTs = createdTs;
        this.updatedTs = updatedTs;
        this.isDefault = isDefault;
        this.status = status;
    }

    /**
     * @return the id
     */
    public ObjectId getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final ObjectId id) {
        this.id = id;
    }

    /**
     * @return the userUuid
     */
    public String getUserUuid() {
        return userUuid;
    }

    /**
     * @param userUuid
     *            the userUuid to set
     */
    public void setUserUuid(final String userUuid) {
        this.userUuid = userUuid;
    }

    /**
     * @return the userId
     */
    @Override
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    @Override
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @return the loginId
     */
    public String getLoginId() {
        return loginId;
    }

    /**
     * @param loginId
     *            the loginId to set
     */
    public void setLoginId(final String loginId) {
        this.loginId = loginId;
    }

    /**
     * @return the createdTs
     */
    public Date getCreatedTs() {
        return createdTs;
    }

    /**
     * @param createdTs
     *            the createdTs to set
     */
    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }

    /**
     * @return the updatedTs
     */
    public Date getUpdatedTs() {
        return updatedTs;
    }

    /**
     * @param updatedTs
     *            the updatedTs to set
     */
    public void setUpdatedTs(final Date updatedTs) {
        this.updatedTs = updatedTs;
    }

    public Boolean isDefault() {
        return isDefault;
    }

    public void setDefault(final Boolean isDefault) {
        this.isDefault = isDefault;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(final String status) {
        this.status = status;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("User [id=");
        builder.append(id);
        builder.append(", userUuid=");
        builder.append(userUuid);
        builder.append(", userId=");
        builder.append(userId);
        builder.append(", loginId=");
        builder.append(loginId);
        builder.append(", createdTs=");
        builder.append(createdTs);
        builder.append(", updatedTs=");
        builder.append(updatedTs);
        builder.append(", isDefault=");
        builder.append(isDefault);
        builder.append("]");
        return builder.toString();
    }

    /**
     * Create Bson Document document from the provided User object
     * 
     * @param User
     *            the User to be converted to a Bson Document
     * @return A Bson document
     */
    public static Document getBsonDocument(final UserIdLoginIdMapping user) {
        if (null == user) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != user.getId()) {
            logsDoc.append(ID_STR, user.getId());
        }

        if (null != user.getUserUuid()) {
            logsDoc.append(USER_UUID_STR, user.getUserUuid());
        }

        if (null != user.getUserId()) {
            logsDoc.append(USER_ID_STR, user.getUserId());
        }

        if (null != user.getLoginId()) {
            logsDoc.append(LOGIN_ID_STR, user.getLoginId());
        }

        if (null != user.getCreatedTs()) {
            logsDoc.append(CREATE_TS_STR, user.getCreatedTs());
        }

        if (null != user.getUpdatedTs()) {
            logsDoc.append(UPDATED_TS_STR, user.getUpdatedTs());
        }

        logsDoc.append(IS_DEFAULT_STR, user.isDefault);

        return logsDoc;
    }

}
