package com.uniken.domains.relid.user;

import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * @author Uniken INC
 */
public class UserOTP {

    public static final String ID_STR = "_id";
    public final static String USER_UUID_STR = "user_uuid";
    public final static String USER_ID = "user_id";
    public final static String OTP = "otp";
    public final static String CREATED_TS_STR = "created_ts";
    public final static String UPDATED_TS_STR = "updated_ts";

    @SerializedName(value = ID_STR)
    private ObjectId id;

    @SerializedName(USER_UUID_STR)
    @Field(USER_UUID_STR)
    private String userUuid;

    @SerializedName(USER_ID)
    @Field(USER_ID)
    private String userId;

    @SerializedName(OTP)
    @Field(OTP)
    private List<OTP> otp;

    @SerializedName(CREATED_TS_STR)
    @Field(CREATED_TS_STR)
    private Date createdTs;

    @SerializedName(UPDATED_TS_STR)
    @Field(UPDATED_TS_STR)
    private Date updatedTs;

    /**
     * @return the userUuid
     */
    public String getUserUuid() {
        return userUuid;
    }

    /**
     * @param userUuid
     *            the userUuid to set
     */
    public void setUserUuid(final String userUuid) {
        this.userUuid = userUuid;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @return the otp
     */
    public List<OTP> getOtp() {
        return otp;
    }

    /**
     * @param otp
     *            the otp to set
     */
    public void setOtp(final List<OTP> otp) {
        this.otp = otp;
    }

    /**
     * @return the createdTs
     */
    public Date getCreatedTs() {
        return createdTs;
    }

    /**
     * @param createdTs
     *            the createdTs to set
     */
    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }

    /**
     * @return the updatedTs
     */
    public Date getUpdatedTs() {
        return updatedTs;
    }

    /**
     * @param updatedTs
     *            the updatedTs to set
     */
    public void setUpdatedTs(final Date updatedTs) {
        this.updatedTs = updatedTs;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "UserOTP [userUuid=" + userUuid + ", userId=" + userId + ", otp=" + otp + ", createdTs=" + createdTs
                + ", updatedTs=" + updatedTs + "]";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((otp == null) ? 0 : otp.hashCode());
        result = prime * result + ((userId == null) ? 0 : userId.hashCode());
        result = prime * result + ((userUuid == null) ? 0 : userUuid.hashCode());
        result = prime * result + ((createdTs == null) ? 0 : createdTs.hashCode());
        result = prime * result + ((updatedTs == null) ? 0 : updatedTs.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final UserOTP other = (UserOTP) obj;
        if (otp == null) {
            if (other.otp != null)
                return false;
        } else if (!otp.equals(other.otp))
            return false;
        if (userId == null) {
            if (other.userId != null)
                return false;
        } else if (!userId.equals(other.userId))
            return false;
        if (userUuid == null) {
            if (other.userUuid != null)
                return false;
        } else if (!userUuid.equals(other.userUuid))
            return false;
        if (createdTs == null) {
            if (other.createdTs != null)
                return false;
        } else if (!createdTs.equals(other.createdTs))
            return false;
        if (updatedTs == null) {
            if (other.updatedTs != null)
                return false;
        } else if (!updatedTs.equals(other.updatedTs))
            return false;
        return true;
    }

    /**
     * Create Bson Document document from the provided User object
     * 
     * @param User
     *            the User to be converted to a Bson Document
     * @return A Bson document
     */
    public static Document getBsonDocument(final UserOTP userOTP) {
        if (null == userOTP) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != userOTP.getUserUuid()) {
            logsDoc.append(USER_UUID_STR, userOTP.getUserUuid());
        }

        if (null != userOTP.getUserId()) {
            logsDoc.append(USER_ID, userOTP.getUserId());
        }

        if (null != userOTP.getOtp()) {
            final SecQueAns[] deviceArray = new SecQueAns[userOTP.getOtp().size()];
            logsDoc.append(OTP, SecQueAns.getBsonDocuments(userOTP.getOtp().toArray(deviceArray)));
            logsDoc.append(USER_ID, userOTP.getUserId());
        }

        if (null != userOTP.getCreatedTs()) {
            logsDoc.append(CREATED_TS_STR, userOTP.getCreatedTs());
        }

        if (null != userOTP.getUpdatedTs()) {
            logsDoc.append(UPDATED_TS_STR, userOTP.getUpdatedTs());
        }

        return logsDoc;
    }

}
