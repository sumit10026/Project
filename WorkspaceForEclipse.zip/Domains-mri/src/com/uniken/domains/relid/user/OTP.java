package com.uniken.domains.relid.user;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;

import com.uniken.domains.enums.OTPType;

/**
 * @author Uniken Inc.
 */
public class OTP {

    @Id
    private ObjectId id;

    public static final String USER_ID = "user_id";
    public static final String USER_UUID = "user_uuid";
    public static final String APP_UUID = "app_uuid";
    public static final String DEV_UUID = "dev_uuid";
    public static final String OTP_ID = "otp_id";
    public static final String OTP_VALUE = "otp_value";
    public static final String CREATED_TS = "created_ts";
    public static final String EXPIRY_TS = "expiry_ts";
    public static final String OTP_STATUS = "otp_status";
    public static final String ARCHIVED_TS = "archived_ts";
    public static final String OTP_TYPE_STR = "otp_type";

    private String user_id;

    private String user_uuid;

    private String app_uuid;

    private String dev_uuid;

    private String otp_id;

    private String otp_value;

    private Date created_ts;

    private Date expiry_ts;

    private String otp_status;

    private Date archived_ts;

    private OTPType otp_type;

    public OTP() {
    }

    public OTP(final String user_id, final String user_uuid, final String app_uuid, final String dev_uuid,
            final String otp_id, final String otp_value, final Date created_ts, final Date expiry_ts,
            final String otp_status, final OTPType otp_type) {

        this.user_id = user_id;
        this.user_uuid = user_uuid;
        this.app_uuid = app_uuid;
        this.dev_uuid = dev_uuid;
        this.otp_id = otp_id;
        this.otp_value = otp_value;
        this.created_ts = created_ts;
        this.expiry_ts = expiry_ts;
        this.otp_status = otp_status;
        this.otp_type = otp_type;
    }

    /**
     * @return the user_id
     */
    public String getUser_id() {
        return user_id;
    }

    /**
     * @param user_id
     *            the user_id to set
     */
    public void setUser_id(final String user_id) {
        this.user_id = user_id;
    }

    /**
     * @return the user_uuid
     */
    public String getUser_uuid() {
        return user_uuid;
    }

    /**
     * @param user_uuid
     *            the user_uuid to set
     */
    public void setUser_uuid(final String user_uuid) {
        this.user_uuid = user_uuid;
    }

    /**
     * @return the app_uuid
     */
    public String getApp_uuid() {
        return app_uuid;
    }

    /**
     * @param app_uuid
     *            the app_uuid to set
     */
    public void setApp_uuid(final String app_uuid) {
        this.app_uuid = app_uuid;
    }

    /**
     * @return the dev_uuid
     */
    public String getDev_uuid() {
        return dev_uuid;
    }

    /**
     * @param dev_uuid
     *            the dev_uuid to set
     */
    public void setDev_uuid(final String dev_uuid) {
        this.dev_uuid = dev_uuid;
    }

    /**
     * @return the otp_id
     */
    public String getOtp_id() {
        return otp_id;
    }

    /**
     * @param otp_id
     *            the otp_id to set
     */
    public void setOtp_id(final String otp_id) {
        this.otp_id = otp_id;
    }

    /**
     * @return the otp_value
     */
    public String getOtp_value() {
        return otp_value;
    }

    /**
     * @param otp_value
     *            the otp_value to set
     */
    public void setOtp_value(final String otp_value) {
        this.otp_value = otp_value;
    }

    /**
     * @return the created_ts
     */
    public Date getCreated_ts() {
        return created_ts;
    }

    /**
     * @param created_ts
     *            the created_ts to set
     */
    public void setCreated_ts(final Date created_ts) {
        this.created_ts = created_ts;
    }

    /**
     * @return the expiry_ts
     */
    public Date getExpiry_ts() {
        return expiry_ts;
    }

    /**
     * @param expiry_ts
     *            the expiry_ts to set
     */
    public void setExpiry_ts(final Date expiry_ts) {
        this.expiry_ts = expiry_ts;
    }

    /**
     * @return the otp_status
     */
    public String getOtp_status() {
        return otp_status;
    }

    /**
     * @param otp_status
     *            the otp_status to set
     */
    public void setOtp_status(final String otp_status) {
        this.otp_status = otp_status;
    }

    /**
     * @param retrives
     *            archived timestamp
     * @return
     */
    public Date getArchived_ts() {
        return archived_ts;
    }

    /**
     * @param set
     *            the archived timestamp
     * @param archived_ts
     */
    public void setArchived_ts(final Date archived_ts) {
        this.archived_ts = archived_ts;
    }

    public OTPType getOtp_type() {
        return otp_type;
    }

    public void setOtp_type(final OTPType otp_type) {
        this.otp_type = otp_type;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "OTP [user_id=" + user_id + ", user_uuid=" + user_uuid + ", app_uuid=" + app_uuid + ", dev_uuid="
                + dev_uuid + ", otp_id=" + otp_id + ", otp_value=" + otp_value + ", created_ts=" + created_ts
                + ", expiry_ts=" + expiry_ts + ", otp_status=" + otp_status + ", archived_ts=" + archived_ts
                + ", otp_type = " + otp_type.name() + "]";
    }

    /**
     * Create Bson Document document from the provided list of Device object
     * 
     * @param secQueAns
     *            list of Device object
     * @return
     */
    public static List<Document> getBsonDocuments(final OTP... OTPS) {

        final List<Document> documents = new ArrayList<Document>();

        for (final OTP otp : OTPS) {
            documents.add(getBsonDocument(otp));
        }

        return documents;

    }

    /**
     * Create Bson Document document from the provided User object
     * 
     * @param User
     *            the User to be converted to a Bson Document
     * @return A Bson document
     */
    public static Document getBsonDocument(final OTP otp) {
        if (null == otp) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != otp.getUser_id()) {
            logsDoc.append(USER_ID, otp.getUser_id());
        }

        if (null != otp.getUser_uuid()) {
            logsDoc.append(USER_UUID, otp.getUser_uuid());
        }

        if (null != otp.getApp_uuid()) {
            logsDoc.append(APP_UUID, otp.getApp_uuid());
        }

        if (null != otp.getDev_uuid()) {
            logsDoc.append(DEV_UUID, otp.getDev_uuid());
        }

        if (null != otp.getOtp_id()) {
            logsDoc.append(OTP_ID, otp.getOtp_id());
        }

        if (null != otp.getOtp_value()) {
            logsDoc.append(OTP_VALUE, otp.getOtp_value());
        }

        if (null != otp.getCreated_ts()) {
            logsDoc.append(CREATED_TS, otp.getCreated_ts());
        }

        if (null != otp.getExpiry_ts()) {
            logsDoc.append(EXPIRY_TS, otp.getExpiry_ts());
        }

        if (null != otp.getOtp_status()) {
            logsDoc.append(OTP_STATUS, otp.getOtp_status());
        }

        if (null != otp.getArchived_ts()) {
            logsDoc.append(ARCHIVED_TS, otp.getArchived_ts());
        }

        if (null != otp.getOtp_type()) {
            logsDoc.append(OTP_TYPE_STR, otp.getOtp_type().name());
        }

        return logsDoc;
    }

}
