package com.uniken.domains.relid.user;

import java.util.Date;

import com.google.gson.annotations.SerializedName;

/**
 * @author Uniken INC
 */
public class OTPArch {

    public final static String OTP_ID = "otpID";
    public final static String OTP_VALUE = "otpValue";
    public final static String OTP_STATUS = "otpStatus";
    public final static String CREATED_TS = "createdTS";
    public final static String EXPIRY_TS = "expiryTS";
    public final static String ARCH_TS = "archTs";

    @SerializedName(OTP_ID)
    private String otpId;

    @SerializedName(OTP_VALUE)
    private String otpValue;

    @SerializedName(OTP_STATUS)
    private String otpStatus;

    @SerializedName(CREATED_TS)
    private Date createdTs;

    @SerializedName(EXPIRY_TS)
    private Date expiryTs;

    @SerializedName(ARCH_TS)
    private Date archTs;

    /**
     * @return the otpId
     */
    public String getOtpId() {
        return otpId;
    }

    /**
     * @param otpId
     *            the otpId to set
     */
    public void setOtpId(final String otpId) {
        this.otpId = otpId;
    }

    /**
     * @return the otpValue
     */
    public String getOtpValue() {
        return otpValue;
    }

    /**
     * @param otpValue
     *            the otpValue to set
     */
    public void setOtpValue(final String otpValue) {
        this.otpValue = otpValue;
    }

    /**
     * @return the otpStatus
     */
    public String getOtpStatus() {
        return otpStatus;
    }

    /**
     * @param otpStatus
     *            the otpStatus to set
     */
    public void setOtpStatus(final String otpStatus) {
        this.otpStatus = otpStatus;
    }

    /**
     * @return the createdTs
     */
    public Date getCreatedTs() {
        return createdTs;
    }

    /**
     * @param createdTs
     *            the createdTs to set
     */
    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }

    /**
     * @return the expiryTs
     */
    public Date getExpiryTs() {
        return expiryTs;
    }

    /**
     * @param expiryTs
     *            the expiryTs to set
     */
    public void setExpiryTs(final Date expiryTs) {
        this.expiryTs = expiryTs;
    }

    /**
     * @return the archTs
     */
    public Date getArchTs() {
        return archTs;
    }

    /**
     * @param archTs
     *            the archTs to set
     */
    public void setArchTs(final Date archTs) {
        this.archTs = archTs;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "OTPArch [otpId=" + otpId + ", otpValue=" + otpValue + ", otpStatus=" + otpStatus + ", createdTs="
                + createdTs + ", expiryTs=" + expiryTs + ", archTs=" + archTs + "]";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((archTs == null) ? 0 : archTs.hashCode());
        result = prime * result + ((createdTs == null) ? 0 : createdTs.hashCode());
        result = prime * result + ((expiryTs == null) ? 0 : expiryTs.hashCode());
        result = prime * result + ((otpId == null) ? 0 : otpId.hashCode());
        result = prime * result + ((otpStatus == null) ? 0 : otpStatus.hashCode());
        result = prime * result + ((otpValue == null) ? 0 : otpValue.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final OTPArch other = (OTPArch) obj;
        if (archTs == null) {
            if (other.archTs != null)
                return false;
        } else if (!archTs.equals(other.archTs))
            return false;
        if (createdTs == null) {
            if (other.createdTs != null)
                return false;
        } else if (!createdTs.equals(other.createdTs))
            return false;
        if (expiryTs == null) {
            if (other.expiryTs != null)
                return false;
        } else if (!expiryTs.equals(other.expiryTs))
            return false;
        if (otpId == null) {
            if (other.otpId != null)
                return false;
        } else if (!otpId.equals(other.otpId))
            return false;
        if (otpStatus == null) {
            if (other.otpStatus != null)
                return false;
        } else if (!otpStatus.equals(other.otpStatus))
            return false;
        if (otpValue == null) {
            if (other.otpValue != null)
                return false;
        } else if (!otpValue.equals(other.otpValue))
            return false;
        return true;
    }

}
