package com.uniken.domains.relid.user;

import java.util.HashMap;
import java.util.Map;

/**
 * This Enum holds all the state for the Session.
 */
public enum State {

    APP_DEV_PRIMARY_STATE("appDevPrimaryState", "appDevPrimaryState"),
    INACTIVE_USER_STATE("inactiveUserState", "inactiveUserState"),
    TO_BE_ACTIVATED_USER_STATE("toBeActivatedUserState", "toBeActivatedUserState"),
    ACTIVE_USER_BOUND_STATE("activeUserBoundState", "activeUserBoundState"),
    ACTIVE_USER_NOT_BOUND_STATE("activeUserNotBoundState", "activeUserNotBoundState"),
    TO_BE_ACTIVATED_USER_DEVICE_STATE("toBeActivatedUserDeviceState", "toBeActivatedUserDeviceState"),
    USER_ACTIVE_STATE("userActiveState", "userActiveState"),
    ERROR_STATE("errorState", "errorState"),
    ACTIVE_USER_FORGET_CREDENTIALS_STATE("activeUserForgetCredentialsState", "activeUserForgetCredentialsState"),
    ACTIVE_USER_CREDS_TO_BE_UPDATED_STATE("activeUserCredsToBeUpdatedState", "activeUserCredsToBeUpdatedState"),
    ACTIVE_USER_NEW_DEVICE_REGISTRATION_STATE("ActiveUserNewDeviceRegistrationState",
            "ActiveUserNewDeviceRegistrationState"),
    ACTIVE_USER_BOUND_USER_PASS_STATE("ActiveUserBoundUserPassState", "ActiveUserBoundUserPassState");

    private static final Map<String, State> stateMap = new HashMap<String, State>();

    static {
        for (final State state : State.values()) {
            stateMap.put(state.name, state);
        }
    }

    private final String name;
    private final String beanName;

    /**
     * Creates and returns a new instance of this enum initialized with given
     * parameters.
     * 
     * @param name
     *            the name
     * @param beanName
     *            the bean name
     */
    State(final String name, final String beanName) {
        this.name = name;
        this.beanName = beanName;
    }

    /**
     * Gets the name of this enum.
     * 
     * @return the name
     */
    public String getName() {
        return this.name;
    }

    /**
     * Gets the bean name of this enum.
     * 
     * @return the bean name
     */
    public String getBeanName() {
        return this.beanName;
    }

    /**
     * Gets the state with given name.
     * 
     * @param name
     *            the name
     * @return the state if any, null otherwise
     */
    public static State getState(final String name) {
        return stateMap.get(name);
    }
}
