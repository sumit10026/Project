package com.uniken.domains.relid.user;

import com.uniken.domains.relid.device.WebDevMaster;

public class WebUserBrowserDetailsDTO {

    private UserBrowser userBrowser;

    private WebDevMaster webDevMaster;

    public WebUserBrowserDetailsDTO(final UserBrowser userBrowser, final WebDevMaster webDevMaster) {
        this.userBrowser = userBrowser;
        this.webDevMaster = webDevMaster;
    }

    public void setUserBrowser(final UserBrowser userBrowser) {
        this.userBrowser = userBrowser;
    }

    public UserBrowser getUserBrowser() {
        return userBrowser;
    }

    public void setWebDevMaster(final WebDevMaster webDevMaster) {
        this.webDevMaster = webDevMaster;
    }

    public WebDevMaster getWebDevMaster() {
        return webDevMaster;
    }

}
