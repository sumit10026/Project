/**
 * 
 */
package com.uniken.domains.relid.user.vo;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.enums.RelIdType;
import com.uniken.domains.relid.user.RelId;

/**
 * The {@code RelIdAuthInfo} POJO is used for storing user's information.
 * 
 * @author Uniken Inc.
 */
public class RelIdAuthInfoVO {

    public static final String RELID_AUTH_INFO_STR = "relid_auth_info";

    public static final String ID_STR = "_id";
    public static final String REL_IDS_STR = "relids";
    public static final String ARCHIVE_REL_IDS_STR = "archive_relids";
    public static final String REL_ID_TYPE_STR = "rel_id_type";
    public static final String USER_UUID_STR = "user_uuid";
    public static final String PRIVACY_KEY_STR = "privacy_key";
    public static final String USER_ID_STR = "user_id";
    public static final String PRIMARY_GROUP_UUID_STR = "primary_group_uuid";
    public static final String SECONDARY_GROUP_UUIDS_STR = "secondary_group_uuids";
    public static final String PRIMARY_GROUP_NAME_STR = "primary_group_name";
    public static final String SECONDARY_GROUP_NAMES_STR = "secondary_group_names";

    @SerializedName(value = ID_STR)
    private ObjectId id;

    @SerializedName(REL_IDS_STR)
    @Field(REL_IDS_STR)
    private List<RelId> relIds;

    @SerializedName(value = ARCHIVE_REL_IDS_STR)
    @Field(ARCHIVE_REL_IDS_STR)
    private List<RelId> archiveRelIds;

    @SerializedName(REL_ID_TYPE_STR)
    @Field(REL_ID_TYPE_STR)
    private RelIdType relIdType;

    @Indexed(unique = true)
    @SerializedName(USER_UUID_STR)
    @Field(USER_UUID_STR)
    private String userUuid;

    @SerializedName(PRIVACY_KEY_STR)
    @Field(PRIVACY_KEY_STR)
    private String privacyKey;

    @Indexed(unique = true)
    @SerializedName(USER_ID_STR)
    @Field(USER_ID_STR)
    private String userId;

    @SerializedName(PRIMARY_GROUP_UUID_STR)
    @Field(PRIMARY_GROUP_UUID_STR)
    private String primaryGroupUuid;

    @SerializedName(SECONDARY_GROUP_UUIDS_STR)
    @Field(SECONDARY_GROUP_UUIDS_STR)
    private List<String> secondaryGroupUuids;

    @SerializedName(PRIMARY_GROUP_NAME_STR)
    @Field(PRIMARY_GROUP_NAME_STR)
    private String primaryGroupName;

    @SerializedName(SECONDARY_GROUP_NAMES_STR)
    @Field(SECONDARY_GROUP_NAMES_STR)
    private List<String> secondaryGroupNames;

    public RelIdAuthInfoVO() {
        super();
        this.relIds = new ArrayList<RelId>();
    }

    /**
     * @param relIds
     * @param relIdType
     * @param userId
     * @param groupUuid
     */
    public RelIdAuthInfoVO(final List<RelId> relIds, final RelIdType relIdType, final String userId) {
        super();
        this.relIds = relIds;
        this.relIdType = relIdType;
        this.userId = userId;
    }

    /**
     * @return the id
     */
    public ObjectId getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final ObjectId id) {
        this.id = id;
    }

    /**
     * Gets list of REL-ID
     * 
     * @return the relIds
     */
    public List<RelId> getRelIds() {
        return relIds;
    }

    /**
     * Sets REL-ID
     * 
     * @param relIds
     *            the relIds to set
     */
    public void setRelIds(final List<RelId> relIds) {
        this.relIds = relIds;
    }

    /**
     * Gets type of REL-ID.
     * 
     * @return the relIdType
     */
    public RelIdType getRelIdType() {
        return relIdType;
    }

    public List<RelId> getArchiveRelIds() {
        return archiveRelIds;
    }

    public void setArchiveRelIds(final List<RelId> archiveRelIds) {
        this.archiveRelIds = archiveRelIds;
    }

    /**
     * Sets type of REL-ID.
     * 
     * @param relIdType
     *            the relIdType to set
     */
    public void setRelIdType(final RelIdType relIdType) {
        this.relIdType = relIdType;
    }

    /**
     * @return the userUuid
     */
    public String getUserUuid() {
        return userUuid;
    }

    /**
     * @param userUuid
     *            the userUuid to set
     */
    public void setUserUuid(final String userUuid) {
        this.userUuid = userUuid;
    }

    /**
     * Gets privacy key of REL-ID.
     * 
     * @return the privacyKey
     */
    public String getPrivacyKey() {
        return privacyKey;
    }

    /**
     * Sets privacy key of REL-ID.
     * 
     * @param privacyKey
     *            the privacyKey to set
     */
    public void setPrivacyKey(final String privacyKey) {
        this.privacyKey = privacyKey;
    }

    /**
     * Gets user id of REL-ID.
     * 
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * Sets user id of REL-ID.
     * 
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * Gets list primary group uuid of REL-ID.
     * 
     * @return the primaryGroupUuid
     */
    public String getPrimaryGroupUuid() {
        return primaryGroupUuid;
    }

    /**
     * Sets list of primary group uuid of REL-ID.
     * 
     * @param primaryGroupUuid
     *            the primaryGroupUuid to set
     */
    public void setPrimaryGroupUuid(final String primaryGroupUuid) {
        this.primaryGroupUuid = primaryGroupUuid;
    }

    /**
     * Gets list secondary group uuid of REL-ID.
     * 
     * @return the secondaryGroupUuids
     */
    public List<String> getSecondaryGroupUuids() {
        return secondaryGroupUuids;
    }

    /**
     * Sets list of secondary group uuid of REL-ID.
     * 
     * @param secondaryGroupUuids
     *            the secondaryGroupUuids to set
     */
    public void setSecondaryGroupUuids(final List<String> secondaryGroupUuids) {
        this.secondaryGroupUuids = secondaryGroupUuids;
    }

    /**
     * Gets REL-ID form relIds.
     * 
     * @param condition
     * @return
     */
    public RelId getRelIdByCondition(final Predicate<? super RelId> condition) {
        return relIds.stream().filter(condition).findFirst().get();
    }

    /**
     * @return the primaryGroupName
     */
    public String getPrimaryGroupName() {
        return primaryGroupName;
    }

    /**
     * @param primaryGroupName
     *            the primaryGroupName to set
     */
    public void setPrimaryGroupName(final String primaryGroupName) {
        this.primaryGroupName = primaryGroupName;
    }

    /**
     * @return the secondaryGroupNames
     */
    public List<String> getSecondaryGroupNames() {
        return secondaryGroupNames;
    }

    /**
     * @param secondaryGroupNames
     *            the secondaryGroupNames to set
     */
    public void setSecondaryGroupNames(final List<String> secondaryGroupNames) {
        this.secondaryGroupNames = secondaryGroupNames;
    }

    /**
     * Gets the BSON document form of given {@link RelIdAuthInfoVO} POJO.
     * 
     * @param relIdAuthInfo
     *            the rel-id
     * @return the document
     */
    public static Document getDocument(final RelIdAuthInfoVO relIdAuthInfo) {

        if (null == relIdAuthInfo) {
            return null;
        }

        final Document document = new Document();

        if (null != relIdAuthInfo.getId()) {
            document.append(ID_STR, relIdAuthInfo.getId());
        }

        if (null != relIdAuthInfo.getRelIds()) {
            document.append(REL_IDS_STR, relIdAuthInfo.getRelIds());
        }

        if (null != relIdAuthInfo.getArchiveRelIds()) {
            document.append(ARCHIVE_REL_IDS_STR, relIdAuthInfo.getArchiveRelIds());
        }

        if (null != relIdAuthInfo.getRelIdType()) {
            document.append(REL_ID_TYPE_STR, relIdAuthInfo.getRelIdType());
        }

        if (null != relIdAuthInfo.getUserId()) {
            document.append(USER_ID_STR, relIdAuthInfo.getUserId());
        }

        if (null != relIdAuthInfo.getUserUuid()) {
            document.append(USER_UUID_STR, relIdAuthInfo.getUserUuid());
        }

        if (null != relIdAuthInfo.getPrivacyKey()) {
            document.append(PRIVACY_KEY_STR, relIdAuthInfo.getPrivacyKey());
        }

        if (null != relIdAuthInfo.getPrimaryGroupUuid()) {
            document.append(PRIMARY_GROUP_UUID_STR, relIdAuthInfo.getPrimaryGroupUuid());
        }

        if (null != relIdAuthInfo.getSecondaryGroupUuids()) {
            document.append(SECONDARY_GROUP_UUIDS_STR, relIdAuthInfo.getSecondaryGroupUuids());
        }

        if (null != relIdAuthInfo.getPrimaryGroupName()) {
            document.append(PRIMARY_GROUP_NAME_STR, relIdAuthInfo.getPrimaryGroupName());
        }

        if (null != relIdAuthInfo.getSecondaryGroupNames()) {
            document.append(SECONDARY_GROUP_NAMES_STR, relIdAuthInfo.getSecondaryGroupNames());
        }

        return document;
    }

}
