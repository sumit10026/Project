package com.uniken.domains.relid.user;

import com.google.gson.annotations.SerializedName;

public class ParentParam {

    @SerializedName(value = "name")
    private String name;

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

}
