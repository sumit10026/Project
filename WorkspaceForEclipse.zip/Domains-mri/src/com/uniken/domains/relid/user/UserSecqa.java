package com.uniken.domains.relid.user;

import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * @author uniken
 */
public class UserSecqa {

    public static final String ID_STR = "_id";
    public final static String USER_UUID_STR = "user_uuid";
    public final static String USER_ID = "user_id";
    public final static String SECQA = "secqa";
    public final static String CREATED_TS_STR = "created_ts";
    public final static String UPDATED_TS_STR = "updated_ts";

    @SerializedName(value = ID_STR)
    private ObjectId id;

    @SerializedName(USER_UUID_STR)
    @Field(USER_UUID_STR)
    private String userUuid;

    @SerializedName(USER_ID)
    @Field(USER_ID)
    private String userId;

    @SerializedName(SECQA)
    @Field(SECQA)
    private List<SecQueAns> secqa;

    @SerializedName(CREATED_TS_STR)
    @Field(CREATED_TS_STR)
    private Date createdTs;

    @SerializedName(UPDATED_TS_STR)
    @Field(UPDATED_TS_STR)
    private Date updatedTs;

    /**
     * @return the userUuid
     */
    public String getUserUuid() {
        return userUuid;
    }

    /**
     * @param userUuid
     *            the userUuid to set
     */
    public void setUserUuid(final String userUuid) {
        this.userUuid = userUuid;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @return the secqa
     */
    public List<SecQueAns> getSecqa() {
        return secqa;
    }

    /**
     * @param secqa
     *            the secqa to set
     */
    public void setSecqa(final List<SecQueAns> secqa) {
        this.secqa = secqa;
    }

    /**
     * @return the createdTs
     */
    public Date getCreatedTs() {
        return createdTs;
    }

    /**
     * @param createdTs
     *            the createdTs to set
     */
    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }

    /**
     * @return the updatedTs
     */
    public Date getUpdatedTs() {
        return updatedTs;
    }

    /**
     * @param updatedTs
     *            the updatedTs to set
     */
    public void setUpdatedTs(final Date updatedTs) {
        this.updatedTs = updatedTs;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "UserSecqa [userId=" + userId + ", secqa=" + secqa + ", createdTs=" + createdTs + ", updatedTs="
                + updatedTs + "]";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((secqa == null) ? 0 : secqa.hashCode());
        result = prime * result + ((userId == null) ? 0 : userId.hashCode());
        result = prime * result + ((userUuid == null) ? 0 : userUuid.hashCode());
        result = prime * result + ((createdTs == null) ? 0 : createdTs.hashCode());
        result = prime * result + ((updatedTs == null) ? 0 : updatedTs.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final UserSecqa other = (UserSecqa) obj;
        if (secqa == null) {
            if (other.secqa != null)
                return false;
        } else if (!secqa.equals(other.secqa))
            return false;
        if (userId == null) {
            if (other.userId != null)
                return false;
        } else if (!userId.equals(other.userId))
            return false;
        if (userUuid == null) {
            if (other.userUuid != null)
                return false;
        } else if (!userUuid.equals(other.userUuid))
            return false;
        if (createdTs == null) {
            if (other.createdTs != null)
                return false;
        } else if (!createdTs.equals(other.createdTs))
            return false;
        if (updatedTs == null) {
            if (other.updatedTs != null)
                return false;
        } else if (!updatedTs.equals(other.updatedTs))
            return false;
        return true;
    }

    /**
     * Create Bson Document document from the provided User object
     * 
     * @param User
     *            the User to be converted to a Bson Document
     * @return A Bson document
     */
    public static Document getBsonDocument(final UserSecqa userSecQa) {
        if (null == userSecQa) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != userSecQa.getUserUuid()) {
            logsDoc.append(USER_UUID_STR, userSecQa.getUserUuid());
        }

        if (null != userSecQa.getUserId()) {
            logsDoc.append(USER_ID, userSecQa.getUserId());
        }

        if (null != userSecQa.getSecqa()) {
            final SecQueAns[] deviceArray = new SecQueAns[userSecQa.getSecqa().size()];
            logsDoc.append(SECQA, SecQueAns.getBsonDocuments(userSecQa.getSecqa().toArray(deviceArray)));
            logsDoc.append(USER_ID, userSecQa.getUserId());
        }

        if (null != userSecQa.getCreatedTs()) {
            logsDoc.append(CREATED_TS_STR, userSecQa.getCreatedTs());
        }

        if (null != userSecQa.getUpdatedTs()) {
            logsDoc.append(UPDATED_TS_STR, userSecQa.getUpdatedTs());
        }

        return logsDoc;
    }

}
