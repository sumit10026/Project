/**
 * 
 */
package com.uniken.domains.relid.user;

import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.relid.BaseEntity;

/**
 * @author Uniken Inc.
 */
public class DigitalCertificate extends BaseEntity {

    public static final String CERTIFICATE_STR = "certificate";
    public static final String CERT_TYPE_STR = "cert_type";
    public static final String CERT_SERIAL_NUMBER_STR = "cert_serial_number";
    public static final String CREATED_TS_STR = "cert_ts";
    public static final String USER_ID_STR = "user_id";
    public static final String DEVICE_ID = "device_id";
    public static final String RELID_UUID_STR = "relid_uuid";

    @SerializedName(value = ID_STR)
    private ObjectId id;

    @SerializedName(value = CERTIFICATE_STR)
    @Field(CERTIFICATE_STR)
    private String certificate;

    @SerializedName(value = CREATED_TS_STR)
    @Field(CREATED_TS_STR)
    private Date createdTS;

    @SerializedName(value = USER_ID_STR)
    @Field(USER_ID_STR)
    private String userId;

    @SerializedName(value = DEVICE_ID)
    @Field(DEVICE_ID)
    private String deviceId;

    @SerializedName(value = RELID_UUID_STR)
    @Field(RELID_UUID_STR)
    private String relIdUuid;

    /**
     * @param certificate
     * @param createdTS
     * @param relIdUuid
     */
    public DigitalCertificate(final String certificate, final Date createdTS, final String relIdUuid,
            final String deviceId) {
        super();
        this.certificate = certificate;
        this.createdTS = createdTS;
        this.relIdUuid = relIdUuid;
        this.deviceId = deviceId;
    }

    /**
     * @return the certificate
     */
    public String getCertificate() {
        return certificate;
    }

    /**
     * @param certificate
     *            the certificate to set
     */
    public void setCertificate(final String certificate) {
        this.certificate = certificate;
    }

    /**
     * @return the createdTS
     */
    public Date getCreatedTS() {
        return createdTS;
    }

    /**
     * @param createdTS
     *            the createdTS to set
     */
    public void setCreatedTS(final Date createdTS) {
        this.createdTS = createdTS;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @return the deviceId
     */
    public String getDeviceId() {
        return deviceId;
    }

    /**
     * @param deviceId
     *            the deviceId to set
     */
    public void setDeviceId(final String deviceId) {
        this.deviceId = deviceId;
    }

    /**
     * @return the relIdUuid
     */
    public String getRelIdUuid() {
        return relIdUuid;
    }

    /**
     * @param relIdUuid
     *            the relIdUuid to set
     */
    public void setRelIdUuid(final String relIdUuid) {
        this.relIdUuid = relIdUuid;
    }

}
