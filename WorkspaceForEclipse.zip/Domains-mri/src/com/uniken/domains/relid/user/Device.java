package com.uniken.domains.relid.user;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

public class Device {

    public static final String USER_UUID = "user_uuid";
    public static final String DEVICE_UUID = "dev_uuid";
    public static final String DEVICE_NAME = "dev_name";
    public static final String DEV_STATUS = "dev_status";
    public static final String CREATED_TS = "created_ts";
    public static final String LAST_ACCESSED_TS = "last_accessed_ts";
    public static final String LAST_LOGIN_STATUS = "last_login_status";
    public static final String DEV_TOKEN_STR = "dev_token";
    public static final String DEV_PLATFORM_STR = "dev_platform";
    public static final String DEV_TYPE_STR = "dev_type";

    @Indexed
    @SerializedName(value = USER_UUID)
    private String userUuid;

    @Indexed
    @SerializedName(value = DEVICE_UUID)
    @Field(value = DEVICE_UUID)
    private String deviceUuid;

    @SerializedName(value = DEVICE_NAME)
    @Field(value = DEVICE_NAME)
    private String deviceName;

    @SerializedName(value = DEV_STATUS)
    @Field(value = DEV_STATUS)
    private DeviceStatus deviceStatus;

    @SerializedName(value = CREATED_TS)
    private Date createdTs;

    @SerializedName(value = LAST_ACCESSED_TS)
    private Date lastAccessedTs;

    @SerializedName(value = LAST_LOGIN_STATUS)
    private String lastLoginStatus;

    @SerializedName(value = DEV_TOKEN_STR)
    @Field(DEV_TOKEN_STR)
    private String deviceToken;

    @SerializedName(value = DEV_PLATFORM_STR)
    @Field(DEV_PLATFORM_STR)
    private String devicePlatform;

    @SerializedName(value = DEV_TYPE_STR)
    @Field(DEV_TYPE_STR)
    private String deviceType;

    /**
     * @return the userUuid
     */
    public String getUserUuid() {
        return userUuid;
    }

    /**
     * @param userUuid
     *            the userUuid to set
     */
    public void setUserUuid(final String userUuid) {
        this.userUuid = userUuid;
    }

    /**
     * @return the deviceUuid
     */
    public String getDeviceUuid() {
        return deviceUuid;
    }

    /**
     * @param deviceUuid
     *            the deviceUuid to set
     */
    public void setDeviceUuid(final String deviceUuid) {
        this.deviceUuid = deviceUuid;
    }

    /**
     * @return the deviceName
     */
    public String getDeviceName() {
        return deviceName;
    }

    /**
     * @param deviceName
     *            the deviceName to set
     */
    public void setDeviceName(final String deviceName) {
        this.deviceName = deviceName;
    }

    /**
     * @return the deviceStatus
     */
    public DeviceStatus getDeviceStatus() {
        return deviceStatus;
    }

    /**
     * @param deviceStatus
     *            the deviceStatus to set
     */
    public void setDeviceStatus(final DeviceStatus deviceStatus) {
        this.deviceStatus = deviceStatus;
    }

    /**
     * @return the createdTs
     */
    public Date getCreatedTs() {
        return createdTs;
    }

    /**
     * @param createdTs
     *            the createdTs to set
     */
    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }

    /**
     * @return the lastAccessedTs
     */
    public Date getLastAccessedTs() {
        return lastAccessedTs;
    }

    /**
     * @param lastAccessedTs
     *            the lastAccessedTs to set
     */
    public void setLastAccessedTs(final Date lastAccessedTs) {
        this.lastAccessedTs = lastAccessedTs;
    }

    /**
     * @return the lastLoginStatus
     */
    public String getLastLoginStatus() {
        return lastLoginStatus;
    }

    /**
     * @param lastLoginStatus
     *            the lastLoginStatus to set
     */
    public void setLastLoginStatus(final String lastLoginStatus) {
        this.lastLoginStatus = lastLoginStatus;
    }

    /**
     * @return the deviceToken
     */
    public String getDeviceToken() {
        return deviceToken;
    }

    /**
     * @param deviceToken
     *            the deviceToken to set
     */
    public void setDeviceToken(final String deviceToken) {
        this.deviceToken = deviceToken;
    }

    /**
     * @return the devicePlatform
     */
    public String getDevicePlatform() {
        return devicePlatform;
    }

    /**
     * @param devicePlatform
     *            the devicePlatform to set
     */
    public void setDevicePlatform(final String devicePlatform) {
        this.devicePlatform = devicePlatform;
    }

    /**
     * @return the deviceType
     */
    public String getDeviceType() {
        return deviceType;
    }

    /**
     * @param deviceType
     *            the deviceType to set
     */
    public void setDeviceType(final String deviceType) {
        this.deviceType = deviceType;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("Device [userUuid=");
        builder.append(userUuid);
        builder.append(", deviceUuid=");
        builder.append(deviceUuid);
        builder.append(", deviceName=");
        builder.append(deviceName);
        builder.append(", deviceStatus=");
        builder.append(deviceStatus);
        builder.append(", createdTs=");
        builder.append(createdTs);
        builder.append(", lastAccessedTs=");
        builder.append(lastAccessedTs);
        builder.append(", lastLoginStatus=");
        builder.append(lastLoginStatus);
        builder.append(", deviceToken=");
        builder.append(deviceToken);
        builder.append(", devicePlatform=");
        builder.append(devicePlatform);
        builder.append(", deviceType=");
        builder.append(deviceType);
        builder.append("]");
        return builder.toString();
    }

    /**
     * Create Bson Document document from the provided Device object
     * 
     * @param Device
     *            the Device to be converted to a Bson Document
     * @return A Bson document
     */

    public static Document getBsonDocument(final Device doc) {
        if (null == doc) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != doc.getUserUuid()) {
            logsDoc.append(USER_UUID, doc.getUserUuid());
        }

        if (null != doc.getDeviceUuid()) {
            logsDoc.append(DEVICE_UUID, doc.getDeviceUuid());
        }

        if (null != doc.getDeviceName()) {
            logsDoc.append(DEVICE_NAME, doc.getDeviceName());
        }

        if (null != doc.getDeviceStatus()) {
            logsDoc.append(DEV_STATUS, doc.getDeviceStatus().name());
        }

        if (null != doc.getCreatedTs()) {
            logsDoc.append(CREATED_TS, doc.getCreatedTs());
        }

        if (null != doc.getLastAccessedTs()) {
            logsDoc.append(LAST_ACCESSED_TS, doc.getLastAccessedTs());
        }

        if (null != doc.getLastLoginStatus()) {
            logsDoc.append(LAST_LOGIN_STATUS, doc.getLastLoginStatus());
        }

        if (null != doc.getDeviceToken()) {
            logsDoc.append(DEV_TOKEN_STR, doc.getDeviceToken());
        }

        if (null != doc.getDevicePlatform()) {
            logsDoc.append(DEV_PLATFORM_STR, doc.getDevicePlatform());
        }
        return logsDoc;
    }

    /**
     * Create Bson Document document from the provided list of Device object
     * 
     * @param devices
     *            list of Device object
     * @return
     */
    public static List<Document> getBsonDocuments(final Device... devices) {

        final List<Document> documents = new ArrayList<Document>();

        for (final Device device : devices) {
            documents.add(getBsonDocument(device));
        }

        return documents;

    }

    private String createdTsStr;
    private String lastAccessedTsStr;

    public String getCreatedTsStr() {
        return createdTsStr;
    }

    public String getLastAccessedTsStr() {
        return lastAccessedTsStr;
    }

    public void parseDateToString(final String dateFormat) {
        final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);
        if (this.createdTs != null)
            this.createdTsStr = sdf.format(createdTs);
        if (this.lastAccessedTs != null)
            this.lastAccessedTsStr = sdf.format(lastAccessedTs);
    }

}
