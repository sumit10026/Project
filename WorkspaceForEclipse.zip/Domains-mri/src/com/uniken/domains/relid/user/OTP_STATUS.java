package com.uniken.domains.relid.user;

public enum OTP_STATUS {

    ACTIVE, USED, EXPIRED, DELETED

}
