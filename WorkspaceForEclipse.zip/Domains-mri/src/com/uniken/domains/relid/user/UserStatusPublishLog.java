package com.uniken.domains.relid.user;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.relid.LogDomain;

public class UserStatusPublishLog extends LogDomain {

    public static final String USER_STATUS_PUBLISH_LOG = "user_status_publish_log";

    public static final String ID_STR = "_id";
    public static final String USER_UUID_STR = "user_uuid";
    public static final String USER_ID_STR = "user_id";
    public static final String PRIMARY_GROUP_NAME_STR = "primary_group_name";
    public static final String SECONDARY_GROUP_NAMES_STR = "secondary_group_names";
    public static final String PUBLISHED_STATUS = "published_status";
    public static final String PUBLISHED_STATUS_TS = "published_status_ts";
    public static final String PUBLISHED_STATUS_PROCESSED_TS = "published_status_processed_ts";
    public static final String PUBLISHED_STATUS_RECEIVED_COMMENTS = "published_status_received_comments";
    public static final String ATTEMPTS_COUNTER = "attempts_counter";

    @SerializedName(value = ID_STR)
    private ObjectId id;

    @Indexed(unique = true)
    @SerializedName(USER_UUID_STR)
    @Field(USER_UUID_STR)
    private String userUuid;

    @Indexed(unique = true)
    @SerializedName(value = USER_ID_STR)
    @Field(USER_ID_STR)
    private String userId;

    @SerializedName(PRIMARY_GROUP_NAME_STR)
    @Field(PRIMARY_GROUP_NAME_STR)
    private String primaryGroupName;

    @SerializedName(SECONDARY_GROUP_NAMES_STR)
    @Field(SECONDARY_GROUP_NAMES_STR)
    private List<String> secondaryGroupNames;

    @SerializedName(PUBLISHED_STATUS)
    @Field(PUBLISHED_STATUS)
    private RelIdUserStatus publishedStatus;

    @SerializedName(PUBLISHED_STATUS_TS)
    @Field(PUBLISHED_STATUS_TS)
    private Date publishedStatusTs;

    @SerializedName(PUBLISHED_STATUS_PROCESSED_TS)
    @Field(PUBLISHED_STATUS_PROCESSED_TS)
    private Date publishedStatusProcessedTs;

    @SerializedName(PUBLISHED_STATUS_RECEIVED_COMMENTS)
    @Field(PUBLISHED_STATUS_RECEIVED_COMMENTS)
    private String publishedStatusReceivedComments;

    @SerializedName(ATTEMPTS_COUNTER)
    @Field(ATTEMPTS_COUNTER)
    private int attemptsCounter;

    /**
     */
    public UserStatusPublishLog() {
        super();
    }

    /**
     * @param relIds
     * @param relIdType
     * @param userId
     * @param groupUuid
     */
    public UserStatusPublishLog(final String userUuid, final String userId, final String primaryGroupName,
            final List<String> secondaryGroupNames, final RelIdUserStatus publishedStatus, final Date publishedStatusTs,
            final Date publishedStatusProcessedTs, final String publishedStatusReceivedComments,
            final int attemptsCounter) {
        super();
        this.userUuid = userUuid;
        this.userId = userId;
        this.primaryGroupName = primaryGroupName;
        this.secondaryGroupNames = secondaryGroupNames;
        this.publishedStatus = publishedStatus;
        this.publishedStatusTs = publishedStatusTs;
        this.publishedStatusProcessedTs = publishedStatusProcessedTs;
        this.publishedStatusReceivedComments = publishedStatusReceivedComments;
        this.attemptsCounter = attemptsCounter;
    }

    /**
     * @return the id
     */
    public ObjectId getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final ObjectId id) {
        this.id = id;
    }

    /**
     * @return the userUuid
     */
    public String getUserUuid() {
        return userUuid;
    }

    /**
     * @param userUuid
     *            the userUuid to set
     */
    public void setUserUuid(final String userUuid) {
        this.userUuid = userUuid;
    }

    /**
     * @return the userId
     */
    @Override
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    @Override
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @return the primaryGroupName
     */
    public String getPrimaryGroupName() {
        return primaryGroupName;
    }

    /**
     * @param primaryGroupName
     *            the primaryGroupName to set
     */
    public void setPrimaryGroupName(final String primaryGroupName) {
        this.primaryGroupName = primaryGroupName;
    }

    /**
     * @return the secondaryGroupNames
     */
    public List<String> getSecondaryGroupNames() {
        return secondaryGroupNames;
    }

    /**
     * @param secondaryGroupNames
     *            the secondaryGroupNames to set
     */
    public void setSecondaryGroupNames(final List<String> secondaryGroupNames) {
        this.secondaryGroupNames = secondaryGroupNames;
    }

    /**
     * @return the publishedStatus
     */
    public RelIdUserStatus getPublishedStatus() {
        return publishedStatus;
    }

    /**
     * @param publishedStatus
     *            the publishedStatus to set
     */
    public void setPublishedStatus(final RelIdUserStatus publishedStatus) {
        this.publishedStatus = publishedStatus;
    }

    /**
     * @return the publishedStatusTs
     */
    public Date getPublishedStatusTs() {
        return publishedStatusTs;
    }

    /**
     * @param publishedStatusTs
     *            the publishedStatusTs to set
     */
    public void setPublishedStatusTs(final Date publishedStatusTs) {
        this.publishedStatusTs = publishedStatusTs;
    }

    /**
     * @return the publishedStatusProcessedTs
     */
    public Date getPublishedStatusProcessedTs() {
        return publishedStatusProcessedTs;
    }

    /**
     * @param publishedStatusProcessedTs
     *            the publishedStatusProcessedTs to set
     */
    public void setPublishedStatusProcessedTs(final Date publishedStatusProcessedTs) {
        this.publishedStatusProcessedTs = publishedStatusProcessedTs;
    }

    /**
     * @return the publishedStatusReceivedComments
     */
    public String getPublishedStatusReceivedComments() {
        return publishedStatusReceivedComments;
    }

    /**
     * @param publishedStatusReceivedComments
     *            the publishedStatusReceivedComments to set
     */
    public void setPublishedStatusReceivedComments(final String publishedStatusReceivedComments) {
        this.publishedStatusReceivedComments = publishedStatusReceivedComments;
    }

    /**
     * @return the attemptsCounter
     */
    public int getAttemptsCounter() {
        return attemptsCounter;
    }

    /**
     * @param attemptsCounter
     *            the attemptsCounter to set
     */
    public void setAttemptsCounter(final int attemptsCounter) {
        this.attemptsCounter = attemptsCounter;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("UserStatusPublishLog [id=");
        builder.append(id);
        builder.append(", userUuid=");
        builder.append(userUuid);
        builder.append(", userId=");
        builder.append(userId);
        builder.append(", primaryGroupName=");
        builder.append(primaryGroupName);
        if (null != secondaryGroupNames) {
            builder.append(", secondaryGroupNames=");
            builder.append(secondaryGroupNames);
        }
        builder.append(", publishedStatus=");
        builder.append(publishedStatus);
        builder.append(", publishedStatusTs=");
        builder.append(publishedStatusTs);
        if (null != publishedStatusProcessedTs) {
            builder.append(", publishedStatusProcessedTs=");
            builder.append(publishedStatusProcessedTs);
        }
        if (null != publishedStatusReceivedComments) {
            builder.append(", publishedStatusReceivedComments=");
            builder.append(publishedStatusReceivedComments);
        }
        builder.append(", attemptsCounter=");
        builder.append(attemptsCounter);
        builder.append("]");
        return builder.toString();
    }

    /**
     * Create Bson Document document from the provided User object
     * 
     * @param User
     *            the User to be converted to a Bson Document
     * @return A Bson document
     */
    public static Document getBsonDocument(final UserStatusPublishLog user) {
        if (null == user) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != user.getId()) {
            logsDoc.append(ID_STR, user.getId());
        }

        if (null != user.getUserUuid()) {
            logsDoc.append(USER_UUID_STR, user.getUserUuid());
        }

        if (null != user.getUserId()) {
            logsDoc.append(USER_ID_STR, user.getUserId());
        }

        if (null != user.getPrimaryGroupName()) {
            logsDoc.append(PRIMARY_GROUP_NAME_STR, user.getPrimaryGroupName());
        }

        if (null != user.getSecondaryGroupNames()) {
            logsDoc.append(SECONDARY_GROUP_NAMES_STR, user.getSecondaryGroupNames());
        }

        if (null != user.getPublishedStatus()) {
            logsDoc.append(PUBLISHED_STATUS, user.getPublishedStatus().getValue());
        }

        if (null != user.getPublishedStatusTs()) {
            logsDoc.append(PUBLISHED_STATUS_TS, user.getPublishedStatusTs());
        }

        if (null != user.getPublishedStatusProcessedTs()) {
            logsDoc.append(PUBLISHED_STATUS_PROCESSED_TS, user.getPublishedStatusProcessedTs());
        }

        if (null != user.getPublishedStatusReceivedComments()) {
            logsDoc.append(PUBLISHED_STATUS_RECEIVED_COMMENTS, user.getPublishedStatusReceivedComments());
        }

        logsDoc.append(ATTEMPTS_COUNTER, user.getAttemptsCounter());

        return logsDoc;
    }

    public static final String PUBLISHED_STATUS_TS_STR = "published_status_ts_str";
    public static final String PUBLISHED_STATUS_PROCESSED_TS_STR = "published_status_processed_ts_str";

    @SerializedName(PUBLISHED_STATUS_TS_STR)
    @Field(PUBLISHED_STATUS_TS_STR)
    private String publishedStatusTsStr;

    @SerializedName(PUBLISHED_STATUS_PROCESSED_TS_STR)
    @Field(PUBLISHED_STATUS_PROCESSED_TS_STR)
    private String publishedStatusProcessedTsStr;

    public String getPublishedStatusTsStr() {
        return publishedStatusTsStr;
    }

    public void setPublishedStatusTsStr(final String publishedStatusTsStr) {
        this.publishedStatusTsStr = publishedStatusTsStr;
    }

    public String getPublishedStatusProcessedTsStr() {
        return publishedStatusProcessedTsStr;
    }

    public void setPublishedStatusProcessedTsStr(final String publishedStatusProcessedTsStr) {
        this.publishedStatusProcessedTsStr = publishedStatusProcessedTsStr;
    }

    public void parseDateToString(final String dateFormat) {
        final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        if (null != this.publishedStatusTs)
            this.publishedStatusTsStr = sdf.format(this.publishedStatusTs);
        if (null != this.publishedStatusProcessedTs)
            this.publishedStatusProcessedTsStr = sdf.format(this.publishedStatusProcessedTs);

    }

}
