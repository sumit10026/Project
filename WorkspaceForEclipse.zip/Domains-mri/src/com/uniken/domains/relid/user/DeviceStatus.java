package com.uniken.domains.relid.user;

import java.util.HashMap;
import java.util.Map;

public enum DeviceStatus {

    ACTIVE("Active"), BLOCKED("Blocked"), CREATED("Created");

    private String name;

    private DeviceStatus(final String name) {
        this.name = name;
    }

    private static final Map<String, DeviceStatus> deviceStatusMap = new HashMap<String, DeviceStatus>();

    static {

        for (final DeviceStatus type : values()) {
            deviceStatusMap.put(type.toString(), type);
        }
    }

    public static DeviceStatus getDeviceStatusValue(final String name) {
        return deviceStatusMap.get(name);
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }
}
