/**
* 
*/
package com.uniken.domains.relid.user;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.enums.RelIdVersion;

/**
 * The {@code RelId} POJO is used for storing user's REL-ID information.
 * 
 * @author Uniken Inc.
 */
public class RelId {

    public static final String RELID_UUID_STR = "relid_uuid";
    public static final String RELID_VERSION_STR = "relid_version";
    public static final String RELID_SERVER_STR = "relid_server";
    public static final String RELID_CLIENT_STR = "relid_client";
    public static final String RELID_STATUS_STR = "relid_status";
    public static final String RELID_PREVIOUS_STATUS_STR = "relid_previous_status";
    public static final String RELID_CREATEDTS_STR = "relid_created_ts";
    public static final String RELID_UPDATEDTS_STR = "relid_updated_ts";
    public static final String RELID_ARCHIVEDTS_STR = "relid_archived_ts";
    public static final String RELID_ARCHIVED_OPERATION_STR = "relid_archived_operation";

    public static final String VER_KEY_STR = "ver_key";
    public static final String ACT_CODE_STR = "act_code";
    public static final String CIPHER_SALT = "cipher_salt";
    public static final String ACT_CODE_EXPIRYTS_STR = "act_code_expiry_ts";
    public static final String PASSWORD_HASH_STR = "password_hash";
    public static final String PASSWORD_UPDATEDTS_STR = "password_updated_ts";
    public static final String PASSWORD_ATTEMPTS_LEFT_STR = "password_attempts_left";
    public static final String FORGOT_PASSWORD_ATTEMPTS_LEFT_STR = "forgot_password_attempts_left";
    public static final String OLD_PASSWORDS_STR = "old_passwords";
    public static final String CRED_TYPE_STR = "cred_type";

    public static final String DEVICE_UUID_STR = "dev_uuid";
    public static final String DEVICE_NAME_STR = "dev_name";
    public static final String DEVICE_STATUS_STR = "dev_status";
    public static final String DEVICE_LAST_ACCESSED_TS_STR = "dev_last_accessed_ts";
    public static final String DEVICE_PLATFORM_STR = "dev_platform";
    public static final String DEVICE_TOKEN_STR = "dev_token";

    public static final String DEVICE_TYPE_STR = "dev_type";
    public static final String DEVICE_BIND_STR = "dev_bind";

    public static final String APP_UUID_STR = "app_uuid";
    public static final String APP_NAME_STR = "app_name";
    public static final String CERT_PUBLIC_KEY = "certificate";

    public static final String TOTP_SEED = "totp_seed";
    public static final String HMAC_INDEX_VAL = "hmac_index_val";
    public static final String HMAC = "hmac";
    public static final String TOTP_VALIDATION_MODE = "totp_validation_mode";

    public static final String ENFORCE_MANUAL_PASS = "ENFORCE_MANUAL_PASS";

    public static final String DEVICE_INACTIVITY_NOTIFIED = "device_inactivity_notified";

    public static final String IS_RE_INITIATING_WORKFLOW = "is_re_initiating_workflow";

    public static final String LDA_TOKEN_STR = "lda_token";

    @SerializedName(RELID_UUID_STR)
    @Field(RELID_UUID_STR)
    private String relIdUuid;

    @SerializedName(RELID_VERSION_STR)
    @Field(RELID_VERSION_STR)
    private RelIdVersion relIdVersion;

    @SerializedName(RELID_SERVER_STR)
    @Field(RELID_SERVER_STR)
    private String relIdServer;

    @SerializedName(RELID_CLIENT_STR)
    @Field(RELID_CLIENT_STR)
    private String relIdClient;

    @SerializedName(RELID_STATUS_STR)
    @Field(RELID_STATUS_STR)
    private RelIdUserStatus relIdStatus;

    @SerializedName(RELID_PREVIOUS_STATUS_STR)
    @Field(RELID_PREVIOUS_STATUS_STR)
    private RelIdUserStatus relIdPreviousStatus;

    @SerializedName(RELID_CREATEDTS_STR)
    @Field(RELID_CREATEDTS_STR)
    private Date relIdCreatedTs;

    @SerializedName(RELID_UPDATEDTS_STR)
    @Field(RELID_UPDATEDTS_STR)
    private Date relIdUpdatedTs;

    @SerializedName(RELID_ARCHIVEDTS_STR)
    @Field(RELID_ARCHIVEDTS_STR)
    private Date relIdArchivedTs;

    @SerializedName(RELID_ARCHIVED_OPERATION_STR)
    @Field(RELID_ARCHIVED_OPERATION_STR)
    private RelIdUserStatus relIdArchivedOperation;

    @SerializedName(VER_KEY_STR)
    @Field(VER_KEY_STR)
    private String verKey;

    @SerializedName(ACT_CODE_STR)
    @Field(ACT_CODE_STR)
    private String actCode;

    @SerializedName(value = CIPHER_SALT)
    @Field(CIPHER_SALT)
    private String cipherSalt;

    @SerializedName(ACT_CODE_EXPIRYTS_STR)
    @Field(ACT_CODE_EXPIRYTS_STR)
    private Date actCodeExpiryTs;

    @SerializedName(PASSWORD_HASH_STR)
    @Field(PASSWORD_HASH_STR)
    private String passwordHash;

    @SerializedName(PASSWORD_UPDATEDTS_STR)
    @Field(PASSWORD_UPDATEDTS_STR)
    private Date passwordUpdatedTs;

    @SerializedName(PASSWORD_ATTEMPTS_LEFT_STR)
    @Field(PASSWORD_ATTEMPTS_LEFT_STR)
    private int passwordAttemptsLeft;

    @SerializedName(value = OLD_PASSWORDS_STR)
    @Field(OLD_PASSWORDS_STR)
    private ArrayDeque<String> oldpasswords;

    @SerializedName(CRED_TYPE_STR)
    @Field(CRED_TYPE_STR)
    private String credType;

    @SerializedName(DEVICE_UUID_STR)
    @Field(DEVICE_UUID_STR)
    private String deviceUuid;

    @SerializedName(DEVICE_NAME_STR)
    @Field(DEVICE_NAME_STR)
    private String deviceName;

    @SerializedName(DEVICE_STATUS_STR)
    @Field(DEVICE_STATUS_STR)
    private String deviceStatus;

    @SerializedName(DEVICE_LAST_ACCESSED_TS_STR)
    @Field(DEVICE_LAST_ACCESSED_TS_STR)
    private Date deviceLastAccessedTs;

    @SerializedName(DEVICE_PLATFORM_STR)
    @Field(DEVICE_PLATFORM_STR)
    private String devicePlatform;

    @SerializedName(DEVICE_TOKEN_STR)
    @Field(DEVICE_TOKEN_STR)
    private String deviceToken;

    @SerializedName(DEVICE_TYPE_STR)
    @Field(DEVICE_TYPE_STR)
    private String deviceType;

    @SerializedName(DEVICE_BIND_STR)
    @Field(DEVICE_BIND_STR)
    private String deviceBind;

    @SerializedName(APP_UUID_STR)
    @Field(APP_UUID_STR)
    private String appUuid;

    @SerializedName(APP_NAME_STR)
    @Field(APP_NAME_STR)
    private String appName;

    @SerializedName(CERT_PUBLIC_KEY)
    @Field(CERT_PUBLIC_KEY)
    private String certPublicKey;

    @SerializedName(TOTP_SEED)
    @Field(TOTP_SEED)
    private String totpSeed;

    @SerializedName(HMAC)
    @Field(HMAC)
    private String hmac;

    @SerializedName(HMAC_INDEX_VAL)
    @Field(HMAC_INDEX_VAL)
    private int hmacIndexVal;

    @SerializedName(TOTP_VALIDATION_MODE)
    @Field(TOTP_VALIDATION_MODE)
    private String totpValidationMode;

    @SerializedName(ENFORCE_MANUAL_PASS)
    @Field(ENFORCE_MANUAL_PASS)
    private boolean enforceManualPass;

    @SerializedName(DEVICE_INACTIVITY_NOTIFIED)
    @Field(DEVICE_INACTIVITY_NOTIFIED)
    private boolean deviceInactivityNotified;

    @SerializedName(FORGOT_PASSWORD_ATTEMPTS_LEFT_STR)
    @Field(FORGOT_PASSWORD_ATTEMPTS_LEFT_STR)
    private int forgotPasswordAttemptsLeft;

    @SerializedName(IS_RE_INITIATING_WORKFLOW)
    @Field(IS_RE_INITIATING_WORKFLOW)
    private boolean isReInitiatingWorkflow;

    @SerializedName(LDA_TOKEN_STR)
    @Field(LDA_TOKEN_STR)
    private String ldaToken;

    public RelId() {
        super();
    }

    /**
     * @param uuid
     * @param version
     * @param relIdServer
     * @param relIdClient
     */
    public RelId(final String relIdUuid, final RelIdVersion relIdVersion, final String relIdServer,
            final String relIdClient) {
        super();
        this.relIdUuid = relIdUuid;
        this.relIdVersion = relIdVersion;
        this.relIdServer = relIdServer;
        this.relIdClient = relIdClient;

    }

    /**
     * @param relIdUUID
     * @param relIdVersion
     * @param relIdServer
     * @param relIdStatus
     * @param createTS
     * @param devUUID
     * @param appUUID
     * @return
     */
    public static RelId getServerRelIdInstance(final String relIdUUID, final RelIdVersion relIdVersion,
            final String relIdServer, final RelIdUserStatus relIdStatus, final Date createTS, final String devUUID,
            final String appUUID) {

        final RelId relId = new RelId();
        relId.setRelIdUuid(relIdUUID);
        relId.setRelIdVersion(relIdVersion);
        relId.setRelIdServer(relIdServer);
        relId.setRelIdStatus(relIdStatus);
        relId.setRelIdCreatedTs(createTS);
        relId.setDeviceUuid(devUUID);
        relId.setAppUuid(appUUID);

        return relId;
    }

    /**
     * @param relIdUUID
     * @param relIdVersion
     * @param relIdClient
     * @param cipherSalt
     * @param relIdStatus
     * @param createTS
     * @param devUUID
     * @param appUUID
     * @return
     */
    public static RelId getClientRelIdInstance(final String relIdUUID, final RelIdVersion relIdVersion,
            final String relIdClient, final String cipherSalt, final RelIdUserStatus relIdStatus, final Date createTS,
            final String devUUID, final String appUUID) {

        final RelId relId = new RelId();
        relId.setRelIdUuid(relIdUUID);
        relId.setRelIdVersion(relIdVersion);
        relId.setRelIdClient(relIdClient);
        relId.setCipherSalt(cipherSalt);
        relId.setRelIdStatus(relIdStatus);
        relId.setRelIdCreatedTs(createTS);
        relId.setDeviceUuid(devUUID);
        relId.setAppUuid(appUUID);

        return relId;
    }

    /**
     * Gets UUID of REL-ID
     * 
     * @return the relIdUuid
     */
    public String getRelIdUuid() {
        return relIdUuid;
    }

    /**
     * Sets UUID of REL-ID.
     * 
     * @param relIdUuid
     *            the relIdUuid to set
     */
    public void setRelIdUuid(final String relIdUuid) {
        this.relIdUuid = relIdUuid;
    }

    /**
     * Gets Version of REL-ID
     * 
     * @return the relIdVersion
     */
    public RelIdVersion getRelIdVersion() {
        return relIdVersion;
    }

    /**
     * Sets Version of REL-ID.
     * 
     * @param relIdVersion
     *            the relIdVersion to set
     */
    public void setRelIdVersion(final RelIdVersion relIdVersion) {
        this.relIdVersion = relIdVersion;
    }

    /**
     * Gets server part key of REL-ID.
     * 
     * @return the relidServer
     */
    public String getRelIdServer() {
        return relIdServer;
    }

    /**
     * Sets server part key of REL-ID.
     * 
     * @param relidServer
     *            the relidServer to set
     */
    public void setRelIdServer(final String relIdServer) {
        this.relIdServer = relIdServer;
    }

    /**
     * Gets server part key of REL-ID.
     * 
     * @return the relidClient
     */
    public String getRelIdClient() {
        return relIdClient;
    }

    /**
     * Sets Client part key of REL-ID.
     * 
     * @param relidClient
     *            the relidClient to set
     */
    public void setRelIdClient(final String relIdClient) {
        this.relIdClient = relIdClient;
    }

    /**
     * Gets Status of REL-ID.
     * 
     * @return the relIdStatus
     */
    public RelIdUserStatus getRelIdStatus() {
        return relIdStatus;
    }

    /**
     * Sets Status of REL-ID.
     * 
     * @param relIdStatus
     *            the relIdStatus to set
     */
    public void setRelIdStatus(final RelIdUserStatus relIdStatus) {
        this.relIdStatus = relIdStatus;
    }

    /**
     * Gets Status of REL-ID.
     * 
     * @return the relIdPreviousStatus
     */
    public RelIdUserStatus getRelIdPreviousStatus() {
        return relIdPreviousStatus;
    }

    /**
     * Sets Status of REL-ID.
     * 
     * @param relIdPreviousStatus
     *            the relIdPreviousStatus to set
     */
    public void setRelIdPreviousStatus(final RelIdUserStatus relIdPreviousStatus) {
        this.relIdPreviousStatus = relIdPreviousStatus;
    }

    /**
     * @return the relIdCreatedTs
     */
    public Date getRelIdCreatedTs() {
        return relIdCreatedTs;
    }

    /**
     * @param relIdCreatedTs
     *            the relIdCreatedTs to set
     */
    public void setRelIdCreatedTs(final Date relIdCreatedTs) {
        this.relIdCreatedTs = relIdCreatedTs;
    }

    /**
     * @return the relIdUpdatedTs
     */
    public Date getRelIdUpdatedTs() {
        return relIdUpdatedTs;
    }

    /**
     * @param relIdUpdatedTs
     *            the relIdUpdatedTs to set
     */
    public void setRelIdUpdatedTs(final Date relIdUpdatedTs) {
        this.relIdUpdatedTs = relIdUpdatedTs;
    }

    public String getVerKey() {
        return verKey;
    }

    public void setVerKey(final String verKey) {
        this.verKey = verKey;
    }

    public String getActCode() {
        return actCode;
    }

    public void setActCode(final String actCode) {
        this.actCode = actCode;
    }

    public String getCipherSalt() {
        return cipherSalt;
    }

    public void setCipherSalt(final String cipherSalt) {
        this.cipherSalt = cipherSalt;
    }

    public Date getActCodeExpiryTs() {
        return actCodeExpiryTs;
    }

    public void setActCodeExpiryTs(final Date actCodeExpiryTs) {
        this.actCodeExpiryTs = actCodeExpiryTs;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(final String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public Date getPasswordUpdatedTs() {
        return passwordUpdatedTs;
    }

    public void setPasswordUpdatedTs(final Date passwordUpdatedTs) {
        this.passwordUpdatedTs = passwordUpdatedTs;
    }

    public int getPasswordAttemptsLeft() {
        return passwordAttemptsLeft;
    }

    public void setPasswordAttemptsLeft(final int passwordAttemptsLeft) {
        this.passwordAttemptsLeft = passwordAttemptsLeft;
    }

    public ArrayDeque<String> getOldpasswords() {
        return oldpasswords;
    }

    public void setOldpasswords(final ArrayDeque<String> oldpasswords) {
        this.oldpasswords = oldpasswords;
    }

    public String getCredType() {
        return credType;
    }

    public void setCredType(final String credType) {
        this.credType = credType;
    }

    /**
     * @return the deviceUuid
     */
    public String getDeviceUuid() {
        return deviceUuid;
    }

    /**
     * @param deviceUuid
     *            the deviceUuid to set
     */
    public void setDeviceUuid(final String deviceUuid) {
        this.deviceUuid = deviceUuid;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(final String deviceName) {
        this.deviceName = deviceName;
    }

    public String getDeviceStatus() {
        return deviceStatus;
    }

    public void setDeviceStatus(final String deviceStatus) {
        this.deviceStatus = deviceStatus;
    }

    public Date getDeviceLastAccessedTs() {
        return deviceLastAccessedTs;
    }

    public void setDeviceLastAccessedTs(final Date deviceLastAccessedTs) {
        this.deviceLastAccessedTs = deviceLastAccessedTs;
    }

    public String getDevicePlatform() {
        return devicePlatform;
    }

    public void setDevicePlatform(final String devicePlatform) {
        this.devicePlatform = devicePlatform;
    }

    public String getDeviceToken() {
        return deviceToken;
    }

    public void setDeviceToken(final String deviceToken) {
        this.deviceToken = deviceToken;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(final String deviceType) {
        this.deviceType = deviceType;
    }

    public String getDeviceBind() {
        return deviceBind;
    }

    public void setDeviceBind(final String deviceBind) {
        this.deviceBind = deviceBind;
    }

    /**
     * @return the appUuid
     */
    public String getAppUuid() {
        return appUuid;
    }

    /**
     * @param appUuid
     *            the appUuid to set
     */
    public void setAppUuid(final String appUuid) {
        this.appUuid = appUuid;
    }

    /**
     * @return
     */
    public String getAppName() {
        return appName;
    }

    /**
     * @param appName
     */
    public void setAppName(final String appName) {
        this.appName = appName;
    }

    /**
     * @return the certPublicKey
     */
    public String getCertPublicKey() {
        return certPublicKey;
    }

    /**
     * @param certPublicKey
     *            the certPublicKey to set
     */
    public void setCertPublicKey(final String certPublicKey) {
        this.certPublicKey = certPublicKey;
    }

    /**
     * @return the totpSeed
     */
    public String getTotpSeed() {
        return totpSeed;
    }

    /**
     * @param totpSeed
     *            the totpSeed to set
     */
    public void setTotpSeed(final String totpSeed) {
        this.totpSeed = totpSeed;
    }

    /**
     * @return the hmac
     */
    public String getHmac() {
        return hmac;
    }

    /**
     * @param hmac
     *            the hmac to set
     */
    public void setHmac(final String hmac) {
        this.hmac = hmac;
    }

    /**
     * @return the hmacIndexVal
     */
    public int getHmacIndexVal() {
        return hmacIndexVal;
    }

    /**
     * @param hmacIndexVal
     *            the hmacIndexVal to set
     */
    public void setHmacIndexVal(final int hmacIndexVal) {
        this.hmacIndexVal = hmacIndexVal;
    }

    /**
     * @return the totpValidationMode
     */
    public String getTotpValidationMode() {
        return totpValidationMode;
    }

    /**
     * @param totpValidationMode
     *            the totpValidationMode to set
     */
    public void setTotpValidationMode(final String totpValidationMode) {
        this.totpValidationMode = totpValidationMode;
    }

    public boolean getEnforceManualPass() {
        return enforceManualPass;
    }

    public void setEnforceManualPass(final boolean enforceManualPass) {
        this.enforceManualPass = enforceManualPass;
    }

    public boolean isDeviceInactivityNotified() {
        return deviceInactivityNotified;
    }

    public void setDeviceInactivityNotified(final boolean deviceInactivityNotified) {
        this.deviceInactivityNotified = deviceInactivityNotified;
    }

    public int getForgotPasswordAttemptsLeft() {
        return forgotPasswordAttemptsLeft;
    }

    public void setForgotPasswordAttemptsLeft(final int forgotPasswordAttemptsLeft) {
        this.forgotPasswordAttemptsLeft = forgotPasswordAttemptsLeft;
    }

    public Date getRelIdArchivedTs() {
        return relIdArchivedTs;
    }

    public void setRelIdArchivedTs(final Date relIdArchivedTs) {
        this.relIdArchivedTs = relIdArchivedTs;
    }

    public RelIdUserStatus getRelIdArchivedOperation() {
        return relIdArchivedOperation;
    }

    public void setRelIdArchivedOperation(final RelIdUserStatus relIdArchivedOperation) {
        this.relIdArchivedOperation = relIdArchivedOperation;
    }

    public boolean isReInitiatingWorkflow() {
        return isReInitiatingWorkflow;
    }

    public void setReInitiatingWorkflow(final boolean isReInitiatingWorkflow) {
        this.isReInitiatingWorkflow = isReInitiatingWorkflow;
    }

    public String getLdaToken() {
        return ldaToken;
    }

    public void setLdaToken(final String ldaToken) {
        this.ldaToken = ldaToken;
    }

    /**
     * Gets the BSON document form of given RelId POJO.
     * 
     * @param relId
     *            the rel-id
     * @return the document
     */
    public static Document getBsonDocument(final RelId relId) {
        if (null == relId) {
            return null;
        }

        final Document document = new Document();

        if (null != relId.getRelIdServer()) {
            document.append(RELID_SERVER_STR, relId.getRelIdServer());
        }

        if (null != relId.getRelIdClient()) {
            document.append(RELID_CLIENT_STR, relId.getRelIdClient());
        }

        if (null != relId.getRelIdUuid()) {
            document.append(RELID_UUID_STR, relId.getRelIdUuid());
        }

        if (null != relId.getRelIdVersion()) {
            document.append(RELID_VERSION_STR, relId.getRelIdVersion().getValue());
        }

        if (null != relId.getRelIdStatus()) {
            document.append(RELID_STATUS_STR, relId.getRelIdStatus().name());
        }

        if (null != relId.getRelIdPreviousStatus()) {
            document.append(RELID_PREVIOUS_STATUS_STR, relId.getRelIdPreviousStatus().name());
        }

        if (null != relId.getRelIdCreatedTs()) {
            document.append(RELID_CREATEDTS_STR, relId.getRelIdCreatedTs());
        }

        if (null != relId.getRelIdUpdatedTs()) {
            document.append(RELID_UPDATEDTS_STR, relId.getRelIdUpdatedTs());
        }

        if (null != relId.getRelIdArchivedTs()) {
            document.append(RELID_ARCHIVEDTS_STR, relId.getRelIdArchivedTs());
        }

        if (null != relId.getRelIdArchivedOperation()) {
            document.append(RELID_ARCHIVED_OPERATION_STR, relId.getRelIdArchivedOperation().name());
        }

        if (null != relId.getVerKey()) {
            document.append(VER_KEY_STR, relId.getVerKey());
        }

        if (null != relId.getActCode()) {
            document.append(ACT_CODE_STR, relId.getActCode());
        }

        if (null != relId.getCipherSalt()) {
            document.append(CIPHER_SALT, relId.getCipherSalt());
        }

        if (null != relId.getActCodeExpiryTs()) {
            document.append(ACT_CODE_EXPIRYTS_STR, relId.getActCodeExpiryTs());
        }

        if (null != relId.getPasswordHash()) {
            document.append(PASSWORD_HASH_STR, relId.getPasswordHash());
        }

        if (null != relId.getPasswordUpdatedTs()) {
            document.append(PASSWORD_UPDATEDTS_STR, relId.getPasswordUpdatedTs());
        }

        document.append(PASSWORD_ATTEMPTS_LEFT_STR, relId.getPasswordAttemptsLeft());

        document.append(FORGOT_PASSWORD_ATTEMPTS_LEFT_STR, relId.getForgotPasswordAttemptsLeft());

        if (null != relId.getOldpasswords()) {
            document.append(OLD_PASSWORDS_STR, relId.getOldpasswords());
        }

        if (null != relId.getCredType()) {
            document.append(CRED_TYPE_STR, relId.getCredType());
        }

        if (null != relId.getDeviceUuid()) {
            document.append(DEVICE_UUID_STR, relId.getDeviceUuid());
        }

        if (null != relId.getDeviceName()) {
            document.append(DEVICE_NAME_STR, relId.getDeviceName());
        }

        if (null != relId.getDeviceStatus()) {
            document.append(DEVICE_STATUS_STR, relId.getDeviceStatus());
        }

        if (null != relId.getDeviceLastAccessedTs()) {
            document.append(DEVICE_LAST_ACCESSED_TS_STR, relId.getDeviceLastAccessedTs());
        }

        if (null != relId.getDevicePlatform()) {
            document.append(DEVICE_PLATFORM_STR, relId.getDevicePlatform());
        }

        if (null != relId.getDeviceToken()) {
            document.append(DEVICE_TOKEN_STR, relId.getDeviceToken());
        }

        if (null != relId.getDeviceType()) {
            document.append(DEVICE_TYPE_STR, relId.getDeviceType());
        }

        if (null != relId.getDeviceBind()) {
            document.append(DEVICE_BIND_STR, relId.getDeviceBind());
        }

        if (null != relId.getAppUuid()) {
            document.append(APP_UUID_STR, relId.getAppUuid());
        }

        if (null != relId.getCertPublicKey()) {
            document.append(CERT_PUBLIC_KEY, relId.getCertPublicKey());
        }

        if (null != relId.getTotpSeed()) {
            document.append(TOTP_SEED, relId.getTotpSeed());
        }

        if (null != relId.getHmac()) {
            document.append(HMAC, relId.getHmac());
        }

        if (null != relId.getTotpValidationMode()) {
            document.append(TOTP_VALIDATION_MODE, relId.getTotpValidationMode());
        }

        if (null != relId.getAppName()) {
            document.append(APP_NAME_STR, relId.getAppName());
        }

        document.append(HMAC_INDEX_VAL, relId.getHmacIndexVal());
        document.append(ENFORCE_MANUAL_PASS, relId.getEnforceManualPass());

        document.append(HMAC_INDEX_VAL, relId.getHmacIndexVal());

        document.append(DEVICE_INACTIVITY_NOTIFIED, relId.isDeviceInactivityNotified());

        document.append(IS_RE_INITIATING_WORKFLOW, relId.isReInitiatingWorkflow);

        if (null != relId.getLdaToken()) {
            document.append(LDA_TOKEN_STR, relId.getLdaToken());
        }

        return document;
    }

    /**
     * Create Bson Document document from the provided list of Device object
     * 
     * @param devices
     *            list of Device object
     * @return
     */
    public static List<Document> getBsonDocuments(final RelId... relids) {

        final List<Document> documents = new ArrayList<Document>();

        for (final RelId relid : relids) {
            documents.add(getBsonDocument(relid));
        }

        return documents;

    }

}
