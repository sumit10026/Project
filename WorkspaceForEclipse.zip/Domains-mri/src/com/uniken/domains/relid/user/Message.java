package com.uniken.domains.relid.user;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;

import com.uniken.domains.enums.AlertType;

public class Message {

    @Id
    private String id;
    private String mobileNumber;
    private String emailId;
    private Date createdTS;

    @Indexed
    private AlertType messageType;

    @Indexed
    private boolean isMessageProcessed;

    private String userId;
    private String verificationKey;
    private String activationCode;
    private Date expiryTS;
    private String primaryGroupName;
    private List<String> secondaryGroupNames;
    private String messageContent;
    private String messageSubject;
    private String firstName;
    private String lastName;

    private boolean isEmailSent;
    private Date emailSentTS;
    private boolean isSmsSent;
    private Date smsSentTS;

    private String dispatchOption;

    @Indexed
    private String status;
    private Date statusTs;

    private String appName;
    private String devName;
    private String devNameOld;
    private String smsComments;
    private String emailComments;
    private int dispatchAttemptsCounter;

    /**
     * @return mongodb ID
     */
    public String getId() {
        return id;
    }

    /**
     * @return mobile number.
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * Set mobile number.
     * 
     * @param mobileNumber
     */
    public void setMobileNumber(final String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    /**
     * @return Email ID
     */
    public String getEmailId() {
        return emailId;
    }

    /**
     * Set Email ID
     * 
     * @param emailId
     */
    public void setEmailId(final String emailId) {
        this.emailId = emailId;
    }

    /**
     * @return Created Timestamp.
     */
    public Date getCreatedTS() {
        return createdTS;
    }

    /**
     * Set Created Timestamp
     * 
     * @param createdTS
     */
    public void setCreatedTS(final Date createdTS) {
        this.createdTS = createdTS;
    }

    /**
     * @return message type
     */
    public AlertType getMessageType() {
        return messageType;
    }

    /**
     * Set Message type.
     * 
     * @param messageType
     */
    public void setMessageType(final AlertType messageType) {
        this.messageType = messageType;
    }

    public boolean isMessageProcessed() {
        return isMessageProcessed;
    }

    public void setMessageProcessed(final boolean isMessageProcessed) {
        this.isMessageProcessed = isMessageProcessed;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @return the verificationKey
     */
    public String getVerificationKey() {
        return verificationKey;
    }

    /**
     * @param verificationKey
     *            the verificationKey to set
     */
    public void setVerificationKey(final String verificationKey) {
        this.verificationKey = verificationKey;
    }

    /**
     * @return the activationCode
     */
    public String getActivationCode() {
        return activationCode;
    }

    /**
     * @param activationCode
     *            the activationCode to set
     */
    public void setActivationCode(final String activationCode) {
        this.activationCode = activationCode;
    }

    /**
     * @return the expiryTS
     */
    public Date getExpiryTS() {
        return expiryTS;
    }

    /**
     * @param expiryTS
     *            the expiryTS to set
     */
    public void setExpiryTS(final Date expiryTS) {
        this.expiryTS = expiryTS;
    }

    /**
     * @return the primaryGroupName
     */
    public String getPrimaryGroupName() {
        return primaryGroupName;
    }

    /**
     * @param primaryGroupName
     *            the primaryGroupName to set
     */
    public void setPrimaryGroupName(final String primaryGroupName) {
        this.primaryGroupName = primaryGroupName;
    }

    /**
     * @return the secondaryGroupNames
     */
    public List<String> getSecondaryGroupNames() {
        return secondaryGroupNames;
    }

    /**
     * @param secondaryGroupNames
     *            the secondaryGroupNames to set
     */
    public void setSecondaryGroupNames(final List<String> secondaryGroupNames) {
        this.secondaryGroupNames = secondaryGroupNames;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final String id) {
        this.id = id;
    }

    /**
     * @return the messageContent
     */
    public String getMessageContent() {
        return messageContent;
    }

    /**
     * @param messageContent
     *            the messageContent to set
     */
    public void setMessageContent(final String messageContent) {
        this.messageContent = messageContent;
    }

    /**
     * @return the messageSubject
     */
    public String getMessageSubject() {
        return messageSubject;
    }

    /**
     * @param messageSubject
     *            the messageSubject to set
     */
    public void setMessageSubject(final String messageSubject) {
        this.messageSubject = messageSubject;
    }

    /**
     * @return the isEmailSent
     */
    public boolean isEmailSent() {
        return isEmailSent;
    }

    /**
     * @param isEmailSent
     *            the isEmailSent to set
     */
    public void setEmailSent(final boolean isEmailSent) {
        this.isEmailSent = isEmailSent;
    }

    /**
     * @return the emailSentTS
     */
    public Date getEmailSentTS() {
        return emailSentTS;
    }

    /**
     * @param emailSentTS
     *            the emailSentTS to set
     */
    public void setEmailSentTS(final Date emailSentTS) {
        this.emailSentTS = emailSentTS;
    }

    /**
     * @return the isSmsSent
     */
    public boolean isSmsSent() {
        return isSmsSent;
    }

    /**
     * @param isSmsSent
     *            the isSmsSent to set
     */
    public void setSmsSent(final boolean isSmsSent) {
        this.isSmsSent = isSmsSent;
    }

    /**
     * @return the smsSentTS
     */
    public Date getSmsSentTS() {
        return smsSentTS;
    }

    /**
     * @param smsSentTS
     *            the smsSentTS to set
     */
    public void setSmsSentTS(final Date smsSentTS) {
        this.smsSentTS = smsSentTS;
    }

    /**
     * @return the dispatchOption
     */
    public String getDispatchOption() {
        return dispatchOption;
    }

    /**
     * @param dispatchOption
     *            the dispatchOption to set
     */
    public void setDispatchOption(final String dispatchOption) {
        this.dispatchOption = dispatchOption;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(final String status) {
        this.status = status;
    }

    public Date getStatusTs() {
        return statusTs;
    }

    public void setStatusTs(final Date statusTs) {
        this.statusTs = statusTs;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("Message [");
        builder.append("id=").append(id);
        if (null != mobileNumber)
            builder.append(", mobileNumber=").append(mobileNumber);
        if (null != emailId)
            builder.append(", emailId=").append(emailId);
        builder.append(", createdTS=").append(createdTS);
        if (null != messageType)
            builder.append(", messageType=").append(messageType);
        builder.append(", isMessageProcessed=").append(isMessageProcessed);
        builder.append(", userId=").append(userId);
        if (null != verificationKey)
            builder.append(", verificationKey=").append(verificationKey);
        if (null != activationCode)
            builder.append(", activationCode=").append(activationCode);
        if (null != expiryTS)
            builder.append(", expiryTS=").append(expiryTS.toString());
        if (null != primaryGroupName)
            builder.append(", primaryGroupName=").append(primaryGroupName);
        if (null != secondaryGroupNames)
            builder.append(", secondaryGroupNames=").append(secondaryGroupNames);
        if (null != messageContent)
            builder.append(", messageContent=").append(messageContent);
        if (null != messageSubject)
            builder.append(", messageSubject=").append(messageSubject);
        builder.append(", isEmailSent=").append(isEmailSent);
        if (null != emailSentTS)
            builder.append(", emailSentTS=").append(emailSentTS);
        builder.append(", isSmsSent=").append(isSmsSent);
        if (null != smsSentTS)
            builder.append(", smsSentTS=").append(smsSentTS);
        if (null != dispatchOption)
            builder.append(", dispatchOption=").append(dispatchOption);
        if (null != status)
            builder.append(", status=").append(status);
        if (null != statusTs)
            builder.append(", statusTs=").append(statusTs);
        if (null != firstName)
            builder.append(", firstName=").append(firstName);
        if (null != lastName)
            builder.append(", lastName=").append(lastName);
        if (null != appName)
            builder.append(", appName=").append(appName);
        if (null != devName)
            builder.append(", devName=").append(devName);
        if (null != devNameOld)
            builder.append(", devNameOld=").append(devNameOld);
        if (null != smsComments)
            builder.append(", smsComments=").append(smsComments);
        if (null != emailComments)
            builder.append(", emailComments=").append(emailComments);
        builder.append(", dispatchAttemptsCounter=").append(dispatchAttemptsCounter);
        if (null != userTS)
            builder.append(", userTS=").append(userTS);
        builder.append("]");
        return builder.toString();
    }

    private String createdTSStr;
    private String expiryTSStr;
    private String emailSentTSStr;
    private String smsSentTSStr;
    private String statusTsStr;

    public String getCreatedTSStr() {
        return createdTSStr;
    }

    public void setCreatedTSStr(final String createdTSStr) {
        this.createdTSStr = createdTSStr;
    }

    public String getExpiryTSStr() {
        return expiryTSStr;
    }

    public void setExpiryTSStr(final String expiryTSStr) {
        this.expiryTSStr = expiryTSStr;
    }

    public String getEmailSentTSStr() {
        return emailSentTSStr;
    }

    public void setEmailSentTSStr(final String emailSentTSStr) {
        this.emailSentTSStr = emailSentTSStr;
    }

    public String getSmsSentTSStr() {
        return smsSentTSStr;
    }

    public void setSmsSentTSStr(final String smsSentTSStr) {
        this.smsSentTSStr = smsSentTSStr;
    }

    public String getStatusTsStr() {
        return statusTsStr;
    }

    public void setStatusTsStr(final String statusTsStr) {
        this.statusTsStr = statusTsStr;
    }

    /**
     * @return the smsComments
     */
    public String getSmsComments() {
        return smsComments;
    }

    /**
     * @param smsComments
     *            the smsComments to set
     */
    public void setSmsComments(final String smsComments) {
        this.smsComments = smsComments;
    }

    /**
     * @return the emailComments
     */
    public String getEmailComments() {
        return emailComments;
    }

    /**
     * @param emailComments
     *            the emailComments to set
     */
    public void setEmailComments(final String emailComments) {
        this.emailComments = emailComments;
    }

    /**
     * @return dispatchAttemptscounter
     */
    public int getDispatchAttemptsCounter() {
        return dispatchAttemptsCounter;
    }

    /**
     * @param dispatchAttemptscounter
     */
    public void setDispatchAttemptsCounter(final int dispatchAttemptscounter) {
        this.dispatchAttemptsCounter = dispatchAttemptscounter;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(final String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(final String lastName) {
        this.lastName = lastName;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(final String appName) {
        this.appName = appName;
    }

    public String getDevName() {
        return devName;
    }

    public void setDevName(final String devName) {
        this.devName = devName;
    }

    public String getDevNameOld() {
        return devNameOld;
    }

    public void setDevNameOld(final String devNameOld) {
        this.devNameOld = devNameOld;
    }

    public void parseDateToString(final String dateFormat) {
        final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        if (null != this.createdTS)
            this.createdTSStr = sdf.format(this.createdTS);
        if (null != this.expiryTS)
            this.expiryTSStr = sdf.format(this.expiryTS);
        if (null != this.emailSentTS)
            this.emailSentTSStr = sdf.format(this.emailSentTS);
        if (null != this.smsSentTS)
            this.smsSentTSStr = sdf.format(this.smsSentTS);
        if (null != this.statusTs)
            this.statusTsStr = sdf.format(statusTs);
        if (null != this.userTS)
            this.userTSStr = sdf.format(userTS);

    }

    /**
     * @param sessionTicket
     * @return
     */
    public Document getBsonDocument(final Message message) {

        Document messageDoc = null;

        if (message != null) {

            messageDoc = new Document();

            if (message.getId() != null) {
                messageDoc.append("_id", message.getId());
            }

            if (message.getMobileNumber() != null) {
                messageDoc.append("mobileNumber", message.getMobileNumber());
            }

            if (message.getEmailId() != null) {
                messageDoc.append("emailId", message.getEmailId());
            }

            if (message.getCreatedTS() != null) {
                messageDoc.append("createdTS", message.getCreatedTS());
            }

            if (message.getMessageType() != null) {
                messageDoc.append("messageType", message.getMessageType().getAlertName());
            }

            messageDoc.append("isMessageProcessed", message.isMessageProcessed);

            if (message.getUserId() != null) {
                messageDoc.append("userId", message.getUserId());
            }

            if (message.getVerificationKey() != null) {
                messageDoc.append("verificationKey", message.getVerificationKey());
            }

            if (message.getActivationCode() != null) {
                messageDoc.append("activationCode", message.getActivationCode());
            }

            if (message.getExpiryTS() != null) {
                messageDoc.append("expiryTS", message.getExpiryTS());
            }

            if (message.getPrimaryGroupName() != null) {
                messageDoc.append("primaryGroupName", message.getPrimaryGroupName());
            }

            if (message.getSecondaryGroupNames() != null) {
                messageDoc.append("secondaryGroupNames", message.getSecondaryGroupNames());
            }

            if (message.getMessageContent() != null) {
                messageDoc.append("messageContent", message.getMessageContent());
            }

            if (message.getMessageSubject() != null) {
                messageDoc.append("messageSubject", message.getMessageSubject());
            }

            messageDoc.append("isEmailSent", message.isEmailSent());

            if (message.getEmailSentTS() != null) {
                messageDoc.append("emailSentTS", message.getEmailSentTS());
            }

            messageDoc.append("isSmsSent", message.isSmsSent());

            if (message.getSmsSentTS() != null) {
                messageDoc.append("smsSentTS", message.getSmsSentTS());
            }

            if (message.getDispatchOption() != null) {
                messageDoc.append("dispatchOption", message.getDispatchOption());
            }

            if (message.getStatus() != null) {
                messageDoc.append("status", message.getStatus());
            }

            if (message.getStatusTs() != null) {
                messageDoc.append("statusTs", message.getStatusTs());
            }

            if (message.getFirstName() != null) {
                messageDoc.append("firstName", message.getFirstName());
            }

            if (message.getLastName() != null) {
                messageDoc.append("lastName", message.getLastName());
            }

            if (message.getAppName() != null) {
                messageDoc.append("appName", message.getAppName());
            }

            if (message.getDevName() != null) {
                messageDoc.append("devName", message.getDevName());
            }

            if (message.getDevNameOld() != null) {
                messageDoc.append("devNameOld", message.getDevNameOld());
            }

            if (message.getSmsComments() != null) {
                messageDoc.append("smsComments", message.getSmsComments());
            }

            if (message.getEmailComments() != null) {
                messageDoc.append("emailComments", message.getEmailComments());
            }

            messageDoc.append("dispatchAttemptsCounter", message.getDispatchAttemptsCounter());

            if (message.getUserTS() != null) {
                messageDoc.append("userTS", message.getUserTS());
            }

        }

        return messageDoc;

    }

    private Date userTS;

    /**
     * @return the userTS
     */
    public Date getUserTS() {
        return userTS;
    }

    /**
     * @param userTS
     *            the userTS to set
     */
    public void setUserTS(final Date userTS) {
        this.userTS = userTS;
    }

    private String userTSStr;

    /**
     * @return the userTSStr
     */
    public String getUserTSStr() {
        return userTSStr;
    }

    /**
     * @param userTSStr
     *            the userTSStr to set
     */
    public void setUserTSStr(final String userTSStr) {
        this.userTSStr = userTSStr;
    }

}
