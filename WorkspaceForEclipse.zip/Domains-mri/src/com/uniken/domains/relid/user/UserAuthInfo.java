package com.uniken.domains.relid.user;

import java.util.ArrayDeque;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.enums.BiometricTemplateSource;
import com.uniken.domains.enums.RelIdType;
import com.uniken.domains.enums.RelIdUserStatus;
import com.uniken.domains.relid.LogDomain;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;
import com.uniken.domains.user.vos.WebUserDetails;

public class UserAuthInfo extends LogDomain {

    public static final String USER_AUTH_INFO_STR = "user_auth_info";

    public static final String ID_STR = "_id";
    public static final String USER_UUID_STR = "user_uuid";
    public static final String PRIVACY_KEY_STR = "privacy_key";
    public static final String REL_IDS_STR = "relids";
    public static final String USER_ID_STR = "user_id";
    public static final String LOGIN_ID_STR = "login_id";
    public static final String CREATE_TS_STR = "created_ts";
    public static final String UPDATE_TS_STR = "updated_ts";
    public static final String CIPHER_SPEC = "cipher_spec";
    public static final String SOURCE_TYPE = "source_type";
    public static final String COUNTER = "counter";
    public static final String DISTINGUISH_NAME = "distinguish_name";
    public static final String IS_RELID_ZERO_ENABLED_STR = "is_relId_zero_enabled";
    public static final String PREVIOUS_STATUS = "previous_status";
    public static final String USER_STATUS_STR = "user_status";
    public static final String REL_ID_TYPE_STR = "rel_id_type";
    public static final String PRIMARY_GROUP_UUID_STR = "primary_group_uuid";
    public static final String USNCHANGED_STR = "usn_changed";
    public static final String DEPARTMENT_STR = "department";
    public static final String FIRST_NAME_STR = "first_name";
    public static final String LAST_NAME_STR = "last_name";
    public static final String GM_USER_ID_STR = "gm_user_id";
    public static final String PRIMARY_GROUP_NAME_STR = "primary_group_name";
    public static final String SECONDARY_GROUP_UUIDS_STR = "secondary_group_uuids";
    public static final String SECONDARY_GROUP_NAMES_STR = "secondary_group_names";
    public static final String LAST_ACCESSED_TS_STR = "last_accessed_ts";
    public static final String LAST_ACCESSED_DEVICE_UUID_STR = "last_accessed_dev_uuid";
    public static final String USER_PASS = "user_pass";
    public static final String USER_PASS_UPDATED_TS = "user_pass_updated_ts";
    public static final String USER_PASS_CIPHER_SALT = "user_pass_cipher_salt";
    public static final String USER_PASS_ATTEMPTS_STR = "user_pass_attempts";
    public static final String FORGOT_USER_PASS_ATTEMPTS_LEFT_STR = "forgot_user_pass_attempts_left";
    public static final String OLD_USER_PASSWORDS_STR = "old_user_passwords";
    // public static final String LOGIN_IDS = "login_ids";
    public static final String EMAIL_ID_STR = "email_id";
    public static final String MOBILE_NUMBER_STR = "mobile_number";

    public static final String SERVER_BIO_TEMPLATE_HASH = "server_bio_template_hash";
    public static final String SERVER_BIO_TEMPLATE_SOURCE = "server_bio_template_source";
    public static final String SERVER_BIO_TEMPLATE_HASH_CREATED_TS = "server_bio_template_hash_created_ts";

    public static final String WEB_USER_DETAILS = "web_user_details";

    public static final String PREDEFINED_CODE_STR = "predefined_code";
    public static final String PREDEFINED_CODE_EXPIRYTS_STR = "predefined_code_expiry_ts";
    public static final String PREDEFINED_VER_KEY_STR = "predefined_ver_key";

    public static final String WEB_ONLY = "web_only";

    @SerializedName(value = ID_STR)
    private ObjectId id;

    @Indexed(unique = true)
    @SerializedName(USER_UUID_STR)
    @Field(USER_UUID_STR)
    private String userUuid;

    @Indexed(unique = true)
    @SerializedName(value = USER_ID_STR)
    @Field(USER_ID_STR)
    private String userId;

    @SerializedName(PRIVACY_KEY_STR)
    @Field(PRIVACY_KEY_STR)
    private String privacyKey;

    @SerializedName(value = REL_IDS_STR)
    @Field(REL_IDS_STR)
    private RelId relId;

    @SerializedName(value = LOGIN_ID_STR)
    @Field(LOGIN_ID_STR)
    private String loginId;

    @SerializedName(value = CREATE_TS_STR)
    @Field(CREATE_TS_STR)
    private Date createdTs;

    @SerializedName(value = UPDATE_TS_STR)
    @Field(UPDATE_TS_STR)
    private Date updatedTs;

    @SerializedName(value = CIPHER_SPEC)
    @Field(CIPHER_SPEC)
    private String cipherSpec;

    @SerializedName(value = SOURCE_TYPE)
    @Field(SOURCE_TYPE)
    private String sourceType;

    @SerializedName(value = COUNTER)
    @Field(COUNTER)
    private int counter;

    @SerializedName(value = DISTINGUISH_NAME)
    @Field(DISTINGUISH_NAME)
    private String distinguishName;

    @SerializedName(IS_RELID_ZERO_ENABLED_STR)
    @Field(IS_RELID_ZERO_ENABLED_STR)
    private Boolean isRelIdZeroEnabled;

    @SerializedName(PREVIOUS_STATUS)
    @Field(PREVIOUS_STATUS)
    private RelIdUserStatus previousStatus;

    @SerializedName(USER_STATUS_STR)
    @Field(USER_STATUS_STR)
    private RelIdUserStatus userStatus;

    @SerializedName(REL_ID_TYPE_STR)
    @Field(REL_ID_TYPE_STR)
    private RelIdType relIdType;

    @SerializedName(PRIMARY_GROUP_UUID_STR)
    @Field(PRIMARY_GROUP_UUID_STR)
    private String primaryGroupUuid;

    @SerializedName(USNCHANGED_STR)
    @Field(USNCHANGED_STR)
    private Long usnChanged;

    @SerializedName(DEPARTMENT_STR)
    @Field(DEPARTMENT_STR)
    private List<String> department;

    @SerializedName(FIRST_NAME_STR)
    @Field(FIRST_NAME_STR)
    private String firstName;

    @SerializedName(LAST_NAME_STR)
    @Field(LAST_NAME_STR)
    private String lastName;

    @SerializedName(GM_USER_ID_STR)
    @Field(GM_USER_ID_STR)
    private String gmUserId;

    @SerializedName(PRIMARY_GROUP_NAME_STR)
    @Field(PRIMARY_GROUP_NAME_STR)
    private String primaryGroupName;

    @SerializedName(SECONDARY_GROUP_UUIDS_STR)
    @Field(SECONDARY_GROUP_UUIDS_STR)
    private List<String> secondaryGroupUuids;

    @SerializedName(SECONDARY_GROUP_NAMES_STR)
    @Field(SECONDARY_GROUP_NAMES_STR)
    private List<String> secondaryGroupNames;

    @SerializedName(LAST_ACCESSED_TS_STR)
    @Field(LAST_ACCESSED_TS_STR)
    private Date lastAccessedTs;

    @SerializedName(LAST_ACCESSED_DEVICE_UUID_STR)
    @Field(LAST_ACCESSED_DEVICE_UUID_STR)
    private String lastAccessedDeviceUuid;

    private List<String> loginIds;

    @SerializedName(USER_PASS)
    @Field(USER_PASS)
    private String userPass;

    @SerializedName(value = USER_PASS_UPDATED_TS)
    @Field(USER_PASS_UPDATED_TS)
    private Date userPassUpdatedTs;

    @SerializedName(value = USER_PASS_CIPHER_SALT)
    @Field(USER_PASS_CIPHER_SALT)
    private String userPassCipherSalt;

    @SerializedName(USER_PASS_ATTEMPTS_STR)
    @Field(USER_PASS_ATTEMPTS_STR)
    private int userPassAttempts;

    @SerializedName(OLD_USER_PASSWORDS_STR)
    @Field(OLD_USER_PASSWORDS_STR)
    private ArrayDeque<String> oldUserPasswords;

    @SerializedName(EMAIL_ID_STR)
    @Field(EMAIL_ID_STR)
    private String emailId;

    @SerializedName(MOBILE_NUMBER_STR)
    @Field(MOBILE_NUMBER_STR)
    private String mobileNumber;

    @SerializedName(FORGOT_USER_PASS_ATTEMPTS_LEFT_STR)
    @Field(FORGOT_USER_PASS_ATTEMPTS_LEFT_STR)
    private int forgotUserPassAttemptsLeft;

    @SerializedName(SERVER_BIO_TEMPLATE_HASH)
    @Field(SERVER_BIO_TEMPLATE_HASH)
    private String serverBioTemplateHash;

    @SerializedName(SERVER_BIO_TEMPLATE_SOURCE)
    @Field(SERVER_BIO_TEMPLATE_SOURCE)
    private BiometricTemplateSource serverBioTemplateSource;

    @SerializedName(SERVER_BIO_TEMPLATE_HASH_CREATED_TS)
    @Field(SERVER_BIO_TEMPLATE_HASH_CREATED_TS)
    private Date serverBioTemplateHashCreatedTs;

    @SerializedName(WEB_USER_DETAILS)
    @Field(WEB_USER_DETAILS)
    private WebUserDetails webUserDetails;

    @SerializedName(PREDEFINED_CODE_STR)
    @Field(PREDEFINED_CODE_STR)
    private String predefinedCode;

    @SerializedName(PREDEFINED_VER_KEY_STR)
    @Field(PREDEFINED_VER_KEY_STR)
    private String predefinedVerKey;

    @SerializedName(PREDEFINED_CODE_EXPIRYTS_STR)
    @Field(PREDEFINED_CODE_EXPIRYTS_STR)
    private Date predefinedCodeExpiryTs;

    @SerializedName(WEB_ONLY)
    @Field(WEB_ONLY)
    private Boolean webOnly;

    public WebUserDetails getWebUserDetails() {
        if (webUserDetails == null) {
            webUserDetails = new WebUserDetails();
        }
        return webUserDetails;
    }

    public void setWebUserDetails(final WebUserDetails webUserDetails) {
        this.webUserDetails = webUserDetails;
    }

    public int getUserPassAttempts() {
        return userPassAttempts;
    }

    public void setUserPassAttempts(final int userPassAttempts) {
        this.userPassAttempts = userPassAttempts;
    }

    public ArrayDeque<String> getOldUserPasswords() {
        return oldUserPasswords;
    }

    public void setOldUserPasswords(final ArrayDeque<String> oldUserPasswords) {
        this.oldUserPasswords = oldUserPasswords;
    }

    /**
     */
    public UserAuthInfo() {
        super();
    }

    /**
     * @param relId
     * @param relIdType
     * @param userId
     * @param groupUuid
     */
    public UserAuthInfo(final RelId relId, final RelIdType relIdType, final String userId) {
        super();
        this.relId = relId;
        this.relIdType = relIdType;
        this.userId = userId;
    }

    /**
     * @param userUuid
     * @param userId
     * @param privacyKey
     * @param relId
     * @param loginIds
     * @param createdTs
     * @param updatedTs
     * @param cipherSpec
     * @param sourceType
     * @param counter
     * @param distinguishName
     * @param isRelIdZeroEnabled
     * @param previousStatus
     * @param userStatus
     * @param relIdType
     * @param groupUuid
     * @param primaryGroupUuid
     * @param usnChanged
     * @param department
     */
    private UserAuthInfo(final String userUuid, final String userId, final String loginId, final String privacyKey,
            final RelId relId, final Date createdTs, final Date updatedTs, final String cipherSpec,
            final String sourceType, final int counter, final String distinguishName, final Boolean isRelIdZeroEnabled,
            final RelIdUserStatus previousStatus, final RelIdUserStatus userStatus, final RelIdType relIdType,
            final String primaryGroupName, final List<String> secondaryGroupNames, final String primaryGroupUuid,
            final List<String> secondaryGroupUuids, final Long usnChanged, final List<String> department,
            final String firstName, final String lastName, final String userPass, final String userPassSalt,
            final String userPassSpec, final Date userPassUpdatedTs, final int userPassAttempts,
            final String serverBioTemplateHash, final String predefinedCode, final String predefinedVerKey,
            final Date predefinedCodeExpiryTs) {
        super();
        this.userUuid = userUuid;
        this.userId = userId;
        this.loginId = loginId;
        this.privacyKey = privacyKey;
        this.relId = relId;
        this.createdTs = createdTs;
        this.updatedTs = updatedTs;
        this.cipherSpec = cipherSpec;
        this.sourceType = sourceType;
        this.counter = counter;
        this.distinguishName = distinguishName;
        this.isRelIdZeroEnabled = isRelIdZeroEnabled;
        this.previousStatus = previousStatus;
        this.userStatus = userStatus;
        this.relIdType = relIdType;
        this.primaryGroupName = primaryGroupName;
        this.secondaryGroupNames = secondaryGroupNames;
        this.primaryGroupUuid = primaryGroupUuid;
        this.secondaryGroupUuids = secondaryGroupUuids;
        this.usnChanged = usnChanged;
        this.department = department;
        this.firstName = firstName;
        this.lastName = lastName;
        this.userPass = userPass;
        this.userPassCipherSalt = userPassSalt;
        this.userPassUpdatedTs = userPassUpdatedTs;
        this.userPassAttempts = userPassAttempts;
        this.serverBioTemplateHash = serverBioTemplateHash;
        this.predefinedCode = predefinedCode;
        this.predefinedVerKey = predefinedVerKey;
        this.predefinedCodeExpiryTs = predefinedCodeExpiryTs;
    }

    public static UserAuthInfo getUserAuthInfo(final UserAuthInfoVO vo, final RelId relId) {
        final UserAuthInfo userAuthInfo = new UserAuthInfo(vo.getUserUuid(), vo.getUserId(), vo.getLoginId(),
                vo.getPrivacyKey(), relId, vo.getCreatedTs(), vo.getUpdatedTs(), vo.getCipherSpec(), vo.getSourceType(),
                vo.getCounter(), vo.getDistinguishName(), vo.isRelIdZeroEnabled(), vo.getPreviousStatus(),
                vo.getUserStatus(), vo.getRelIdType(), vo.getPrimaryGroupName(), vo.getSecondaryGroupNames(),
                vo.getPrimaryGroupUuid(), vo.getSecondaryGroupUuids(), vo.getUsnChanged(), vo.getDepartment(),
                vo.getFirstName(), vo.getLastName(), vo.getUserPass(), vo.getUserPassCipherSalt(), vo.getCipherSpec(),
                vo.getUserPassUpdatedTs(), vo.getUserPassAttempts(), vo.getServerBioTemplateHash(),
                vo.getPredefinedCode(), vo.getPredefinedVerKey(), vo.getPredefinedCodeExpiryTs());
        userAuthInfo.setWebOnly(vo.isWebOnly());
        return userAuthInfo;
    }

    /**
     * @return the id
     */
    public ObjectId getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final ObjectId id) {
        this.id = id;
    }

    /**
     * @return the userUuid
     */
    public String getUserUuid() {
        return userUuid;
    }

    /**
     * @param userUuid
     *            the userUuid to set
     */
    public void setUserUuid(final String userUuid) {
        this.userUuid = userUuid;
    }

    /**
     * Gets privacy key of REL-ID.
     * 
     * @return the privacyKey
     */
    public String getPrivacyKey() {
        return privacyKey;
    }

    /**
     * Sets privacy key of REL-ID.
     * 
     * @param privacyKey
     *            the privacyKey to set
     */
    public void setPrivacyKey(final String privacyKey) {
        this.privacyKey = privacyKey;
    }

    /**
     * @return the userId
     */
    @Override
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    @Override
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @return the relId
     */
    public RelId getRelId() {
        return relId;
    }

    /**
     * @param relId
     *            the relId to set
     */
    public void setRelId(final RelId relId) {
        this.relId = relId;
    }

    /**
     * @return
     */
    public String getLoginId() {
        return loginId;
    }

    /**
     * @param loginId
     */
    public void setLoginId(final String loginId) {
        this.loginId = loginId;
    }

    /**
     * @return the createdTs
     */
    public Date getCreatedTs() {
        return createdTs;
    }

    /**
     * @param createdTs
     *            the createdTs to set
     */
    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }

    /**
     * @return the updatedTs
     */
    public Date getUpdatedTs() {
        return updatedTs;
    }

    /**
     * @param updatedTs
     *            the updatedTs to set
     */
    public void setUpdatedTs(final Date updatedTs) {
        this.updatedTs = updatedTs;
    }

    /**
     * @return the cipherSpec
     */
    public String getCipherSpec() {
        return cipherSpec;
    }

    /**
     * @param cipherSpec
     *            the cipherSpec to set
     */
    public void setCipherSpec(final String cipherSpec) {
        this.cipherSpec = cipherSpec;
    }

    /**
     * @return the sourceType
     */
    public String getSourceType() {
        return sourceType;
    }

    /**
     * @param sourceType
     *            the sourceType to set
     */
    public void setSourceType(final String sourceType) {
        this.sourceType = sourceType;
    }

    /**
     * @return the counter
     */
    public int getCounter() {
        return counter;
    }

    /**
     * @param counter
     *            the counter to set
     */
    public void setCounter(final int counter) {
        this.counter = counter;
    }

    /**
     * @return the distinguishName
     */
    public String getDistinguishName() {
        return distinguishName;
    }

    /**
     * @param distinguishName
     *            the distinguishName to set
     */
    public void setDistinguishName(final String distinguishName) {
        this.distinguishName = distinguishName;
    }

    /**
     * @return the isRelIdZeroEnabled
     */
    public Boolean isRelIdZeroEnabled() {
        return isRelIdZeroEnabled;
    }

    /**
     * @param isRelIdZeroEnabled
     *            the isRelIdZeroEnabled to set
     */
    public void setRelIdZeroEnabled(final Boolean isRelIdZeroEnabled) {
        this.isRelIdZeroEnabled = isRelIdZeroEnabled;
    }

    /**
     * @return the previousStatus
     */
    public RelIdUserStatus getPreviousStatus() {
        return previousStatus;
    }

    /**
     * @param previousStatus
     *            the previousStatus to set
     */
    public void setPreviousStatus(final RelIdUserStatus previousStatus) {
        this.previousStatus = previousStatus;
    }

    /**
     * @return the userStatus
     */
    public RelIdUserStatus getUserStatus() {
        return userStatus;
    }

    /**
     * @param userStatus
     *            the userStatus to set
     */
    public void setUserStatus(final RelIdUserStatus userStatus) {
        this.userStatus = userStatus;
    }

    /**
     * Gets type of REL-ID.
     * 
     * @return the relIdType
     */
    public RelIdType getRelIdType() {
        return relIdType;
    }

    /**
     * Sets type of REL-ID.
     * 
     * @param relIdType
     *            the relIdType to set
     */
    public void setRelIdType(final RelIdType relIdType) {
        this.relIdType = relIdType;
    }

    /**
     * Gets list primary group uuid of REL-ID.
     * 
     * @return the primaryGroupUuid
     */
    public String getPrimaryGroupUuid() {
        return primaryGroupUuid;
    }

    /**
     * Sets list of primary group uuid of REL-ID.
     * 
     * @param primaryGroupUuid
     *            the primaryGroupUuid to set
     */
    public void setPrimaryGroupUuid(final String primaryGroupUuid) {
        this.primaryGroupUuid = primaryGroupUuid;
    }

    /**
     * @return the usnChanged
     */
    public Long getUsnChanged() {
        return usnChanged;
    }

    /**
     * @param usnChanged
     *            the usnChanged to set
     */
    public void setUsnChanged(final Long usnChanged) {
        this.usnChanged = usnChanged;
    }

    /**
     * @return the department
     */
    public List<String> getDepartment() {
        return department;
    }

    /**
     * @param department
     *            the department to set
     */
    public void setDepartment(final List<String> department) {
        this.department = department;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName
     *            the firstName to set
     */
    public void setFirstName(final String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName
     *            the lastName to set
     */
    public void setLastName(final String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the gmUserId
     */
    public String getGmUserId() {
        return gmUserId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setGmUserId(final String gmUserId) {
        this.gmUserId = gmUserId;
    }

    /**
     * @return the primaryGroupName
     */
    public String getPrimaryGroupName() {
        return primaryGroupName;
    }

    /**
     * @param primaryGroupName
     *            the primaryGroupName to set
     */
    public void setPrimaryGroupName(final String primaryGroupName) {
        this.primaryGroupName = primaryGroupName;
    }

    /**
     * @return the secondaryGroupUuid
     */
    public List<String> getSecondaryGroupUuids() {
        return secondaryGroupUuids;
    }

    /**
     * @param secondaryGroupUuid
     *            the secondaryGroupUuid to set
     */
    public void setSecondaryGroupUuids(final List<String> secondaryGroupUuids) {
        this.secondaryGroupUuids = secondaryGroupUuids;
    }

    /**
     * @return the secondaryGroupNames
     */
    public List<String> getSecondaryGroupNames() {
        return secondaryGroupNames;
    }

    /**
     * @param secondaryGroupNames
     *            the secondaryGroupNames to set
     */
    public void setSecondaryGroupNames(final List<String> secondaryGroupNames) {
        this.secondaryGroupNames = secondaryGroupNames;
    }

    /**
     * @return the lastAccessedTs
     */
    public Date getLastAccessedTs() {
        return lastAccessedTs;
    }

    /**
     * @param lastAccessedTs
     *            the lastAccessedTs to set
     */
    public void setLastAccessedTs(final Date lastAccessedTs) {
        this.lastAccessedTs = lastAccessedTs;
    }

    /**
     * @return the lastAccessedDeviceUuid
     */
    public String getLastAccessedDeviceUuid() {
        return lastAccessedDeviceUuid;
    }

    /**
     * @param lastAccessedDeviceUuid
     *            the lastAccessedDeviceUuid to set
     */
    public void setLastAccessedDeviceUuid(final String lastAccessedDeviceUuid) {
        this.lastAccessedDeviceUuid = lastAccessedDeviceUuid;
    }

    /**
     * @return the loginIds
     */
    public List<String> getLoginIds() {
        return loginIds;
    }

    /**
     * @param loginIds
     *            the loginIds to set
     */
    public void setLoginIds(final List<String> loginIds) {
        this.loginIds = loginIds;
    }

    public String getUserPass() {
        return userPass;
    }

    public void setUserPass(final String userPass) {
        this.userPass = userPass;
    }

    public Date getUserPassUpdatedTs() {
        return userPassUpdatedTs;
    }

    public void setUserPassUpdatedTs(final Date userPassUpdatedTs) {
        this.userPassUpdatedTs = userPassUpdatedTs;
    }

    public String getUserPassCipherSalt() {
        return userPassCipherSalt;
    }

    public void setUserPassCipherSalt(final String userPassCipherSalt) {
        this.userPassCipherSalt = userPassCipherSalt;
    }

    public int getForgotUserPassAttemptsLeft() {
        return forgotUserPassAttemptsLeft;
    }

    public void setForgotUserPassAttemptsLeft(final int forgotUserPassAttemptsLeft) {
        this.forgotUserPassAttemptsLeft = forgotUserPassAttemptsLeft;
    }

    public String getServerBioTemplateHash() {
        return serverBioTemplateHash;
    }

    public void setServerBioTemplateHash(final String serverBioTemplateHash) {
        this.serverBioTemplateHash = serverBioTemplateHash;
    }

    /**
     * @return the serverBioTemplateSource
     */
    public BiometricTemplateSource getServerBioTemplateSource() {
        return serverBioTemplateSource;
    }

    /**
     * @param serverBioTemplateSource
     *            the serverBioTemplateSource to set
     */
    public void setServerBioTemplateSource(final BiometricTemplateSource serverBioTemplateSource) {
        this.serverBioTemplateSource = serverBioTemplateSource;
    }

    /**
     * @return the serverBioTemplateHashCreatedTs
     */
    public Date getServerBioTemplateHashCreatedTs() {
        return serverBioTemplateHashCreatedTs;
    }

    /**
     * @param serverBioTemplateHashCreatedTs
     *            the serverBioTemplateHashCreatedTs to set
     */
    public void setServerBioTemplateHashCreatedTs(final Date serverBioTemplateHashCreatedTs) {
        this.serverBioTemplateHashCreatedTs = serverBioTemplateHashCreatedTs;
    }

    /**
     * @return the predefinedCode
     */
    public String getPredefinedCode() {
        return predefinedCode;
    }

    /**
     * @param predefinedCode
     *            the predefinedCode to set
     */
    public void setPredefinedCode(final String predefinedCode) {
        this.predefinedCode = predefinedCode;
    }

    /**
     * @return the predefinedVerKey
     */
    public String getPredefinedVerKey() {
        return predefinedVerKey;
    }

    /**
     * @param predefinedVerKey
     *            the predefinedVerKey to set
     */
    public void setPredefinedVerKey(final String predefinedVerKey) {
        this.predefinedVerKey = predefinedVerKey;
    }

    /**
     * @return the predefinedCodeExpiryTs
     */
    public Date getPredefinedCodeExpiryTs() {
        return predefinedCodeExpiryTs;
    }

    /**
     * @param predefinedCodeExpiryTs
     *            the predefinedCodeExpiryTs to set
     */
    public void setPredefinedCodeExpiryTs(final Date predefinedCodeExpiryTs) {
        this.predefinedCodeExpiryTs = predefinedCodeExpiryTs;
    }

    /**
     * @return the webOnly
     */
    public Boolean isWebOnly() {
        return webOnly;
    }

    /**
     * @param webOnly
     *            the webOnly to set
     */
    public void setWebOnly(final Boolean webOnly) {
        this.webOnly = webOnly;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("User [id=");
        builder.append(id);
        builder.append(", userUuid=");
        builder.append(userUuid);
        builder.append(", privacyKey=");
        builder.append(privacyKey);
        builder.append(", userId=");
        builder.append(userId);
        builder.append(", loginId=");
        builder.append(loginId);
        builder.append(", relIds=");
        builder.append(relId);
        builder.append(", createdTs=");
        builder.append(createdTs);
        builder.append(", updatedTs=");
        builder.append(updatedTs);
        builder.append(", cipherSpec=");
        builder.append(cipherSpec);
        builder.append(", sourceType=");
        builder.append(sourceType);
        builder.append(", counter=");
        builder.append(counter);
        builder.append(", distinguishName=");
        builder.append(distinguishName);
        builder.append(", isRelIdZeroEnabled=");
        builder.append(isRelIdZeroEnabled);
        builder.append(", status=");
        builder.append(previousStatus);
        builder.append(", status=");
        builder.append(previousStatus);
        builder.append(", relIdType=");
        builder.append(relIdType);
        builder.append(", primaryGroupUuid=");
        builder.append(primaryGroupUuid);
        builder.append(", usnChanged=");
        builder.append(usnChanged);
        builder.append(", department=");
        builder.append(department);
        builder.append(", firstName=");
        builder.append(firstName);
        builder.append(", lastName=");
        builder.append(lastName);
        builder.append(", gmUserId=");
        builder.append(gmUserId);
        builder.append(", primaryGroupName=");
        builder.append(primaryGroupName);
        builder.append(", secondaryGroupUuids=");
        builder.append(secondaryGroupUuids);
        builder.append(", secondaryGroupNames=");
        builder.append(secondaryGroupNames);
        builder.append(", lastAccessedTs=");
        builder.append(lastAccessedTs);
        builder.append(", lastAccessedDeviceUuid=");
        builder.append(lastAccessedDeviceUuid);
        builder.append(", userPass=");
        builder.append(userPass);
        builder.append(", userPassUpdatedTs=");
        builder.append(userPassUpdatedTs);
        builder.append(", userPassCipherSalt=");
        builder.append(userPassCipherSalt);
        builder.append(", emailId=");
        builder.append(emailId);
        builder.append(", mobileNumber=");
        builder.append(mobileNumber);
        builder.append(", predefinedCode=");
        builder.append(predefinedCode);
        builder.append(", webOnly=");
        builder.append(webOnly);
        builder.append("]");
        return builder.toString();
    }

    /**
     * Create Bson Document document from the provided User object
     * 
     * @param User
     *            the User to be converted to a Bson Document
     * @return A Bson document
     */
    public static Document getBsonDocument(final UserAuthInfo user) {
        if (null == user) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != user.getId()) {
            logsDoc.append(ID_STR, user.getId());
        }

        if (null != user.getUserUuid()) {
            logsDoc.append(USER_UUID_STR, user.getUserUuid());
        }

        if (null != user.getPrivacyKey()) {
            logsDoc.append(PRIVACY_KEY_STR, user.getPrivacyKey());
        }

        if (null != user.getUserId()) {
            logsDoc.append(USER_ID_STR, user.getUserId());
        }

        if (null != user.getLoginId()) {
            logsDoc.append(LOGIN_ID_STR, user.getLoginId());
        }

        if (null != user.getRelId()) {
            logsDoc.append(REL_IDS_STR, RelId.getBsonDocuments(user.getRelId()));
        }

        if (null != user.getCreatedTs()) {
            logsDoc.append(CREATE_TS_STR, user.getCreatedTs());
        }

        if (null != user.getUpdatedTs()) {
            logsDoc.append(UPDATE_TS_STR, user.getUpdatedTs());
        }

        if (null != user.getCipherSpec()) {
            logsDoc.append(CIPHER_SPEC, user.getCipherSpec());
        }

        if (null != user.getSourceType()) {
            logsDoc.append(SOURCE_TYPE, user.getSourceType());
        }

        logsDoc.append(COUNTER, user.getCounter());

        if (null != user.getDistinguishName()) {
            logsDoc.append(DISTINGUISH_NAME, user.getDistinguishName());
        }

        if (null != user.isRelIdZeroEnabled()) {
            logsDoc.append(IS_RELID_ZERO_ENABLED_STR, user.isRelIdZeroEnabled());
        }

        if (null != user.getPreviousStatus()) {
            logsDoc.append(PREVIOUS_STATUS, user.getPreviousStatus());
        }

        if (null != user.getUserStatus()) {
            logsDoc.append(USER_STATUS_STR, user.getUserStatus());
        }

        if (null != user.getRelIdType()) {
            logsDoc.append(REL_ID_TYPE_STR, user.getRelIdType());
        }

        if (null != user.getPrimaryGroupUuid()) {
            logsDoc.append(PRIMARY_GROUP_UUID_STR, user.getPrimaryGroupUuid());
        }

        if (null != user.getUsnChanged()) {
            logsDoc.append(USNCHANGED_STR, user.getUsnChanged());
        }

        if (null != user.getDepartment()) {
            logsDoc.append(DEPARTMENT_STR, user.getDepartment());
        }

        if (null != user.getFirstName()) {
            logsDoc.append(FIRST_NAME_STR, user.getFirstName());
        }

        if (null != user.getLastName()) {
            logsDoc.append(LAST_NAME_STR, user.getLastName());
        }

        if (null != user.getGmUserId()) {
            logsDoc.append(GM_USER_ID_STR, user.getGmUserId());
        }

        if (null != user.getPrimaryGroupName()) {
            logsDoc.append(PRIMARY_GROUP_NAME_STR, user.getPrimaryGroupName());
        }

        if (null != user.getSecondaryGroupUuids()) {
            logsDoc.append(SECONDARY_GROUP_UUIDS_STR, user.getSecondaryGroupUuids());
        }

        if (null != user.getSecondaryGroupNames()) {
            logsDoc.append(SECONDARY_GROUP_NAMES_STR, user.getSecondaryGroupNames());
        }

        if (null != user.getLastAccessedTs()) {
            logsDoc.append(LAST_ACCESSED_TS_STR, user.getLastAccessedTs());
        }

        if (null != user.getLastAccessedDeviceUuid()) {
            logsDoc.append(LAST_ACCESSED_DEVICE_UUID_STR, user.getLastAccessedDeviceUuid());
        }

        if (null != user.getUserPass()) {
            logsDoc.append(USER_PASS, user.getUserPass());
        }

        if (null != user.getUserPassUpdatedTs()) {
            logsDoc.append(USER_PASS_UPDATED_TS, user.getUserPassUpdatedTs());
        }

        if (null != user.getUserPassCipherSalt()) {
            logsDoc.append(USER_PASS_CIPHER_SALT, user.getUserPassCipherSalt());
        }

        logsDoc.append(USER_PASS_ATTEMPTS_STR, user.getUserPassAttempts());

        logsDoc.append(FORGOT_USER_PASS_ATTEMPTS_LEFT_STR, user.getForgotUserPassAttemptsLeft());

        if (null != user.getOldUserPasswords()) {
            logsDoc.append(OLD_USER_PASSWORDS_STR, user.getOldUserPasswords());
        }

        if (null != user.getEmailId()) {
            logsDoc.append(EMAIL_ID_STR, user.getEmailId());
        }

        if (null != user.getMobileNumber()) {
            logsDoc.append(MOBILE_NUMBER_STR, user.getMobileNumber());
        }

        if (null != user.getPredefinedCode()) {
            logsDoc.append(PREDEFINED_CODE_STR, user.getPredefinedCode());
        }

        if (null != user.getPredefinedVerKey()) {
            logsDoc.append(PREDEFINED_VER_KEY_STR, user.getPredefinedVerKey());
        }

        if (null != user.getPredefinedCodeExpiryTs()) {
            logsDoc.append(PREDEFINED_CODE_EXPIRYTS_STR, user.getPredefinedCodeExpiryTs());
        }

        if (null != user.isWebOnly()) {
            logsDoc.append(WEB_ONLY, user.isWebOnly());
        }

        return logsDoc;
    }

    /**
     * This method will identify the relid and return its attempt count of user
     * object.
     * 
     * @param state
     * @return attemptCount.
     */
    public int getPasswordAttemptCounter(final String relidUuid) {
        return relId.getPasswordAttemptsLeft();
    }

    /**
     * This method will identify the relid and return its attempt count of user
     * object.
     * 
     * @param state
     * @return attemptCount.
     */
    public void setPasswordAttemptCounter(final String relidUuid, final int attemptCounter) {
        relId.setPasswordAttemptsLeft(attemptCounter);
    }

    /**
     * @return the emailId
     */
    public String getEmailId() {
        return emailId;
    }

    /**
     * @param emailId
     *            the emailId to set
     */
    public void setEmailId(final String emailId) {
        this.emailId = emailId;
    }

    /**
     * @return the mobileNumber
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * @param mobileNumber
     *            the mobileNumber to set
     */
    public void setMobileNumber(final String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

}
