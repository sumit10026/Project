package com.uniken.domains.relid.user;

import java.util.Date;
import java.util.Set;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

public class UserBrowser {

    public static final String ID_STR = "_id";
    public static final String WEB_DEVICE_UUID_STR = "web_device_uuid";
    public static final String STATUS = "status";
    public static final String CREATED_TS = "created_ts";
    public static final String LAST_LOGIN_TS = "last_login_ts";
    public static final String LAST_LOGIN_METHOD = "last_login_method";
    public static final String ARCHIVED_TS = "archived_ts";
    public static final String USER_OPTED_OUT_FOR_FIDO_REG = "user_opted_out_for_fido_reg";
    public static final String AUTHENTICATOR_UUID = "authenticator_uuid";
    public static final String ADDED_FOR_AUTHENTICATOR = "added_for_authenticator";

    @SerializedName(value = ID_STR)
    @Field(ID_STR)
    private ObjectId id;

    @SerializedName(WEB_DEVICE_UUID_STR)
    @Field(WEB_DEVICE_UUID_STR)
    private String webDeviceUuid;

    @SerializedName(STATUS)
    @Field(STATUS)
    private String status;

    @SerializedName(CREATED_TS)
    @Field(CREATED_TS)
    private Date createdTs;

    @SerializedName(LAST_LOGIN_TS)
    @Field(LAST_LOGIN_TS)
    private Date lastLoginTs;

    @SerializedName(LAST_LOGIN_METHOD)
    @Field(LAST_LOGIN_METHOD)
    private Set<String> lastLoginMehod;

    @SerializedName(ARCHIVED_TS)
    @Field(ARCHIVED_TS)
    private Date archivedTS;

    @SerializedName(USER_OPTED_OUT_FOR_FIDO_REG)
    @Field(USER_OPTED_OUT_FOR_FIDO_REG)
    private boolean userOptedOutForFidoReg;

    @SerializedName(AUTHENTICATOR_UUID)
    @Field(AUTHENTICATOR_UUID)
    private String authenticatorUuid;

    @SerializedName(ADDED_FOR_AUTHENTICATOR)
    @Field(ADDED_FOR_AUTHENTICATOR)
    private boolean addedForAuthenticator;

    public boolean isUserOptedOutForFidoReg() {
        return userOptedOutForFidoReg;
    }

    public void setUserOptedOutForFidoReg(final boolean userOptedOutForFidoReg) {
        this.userOptedOutForFidoReg = userOptedOutForFidoReg;
    }

    public boolean isAddedForAuthenticator() {
        return addedForAuthenticator;
    }

    public void setAddedForAuthenticator(final boolean addedForAuthenticator) {
        this.addedForAuthenticator = addedForAuthenticator;
    }

    public String getAuthenticatorUuid() {
        return authenticatorUuid;
    }

    public void setAuthenticatorUuid(final String authenticatorUuid) {
        this.authenticatorUuid = authenticatorUuid;
    }

    /**
     * @return the id
     */
    public ObjectId getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final ObjectId id) {
        this.id = id;
    }

    public String getWebDeviceUuid() {
        return webDeviceUuid;
    }

    public void setWebDeviceUuid(final String webDeviceUuid) {
        this.webDeviceUuid = webDeviceUuid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(final String status) {
        this.status = status;
    }

    public Date getCreatedTs() {
        return createdTs;
    }

    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }

    public Date getLastLoginTs() {
        return lastLoginTs;
    }

    public void setLastLoginTs(final Date lastLoginTs) {
        this.lastLoginTs = lastLoginTs;
    }

    public Set<String> getLastLoginMehod() {
        return lastLoginMehod;
    }

    public void setLastLoginMehod(final Set<String> lastLoginMehod) {
        this.lastLoginMehod = lastLoginMehod;
    }

    public Date getArchivedTS() {
        return archivedTS;
    }

    public void setArchivedTS(final Date archivedTS) {
        this.archivedTS = archivedTS;
    }

}
