package com.uniken.domains.relid.user;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class Param {

    public static final String UUID_KEY = "uuidkey";

    public static final String PARAMS = "params";

    @SerializedName(value = UUID_KEY)
    private String uuidKey;

    @SerializedName(value = PARAMS)
    private List<ParentParam> params;

    public String getUuidKey() {
        return uuidKey;
    }

    public void setUuidKey(final String uuidKey) {
        this.uuidKey = uuidKey;
    }

    public List<ParentParam> getParams() {
        return params;
    }

    public void setParams(final List<ParentParam> params) {
        this.params = params;
    }

}
