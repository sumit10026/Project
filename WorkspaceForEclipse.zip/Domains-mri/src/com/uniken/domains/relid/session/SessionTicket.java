package com.uniken.domains.relid.session;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.enums.RelIdVersion;
import com.uniken.domains.idv.util.IDVAuditingTemplate;
import com.uniken.domains.relid.challenge.Challenge;
import com.uniken.domains.relid.device.DfpParameters;

public class SessionTicket {

    public static final String ID = "_id";
    public final static String SESSION_TICKET_ID = "session_id";
    public final static String UUID = "uuid";
    public final static String DEVICE_UUID = "device_uuid";
    public final static String PRIVACY_KEY = "privacy_key";
    public final static String STATE = "state";
    public final static String CREATED_TS = "created_ts";
    public final static String EXPIRY_TS = "expiry_ts";
    public final static String UPDATED_TS = "updated_ts";
    public final static String STATUS_STR = "status";
    public final static String SESSION_TYPE_STR = "session_type";
    public final static String APP_SESSION_ID = "app_session_id";
    public final static String APP_UUID = "app_uuid";
    public final static String APP_AGENT_NAME = "app_agent_name";
    public final static String USER_ID = "user_id";
    public final static String RELID_VERSION = "relid_version";
    public final static String ARCHIVED_TS = "archived_ts";
    public final static String RELID_SERVER_PART = "relid_server";
    public final static String DEVICE_DETAILS = "device_details";
    public final static String JWT = "jwt";
    public final static String LOGIN_ID = "login_id";
    public final static String LAST_ACCESS_TS = "last_access_ts";
    public final static String IDLE_TIMEOUT_TS = "idle_timeout_ts";
    public final static String CLIENT_IP_ADDRESS = "client_ip_address";
    public static final String PRIMARY_GROUP_NAME_STR = "primary_group_name";
    public static final String SECONDARY_GROUP_NAMES_STR = "secondary_group_names";
    public static final String PENDING_CHALLENGES_STR = "pending_challenges";
    public static final String IN_PROCESS_CHALLENGE_STR = "in_process_challenge";
    public static final String AUTHENTICATED_WITH_STR = "authenticated_with";

    public final static String DEVICE_NAME = "device_name";
    public final static String LOGOUT_TS = "logout_ts";
    public final static String SESSION_EXPIRY_TS = "session_expiry_ts";
    public final static String SESSION_EXPIRED_BY = "session_expired_by";
    public final static String LOGOUT_CLIENT_IP_ADDRESS = "logout_client_ip_address";
    public final static String APP_NAME = "app_name";
    public final static String APP_VERSION = "app_version";

    public final static String IDV_AUDIT_INFO = "idv_audit_info";

    @SerializedName(ID)
    private Object id;

    @SerializedName(SESSION_TICKET_ID)
    @Field(SESSION_TICKET_ID)
    private String sessionId;

    @SerializedName(UUID)
    @Field(UUID)
    private String uuid;

    @SerializedName(DEVICE_UUID)
    @Field(DEVICE_UUID)
    private String deviceUuid;

    @SerializedName(PRIVACY_KEY)
    @Field(PRIVACY_KEY)
    private String privacyKey;

    @SerializedName(STATE)
    @Field(STATE)
    private String state;

    @SerializedName(CREATED_TS)
    @Field(CREATED_TS)
    private Date createdTs;

    @SerializedName(EXPIRY_TS)
    @Field(EXPIRY_TS)
    private Date expiryTs;

    @SerializedName(UPDATED_TS)
    @Field(UPDATED_TS)
    private Date updatedTs;

    @SerializedName(STATUS_STR)
    @Field(STATUS_STR)
    private String status;

    @SerializedName(SESSION_TYPE_STR)
    @Field(SESSION_TYPE_STR)
    private String sessionType;

    @SerializedName(APP_SESSION_ID)
    @Field(APP_SESSION_ID)
    private String appSessionId;

    @SerializedName(APP_UUID)
    @Field(APP_UUID)
    private String appUuid;

    @SerializedName(APP_AGENT_NAME)
    @Field(APP_AGENT_NAME)
    private String appAgentName;

    @SerializedName(USER_ID)
    @Field(USER_ID)
    private String userId;

    @SerializedName(RELID_VERSION)
    @Field(RELID_VERSION)
    private RelIdVersion relIdVersion;

    @SerializedName(ARCHIVED_TS)
    @Field(ARCHIVED_TS)
    private Date archivedTs;

    @SerializedName(RELID_SERVER_PART)
    @Field(RELID_SERVER_PART)
    private String relidServerPart;

    @SerializedName(DEVICE_DETAILS)
    @Field(DEVICE_DETAILS)
    private DfpParameters dfp;

    @SerializedName(JWT)
    @Field(JWT)
    private String jwt;

    @SerializedName(LOGIN_ID)
    @Field(LOGIN_ID)
    private String loginId;

    @SerializedName(LAST_ACCESS_TS)
    @Field(LAST_ACCESS_TS)
    private Date lastAccessTs;

    @SerializedName(IDLE_TIMEOUT_TS)
    @Field(IDLE_TIMEOUT_TS)
    private Date idleTimeoutTs;

    @SerializedName(CLIENT_IP_ADDRESS)
    @Field(CLIENT_IP_ADDRESS)
    private String clientIpAddress;

    @SerializedName(PRIMARY_GROUP_NAME_STR)
    @Field(PRIMARY_GROUP_NAME_STR)
    private String primaryGroupName;

    @SerializedName(SECONDARY_GROUP_NAMES_STR)
    @Field(SECONDARY_GROUP_NAMES_STR)
    private List<String> secondaryGroupNames;

    @SerializedName(PENDING_CHALLENGES_STR)
    @Field(PENDING_CHALLENGES_STR)
    private List<Challenge> pendingChallenges;

    @SerializedName(IN_PROCESS_CHALLENGE_STR)
    @Field(IN_PROCESS_CHALLENGE_STR)
    private Challenge inProcessChallenge;

    @SerializedName(AUTHENTICATED_WITH_STR)
    @Field(AUTHENTICATED_WITH_STR)
    private String authenticatedWith;

    @SerializedName(IDV_AUDIT_INFO)
    @Field(IDV_AUDIT_INFO)
    private IDVAuditingTemplate idvAuditInfo;

    /**
     * Default Constructor.
     */
    public SessionTicket() {
        super();
    }

    /**
     * Create SessionTicket object in case of APP_SESSION.
     * 
     * @param sessionTicketId
     *            the session ticket Id
     * @param uuid
     *            the UUID of app agent in case of APP_SESSION and user UUID in
     *            case of USER_SESSION
     * @param deviceUuid
     *            the device UUID.
     * @param privacyKey
     *            the privacy case
     * @param createdTs
     *            the created time stamp
     * @param expiryTs
     *            the expiry time stamp
     * @param status
     *            the session status.
     * @param sessionType
     *            the session type
     * @param appAgentName
     *            the app agent name for which session ticket is created.
     * @param relIdVersion
     *            the {@link RelIdVersion}
     * @param appUuid
     *            the app agent uuid.
     * @param dfp
     *            device params
     * @param lastAccessTs
     *            last access timestamp
     */
    public SessionTicket(final String sessionTicketId, final String uuid, final String deviceUuid,
            final String privacyKey, final Date createdTs, final Date expiryTs, final String status,
            final String sessionType, final String appAgentName, final RelIdVersion relIdVersion, final String appUuid,
            final DfpParameters dfp, final Date lastAccessTs, final Date idleTimeoutTs, final String clientIpAddress,
            final String deviceName, final String appName, final String appVersion) {
        super();
        this.sessionId = sessionTicketId;
        this.uuid = uuid;
        this.deviceUuid = deviceUuid;
        this.privacyKey = privacyKey;
        this.createdTs = createdTs;
        this.expiryTs = expiryTs;
        this.status = status;
        this.sessionType = sessionType;
        this.appAgentName = appAgentName;
        this.relIdVersion = relIdVersion;
        this.appUuid = appUuid;
        this.dfp = dfp;
        this.lastAccessTs = lastAccessTs;
        this.idleTimeoutTs = idleTimeoutTs;
        this.clientIpAddress = clientIpAddress;
        this.deviceName = deviceName;
        this.appName = appName;
        this.appVersion = appVersion;
    }

    /**
     * Create SessionTicket object in case of USER_SESSION.
     * 
     * @param sessionId
     *            the session ticket id
     * @param uuid
     *            the UUID of app agent REL-ID in case of APP_SESSION and user
     *            UUID in case of USER_SESSION
     * @param deviceUuid
     *            the device UUID.
     * @param privacyKey
     *            the privacy case
     * @param createdTs
     *            the created time stamp
     * @param expiryTs
     *            the expiry time stamp
     * @param status
     *            the session status.
     * @param sessionType
     *            the session type
     * @param appSessionId
     *            the app session ticket id
     * @param appUuid
     *            the app agent UUID
     * @param appAgentName
     *            : app agent name
     * @param userName
     *            the user name for which session ticket is created.
     * @param relIdVersion
     *            version of REL-ID
     * @param dfp
     *            device params
     * @param lastAccessTs
     *            last access timestamp
     */
    public SessionTicket(final String sessionId, final String uuid, final String deviceUuid, final String privacyKey,
            final Date createdTs, final Date expiryTs, final String status, final String sessionType,
            final String appSessionId, final String appUuid, final String appAgentName, final String userId,
            final RelIdVersion relIdVersion, final DfpParameters dfp, final String loginId, final Date lastAccessTs,
            final Date idleTimeoutTs, final String clientIpAddress, final String primaryGroupName,
            final List<String> secondaryGroupNames, final String authenticatedWith, final String deviceName,
            final String appName, final String appVersion) {
        super();
        this.sessionId = sessionId;
        this.uuid = uuid;
        this.deviceUuid = deviceUuid;
        this.privacyKey = privacyKey;
        this.createdTs = createdTs;
        this.expiryTs = expiryTs;
        this.status = status;
        this.sessionType = sessionType;
        this.appSessionId = appSessionId;
        this.appUuid = appUuid;
        this.appAgentName = appAgentName;
        this.userId = userId;
        this.relIdVersion = relIdVersion;
        this.dfp = dfp;
        this.loginId = loginId;
        this.lastAccessTs = lastAccessTs;
        this.idleTimeoutTs = idleTimeoutTs;
        this.clientIpAddress = clientIpAddress;
        this.primaryGroupName = primaryGroupName;
        this.secondaryGroupNames = secondaryGroupNames;
        this.authenticatedWith = authenticatedWith;
        this.deviceName = deviceName;
        this.appName = appName;
        this.appVersion = appVersion;
    }

    /**
     * @return the id
     */
    public Object getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final Object id) {
        this.id = id;
    }

    /**
     * @return the sessionId
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * @param sessionId
     *            the sessionId to set
     */
    public void setSessionId(final String sessionId) {
        this.sessionId = sessionId;
    }

    /**
     * @return the uuid
     */
    public String getUuid() {
        return uuid;
    }

    /**
     * @param uuid
     *            the uuid to set
     */
    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    /**
     * @return the deviceUuid
     */
    public String getDeviceUuid() {
        return deviceUuid;
    }

    /**
     * @param deviceUuid
     *            the deviceUuid to set
     */
    public void setDeviceUuid(final String deviceUuid) {
        this.deviceUuid = deviceUuid;
    }

    /**
     * @return the privacyKey
     */
    public String getPrivacyKey() {
        return privacyKey;
    }

    /**
     * @param privacyKey
     *            the privacyKey to set
     */
    public void setPrivacyKey(final String privacyKey) {
        this.privacyKey = privacyKey;
    }

    /**
     * @return the state
     */
    public String getState() {
        return state;
    }

    /**
     * @param state
     *            the state to set
     */
    public void setState(final String state) {
        this.state = state;
    }

    /**
     * @return the createdTs
     */
    public Date getCreatedTs() {
        return createdTs;
    }

    /**
     * @param createdTs
     *            the createdTs to set
     */
    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }

    /**
     * @return the expiryTs
     */
    public Date getExpiryTs() {
        return expiryTs;
    }

    /**
     * @param expiryTs
     *            the expiryTs to set
     */
    public void setExpiryTs(final Date expiryTs) {
        this.expiryTs = expiryTs;
    }

    /**
     * @return the updatedTs
     */
    public Date getUpdatedTs() {
        return updatedTs;
    }

    /**
     * @param updatedTs
     *            the updatedTs to set
     */
    public void setUpdatedTs(final Date updatedTs) {
        this.updatedTs = updatedTs;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(final String status) {
        this.status = status;
    }

    /**
     * @return the sessionType
     */
    public String getSessionType() {
        return sessionType;
    }

    /**
     * @param sessionType
     *            the sessionType to set
     */
    public void setSessionType(final String sessionType) {
        this.sessionType = sessionType;
    }

    /**
     * @return the appSessionId
     */
    public String getAppSessionId() {
        return appSessionId;
    }

    /**
     * @param appSessionId
     *            the appSessionId to set
     */
    public void setAppSessionId(final String appSessionId) {
        this.appSessionId = appSessionId;
    }

    /**
     * @return the appUuid
     */
    public String getAppUuid() {
        return appUuid;
    }

    /**
     * @param appUuid
     *            the appUuid to set
     */
    public void setAppUuid(final String appUuid) {
        this.appUuid = appUuid;
    }

    /**
     * @return the appAgentName
     */
    public String getAppAgentName() {
        return appAgentName;
    }

    /**
     * @param appAgentName
     *            the appAgentName to set
     */
    public void setAppAgentName(final String appAgentName) {
        this.appAgentName = appAgentName;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    public RelIdVersion getRelIdVersion() {
        return relIdVersion;
    }

    public void setRelIdVersion(final RelIdVersion relIdVersion) {
        this.relIdVersion = relIdVersion;
    }

    public DfpParameters getDfp() {
        return dfp;
    }

    public void setDfp(final DfpParameters dfp) {
        this.dfp = dfp;
    }

    /**
     * @return the archivedTs
     */
    public Date getArchivedTs() {
        return archivedTs;
    }

    /**
     * @param archivedTs
     *            the archivedTs to set
     */
    public void setArchivedTs(final Date archivedTs) {
        this.archivedTs = archivedTs;
    }

    public String getRelidServer() {
        return relidServerPart;
    }

    public void setRelidServer(final String relidServerPart) {
        this.relidServerPart = relidServerPart;
    }

    /**
     * @return the jwt
     */
    public String getJwt() {
        return jwt;
    }

    /**
     * @param jwt
     *            the jwt to set
     */
    public void setJwt(final String jwt) {
        this.jwt = jwt;
    }

    /**
     * @return the loginId
     */
    public String getLoginId() {
        return loginId;
    }

    /**
     * @param loginId
     *            the loginId to set
     */
    public void setLoginId(final String loginId) {
        this.loginId = loginId;
    }

    /**
     * @return the lastAccessTs
     */
    public Date getLastAccessTs() {
        return lastAccessTs;
    }

    /**
     * @param lastAccessTs
     *            the lastAccessTs to set
     */
    public void setLastAccessTs(final Date lastAccessTs) {
        this.lastAccessTs = lastAccessTs;
    }

    /**
     * @return the idleTimeoutTs
     */
    public Date getIdleTimeoutTs() {
        return idleTimeoutTs;
    }

    /**
     * @param idleTimeoutTs
     *            the idleTimeoutTs to set
     */
    public void setIdleTimeoutTs(final Date idleTimeoutTs) {
        this.idleTimeoutTs = idleTimeoutTs;
    }

    public String getClientIpAddress() {
        return clientIpAddress;
    }

    public void setClientIpAddress(final String clientIpAddress) {
        this.clientIpAddress = clientIpAddress;
    }

    /**
     * @return the primaryGroupName
     */
    public String getPrimaryGroupName() {
        return primaryGroupName;
    }

    /**
     * @param primaryGroupName
     *            the primaryGroupName to set
     */
    public void setPrimaryGroupName(final String primaryGroupName) {
        this.primaryGroupName = primaryGroupName;
    }

    /**
     * @return the secondaryGroupNames
     */
    public List<String> getSecondaryGroupNames() {
        return secondaryGroupNames;
    }

    /**
     * @param secondaryGroupNames
     *            the secondaryGroupNames to set
     */
    public void setSecondaryGroupNames(final List<String> secondaryGroupNames) {
        this.secondaryGroupNames = secondaryGroupNames;
    }

    /**
     * @return the pendingChallenges
     */
    public List<Challenge> getPendingChallenges() {
        return pendingChallenges;
    }

    /**
     * @param pendingChallenges
     *            the pendingChallenges to set
     */
    public void setPendingChallenges(final List<Challenge> pendingChallenges) {
        this.pendingChallenges = pendingChallenges;
    }

    /**
     * @return the inProcessChallenge
     */
    public Challenge getInProcessChallenge() {
        return inProcessChallenge;
    }

    /**
     * @param inProcessChallenge
     *            the inProcessChallenge to set
     */
    public void setInProcessChallenge(final Challenge inProcessChallenge) {
        this.inProcessChallenge = inProcessChallenge;
    }

    /**
     * @return the authenticatedWith
     */
    public String getAuthenticatedWith() {
        return authenticatedWith;
    }

    /**
     * @param authenticatedWith
     *            the authenticatedWith to set
     */
    public void setAuthenticatedWith(final String authenticatedWith) {
        this.authenticatedWith = authenticatedWith;
    }

    /**
     * @param sessionTicket
     * @return
     */
    public Document getBsonDocument(final SessionTicket sessionTicket) {

        Document sessionTcktDoc = null;

        if (sessionTicket != null) {

            sessionTcktDoc = new Document();

            if (sessionTicket.getSessionId() != null) {
                sessionTcktDoc.append(SESSION_TICKET_ID, sessionTicket.getSessionId());
            }

            if (sessionTicket.getUuid() != null) {
                sessionTcktDoc.append(UUID, sessionTicket.getUuid());
            }

            if (sessionTicket.getCreatedTs() != null) {
                sessionTcktDoc.append(CREATED_TS, sessionTicket.getCreatedTs());
            }

            if (sessionTicket.getExpiryTs() != null) {
                sessionTcktDoc.append(EXPIRY_TS, sessionTicket.getExpiryTs());
            }

            if (sessionTicket.getDeviceUuid() != null) {
                sessionTcktDoc.append(DEVICE_UUID, sessionTicket.getDeviceUuid());
            }

            if (sessionTicket.getPrivacyKey() != null) {
                sessionTcktDoc.append(PRIVACY_KEY, sessionTicket.getPrivacyKey());
            }

            if (sessionTicket.getStatus() != null) {
                sessionTcktDoc.append(STATUS_STR, sessionTicket.getStatus());
            }

            if (sessionTicket.getSessionType() != null) {
                sessionTcktDoc.append(SESSION_TYPE_STR, sessionTicket.getSessionType());
            }

            if (sessionTicket.getAppSessionId() != null) {
                sessionTcktDoc.append(APP_SESSION_ID, sessionTicket.getAppSessionId());
            }

            if (sessionTicket.getAppUuid() != null) {
                sessionTcktDoc.append(APP_UUID, sessionTicket.getAppUuid());
            }

            if (sessionTicket.getAppAgentName() != null) {
                sessionTcktDoc.append(APP_AGENT_NAME, sessionTicket.getAppAgentName());
            }

            if (sessionTicket.getUserId() != null) {
                sessionTcktDoc.append(USER_ID, sessionTicket.getUserId());
            }

            if (sessionTicket.getRelIdVersion() != null) {
                sessionTcktDoc.append(RELID_VERSION, sessionTicket.getRelIdVersion().toString());
            }

            if (sessionTicket.getArchivedTs() != null) {
                sessionTcktDoc.append(ARCHIVED_TS, sessionTicket.getArchivedTs());
            }

            if (sessionTicket.getDfp() != null) {
                sessionTcktDoc.append(DEVICE_DETAILS, DfpParameters.getBsonDocument(sessionTicket.getDfp()));
            }

            if (sessionTicket.getJwt() != null) {
                sessionTcktDoc.append(JWT, sessionTicket.getJwt());
            }

            if (sessionTicket.getLoginId() != null) {
                sessionTcktDoc.append(LOGIN_ID, sessionTicket.getLoginId());
            }

            if (sessionTicket.getLastAccessTs() != null) {
                sessionTcktDoc.append(LAST_ACCESS_TS, sessionTicket.getLastAccessTs());
            }

            if (sessionTicket.getIdleTimeoutTs() != null) {
                sessionTcktDoc.append(IDLE_TIMEOUT_TS, sessionTicket.getIdleTimeoutTs());
            }

            if (sessionTicket.getClientIpAddress() != null) {
                sessionTcktDoc.append(CLIENT_IP_ADDRESS, sessionTicket.getClientIpAddress());
            }

            if (sessionTicket.getPrimaryGroupName() != null) {
                sessionTcktDoc.append(PRIMARY_GROUP_NAME_STR, sessionTicket.getPrimaryGroupName());
            }

            if (sessionTicket.getSecondaryGroupNames() != null) {
                sessionTcktDoc.append(SECONDARY_GROUP_NAMES_STR, sessionTicket.getSecondaryGroupNames());
            }

            if (sessionTicket.getInProcessChallenge() != null) {
                sessionTcktDoc.append(IN_PROCESS_CHALLENGE_STR,
                        Challenge.getBsonDocument(sessionTicket.getInProcessChallenge()));
            }

            if (sessionTicket.getPendingChallenges() != null) {
                sessionTcktDoc.append(PENDING_CHALLENGES_STR,
                        Challenge.getBsonDocumentFromList(sessionTicket.getPendingChallenges()));
            }

            if (sessionTicket.getAuthenticatedWith() != null) {
                sessionTcktDoc.append(AUTHENTICATED_WITH_STR, sessionTicket.getAuthenticatedWith());
            }

            if (sessionTicket.getDeviceName() != null) {
                sessionTcktDoc.append(DEVICE_NAME, sessionTicket.getDeviceName());
            }

            if (sessionTicket.getAppName() != null) {
                sessionTcktDoc.append(APP_NAME, sessionTicket.getAppName());
            }

            if (sessionTicket.getAppVersion() != null) {
                sessionTcktDoc.append(APP_VERSION, sessionTicket.getAppVersion());
            }

            if (sessionTicket.getSessionExpiryTs() != null) {
                sessionTcktDoc.append(SESSION_EXPIRY_TS, sessionTicket.getSessionExpiryTs());
            }

            if (sessionTicket.getSessionExpiredBy() != null) {
                sessionTcktDoc.append(SESSION_EXPIRED_BY, sessionTicket.getSessionExpiredBy());
            }

            if (sessionTicket.getLogoutTs() != null) {
                sessionTcktDoc.append(LOGOUT_TS, sessionTicket.getLogoutTs());
            }

            if (sessionTicket.getLogoutClientIpAddress() != null) {
                sessionTcktDoc.append(LOGOUT_CLIENT_IP_ADDRESS, sessionTicket.getLogoutClientIpAddress());
            }

            if (sessionTicket.getState() != null) {
                sessionTcktDoc.append(STATE, sessionTicket.getState());
            }
        }

        return sessionTcktDoc;

    }

    // /*
    // * (non-Javadoc)
    // * @see java.lang.Object#toString()
    // */
    // @Override
    // public String toString() {
    // return "SessionTicket [id=" + id + ", sessionTicketId=" + sessionId + ",
    // uuid=" + uuid + ", deviceUuid="
    // + deviceUuid + ", privacyKey=" + privacyKey + ", state=" + state + ",
    // createdTs=" + createdTs
    // + ", expiryTs=" + expiryTs + ", updatedTs=" + updatedTs + ", status=" +
    // status + ", sessionType="
    // + sessionType + ", appSessionId=" + appSessionId + ", appUuid=" + appUuid
    // + ", appAgentName="
    // + appAgentName + ", userId=" + userId + ", archivedTs=" + archivedTs + ",
    // relIdVersion=" + relIdVersion
    // + ", dfp=" + dfp + ", loginId=" + loginId + ", lastAccessTs=" +
    // lastAccessTs + ", idleTimeoutTs="
    // + idleTimeoutTs + ", clientIpAddress=" + clientIpAddress + ",
    // primaryGroupName=" + primaryGroupName
    // + ", secondaryGroupNames=" + secondaryGroupNames + "]";
    // }

    @Override
    public String toString() {
        return "SessionTicket [id=" + id + ", sessionTicketId=" + sessionId + ", uuid=" + uuid + ", deviceUuid="
                + deviceUuid + ", privacyKey=" + privacyKey + ", state=" + state + ", createdTs=" + createdTs
                + ", expiryTs=" + expiryTs + ", updatedTs=" + updatedTs + ", status=" + status + ", sessionType="
                + sessionType + ", appSessionId=" + appSessionId + ", appUuid=" + appUuid + ", appAgentName="
                + appAgentName + ", userId=" + userId + ", relIdVersion=" + relIdVersion + ", archivedTs=" + archivedTs
                + ", jwt=" + jwt + ", loginId=" + loginId + ", lastAccessTs=" + lastAccessTs + ", idleTimeoutTs="
                + idleTimeoutTs + ", clientIpAddress=" + clientIpAddress + ", primaryGroupName=" + primaryGroupName
                + ", secondaryGroupNames=" + secondaryGroupNames + ", pendingChallenges=" + pendingChallenges
                + ", inProcessChallengeName=" + inProcessChallenge + ", createdTsStr=" + createdTsStr + ", expiryTsStr="
                + expiryTsStr + ", updatedTsStr=" + updatedTsStr + ", archivedTsStr=" + archivedTsStr
                + ", lastAccessTsStr=" + lastAccessTsStr + ", idleTimeoutTsStr=" + idleTimeoutTsStr + "]";
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((appAgentName == null) ? 0 : appAgentName.hashCode());
        result = prime * result + ((appSessionId == null) ? 0 : appSessionId.hashCode());
        result = prime * result + ((appUuid == null) ? 0 : appUuid.hashCode());
        result = prime * result + ((archivedTs == null) ? 0 : archivedTs.hashCode());
        result = prime * result + ((archivedTsStr == null) ? 0 : archivedTsStr.hashCode());
        result = prime * result + ((clientIpAddress == null) ? 0 : clientIpAddress.hashCode());
        result = prime * result + ((createdTs == null) ? 0 : createdTs.hashCode());
        result = prime * result + ((createdTsStr == null) ? 0 : createdTsStr.hashCode());
        result = prime * result + ((deviceUuid == null) ? 0 : deviceUuid.hashCode());
        result = prime * result + ((expiryTs == null) ? 0 : expiryTs.hashCode());
        result = prime * result + ((expiryTsStr == null) ? 0 : expiryTsStr.hashCode());
        result = prime * result + ((id == null) ? 0 : id.hashCode());
        result = prime * result + ((idleTimeoutTs == null) ? 0 : idleTimeoutTs.hashCode());
        result = prime * result + ((idleTimeoutTsStr == null) ? 0 : idleTimeoutTsStr.hashCode());
        result = prime * result + ((inProcessChallenge == null) ? 0 : inProcessChallenge.hashCode());
        result = prime * result + ((jwt == null) ? 0 : jwt.hashCode());
        result = prime * result + ((lastAccessTs == null) ? 0 : lastAccessTs.hashCode());
        result = prime * result + ((lastAccessTsStr == null) ? 0 : lastAccessTsStr.hashCode());
        result = prime * result + ((loginId == null) ? 0 : loginId.hashCode());
        result = prime * result + ((pendingChallenges == null) ? 0 : pendingChallenges.hashCode());
        result = prime * result + ((primaryGroupName == null) ? 0 : primaryGroupName.hashCode());
        result = prime * result + ((privacyKey == null) ? 0 : privacyKey.hashCode());
        result = prime * result + ((relIdVersion == null) ? 0 : relIdVersion.hashCode());
        result = prime * result + ((secondaryGroupNames == null) ? 0 : secondaryGroupNames.hashCode());
        result = prime * result + ((sessionId == null) ? 0 : sessionId.hashCode());
        result = prime * result + ((sessionType == null) ? 0 : sessionType.hashCode());
        result = prime * result + ((state == null) ? 0 : state.hashCode());
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        result = prime * result + ((updatedTs == null) ? 0 : updatedTs.hashCode());
        result = prime * result + ((updatedTsStr == null) ? 0 : updatedTsStr.hashCode());
        result = prime * result + ((userId == null) ? 0 : userId.hashCode());
        result = prime * result + ((uuid == null) ? 0 : uuid.hashCode());
        return result;
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final SessionTicket other = (SessionTicket) obj;
        if (appAgentName == null) {
            if (other.appAgentName != null)
                return false;
        } else if (!appAgentName.equals(other.appAgentName))
            return false;
        if (appSessionId == null) {
            if (other.appSessionId != null)
                return false;
        } else if (!appSessionId.equals(other.appSessionId))
            return false;
        if (appUuid == null) {
            if (other.appUuid != null)
                return false;
        } else if (!appUuid.equals(other.appUuid))
            return false;
        if (archivedTs == null) {
            if (other.archivedTs != null)
                return false;
        } else if (!archivedTs.equals(other.archivedTs))
            return false;
        if (archivedTsStr == null) {
            if (other.archivedTsStr != null)
                return false;
        } else if (!archivedTsStr.equals(other.archivedTsStr))
            return false;
        if (clientIpAddress == null) {
            if (other.clientIpAddress != null)
                return false;
        } else if (!clientIpAddress.equals(other.clientIpAddress))
            return false;
        if (createdTs == null) {
            if (other.createdTs != null)
                return false;
        } else if (!createdTs.equals(other.createdTs))
            return false;
        if (createdTsStr == null) {
            if (other.createdTsStr != null)
                return false;
        } else if (!createdTsStr.equals(other.createdTsStr))
            return false;
        if (deviceUuid == null) {
            if (other.deviceUuid != null)
                return false;
        } else if (!deviceUuid.equals(other.deviceUuid))
            return false;
        if (dfp == null) {
            if (other.dfp != null)
                return false;
        } else if (!expiryTs.equals(other.expiryTs))
            return false;
        if (expiryTsStr == null) {
            if (other.expiryTsStr != null)
                return false;
        } else if (!expiryTsStr.equals(other.expiryTsStr))
            return false;
        if (id == null) {
            if (other.id != null)
                return false;
        } else if (!id.equals(other.id))
            return false;
        if (idleTimeoutTs == null) {
            if (other.idleTimeoutTs != null)
                return false;
        } else if (!idleTimeoutTs.equals(other.idleTimeoutTs))
            return false;
        if (idleTimeoutTsStr == null) {
            if (other.idleTimeoutTsStr != null)
                return false;
        } else if (!idleTimeoutTsStr.equals(other.idleTimeoutTsStr))
            return false;
        if (inProcessChallenge == null) {
            if (other.inProcessChallenge != null)
                return false;
        } else if (!inProcessChallenge.equals(other.inProcessChallenge))
            return false;
        if (jwt == null) {
            if (other.jwt != null)
                return false;
        } else if (!jwt.equals(other.jwt))
            return false;
        if (lastAccessTs == null) {
            if (other.lastAccessTs != null)
                return false;
        } else if (!lastAccessTs.equals(other.lastAccessTs))
            return false;
        if (lastAccessTsStr == null) {
            if (other.lastAccessTsStr != null)
                return false;
        } else if (!lastAccessTsStr.equals(other.lastAccessTsStr))
            return false;
        if (loginId == null) {
            if (other.loginId != null)
                return false;
        } else if (!loginId.equals(other.loginId))
            return false;
        if (pendingChallenges == null) {
            if (other.pendingChallenges != null)
                return false;
        } else if (!pendingChallenges.equals(other.pendingChallenges))
            return false;
        if (primaryGroupName == null) {
            if (other.primaryGroupName != null)
                return false;
        } else if (!primaryGroupName.equals(other.primaryGroupName))
            return false;
        if (privacyKey == null) {
            if (other.privacyKey != null)
                return false;
        } else if (!privacyKey.equals(other.privacyKey))
            return false;
        if (relIdVersion != other.relIdVersion)
            return false;
        if (relidServerPart == null) {
            if (other.relidServerPart != null)
                return false;
        } else if (!secondaryGroupNames.equals(other.secondaryGroupNames))
            return false;
        if (sessionId == null) {
            if (other.sessionId != null)
                return false;
        } else if (!sessionId.equals(other.sessionId))
            return false;
        if (sessionType == null) {
            if (other.sessionType != null)
                return false;
        } else if (!sessionType.equals(other.sessionType))
            return false;
        if (state == null) {
            if (other.state != null)
                return false;
        } else if (!state.equals(other.state))
            return false;
        if (status == null) {
            if (other.status != null)
                return false;
        } else if (!status.equals(other.status))
            return false;
        if (updatedTs == null) {
            if (other.updatedTs != null)
                return false;
        } else if (!updatedTs.equals(other.updatedTs))
            return false;
        if (updatedTsStr == null) {
            if (other.updatedTsStr != null)
                return false;
        } else if (!updatedTsStr.equals(other.updatedTsStr))
            return false;
        if (userId == null) {
            if (other.userId != null)
                return false;
        } else if (!userId.equals(other.userId))
            return false;
        if (uuid == null) {
            if (other.uuid != null)
                return false;
        } else if (!uuid.equals(other.uuid))
            return false;
        return true;
    }

    private String createdTsStr;

    private String expiryTsStr;

    private String updatedTsStr;

    private String archivedTsStr;

    private String lastAccessTsStr;

    private String idleTimeoutTsStr;

    /**
     * @return the createdTsStr
     */
    public String getCreatedTsStr() {
        return createdTsStr;
    }

    /**
     * @param createdTsStr
     *            the createdTsStr to set
     */
    public void setCreatedTsStr(final String createdTsStr) {
        this.createdTsStr = createdTsStr;
    }

    /**
     * @return the expiryTsStr
     */
    public String getExpiryTsStr() {
        return expiryTsStr;
    }

    /**
     * @param expiryTsStr
     *            the expiryTsStr to set
     */
    public void setExpiryTsStr(final String expiryTsStr) {
        this.expiryTsStr = expiryTsStr;
    }

    /**
     * @return the updatedTsStr
     */
    public String getUpdatedTsStr() {
        return updatedTsStr;
    }

    /**
     * @param updatedTsStr
     *            the updatedTsStr to set
     */
    public void setUpdatedTsStr(final String updatedTsStr) {
        this.updatedTsStr = updatedTsStr;
    }

    /**
     * @return the archivedTsStr
     */
    public String getArchivedTsStr() {
        return archivedTsStr;
    }

    /**
     * @param archivedTsStr
     *            the archivedTsStr to set
     */
    public void setArchivedTsStr(final String archivedTsStr) {
        this.archivedTsStr = archivedTsStr;
    }

    /**
     * @return the lastAccessTsStr
     */
    public String getLastAccessTsStr() {
        return lastAccessTsStr;
    }

    /**
     * @param lastAccessTsStr
     *            the lastAccessTsStr to set
     */
    public void setLastAccessTsStr(final String lastAccessTsStr) {
        this.lastAccessTsStr = lastAccessTsStr;
    }

    /**
     * @return the idleTimeoutTsStr
     */
    public String getIdleTimeoutTsStr() {
        return idleTimeoutTsStr;
    }

    /**
     * @param idleTimeoutTsStr
     *            the idleTimeoutTsStr to set
     */
    public void setIdleTimeoutTsStr(final String idleTimeoutTsStr) {
        this.idleTimeoutTsStr = idleTimeoutTsStr;
    }

    public void parseDateToString(final String dateFormat) {
        final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        if (null != this.createdTs)
            this.createdTsStr = sdf.format(this.createdTs);
        if (null != this.expiryTs)
            this.expiryTsStr = sdf.format(this.expiryTs);
        if (null != this.updatedTs)
            this.updatedTsStr = sdf.format(this.updatedTs);
        if (null != this.archivedTs)
            this.archivedTsStr = sdf.format(this.archivedTs);
        if (null != this.lastAccessTs)
            this.lastAccessTsStr = sdf.format(this.lastAccessTs);
        if (null != this.idleTimeoutTs)
            this.idleTimeoutTsStr = sdf.format(this.idleTimeoutTs);
        if (null != this.logoutTs)
            this.logoutTsStr = sdf.format(this.logoutTs);
        if (null != this.sessionExpiryTs)
            this.sessionExpiryTsStr = sdf.format(this.sessionExpiryTs);

    }

    @SerializedName(DEVICE_NAME)
    @Field(DEVICE_NAME)
    private String deviceName;

    @SerializedName(APP_NAME)
    @Field(APP_NAME)
    private String appName;

    @SerializedName(APP_VERSION)
    @Field(APP_VERSION)
    private String appVersion;

    @SerializedName(SESSION_EXPIRY_TS)
    @Field(SESSION_EXPIRY_TS)
    private Date sessionExpiryTs;

    private String sessionExpiryTsStr;

    @SerializedName(SESSION_EXPIRED_BY)
    @Field(SESSION_EXPIRED_BY)
    private String sessionExpiredBy;

    @SerializedName(LOGOUT_TS)
    @Field(LOGOUT_TS)
    private Date logoutTs;

    private String logoutTsStr;

    @SerializedName(LOGOUT_CLIENT_IP_ADDRESS)
    @Field(LOGOUT_CLIENT_IP_ADDRESS)
    private String logoutClientIpAddress;

    /**
     * @return the deviceName
     */
    public String getDeviceName() {
        return deviceName;
    }

    /**
     * @param deviceName
     *            the deviceName to set
     */
    public void setDeviceName(final String deviceName) {
        this.deviceName = deviceName;
    }

    /**
     * @return the appName
     */
    public String getAppName() {
        return appName;
    }

    /**
     * @param appName
     *            the appName to set
     */
    public void setAppName(final String appName) {
        this.appName = appName;
    }

    /**
     * @return the appVersion
     */
    public String getAppVersion() {
        return appVersion;
    }

    /**
     * @param appVersion
     *            the appVersion to set
     */
    public void setAppVersion(final String appVersion) {
        this.appVersion = appVersion;
    }

    /**
     * @return the sessionExpiryTs
     */
    public Date getSessionExpiryTs() {
        return sessionExpiryTs;
    }

    /**
     * @param sessionExpiryTs
     *            the sessionExpiryTs to set
     */
    public void setSessionExpiryTs(final Date sessionExpiryTs) {
        this.sessionExpiryTs = sessionExpiryTs;
    }

    /**
     * @return the sessionExpiryTsStr
     */
    public String getSessionExpiryTsStr() {
        return sessionExpiryTsStr;
    }

    /**
     * @param sessionExpiryTsStr
     *            the sessionExpiryTsStr to set
     */
    public void setSessionExpiryTsStr(final String sessionExpiryTsStr) {
        this.sessionExpiryTsStr = sessionExpiryTsStr;
    }

    /**
     * @return the sessionExpiredBy
     */
    public String getSessionExpiredBy() {
        return sessionExpiredBy;
    }

    /**
     * @param sessionExpiredBy
     *            the sessionExpiredBy to set
     */
    public void setSessionExpiredBy(final String sessionExpiredBy) {
        this.sessionExpiredBy = sessionExpiredBy;
    }

    /**
     * @return the logoutTs
     */
    public Date getLogoutTs() {
        return logoutTs;
    }

    /**
     * @param logoutTs
     *            the logoutTs to set
     */
    public void setLogoutTs(final Date logoutTs) {
        this.logoutTs = logoutTs;
    }

    /**
     * @return the logoutTsStr
     */
    public String getLogoutTsStr() {
        return logoutTsStr;
    }

    /**
     * @param logoutTsStr
     *            the logoutTsStr to set
     */
    public void setLogoutTsStr(final String logoutTsStr) {
        this.logoutTsStr = logoutTsStr;
    }

    /**
     * @return the logoutClientIpAddress
     */
    public String getLogoutClientIpAddress() {
        return logoutClientIpAddress;
    }

    /**
     * @param logoutClientIpAddress
     *            the logoutClientIpAddress to set
     */
    public void setLogoutClientIpAddress(final String logoutClientIpAddress) {
        this.logoutClientIpAddress = logoutClientIpAddress;
    }

    public IDVAuditingTemplate getIdvAuditInfo() {
        return idvAuditInfo;
    }

    public void setIdvAuditInfo(final IDVAuditingTemplate idvAuditInfo) {
        this.idvAuditInfo = idvAuditInfo;
    }
}
