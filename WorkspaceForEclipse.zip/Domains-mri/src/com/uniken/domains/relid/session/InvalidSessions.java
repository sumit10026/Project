package com.uniken.domains.relid.session;

import java.util.Date;

import org.bson.Document;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.relid.BaseEntity;

public class InvalidSessions extends BaseEntity {

    public final static String SESSION_ID = "session_id";
    public final static String CREATE_TS = "create_ts";

    @SerializedName(SESSION_ID)
    private String sessionId;

    @SerializedName(CREATE_TS)
    private Date createTs;

    /**
     * @return the sessionId
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * @param sessionId
     *            the sessionId to set
     */
    public void setSessionId(final String sessionId) {
        this.sessionId = sessionId;
    }

    /**
     * @return the createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     *            the createTs to set
     */
    public void setCreateTs(final Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @param invalidSession
     * @return
     */
    public Document getBsonDocument(final InvalidSessions invalidSession) {

        Document invalidSessionsDoc = null;

        if (invalidSession != null) {

            invalidSessionsDoc = new Document();

            if (invalidSession.getId() != null) {
                invalidSessionsDoc.append(ID_STR, invalidSession.getId());
            }

            if (invalidSession.getSessionId() != null) {
                invalidSessionsDoc.append(SESSION_ID, invalidSession.getSessionId());
            }

            if (invalidSession.getCreateTs() != null) {
                invalidSessionsDoc.append(CREATE_TS, invalidSession.getCreateTs());
            }

        }

        return invalidSessionsDoc;

    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "InvalidSessions [sessionId=" + sessionId + ", createTs=" + createTs + "]";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((createTs == null) ? 0 : createTs.hashCode());
        result = prime * result + ((sessionId == null) ? 0 : sessionId.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final InvalidSessions other = (InvalidSessions) obj;
        if (createTs == null) {
            if (other.createTs != null)
                return false;
        } else if (!createTs.equals(other.createTs))
            return false;
        if (sessionId == null) {
            if (other.sessionId != null)
                return false;
        } else if (!sessionId.equals(other.sessionId))
            return false;
        return true;
    }

}
