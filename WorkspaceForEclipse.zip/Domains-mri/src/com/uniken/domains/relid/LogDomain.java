package com.uniken.domains.relid;

import java.util.List;

import org.springframework.data.annotation.Transient;

import com.uniken.domains.enums.ACTIVITY_TYPE;

/**
 * To be inherited by all domains
 * 
 * @author UNIKEN
 */
public abstract class LogDomain {

    /**
     * Keep userId here. Put a setter. Put a getter which will give username
     * from session if not available
     */
    @Transient
    private String userId;

    @Transient
    private ACTIVITY_TYPE activityType;

    @Transient
    private List<String> logValues;

    /**
     * @return
     */
    public ACTIVITY_TYPE getActivityType() {
        return activityType;
    }

    /**
     * @param activityType
     *            the activityType to set
     */
    public void setActivityType(final ACTIVITY_TYPE activityType) {
        this.activityType = activityType;
    }

    /**
     * @param logValues
     *            the logValues to set
     */
    public void setLogValues(final List<String> logValues) {
        this.logValues = logValues;
    }

    /**
     * @return the logValues
     */
    public List<String> getLogValues() {
        return logValues;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((activityType == null) ? 0 : activityType.hashCode());
        result = prime * result + ((logValues == null) ? 0 : logValues.hashCode());
        result = prime * result + ((userId == null) ? 0 : userId.hashCode());
        return result;
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final LogDomain other = (LogDomain) obj;
        if (activityType != other.activityType)
            return false;
        if (logValues == null) {
            if (other.logValues != null)
                return false;
        } else if (!logValues.equals(other.logValues))
            return false;
        if (userId == null) {
            if (other.userId != null)
                return false;
        } else if (!userId.equals(other.userId))
            return false;
        return true;
    }

    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("LogDomain [userId=");
        builder.append(userId);
        builder.append(", activityType=");
        builder.append(activityType);
        builder.append(", logValues=");
        builder.append(logValues);
        builder.append("]");
        return builder.toString();
    }

}
