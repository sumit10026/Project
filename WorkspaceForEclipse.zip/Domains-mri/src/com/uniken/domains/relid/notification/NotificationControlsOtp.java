/**
 * 
 */
package com.uniken.domains.relid.notification;

import com.google.gson.annotations.SerializedName;

public class NotificationControlsOtp {

    @SerializedName("attempts")
    private int attempts;

    @SerializedName("hash_spec")
    private String hashSpec;

    /**
     * @return the attempts
     */
    public int getAttempts() {
        return attempts;
    }

    /**
     * @param attempts
     *            the attempts to set
     */
    public void setAttempts(final int attempts) {
        this.attempts = attempts;
    }

    /**
     * @return the hashSpec
     */
    public String getHashSpec() {
        return hashSpec;
    }

    /**
     * @param hashSpec
     *            the hashSpec to set
     */
    public void setHashSpec(final String hashSpec) {
        this.hashSpec = hashSpec;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("NotificationControlsOtp [attempts=").append(attempts).append(", hashSpec=").append(hashSpec)
                .append("]");
        return builder.toString();
    }

}
