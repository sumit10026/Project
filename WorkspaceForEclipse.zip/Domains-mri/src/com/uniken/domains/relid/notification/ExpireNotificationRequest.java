/**
 * 
 */
package com.uniken.domains.relid.notification;

import com.google.gson.annotations.SerializedName;

/**
 * Domain object for expire notification request.
 * 
 * @author Uniken Inc.
 */
public class ExpireNotificationRequest {

    public static final String USER_ID = "user_id";
    public static final String USER_UUID = "user_uuid";
    public static final String DEVICE_TO_BE_ACTIVATED = "device_to_be_activated";
    public static final String APP_ID = "app_id";
    public static final String APP_UUID = "app_uuid";
    public static final String NOTIFICATION_REQUESTER_NAME = "notification_requester_name";

    @SerializedName(value = USER_ID)
    private final String userId;

    @SerializedName(value = USER_UUID)
    private String userUUID;

    @SerializedName(value = DEVICE_TO_BE_ACTIVATED)
    private final String deviceToBeActivated;

    @SerializedName(value = APP_ID)
    private String appId;

    @SerializedName(value = APP_UUID)
    private final String appUUID;

    @SerializedName(value = NOTIFICATION_REQUESTER_NAME)
    private String notificationRequesterName;

    public ExpireNotificationRequest(final String userId, final String userUUID, final String deviceToBeActivated,
            final String appId, final String appUUID) {
        this.userId = userId;
        this.userUUID = userUUID;
        this.deviceToBeActivated = deviceToBeActivated;
        this.appId = appId;
        this.appUUID = appUUID;

    }

    /**
     * @param userId
     * @param deviceToBeActivated
     * @param appUUID
     */
    public ExpireNotificationRequest(final String userId, final String deviceToBeActivated, final String appUUID) {
        this.userId = userId;
        this.deviceToBeActivated = deviceToBeActivated;
        this.appUUID = appUUID;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @return the userUUID
     */
    public String getUserUUID() {
        return userUUID;
    }

    /**
     * @return the deviceToBeActivated
     */
    public String getDeviceToBeActivated() {
        return deviceToBeActivated;
    }

    /**
     * @return the appId
     */
    public String getAppId() {
        return appId;
    }

    /**
     * @return the appUUID
     */
    public String getAppUUID() {
        return appUUID;
    }

    /**
     * @return
     */
    public String getNotificationRequesterName() {
        return notificationRequesterName;
    }

    /**
     * @param notificationRequesterName
     */
    public void setNotificationRequesterName(final String notificationRequesterName) {
        this.notificationRequesterName = notificationRequesterName;
    }

    @Override
    public String toString() {
        return "ExpireNotificationRequest [userId=" + userId + ", deviceToBeActivated=" + deviceToBeActivated
                + ", appUUID=" + appUUID + "]";
    }

}
