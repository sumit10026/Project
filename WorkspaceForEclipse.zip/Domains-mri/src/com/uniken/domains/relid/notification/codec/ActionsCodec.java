package com.uniken.domains.relid.notification.codec;

import org.bson.BsonReader;
import org.bson.BsonType;
import org.bson.BsonWriter;
import org.bson.codecs.Codec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.codecs.configuration.CodecRegistry;

import com.uniken.domains.relid.notification.Action;
import com.uniken.domains.relid.notification.Notification;

public class ActionsCodec
        implements
        Codec<Action> {

    private final CodecRegistry codecRegistry;

    public ActionsCodec(final CodecRegistry codecRegistry) {
        this.codecRegistry = codecRegistry;
    }

    @Override
    public void encode(final BsonWriter writer, final Action actions, final EncoderContext encoderContext) {
        writer.writeStartDocument();

        if (actions.getAction() != null) {
            writer.writeName(Notification.ACTION_KEY);
            writer.writeString(actions.getAction());
        }

        if (actions.getLabel() != null) {
            writer.writeName(Notification.ACTION_LABEL);
            writer.writeString(actions.getLabel());
        }

        if (actions.getAuthlevel() != null) {
            writer.writeName(Notification.ACTION_AUTHLEVEL);
            writer.writeString(actions.getAuthlevel());
        }

        if (actions.getAuthenticator() != null) {
            writer.writeName(Notification.ACTION_AUTHENTICATOR);
            writer.writeString(actions.getAuthenticator());
        }
        writer.writeEndDocument();

    }

    @Override
    public Class<Action> getEncoderClass() {
        return Action.class;
    }

    @Override
    public Action decode(final BsonReader reader, final DecoderContext decodeContext) {

        final Action actionsDoc = new Action();
        reader.readStartDocument();

        while (reader.readBsonType() != BsonType.END_OF_DOCUMENT) {
            switch (reader.readName()) {
            case Notification.ACTION_KEY:
                actionsDoc.setAction(reader.readString());
                break;
            case Notification.ACTION_LABEL:
                actionsDoc.setLabel(reader.readString());
                break;
            case Notification.ACTION_AUTHLEVEL:
                actionsDoc.setAuthlevel(reader.readString());
                break;
            case Notification.ACTION_AUTHENTICATOR:
                actionsDoc.setAuthenticator(reader.readString());
                break;
            default:
                break;

            }
        }
        reader.readEndDocument();

        return actionsDoc;
    }
}
