package com.uniken.domains.relid.notification;

import java.util.List;

import com.google.gson.annotations.SerializedName;

/*
 * @author Sumeet Khambe
 */
public class NotificationDetails {

    private static final String START = "start";
    private static final String COUNT = "count";
    private static final String TOTAL = "total";
    private static final String NOTIFICATIONS = "notifications";

    @SerializedName(NOTIFICATIONS)
    private List<NotificationPacket> notifications;

    @SerializedName(START)
    private int startIndex;

    @SerializedName(COUNT)
    private int notificationCountInResponse;

    @SerializedName(TOTAL)
    private int totalNotifications;

    /**
     * @return the notifications
     */
    public List<NotificationPacket> getNotifications() {
        return notifications;
    }

    /**
     * @param notifications
     *            the notifications to set
     */
    public void setNotifications(final List<NotificationPacket> notifications) {
        this.notifications = notifications;
    }

    /**
     * @return the startIndex
     */
    public int getStartIndex() {
        return startIndex;
    }

    /**
     * @param startIndex
     *            the startIndex to set
     */
    public void setStartIndex(final int startIndex) {
        this.startIndex = startIndex;
    }

    /**
     * @return the notificationCountInResponse
     */
    public int getNotificationCountInResponse() {
        return notificationCountInResponse;
    }

    /**
     * @param notificationCountInResponse
     *            the notificationCountInResponse to set
     */
    public void setNotificationCountInResponse(final int notificationCountInResponse) {
        this.notificationCountInResponse = notificationCountInResponse;
    }

    /**
     * @return the totalNotifications
     */
    public int getTotalNotifications() {
        return totalNotifications;
    }

    /**
     * @param totalNotifications
     *            the totalNotifications to set
     */
    public void setTotalNotifications(final int totalNotifications) {
        this.totalNotifications = totalNotifications;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("NotificationDetails [notifications=");
        builder.append(notifications);
        builder.append(", startIndex=");
        builder.append(startIndex);
        builder.append(", notificationCountInResponse=");
        builder.append(notificationCountInResponse);
        builder.append(", totalNotifications=");
        builder.append(totalNotifications);
        builder.append("]");
        return builder.toString();
    }

}
