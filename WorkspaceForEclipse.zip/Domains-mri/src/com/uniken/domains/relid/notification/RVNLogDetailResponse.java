/**
 * 
 */
package com.uniken.domains.relid.notification;

import java.util.Date;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.enums.NotificationStatus;
import com.uniken.domains.relid.device.DfpParameters;

/**
 * @author Uniken Inc.
 */
public class RVNLogDetailResponse {

    public static final String RESPONSE_CODE = "response_code";
    public static final String DS_PUBLIC_CERT = "ds_public_cert";
    public static final String NOTIFICATION_DETAILS = "notification_details";
    public static final String DEVICE_DETAILS = "device_details";
    public static final String DS_SIGN_DATA = "ds_sign_data";
    public static final String DS_PLAIN_DATA = "ds_plain_data";
    public static final String ACTION_DEVICE_NAME = "action_device_name";
    public final static String CLIENT_IP_ADDRESS = "client_ip_address";

    public static final String ERROR_MESSAGE = "error_msg";
    public static final String ERROR_CODE = "error_code";

    @SerializedName(value = RESPONSE_CODE)
    private int responseCode;

    @SerializedName(value = Notification.NOTIFICATION_UUID)
    private String notificationUUID;

    @SerializedName(value = Notification.ENTERPRISE_ID)
    private String enterpriseId;

    @SerializedName(value = Notification.USER_ID)
    private String userId;

    @SerializedName(value = Notification.ACTION_PERFORMED)
    private String actionPerformed;

    @SerializedName(value = Notification.STATUS)
    private NotificationStatus status;

    @SerializedName(value = ACTION_DEVICE_NAME)
    private String actionDeviceName;

    @SerializedName(value = Notification.CREATE_TS)
    private Date createTimestamp;

    @SerializedName(value = Notification.UPDATE_TS)
    private Date updateTimestamp;

    @SerializedName(value = Notification.EXPIRY_TIMESTAMP)
    private Date expiryTimestamp;

    @SerializedName(value = Notification.DELIVERY_STATUS)
    private NotificationStatus deliveryStatus;

    @SerializedName(value = Notification.DS_REQUIRED)
    private boolean dsRequired;

    @SerializedName(value = Notification.IS_DS_VERIFIED)
    private boolean isDsVerified;

    @SerializedName(value = DS_PUBLIC_CERT)
    private String dsPublicCert;

    @SerializedName(value = DS_SIGN_DATA)
    private String signData;

    @SerializedName(value = DS_PLAIN_DATA)
    private String plainData;

    @SerializedName(value = DEVICE_DETAILS)
    private DfpParameters deviceDetails;

    @SerializedName(value = Notification.JWT)
    private String jwt;

    @SerializedName(CLIENT_IP_ADDRESS)
    private String clientIpAddress;

    public RVNLogDetailResponse() {
    }

    /**
     * @param responseCode
     * @param notificationUUID
     * @param enterpriseId
     * @param userId
     * @param actionPerformed
     * @param status
     * @param actionDeviceName
     * @param createTimestamp
     * @param expiryTimestamp
     * @param deliveryStatus
     * @param dsRequired
     * @param isDsVerified
     * @param dsPublicCert
     * @param signData
     * @param plainData
     * @param deviceDetails
     */
    public RVNLogDetailResponse(final int responseCode, final String notificationUUID, final String enterpriseId,
            final String userId, final String actionPerformed, final NotificationStatus status,
            final String actionDeviceName, final Date createTimestamp, final Date updateTimestamp,
            final Date expiryTimestamp, final NotificationStatus deliveryStatus, final boolean dsRequired,
            final boolean isDsVerified, final String dsPublicCert, final String signData, final String plainData,
            final DfpParameters deviceDetails, final String jwt, final String clientIpAddress) {
        super();
        this.responseCode = responseCode;
        this.notificationUUID = notificationUUID;
        this.enterpriseId = enterpriseId;
        this.userId = userId;
        this.actionPerformed = actionPerformed;
        this.status = status;
        this.actionDeviceName = actionDeviceName;
        this.createTimestamp = createTimestamp;
        this.updateTimestamp = updateTimestamp;
        this.expiryTimestamp = expiryTimestamp;
        this.deliveryStatus = deliveryStatus;
        this.dsRequired = dsRequired;
        this.isDsVerified = isDsVerified;
        this.dsPublicCert = dsPublicCert;
        this.signData = signData;
        this.plainData = plainData;
        this.deviceDetails = deviceDetails;
        this.jwt = jwt;
        this.clientIpAddress = clientIpAddress;
    }

    /**
     * @return the responseCode
     */
    public int getResponseCode() {
        return responseCode;
    }

    /**
     * @param responseCode
     *            the responseCode to set
     */
    public void setResponseCode(final int responseCode) {
        this.responseCode = responseCode;
    }

    /**
     * @return the notificationUUID
     */
    public String getNotificationUUID() {
        return notificationUUID;
    }

    /**
     * @param notificationUUID
     *            the notificationUUID to set
     */
    public void setNotificationUUID(final String notificationUUID) {
        this.notificationUUID = notificationUUID;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @return the dsPublicCert
     */
    public String getDsPublicCert() {
        return dsPublicCert;
    }

    /**
     * @param dsPublicCert
     *            the dsPublicCert to set
     */
    public void setDsPublicCert(final String dsPublicCert) {
        this.dsPublicCert = dsPublicCert;
    }

    /**
     * @return the signData
     */
    public String getSignData() {
        return signData;
    }

    /**
     * @param signData
     *            the signData to set
     */
    public void setSignData(final String signData) {
        this.signData = signData;
    }

    /**
     * @return the plainData
     */
    public String getPlainData() {
        return plainData;
    }

    /**
     * @param plainData
     *            the plainData to set
     */
    public void setPlainData(final String plainData) {
        this.plainData = plainData;
    }

    /**
     * @return the actionDeviceName
     */
    public String getActionDeviceName() {
        return actionDeviceName;
    }

    /**
     * @param actionDeviceName
     *            the actionDeviceName to set
     */
    public void setActionDeviceName(final String actionDeviceName) {
        this.actionDeviceName = actionDeviceName;
    }

    /**
     * @return the enterpriseId
     */
    public String getEnterpriseId() {
        return enterpriseId;
    }

    /**
     * @param enterpriseId
     *            the enterpriseId to set
     */
    public void setEnterpriseId(final String enterpriseId) {
        this.enterpriseId = enterpriseId;
    }

    /**
     * @return the actionPerformed
     */
    public String getActionPerformed() {
        return actionPerformed;
    }

    /**
     * @param actionPerformed
     *            the actionPerformed to set
     */
    public void setActionPerformed(final String actionPerformed) {
        this.actionPerformed = actionPerformed;
    }

    /**
     * @return the status
     */
    public NotificationStatus getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(final NotificationStatus status) {
        this.status = status;
    }

    /**
     * @return the createTimestamp
     */
    public Date getCreateTimestamp() {
        return createTimestamp;
    }

    /**
     * @param createTimestamp
     *            the createTimestamp to set
     */
    public void setCreateTimestamp(final Date createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    /**
     * @return the updateTimestamp
     */
    public Date getUpdateTimestamp() {
        return updateTimestamp;
    }

    /**
     * @param updateTimestamp
     *            the updateTimestamp to set
     */
    public void setUpdateTimestamp(final Date updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

    /**
     * @return the expiryTimestamp
     */
    public Date getExpiryTimestamp() {
        return expiryTimestamp;
    }

    /**
     * @param expiryTimestamp
     *            the expiryTimestamp to set
     */
    public void setExpiryTimestamp(final Date expiryTimestamp) {
        this.expiryTimestamp = expiryTimestamp;
    }

    /**
     * @return the deliveryStatus
     */
    public NotificationStatus getDeliveryStatus() {
        return deliveryStatus;
    }

    /**
     * @param deliveryStatus
     *            the deliveryStatus to set
     */
    public void setDeliveryStatus(final NotificationStatus deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }

    /**
     * @return the dsRequired
     */
    public boolean isDsRequired() {
        return dsRequired;
    }

    /**
     * @param dsRequired
     *            the dsRequired to set
     */
    public void setDsRequired(final boolean dsRequired) {
        this.dsRequired = dsRequired;
    }

    /**
     * @return the isDsVerified
     */
    public boolean isDsVerified() {
        return isDsVerified;
    }

    /**
     * @param isDsVerified
     *            the isDsVerified to set
     */
    public void setDsVerified(final boolean isDsVerified) {
        this.isDsVerified = isDsVerified;
    }

    /**
     * @return the deviceDetails
     */
    public DfpParameters getDeviceDetails() {
        return deviceDetails;
    }

    /**
     * @param deviceDetails
     *            the deviceDetails to set
     */
    public void setDeviceDetails(final DfpParameters deviceDetails) {
        this.deviceDetails = deviceDetails;
    }

    /**
     * @return the jwt
     */
    public String getJwt() {
        return jwt;
    }

    /**
     * @param jwt
     *            the jwt to set
     */
    public void setJwt(final String jwt) {
        this.jwt = jwt;
    }

    /**
     * @return the clientIpAddress
     */
    public String getClientIpAddress() {
        return clientIpAddress;
    }

    /**
     * @param clientIpAddress
     *            the clientIpAddress to set
     */
    public void setClientIpAddress(final String clientIpAddress) {
        this.clientIpAddress = clientIpAddress;
    }

}
