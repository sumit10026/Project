/**
 * 
 */
package com.uniken.domains.relid.notification;

import java.util.Date;

import com.google.gson.annotations.SerializedName;

public class NotificationControlsPushFallback {

    @SerializedName("duration")
    private int duration;

    @SerializedName("datetime")
    private Date datetime;

    @SerializedName("fallback_type")
    private String fallbackType;

    /**
     * @return the duration
     */
    public int getDuration() {
        return duration;
    }

    /**
     * @param duration
     *            the duration to set
     */
    public void setDuration(final int duration) {
        this.duration = duration;
    }

    /**
     * @return the datetime
     */
    public Date getDatetime() {
        return datetime;
    }

    /**
     * @param datetime
     *            the datetime to set
     */
    public void setDatetime(final Date datetime) {
        this.datetime = datetime;
    }

    /**
     * @return the fallbackType
     */
    public String getFallbackType() {
        return fallbackType;
    }

    /**
     * @param fallbackType
     *            the fallbackType to set
     */
    public void setFallbackType(final String fallbackType) {
        this.fallbackType = fallbackType;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("NotificationControlsPushFallback [duration=").append(duration).append(", datetime=")
                .append(datetime).append(", fallbackType=").append(fallbackType).append("]");
        return builder.toString();
    }

}
