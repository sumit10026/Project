/**
 * 
 */
package com.uniken.domains.relid.notification;

import com.google.gson.annotations.SerializedName;

/**
 * @author Chetan Patil
 */
public class NotificationUserActionRequest {

    @SerializedName("notification_uuid")
    private String notificationUuid;

    /**
     * @return the notificationUuid
     */
    public String getNotificationUuid() {
        return notificationUuid;
    }

    /**
     * @param notificationUuid
     *            the notificationUuid to set
     */
    public void setNotificationUuid(final String notificationUuid) {
        this.notificationUuid = notificationUuid;
    }

}
