package com.uniken.domains.relid.notification.codec;

import java.util.Map;

import org.bson.BsonReader;
import org.bson.BsonType;
import org.bson.BsonWriter;
import org.bson.codecs.Codec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.codecs.MapCodec;
import org.bson.codecs.configuration.CodecRegistry;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.uniken.domains.relid.notification.Message;
import com.uniken.domains.relid.notification.Notification;

public class MessageCodec
        implements
        Codec<Message> {

    public final Gson GSON_BUILDER = new GsonBuilder().disableHtmlEscaping().create();

    private final CodecRegistry codecRegistry;

    public MessageCodec(final CodecRegistry codecRegistry) {
        this.codecRegistry = codecRegistry;
    }

    @Override
    public void encode(final BsonWriter writer, final Message message, final EncoderContext encoderContext) {
        writer.writeStartDocument();

        if (message.getLng() != null) {
            writer.writeName(Notification.MESSAGE_LNG);
            writer.writeString(message.getLng());
        }

        if (message.getSubject() != null) {
            writer.writeName(Notification.MESSAGE_SUBJECT);
            writer.writeString(message.getSubject());
        }

        if (message.getMessage() != null) {
            writer.writeName(Notification.MESSAGE_MESSAGE);
            writer.writeString(message.getMessage());
        }

        if (message.getLabel() != null) {
            writer.writeName(Notification.MESSAGE_LABEL);

            final MapCodec mapCodec = new MapCodec(codecRegistry);
            mapCodec.encode(writer, message.getLabel(), encoderContext);
        }

        writer.writeEndDocument();
    }

    @Override
    public Class<Message> getEncoderClass() {
        return Message.class;
    }

    @Override
    public Message decode(final BsonReader reader, final DecoderContext decodeContext) {
        Message messageDoc = null;
        boolean variableValuePresent = false;
        String lng = null;
        String subject = null;
        String message = null;
        Map<String, Object> label = null;

        reader.readStartDocument();
        while (reader.readBsonType() != BsonType.END_OF_DOCUMENT) {
            switch (reader.readName()) {
            case Notification.MESSAGE_LNG:
                lng = reader.readString();
                variableValuePresent = true;
                break;
            case Notification.MESSAGE_SUBJECT:
                subject = reader.readString();
                variableValuePresent = true;
                break;
            case Notification.MESSAGE_MESSAGE:
                message = reader.readString();
                variableValuePresent = true;
                break;
            case Notification.MESSAGE_LABEL:
                final MapCodec mapCodec = new MapCodec(codecRegistry);
                label = mapCodec.decode(reader, decodeContext);

                variableValuePresent = true;
                break;
            default:
                break;

            }
        }
        reader.readEndDocument();

        if (variableValuePresent) {
            messageDoc = new Message();
            messageDoc.setLng(lng);
            messageDoc.setSubject(subject);
            messageDoc.setMessage(message);
            messageDoc.setLabel(label);
        }
        return messageDoc;
    }
}
