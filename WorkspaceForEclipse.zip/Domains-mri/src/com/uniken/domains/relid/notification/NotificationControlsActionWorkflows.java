/**
 * 
 */
package com.uniken.domains.relid.notification;

import java.util.Map;

import com.google.gson.annotations.SerializedName;

public class NotificationControlsActionWorkflows {

    @SerializedName(Notification.NOTIFICATION_CONTROLS_ACTION_WORKFLOWS_PARAMS)
    private NotificationControlsActionWorkflowsParams workflowsParams;

    @SerializedName(Notification.NOTIFICATION_CONTROLS_ACTION_WORKFLOWS_WORKFLOWS)
    private Map<String, Object> workflows;

    /**
     * @return the workflowsParams
     */
    public NotificationControlsActionWorkflowsParams getWorkflowsParams() {
        return workflowsParams;
    }

    /**
     * @param workflowsParams
     *            the workflowsParams to set
     */
    public void setWorkflowsParams(final NotificationControlsActionWorkflowsParams workflowsParams) {
        this.workflowsParams = workflowsParams;
    }

    /**
     * @return the workflows
     */
    public Map<String, Object> getWorkflows() {
        return workflows;
    }

    /**
     * @param workflows
     *            the workflows to set
     */
    public void setWorkflows(final Map<String, Object> workflows) {
        this.workflows = workflows;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("NotificationActionWorkflows [workflowsParams=");
        builder.append(workflowsParams);
        builder.append(", workflows=");
        builder.append(workflows);
        builder.append("]");
        return builder.toString();
    }

}
