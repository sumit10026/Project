/**
 * 
 */
package com.uniken.domains.relid.notification.codec;

import java.util.Date;

import org.bson.BsonReader;
import org.bson.BsonType;
import org.bson.BsonWriter;
import org.bson.codecs.Codec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.codecs.configuration.CodecRegistry;

import com.uniken.domains.relid.notification.Notification;
import com.uniken.domains.relid.notification.PushNotificationDevTokenStatus;

/**
 * @author UNIKEN
 */
public class PushNotificationDevTokenStatusCodec
        implements
        Codec<PushNotificationDevTokenStatus> {

    private final CodecRegistry codecRegistry;

    /**
     * Creates and returns a new instance of this class initialized with given
     * parameters.
     * 
     * @param codecRegistry
     *            the codec registry
     */
    public PushNotificationDevTokenStatusCodec(final CodecRegistry codecRegistry) {
        this.codecRegistry = codecRegistry;
    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Encoder#getEncoderClass()
     */
    @Override
    public Class<PushNotificationDevTokenStatus> getEncoderClass() {
        return PushNotificationDevTokenStatus.class;
    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Encoder#encode(org.bson.BsonWriter,
     * java.lang.Object, org.bson.codecs.EncoderContext)
     */
    @Override
    public void encode(final BsonWriter writer, final PushNotificationDevTokenStatus devTokenStatus,
            final EncoderContext encoderContext) {
        writer.writeStartDocument();

        if (null != devTokenStatus.getDevtoken()) {
            writer.writeName(Notification.DEVTOKEN);
            writer.writeString(devTokenStatus.getDevtoken());
        }

        if (null != devTokenStatus.getDevname()) {
            writer.writeName(Notification.DEVALIAS);
            writer.writeString(devTokenStatus.getDevname());
        }

        if (null != devTokenStatus.getResponseCode()) {
            writer.writeName(Notification.DEVTOKEN_RESPONSE_CODE);
            writer.writeInt32(devTokenStatus.getResponseCode());
        }

        if (null != devTokenStatus.getDevuuid()) {
            writer.writeName(Notification.DEVICE_UUID);
            writer.writeString(devTokenStatus.getDevuuid());
        }

        if (null != devTokenStatus.getDevtype()) {
            writer.writeName(Notification.DEVTYPE);
            writer.writeString(devTokenStatus.getDevtype());
        }

        if (null != devTokenStatus.getPnsmessageid()) {
            writer.writeName(Notification.PNS_MESSAGE_ID);
            writer.writeString(devTokenStatus.getPnsmessageid());
        }

        if (null != devTokenStatus.getPnstimestamp()) {
            writer.writeName(Notification.PNS_TIMESTAMP);
            writer.writeDateTime(devTokenStatus.getPnstimestamp().getTime());
        }

        writer.writeEndDocument();

    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Decoder#decode(org.bson.BsonReader,
     * org.bson.codecs.DecoderContext)
     */
    @Override
    public PushNotificationDevTokenStatus decode(final BsonReader reader, final DecoderContext decoderContext) {
        final PushNotificationDevTokenStatus devTokenStatus = new PushNotificationDevTokenStatus();
        reader.readStartDocument();

        while (reader.readBsonType() != BsonType.END_OF_DOCUMENT) {
            switch (reader.readName()) {
            case Notification.DEVTOKEN:
                devTokenStatus.setDevtoken(reader.readString());
                break;

            case Notification.DEVTOKEN_RESPONSE_CODE:
                devTokenStatus.setResponseCode(reader.readInt32());
                break;

            case Notification.DEVALIAS:
                devTokenStatus.setDevname(reader.readString());
                break;

            case Notification.DEVICE_UUID:
                devTokenStatus.setDevuuid(reader.readString());
                break;

            case Notification.DEVTYPE:
                devTokenStatus.setDevtype(reader.readString());
                break;

            case Notification.PNS_MESSAGE_ID:
                devTokenStatus.setPnsmessageid(reader.readString());
                break;

            case Notification.PNS_TIMESTAMP:
                devTokenStatus.setPnstimestamp(new Date(reader.readDateTime()));
                break;

            default:
                break;
            }
        }

        reader.readEndDocument();
        return devTokenStatus;
    }

}
