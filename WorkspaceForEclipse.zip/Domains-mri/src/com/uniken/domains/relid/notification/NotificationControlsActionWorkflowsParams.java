/**
 * 
 */
package com.uniken.domains.relid.notification;

import com.google.gson.annotations.SerializedName;

public class NotificationControlsActionWorkflowsParams {

    @SerializedName(Notification.NOTIFICATION_CONTROLS_ACTION_WORKFLOWS_PARAMS_JWT_EXPIRES_IN)
    private int jwtExpiresIn;

    /**
     * @return the jwtExpiresIn
     */
    public int getJwtExpiresIn() {
        return jwtExpiresIn;
    }

    /**
     * @param jwtExpiresIn
     *            the jwtExpiresIn to set
     */
    public void setJwtExpiresIn(final int jwtExpiresIn) {
        this.jwtExpiresIn = jwtExpiresIn;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("NotificationControlsActionWorkflowsParams [jwtExpiresIn=");
        builder.append(jwtExpiresIn);
        builder.append("]");
        return builder.toString();
    }

}
