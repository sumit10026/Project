/**
 * 
 */
package com.uniken.domains.relid.notification.codec;

import org.bson.BsonReader;
import org.bson.BsonType;
import org.bson.BsonWriter;
import org.bson.codecs.Codec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.codecs.configuration.CodecRegistry;

import com.uniken.domains.relid.notification.Notification;
import com.uniken.domains.relid.notification.NotificationControlsActionWorkflows;
import com.uniken.domains.relid.notification.NotificationControls;
import com.uniken.domains.relid.notification.NotificationControlsOtp;
import com.uniken.domains.relid.notification.NotificationControlsPushFallback;
import com.uniken.domains.relid.notification.NotificationControlsPushRetry;

/**
 * @author UNIKEN
 */
public class NotificationControlsCodec
        implements
        Codec<NotificationControls> {

    private final CodecRegistry codecRegistry;

    /**
     * Creates and returns a new instance of this class initialized with given
     * parameters.
     * 
     * @param codecRegistry
     *            the codec registry
     */
    public NotificationControlsCodec(final CodecRegistry codecRegistry) {
        this.codecRegistry = codecRegistry;
    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Encoder#getEncoderClass()
     */
    @Override
    public Class<NotificationControls> getEncoderClass() {
        return NotificationControls.class;
    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Encoder#encode(org.bson.BsonWriter,
     * java.lang.Object, org.bson.codecs.EncoderContext)
     */
    @Override
    public void encode(final BsonWriter writer, final NotificationControls object,
            final EncoderContext encoderContext) {
        writer.writeStartDocument();

        if (null != object.getPushRetry()) {
            writer.writeName(Notification.NOTIFICATION_CONTROLS_PUSH_RETRY);
            final Codec<NotificationControlsPushRetry> notificationControlsPushRetryCodec = codecRegistry
                    .get(NotificationControlsPushRetry.class);
            notificationControlsPushRetryCodec.encode(writer, object.getPushRetry(), encoderContext);
        }

        if (null != object.getPushFallback()) {
            writer.writeName(Notification.NOTIFICATION_CONTROLS_PUSH_FALLBACK);
            final Codec<NotificationControlsPushFallback> notificationControlsPushFallbackCodec = codecRegistry
                    .get(NotificationControlsPushFallback.class);
            notificationControlsPushFallbackCodec.encode(writer, object.getPushFallback(), encoderContext);
        }

        if (null != object.getOtp()) {
            writer.writeName(Notification.NOTIFICATION_CONTROLS_OTP);
            final Codec<NotificationControlsOtp> notificationControlsOtpCodec = codecRegistry
                    .get(NotificationControlsOtp.class);
            notificationControlsOtpCodec.encode(writer, object.getOtp(), encoderContext);
        }

        if (null != object.getActionWorkflows()) {
            writer.writeName(Notification.NOTIFICATION_CONTROLS_ACTION_WORKFLOWS);
            final Codec<NotificationControlsActionWorkflows> notificationActionWorkflowsCodec = codecRegistry
                    .get(NotificationControlsActionWorkflows.class);
            notificationActionWorkflowsCodec.encode(writer, object.getActionWorkflows(), encoderContext);
        }

        writer.writeEndDocument();

    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Decoder#decode(org.bson.BsonReader,
     * org.bson.codecs.DecoderContext)
     */
    @Override
    public NotificationControls decode(final BsonReader reader, final DecoderContext decoderContext) {
        final NotificationControls object = new NotificationControls();
        reader.readStartDocument();

        while (reader.readBsonType() != BsonType.END_OF_DOCUMENT) {
            switch (reader.readName()) {
            case Notification.NOTIFICATION_CONTROLS_PUSH_RETRY:
                final Codec<NotificationControlsPushRetry> notificationControlsPushRetryCodec = codecRegistry
                        .get(NotificationControlsPushRetry.class);
                final NotificationControlsPushRetry notificationControlsPushRetry = notificationControlsPushRetryCodec
                        .decode(reader, decoderContext);
                object.setPushRetry(notificationControlsPushRetry);
                break;

            case Notification.NOTIFICATION_CONTROLS_PUSH_FALLBACK:
                final Codec<NotificationControlsPushFallback> notificationControlsPushFallbackCodec = codecRegistry
                        .get(NotificationControlsPushFallback.class);
                final NotificationControlsPushFallback notificationControlsPushFallback = notificationControlsPushFallbackCodec
                        .decode(reader, decoderContext);
                object.setPushFallback(notificationControlsPushFallback);
                break;

            case Notification.NOTIFICATION_CONTROLS_OTP:
                final Codec<NotificationControlsOtp> notificationControlsOtpCodec = codecRegistry
                        .get(NotificationControlsOtp.class);
                final NotificationControlsOtp notificationControlsOtp = notificationControlsOtpCodec.decode(reader,
                        decoderContext);
                object.setOtp(notificationControlsOtp);
                break;

            case Notification.NOTIFICATION_CONTROLS_ACTION_WORKFLOWS:
                final Codec<NotificationControlsActionWorkflows> notificationActionWorkflowsCodec = codecRegistry
                        .get(NotificationControlsActionWorkflows.class);
                final NotificationControlsActionWorkflows actionWorkflows = notificationActionWorkflowsCodec.decode(reader,
                        decoderContext);
                object.setActionWorkflows(actionWorkflows);
                break;

            default:
                break;
            }
        }

        reader.readEndDocument();
        return object;
    }

}
