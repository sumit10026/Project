/**
 * 
 */
package com.uniken.domains.relid.notification;

import com.google.gson.annotations.SerializedName;

public class NotificationControls {

    @SerializedName("push_retry")
    private NotificationControlsPushRetry pushRetry;

    @SerializedName("push_fallback")
    private NotificationControlsPushFallback pushFallback;

    @SerializedName("otp")
    private NotificationControlsOtp otp;

    @SerializedName(Notification.NOTIFICATION_CONTROLS_ACTION_WORKFLOWS)
    private NotificationControlsActionWorkflows actionWorkflows;

    /**
     * @return the pushRetry
     */
    public NotificationControlsPushRetry getPushRetry() {
        return pushRetry;
    }

    /**
     * @param pushRetry
     *            the pushRetry to set
     */
    public void setPushRetry(final NotificationControlsPushRetry pushRetry) {
        this.pushRetry = pushRetry;
    }

    /**
     * @return the pushFallback
     */
    public NotificationControlsPushFallback getPushFallback() {
        return pushFallback;
    }

    /**
     * @param pushFallback
     *            the pushFallback to set
     */
    public void setPushFallback(final NotificationControlsPushFallback pushFallback) {
        this.pushFallback = pushFallback;
    }

    /**
     * @return the otp
     */
    public NotificationControlsOtp getOtp() {
        return otp;
    }

    /**
     * @param otp
     *            the otp to set
     */
    public void setOtp(final NotificationControlsOtp otp) {
        this.otp = otp;
    }

    /**
     * @return the actionWorkflows
     */
    public NotificationControlsActionWorkflows getActionWorkflows() {
        return actionWorkflows;
    }

    /**
     * @param actionWorkflows
     *            the actionWorkflows to set
     */
    public void setActionWorkflows(final NotificationControlsActionWorkflows actionWorkflows) {
        this.actionWorkflows = actionWorkflows;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("NotificationControls [");
        builder.append("pushRetry=").append(pushRetry != null ? pushRetry.toString() : "EMPTY");
        builder.append(", pushFallback=").append(pushFallback != null ? pushFallback.toString() : "EMPTY");
        builder.append(", otp=").append(otp != null ? otp.toString() : "EMPTY");
        builder.append(", notificationActionWorkflows=").append(actionWorkflows != null ? actionWorkflows : "EMPTY");
        builder.append("]");
        return builder.toString();
    }

}
