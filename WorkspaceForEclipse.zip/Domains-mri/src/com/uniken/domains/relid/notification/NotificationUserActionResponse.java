/**
 * 
 */
package com.uniken.domains.relid.notification;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * @author Chetan Patil
 */
public class NotificationUserActionResponse extends WSResponse {

    public final static String USER_ID = "user_id";
    public final static String NOTIFICATION_UUID = "notification_uuid";
    public final static String ACTION_RESPONSE = "action_response";
    public final static String STATUS = "status";
    public final static String MSG_ID = "msg_id";
    public final static String DELIVERY_STATUS = "delivery_status";
    public static final String VERIFICATION_MODE = "verification_mode";
    public static final String ORIGINAL_VERIFICATION_MODE = "original_verification_mode";
    public final static String PUSH_FALLBACK_STATUS = "push_fallback_status";
    public static final String IS_DS_VERIFIED = "is_ds_verified";
    public final static String JWT = "jwt";
    public final static String TOKEN = "token";
    public final static String DEVICE_TO_BE_ACTIVATED = "device_to_be_activated";
    public final static String APP_UUID = "app_uuid";
    public final static String CREATE_TS = "create_ts";
    public final static String UPDATE_TS = "update_ts";
    public final static String EXPIRY_TIMESTAMP = "expiry_timestamp";
    public final static String CLIENT_IP_ADDRESS = "client_ip_address";

    @SerializedName(USER_ID)
    private String userId;

    @SerializedName(NOTIFICATION_UUID)
    private String notificationUuid;

    @SerializedName(ACTION_RESPONSE)
    private String actionResponse;

    @SerializedName(STATUS)
    private String status;

    @SerializedName(MSG_ID)
    private String msgId;

    @SerializedName(DELIVERY_STATUS)
    private String deliveryStatus;

    @SerializedName(VERIFICATION_MODE)
    private String verificationMode;

    @SerializedName(ORIGINAL_VERIFICATION_MODE)
    private String originalVerificationMode;

    @SerializedName(PUSH_FALLBACK_STATUS)
    private String pushFallbackStatus;

    @SerializedName(IS_DS_VERIFIED)
    private boolean dsVerified;

    @SerializedName(JWT)
    private String jwt;

    @SerializedName(TOKEN)
    private String token;

    @SerializedName(DEVICE_TO_BE_ACTIVATED)
    @Field(DEVICE_TO_BE_ACTIVATED)
    private String deviceToBeActivated;

    @SerializedName(APP_UUID)
    @Field(APP_UUID)
    private String appUuid;

    @SerializedName(CREATE_TS)
    @Field(CREATE_TS)
    private Date createTimestamp;

    @SerializedName(UPDATE_TS)
    @Field(UPDATE_TS)
    private Date updateTimestamp;

    @SerializedName(EXPIRY_TIMESTAMP)
    @Field(EXPIRY_TIMESTAMP)
    private Date expiryTimestamp;

    @SerializedName(CLIENT_IP_ADDRESS)
    @Field(CLIENT_IP_ADDRESS)
    private String clientIpAddress;

    /**
     * 
     */
    public NotificationUserActionResponse() {
    }

    /**
     * @param notificationUuid
     * @param actionResponse
     * @param status
     * @param msgId
     */
    public NotificationUserActionResponse(final String userId, final String notificationUuid,
            final String actionResponse, final String status, final String msgId, final boolean dsVerified) {
        this.userId = userId;
        this.notificationUuid = notificationUuid;
        this.actionResponse = actionResponse;
        this.status = status;
        this.msgId = msgId;
        this.dsVerified = dsVerified;
    }

    public static NotificationUserActionResponse getNotificationUserActionResponse(final Notification notification) {

        final NotificationUserActionResponse notificationUserActionResponse = new NotificationUserActionResponse(
                notification.getUserId(), notification.getNotificationUuid(), notification.getActionPerformed(),
                notification.getStatus().name(), notification.getMsgId(), notification.isDsVerified());

        if (notification.getDeliveryStatus() != null)
            notificationUserActionResponse.setDeliveryStatus(notification.getDeliveryStatus().name());

        if (notification.getOriginalVerificationMode() != null
                && notification.getOriginalVerificationMode().trim().length() > 0) {
            notificationUserActionResponse.setPushFallbackStatus("FALLBACK-" + notification.getVerificationMode());
            notificationUserActionResponse.setOriginalVerificationMode(notification.getOriginalVerificationMode());
        }

        return notificationUserActionResponse;
    }

    /**
     * This will give the instance of NotificationUserActionResponse. Only be
     * used in-case of error response.
     * 
     * @param msgId
     * @param responseCode
     * @param errorCode
     * @param errorMessage
     * @return
     */
    public static NotificationUserActionResponse getErrorResponseInstance(final String msgId,
            final Integer responseCode, final Integer errorCode, final String errorMessage) {

        final NotificationUserActionResponse response = new NotificationUserActionResponse();

        response.setMsgId(msgId);
        response.setResponseCode(responseCode);
        response.setErrorCode(errorCode);
        response.setErrorMessage(errorMessage);

        return response;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(final String status) {
        this.status = status;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @return the notificationUuid
     */
    public String getNotificationUuid() {
        return notificationUuid;
    }

    /**
     * @param notificationUuid
     *            the notificationUuid to set
     */
    public void setNotificationUuid(final String notificationUuid) {
        this.notificationUuid = notificationUuid;
    }

    /**
     * @return the actionResponse
     */
    public String getActionResponse() {
        return actionResponse;
    }

    /**
     * @param actionResponse
     *            the actionResponse to set
     */
    public void setActionResponse(final String actionResponse) {
        this.actionResponse = actionResponse;
    }

    /**
     * @return the deliveryStatus
     */
    public String getDeliveryStatus() {
        return deliveryStatus;
    }

    /**
     * @param deliveryStatus
     *            the deliveryStatus to set
     */
    public void setDeliveryStatus(final String deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }

    /**
     * @return the msgId
     */
    public String getMsgId() {
        return msgId;
    }

    /**
     * @param msgId
     *            the msgId to set
     */
    public void setMsgId(final String msgId) {
        this.msgId = msgId;
    }

    /**
     * @return the verificationMode
     */
    public String getVerificationMode() {
        return verificationMode;
    }

    /**
     * @param verificationMode
     *            the verificationMode to set
     */
    public void setVerificationMode(final String verificationMode) {
        this.verificationMode = verificationMode;
    }

    /**
     * @return the originalVerificationMode
     */
    public String getOriginalVerificationMode() {
        return originalVerificationMode;
    }

    /**
     * @param originalVerificationMode
     *            the originalVerificationMode to set
     */
    public void setOriginalVerificationMode(final String originalVerificationMode) {
        this.originalVerificationMode = originalVerificationMode;
    }

    /**
     * @return the pushFallbackStatus
     */
    public String getPushFallbackStatus() {
        return pushFallbackStatus;
    }

    /**
     * @param pushFallbackStatus
     *            the pushFallbackStatus to set
     */
    public void setPushFallbackStatus(final String pushFallbackStatus) {
        this.pushFallbackStatus = pushFallbackStatus;
    }

    /**
     * @return the dsVerified
     */
    public boolean isDsVerified() {
        return dsVerified;
    }

    /**
     * @param dsVerified
     *            the dsVerified to set
     */
    public void setDsVerified(final boolean dsVerified) {
        this.dsVerified = dsVerified;
    }

    /**
     * @return the jwt
     */
    public String getJwt() {
        return jwt;
    }

    /**
     * @param jwt
     *            the jwt to set
     */
    public void setJwt(final String jwt) {
        this.jwt = jwt;
    }

    /**
     * @return the token
     */
    public String getToken() {
        return token;
    }

    /**
     * @param token
     *            the token to set
     */
    public void setToken(final String token) {
        this.token = token;
    }

    /**
     * @return the deviceToBeActivated
     */
    public String getDeviceToBeActivated() {
        return deviceToBeActivated;
    }

    /**
     * @param deviceToBeActivated
     *            the deviceToBeActivated to set
     */
    public void setDeviceToBeActivated(final String deviceToBeActivated) {
        this.deviceToBeActivated = deviceToBeActivated;
    }

    /**
     * @return the appUuid
     */
    public String getAppUuid() {
        return appUuid;
    }

    /**
     * @param appUuid
     *            the appUuid to set
     */
    public void setAppUuid(final String appUuid) {
        this.appUuid = appUuid;
    }

    /**
     * @return the createTimestamp
     */
    public Date getCreateTimestamp() {
        return createTimestamp;
    }

    /**
     * @param createTimestamp
     *            the createTimestamp to set
     */
    public void setCreateTimestamp(final Date createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    /**
     * @return the updateTimestamp
     */
    public Date getUpdateTimestamp() {
        return updateTimestamp;
    }

    /**
     * @param updateTimestamp
     *            the updateTimestamp to set
     */
    public void setUpdateTimestamp(final Date updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

    /**
     * @return the expiryTimestamp
     */
    public Date getExpiryTimestamp() {
        return expiryTimestamp;
    }

    /**
     * @param expiryTimestamp
     *            the expiryTimestamp to set
     */
    public void setExpiryTimestamp(final Date expiryTimestamp) {
        this.expiryTimestamp = expiryTimestamp;
    }

    /**
     * @return the clientIpAddress
     */
    public String getClientIpAddress() {
        return clientIpAddress;
    }

    /**
     * @param clientIpAddress
     *            the clientIpAddress to set
     */
    public void setClientIpAddress(final String clientIpAddress) {
        this.clientIpAddress = clientIpAddress;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("NotificationUserActionResponse [userId=");
        builder.append(userId);
        builder.append(", notificationUuid=");
        builder.append(notificationUuid);
        builder.append(", actionResponse=");
        builder.append(actionResponse);
        builder.append(", status=");
        builder.append(status);
        builder.append(", msgId=");
        builder.append(msgId);
        builder.append(", deliveryStatus=");
        builder.append(deliveryStatus);
        builder.append(", verificationMode=");
        builder.append(verificationMode);
        builder.append(", originalVerificationMode=");
        builder.append(originalVerificationMode);
        builder.append(", pushFallbackStatus=");
        builder.append(pushFallbackStatus);
        builder.append(", dsVerified=");
        builder.append(dsVerified);
        builder.append(", jwt=");
        builder.append(jwt);
        builder.append(", token=");
        builder.append(token);
        builder.append(", deviceToBeActivated=");
        builder.append(deviceToBeActivated);
        builder.append(", appUuid=");
        builder.append(appUuid);
        builder.append(", createTimestamp=");
        builder.append(createTimestamp);
        builder.append(", updateTimestamp=");
        builder.append(updateTimestamp);
        builder.append(", expiryTimestamp=");
        builder.append(expiryTimestamp);
        builder.append(", clientIpAddress=");
        builder.append(clientIpAddress);
        builder.append("]");
        return builder.toString();
    }

}
