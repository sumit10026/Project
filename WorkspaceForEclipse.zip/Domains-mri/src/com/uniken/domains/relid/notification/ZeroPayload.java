package com.uniken.domains.relid.notification;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.relid.device.DfpParameters;

public class ZeroPayload {

    @SerializedName("session_id")
    private String sessionId;

    @SerializedName("device_uuid")
    private String deviceId;

    @SerializedName("app_uuid")
    private String appUuid;

    // @SerializedName("timestamp")
    // private Date timestamp;

    @SerializedName("uuid")
    private String uuidOfRelId;

    @SerializedName("node_name")
    private String nodeName;

    @SerializedName("device_details")
    private DfpParameters deviceDetails;

    @SerializedName("client_ip_address")
    private String clientIpAddress;

    @SerializedName("user_id")
    private String userId;

    public void copyRequestPayload(final ZeroPayload payload) {

        this.setDeviceId(payload.getDeviceId());
        this.setNodeName(payload.getNodeName());
        this.setSessionId(payload.getSessionId());
        // this.setTimestamp(payload.getTimestamp());
        this.setUuidOfRelId(payload.getUuidOfRelId());
        this.setDeviceDetails(payload.getDeviceDetails());
        this.setClientIpAddress(payload.getClientIpAddress());
        this.setUserId(payload.getUserId());
    }

    /**
     * @return the sessionId
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * @param sessionId
     *            the sessionId to set
     */
    public void setSessionId(final String sessionId) {
        this.sessionId = sessionId;
    }

    /**
     * @return the deviceId
     */
    public String getDeviceId() {
        return deviceId;
    }

    /**
     * @param deviceId
     *            the deviceId to set
     */
    public void setDeviceId(final String deviceId) {
        this.deviceId = deviceId;
    }

    /**
     * @return the appUuid
     */
    public String getAppUuid() {
        return appUuid;
    }

    /**
     * @param appUuid
     *            the appUuid to set
     */
    public void setAppUuid(final String appUuid) {
        this.appUuid = appUuid;
    }

    /**
     * @return the timestamp
     */
    // public Date getTimestamp() {
    // return timestamp;
    // }

    /**
     * @param timestamp
     *            the timestamp to set
     */
    // public void setTimestamp(final Date timestamp) {
    // this.timestamp = timestamp;
    // }

    /**
     * @return the nodeName
     */
    public String getNodeName() {
        return nodeName;
    }

    /**
     * @param nodeName
     *            the nodeName to set
     */
    public void setNodeName(final String nodeName) {
        this.nodeName = nodeName;
    }

    /**
     * @return the uuidOfRelId
     */
    public String getUuidOfRelId() {
        return uuidOfRelId;
    }

    /**
     * @param uuidOfRelId
     *            the uuidOfRelId to set
     */
    public void setUuidOfRelId(final String uuidOfRelId) {
        this.uuidOfRelId = uuidOfRelId;
    }

    /**
     * @return the deviceDetails
     */
    public DfpParameters getDeviceDetails() {
        return deviceDetails;
    }

    /**
     * @param deviceDetails
     *            the deviceDetails to set
     */
    public void setDeviceDetails(final DfpParameters deviceDetails) {
        this.deviceDetails = deviceDetails;
    }

    public String getClientIpAddress() {
        return clientIpAddress;
    }

    public void setClientIpAddress(final String clientIpAddress) {
        this.clientIpAddress = clientIpAddress;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("ZeroRequest [sessionId=");
        builder.append(sessionId);
        builder.append(", deviceId=");
        builder.append(deviceId);
        // builder.append(", timestamp=");
        // builder.append(timestamp);
        builder.append(", uuidOfRelId=");
        builder.append(uuidOfRelId);
        builder.append(", nodeName=");
        builder.append(nodeName);

        if (deviceDetails != null) {
            builder.append(", deviceDetails=");
            builder.append(deviceDetails.toString());
        }

        builder.append(", clientIpAddress=");
        builder.append(clientIpAddress);

        builder.append(", userId=");
        builder.append(userId);

        builder.append("]");
        return builder.toString();
    }

}
