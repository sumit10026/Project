/**
 * 
 */
package com.uniken.domains.relid.notification;

import com.google.gson.annotations.SerializedName;

public class NotificationControlsPushRetry {

    @SerializedName("type")
    private String type;

    @SerializedName("interval")
    private int interval;

    @SerializedName("number")
    private int number;

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type
     *            the type to set
     */
    public void setType(final String type) {
        this.type = type;
    }

    /**
     * @return the interval
     */
    public int getInterval() {
        return interval;
    }

    /**
     * @param interval
     *            the interval to set
     */
    public void setInterval(final int interval) {
        this.interval = interval;
    }

    /**
     * @return the number
     */
    public int getNumber() {
        return number;
    }

    /**
     * @param number
     *            the number to set
     */
    public void setNumber(final int number) {
        this.number = number;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("NotificationControlsPushRetry [type=").append(type).append(", interval=").append(interval)
                .append(", number=").append(number).append("]");
        return builder.toString();
    }

}
