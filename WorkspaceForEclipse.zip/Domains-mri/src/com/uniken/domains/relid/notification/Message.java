package com.uniken.domains.relid.notification;

import java.util.Map;

import com.google.gson.annotations.SerializedName;

public class Message {

    private static final String LNG = "lng";
    private static final String SUBJECT = "subject";
    private static final String MESSAGE = "message";
    private static final String LABEL = "label";

    @SerializedName(LNG)
    private String lng;

    @SerializedName(SUBJECT)
    private String subject;

    @SerializedName(MESSAGE)
    private String message;

    @SerializedName(LABEL)
    private Map<String, Object> label;

    /**
     * @return the lng
     */
    public String getLng() {
        return lng;
    }

    /**
     * @param lng
     *            the lng to set
     */
    public void setLng(final String lng) {
        this.lng = lng;
    }

    /**
     * @return the subject
     */
    public String getSubject() {
        return subject;
    }

    /**
     * @param subject
     *            the subject to set
     */
    public void setSubject(final String subject) {
        this.subject = subject;
    }

    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message
     *            the message to set
     */
    public void setMessage(final String message) {
        this.message = message;
    }

    /**
     * @return the label
     */
    public Map<String, Object> getLabel() {
        return label;
    }

    /**
     * @param label
     *            the label to set
     */
    public void setLabel(final Map<String, Object> label) {
        this.label = label;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("Message [");
        builder.append("lng=");
        builder.append(lng);
        builder.append("subject=");
        builder.append(subject);
        builder.append(", message=");
        builder.append(message);
        builder.append(", label=");
        builder.append(label);
        builder.append("]");
        return builder.toString();
    }

}
