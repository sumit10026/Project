package com.uniken.domains.relid.notification.codec;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.BsonReader;
import org.bson.BsonType;
import org.bson.BsonWriter;
import org.bson.codecs.Codec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.codecs.configuration.CodecRegistry;

import com.uniken.domains.enums.NotificationStatus;
import com.uniken.domains.relid.device.DfpParameters;
import com.uniken.domains.relid.notification.Action;
import com.uniken.domains.relid.notification.Message;
import com.uniken.domains.relid.notification.Notification;
import com.uniken.domains.relid.notification.NotificationControls;
import com.uniken.domains.relid.notification.PushNotificationDevTokenStatus;
import com.uniken.domains.relid.user.vo.UserAuthInfoVO;

public class NotificationCodec
        implements
        Codec<Notification> {

    private final CodecRegistry codecRegistry;

    public NotificationCodec(final CodecRegistry codecRegistry) {
        this.codecRegistry = codecRegistry;
    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Encoder#encode(org.bson.BsonWriter,
     * java.lang.Object, org.bson.codecs.EncoderContext)
     */
    @Override
    public void encode(final BsonWriter writer, final Notification notification, final EncoderContext encoderContext) {

        writer.writeStartDocument();

        if (notification.getNotificationUuid() != null) {
            writer.writeName(Notification.NOTIFICATION_UUID);
            writer.writeString(notification.getNotificationUuid());
        }

        if (notification.getUserId() != null) {
            writer.writeName(Notification.USER_ID);
            writer.writeString(notification.getUserId());
        }

        if (notification.getUserUuid() != null) {
            writer.writeName(Notification.USER_UUID);
            writer.writeString(notification.getUserUuid());
        }

        if (notification.getStatus() != null) {
            writer.writeName(Notification.STATUS);
            writer.writeString(notification.getStatus().toString());
        }

        if (notification.getDeliveryStatus() != null) {
            writer.writeName(Notification.DELIVERY_STATUS);
            writer.writeString(notification.getDeliveryStatus().toString());
        }

        if (notification.getExpiryTimestamp() != null) {
            writer.writeName(Notification.EXPIRY_TIMESTAMP);
            writer.writeDateTime(notification.getExpiryTimestamp().getTime());
        }

        if (notification.getMsg() != null) {
            writer.writeName(Notification.MESSAGE);
            final Codec<Message> messageCodec = codecRegistry.get(Message.class);
            writer.writeStartArray();
            for (final Message message : notification.getMsg()) {
                messageCodec.encode(writer, message, encoderContext);
            }
            writer.writeEndArray();
        }

        if (notification.getNotificationMessage() != null) {
            writer.writeName(Notification.NOTIFICATION_MESSAGE);
            final Codec<Message> notificationMessageCodec = codecRegistry.get(Message.class);
            notificationMessageCodec.encode(writer, notification.getNotificationMessage(), encoderContext);
        }

        if (notification.getCreateTimestamp() != null) {
            writer.writeName(Notification.CREATE_TS);
            writer.writeDateTime(notification.getCreateTimestamp().getTime());
        }

        if (notification.getUpdateTimestamp() != null) {
            writer.writeName(Notification.UPDATE_TS);
            writer.writeDateTime(notification.getUpdateTimestamp().getTime());
        }

        if (notification.getActionPerformed() != null) {
            writer.writeName(Notification.ACTION_PERFORMED);
            writer.writeString(notification.getActionPerformed());
        }

        if (notification.getActionDeviceUuid() != null) {
            writer.writeName(Notification.ACTION_DEVICE_UUID);
            writer.writeString(notification.getActionDeviceUuid());
        }

        if (notification.getActionDeviceName() != null) {
            writer.writeName(Notification.ACTION_DEVICE_NAME);
            writer.writeString(notification.getActionDeviceName());
        }

        if (notification.getActions() != null) {
            writer.writeName(Notification.ACTIONS);
            final Codec<Action> actionsCodec = codecRegistry.get(Action.class);
            writer.writeStartArray();
            for (final Action action : notification.getActions()) {
                actionsCodec.encode(writer, action, encoderContext);
            }
            writer.writeEndArray();
        }

        if (notification.getEnterpriseId() != null) {
            writer.writeName(Notification.ENTERPRISE_ID);
            writer.writeString(notification.getEnterpriseId());
        }

        if (notification.getAppUuid() != null) {
            writer.writeName(Notification.APP_UUID);
            writer.writeString(notification.getAppUuid());
        }

        if (notification.getAppId() != null) {
            writer.writeName(Notification.APP_ID);
            writer.writeString(notification.getAppId());
        }

        if (notification.getExpiresIn() != null) {
            writer.writeName(Notification.EXPIRES_IN);
            writer.writeInt32(notification.getExpiresIn());
        }

        if (notification.getRequestAcceptTimestamp() != null) {
            writer.writeName(Notification.REQUEST_ACCEPT_TS);
            writer.writeDateTime(notification.getRequestAcceptTimestamp().getTime());
        }

        if (null != notification.getDevTokenStatusList()) {
            writer.writeName(Notification.DEVTOKEN_STATUS);
            final Codec<PushNotificationDevTokenStatus> devTokenStatusCodec = codecRegistry
                    .get(PushNotificationDevTokenStatus.class);
            writer.writeStartArray();
            for (final PushNotificationDevTokenStatus devTokenStatus : notification.getDevTokenStatusList()) {
                devTokenStatusCodec.encode(writer, devTokenStatus, encoderContext);
            }
            writer.writeEndArray();
        }

        if (notification.getCallbackUrl() != null) {
            writer.writeName(Notification.CALLBACK_URL);
            writer.writeString(notification.getCallbackUrl());
        }

        if (notification.getCallbackResponse() != null) {
            writer.writeName(Notification.CALLBACK_RESPONSE);
            writer.writeString(notification.getCallbackResponse());
        }

        writer.writeName(Notification.CALLBACK_ATTEMPTS);
        writer.writeInt32(notification.getCallbackAttempts());

        if (notification.getCallbackAttemptUpdateTs() != null) {
            writer.writeName(Notification.CALLBACK_ATTEMPT_UPDATE_TS);
            writer.writeDateTime(notification.getCallbackAttemptUpdateTs().getTime());
        }

        writer.writeName(Notification.DS_REQUIRED);
        writer.writeBoolean(notification.isDsRequired());

        if (notification.getMobileNumber() != null) {
            writer.writeName(UserAuthInfoVO.MOBILE_NUMBER_STR);
            writer.writeString(notification.getMobileNumber());
        }

        if (notification.getMsgType() != null) {
            writer.writeName(Notification.MSG_TYPE_STR);
            writer.writeString(notification.getMsgType());
        }

        if (notification.getModePref() != null) {
            writer.writeName(Notification.MODE_PREF_STR);
            writer.writeString(notification.getModePref());
        }

        if (notification.getVerificationMode() != null) {
            writer.writeName(Notification.VERIFICATION_MODE_STR);
            writer.writeString(notification.getVerificationMode());
        }

        if (notification.getOriginalVerificationMode() != null) {
            writer.writeName(Notification.ORIGINAL_VERIFICATION_MODE_STR);
            writer.writeString(notification.getOriginalVerificationMode());
        }

        if (notification.getSmsMsg() != null) {
            writer.writeName(Notification.SMS_MSG_STR);
            writer.writeString(notification.getSmsMsg());
        }

        if (notification.getCallMsg() != null) {
            writer.writeName(Notification.CALL_MSG_STR);
            writer.writeString(notification.getCallMsg());
        }

        if (notification.getSmsMsgIds() != null) {
            writer.writeName(Notification.SMS_MSG_IDS_STR);
            final Codec<String> smsMsgIdsCodec = codecRegistry.get(String.class);
            writer.writeStartArray();
            for (final String smsMsgId : notification.getSmsMsgIds()) {
                smsMsgIdsCodec.encode(writer, smsMsgId, encoderContext);
            }
            writer.writeEndArray();
        }

        if (notification.getSmsMsgStatus() != null) {
            writer.writeName(Notification.SMS_MSG_STATUS_STR);
            writer.writeString(notification.getSmsMsgStatus());
        }

        if (notification.getOtpValue() != null) {
            writer.writeName(Notification.OTP_VALUE_STR);
            writer.writeString(notification.getOtpValue());
        }

        if (notification.getHashSpec() != null) {
            writer.writeName(Notification.HASH_SPEC_STR);
            writer.writeString(notification.getHashSpec());
        }

        if (notification.getValidateOtpAttempts() != null) {
            writer.writeName(Notification.VALIDATE_OTP_ATTEMPTS);
            writer.writeInt32(notification.getValidateOtpAttempts());
        }

        if (notification.getValidateOtpStatus() != null) {
            writer.writeName(Notification.VALIDATE_OTP_STATUS);
            writer.writeString(notification.getValidateOtpStatus());
        }

        if (notification.getCertificate() != null) {
            writer.writeName(Notification.CERTIFICATE_STR);
            writer.writeString(notification.getCertificate());
        }

        if (notification.getPlainData() != null) {
            writer.writeName(Notification.PLAIN_DATA_STR);
            writer.writeString(notification.getPlainData());
        }

        if (notification.getSignature() != null) {
            writer.writeName(Notification.SIGNATURE_STR);
            writer.writeString(notification.getSignature());
        }

        writer.writeName(Notification.IS_DS_VERIFIED);
        writer.writeBoolean(notification.isDsVerified());

        if (notification.getUserStatus() != null) {
            writer.writeName(Notification.USER_STATUS);
            writer.writeString(notification.getUserStatus());
        }

        if (notification.getMsgId() != null) {
            writer.writeName(Notification.MSG_ID);
            writer.writeString(notification.getMsgId());
        }

        if (notification.getArchivedTs() != null) {
            writer.writeName(Notification.ARCHIVED_TS);
            writer.writeDateTime(notification.getArchivedTs().getTime());
        }

        if (notification.getControls() != null) {
            writer.writeName(Notification.NOTIFICATION_CONTROLS);
            final Codec<NotificationControls> notificationControlsCodec = codecRegistry.get(NotificationControls.class);
            notificationControlsCodec.encode(writer, notification.getControls(), encoderContext);
        }

        if (notification.getNotificationRequesterIP() != null) {
            writer.writeName(Notification.NOTIFICATION_REQUESTER_IP);
            writer.writeString(notification.getNotificationRequesterIP());
        }

        if (notification.getNotificationRequesterName() != null) {
            writer.writeName(Notification.NOTIFICATION_REQUESTER_NAME);
            writer.writeString(notification.getNotificationRequesterName());
        }

        if (notification.getSessionId() != null) {
            writer.writeName(Notification.NOTIFICATION_SESSION_ID);
            writer.writeString(notification.getSessionId());
        }

        if (notification.getDeviceDetails() != null) {
            writer.writeName(Notification.DEVICE_DETAILS);
            codecRegistry.get(DfpParameters.class).encode(writer, notification.getDeviceDetails(), encoderContext);
        }

        if (notification.getJwt() != null) {
            writer.writeName(Notification.JWT);
            writer.writeString(notification.getJwt());
        }

        if (notification.getToken() != null) {
            writer.writeName(Notification.TOKEN);
            writer.writeString(notification.getToken());
        }

        if (notification.getDeviceToBeActivated() != null) {
            writer.writeName(Notification.DEVICE_TO_BE_ACTIVATED);
            writer.writeString(notification.getDeviceToBeActivated());
        }

        if (notification.getPrimaryGroup() != null) {
            writer.writeName(Notification.PRIMARY_GROUP_NAME_STR);
            writer.writeString(notification.getPrimaryGroup());
        }

        if (notification.getSecondaryGroupNames() != null) {
            writer.writeName(Notification.SECONDARY_GROUP_NAMES_STR);
            final Codec<String> secGrpNamesCodec = codecRegistry.get(String.class);
            writer.writeStartArray();
            for (final String group : notification.getSecondaryGroupNames()) {
                secGrpNamesCodec.encode(writer, group, encoderContext);
            }
            writer.writeEndArray();
        }

        if (notification.getClientIpAddress() != null) {
            writer.writeName(Notification.CLIENT_IP_ADDRESS);
            writer.writeString(notification.getClientIpAddress());
        }

        writer.writeEndDocument();
    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Encoder#getEncoderClass()
     */
    @Override
    public Class<Notification> getEncoderClass() {
        return Notification.class;
    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Decoder#decode(org.bson.BsonReader,
     * org.bson.codecs.DecoderContext)
     */
    @Override
    public Notification decode(final BsonReader reader, final DecoderContext decodeContext) {

        final Notification notificationDocument = new Notification();
        final ArrayList<Message> messages = new ArrayList<>();
        final ArrayList<Action> actions = new ArrayList<>();
        final ArrayList<String> smsMsgIds = new ArrayList<>();
        final ArrayList<String> secondaryGroups = new ArrayList<>();
        final ArrayList<String> secondaryGroupUuids = new ArrayList<>();

        reader.readStartDocument();
        while (reader.readBsonType() != BsonType.END_OF_DOCUMENT) {
            switch (reader.readName()) {
            case Notification.ID:
                notificationDocument.setId(reader.readObjectId());
                break;
            case Notification.USER_ID:
                notificationDocument.setUserId(reader.readString());
                break;
            case Notification.USER_UUID:
                notificationDocument.setUserUuid(reader.readString());
                break;
            case Notification.NOTIFICATION_UUID:
                notificationDocument.setNotificationUuid(reader.readString());
                break;
            case Notification.STATUS:
                final NotificationStatus status = NotificationStatus.valueOf(reader.readString());
                notificationDocument.setStatus(status);
                break;
            case Notification.DELIVERY_STATUS:
                final NotificationStatus deliveryStatus = NotificationStatus.valueOf(reader.readString());
                notificationDocument.setDeliveryStatus(deliveryStatus);
                break;
            case Notification.EXPIRES_IN:
                notificationDocument.setExpiresIn(reader.readInt32());
                break;
            case Notification.EXPIRY_TIMESTAMP:
                notificationDocument.setExpiryTimestamp(new Date(reader.readDateTime()));
                break;
            case Notification.MESSAGE:
                final Codec<Message> messageCode = codecRegistry.get(Message.class);

                reader.readStartArray();
                while (reader.readBsonType() != BsonType.END_OF_DOCUMENT) {
                    messages.add(messageCode.decode(reader, decodeContext));
                }
                reader.readEndArray();
                notificationDocument.setMsg(messages);
                break;
            case Notification.NOTIFICATION_MESSAGE:
                final Codec<Message> notificationMessageCodec = codecRegistry.get(Message.class);
                final Message notificationMessage = notificationMessageCodec.decode(reader, decodeContext);
                notificationDocument.setNotificationMessage(notificationMessage);
                break;
            case Notification.CREATE_TS:
                notificationDocument.setCreateTimestamp(new Date(reader.readDateTime()));
                break;
            case Notification.UPDATE_TS:
                notificationDocument.setUpdateTimestamp(new Date(reader.readDateTime()));
                break;
            case Notification.ACTION_PERFORMED:
                notificationDocument.setActionPerformed(reader.readString());
                break;
            case Notification.ACTION_DEVICE_UUID:
                final String tempADU = reader.readString();
                if (null == tempADU)
                    notificationDocument.setActionDeviceUuid("EMPTY_DEVICE_UUID");
                else
                    notificationDocument.setActionDeviceUuid(tempADU);
                break;
            case Notification.ACTION_DEVICE_NAME:
                final String tempADN = reader.readString();
                if (null == tempADN)
                    notificationDocument.setActionDeviceName("EMPTY_DEVICE_NAME");
                else
                    notificationDocument.setActionDeviceName(tempADN);
                break;
            case Notification.ACTIONS:
                final Codec<Action> actionCode = codecRegistry.get(Action.class);

                reader.readStartArray();
                while (reader.readBsonType() != BsonType.END_OF_DOCUMENT) {
                    actions.add(actionCode.decode(reader, decodeContext));
                }
                reader.readEndArray();
                notificationDocument.setActions(actions);

                break;
            case Notification.ENTERPRISE_ID:
                notificationDocument.setEnterpriseId(reader.readString());
                break;

            case Notification.APP_UUID:
                notificationDocument.setAppUuid(reader.readString());
                break;

            case Notification.APP_ID:
                notificationDocument.setAppId(reader.readString());
                break;

            case Notification.REQUEST_ACCEPT_TS:
                notificationDocument.setRequestAcceptTimestamp(new Date(reader.readDateTime()));
                break;

            case Notification.DEVTOKEN_STATUS:
                final Codec<PushNotificationDevTokenStatus> devTokenStatusCodec = codecRegistry
                        .get(PushNotificationDevTokenStatus.class);
                final List<PushNotificationDevTokenStatus> devTokenStatusList = new ArrayList<PushNotificationDevTokenStatus>();

                reader.readStartArray();
                while (reader.readBsonType() != BsonType.END_OF_DOCUMENT) {
                    devTokenStatusList.add(devTokenStatusCodec.decode(reader, decodeContext));
                }
                reader.readEndArray();

                notificationDocument.setDevTokenStatusList(devTokenStatusList);
                break;

            case Notification.CALLBACK_URL:
                notificationDocument.setCallbackUrl(reader.readString());
                break;

            case Notification.CALLBACK_RESPONSE:
                notificationDocument.setCallbackResponse(reader.readString());
                break;

            case Notification.CALLBACK_ATTEMPTS:
                notificationDocument.setCallbackAttempts(reader.readInt32());
                break;

            case Notification.CALLBACK_ATTEMPT_UPDATE_TS:
                notificationDocument.setCallbackAttemptUpdateTs(new Date(reader.readDateTime()));
                break;

            case Notification.DS_REQUIRED:
                notificationDocument.setDsRequired(reader.readBoolean());
                break;

            case Notification.MOBILE_NUMBER_STR:
                notificationDocument.setMobileNumber(reader.readString());
                break;

            case Notification.MSG_TYPE_STR:
                notificationDocument.setMsgType(reader.readString());
                break;

            case Notification.MODE_PREF_STR:
                notificationDocument.setModePref(reader.readString());
                break;

            case Notification.VERIFICATION_MODE_STR:
                notificationDocument.setVerificationMode(reader.readString());
                break;

            case Notification.ORIGINAL_VERIFICATION_MODE_STR:
                notificationDocument.setOriginalVerificationMode(reader.readString());
                break;

            case Notification.SMS_MSG_STR:
                notificationDocument.setSmsMsg(reader.readString());
                break;

            case Notification.CALL_MSG_STR:
                notificationDocument.setCallMsg(reader.readString());
                break;

            case Notification.SMS_MSG_IDS_STR:
                final Codec<String> smsMsgIdsCodec = codecRegistry.get(String.class);
                reader.readStartArray();
                while (reader.readBsonType() != BsonType.END_OF_DOCUMENT) {
                    smsMsgIds.add(smsMsgIdsCodec.decode(reader, decodeContext));
                }
                reader.readEndArray();
                notificationDocument.setSmsMsgIds(smsMsgIds);
                break;

            case Notification.SMS_MSG_STATUS_STR:
                notificationDocument.setSmsMsgStatus(reader.readString());
                break;

            case Notification.OTP_VALUE_STR:
                notificationDocument.setOtpValue(reader.readString());
                break;

            case Notification.HASH_SPEC_STR:
                notificationDocument.setHashSpec(reader.readString());
                break;

            case Notification.VALIDATE_OTP_ATTEMPTS:
                notificationDocument.setValidateOtpAttempts(reader.readInt32());
                break;

            case Notification.VALIDATE_OTP_STATUS:
                notificationDocument.setValidateOtpStatus(reader.readString());
                break;

            case Notification.CERTIFICATE_STR:
                notificationDocument.setCertificate(reader.readString());
                break;

            case Notification.PLAIN_DATA_STR:
                notificationDocument.setPlainData(reader.readString());
                break;

            case Notification.SIGNATURE_STR:
                notificationDocument.setSignature(reader.readString());
                break;

            case Notification.IS_DS_VERIFIED:
                notificationDocument.setDsVerified(reader.readBoolean());
                break;

            case Notification.USER_STATUS:
                notificationDocument.setUserStatus(reader.readString());
                break;

            case Notification.MSG_ID:
                notificationDocument.setMsgId(reader.readString());
                break;

            case Notification.NOTIFICATION_CONTROLS:
                final Codec<NotificationControls> notificationControlsCodec = codecRegistry
                        .get(NotificationControls.class);
                final NotificationControls notificationControls = notificationControlsCodec.decode(reader,
                        decodeContext);
                notificationDocument.setControls(notificationControls);
                break;

            case Notification.ARCHIVED_TS:
                notificationDocument.setArchivedTs(new Date(reader.readDateTime()));
                break;

            case Notification.NOTIFICATION_REQUESTER_IP:
                notificationDocument.setNotificationRequesterIP(reader.readString());
                break;

            case Notification.NOTIFICATION_REQUESTER_NAME:
                notificationDocument.setNotificationRequesterName(reader.readString());
                break;

            case Notification.NOTIFICATION_SESSION_ID:
                notificationDocument.setSessionId(reader.readString());
                break;

            case Notification.DEVICE_DETAILS:
                final Codec<DfpParameters> deviceDeatilsCodec = codecRegistry.get(DfpParameters.class);
                notificationDocument.setDeviceDetails(deviceDeatilsCodec.decode(reader, decodeContext));
                break;

            case Notification.JWT:
                notificationDocument.setJwt(reader.readString());
                break;

            case Notification.TOKEN:
                notificationDocument.setToken(reader.readString());
                break;

            case Notification.DEVICE_TO_BE_ACTIVATED:
                notificationDocument.setDeviceToBeActivated(reader.readString());

            case Notification.PRIMARY_GROUP_NAME_STR:
                notificationDocument.setPrimaryGroup(reader.readString());
                break;

            case Notification.SECONDARY_GROUP_NAMES_STR:
                final Codec<String> secondaryGroupsCodec = codecRegistry.get(String.class);
                reader.readStartArray();
                while (reader.readBsonType() != BsonType.END_OF_DOCUMENT) {
                    secondaryGroups.add(secondaryGroupsCodec.decode(reader, decodeContext));
                }
                reader.readEndArray();
                notificationDocument.setSecondaryGroupNames(secondaryGroups);
                break;

            case Notification.CLIENT_IP_ADDRESS:
                notificationDocument.setClientIpAddress(reader.readString());
                break;

            default:
                break;
            }
        }
        reader.readEndDocument();

        return notificationDocument;
    }

}
