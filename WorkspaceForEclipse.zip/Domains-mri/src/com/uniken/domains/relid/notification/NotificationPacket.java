package com.uniken.domains.relid.notification;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.google.gson.annotations.SerializedName;

public class NotificationPacket {

    private static final String NOTIFICATION_UUID = "notification_uuid";
    private static final String CREATE_TS = "create_ts";
    private static final String EXPIRY_TIMESTAMP = "expiry_timestamp";
    private static final String BODY = "body";
    private static final String ACTIONS = "actions";
    private static final String ACTION_PERFORMED = "action_performed";
    private static final String DS_REQUIRED = "ds_required";

    @SerializedName(NOTIFICATION_UUID)
    private String notificationUuid;

    @SerializedName(CREATE_TS)
    private Date createTimestamp;

    @SerializedName(EXPIRY_TIMESTAMP)
    private Date expiryTimestamp;

    @SerializedName(BODY)
    private List<Message> body;

    @SerializedName(ACTIONS)
    private List<Action> actions;

    @SerializedName(ACTION_PERFORMED)
    private String actionPerformed;

    @SerializedName(DS_REQUIRED)
    private boolean dsRequired;

    /**
     * @return the notificationUuid
     */
    public String getNotificationUuid() {
        return notificationUuid;
    }

    /**
     * @param notificationUuid
     *            the notificationUuid to set
     */
    public void setNotificationUuid(final String notificationUuid) {
        this.notificationUuid = notificationUuid;
    }

    public Date getCreateTimestamp() {
        return createTimestamp;
    }

    public void setCreateTimestamp(final Date createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    /**
     * @return the expiryTimestamp
     */
    public Date getExpiryTimestamp() {
        return expiryTimestamp;
    }

    /**
     * @param expiryTimestamp
     *            the expiryTimestamp to set
     */
    public void setExpiryTimestamp(final Date expiryTimestamp) {
        this.expiryTimestamp = expiryTimestamp;
    }

    /**
     * @return the body
     */
    public List<Message> getBody() {
        return body;
    }

    /**
     * @param body
     *            the body to set
     */
    public void setBody(final List<Message> body) {
        this.body = body;
    }

    /**
     * @return the actions
     */
    public List<Action> getActions() {
        return actions;
    }

    /**
     * @param actions
     *            the actions to set
     */
    public void setActions(final List<Action> actions) {
        this.actions = actions;
    }

    public String getActionPerformed() {
        return actionPerformed;
    }

    public void setActionPerformed(final String actionPerformed) {
        this.actionPerformed = actionPerformed;
    }

    public boolean isDsRequired() {
        return dsRequired;
    }

    public void setDsRequired(final boolean dsRequired) {
        this.dsRequired = dsRequired;
    }

    public static List<NotificationPacket> getInstance(final List<Notification> notifications) {

        final List<NotificationPacket> notificationPackets = new ArrayList<>();

        for (final Notification n : notifications) {
            final NotificationPacket packet = new NotificationPacket();
            packet.setDsRequired(n.isDsRequired());
            // Set ActionPerformed with an empty field if the ActionPerformed
            // field in
            // received notification is null
            if (null != n.getActionPerformed()) {
                packet.setActionPerformed(n.getActionPerformed());
            } else {
                packet.setActionPerformed("");
            }
            packet.setActions(n.getActions());
            packet.setCreateTimestamp(n.getCreateTimestamp());
            packet.setExpiryTimestamp(n.getExpiryTimestamp());
            packet.setBody(n.getMsg());
            packet.setNotificationUuid(n.getNotificationUuid());
            notificationPackets.add(packet);
        }

        return notificationPackets;

    }

}
