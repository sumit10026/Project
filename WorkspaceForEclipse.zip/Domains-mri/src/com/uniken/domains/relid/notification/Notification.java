package com.uniken.domains.relid.notification;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.concurrent.Delayed;
import java.util.concurrent.TimeUnit;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.enums.NotificationStatus;
import com.uniken.domains.relid.device.DfpParameters;

public class Notification
        implements
        Delayed {

    public final static String ID = "_id";
    public final static String NOTIFICATION_UUID = "notification_uuid";
    public final static String USER_ID = "user_id";
    public final static String USER_UUID = "user_uuid";
    public final static String MESSAGE = "msg";
    public final static String MESSAGE_LNG = "lng";
    public final static String MESSAGE_SUBJECT = "subject";
    public final static String MESSAGE_MESSAGE = "message";
    public final static String MESSAGE_LABEL = "label";
    public final static String NOTIFICATION_MESSAGE = "notification_message";
    public final static String EXPIRY_TIMESTAMP = "expiry_timestamp";
    public final static String ACTIONS = "actions";
    public final static String ACTION_LABEL = "label";
    public final static String ACTION_KEY = "action";
    public final static String ACTION_AUTHLEVEL = "authlevel";
    public final static String ACTION_AUTHENTICATOR = "authenticator";
    public final static String UPDATE_TS = "update_ts";
    public final static String CREATE_TS = "create_ts";
    public final static String STATUS = "status";
    public final static String DELIVERY_STATUS = "delivery_status";
    public final static String ACTION_PERFORMED = "action_performed";
    public final static String ACTION_DEVICE_UUID = "action_device_uuid";
    public final static String ACTION_DEVICE_NAME = "action_device_name";
    public final static String ENTERPRISE_ID = "enterprise_id";
    public final static String APP_UUID = "app_uuid";
    public final static String APP_ID = "app_id";
    public final static String EXPIRES_IN = "expires_in";
    public final static String DEVTOKEN_STATUS = "devtoken_status";
    public final static String DEVTOKEN = "devtoken";
    public final static String DEVALIAS = "devname";
    public final static String DEVTYPE = "devtype";
    public final static String DEVTOKEN_RESPONSE_CODE = "response_code";
    public final static String REQUEST_ACCEPT_TS = "request_accept_ts";
    public final static String DEVICE_UUID = "devuuid";
    public final static String CALLBACK_URL = "callback_url";
    public final static String CALLBACK_RESPONSE = "callback_response";
    public final static String CALLBACK_ATTEMPTS = "callback_attempts";
    public final static String CALLBACK_ATTEMPT_UPDATE_TS = "callback_attempt_update_ts";
    public final static String DS_REQUIRED = "ds_required";
    public final static String PNS_MESSAGE_ID = "pnsmessageid";
    public final static String PNS_TIMESTAMP = "pnstimestamp";
    public static final String MOBILE_NUMBER_STR = "mobile_number";
    public static final String MSG_TYPE_STR = "msg_type";
    public static final String MODE_PREF_STR = "mode_pref";
    public static final String VERIFICATION_MODE_STR = "verification_mode";
    public static final String ORIGINAL_VERIFICATION_MODE_STR = "original_verification_mode";
    public static final String SMS_MSG_STR = "sms_msg";
    public static final String CALL_MSG_STR = "call_msg";
    public static final String SMS_MSG_IDS_STR = "sms_msg_ids";
    public static final String SMS_MSG_STATUS_STR = "sms_msg_status";
    public static final String OTP_VALUE_STR = "otp_value";
    public static final String HASH_SPEC_STR = "hash_spec";
    public static final String VALIDATE_OTP_ATTEMPTS = "validate_otp_attempts";
    public static final String VALIDATE_OTP_STATUS = "validate_otp_status";
    public static final String CERTIFICATE_STR = "certificate";
    public static final String PLAIN_DATA_STR = "plain_data";
    public static final String SIGNATURE_STR = "signature";
    public static final String IS_DS_VERIFIED = "is_ds_verified";
    public final static String USER_STATUS = "user_status";
    public final static String MSG_ID = "msg_id";
    public final static String ARCHIVED_TS = "archived_ts";
    public final static String NOTIFICATION_REQUESTER_NAME = "notification_requester_name";
    public final static String NOTIFICATION_REQUESTER_IP = "notification_requester_ip";

    public final static String NOTIFICATION_CONTROLS = "controls";
    public final static String NOTIFICATION_CONTROLS_PUSH_RETRY = "push_retry";
    public final static String NOTIFICATION_CONTROLS_PUSH_RETRY_TYPE = "type";
    public final static String NOTIFICATION_CONTROLS_PUSH_RETRY_INTERVAL = "interval";
    public final static String NOTIFICATION_CONTROLS_PUSH_RETRY_NUMBER = "number";
    public final static String NOTIFICATION_CONTROLS_PUSH_FALLBACK = "push_fallback";
    public final static String NOTIFICATION_CONTROLS_PUSH_FALLBACK_DURATION = "duration";
    public final static String NOTIFICATION_CONTROLS_PUSH_FALLBACK_DATETIME = "datetime";
    public final static String NOTIFICATION_CONTROLS_PUSH_FALLBACK_FALLBACK_TYPE = "fallback_type";
    public final static String NOTIFICATION_CONTROLS_OTP = "otp";
    public final static String NOTIFICATION_CONTROLS_OTP_ATTEMPTS = "attempts";
    public final static String NOTIFICATION_CONTROLS_OTP_HASH_SPEC = "hash_spec";
    public final static String NOTIFICATION_CONTROLS_ACTION_WORKFLOWS = "action_workflows";
    public final static String NOTIFICATION_CONTROLS_ACTION_WORKFLOWS_PARAMS = "workflows_params";
    public final static String NOTIFICATION_CONTROLS_ACTION_WORKFLOWS_WORKFLOWS = "workflows";
    public final static String NOTIFICATION_CONTROLS_ACTION_WORKFLOWS_PARAMS_JWT_EXPIRES_IN = "jwt_expires_in";
    public final static String NOTIFICATION_SESSION_ID = "session_id";
    public final static String DEVICE_DETAILS = "device_details";
    public final static String JWT = "jwt";
    public final static String TOKEN = "token";
    public final static String DEVICE_TO_BE_ACTIVATED = "device_to_be_activated";
    public final static String EXPIRY_TIMESTAMP_STR = "expiry_timestamp_str";
    public final static String UPDATE_TS_STR = "update_ts_str";
    public final static String CREATE_TS_STR = "create_ts_str";
    public final static String REQUEST_ACCEPT_TS_STR = "request_accept_ts_str";
    public final static String ARCHIVED_TS_STR = "archived_ts_str";
    public final static String CALLBACK_ATTEMPT_UPDATE_TS_STR = "callback_attempt_update_ts_str";
    public static final String PRIMARY_GROUP_NAME_STR = "primary_group_name";
    public static final String SECONDARY_GROUP_NAMES_STR = "secondary_group_names";

    public final static String CLIENT_IP_ADDRESS = "client_ip_address";

    @SerializedName(ID)
    private ObjectId id;

    @SerializedName(USER_ID)
    @Field(USER_ID)
    private String userId;

    @SerializedName(USER_UUID)
    @Field(USER_UUID)
    private String userUuid;

    @SerializedName(NOTIFICATION_UUID)
    @Field(NOTIFICATION_UUID)
    private String notificationUuid;

    @SerializedName(EXPIRY_TIMESTAMP)
    @Field(EXPIRY_TIMESTAMP)
    private Date expiryTimestamp;

    @SerializedName(CREATE_TS)
    @Field(CREATE_TS)
    private Date createTimestamp;

    @SerializedName(REQUEST_ACCEPT_TS)
    @Field(REQUEST_ACCEPT_TS)
    private Date requestAcceptTimestamp;

    @SerializedName(UPDATE_TS)
    @Field(UPDATE_TS)
    private Date updateTimestamp;

    @SerializedName(MESSAGE)
    @Field(MESSAGE)
    private List<Message> msg;

    @SerializedName(NOTIFICATION_MESSAGE)
    @Field(NOTIFICATION_MESSAGE)
    private Message notificationMessage;

    @SerializedName(ACTIONS)
    @Field(ACTIONS)
    private List<Action> actions;

    @SerializedName(ACTION_PERFORMED)
    @Field(ACTION_PERFORMED)
    private String actionPerformed;

    @SerializedName(ACTION_DEVICE_UUID)
    @Field(ACTION_DEVICE_UUID)
    private String actionDeviceUuid;

    @SerializedName(ACTION_DEVICE_NAME)
    @Field(ACTION_DEVICE_NAME)
    private String actionDeviceName;

    @SerializedName(STATUS)
    @Field(STATUS)
    private NotificationStatus status;

    @SerializedName(DELIVERY_STATUS)
    @Field(DELIVERY_STATUS)
    private NotificationStatus deliveryStatus;

    @SerializedName(ENTERPRISE_ID)
    @Field(ENTERPRISE_ID)
    private String enterpriseId;

    @SerializedName(APP_UUID)
    @Field(APP_UUID)
    private String appUuid;

    @SerializedName(APP_ID)
    @Field(APP_ID)
    private String appId;

    @SerializedName(EXPIRES_IN)
    @Field(EXPIRES_IN)
    private Integer expiresIn;

    @SerializedName(DEVTOKEN_STATUS)
    @Field(DEVTOKEN_STATUS)
    private List<PushNotificationDevTokenStatus> devTokenStatusList;

    @SerializedName(CALLBACK_URL)
    @Field(CALLBACK_URL)
    private String callbackUrl;

    @SerializedName(CALLBACK_RESPONSE)
    @Field(CALLBACK_RESPONSE)
    private String callbackResponse;

    @SerializedName(CALLBACK_ATTEMPTS)
    @Field(CALLBACK_ATTEMPTS)
    private int callbackAttempts;

    @SerializedName(CALLBACK_ATTEMPT_UPDATE_TS)
    @Field(CALLBACK_ATTEMPT_UPDATE_TS)
    private Date callbackAttemptUpdateTs;

    @SerializedName(DS_REQUIRED)
    @Field(DS_REQUIRED)
    private boolean dsRequired;

    @SerializedName(MOBILE_NUMBER_STR)
    @Field(MOBILE_NUMBER_STR)
    private String mobileNumber;

    @SerializedName(MSG_TYPE_STR)
    @Field(MSG_TYPE_STR)
    private String msgType;

    @SerializedName(MODE_PREF_STR)
    @Field(MODE_PREF_STR)
    private String modePref;

    @SerializedName(VERIFICATION_MODE_STR)
    @Field(VERIFICATION_MODE_STR)
    private String verificationMode;

    @SerializedName(ORIGINAL_VERIFICATION_MODE_STR)
    @Field(ORIGINAL_VERIFICATION_MODE_STR)
    private String originalVerificationMode;

    @SerializedName(SMS_MSG_STR)
    @Field(SMS_MSG_STR)
    private String smsMsg;

    @SerializedName(CALL_MSG_STR)
    @Field(CALL_MSG_STR)
    private String callMsg;

    @SerializedName(SMS_MSG_IDS_STR)
    @Field(SMS_MSG_IDS_STR)
    private List<String> smsMsgIds;

    @SerializedName(SMS_MSG_STATUS_STR)
    @Field(SMS_MSG_STATUS_STR)
    private String smsMsgStatus;

    @SerializedName(OTP_VALUE_STR)
    @Field(OTP_VALUE_STR)
    private String otpValue;

    @SerializedName(HASH_SPEC_STR)
    @Field(HASH_SPEC_STR)
    private String hashSpec;

    @SerializedName(VALIDATE_OTP_ATTEMPTS)
    @Field(VALIDATE_OTP_ATTEMPTS)
    private Integer validateOtpAttempts;

    @SerializedName(VALIDATE_OTP_STATUS)
    @Field(VALIDATE_OTP_STATUS)
    private String validateOtpStatus;

    @SerializedName(CERTIFICATE_STR)
    @Field(CERTIFICATE_STR)
    private String certificate;

    @SerializedName(PLAIN_DATA_STR)
    @Field(PLAIN_DATA_STR)
    private String plainData;

    @SerializedName(SIGNATURE_STR)
    @Field(SIGNATURE_STR)
    private String signature;

    @SerializedName(IS_DS_VERIFIED)
    @Field(IS_DS_VERIFIED)
    private boolean dsVerified;

    @SerializedName(USER_STATUS)
    @Field(USER_STATUS)
    private String userStatus;

    @SerializedName(MSG_ID)
    @Field(MSG_ID)
    private String msgId;

    @SerializedName(ARCHIVED_TS)
    @Field(ARCHIVED_TS)
    private Date archivedTs;

    @SerializedName(NOTIFICATION_REQUESTER_IP)
    @Field(NOTIFICATION_REQUESTER_IP)
    private String notificationRequesterIP;

    @SerializedName(NOTIFICATION_REQUESTER_NAME)
    @Field(NOTIFICATION_REQUESTER_NAME)
    private String notificationRequesterName;

    @SerializedName(NOTIFICATION_CONTROLS)
    @Field(NOTIFICATION_CONTROLS)
    private NotificationControls controls;

    @SerializedName(NOTIFICATION_SESSION_ID)
    @Field(NOTIFICATION_SESSION_ID)
    private String sessionId;

    @SerializedName(DEVICE_DETAILS)
    @Field(DEVICE_DETAILS)
    private DfpParameters deviceDetails;

    @SerializedName(JWT)
    @Field(JWT)
    private String jwt;

    @SerializedName(TOKEN)
    @Field(TOKEN)
    private String token;

    @SerializedName(DEVICE_TO_BE_ACTIVATED)
    @Field(DEVICE_TO_BE_ACTIVATED)
    private String deviceToBeActivated;

    @SerializedName(EXPIRY_TIMESTAMP_STR)
    @Field(EXPIRY_TIMESTAMP_STR)
    private String expiryTimestampStr;

    @SerializedName(CREATE_TS_STR)
    @Field(CREATE_TS_STR)
    private String createTimestampStr;

    @SerializedName(REQUEST_ACCEPT_TS_STR)
    @Field(REQUEST_ACCEPT_TS_STR)
    private String requestAcceptTimestampStr;

    @SerializedName(UPDATE_TS_STR)
    @Field(UPDATE_TS_STR)
    private String updateTimestampStr;

    @SerializedName(ARCHIVED_TS_STR)
    @Field(ARCHIVED_TS_STR)
    private String archivedTsStr;

    @SerializedName(CALLBACK_ATTEMPT_UPDATE_TS_STR)
    @Field(CALLBACK_ATTEMPT_UPDATE_TS_STR)
    private String callbackAttemptUpdateTsStr;

    @SerializedName(PRIMARY_GROUP_NAME_STR)
    @Field(PRIMARY_GROUP_NAME_STR)
    private String primaryGroup;

    @SerializedName(SECONDARY_GROUP_NAMES_STR)
    @Field(SECONDARY_GROUP_NAMES_STR)
    private List<String> secondaryGroupNames;

    @SerializedName(CLIENT_IP_ADDRESS)
    @Field(CLIENT_IP_ADDRESS)
    private String clientIpAddress;

    /**
     * @return the id
     */
    public ObjectId getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final ObjectId id) {
        this.id = id;
    }

    /**
     * @return the notificationUuid
     */
    public String getNotificationUuid() {
        return notificationUuid;
    }

    /**
     * @param notificationUuid
     *            the notificationUuid to set
     */
    public void setNotificationUuid(final String notificationUuid) {
        this.notificationUuid = notificationUuid;
    }

    /**
     * @return the msg
     */
    public List<Message> getMsg() {
        return msg;
    }

    /**
     * @param msg
     *            the msg to set
     */
    public void setMsg(final List<Message> msg) {
        this.msg = msg;
    }

    /**
     * @return the actions
     */
    public List<Action> getActions() {
        return actions;
    }

    /**
     * @param actions
     *            the actions to set
     */
    public void setActions(final List<Action> actions) {
        this.actions = actions;
    }

    /**
     * @return the actionPerformed
     */
    public String getActionPerformed() {
        return actionPerformed;
    }

    /**
     * @param actionPerformed
     *            the actionPerformed to set
     */
    public void setActionPerformed(final String actionPerformed) {
        this.actionPerformed = actionPerformed;
    }

    /**
     * @return the expiryTimestamp
     */
    public Date getExpiryTimestamp() {
        return expiryTimestamp;
    }

    /**
     * @param expiryTimestamp
     *            the expiryTimestamp to set
     */
    public void setExpiryTimestamp(final Date expiryTimestamp) {
        this.expiryTimestamp = expiryTimestamp;
    }

    /**
     * @return the notificationMessage
     */
    public Message getNotificationMessage() {
        return notificationMessage;
    }

    /**
     * @param notificationMessage
     *            the notificationMessage to set
     */
    public void setNotificationMessage(final Message notificationMessage) {
        this.notificationMessage = notificationMessage;
    }

    /**
     * @return the createTimestamp
     */
    public Date getCreateTimestamp() {
        return createTimestamp;
    }

    /**
     * @param createTimestamp
     *            the createTimestamp to set
     */
    public void setCreateTimestamp(final Date createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    /**
     * @return the updateTimestamp
     */
    public Date getUpdateTimestamp() {
        return updateTimestamp;
    }

    /**
     * @return the requestAcceptTimestamp
     */
    public Date getRequestAcceptTimestamp() {
        return requestAcceptTimestamp;
    }

    /**
     * @param requestAcceptTimestamp
     *            the requestAcceptTimestamp to set
     */
    public void setRequestAcceptTimestamp(final Date requestAcceptTimestamp) {
        this.requestAcceptTimestamp = requestAcceptTimestamp;
    }

    /**
     * @param updateTimestamp
     *            the updateTimestamp to set
     */
    public void setUpdateTimestamp(final Date updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

    /**
     * @return the actionDeviceName
     */
    public String getActionDeviceName() {
        return actionDeviceName;
    }

    /**
     * @param actionDeviceName
     *            the actionDeviceName to set
     */
    public void setActionDeviceName(final String actionDeviceName) {
        this.actionDeviceName = actionDeviceName;
    }

    /**
     * @return the actionDeviceUuid
     */
    public String getActionDeviceUuid() {
        return actionDeviceUuid;
    }

    /**
     * @param actionDeviceUuid
     *            the actionDeviceUuid to set
     */
    public void setActionDeviceUuid(final String actionDeviceUuid) {
        this.actionDeviceUuid = actionDeviceUuid;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @return the userUuid
     */
    public String getUserUuid() {
        return userUuid;
    }

    /**
     * @param userUuid
     *            the userUuid to set
     */
    public void setUserUuid(final String userUuid) {
        this.userUuid = userUuid;
    }

    /**
     * @return the status
     */
    public NotificationStatus getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(final NotificationStatus status) {
        this.status = status;
    }

    /**
     * @return the enterpriseId
     */
    public String getEnterpriseId() {
        return enterpriseId;
    }

    /**
     * @param enterpriseId
     *            the enterpriseId to set
     */
    public void setEnterpriseId(final String enterpriseId) {
        this.enterpriseId = enterpriseId;
    }

    /**
     * @return the appUuid
     */
    public String getAppUuid() {
        return appUuid;
    }

    /**
     * @param appUuid
     *            the appUuid to set
     */
    public void setAppUuid(final String appUuid) {
        this.appUuid = appUuid;
    }

    /**
     * @return the appId
     */
    public String getAppId() {
        return appId;
    }

    /**
     * @param appId
     *            the appId to set
     */
    public void setAppId(final String appId) {
        this.appId = appId;
    }

    /**
     * @return the expiresIn
     */
    public Integer getExpiresIn() {
        return expiresIn;
    }

    /**
     * @param expiresIn
     *            the expiresIn to set
     */
    public void setExpiresIn(final Integer expiresIn) {
        this.expiresIn = expiresIn;
    }

    /**
     * @return the devTokenStatusList
     */
    public List<PushNotificationDevTokenStatus> getDevTokenStatusList() {
        return devTokenStatusList;
    }

    /**
     * @param devTokenStatusList
     *            the devTokenStatusList to set
     */
    public void setDevTokenStatusList(final List<PushNotificationDevTokenStatus> devTokenStatusList) {
        this.devTokenStatusList = devTokenStatusList;
    }

    /**
     * @return the deliveryStatus
     */
    public NotificationStatus getDeliveryStatus() {
        return deliveryStatus;
    }

    /**
     * @param deliveryStatus
     *            the deliveryStatus to set
     */
    public void setDeliveryStatus(final NotificationStatus deliveryStatus) {
        this.deliveryStatus = deliveryStatus;
    }

    /**
     * @return the callbackUrl
     */
    public String getCallbackUrl() {
        return callbackUrl;
    }

    /**
     * @param callbackUrl
     *            the callbackUrl to set
     */
    public void setCallbackUrl(final String callbackUrl) {
        this.callbackUrl = callbackUrl;
    }

    /**
     * @return the callbackResponse
     */
    public String getCallbackResponse() {
        return callbackResponse;
    }

    /**
     * @param callbackResponse
     *            the callbackResponse to set
     */
    public void setCallbackResponse(final String callbackResponse) {
        this.callbackResponse = callbackResponse;
    }

    /**
     * @return the callbackAttempts
     */
    public int getCallbackAttempts() {
        return callbackAttempts;
    }

    /**
     * @param callbackAttempts
     *            the callbackAttempts to set
     */
    public void setCallbackAttempts(final int callbackAttempts) {
        this.callbackAttempts = callbackAttempts;
    }

    /**
     * @return the callbackAttemptUpdateTs
     */
    public Date getCallbackAttemptUpdateTs() {
        return callbackAttemptUpdateTs;
    }

    /**
     * @param callbackAttemptUpdateTs
     *            the callbackAttemptUpdateTs to set
     */
    public void setCallbackAttemptUpdateTs(final Date callbackAttemptUpdateTs) {
        this.callbackAttemptUpdateTs = callbackAttemptUpdateTs;
    }

    public boolean isDsRequired() {
        return dsRequired;
    }

    public void setDsRequired(final boolean dsRequired) {
        this.dsRequired = dsRequired;
    }

    /**
     * @return the mobileNumber
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * @param mobileNumber
     *            the mobileNumber to set
     */
    public void setMobileNumber(final String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    /**
     * @return the msgType
     */
    public String getMsgType() {
        return msgType;
    }

    /**
     * @param msgType
     *            the msgType to set
     */
    public void setMsgType(final String msgType) {
        this.msgType = msgType;
    }

    /**
     * @return the modePref
     */
    public String getModePref() {
        return modePref;
    }

    /**
     * @param modePref
     *            the modePref to set
     */
    public void setModePref(final String modePref) {
        this.modePref = modePref;
    }

    /**
     * @return the verificationMode
     */
    public String getVerificationMode() {
        return verificationMode;
    }

    /**
     * @param verificationMode
     *            the verificationMode to set
     */
    public void setVerificationMode(final String verificationMode) {
        this.verificationMode = verificationMode;
    }

    /**
     * @return the originalVerificationMode
     */
    public String getOriginalVerificationMode() {
        return originalVerificationMode;
    }

    /**
     * @param originalVerificationMode
     *            the originalVerificationMode to set
     */
    public void setOriginalVerificationMode(final String originalVerificationMode) {
        this.originalVerificationMode = originalVerificationMode;
    }

    /**
     * @return the smsMsg
     */
    public String getSmsMsg() {
        return smsMsg;
    }

    /**
     * @param smsMsg
     *            the smsMsg to set
     */
    public void setSmsMsg(final String smsMsg) {
        this.smsMsg = smsMsg;
    }

    /**
     * @return the callMsg
     */
    public String getCallMsg() {
        return callMsg;
    }

    /**
     * @param callMsg
     *            the callMsg to set
     */
    public void setCallMsg(final String callMsg) {
        this.callMsg = callMsg;
    }

    /**
     * @return the smsMsgIds
     */
    public List<String> getSmsMsgIds() {
        return smsMsgIds;
    }

    /**
     * @param smsMsgIds
     *            the smsMsgIds to set
     */
    public void setSmsMsgIds(final List<String> smsMsgIds) {
        this.smsMsgIds = smsMsgIds;
    }

    /**
     * @return the smsMsgStatus
     */
    public String getSmsMsgStatus() {
        return smsMsgStatus;
    }

    /**
     * @param smsMsgStatus
     *            the smsMsgStatus to set
     */
    public void setSmsMsgStatus(final String smsMsgStatus) {
        this.smsMsgStatus = smsMsgStatus;
    }

    /**
     * @return the otpValue
     */
    public String getOtpValue() {
        return otpValue;
    }

    /**
     * @param otpValue
     *            the otpValue to set
     */
    public void setOtpValue(final String otpValue) {
        this.otpValue = otpValue;
    }

    /**
     * @return the hashSpec
     */
    public String getHashSpec() {
        return hashSpec;
    }

    /**
     * @param hashSpec
     *            the hashSpec to set
     */
    public void setHashSpec(final String hashSpec) {
        this.hashSpec = hashSpec;
    }

    /**
     * @return the validateOtpAttempts
     */
    public Integer getValidateOtpAttempts() {
        return validateOtpAttempts;
    }

    /**
     * @param validateOtpAttempts
     *            the validateOtpAttempts to set
     */
    public void setValidateOtpAttempts(final Integer validateOtpAttempts) {
        this.validateOtpAttempts = validateOtpAttempts;
    }

    /**
     * @return the validateOtpStatus
     */
    public String getValidateOtpStatus() {
        return validateOtpStatus;
    }

    /**
     * @param validateOtpStatus
     *            the validateOtpStatus to set
     */
    public void setValidateOtpStatus(final String validateOtpStatus) {
        this.validateOtpStatus = validateOtpStatus;
    }

    /**
     * @return the certificate
     */
    public String getCertificate() {
        return certificate;
    }

    /**
     * @param certificate
     *            the certificate to set
     */
    public void setCertificate(final String certificate) {
        this.certificate = certificate;
    }

    /**
     * @return the plainData
     */
    public String getPlainData() {
        return plainData;
    }

    /**
     * @param plainData
     *            the plainSignData to set
     */
    public void setPlainData(final String plainData) {
        this.plainData = plainData;
    }

    /**
     * @return the signature
     */
    public String getSignature() {
        return signature;
    }

    /**
     * @param signature
     *            the signature to set
     */
    public void setSignature(final String signature) {
        this.signature = signature;
    }

    /**
     * @return the isDsVerified
     */
    public boolean isDsVerified() {
        return dsVerified;
    }

    /**
     * @param dsVerified
     *            the dsVerified to set
     */
    public void setDsVerified(final boolean dsVerified) {
        this.dsVerified = dsVerified;
    }

    /**
     * @return the userStatus
     */
    public String getUserStatus() {
        return userStatus;
    }

    /**
     * @param userStatus
     *            the userStatus to set
     */
    public void setUserStatus(final String userStatus) {
        this.userStatus = userStatus;
    }

    /**
     * @return the msgId
     */
    public String getMsgId() {
        return msgId;
    }

    /**
     * @param msgId
     *            the msgId to set
     */
    public void setMsgId(final String msgId) {
        this.msgId = msgId;
    }

    /**
     * @return the archivedTs
     */
    public Date getArchivedTs() {
        return archivedTs;
    }

    /**
     * @param archivedTs
     *            the archivedTs to set
     */
    public void setArchivedTs(final Date archivedTs) {
        this.archivedTs = archivedTs;
    }

    /**
     * @return the notificationRequesterIP
     */
    public String getNotificationRequesterIP() {
        return notificationRequesterIP;
    }

    /**
     * @param notificationRequesterIP
     *            the notificationRequesterIP to set
     */
    public void setNotificationRequesterIP(final String notificationRequesterIP) {
        this.notificationRequesterIP = notificationRequesterIP;
    }

    /**
     * @return the notificationRequesterName
     */
    public String getNotificationRequesterName() {
        return notificationRequesterName;
    }

    /**
     * @param notificationRequesterName
     *            the notificationRequesterName to set
     */
    public void setNotificationRequesterName(final String notificationRequesterName) {
        this.notificationRequesterName = notificationRequesterName;
    }

    /**
     * @return the controls
     */
    public NotificationControls getControls() {
        return controls;
    }

    /**
     * @param controls
     *            the controls to set
     */
    public void setControls(final NotificationControls controls) {
        this.controls = controls;
    }

    /**
     * @return the sessionId
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * @param sessionId
     *            the sessionId to set
     */
    public void setSessionId(final String sessionId) {
        this.sessionId = sessionId;
    }

    @Override
    public int compareTo(final Delayed o) {
        if (this.expiryTimestamp != null) {
            if (this.expiryTimestamp.before(((Notification) o).expiryTimestamp)) {
                return -1;
            }
            if (this.expiryTimestamp.after(((Notification) o).expiryTimestamp)) {
                return 1;
            }
        }
        return 0;
    }

    @Override
    public long getDelay(final TimeUnit unit) {
        final long diff = expiryTimestamp.getTime() - System.currentTimeMillis();
        return unit.convert(diff, TimeUnit.MILLISECONDS);
    }

    /**
     * @return the jwt
     */
    public String getJwt() {
        return jwt;
    }

    /**
     * @param jwt
     *            the jwt to set
     */
    public void setJwt(final String jwt) {
        this.jwt = jwt;
    }

    /**
     * @return the token
     */
    public String getToken() {
        return token;
    }

    /**
     * @param token
     *            the token to set
     */
    public void setToken(final String token) {
        this.token = token;
    }

    /**
     * @return the deviceToBeActivated
     */
    public String getDeviceToBeActivated() {
        return deviceToBeActivated;
    }

    /**
     * @param deviceToBeActivated
     *            the deviceToBeActivated to set
     */
    public void setDeviceToBeActivated(final String deviceToBeActivated) {
        this.deviceToBeActivated = deviceToBeActivated;
    }

    public String getExpiryTimestampStr() {
        return expiryTimestampStr;
    }

    public void setExpiryTimestampStr(final String expiryTimestampStr) {
        this.expiryTimestampStr = expiryTimestampStr;
    }

    public String getCreateTimestampStr() {
        return createTimestampStr;
    }

    public void setCreateTimestampStr(final String createTimestampStr) {
        this.createTimestampStr = createTimestampStr;
    }

    public String getUpdateTimestampStr() {
        return updateTimestampStr;
    }

    public void setUpdateTimestampStr(final String updateTimestampStr) {
        this.updateTimestampStr = updateTimestampStr;
    }

    public String getRequestAcceptTimestampStr() {
        return requestAcceptTimestampStr;
    }

    public void setRequestAcceptTimestampStr(final String requestAcceptTimestampStr) {
        this.requestAcceptTimestampStr = requestAcceptTimestampStr;
    }

    public String getArchivedTsStr() {
        return archivedTsStr;
    }

    public void setArchivedTsStr(final String archivedTsStr) {
        this.archivedTsStr = archivedTsStr;
    }

    /**
     * @return the deviceDetails
     */
    public DfpParameters getDeviceDetails() {
        return deviceDetails;
    }

    /**
     * @param deviceDetails
     *            the deviceDetails to set
     */
    public void setDeviceDetails(final DfpParameters deviceDetails) {
        this.deviceDetails = deviceDetails;
    }

    public String getCallbackAttemptUpdateTsStr() {
        return callbackAttemptUpdateTsStr;
    }

    public void setCallbackAttemptUpdateTsStr(final String callbackAttemptUpdateTsStr) {
        this.callbackAttemptUpdateTsStr = callbackAttemptUpdateTsStr;
    }

    public String getPrimaryGroup() {
        return primaryGroup;
    }

    public void setPrimaryGroup(final String primaryGroup) {
        this.primaryGroup = primaryGroup;
    }

    public List<String> getSecondaryGroupNames() {
        return secondaryGroupNames;
    }

    public void setSecondaryGroupNames(final List<String> secondaryGroupNames) {
        this.secondaryGroupNames = secondaryGroupNames;
    }

    public String getClientIpAddress() {
        return clientIpAddress;
    }

    public void setClientIpAddress(final String clientIpAddress) {
        this.clientIpAddress = clientIpAddress;
    }

    public void parseDateToString(final String dateFormat) {
        final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        if (null != this.expiryTimestamp)
            this.expiryTimestampStr = sdf.format(this.expiryTimestamp);
        if (null != this.createTimestamp)
            this.createTimestampStr = sdf.format(this.createTimestamp);
        if (null != this.updateTimestamp)
            this.updateTimestampStr = sdf.format(this.updateTimestamp);
        if (null != this.requestAcceptTimestamp)
            this.requestAcceptTimestampStr = sdf.format(this.requestAcceptTimestamp);
        if (null != this.archivedTs)
            this.archivedTsStr = sdf.format(archivedTs);
        if (null != this.callbackAttemptUpdateTs)
            this.callbackAttemptUpdateTsStr = sdf.format(this.callbackAttemptUpdateTs);

    }

    // /*
    // * (non-Javadoc)
    // * @see java.lang.Object#hashCode()
    // */
    // @Override
    // public int hashCode() {
    // final int prime = 31;
    // int result = 1;
    // result = prime * result + ((expiryTimestamp == null) ? 0 :
    // expiryTimestamp.hashCode());
    // result = prime * result + ((notificationUuid == null) ? 0 :
    // notificationUuid.hashCode());
    // return result;
    // }
    //
    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (!(obj instanceof Notification)) {
            return false;
        }
        final Notification other = (Notification) obj;
        if (expiryTimestamp == null) {
            if (other.expiryTimestamp != null) {
                return false;
            }
        } else if (!expiryTimestamp.equals(other.expiryTimestamp)) {
            return false;
        }
        if (notificationUuid == null) {
            if (other.notificationUuid != null) {
                return false;
            }
        } else if (!notificationUuid.equals(other.notificationUuid)) {
            return false;
        }
        return true;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("Notification [id=");
        builder.append(id);
        builder.append(", userId=");
        builder.append(userId);
        builder.append(", userUuid=");
        builder.append(userUuid);
        builder.append(", notificationUuid=");
        builder.append(notificationUuid);
        builder.append(", expiryTimestamp=");
        builder.append(expiryTimestamp);
        builder.append(", createTimestamp=");
        builder.append(createTimestamp);
        builder.append(", requestAcceptTimestamp=");
        builder.append(requestAcceptTimestamp);
        builder.append(", updateTimestamp=");
        builder.append(updateTimestamp);
        builder.append(", msg=");
        builder.append(msg);
        builder.append(", notificationMessage=");
        builder.append(notificationMessage);
        builder.append(", actions=");
        builder.append(actions);
        builder.append(", actionPerformed=");
        builder.append(actionPerformed);
        builder.append(", actionDeviceUuid=");
        builder.append(actionDeviceUuid);
        builder.append(", actionDeviceName=");
        builder.append(actionDeviceName);
        builder.append(", status=");
        builder.append(status);
        builder.append(", deliveryStatus=");
        builder.append(deliveryStatus);
        builder.append(", enterpriseId=");
        builder.append(enterpriseId);
        builder.append(", appUuid=");
        builder.append(appUuid);
        builder.append(", appId=");
        builder.append(appId);
        builder.append(", callbackUrl=");
        builder.append(callbackUrl);
        builder.append(", callbackResponse=");
        builder.append(callbackResponse);
        builder.append(", callbackAttempts=");
        builder.append(callbackAttempts);
        builder.append(", callbackAttemptUpdateTs=");
        builder.append(callbackAttemptUpdateTs);
        builder.append(", expiresIn=");
        builder.append(expiresIn);
        builder.append(", devTokenStatusList=");
        builder.append(devTokenStatusList);
        builder.append(", dsRequired=");
        builder.append(dsRequired);
        builder.append(", mobileNumber=");
        builder.append(mobileNumber);
        builder.append(", msgType=");
        builder.append(msgType);
        builder.append(", modePref=");
        builder.append(modePref);
        builder.append(", verificationMode=");
        builder.append(verificationMode);
        builder.append(", originalVerificationMode=");
        builder.append(originalVerificationMode);
        builder.append(", smsMsg=");
        builder.append(smsMsg);
        builder.append(", callMsg=");
        builder.append(callMsg);
        builder.append(", smsMsgIds=");
        builder.append(smsMsgIds);
        builder.append(", smsMsgStatus=");
        builder.append(smsMsgStatus);
        builder.append(", otpValue=");
        builder.append(otpValue);
        builder.append(", hashSpec=");
        builder.append(hashSpec);
        builder.append(", validateOtpAttempts=");
        builder.append(validateOtpAttempts);
        builder.append(", validateOtpStatus=");
        builder.append(validateOtpStatus);
        builder.append(", certificate=");
        builder.append(certificate);
        builder.append(", plainSignData=");
        builder.append(plainData);
        builder.append(", signData=");
        builder.append(signature);
        builder.append(", isSignData=");
        builder.append(dsVerified);
        builder.append(", userStatus=");
        builder.append(userStatus);
        builder.append(", msgId=");
        builder.append(msgId);
        builder.append(", archivedTs=");
        builder.append(archivedTs);
        builder.append(", notificationRequesterIP=");
        builder.append(notificationRequesterIP);
        builder.append(", notificationRequesterName=");
        builder.append(notificationRequesterName);
        builder.append(", controls=");
        builder.append(controls);
        builder.append(", jwt=");
        builder.append(jwt);
        builder.append(", token=");
        builder.append(token);
        builder.append(", primaryGroup");
        builder.append(primaryGroup);
        builder.append(", clientIpAddress");
        builder.append(clientIpAddress);
        builder.append("]");

        return builder.toString();

    }

    public final static String DS_REQUIRED_STR = "ds_required_str";
    public static final String IS_DS_VERIFIED_STR = "is_ds_verified_str";

    @SerializedName(DS_REQUIRED_STR)
    @Field(DS_REQUIRED_STR)
    private String dsRequiredStr;

    @SerializedName(IS_DS_VERIFIED_STR)
    @Field(IS_DS_VERIFIED_STR)
    private String dsVerifiedStr;

    /**
     * @return the dsRequiredStr
     */
    public String getDsRequiredStr() {
        return dsRequiredStr;
    }

    /**
     * @param dsRequiredStr
     *            the dsRequiredStr to set
     */
    public void setDsRequiredStr(final String dsRequiredStr) {
        this.dsRequiredStr = dsRequiredStr;
    }

    /**
     * @return the dsVerifiedStr
     */
    public String getDsVerifiedStr() {
        return dsVerifiedStr;
    }

    /**
     * @param dsVerifiedStr
     *            the dsVerifiedStr to set
     */
    public void setDsVerifiedStr(final String dsVerifiedStr) {
        this.dsVerifiedStr = dsVerifiedStr;
    }

    public void parseBooleanToString() {
        if (this.status == NotificationStatus.ACTIVE || this.status == NotificationStatus.EXPIRED || !this.dsRequired) {
            this.dsVerifiedStr = "NA";
        } else {
            if (dsVerified) {
                this.dsVerifiedStr = "TRUE";
            } else {
                this.dsVerifiedStr = "FALSE";
            }
        }
    }

}
