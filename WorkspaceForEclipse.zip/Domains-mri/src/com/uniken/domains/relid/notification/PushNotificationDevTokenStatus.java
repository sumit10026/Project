package com.uniken.domains.relid.notification;

import java.util.Date;

/**
 * @author UNIKEN
 */
public class PushNotificationDevTokenStatus {

    private String devtoken;
    private Integer response_code;
    private String devname;
    private String devuuid;
    private String devtype;
    private String pnsmessageid;
    private Date pnstimestamp;

    /**
     * 
     */
    public PushNotificationDevTokenStatus() {
        super();
    }

    /**
     * Construct {@link PushNotificationDevTokenStatus} object.
     * 
     * @param devtoken
     * @param devname
     * @param devuuid
     * @param devtype
     */
    public PushNotificationDevTokenStatus(final String devtoken, final String devname, final String devuuid,
            final String devtype) {
        this.devtoken = devtoken;
        this.devname = devname;
        this.devuuid = devuuid;
        this.devtype = devtype;
    }

    /**
     * @return the devtoken
     */
    public String getDevtoken() {
        return devtoken;
    }

    /**
     * @param devtoken
     *            the devtoken to set
     */
    public void setDevtoken(final String devtoken) {
        this.devtoken = devtoken;
    }

    /**
     * @return the responseCode
     */
    public Integer getResponseCode() {
        return response_code;
    }

    /**
     * @param responseCode
     *            the responseCode to set
     */
    public void setResponseCode(final Integer responseCode) {
        this.response_code = responseCode;
    }

    /**
     * @return the devname
     */
    public String getDevname() {
        return devname;
    }

    /**
     * @param devname
     *            the devname to set
     */
    public void setDevname(final String devname) {
        this.devname = devname;
    }

    /**
     * @return the devuuid
     */
    public String getDevuuid() {
        return devuuid;
    }

    /**
     * @param devuuid
     *            the devuuid to set
     */
    public void setDevuuid(final String devuuid) {
        this.devuuid = devuuid;
    }

    /**
     * @return the devtype
     */
    public String getDevtype() {
        return devtype;
    }

    /**
     * @param devtype
     *            the devtype to set
     */
    public void setDevtype(final String devtype) {
        this.devtype = devtype;
    }

    public String getPnsmessageid() {
        return pnsmessageid;
    }

    public void setPnsmessageid(final String pnsmessageid) {
        this.pnsmessageid = pnsmessageid;
    }

    /**
     * @return the pnstimestamp
     */
    public Date getPnstimestamp() {
        return pnstimestamp;
    }

    /**
     * @param pnstimestamp
     *            the pnstimestamp to set
     */
    public void setPnstimestamp(final Date pnstimestamp) {
        this.pnstimestamp = pnstimestamp;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("PushNotificationDevTokenStatus [devtoken=");
        builder.append(devtoken);
        builder.append(", response_code=");
        builder.append(response_code);
        builder.append(", devname=");
        builder.append(devname);
        builder.append(", devuuid=");
        builder.append(devuuid);
        builder.append(", devtype=");
        builder.append(devtype);
        builder.append(", pnsmessageid=");
        builder.append(pnsmessageid);
        builder.append(", pnstimestamp=");
        builder.append(pnstimestamp);
        builder.append("]");
        return builder.toString();
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((devname == null) ? 0 : devname.hashCode());
        result = prime * result + ((devtoken == null) ? 0 : devtoken.hashCode());
        result = prime * result + ((devtype == null) ? 0 : devtype.hashCode());
        result = prime * result + ((devuuid == null) ? 0 : devuuid.hashCode());
        return result;
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (!(obj instanceof PushNotificationDevTokenStatus))
            return false;
        final PushNotificationDevTokenStatus other = (PushNotificationDevTokenStatus) obj;
        if (devname == null) {
            if (other.devname != null)
                return false;
        } else if (!devname.equals(other.devname))
            return false;
        if (devtoken == null) {
            if (other.devtoken != null)
                return false;
        } else if (!devtoken.equals(other.devtoken))
            return false;
        if (devtype == null) {
            if (other.devtype != null)
                return false;
        } else if (!devtype.equals(other.devtype))
            return false;
        if (devuuid == null) {
            if (other.devuuid != null)
                return false;
        } else if (!devuuid.equals(other.devuuid))
            return false;
        return true;
    }

}
