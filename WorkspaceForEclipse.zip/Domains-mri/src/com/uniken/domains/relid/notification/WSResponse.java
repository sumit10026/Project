/**
 * 
 */
package com.uniken.domains.relid.notification;

import com.google.gson.annotations.SerializedName;

/**
 * @author Chetan Patil
 */
public class WSResponse {

    public final static String RESPONSE_CODE = "response_code";
    public final static String ERROR_CODE = "error_code";
    public final static String ERROR_MESSAGE = "error_message";

    @SerializedName(RESPONSE_CODE)
    private Integer responseCode;

    @SerializedName(ERROR_CODE)
    private Integer errorCode;

    @SerializedName(ERROR_MESSAGE)
    private String errorMessage;

    /**
     * @return the responseCode
     */
    public Integer getResponseCode() {
        return responseCode;
    }

    /**
     * @param responseCode
     *            the responseCode to set
     */
    public void setResponseCode(final Integer responseCode) {
        this.responseCode = responseCode;
    }

    /**
     * @return the errorCode
     */
    public Integer getErrorCode() {
        return errorCode;
    }

    /**
     * @param errorCode
     *            the errorCode to set
     */
    public void setErrorCode(final Integer errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * @return the errorMessage
     */
    public String getErrorMessage() {
        return errorMessage;
    }

    /**
     * @param errorMessage
     *            the errorMessage to set
     */
    public void setErrorMessage(final String errorMessage) {
        this.errorMessage = errorMessage;
    }

}
