/**
 * 
 */
package com.uniken.domains.relid.notification.codec;

import org.bson.BsonReader;
import org.bson.BsonType;
import org.bson.BsonWriter;
import org.bson.codecs.Codec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.codecs.configuration.CodecRegistry;

import com.uniken.domains.relid.notification.Notification;
import com.uniken.domains.relid.notification.NotificationControlsActionWorkflowsParams;

/**
 * @author UNIKEN
 */
public class NotificationControlsActionWorkflowsParamsCodec
        implements
        Codec<NotificationControlsActionWorkflowsParams> {

    private final CodecRegistry codecRegistry;

    /**
     * Creates and returns a new instance of this class initialized with given
     * parameters.
     * 
     * @param codecRegistry
     *            the codec registry
     */
    public NotificationControlsActionWorkflowsParamsCodec(final CodecRegistry codecRegistry) {
        this.codecRegistry = codecRegistry;
    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Encoder#getEncoderClass()
     */
    @Override
    public Class<NotificationControlsActionWorkflowsParams> getEncoderClass() {
        return NotificationControlsActionWorkflowsParams.class;
    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Encoder#encode(org.bson.BsonWriter,
     * java.lang.Object, org.bson.codecs.EncoderContext)
     */
    @Override
    public void encode(final BsonWriter writer, final NotificationControlsActionWorkflowsParams object,
            final EncoderContext encoderContext) {
        writer.writeStartDocument();

        writer.writeName(Notification.NOTIFICATION_CONTROLS_ACTION_WORKFLOWS_PARAMS_JWT_EXPIRES_IN);
        writer.writeInt32(object.getJwtExpiresIn());

        writer.writeEndDocument();

    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Decoder#decode(org.bson.BsonReader,
     * org.bson.codecs.DecoderContext)
     */
    @Override
    public NotificationControlsActionWorkflowsParams decode(final BsonReader reader,
            final DecoderContext decoderContext) {
        final NotificationControlsActionWorkflowsParams object = new NotificationControlsActionWorkflowsParams();
        reader.readStartDocument();

        while (reader.readBsonType() != BsonType.END_OF_DOCUMENT) {
            switch (reader.readName()) {
            case Notification.NOTIFICATION_CONTROLS_ACTION_WORKFLOWS_PARAMS_JWT_EXPIRES_IN:
                object.setJwtExpiresIn(reader.readInt32());
                break;

            default:
                break;
            }
        }

        reader.readEndDocument();
        return object;
    }

}
