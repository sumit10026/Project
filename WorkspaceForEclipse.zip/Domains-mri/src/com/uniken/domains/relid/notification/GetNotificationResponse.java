package com.uniken.domains.relid.notification;

import java.util.Date;

import com.google.gson.annotations.SerializedName;

/*
 * @author Sumeet Khambe
 */
public class GetNotificationResponse extends ZeroResponse {

    @SerializedName("notification_details")
    private NotificationDetails notificationDetails;

    @SerializedName("rd_signature")
    private String rdSignature;

    @SerializedName("timestamp")
    private Date timestamp;

    @SerializedName("version")
    private String version;

    /**
     * @return the notificationDetails
     */
    public NotificationDetails getNotificationDetails() {
        return notificationDetails;
    }

    /**
     * @param notificationDetails
     *            the notificationDetails to set
     */
    public void setNotificationDetails(final NotificationDetails notificationDetails) {
        this.notificationDetails = notificationDetails;
    }

    /**
     * @return the rdSignature
     */
    public String getRdSignature() {
        return rdSignature;
    }

    /**
     * @param rdSignature
     *            the rdSignature to set
     */
    public void setRdSignature(final String rdSignature) {
        this.rdSignature = rdSignature;
    }

    /**
     * @return the timestamp
     */
    public Date getTimestamp() {
        return timestamp;
    }

    /**
     * @param timestamp
     *            the timestamp to set
     */
    public void setTimestamp(final Date timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * @return the version
     */
    public String getVersion() {
        return version;
    }

    /**
     * @param version
     *            the version to set
     */
    public void setVersion(final String version) {
        this.version = version;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "GetNotificationResponse [notificationDetails=" + notificationDetails + ", rdSignature=" + rdSignature
                + ", timestamp=" + timestamp + ", version=" + version + "]";
    }

}
