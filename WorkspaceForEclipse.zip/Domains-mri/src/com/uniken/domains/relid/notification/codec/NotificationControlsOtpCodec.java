/**
 * 
 */
package com.uniken.domains.relid.notification.codec;

import org.bson.BsonReader;
import org.bson.BsonType;
import org.bson.BsonWriter;
import org.bson.codecs.Codec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.codecs.configuration.CodecRegistry;

import com.uniken.domains.relid.notification.Notification;
import com.uniken.domains.relid.notification.NotificationControlsOtp;

/**
 * @author UNIKEN
 */
public class NotificationControlsOtpCodec
        implements
        Codec<NotificationControlsOtp> {

    private final CodecRegistry codecRegistry;

    /**
     * Creates and returns a new instance of this class initialized with given
     * parameters.
     * 
     * @param codecRegistry
     *            the codec registry
     */
    public NotificationControlsOtpCodec(final CodecRegistry codecRegistry) {
        this.codecRegistry = codecRegistry;
    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Encoder#getEncoderClass()
     */
    @Override
    public Class<NotificationControlsOtp> getEncoderClass() {
        return NotificationControlsOtp.class;
    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Encoder#encode(org.bson.BsonWriter,
     * java.lang.Object, org.bson.codecs.EncoderContext)
     */
    @Override
    public void encode(final BsonWriter writer, final NotificationControlsOtp object,
            final EncoderContext encoderContext) {
        writer.writeStartDocument();

        writer.writeName(Notification.NOTIFICATION_CONTROLS_OTP_ATTEMPTS);
        writer.writeInt32(object.getAttempts());

        if (null != object.getHashSpec()) {
            writer.writeName(Notification.NOTIFICATION_CONTROLS_OTP_HASH_SPEC);
            writer.writeString(object.getHashSpec());
        }

        writer.writeEndDocument();

    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Decoder#decode(org.bson.BsonReader,
     * org.bson.codecs.DecoderContext)
     */
    @Override
    public NotificationControlsOtp decode(final BsonReader reader, final DecoderContext decoderContext) {
        final NotificationControlsOtp object = new NotificationControlsOtp();
        reader.readStartDocument();

        while (reader.readBsonType() != BsonType.END_OF_DOCUMENT) {
            switch (reader.readName()) {
            case Notification.NOTIFICATION_CONTROLS_OTP_ATTEMPTS:
                object.setAttempts(reader.readInt32());
                break;

            case Notification.NOTIFICATION_CONTROLS_OTP_HASH_SPEC:
                object.setHashSpec(reader.readString());
                break;

            default:
                break;
            }
        }

        reader.readEndDocument();
        return object;
    }

}
