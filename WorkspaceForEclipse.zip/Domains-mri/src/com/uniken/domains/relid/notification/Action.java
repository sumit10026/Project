package com.uniken.domains.relid.notification;

import com.google.gson.annotations.SerializedName;

public class Action {

    private static final String LABEL = "label";
    private static final String ACTION = "action";
    private static final String AUTHLEVEL = "authlevel";
    private static final String AUTHENTICATOR = "authenticator";

    @SerializedName(LABEL)
    private String label;

    @SerializedName(ACTION)
    private String action;

    @SerializedName(AUTHLEVEL)
    private String authlevel;

    @SerializedName(AUTHENTICATOR)
    private String authenticator;

    /**
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * @param label
     *            the label to set
     */
    public void setLabel(final String label) {
        this.label = label;
    }

    /**
     * @return the action
     */
    public String getAction() {
        return action;
    }

    /**
     * @param action
     *            the action to set
     */
    public void setAction(final String action) {
        this.action = action;
    }

    /**
     * @return the authlevel
     */
    public String getAuthlevel() {
        if (null == authlevel)
            this.authlevel = "0";
        return authlevel;
    }

    /**
     * @param authlevel
     *            the authlevel to set
     */
    public void setAuthlevel(final String authlevel) {
        if (null != authlevel)
            this.authlevel = authlevel;
        else
            this.authlevel = "0";
    }

    /**
     * @return the authenticator
     */
    public String getAuthenticator() {
        return authenticator;
    }

    /**
     * @param authenticator
     *            the authenticator to set
     */
    public void setAuthenticator(final String authenticator) {
        this.authenticator = authenticator;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("Actions [label=");
        builder.append(label);
        builder.append(", action=");
        builder.append(action);
        builder.append(", authlevel=");
        builder.append(authlevel);
        builder.append(", authenticator=");
        builder.append(authenticator);
        builder.append("]");
        return builder.toString();
    }

}
