package com.uniken.domains.relid.device;

import java.util.Date;
import java.util.List;

import org.bson.Document;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.enums.DfpPolicyStatus;

/**
 * <H4>DFPPolicy</H4>
 * <p>
 * This POJO is for policy storing <i>device finger prints</i>. </br>
 * Every stored or new device will have :
 * <li>version (auto increment)</li>
 * <li>status (DfpPolicyStatus)</li>
 * <li>insertion time</li>
 * <li>updation time</li>
 * <li>policy</li>
 * </p>
 * 
 * @author Akash
 */

public class DFPPolicy {

    private static final String VERSION = "version";
    private static final String STATUS = "status";
    private static final String INSERT_TS = "insert_ts";
    private static final String UPDATE_TS = "update_ts";
    private static final String POLICY = "policy";

    @SerializedName(VERSION)
    public int version;

    @SerializedName(STATUS)
    public DfpPolicyStatus status;

    @SerializedName(INSERT_TS)
    public Date insertTs;

    @SerializedName(UPDATE_TS)
    public Date updateTs;

    @SerializedName(POLICY)
    public List<SubDFPPolicy> policy;

    /**
     * @return the version
     */
    public int getVersion() {
        return version;
    }

    /**
     * @param version
     *            the version to set
     */
    public void setVersion(final int version) {
        this.version = version;
    }

    /**
     * @return the status
     */
    public DfpPolicyStatus getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(final DfpPolicyStatus status) {
        this.status = status;
    }

    /**
     * @return the insertTs
     */
    public Date getInsertTs() {
        return insertTs;
    }

    /**
     * @param insertTs
     *            the insertTs to set
     */
    public void setInsertTs(final Date insertTs) {
        this.insertTs = insertTs;
    }

    /**
     * @return the updateTs
     */
    public Date getUpdateTs() {
        return updateTs;
    }

    /**
     * @param updateTs
     *            the updateTs to set
     */
    public void setUpdateTs(final Date updateTs) {
        this.updateTs = updateTs;
    }

    /**
     * @return the policy
     */
    public List<SubDFPPolicy> getPolicy() {
        return policy;
    }

    /**
     * @param policy
     *            the policy to set
     */
    public void setPolicy(final List<SubDFPPolicy> policy) {
        this.policy = policy;
    }

    /**
     * Create Bson document from the provided DFPPolicy object
     * 
     * @param dfpPolicy
     *            DFPPolicy to be converted to a Bson Document
     * @return A Bson document
     */
    public static Document getBsonDocument(final DFPPolicy dfpPolicy) {

        final Document dfpPolicyDoc = new Document();

        if (dfpPolicy.getVersion() > 0) {
            dfpPolicyDoc.append(DFPPolicy.VERSION, dfpPolicy.getVersion());
        }

        if (dfpPolicy.getStatus() != null) {
            dfpPolicyDoc.append(DFPPolicy.STATUS, dfpPolicy.getStatus());
        }

        if (dfpPolicy.getInsertTs() != null) {
            dfpPolicyDoc.append(DFPPolicy.INSERT_TS, dfpPolicy.getInsertTs());
        }

        if (dfpPolicy.getUpdateTs() != null) {
            dfpPolicyDoc.append(DFPPolicy.UPDATE_TS, dfpPolicy.getUpdateTs());
        }

        if (dfpPolicy.getPolicy() != null) {
            dfpPolicyDoc.append(DFPPolicy.POLICY, dfpPolicy.getPolicy());
        }
        return dfpPolicyDoc;
    }

}
