package com.uniken.domains.relid.device;

import java.util.Date;
import java.util.Map;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.user.vos.SecureCookie;

/**
 * web device master domain object
 * 
 * @author Uday T
 */
@Document(collection = "web_dev_master")
public class WebDevMaster {

    @Indexed
    public static final String WEB_ID_STR = "web_device_uuid";
    public static final String STATUS_STR = "status";
    public static final String USER_LOCATION_STR = "user_location";
    public static final String WEB_DEV_PARAMETERS_STR = "web_device_parameters";
    public static final String CREATED_TS_STR = "created_ts";
    public static final String UPDATED_TS_STR = "updated_ts";

    @Indexed
    public static final String WEB_DEV_PARAMETERS_CHECKSUM_STR = "web_device_parameter_checksum";

    // For storing secure cookie in WebDevMaster
    public static final String SECURE_COOKIE = "secure_cookie";

    @Id
    public ObjectId _id;

    @Field(WEB_ID_STR)
    @SerializedName(WEB_ID_STR)
    private final String webDeviceUuid;

    @Field(STATUS_STR)
    @SerializedName(STATUS_STR)
    private String status;

    @Field(USER_LOCATION_STR)
    @SerializedName(USER_LOCATION_STR)
    private UserLocation userLocation;

    @Field(WEB_DEV_PARAMETERS_STR)
    @SerializedName(WEB_DEV_PARAMETERS_STR)
    private Map<String, Object> webDeviceParameters;

    @Field(CREATED_TS_STR)
    @SerializedName(CREATED_TS_STR)
    private final Date createdTS;

    @Field(UPDATED_TS_STR)
    @SerializedName(UPDATED_TS_STR)
    private Date updatedTS;

    @Field(WEB_DEV_PARAMETERS_CHECKSUM_STR)
    @SerializedName(WEB_DEV_PARAMETERS_CHECKSUM_STR)
    private String webDeviceParameterChecksum;

    @SerializedName(SECURE_COOKIE)
    @Field(SECURE_COOKIE)
    private SecureCookie secureCookie;

    /**
     * Parameterized constructor
     * 
     * @param webDeviceUuid
     * @param status
     * @param webDeviceParameters
     * @param createdTS
     * @param updatedTS
     * @param webDeviceParameterChecksum
     */
    public WebDevMaster(final String webDeviceUuid, final String status, final UserLocation userLocation,
            final Map<String, Object> webDeviceParameters, final Date createdTS, final Date updatedTS,
            final String webDeviceParameterChecksum) {
        this.webDeviceUuid = webDeviceUuid;
        this.status = status;
        this.userLocation = userLocation;
        this.webDeviceParameters = webDeviceParameters;
        this.createdTS = createdTS;
        this.updatedTS = updatedTS;
        this.webDeviceParameterChecksum = webDeviceParameterChecksum;
    }

    /**
     * @return the webDeviceUuid
     */
    public String getWebDeviceUuid() {
        return webDeviceUuid;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @return the userLocation
     */
    public UserLocation getUserLocation() {
        return userLocation;
    }

    /**
     * @return the webDeviceParameters
     */
    public Map<String, Object> getWebDeviceParameters() {
        return webDeviceParameters;
    }

    /**
     * @return the createdTS
     */
    public Date getCreatedTS() {
        return createdTS;
    }

    /**
     * @return the updatedTS
     */
    public Date getUpdatedTS() {
        return updatedTS;
    }

    /**
     * @return the webDeviceParameterChecksum
     */
    public String getWebDeviceParameterChecksum() {
        return webDeviceParameterChecksum;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(final String status) {
        this.status = status;
    }

    /**
     * @param userLocation
     */
    public void setUserLocation(final UserLocation userLocation) {
        this.userLocation = userLocation;
    }

    /**
     * @param webDeviceParameters
     *            the webDeviceParameters to set
     */
    public void setWebDeviceParameters(final Map<String, Object> webDeviceParameters) {
        this.webDeviceParameters = webDeviceParameters;
    }

    /**
     * @param updatedTS
     *            the updatedTS to set
     */
    public void setUpdatedTS(final Date updatedTS) {
        this.updatedTS = updatedTS;
    }

    /**
     * @param webDeviceParameterChecksum
     *            the webDeviceParameterChecksum to set
     */
    public void setWebDeviceParameterChecksum(final String webDeviceParameterChecksum) {
        this.webDeviceParameterChecksum = webDeviceParameterChecksum;
    }

    /**
     * @return secureCookie Returns the secure cookie value
     */
    public SecureCookie getSecureCookie() {
        return secureCookie;
    }

    /**
     * @param secureCookie
     *            the secureCookie to set
     */

    public void setSecureCookie(final SecureCookie secureCookie) {
        this.secureCookie = secureCookie;
    }

}
