package com.uniken.domains.relid.device;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * This class is used a domain object for interaction with Device collection in
 * database
 * 
 * @author Sumeet Khambe
 */
public class Device {

    public final static String DEVICE_PARAMETER = "device_parameters";
    public final static String DEVICE_PLATFORM_PARAMETER = "device_parameters.Platform";
    public final static String CREATE_TS = "create_ts";
    public final static String UPDATE_TS = "update_ts";
    public final static String DEVICE_UUID = "device_uuid";
    public final static String STATUS = "status";
    public final static String INVARIANT_PARAMETERS = "invariant_parameters";
    public final static String VARIANT_PARAMETERS = "variant_parameters";
    public final static String PRIVACY_KEY = "privacy_key";

    @SerializedName(DEVICE_PARAMETER)
    @Field(DEVICE_PARAMETER)
    private DfpParameters dfpParameters;

    @SerializedName(STATUS)
    @Field(STATUS)
    private String status;

    @SerializedName(CREATE_TS)
    @Field(CREATE_TS)
    private Date insts;

    @Expose
    @SerializedName(UPDATE_TS)
    @Field(UPDATE_TS)
    private Date updts;

    @Expose
    @SerializedName(INVARIANT_PARAMETERS)
    @Field(INVARIANT_PARAMETERS)
    private DfpParameters invariantParameters;

    @SerializedName(VARIANT_PARAMETERS)
    @Field(VARIANT_PARAMETERS)
    private DfpParameters variantParameters;

    @Expose
    @SerializedName(DEVICE_UUID)
    @Field(DEVICE_UUID)
    private String deviceUuid;

    @Expose
    @SerializedName(PRIVACY_KEY)
    @Field(PRIVACY_KEY)
    private String dfpPrivacyKey;

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(final String status) {
        this.status = status;
    }

    /**
     * @param insts
     *            the insts to set
     */
    public void setInsts(final Date insts) {
        this.insts = insts;
    }

    /**
     * @param updts
     *            the updts to set
     */
    public void setUpdts(final Date updts) {
        this.updts = updts;
    }

    /**
     * @return the insts
     */
    public Date getInsts() {
        return insts;
    }

    /**
     * @return the updts
     */
    public Date getUpdts() {
        return updts;
    }

    /**
     * @return the invariantParameters
     */
    public DfpParameters getInvariantParameters() {
        return invariantParameters;
    }

    /**
     * @param invariantParameters
     *            the invariantParameters to set
     */
    public void setInvariantParameters(final DfpParameters invariantParameters) {
        this.invariantParameters = invariantParameters;
    }

    /**
     * @return the dfpParameters
     */
    public DfpParameters getDfpParameters() {
        return dfpParameters;
    }

    /**
     * @param dfpParameters
     *            the dfpParameters to set
     */
    public void setDfpParameters(final DfpParameters dfpParameters) {
        this.dfpParameters = dfpParameters;
    }

    /**
     * @return the deviceUuid
     */
    public String getDeviceUuid() {
        return deviceUuid;
    }

    /**
     * @param deviceUuid
     *            the deviceUuid to set
     */
    public void setDeviceUuid(final String deviceUuid) {
        this.deviceUuid = deviceUuid;
    }

    /**
     * @return the dfpPrivacyKey
     */
    public String getDfpPrivacyKey() {
        return dfpPrivacyKey;
    }

    /**
     * @param dfpPrivacyKey
     *            the dfpPrivacyKey to set
     */
    public void setDfpPrivacyKey(final String dfpPrivacyKey) {
        this.dfpPrivacyKey = dfpPrivacyKey;
    }

    /**
     * @return the variantParameters
     */
    public DfpParameters getVariantParameters() {
        return variantParameters;
    }

    /**
     * @param variantParameters
     *            the variantParameters to set
     */
    public void setVariantParameters(final DfpParameters variantParameters) {
        this.variantParameters = variantParameters;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("Device [dfpParameters=");
        builder.append(dfpParameters);
        builder.append(", status=");
        builder.append(status);
        builder.append(", insts=");
        builder.append(insts);
        builder.append(", updts=");
        builder.append(updts);
        builder.append(", invariantParameters=");
        builder.append(invariantParameters);
        builder.append(", variantParameters=");
        builder.append(variantParameters);
        builder.append(", deviceUuid=");
        builder.append(deviceUuid);
        builder.append(", dfpPrivacyKey=");
        builder.append(dfpPrivacyKey);
        builder.append("]");
        return builder.toString();
    }

}
