package com.uniken.domains.relid.device;

import java.util.Date;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * This POJO is to store the mapping of user device and application in database
 * 
 * @author Akash S
 */
public class UserDeviceAppMapping {

    public static final String USER_ID = "user_id";
    public static final String USER_UUID = "user_uuid";
    public static final String RELID_UUID = "relid_uuid";
    public static final String DEVICE_UUID = "device_uuid";
    public static final String APP_UUID = "app_uuid";
    public static final String APP_NAME = "app_name";
    public static final String CREATED_TS = "created_ts";
    public static final String DEVICE_NAME = "device_name";

    @SerializedName(value = USER_ID)
    @Field(value = USER_ID)
    private String userId;

    @SerializedName(value = USER_UUID)
    @Field(value = USER_UUID)
    private String userUuid;

    @SerializedName(RELID_UUID)
    @Field(RELID_UUID)
    private String relIdUuid;

    @SerializedName(value = DEVICE_UUID)
    @Field(value = DEVICE_UUID)
    private String deviceUuid;

    @SerializedName(value = APP_UUID)
    @Field(value = APP_UUID)
    private String appUuid;

    @SerializedName(value = APP_NAME)
    @Field(value = APP_NAME)
    private String appName;

    @SerializedName(value = DEVICE_NAME)
    @Field(value = DEVICE_NAME)
    private String deviceName;

    @SerializedName(value = CREATED_TS)
    @Field(value = CREATED_TS)
    private Date createdTs;

    public UserDeviceAppMapping(final String userId, final String userUuid, final String relIdUuid,
            final String deviceUuid, final String deviceName, final String appUuid, final String appName,
            final Date createdTs) {
        this.userId = userId;
        this.userUuid = userUuid;
        this.relIdUuid = relIdUuid;
        this.deviceName = deviceName;
        this.deviceUuid = deviceUuid;
        this.appUuid = appUuid;
        this.appName = appName;
        this.createdTs = createdTs;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(final String userId) {
        this.userId = userId;
    }

    public String getUserUuid() {
        return userUuid;
    }

    public void setUserUuid(final String userUuid) {
        this.userUuid = userUuid;
    }

    public String getRelIdUuid() {
        return relIdUuid;
    }

    public void setRelIdUuid(final String relIdUuid) {
        this.relIdUuid = relIdUuid;
    }

    public String getDeviceUuid() {
        return deviceUuid;
    }

    public void setDeviceUuid(final String deviceUuid) {
        this.deviceUuid = deviceUuid;
    }

    public String getAppUuid() {
        return appUuid;
    }

    public void setAppUuid(final String appUuid) {
        this.appUuid = appUuid;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(final String deviceName) {
        this.deviceName = deviceName;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(final String appName) {
        this.appName = appName;
    }

    public Date getCreatedTs() {
        return createdTs;
    }

    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }

    /**
     * Get the bson object of UserDeviceAppMapping Object
     * 
     * @param mapping
     * @return : Bson object
     */
    public static Document getBsonDocument(final UserDeviceAppMapping mapping) {

        if (null == mapping) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != mapping.getUserId()) {
            logsDoc.append(USER_ID, mapping.getUserId());
        }
        if (null != mapping.getUserUuid()) {
            logsDoc.append(USER_UUID, mapping.getUserUuid());
        }
        if (null != mapping.getRelIdUuid()) {
            logsDoc.append(RELID_UUID, mapping.getRelIdUuid());
        }
        if (null != mapping.getDeviceUuid()) {
            logsDoc.append(DEVICE_UUID, mapping.getDeviceUuid());
        }
        if (null != mapping.getDeviceName()) {
            logsDoc.append(DEVICE_NAME, mapping.getDeviceName());
        }
        if (null != mapping.getAppUuid()) {
            logsDoc.append(APP_UUID, mapping.getAppUuid());
        }
        if (null != mapping.getAppUuid()) {
            logsDoc.append(APP_NAME, mapping.getAppName());
        }
        if (null != mapping.getCreatedTs()) {
            logsDoc.append(CREATED_TS, mapping.getCreatedTs());
        }

        return logsDoc;
    }

}
