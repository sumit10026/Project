package com.uniken.domains.relid.device;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.relid.ComparableData;

/**
 * @author uniken
 */
public class Policy {

    public static final String ID = "_id";
    public static final String POLICY_UUID = "policy_uuid";
    public static final String PLATFORM = "platform";
    public static final String EXPRESSION = "expression";
    public static final String COMPARABLE_DATA = "comparable_data";
    public static final String LEVEL_IDENTIFIER = "level_identifier";
    public static final String CREATED_TS = "created_ts";

    @SerializedName(POLICY_UUID)
    @Field(POLICY_UUID)
    private String policyUuid;

    @SerializedName(PLATFORM)
    @Field(PLATFORM)
    private String platform;

    @SerializedName(EXPRESSION)
    @Field(EXPRESSION)
    private String expression;

    @SerializedName(COMPARABLE_DATA)
    @Field(COMPARABLE_DATA)
    private List<ComparableData> comparableData;

    @SerializedName(LEVEL_IDENTIFIER)
    @Field(LEVEL_IDENTIFIER)
    private String levelIdentifier;

    @SerializedName(CREATED_TS)
    @Field(CREATED_TS)
    private Date createdTs;

    /**
     * @return the policyUuid
     */
    public String getPolicyUuid() {
        return policyUuid;
    }

    /**
     * @param policyUuid
     *            the policyUuid to set
     */
    public void setPolicyUuid(final String policyUuid) {
        this.policyUuid = policyUuid;
    }

    /**
     * @return the platform
     */
    public String getPlatform() {
        return platform;
    }

    /**
     * @param platform
     *            the platform to set
     */
    public void setPlatform(final String platform) {
        this.platform = platform;
    }

    /**
     * @return the expression
     */
    public String getExpression() {
        return expression;
    }

    /**
     * @param expression
     *            the expression to set
     */
    public void setExpression(final String expression) {
        this.expression = expression;
    }

    /**
     * @return the comparableData
     */
    public List<ComparableData> getComparableData() {
        return comparableData;
    }

    /**
     * @param comparableData
     *            the comparableData to set
     */
    public void setComparableData(final List<ComparableData> comparableData) {
        this.comparableData = comparableData;
    }

    /**
     * @return the levelIdentifier
     */
    public String getLevelIdentifier() {
        return levelIdentifier;
    }

    /**
     * @param userNames
     *            the userNames to set
     */
    public void setLevelIdentifier(final String levelIdentifier) {
        this.levelIdentifier = levelIdentifier;
    }

    /**
     * @return the createdTs
     */
    public Date getCreatedTs() {
        return createdTs;
    }

    /**
     * @param createdTs
     *            the createdTs to set
     */
    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "Policy [platform=" + platform + ", policyUuid=" + policyUuid + ", expression=" + expression
                + ", comparableData=" + comparableData + ", levelIdentifier=" + levelIdentifier + ", createdTs="
                + createdTs + "]";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((comparableData == null) ? 0 : comparableData.hashCode());
        result = prime * result + ((createdTs == null) ? 0 : createdTs.hashCode());
        result = prime * result + ((expression == null) ? 0 : expression.hashCode());
        result = prime * result + ((platform == null) ? 0 : platform.hashCode());
        result = prime * result + ((policyUuid == null) ? 0 : policyUuid.hashCode());
        result = prime * result + ((levelIdentifier == null) ? 0 : levelIdentifier.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final Policy other = (Policy) obj;
        if (comparableData == null) {
            if (other.comparableData != null)
                return false;
        } else if (!comparableData.equals(other.comparableData))
            return false;
        if (createdTs == null) {
            if (other.createdTs != null)
                return false;
        } else if (!createdTs.equals(other.createdTs))
            return false;
        if (expression == null) {
            if (other.expression != null)
                return false;
        } else if (!expression.equals(other.expression))
            return false;
        if (platform == null) {
            if (other.platform != null)
                return false;
        } else if (!platform.equals(other.platform))
            return false;
        if (policyUuid == null) {
            if (other.policyUuid != null)
                return false;
        } else if (!policyUuid.equals(other.policyUuid))
            return false;
        if (levelIdentifier == null) {
            if (other.levelIdentifier != null)
                return false;
        } else if (!levelIdentifier.equals(other.levelIdentifier))
            return false;
        return true;
    }

}
