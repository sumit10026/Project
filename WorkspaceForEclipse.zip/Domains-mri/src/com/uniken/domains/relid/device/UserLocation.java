package com.uniken.domains.relid.device;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

public class UserLocation {

    public static final String LATITUDE_STR = "latitude";
    public static final String LONGITUDE_STR = "longitude";

    @Field(LATITUDE_STR)
    @SerializedName(LATITUDE_STR)
    private String latitude;

    @Field(LONGITUDE_STR)
    @SerializedName(LONGITUDE_STR)
    private String longitude;

    /**
     * Parameterized constructor
     * 
     * @param latitude
     * @param longitude
     */
    public UserLocation(final String latitude, final String longitude) {
        this.latitude = latitude;
        this.longitude = longitude;
    }

    /**
     * @return the latitude
     */
    public String getLatitude() {
        return latitude;
    }

    /**
     * @param latitude
     *            the latitude to set
     */
    public void setLatitude(final String latitude) {
        this.latitude = latitude;
    }

    /**
     * @return the longitude
     */
    public String getLongitude() {
        return longitude;
    }

    /**
     * @param longitude
     *            the longitude to set
     */
    public void setLongitude(final String longitude) {
        this.longitude = longitude;
    }

}
