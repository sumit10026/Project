package com.uniken.domains.relid.device;

import java.util.Date;

import com.google.gson.annotations.SerializedName;

public class DFPMaster {

    public final static String STATUS = "status";
    public final static String DEVICE_UUID = "device_uuid";
    public final static String PRIVACY_KEY = "privacy_key";
    public final static String INVARIANT_PARAMETERS = "invariant_parameters";
    public final static String DEVICE_PARAMETERS = "device_parameters";
    public final static String CREATED_TS = "created_ts";
    public final static String UPDATED_TS = "updated_ts";
    public final static String ACCESSED_TS = "accessed_ts";

    @SerializedName(STATUS)
    private String status;

    @SerializedName(DEVICE_UUID)
    private String deviceUuid;

    @SerializedName(PRIVACY_KEY)
    private String privacyKey;

    @SerializedName(INVARIANT_PARAMETERS)
    private String invariantParameters;

    @SerializedName(DEVICE_PARAMETERS)
    private DfpParameters deviceParameters;

    @SerializedName(CREATED_TS)
    private Date createdTs;

    @SerializedName(UPDATED_TS)
    private Date updatedTs;

    @SerializedName(ACCESSED_TS)
    private Date accessedTs;

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(final String status) {
        this.status = status;
    }

    /**
     * @return the deviceUuid
     */
    public String getDeviceUuid() {
        return deviceUuid;
    }

    /**
     * @param deviceUuid
     *            the deviceUuid to set
     */
    public void setDeviceUuid(final String deviceUuid) {
        this.deviceUuid = deviceUuid;
    }

    /**
     * @return the privacyKey
     */
    public String getPrivacyKey() {
        return privacyKey;
    }

    /**
     * @param privacyKey
     *            the privacyKey to set
     */
    public void setPrivacyKey(final String privacyKey) {
        this.privacyKey = privacyKey;
    }

    /**
     * @return the invariantParameters
     */
    public String getInvariantParameters() {
        return invariantParameters;
    }

    /**
     * @param invariantParameters
     *            the invariantParameters to set
     */
    public void setInvariantParameters(final String invariantParameters) {
        this.invariantParameters = invariantParameters;
    }

    /**
     * @return the deviceParameters
     */
    public DfpParameters getDeviceParameters() {
        return deviceParameters;
    }

    /**
     * @param deviceParameters
     *            the deviceParameters to set
     */
    public void setDeviceParameters(final DfpParameters deviceParameters) {
        this.deviceParameters = deviceParameters;
    }

    /**
     * @return the createdTs
     */
    public Date getCreatedTs() {
        return createdTs;
    }

    /**
     * @param createdTs
     *            the createdTs to set
     */
    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }

    /**
     * @return the updatedTs
     */
    public Date getUpdatedTs() {
        return updatedTs;
    }

    /**
     * @param updatedTs
     *            the updatedTs to set
     */
    public void setUpdatedTs(final Date updatedTs) {
        this.updatedTs = updatedTs;
    }

    /**
     * @return the accessedTs
     */
    public Date getAccessedTs() {
        return accessedTs;
    }

    /**
     * @param accessedTs
     *            the accessedTs to set
     */
    public void setAccessedTs(final Date accessedTs) {
        this.accessedTs = accessedTs;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "DFPMaster [status=" + status + ", deviceUuid=" + deviceUuid + ", privacyKey=" + privacyKey
                + ", invariantParameters=" + invariantParameters + ", deviceParameters=" + deviceParameters
                + ", createdTs=" + createdTs + ", updatedTs=" + updatedTs + ", accessedTs=" + accessedTs + "]";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((accessedTs == null) ? 0 : accessedTs.hashCode());
        result = prime * result + ((createdTs == null) ? 0 : createdTs.hashCode());
        result = prime * result + ((deviceParameters == null) ? 0 : deviceParameters.hashCode());
        result = prime * result + ((deviceUuid == null) ? 0 : deviceUuid.hashCode());
        result = prime * result + ((invariantParameters == null) ? 0 : invariantParameters.hashCode());
        result = prime * result + ((privacyKey == null) ? 0 : privacyKey.hashCode());
        result = prime * result + ((status == null) ? 0 : status.hashCode());
        result = prime * result + ((updatedTs == null) ? 0 : updatedTs.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final DFPMaster other = (DFPMaster) obj;
        if (accessedTs == null) {
            if (other.accessedTs != null)
                return false;
        } else if (!accessedTs.equals(other.accessedTs))
            return false;
        if (createdTs == null) {
            if (other.createdTs != null)
                return false;
        } else if (!createdTs.equals(other.createdTs))
            return false;
        if (deviceParameters == null) {
            if (other.deviceParameters != null)
                return false;
        } else if (!deviceParameters.equals(other.deviceParameters))
            return false;
        if (deviceUuid == null) {
            if (other.deviceUuid != null)
                return false;
        } else if (!deviceUuid.equals(other.deviceUuid))
            return false;
        if (invariantParameters == null) {
            if (other.invariantParameters != null)
                return false;
        } else if (!invariantParameters.equals(other.invariantParameters))
            return false;
        if (privacyKey == null) {
            if (other.privacyKey != null)
                return false;
        } else if (!privacyKey.equals(other.privacyKey))
            return false;
        if (status == null) {
            if (other.status != null)
                return false;
        } else if (!status.equals(other.status))
            return false;
        if (updatedTs == null) {
            if (other.updatedTs != null)
                return false;
        } else if (!updatedTs.equals(other.updatedTs))
            return false;
        return true;
    }

}
