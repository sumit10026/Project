/**
 * 
 */
package com.uniken.domains.relid.device.codec;

import org.bson.BsonReader;
import org.bson.BsonType;
import org.bson.BsonWriter;
import org.bson.codecs.Codec;
import org.bson.codecs.DecoderContext;
import org.bson.codecs.EncoderContext;
import org.bson.codecs.configuration.CodecRegistry;

import com.uniken.domains.relid.device.DfpParameters;

/**
 * @author Uniken Inc.
 */
public class DfpParameterCodec
        implements
        Codec<DfpParameters> {

    private CodecRegistry codecRegistry;

    public DfpParameterCodec() {}

    /**
     * @param codecRegistry
     */
    public DfpParameterCodec(final CodecRegistry codecRegistry) {
        this.codecRegistry = codecRegistry;
    }

    /*
     * (non-Javadoc)
     * @see org.bson.codecs.Encoder#encode(org.bson.BsonWriter, java.lang.Object,
     * org.bson.codecs.EncoderContext)
     */
    @Override
    public void encode(final BsonWriter writer, final DfpParameters dfpParameters, final EncoderContext context) {

        writer.writeStartDocument();

        if (dfpParameters.getiPAddress() != null) {
            writer.writeName(DfpParameters.IP_ADDRESS);
            writer.writeString(dfpParameters.getiPAddress());
        }

        if (dfpParameters.getNwMacAddr() != null) {
            writer.writeName(DfpParameters.NW_MAC_ADDRESS);
            writer.writeString(dfpParameters.getNwMacAddr());
        }

        if (dfpParameters.getCarrierNameOprator() != null) {
            writer.writeName(DfpParameters.CARRIER_NAME_OPERATOR);
            writer.writeString(dfpParameters.getCarrierNameOprator());
        }

        if (dfpParameters.getCarrierSerialNumber() != null) {
            writer.writeName(DfpParameters.CARRIER_SR_NUM);
            writer.writeString(dfpParameters.getCarrierSerialNumber());
        }

        if (dfpParameters.getLatitude() != null) {
            writer.writeName(DfpParameters.LATITUDE);
            writer.writeString(dfpParameters.getLatitude());
        }

        if (dfpParameters.getLongitude() != null) {
            writer.writeName(DfpParameters.LONGITUDE);
            writer.writeString(dfpParameters.getLongitude());
        }

        if (dfpParameters.getAltitude() != null) {
            writer.writeName(DfpParameters.ALTITUDE);
            writer.writeString(dfpParameters.getAltitude());
        }

        if (dfpParameters.getSsid() != null) {
            writer.writeName(DfpParameters.SSID);
            writer.writeString(dfpParameters.getSsid());
        }

        if (dfpParameters.getBssid() != null) {
            writer.writeName(DfpParameters.BSSID);
            writer.writeString(dfpParameters.getBssid());
        }

        if (dfpParameters.getPlatform() != null) {
            writer.writeName(DfpParameters.PLATFORM);
            writer.writeString(dfpParameters.getPlatform());
        }

        if (dfpParameters.getAppName() != null) {
            writer.writeName(DfpParameters.APPNAME);
            writer.writeString(dfpParameters.getAppName());
        }

        if (dfpParameters.getAppVersion() != null) {
            writer.writeName(DfpParameters.APPVERSION);
            writer.writeString(dfpParameters.getAppVersion());
        }

        if (dfpParameters.getCarrierName() != null) {
            writer.writeName(DfpParameters.CARRIER_NAME);
            writer.writeString(dfpParameters.getCarrierName());
        }

        writer.writeEndDocument();

    }

    /**
     * @return the {@link DfpParameters} CLASS reference.
     */
    @Override
    public Class<DfpParameters> getEncoderClass() {
        return DfpParameters.class;
    }

    /**
     * @param reader
     * @param context
     * @return
     */
    @Override
    public DfpParameters decode(final BsonReader reader, final DecoderContext context) {

        reader.readStartDocument();

        final DfpParameters dfpParameters = new DfpParameters();

        while (reader.readBsonType() != BsonType.END_OF_DOCUMENT) {

            switch (reader.readName()) {
            case DfpParameters.IP_ADDRESS:
                dfpParameters.setiPAddress(reader.readString());
                break;

            case DfpParameters.NW_MAC_ADDRESS:
                dfpParameters.setNwMacAddr(reader.readString());
                break;

            case DfpParameters.CARRIER_NAME_OPERATOR:
                dfpParameters.setCarrierNameOprator(reader.readString());
                break;

            case DfpParameters.CARRIER_SR_NUM:
                dfpParameters.setCarrierSerialNumber(reader.readString());
                break;

            case DfpParameters.LATITUDE:
                dfpParameters.setLatitude(reader.readString());
                break;

            case DfpParameters.LONGITUDE:
                dfpParameters.setLongitude(reader.readString());
                break;

            case DfpParameters.ALTITUDE:
                dfpParameters.setAltitude(reader.readString());
                break;

            case DfpParameters.SSID:
                dfpParameters.setSsid(reader.readString());
                break;

            case DfpParameters.BSSID:
                dfpParameters.setBssid(reader.readString());
                break;

            case DfpParameters.PLATFORM:
                dfpParameters.setPlatform(reader.readString());
                break;

            case DfpParameters.APPNAME:
                dfpParameters.setAppName(reader.readString());
                break;

            case DfpParameters.APPVERSION:
                dfpParameters.setAppVersion(reader.readString());
                break;

            case DfpParameters.CARRIER_NAME:
                dfpParameters.setCarrierName(reader.readString());
                break;

            default:
                break;
            }

        }

        reader.readEndDocument();
        return dfpParameters;
    }

    /**
     * @return the codecRegistry
     */
    public CodecRegistry getCodecRegistry() {
        return codecRegistry;
    }

    /**
     * @param codecRegistry
     *            the codecRegistry to set
     */
    public void setCodecRegistry(final CodecRegistry codecRegistry) {
        this.codecRegistry = codecRegistry;
    }

}
