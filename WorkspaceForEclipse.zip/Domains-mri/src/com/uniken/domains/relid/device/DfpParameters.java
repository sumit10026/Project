package com.uniken.domains.relid.device;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * Used to store device finger print parameters. Every field of this class has
 * SerializedName annotation which represents key name while converting from/to
 * the json.
 * 
 * @author Sumeet Khambe
 */
public class DfpParameters
        implements
        Cloneable {

    public static final String APP_IDENTIFIER = "AppIdentifier";
    public static final String AUDIO_ADAPTER = "AudioAdapter";
    public static final String BIOS = "Bios";
    public static final String BROADBAND_DEVID = "BroadbandDevID";
    public static final String BT_MAC_ADDRESS = "BtMacAddr";
    public static final String CPU_ID = "CpuId";
    public static final String DISK_SR_NO = "DiskSrNo";
    public static final String IP_ADDRESS = "IPAddress";
    public static final String MANUFACTURER = "Manufacturer";
    public static final String MEMORY = "Memory";
    public static final String NW_MAC_ADDRESS = "NwMacAddr";
    public static final String PLATFORM = "Platform";
    public static final String PRODUCT_NAME = "ProductName";
    public static final String TIME_ZONE = "TimeZone";
    public static final String ADVERTISING_ID = "AdvertisingIdentifier";
    public static final String CARRIER_COUNTRY_CODE = "CarrierCountryCode";
    public static final String CARRIER_NAME = "CarrierName";
    public static final String CARRIER_NETWORK_CODE = "CarrierNetworkCode";
    public static final String COUNTRY = "Country";
    public static final String DEV_DEVICE_MODEL = "DeveloperDeviceModel";
    public static final String DEVICE_MODEL = "DeviceModel";
    public static final String DEVICE_NAME = "DeviceName";
    public static final String DEVICE_UUID = "DeviceUUID";
    public static final String KERNEL_INFO = "KernelInfo";
    public static final String LOCALIZED_MODEL = "LocalizedModel";
    public static final String NUM_OF_PROCESSORS = "NumberOfProcessors";
    public static final String OS_VERSION = "OsVersion";
    public static final String OS_VERSION_BUILD = "OSVersionBuild";
    public static final String SCREEN_HEIGHT = "ScreenHeight";
    public static final String SCREEN_WIDTH = "ScreenWidth";
    public static final String SYSTEM_MACH_NAME = "SystemMachineName";
    public static final String VENDOR_IDENTIFIER = "VendorIdentifier";
    public static final String ANDROID_ID = "AndroidID";
    public static final String BOARD = "Board";
    public static final String BOOT_LOADER = "BootLoader";
    public static final String BRAND = "Brand";
    public static final String CPU_ABIS = "CPU_ABIS";
    public static final String CARRIER_NAME_OPERATOR = "CarrierNameOprator";
    public static final String CARRIER_SR_NUM = "CarrierSerialNumber";
    public static final String DPI = "DPI";
    public static final String DERIVE_FINGER_PRINT = "DeriveFingerPrint";
    public static final String DEVICE = "Device";
    public static final String DEVICE_TYPE = "DeviceType";
    public static final String DISPLAY = "Display";
    public static final String HARDWARE = "Hardware";
    public static final String HARDWARE_SR_NUM = "HardwareSerialNumber";
    public static final String DISK_DRIVE_SR_NUM = "DiskDriveSerialNumber";
    public static final String IMEI = "IMEI";
    public static final String IMSI = "IMSI";
    public static final String MODEL = "Model";
    public static final String NW_COUNTRY_ISO = "NetworkCountryISO";
    public static final String NW_OP = "NetworkOperator";
    public static final String NW_OP_NAME = "NetworkOperatorName";
    public static final String PHONE_NUM = "PhoneNumber";
    public static final String PRODUCT = "Product";
    public static final String RADIO = "Radio";
    public static final String SCREEN_SIZE = "ScreenSize";
    public static final String TAGS = "Tags";
    public static final String TYPE = "Type";
    public static final String LATITUDE = "Latitude";
    public static final String LONGITUDE = "Longitude";
    public static final String ALTITUDE = "Altitude";
    public static final String APPNAME = "AppName";
    public static final String APPVERSION = "AppVersion";
    public static final String SSID = "SSID";
    public static final String BSSID = "BSSID";
    public static final String CS_DFP = "cs_dfp";

    // new parameters for MAC and Windows desktop
    public static final String PROCESSORINFO = "ProcessorInfo";
    public static final String PROCESSORSERIALNUMBER = "ProcessorSerialNumber";
    public static final String NETBIOS = "NetBios";
    public static final String DNSHOSTNAME = "DNSHostname";
    public static final String DNSDOMAIN = "DNSDomain";
    public static final String ARCHITECTURE = "Architecture";
    public static final String OSSERVICEPACK = "OsServicePack";
    public static final String OSBUILDNUMBER = "OsBuildNumber";
    public static final String CPUBRAND = "CPUBrand";
    public static final String CPUTYPE = "CpuType";
    public static final String PACKAGES = "Packages";
    public static final String CURRENTPROCESSORSPEED = "CurrentProcessorSpeed";
    public static final String L3CACHE = "L3Cache";
    public static final String BOOTROMVERSION = "BootRomVersion";
    public static final String L2CACHECORE = "L2CacheCore";
    public static final String NUMBEROFCORES = "NumberofCores";
    public static final String MACHINENAME = "MachineName";
    public static final String PRIMARYMACADDRESS = "PrimaryMACAddress";
    public static final String LOCALIZEDNAME = "LocalizedName";
    public static final String PHYSICALMEMORY = "PhysicalMemory";
    public static final String SERIALNUMBER = "SerialNumber";
    public static final String MACHINEMODEL = "MachineModel";
    public static final String SMCVERSIONSYSTEM = "SmcVersionSystem";
    public static final String PLATFORMUUID = "PlatformUuid";

    public static final String MANUFACTURER_FB = "Manufacturer_FB";
    public static final String HARDWARE_SR_NUM_FB = "HardwareSerialNumber_FB";
    public static final String DISK_DRIVE_SR_NUM_FB = "DiskDriveSerialNumber_FB";
    public static final String OS_MAJOR = "OS_MAJOR";

    @SerializedName(APP_IDENTIFIER)
    @Field(APP_IDENTIFIER)
    private String appIdentifier;

    @SerializedName(AUDIO_ADAPTER)
    @Field(AUDIO_ADAPTER)
    private String audioAdapter;

    @SerializedName(BIOS)
    @Field(BIOS)
    private String bios;

    @SerializedName(BROADBAND_DEVID)
    @Field(BROADBAND_DEVID)
    private String broadbandDevID;

    @SerializedName(BT_MAC_ADDRESS)
    @Field(BT_MAC_ADDRESS)
    private String btMacAddr;

    @SerializedName(CPU_ID)
    @Field(CPU_ID)
    private String cpuId;

    @SerializedName(DISK_SR_NO)
    @Field(DISK_SR_NO)
    private String diskSrNo;

    @SerializedName(IP_ADDRESS)
    @Field(IP_ADDRESS)
    private String iPAddress;

    @SerializedName(MANUFACTURER)
    @Field(MANUFACTURER)
    private String manufacturer;

    @SerializedName(MEMORY)
    @Field(MEMORY)
    private String memory;

    @SerializedName(NW_MAC_ADDRESS)
    @Field(NW_MAC_ADDRESS)
    private String nwMacAddr;

    @SerializedName(PLATFORM)
    @Field(PLATFORM)
    private String platform;

    @SerializedName(PRODUCT_NAME)
    @Field(PRODUCT_NAME)
    private String productName;

    @SerializedName(TIME_ZONE)
    @Field(TIME_ZONE)
    private String timeZone;

    @SerializedName(ADVERTISING_ID)
    @Field(ADVERTISING_ID)
    private String advertisingIdentifier;

    @SerializedName(CARRIER_COUNTRY_CODE)
    @Field(CARRIER_COUNTRY_CODE)
    private String carrierCountryCode;

    @SerializedName(CARRIER_NAME)
    @Field(CARRIER_NAME)
    private String carrierName;

    @SerializedName(CARRIER_NETWORK_CODE)
    @Field(CARRIER_NETWORK_CODE)
    private String carrierNetworkCode;

    @SerializedName(COUNTRY)
    @Field(COUNTRY)
    private String country;

    @SerializedName(DEV_DEVICE_MODEL)
    @Field(DEV_DEVICE_MODEL)
    private String developerDeviceModel;

    @SerializedName(DEVICE_MODEL)
    @Field(DEVICE_MODEL)
    private String deviceModel;

    @SerializedName(DEVICE_NAME)
    @Field(DEVICE_NAME)
    private String deviceName;

    @SerializedName(DEVICE_UUID)
    @Field(DEVICE_UUID)
    private String deviceUUID;

    @SerializedName(KERNEL_INFO)
    @Field(KERNEL_INFO)
    private String kernelInfo;

    @SerializedName(LOCALIZED_MODEL)
    @Field(LOCALIZED_MODEL)
    private String localizedModel;

    @SerializedName(NUM_OF_PROCESSORS)
    @Field(NUM_OF_PROCESSORS)
    private String numberOfProcessors;

    @SerializedName(OS_VERSION)
    @Field(OS_VERSION)
    private String oSVersion;

    @SerializedName(OS_VERSION_BUILD)
    @Field(OS_VERSION_BUILD)
    private String oSVersionBuild;

    @SerializedName(SCREEN_HEIGHT)
    @Field(SCREEN_HEIGHT)
    private String screenHeight;

    @SerializedName(SCREEN_WIDTH)
    @Field(SCREEN_WIDTH)
    private String screenWidth;

    @SerializedName(SYSTEM_MACH_NAME)
    @Field(SYSTEM_MACH_NAME)
    private String systemMachineName;

    @SerializedName(VENDOR_IDENTIFIER)
    @Field(VENDOR_IDENTIFIER)
    private String vendorIdentifier;

    @SerializedName(ANDROID_ID)
    @Field(ANDROID_ID)
    private String androidID;

    @SerializedName(BOARD)
    @Field(BOARD)
    private String board;

    @SerializedName(BOOT_LOADER)
    @Field(BOOT_LOADER)
    private String bootLoader;

    @SerializedName(BRAND)
    @Field(BRAND)
    private String brand;

    @SerializedName(CPU_ABIS)
    @Field(CPU_ABIS)
    private String cPUABIS;

    @SerializedName(CARRIER_NAME_OPERATOR)
    @Field(CARRIER_NAME_OPERATOR)
    private String carrierNameOprator;

    @SerializedName(CARRIER_SR_NUM)
    @Field(CARRIER_SR_NUM)
    private String carrierSerialNumber;

    @SerializedName(DPI)
    @Field(DPI)
    private String dPI;

    @SerializedName(DERIVE_FINGER_PRINT)
    @Field(DERIVE_FINGER_PRINT)
    private String deriveFingerPrint;

    @SerializedName(DEVICE)
    @Field(DEVICE)
    private String device;

    @SerializedName(DEVICE_TYPE)
    @Field(DEVICE_TYPE)
    private String deviceType;

    @SerializedName(DISPLAY)
    @Field(DISPLAY)
    private String display;

    @SerializedName(HARDWARE)
    @Field(HARDWARE)
    private String hardware;

    @SerializedName(HARDWARE_SR_NUM)
    @Field(HARDWARE_SR_NUM)
    private String hardwareSerialNumber;

    @SerializedName(DISK_DRIVE_SR_NUM)
    @Field(DISK_DRIVE_SR_NUM)
    private String diskDriveSerialNumber;

    @SerializedName(IMEI)
    @Field(IMEI)
    private String iMEI;

    @SerializedName(IMSI)
    @Field(IMSI)
    private String iMSI;

    @SerializedName(MODEL)
    @Field(MODEL)
    private String model;

    @SerializedName(NW_COUNTRY_ISO)
    @Field(NW_COUNTRY_ISO)
    private String networkCountryISO;

    @SerializedName(NW_OP)
    @Field(NW_OP)
    private String networkOperator;

    @SerializedName(NW_OP_NAME)
    @Field(NW_OP_NAME)
    private String networkOperatorName;

    @SerializedName(PHONE_NUM)
    @Field(PHONE_NUM)
    private String phoneNumber;

    @SerializedName(PRODUCT)
    @Field(PRODUCT)
    private String product;

    @SerializedName(RADIO)
    @Field(RADIO)
    private String radio;

    @SerializedName(SCREEN_SIZE)
    @Field(SCREEN_SIZE)
    private String screenSize;

    @SerializedName(TAGS)
    @Field(TAGS)
    private String tags;

    @SerializedName(TYPE)
    @Field(TYPE)
    private String type;

    @SerializedName(LATITUDE)
    @Field(LATITUDE)
    private String latitude;

    @SerializedName(LONGITUDE)
    @Field(LONGITUDE)
    private String longitude;

    @SerializedName(ALTITUDE)
    @Field(ALTITUDE)
    private String altitude;

    @SerializedName(APPNAME)
    @Field(APPNAME)
    private String appName;

    @SerializedName(APPVERSION)
    @Field(APPVERSION)
    private String appVersion;

    @SerializedName(PLATFORMUUID)
    @Field(PLATFORMUUID)
    private String platformUuid;

    @SerializedName(SMCVERSIONSYSTEM)
    @Field(SMCVERSIONSYSTEM)
    private String smcVersionSystem;

    @SerializedName(MACHINEMODEL)
    @Field(MACHINEMODEL)
    private String machineModel;

    @SerializedName(SERIALNUMBER)
    @Field(SERIALNUMBER)
    private String serialNumber;

    @SerializedName(PHYSICALMEMORY)
    @Field(PHYSICALMEMORY)
    private String physicalMemory;

    @SerializedName(LOCALIZEDNAME)
    @Field(LOCALIZEDNAME)
    private String localizedName;

    @SerializedName(PRIMARYMACADDRESS)
    @Field(PRIMARYMACADDRESS)
    private String primaryMACAddress;

    @SerializedName(MACHINENAME)
    @Field(MACHINENAME)
    private String machineName;

    @SerializedName(NUMBEROFCORES)
    @Field(NUMBEROFCORES)
    private String numberOfCores;

    @SerializedName(L2CACHECORE)
    @Field(L2CACHECORE)
    private String l2CacheCore;

    @SerializedName(BOOTROMVERSION)
    @Field(BOOTROMVERSION)
    private String bootRomVersion;

    @SerializedName(L3CACHE)
    @Field(L3CACHE)
    private String l3Cache;

    @SerializedName(CURRENTPROCESSORSPEED)
    @Field(CURRENTPROCESSORSPEED)
    private String currentProcessorSpeed;

    @SerializedName(PACKAGES)
    @Field(PACKAGES)
    private String packages;

    @SerializedName(CPUTYPE)
    @Field(CPUTYPE)
    private String cpuType;

    @SerializedName(CPUBRAND)
    @Field(CPUBRAND)
    private String cpuBrand;

    @SerializedName(OSBUILDNUMBER)
    @Field(OSBUILDNUMBER)
    private String osBuildNumber;

    @SerializedName(OSSERVICEPACK)
    @Field(OSSERVICEPACK)
    private String osServicePack;

    @SerializedName(ARCHITECTURE)
    @Field(ARCHITECTURE)
    private String architecture;

    @SerializedName(DNSDOMAIN)
    @Field(DNSDOMAIN)
    private String dnsDomain;

    @SerializedName(DNSHOSTNAME)
    @Field(DNSHOSTNAME)
    private String dnsHostname;

    @SerializedName(NETBIOS)
    @Field(NETBIOS)
    private String netBios;

    @SerializedName(PROCESSORSERIALNUMBER)
    @Field(PROCESSORSERIALNUMBER)
    private String processorSerialNumber;

    @SerializedName(PROCESSORINFO)
    @Field(PROCESSORINFO)
    private String processorInfo;

    @SerializedName(SSID)
    @Field(SSID)
    private String ssid;

    @SerializedName(BSSID)
    @Field(BSSID)
    private String bssid;

    @SerializedName(CS_DFP)
    @Field(CS_DFP)
    private String cs_dfp;

    @SerializedName(MANUFACTURER_FB)
    @Field(MANUFACTURER_FB)
    private String manufacturer_FB;

    @SerializedName(HARDWARE_SR_NUM_FB)
    @Field(HARDWARE_SR_NUM_FB)
    private String hardwareSerialNumber_FB;

    @SerializedName(DISK_DRIVE_SR_NUM_FB)
    @Field(DISK_DRIVE_SR_NUM_FB)
    private String diskDriveSerialNumber_FB;

    @SerializedName(OS_MAJOR)
    @Field(OS_MAJOR)
    private String osMajor;

    /**
     * @return the appIdentifier
     */
    public String getAppIdentifier() {
        return appIdentifier;
    }

    /**
     * @param appIdentifier
     *            the appIdentifier to set
     */
    public void setAppIdentifier(final String appIdentifier) {
        this.appIdentifier = appIdentifier;
    }

    /**
     * @return the audioAdapter
     */
    public String getAudioAdapter() {
        return audioAdapter;
    }

    /**
     * @param audioAdapter
     *            the audioAdapter to set
     */
    public void setAudioAdapter(final String audioAdapter) {
        this.audioAdapter = audioAdapter;
    }

    /**
     * @return the bios
     */
    public String getBios() {
        return bios;
    }

    /**
     * @param bios
     *            the bios to set
     */
    public void setBios(final String bios) {
        this.bios = bios;
    }

    /**
     * @return the broadbandDevID
     */
    public String getBroadbandDevID() {
        return broadbandDevID;
    }

    /**
     * @param broadbandDevID
     *            the broadbandDevID to set
     */
    public void setBroadbandDevID(final String broadbandDevID) {
        this.broadbandDevID = broadbandDevID;
    }

    /**
     * @return the btMacAddr
     */
    public String getBtMacAddr() {
        return btMacAddr;
    }

    /**
     * @param btMacAddr
     *            the btMacAddr to set
     */
    public void setBtMacAddr(final String btMacAddr) {
        this.btMacAddr = btMacAddr;
    }

    /**
     * @return the cpuId
     */
    public String getCpuId() {
        return cpuId;
    }

    /**
     * @param cpuId
     *            the cpuId to set
     */
    public void setCpuId(final String cpuId) {
        this.cpuId = cpuId;
    }

    /**
     * @return the diskSrNo
     */
    public String getDiskSrNo() {
        return diskSrNo;
    }

    /**
     * @param diskSrNo
     *            the diskSrNo to set
     */
    public void setDiskSrNo(final String diskSrNo) {
        this.diskSrNo = diskSrNo;
    }

    /**
     * @return the iPAddress
     */
    public String getiPAddress() {
        return iPAddress;
    }

    /**
     * @param iPAddress
     *            the iPAddress to set
     */
    public void setiPAddress(final String iPAddress) {
        this.iPAddress = iPAddress;
    }

    /**
     * @return the manufacturer
     */
    public String getManufacturer() {
        return manufacturer;
    }

    /**
     * @param manufacturer
     *            the manufacturer to set
     */
    public void setManufacturer(final String manufacturer) {
        this.manufacturer = manufacturer;
    }

    /**
     * @return the memory
     */
    public String getMemory() {
        return memory;
    }

    /**
     * @param memory
     *            the memory to set
     */
    public void setMemory(final String memory) {
        this.memory = memory;
    }

    /**
     * @return the nwMacAddr
     */
    public String getNwMacAddr() {
        return nwMacAddr;
    }

    /**
     * @param nwMacAddr
     *            the nwMacAddr to set
     */
    public void setNwMacAddr(final String nwMacAddr) {
        this.nwMacAddr = nwMacAddr;
    }

    /**
     * @return the platform
     */
    public String getPlatform() {
        return platform;
    }

    /**
     * @param platform
     *            the platform to set
     */
    public void setPlatform(final String platform) {
        this.platform = platform;
    }

    /**
     * @return the productName
     */
    public String getProductName() {
        return productName;
    }

    /**
     * @param productName
     *            the productName to set
     */
    public void setProductName(final String productName) {
        this.productName = productName;
    }

    /**
     * @return the timeZone
     */
    public String getTimeZone() {
        return timeZone;
    }

    /**
     * @param timeZone
     *            the timeZone to set
     */
    public void setTimeZone(final String timeZone) {
        this.timeZone = timeZone;
    }

    /**
     * @return the advertisingIdentifier
     */
    public String getAdvertisingIdentifier() {
        return advertisingIdentifier;
    }

    /**
     * @param advertisingIdentifier
     *            the advertisingIdentifier to set
     */
    public void setAdvertisingIdentifier(final String advertisingIdentifier) {
        this.advertisingIdentifier = advertisingIdentifier;
    }

    /**
     * @return the carrierCountryCode
     */
    public String getCarrierCountryCode() {
        return carrierCountryCode;
    }

    /**
     * @param carrierCountryCode
     *            the carrierCountryCode to set
     */
    public void setCarrierCountryCode(final String carrierCountryCode) {
        this.carrierCountryCode = carrierCountryCode;
    }

    /**
     * @return the carrierName
     */
    public String getCarrierName() {
        return carrierName;
    }

    /**
     * @param carrierName
     *            the carrierName to set
     */
    public void setCarrierName(final String carrierName) {
        this.carrierName = carrierName;
    }

    /**
     * @return the carrierNetworkCode
     */
    public String getCarrierNetworkCode() {
        return carrierNetworkCode;
    }

    /**
     * @param carrierNetworkCode
     *            the carrierNetworkCode to set
     */
    public void setCarrierNetworkCode(final String carrierNetworkCode) {
        this.carrierNetworkCode = carrierNetworkCode;
    }

    /**
     * @return the country
     */
    public String getCountry() {
        return country;
    }

    /**
     * @param country
     *            the country to set
     */
    public void setCountry(final String country) {
        this.country = country;
    }

    /**
     * @return the developerDeviceModel
     */
    public String getDeveloperDeviceModel() {
        return developerDeviceModel;
    }

    /**
     * @param developerDeviceModel
     *            the developerDeviceModel to set
     */
    public void setDeveloperDeviceModel(final String developerDeviceModel) {
        this.developerDeviceModel = developerDeviceModel;
    }

    /**
     * @return the deviceModel
     */
    public String getDeviceModel() {
        return deviceModel;
    }

    /**
     * @param deviceModel
     *            the deviceModel to set
     */
    public void setDeviceModel(final String deviceModel) {
        this.deviceModel = deviceModel;
    }

    /**
     * @return the deviceName
     */
    public String getDeviceName() {
        return deviceName;
    }

    /**
     * @param deviceName
     *            the deviceName to set
     */
    public void setDeviceName(final String deviceName) {
        this.deviceName = deviceName;
    }

    /**
     * @return the deviceUUID
     */
    public String getDeviceUUID() {
        return deviceUUID;
    }

    /**
     * @param deviceUUID
     *            the deviceUUID to set
     */
    public void setDeviceUUID(final String deviceUUID) {
        this.deviceUUID = deviceUUID;
    }

    /**
     * @return the kernelInfo
     */
    public String getKernelInfo() {
        return kernelInfo;
    }

    /**
     * @param kernelInfo
     *            the kernelInfo to set
     */
    public void setKernelInfo(final String kernelInfo) {
        this.kernelInfo = kernelInfo;
    }

    /**
     * @return the localizedModel
     */
    public String getLocalizedModel() {
        return localizedModel;
    }

    /**
     * @param localizedModel
     *            the localizedModel to set
     */
    public void setLocalizedModel(final String localizedModel) {
        this.localizedModel = localizedModel;
    }

    /**
     * @return the numberOfProcessors
     */
    public String getNumberOfProcessors() {
        return numberOfProcessors;
    }

    /**
     * @param numberOfProcessors
     *            the numberOfProcessors to set
     */
    public void setNumberOfProcessors(final String numberOfProcessors) {
        this.numberOfProcessors = numberOfProcessors;
    }

    /**
     * @return the oSVersion
     */
    public String getoSVersion() {
        return oSVersion;
    }

    /**
     * @param oSVersion
     *            the oSVersion to set
     */
    public void setoSVersion(final String oSVersion) {
        this.oSVersion = oSVersion;
    }

    /**
     * @return the oSVersionBuild
     */
    public String getoSVersionBuild() {
        return oSVersionBuild;
    }

    /**
     * @param oSVersionBuild
     *            the oSVersionBuild to set
     */
    public void setoSVersionBuild(final String oSVersionBuild) {
        this.oSVersionBuild = oSVersionBuild;
    }

    /**
     * @return the screenHeight
     */
    public String getScreenHeight() {
        return screenHeight;
    }

    /**
     * @param screenHeight
     *            the screenHeight to set
     */
    public void setScreenHeight(final String screenHeight) {
        this.screenHeight = screenHeight;
    }

    /**
     * @return the screenWidth
     */
    public String getScreenWidth() {
        return screenWidth;
    }

    /**
     * @param screenWidth
     *            the screenWidth to set
     */
    public void setScreenWidth(final String screenWidth) {
        this.screenWidth = screenWidth;
    }

    /**
     * @return the systemMachineName
     */
    public String getSystemMachineName() {
        return systemMachineName;
    }

    /**
     * @param systemMachineName
     *            the systemMachineName to set
     */
    public void setSystemMachineName(final String systemMachineName) {
        this.systemMachineName = systemMachineName;
    }

    /**
     * @return the vendorIdentifier
     */
    public String getVendorIdentifier() {
        return vendorIdentifier;
    }

    /**
     * @param vendorIdentifier
     *            the vendorIdentifier to set
     */
    public void setVendorIdentifier(final String vendorIdentifier) {
        this.vendorIdentifier = vendorIdentifier;
    }

    /**
     * @return the androidID
     */
    public String getAndroidID() {
        return androidID;
    }

    /**
     * @param androidID
     *            the androidID to set
     */
    public void setAndroidID(final String androidID) {
        this.androidID = androidID;
    }

    /**
     * @return the board
     */
    public String getBoard() {
        return board;
    }

    /**
     * @param board
     *            the board to set
     */
    public void setBoard(final String board) {
        this.board = board;
    }

    /**
     * @return the bootLoader
     */
    public String getBootLoader() {
        return bootLoader;
    }

    /**
     * @param bootLoader
     *            the bootLoader to set
     */
    public void setBootLoader(final String bootLoader) {
        this.bootLoader = bootLoader;
    }

    /**
     * @return the brand
     */
    public String getBrand() {
        return brand;
    }

    /**
     * @param brand
     *            the brand to set
     */
    public void setBrand(final String brand) {
        this.brand = brand;
    }

    /**
     * @return the cPUABIS
     */
    public String getcPUABIS() {
        return cPUABIS;
    }

    /**
     * @param cPUABIS
     *            the cPUABIS to set
     */
    public void setcPUABIS(final String cPUABIS) {
        this.cPUABIS = cPUABIS;
    }

    /**
     * @return the carrierNameOprator
     */
    public String getCarrierNameOprator() {
        return carrierNameOprator;
    }

    /**
     * @param carrierNameOprator
     *            the carrierNameOprator to set
     */
    public void setCarrierNameOprator(final String carrierNameOprator) {
        this.carrierNameOprator = carrierNameOprator;
    }

    /**
     * @return the carrierSerialNumber
     */
    public String getCarrierSerialNumber() {
        return carrierSerialNumber;
    }

    /**
     * @param carrierSerialNumber
     *            the carrierSerialNumber to set
     */
    public void setCarrierSerialNumber(final String carrierSerialNumber) {
        this.carrierSerialNumber = carrierSerialNumber;
    }

    /**
     * @return the dPI
     */
    public String getdPI() {
        return dPI;
    }

    /**
     * @param dPI
     *            the dPI to set
     */
    public void setdPI(final String dPI) {
        this.dPI = dPI;
    }

    /**
     * @return the deriveFingerPrint
     */
    public String getDeriveFingerPrint() {
        return deriveFingerPrint;
    }

    /**
     * @param deriveFingerPrint
     *            the deriveFingerPrint to set
     */
    public void setDeriveFingerPrint(final String deriveFingerPrint) {
        this.deriveFingerPrint = deriveFingerPrint;
    }

    /**
     * @return the device
     */
    public String getDevice() {
        return device;
    }

    /**
     * @param device
     *            the device to set
     */
    public void setDevice(final String device) {
        this.device = device;
    }

    /**
     * @return the deviceType
     */
    public String getDeviceType() {
        return deviceType;
    }

    /**
     * @param deviceType
     *            the deviceType to set
     */
    public void setDeviceType(final String deviceType) {
        this.deviceType = deviceType;
    }

    /**
     * @return the display
     */
    public String getDisplay() {
        return display;
    }

    /**
     * @param display
     *            the display to set
     */
    public void setDisplay(final String display) {
        this.display = display;
    }

    /**
     * @return the hardware
     */
    public String getHardware() {
        return hardware;
    }

    /**
     * @param hardware
     *            the hardware to set
     */
    public void setHardware(final String hardware) {
        this.hardware = hardware;
    }

    /**
     * @return the hardwareSerialNumber
     */
    public String getHardwareSerialNumber() {
        return hardwareSerialNumber;
    }

    /**
     * @param hardwareSerialNumber
     *            the hardwareSerialNumber to set
     */
    public void setHardwareSerialNumber(final String hardwareSerialNumber) {
        this.hardwareSerialNumber = hardwareSerialNumber;
    }

    /**
     * @return the diskDriveSerialNumber
     */
    public String getDiskDriveSerialNumber() {
        return diskDriveSerialNumber;
    }

    /**
     * @param diskDriveSerialNumber
     *            the diskDriveSerialNumber to set
     */
    public void setDiskDriveSerialNumber(final String diskDriveSerialNumber) {
        this.diskDriveSerialNumber = diskDriveSerialNumber;
    }

    /**
     * @return the iMEI
     */
    public String getiMEI() {
        return iMEI;
    }

    /**
     * @param iMEI
     *            the iMEI to set
     */
    public void setiMEI(final String iMEI) {
        this.iMEI = iMEI;
    }

    /**
     * @return the iMSI
     */
    public String getiMSI() {
        return iMSI;
    }

    /**
     * @param iMSI
     *            the iMSI to set
     */
    public void setiMSI(final String iMSI) {
        this.iMSI = iMSI;
    }

    /**
     * @return the model
     */
    public String getModel() {
        return model;
    }

    /**
     * @param model
     *            the model to set
     */
    public void setModel(final String model) {
        this.model = model;
    }

    /**
     * @return the networkCountryISO
     */
    public String getNetworkCountryISO() {
        return networkCountryISO;
    }

    /**
     * @param networkCountryISO
     *            the networkCountryISO to set
     */
    public void setNetworkCountryISO(final String networkCountryISO) {
        this.networkCountryISO = networkCountryISO;
    }

    /**
     * @return the networkOperator
     */
    public String getNetworkOperator() {
        return networkOperator;
    }

    /**
     * @param networkOperator
     *            the networkOperator to set
     */
    public void setNetworkOperator(final String networkOperator) {
        this.networkOperator = networkOperator;
    }

    /**
     * @return the networkOperatorName
     */
    public String getNetworkOperatorName() {
        return networkOperatorName;
    }

    /**
     * @param networkOperatorName
     *            the networkOperatorName to set
     */
    public void setNetworkOperatorName(final String networkOperatorName) {
        this.networkOperatorName = networkOperatorName;
    }

    /**
     * @return the phoneNumber
     */
    public String getPhoneNumber() {
        return phoneNumber;
    }

    /**
     * @param phoneNumber
     *            the phoneNumber to set
     */
    public void setPhoneNumber(final String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    /**
     * @return the product
     */
    public String getProduct() {
        return product;
    }

    /**
     * @param product
     *            the product to set
     */
    public void setProduct(final String product) {
        this.product = product;
    }

    /**
     * @return the radio
     */
    public String getRadio() {
        return radio;
    }

    /**
     * @param radio
     *            the radio to set
     */
    public void setRadio(final String radio) {
        this.radio = radio;
    }

    /**
     * @return the screenSize
     */
    public String getScreenSize() {
        return screenSize;
    }

    /**
     * @param screenSize
     *            the screenSize to set
     */
    public void setScreenSize(final String screenSize) {
        this.screenSize = screenSize;
    }

    /**
     * @return the tags
     */
    public String getTags() {
        return tags;
    }

    /**
     * @param tags
     *            the tags to set
     */
    public void setTags(final String tags) {
        this.tags = tags;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type
     *            the type to set
     */
    public void setType(final String type) {
        this.type = type;
    }

    /**
     * @return the latitude
     */
    public String getLatitude() {
        return latitude;
    }

    /**
     * @param latitude
     *            the latitude to set
     */
    public void setLatitude(final String latitude) {
        this.latitude = latitude;
    }

    /**
     * @return the longitude
     */
    public String getLongitude() {
        return longitude;
    }

    /**
     * @param longitude
     *            the longitude to set
     */
    public void setLongitude(final String longitude) {
        this.longitude = longitude;
    }

    /**
     * @return the altitude
     */
    public String getAltitude() {
        return altitude;
    }

    /**
     * @param altitude
     *            the altitude to set
     */
    public void setAltitude(final String altitude) {
        this.altitude = altitude;
    }

    /**
     * @return the appName
     */
    public String getAppName() {
        return appName;
    }

    /**
     * @param appName
     *            the appName to set
     */
    public void setAppName(final String appName) {
        this.appName = appName;
    }

    /**
     * @return the appVersion
     */
    public String getAppVersion() {
        return appVersion;
    }

    /**
     * @param appVersion
     *            the appVersion to set
     */
    public void setAppVersion(final String appVersion) {
        this.appVersion = appVersion;
    }

    /**
     * @return the platformUuid
     */
    public String getPlatformUuid() {
        return platformUuid;
    }

    /**
     * @param platformUuid
     *            the platformUuid to set
     */
    public void setPlatformUuid(final String platformUuid) {
        this.platformUuid = platformUuid;
    }

    /**
     * @return the smcVersionSystem
     */
    public String getSmcVersionSystem() {
        return smcVersionSystem;
    }

    /**
     * @param smcVersionSystem
     *            the smcVersionSystem to set
     */
    public void setSmcVersionSystem(final String smcVersionSystem) {
        this.smcVersionSystem = smcVersionSystem;
    }

    /**
     * @return the machineModel
     */
    public String getMachineModel() {
        return machineModel;
    }

    /**
     * @param machineModel
     *            the machineModel to set
     */
    public void setMachineModel(final String machineModel) {
        this.machineModel = machineModel;
    }

    /**
     * @return the serialNumber
     */
    public String getSerialNumber() {
        return serialNumber;
    }

    /**
     * @param serialNumber
     *            the serialNumber to set
     */
    public void setSerialNumber(final String serialNumber) {
        this.serialNumber = serialNumber;
    }

    /**
     * @return the physicalMemory
     */
    public String getPhysicalMemory() {
        return physicalMemory;
    }

    /**
     * @param physicalMemory
     *            the physicalMemory to set
     */
    public void setPhysicalMemory(final String physicalMemory) {
        this.physicalMemory = physicalMemory;
    }

    /**
     * @return the localizedName
     */
    public String getLocalizedName() {
        return localizedName;
    }

    /**
     * @param localizedName
     *            the localizedName to set
     */
    public void setLocalizedName(final String localizedName) {
        this.localizedName = localizedName;
    }

    /**
     * @return the primaryMACAddress
     */
    public String getPrimaryMACAddress() {
        return primaryMACAddress;
    }

    /**
     * @param primaryMACAddress
     *            the primaryMACAddress to set
     */
    public void setPrimaryMACAddress(final String primaryMACAddress) {
        this.primaryMACAddress = primaryMACAddress;
    }

    /**
     * @return the machineName
     */
    public String getMachineName() {
        return machineName;
    }

    /**
     * @param machineName
     *            the machineName to set
     */
    public void setMachineName(final String machineName) {
        this.machineName = machineName;
    }

    /**
     * @return the numberOfCores
     */
    public String getNumberOfCores() {
        return numberOfCores;
    }

    /**
     * @param numberOfCores
     *            the numberOfCores to set
     */
    public void setNumberOfCores(final String numberOfCores) {
        this.numberOfCores = numberOfCores;
    }

    /**
     * @return the l2CacheCore
     */
    public String getL2CacheCore() {
        return l2CacheCore;
    }

    /**
     * @param l2CacheCore
     *            the l2CacheCore to set
     */
    public void setL2CacheCore(final String l2CacheCore) {
        this.l2CacheCore = l2CacheCore;
    }

    /**
     * @return the bootRomVersion
     */
    public String getBootRomVersion() {
        return bootRomVersion;
    }

    /**
     * @param bootRomVersion
     *            the bootRomVersion to set
     */
    public void setBootRomVersion(final String bootRomVersion) {
        this.bootRomVersion = bootRomVersion;
    }

    /**
     * @return the l3Cache
     */
    public String getL3Cache() {
        return l3Cache;
    }

    /**
     * @param l3Cache
     *            the l3Cache to set
     */
    public void setL3Cache(final String l3Cache) {
        this.l3Cache = l3Cache;
    }

    /**
     * @return the currentProcessorSpeed
     */
    public String getCurrentProcessorSpeed() {
        return currentProcessorSpeed;
    }

    /**
     * @param currentProcessorSpeed
     *            the currentProcessorSpeed to set
     */
    public void setCurrentProcessorSpeed(final String currentProcessorSpeed) {
        this.currentProcessorSpeed = currentProcessorSpeed;
    }

    /**
     * @return the packages
     */
    public String getPackages() {
        return packages;
    }

    /**
     * @param packages
     *            the packages to set
     */
    public void setPackages(final String packages) {
        this.packages = packages;
    }

    /**
     * @return the cpuType
     */
    public String getCpuType() {
        return cpuType;
    }

    /**
     * @param cpuType
     *            the cpuType to set
     */
    public void setCpuType(final String cpuType) {
        this.cpuType = cpuType;
    }

    /**
     * @return the cpuBrand
     */
    public String getCpuBrand() {
        return cpuBrand;
    }

    /**
     * @param cpuBrand
     *            the cpuBrand to set
     */
    public void setCpuBrand(final String cpuBrand) {
        this.cpuBrand = cpuBrand;
    }

    /**
     * @return the osBuildNumber
     */
    public String getOsBuildNumber() {
        return osBuildNumber;
    }

    /**
     * @param osBuildNumber
     *            the osBuildNumber to set
     */
    public void setOsBuildNumber(final String osBuildNumber) {
        this.osBuildNumber = osBuildNumber;
    }

    /**
     * @return the osServicePack
     */
    public String getOsServicePack() {
        return osServicePack;
    }

    /**
     * @param osServicePack
     *            the osServicePack to set
     */
    public void setOsServicePack(final String osServicePack) {
        this.osServicePack = osServicePack;
    }

    /**
     * @return the architecture
     */
    public String getArchitecture() {
        return architecture;
    }

    /**
     * @param architecture
     *            the architecture to set
     */
    public void setArchitecture(final String architecture) {
        this.architecture = architecture;
    }

    /**
     * @return the dnsDomain
     */
    public String getDnsDomain() {
        return dnsDomain;
    }

    /**
     * @param dnsDomain
     *            the dnsDomain to set
     */
    public void setDnsDomain(final String dnsDomain) {
        this.dnsDomain = dnsDomain;
    }

    /**
     * @return the dnsHostname
     */
    public String getDnsHostname() {
        return dnsHostname;
    }

    /**
     * @param dnsHostname
     *            the dnsHostname to set
     */
    public void setDnsHostname(final String dnsHostname) {
        this.dnsHostname = dnsHostname;
    }

    /**
     * @return the netBios
     */
    public String getNetBios() {
        return netBios;
    }

    /**
     * @param netBios
     *            the netBios to set
     */
    public void setNetBios(final String netBios) {
        this.netBios = netBios;
    }

    /**
     * @return the processorSerialNumber
     */
    public String getProcessorSerialNumber() {
        return processorSerialNumber;
    }

    /**
     * @param processorSerialNumber
     *            the processorSerialNumber to set
     */
    public void setProcessorSerialNumber(final String processorSerialNumber) {
        this.processorSerialNumber = processorSerialNumber;
    }

    /**
     * @return the processorInfo
     */
    public String getProcessorInfo() {
        return processorInfo;
    }

    /**
     * @param processorInfo
     *            the processorInfo to set
     */
    public void setProcessorInfo(final String processorInfo) {
        this.processorInfo = processorInfo;
    }

    /**
     * @return the ssid
     */
    public String getSsid() {
        return ssid;
    }

    /**
     * @param ssid
     *            the ssid to set
     */
    public void setSsid(final String ssid) {
        this.ssid = ssid;
    }

    /**
     * @return the bssid
     */
    public String getBssid() {
        return bssid;
    }

    /**
     * @param bssid
     *            the bssid to set
     */
    public void setBssid(final String bssid) {
        this.bssid = bssid;
    }

    public String getCsDfp() {
        return cs_dfp;
    }

    public void setCsDfp(final String csDfp) {
        this.cs_dfp = csDfp;
    }

    /**
     * @return the manufacturer_FB
     */
    public String getManufacturer_FB() {
        return manufacturer_FB;
    }

    /**
     * @param manufacturer_FB
     *            the manufacturer_FB to set
     */
    public void setManufacturer_FB(final String manufacturer_FB) {
        this.manufacturer_FB = manufacturer_FB;
    }

    /**
     * @return the hardwareSerialNumber_FB
     */
    public String getHardwareSerialNumber_FB() {
        return hardwareSerialNumber_FB;
    }

    /**
     * @param hardwareSerialNumber_FB
     *            the hardwareSerialNumber_FB to set
     */
    public void setHardwareSerialNumber_FB(final String hardwareSerialNumber_FB) {
        this.hardwareSerialNumber_FB = hardwareSerialNumber_FB;
    }

    /**
     * @return the diskDriveSerialNumber_FB
     */
    public String getDiskDriveSerialNumber_FB() {
        return diskDriveSerialNumber_FB;
    }

    /**
     * @param diskDriveSerialNumber_FB
     *            the diskDriveSerialNumber_FB to set
     */
    public void setDiskDriveSerialNumber_FB(final String diskDriveSerialNumber_FB) {
        this.diskDriveSerialNumber_FB = diskDriveSerialNumber_FB;
    }

    /**
     * @return the osMajor
     */
    public String getOsMajor() {
        return osMajor;
    }

    /**
     * @param osMajor
     *            the osMajor to set
     */
    public void setOsMajor(final String osMajor) {
        this.osMajor = osMajor;
    }

    private String base64decode(final String encodedValue) {
        // return new String(Base64.getDecoder().decode(encodedValue));
        return encodedValue;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("DfpParameters [");
        if (null != platform)
            builder.append("platform=").append(base64decode(platform));
        if (null != appIdentifier)
            builder.append(", appIdentifier=").append(base64decode(appIdentifier));
        if (null != audioAdapter)
            builder.append(", audioAdapter=").append(base64decode(audioAdapter));
        if (null != bios)
            builder.append(", bios=").append(base64decode(bios));
        if (null != broadbandDevID)
            builder.append(", broadbandDevID=").append(base64decode(broadbandDevID));
        if (null != btMacAddr)
            builder.append(", btMacAddr=").append(base64decode(btMacAddr));
        if (null != cpuId)
            builder.append(", cpuId=").append(base64decode(cpuId));
        if (null != diskSrNo)
            builder.append(", diskSrNo=").append(base64decode(diskSrNo));
        if (null != iPAddress)
            builder.append(", iPAddress=").append(base64decode(iPAddress));
        if (null != manufacturer)
            builder.append(", manufacturer=").append(base64decode(manufacturer));
        if (null != memory)
            builder.append(", memory=").append(base64decode(memory));
        if (null != nwMacAddr)
            builder.append(", nwMacAddr=").append(base64decode(nwMacAddr));
        if (null != productName)
            builder.append(", productName=").append(base64decode(productName));
        if (null != timeZone)
            builder.append(", timeZone=").append(base64decode(timeZone));
        if (null != advertisingIdentifier)
            builder.append(", advertisingIdentifier=").append(base64decode(advertisingIdentifier));
        if (null != carrierCountryCode)
            builder.append(", carrierCountryCode=").append(base64decode(carrierCountryCode));
        if (null != carrierName)
            builder.append(", carrierName=").append(base64decode(carrierName));
        if (null != carrierNetworkCode)
            builder.append(", carrierNetworkCode=").append(base64decode(carrierNetworkCode));
        if (null != country)
            builder.append(", country=").append(base64decode(country));
        if (null != developerDeviceModel)
            builder.append(", developerDeviceModel=").append(base64decode(developerDeviceModel));
        if (null != deviceModel)
            builder.append(", deviceModel=").append(base64decode(deviceModel));
        if (null != deviceName)
            builder.append(", deviceName=").append(base64decode(deviceName));
        if (null != deviceUUID)
            builder.append(", deviceUUID=").append(base64decode(deviceUUID));
        if (null != kernelInfo)
            builder.append(", kernelInfo=").append(base64decode(kernelInfo));
        if (null != localizedModel)
            builder.append(", localizedModel=").append(base64decode(localizedModel));
        if (null != numberOfProcessors)
            builder.append(", numberOfProcessors=").append(base64decode(numberOfProcessors));
        if (null != oSVersion)
            builder.append(", oSVersion=").append(base64decode(oSVersion));
        if (null != oSVersionBuild)
            builder.append(", oSVersionBuild=").append(base64decode(oSVersionBuild));
        if (null != screenHeight)
            builder.append(", screenHeight=").append(base64decode(screenHeight));
        if (null != screenWidth)
            builder.append(", screenWidth=").append(base64decode(screenWidth));
        if (null != systemMachineName)
            builder.append(", systemMachineName=").append(base64decode(systemMachineName));
        if (null != vendorIdentifier)
            builder.append(", vendorIdentifier=").append(base64decode(vendorIdentifier));
        if (null != androidID)
            builder.append(", androidID=").append(base64decode(androidID));
        if (null != board)
            builder.append(", board=").append(base64decode(board));
        if (null != bootLoader)
            builder.append(", bootLoader=").append(base64decode(bootLoader));
        if (null != brand)
            builder.append(", brand=").append(base64decode(brand));
        if (null != cPUABIS)
            builder.append(", cPUABIS=").append(base64decode(cPUABIS));
        if (null != carrierNameOprator)
            builder.append(", carrierNameOprator=").append(base64decode(carrierNameOprator));
        if (null != carrierSerialNumber)
            builder.append(", carrierSerialNumber=").append(base64decode(carrierSerialNumber));
        if (null != dPI)
            builder.append(", dPI=").append(base64decode(dPI));
        if (null != deriveFingerPrint)
            builder.append(", deriveFingerPrint=").append(base64decode(deriveFingerPrint));
        if (null != device)
            builder.append(", device=").append(base64decode(device));
        if (null != deviceType)
            builder.append(", deviceType=").append(base64decode(deviceType));
        if (null != display)
            builder.append(", display=").append(base64decode(display));
        if (null != hardware)
            builder.append(", hardware=").append(base64decode(hardware));
        if (null != hardwareSerialNumber)
            builder.append(", hardwareSerialNumber=").append(base64decode(hardwareSerialNumber));
        if (null != diskDriveSerialNumber)
            builder.append(", diskDriveSerialNumber=").append(base64decode(diskDriveSerialNumber));
        if (null != iMEI)
            builder.append(", iMEI=").append(base64decode(iMEI));
        if (null != iMSI)
            builder.append(", iMSI=").append(base64decode(iMSI));
        if (null != model)
            builder.append(", model=").append(base64decode(model));
        if (null != networkCountryISO)
            builder.append(", networkCountryISO=").append(base64decode(networkCountryISO));
        if (null != networkOperator)
            builder.append(", networkOperator=").append(base64decode(networkOperator));
        if (null != networkOperatorName)
            builder.append(", networkOperatorName=").append(base64decode(networkOperatorName));
        if (null != phoneNumber)
            builder.append(", phoneNumber=").append(base64decode(phoneNumber));
        if (null != product)
            builder.append(", product=").append(base64decode(product));
        if (null != radio)
            builder.append(", radio=").append(base64decode(radio));
        if (null != screenSize)
            builder.append(", screenSize=").append(base64decode(screenSize));
        if (null != tags)
            builder.append(", tags=").append(base64decode(tags));
        if (null != type)
            builder.append(", type=").append(base64decode(type));
        if (null != latitude)
            builder.append(", latitude=").append(base64decode(latitude));
        if (null != longitude)
            builder.append(", longitude=").append(base64decode(longitude));
        if (null != altitude)
            builder.append(", altitude=").append(base64decode(altitude));
        if (null != appName)
            builder.append(", appName=").append(base64decode(appName));
        if (null != appVersion)
            builder.append(", appVersion=").append(base64decode(appVersion));
        if (null != platformUuid)
            builder.append(", platformUuid=").append(base64decode(platformUuid));
        if (null != smcVersionSystem)
            builder.append(", smcVersionSystem=").append(base64decode(smcVersionSystem));
        if (null != machineModel)
            builder.append(", machineModel=").append(base64decode(machineModel));
        if (null != serialNumber)
            builder.append(", serialNumber=").append(base64decode(serialNumber));
        if (null != physicalMemory)
            builder.append(", physicalMemory=").append(base64decode(physicalMemory));
        if (null != localizedName)
            builder.append(", localizedName=").append(base64decode(localizedName));
        if (null != primaryMACAddress)
            builder.append(", primaryMACAddress=").append(base64decode(primaryMACAddress));
        if (null != machineName)
            builder.append(", machineName=").append(base64decode(machineName));
        if (null != numberOfCores)
            builder.append(", numberOfCores=").append(base64decode(numberOfCores));
        if (null != l2CacheCore)
            builder.append(", l2CacheCore=").append(base64decode(l2CacheCore));
        if (null != bootRomVersion)
            builder.append(", bootRomVersion=").append(base64decode(bootRomVersion));
        if (null != l3Cache)
            builder.append(", l3Cache=").append(base64decode(l3Cache));
        if (null != currentProcessorSpeed)
            builder.append(", currentProcessorSpeed=").append(base64decode(currentProcessorSpeed));
        if (null != packages)
            builder.append(", packages=").append(base64decode(packages));
        if (null != cpuType)
            builder.append(", cpuType=").append(base64decode(cpuType));
        if (null != cpuBrand)
            builder.append(", cpuBrand=").append(base64decode(cpuBrand));
        if (null != osBuildNumber)
            builder.append(", osBuildNumber=").append(base64decode(osBuildNumber));
        if (null != osServicePack)
            builder.append(", osServicePack=").append(base64decode(osServicePack));
        if (null != architecture)
            builder.append(", architecture=").append(base64decode(architecture));
        if (null != dnsDomain)
            builder.append(", dnsDomain=").append(base64decode(dnsDomain));
        if (null != dnsHostname)
            builder.append(", dnsHostname=").append(base64decode(dnsHostname));
        if (null != netBios)
            builder.append(", netBios=").append(base64decode(netBios));
        if (null != processorSerialNumber)
            builder.append(", processorSerialNumber=").append(base64decode(processorSerialNumber));
        if (null != processorInfo)
            builder.append(", processorInfo=").append(base64decode(processorInfo));
        if (null != ssid)
            builder.append(", SSID=").append(base64decode(ssid));
        if (null != bssid)
            builder.append(", BSSID=").append(base64decode(bssid));
        if (null != cs_dfp)
            builder.append(", cs_dfp=").append(base64decode(cs_dfp));
        if (null != manufacturer_FB)
            builder.append(", manufacturer_FB=").append(manufacturer_FB);
        if (null != hardwareSerialNumber_FB)
            builder.append(", hardwareSerialNumber_FB=").append(hardwareSerialNumber_FB);
        if (null != diskDriveSerialNumber_FB)
            builder.append(", diskDriveSerialNumber_FB=").append(diskDriveSerialNumber_FB);
        if (null != osMajor)
            builder.append(", osMajor=").append(osMajor);
        builder.append("]");
        /*
         * builder.append("DfpParameters [appIdentifier=").append(appIdentifier)
         * .append(", audioAdapter=")
         * .append(audioAdapter).append(", bios=").append(bios).
         * append(", broadbandDevID=").append(broadbandDevID)
         * .append(", btMacAddr=").append(btMacAddr).append(", cpuId=").append(
         * cpuId).append(", diskSrNo=")
         * .append(diskSrNo).append(", iPAddress=").append(iPAddress).
         * append(", manufacturer=")
         * .append(manufacturer).append(", memory=").append(memory).
         * append(", nwMacAddr=").append(nwMacAddr)
         * .append(", platform=").append(platform).append(", productName=").
         * append(productName) .append(", timeZone=").append(timeZone).
         * append(", advertisingIdentifier=").append(advertisingIdentifier)
         * .append(", carrierCountryCode=").append(carrierCountryCode).
         * append(", carrierName=").append(carrierName)
         * .append(", carrierNetworkCode=").append(carrierNetworkCode).
         * append(", country=").append(country)
         * .append(", developerDeviceModel=").append(developerDeviceModel).
         * append(", deviceModel=")
         * .append(deviceModel).append(", deviceName=").append(deviceName).
         * append(", deviceUUID=")
         * .append(deviceUUID).append(", kernelInfo=").append(kernelInfo).
         * append(", localizedModel=")
         * .append(localizedModel).append(", numberOfProcessors=").append(
         * numberOfProcessors)
         * .append(", oSVersion=").append(oSVersion).append(", oSVersionBuild=")
         * .append(oSVersionBuild)
         * .append(", screenHeight=").append(screenHeight).
         * append(", screenWidth=").append(screenWidth)
         * .append(", systemMachineName=").append(systemMachineName).
         * append(", vendorIdentifier=")
         * .append(vendorIdentifier).append(", androidID=").append(androidID).
         * append(", board=").append(board)
         * .append(", bootLoader=").append(bootLoader).append(", brand=").append
         * (brand).append(", cPUABIS=")
         * .append(cPUABIS).append(", carrierNameOprator=").append(
         * carrierNameOprator)
         * .append(", carrierSerialNumber=").append(carrierSerialNumber).
         * append(", dPI=").append(dPI)
         * .append(", deriveFingerPrint=").append(deriveFingerPrint).
         * append(", device=").append(device)
         * .append(", deviceType=").append(deviceType).append(", display=").
         * append(display).append(", hardware=")
         * .append(hardware).append(", hardwareSerialNumber=").append(
         * hardwareSerialNumber).append(", iMEI=")
         * .append(iMEI).append(", iMSI=").append(iMSI).append(", model=").
         * append(model)
         * .append(", networkCountryISO=").append(networkCountryISO).
         * append(", networkOperator=")
         * .append(networkOperator).append(", networkOperatorName=").append(
         * networkOperatorName)
         * .append(", phoneNumber=").append(phoneNumber).append(", product=").
         * append(product).append(", radio=")
         * .append(radio).append(", screenSize=").append(screenSize).
         * append(", tags=").append(tags)
         * .append(", type=").append(type).append(", latitude=").append(latitude
         * ).append(", longitude=")
         * .append(longitude).append(", altitude=").append(altitude).
         * append(", appName=").append(appName)
         * .append(", appVersion=").append(appVersion).append(", platformUuid=")
         * .append(platformUuid)
         * .append(", smcVersionSystem=").append(smcVersionSystem).
         * append(", machineModel=").append(machineModel)
         * .append(", serialNumber=").append(serialNumber).
         * append(", physicalMemory=").append(physicalMemory)
         * .append(", localizedName=").append(localizedName).
         * append(", primaryMACAddress=")
         * .append(primaryMACAddress).append(", machineName=").append(
         * machineName).append(", numberOfCores=")
         * .append(numberOfCores).append(", l2CacheCore=").append(l2CacheCore).
         * append(", bootRomVersion=")
         * .append(bootRomVersion).append(", l3Cache=").append(l3Cache).
         * append(", currentProcessorSpeed=")
         * .append(currentProcessorSpeed).append(", packages=").append(packages)
         * .append(", cpuType=")
         * .append(cpuType).append(", cpuBrand=").append(cpuBrand).
         * append(", osBuildNumber=").append(osBuildNumber)
         * .append(", osServicePack=").append(osServicePack).
         * append(", architecture=").append(architecture)
         * .append(", dnsDomain=").append(dnsDomain).append(", dnsHostname=").
         * append(dnsHostname) .append(", netBios=").append(netBios).
         * append(", processorSerialNumber=").append(processorSerialNumber)
         * .append(", processorInfo=").append(processorInfo).append(", SSID=").
         * append(ssid).append(", BSSID=")
         * .append(bssid).append(", cs_dfp").append(cs_dfp)..append("]");
         */
        return builder.toString();
    }

    /**
     * Create Bson Document document from the provided DFPParameters object
     * 
     * @param dfpParameters
     *            DFPParameters to be converted to a Bson Document
     * @return A Bson document
     */
    public static Document getBsonDocument(final DfpParameters dfpParameters) {

        final Document dfpPraramDoc = new Document();

        if (dfpParameters.getAppIdentifier() != null) {
            dfpPraramDoc.append(DfpParameters.APP_IDENTIFIER, dfpParameters.getAppIdentifier());
        }

        if (dfpParameters.getAudioAdapter() != null) {
            dfpPraramDoc.append(DfpParameters.AUDIO_ADAPTER, dfpParameters.getAudioAdapter());
        }

        if (dfpParameters.getBios() != null) {
            dfpPraramDoc.append(DfpParameters.BIOS, dfpParameters.getBios());
        }

        if (dfpParameters.getBroadbandDevID() != null) {
            dfpPraramDoc.append(DfpParameters.BROADBAND_DEVID, dfpParameters.getBroadbandDevID());
        }

        if (dfpParameters.getBtMacAddr() != null) {
            dfpPraramDoc.append(DfpParameters.BT_MAC_ADDRESS, dfpParameters.getBtMacAddr());
        }

        if (dfpParameters.getCpuId() != null) {
            dfpPraramDoc.append(DfpParameters.CPU_ID, dfpParameters.getCpuId());
        }

        if (dfpParameters.getDiskSrNo() != null) {
            dfpPraramDoc.append(DfpParameters.DISK_SR_NO, dfpParameters.getDiskSrNo());
        }

        if (dfpParameters.getiPAddress() != null) {
            dfpPraramDoc.append(DfpParameters.IP_ADDRESS, dfpParameters.getiPAddress());
        }

        if (dfpParameters.getManufacturer() != null) {
            dfpPraramDoc.append(DfpParameters.MANUFACTURER, dfpParameters.getManufacturer());
        }

        if (dfpParameters.getMemory() != null) {
            dfpPraramDoc.append(DfpParameters.MEMORY, dfpParameters.getMemory());
        }

        if (dfpParameters.getNwMacAddr() != null) {
            dfpPraramDoc.append(DfpParameters.NW_MAC_ADDRESS, dfpParameters.getNwMacAddr());
        }

        if (dfpParameters.getPlatform() != null) {
            dfpPraramDoc.append(DfpParameters.PLATFORM, dfpParameters.getPlatform());
        }

        if (dfpParameters.getProductName() != null) {
            dfpPraramDoc.append(DfpParameters.PRODUCT_NAME, dfpParameters.getProductName());
        }

        if (dfpParameters.getTimeZone() != null) {
            dfpPraramDoc.append(DfpParameters.TIME_ZONE, dfpParameters.getTimeZone());
        }

        if (dfpParameters.getAdvertisingIdentifier() != null) {
            dfpPraramDoc.append(DfpParameters.ADVERTISING_ID, dfpParameters.getAdvertisingIdentifier());
        }

        if (dfpParameters.getCarrierCountryCode() != null) {
            dfpPraramDoc.append(DfpParameters.CARRIER_COUNTRY_CODE, dfpParameters.getCarrierCountryCode());
        }

        if (dfpParameters.getCarrierName() != null) {
            dfpPraramDoc.append(DfpParameters.CARRIER_NAME, dfpParameters.getCarrierName());
        }

        if (dfpParameters.getCarrierNetworkCode() != null) {
            dfpPraramDoc.append(DfpParameters.CARRIER_NETWORK_CODE, dfpParameters.getCarrierNetworkCode());
        }

        if (dfpParameters.getCountry() != null) {
            dfpPraramDoc.append(DfpParameters.COUNTRY, dfpParameters.getCountry());
        }

        if (dfpParameters.getDeveloperDeviceModel() != null) {
            dfpPraramDoc.append(DfpParameters.DEV_DEVICE_MODEL, dfpParameters.getDeveloperDeviceModel());
        }

        if (dfpParameters.getDeviceModel() != null) {
            dfpPraramDoc.append(DfpParameters.DEVICE_MODEL, dfpParameters.getDeviceModel());
        }

        if (dfpParameters.getDeviceName() != null) {
            dfpPraramDoc.append(DfpParameters.DEVICE_NAME, dfpParameters.getDeviceName());
        }

        if (dfpParameters.getDeviceUUID() != null) {
            dfpPraramDoc.append(DfpParameters.DEVICE_UUID, dfpParameters.getDeviceUUID());
        }

        if (dfpParameters.getKernelInfo() != null) {
            dfpPraramDoc.append(DfpParameters.KERNEL_INFO, dfpParameters.getKernelInfo());
        }

        if (dfpParameters.getLocalizedModel() != null) {
            dfpPraramDoc.append(DfpParameters.LOCALIZED_MODEL, dfpParameters.getLocalizedModel());
        }

        if (dfpParameters.getNumberOfProcessors() != null) {
            dfpPraramDoc.append(DfpParameters.NUM_OF_PROCESSORS, dfpParameters.getNumberOfProcessors());
        }

        if (dfpParameters.getoSVersion() != null) {
            dfpPraramDoc.append(DfpParameters.OS_VERSION, dfpParameters.getoSVersion());
        }

        if (dfpParameters.getoSVersionBuild() != null) {
            dfpPraramDoc.append(DfpParameters.OS_VERSION_BUILD, dfpParameters.getoSVersionBuild());
        }

        if (dfpParameters.getScreenHeight() != null) {
            dfpPraramDoc.append(DfpParameters.SCREEN_HEIGHT, dfpParameters.getScreenHeight());
        }

        if (dfpParameters.getScreenWidth() != null) {
            dfpPraramDoc.append(DfpParameters.SCREEN_WIDTH, dfpParameters.getScreenWidth());
        }

        if (dfpParameters.getSystemMachineName() != null) {
            dfpPraramDoc.append(DfpParameters.SYSTEM_MACH_NAME, dfpParameters.getSystemMachineName());
        }

        if (dfpParameters.getVendorIdentifier() != null) {
            dfpPraramDoc.append(DfpParameters.VENDOR_IDENTIFIER, dfpParameters.getVendorIdentifier());
        }

        if (dfpParameters.getAndroidID() != null) {
            dfpPraramDoc.append(DfpParameters.ANDROID_ID, dfpParameters.getAndroidID());
        }

        if (dfpParameters.getBoard() != null) {
            dfpPraramDoc.append(DfpParameters.BOARD, dfpParameters.getBoard());
        }

        if (dfpParameters.getBootLoader() != null) {
            dfpPraramDoc.append(DfpParameters.BOOT_LOADER, dfpParameters.getBootLoader());
        }

        if (dfpParameters.getBrand() != null) {
            dfpPraramDoc.append(DfpParameters.BRAND, dfpParameters.getBrand());
        }

        if (dfpParameters.getcPUABIS() != null) {
            dfpPraramDoc.append(DfpParameters.CPU_ABIS, dfpParameters.getcPUABIS());
        }

        if (dfpParameters.getCarrierNameOprator() != null) {
            dfpPraramDoc.append(DfpParameters.CARRIER_NAME_OPERATOR, dfpParameters.getCarrierNameOprator());
        }

        if (dfpParameters.getCarrierSerialNumber() != null) {
            dfpPraramDoc.append(DfpParameters.CARRIER_SR_NUM, dfpParameters.getCarrierSerialNumber());
        }

        if (dfpParameters.getdPI() != null) {
            dfpPraramDoc.append(DfpParameters.DPI, dfpParameters.getdPI());
        }

        if (dfpParameters.getDeriveFingerPrint() != null) {
            dfpPraramDoc.append(DfpParameters.DERIVE_FINGER_PRINT, dfpParameters.getDeriveFingerPrint());
        }

        if (dfpParameters.getDevice() != null) {
            dfpPraramDoc.append(DfpParameters.DEVICE, dfpParameters.getDevice());
        }

        if (dfpParameters.getDeviceType() != null) {
            dfpPraramDoc.append(DfpParameters.DEVICE_TYPE, dfpParameters.getDeviceType());
        }

        if (dfpParameters.getDisplay() != null) {
            dfpPraramDoc.append(DfpParameters.DISPLAY, dfpParameters.getDisplay());
        }

        if (dfpParameters.getHardware() != null) {
            dfpPraramDoc.append(DfpParameters.HARDWARE, dfpParameters.getHardware());
        }

        if (dfpParameters.getHardwareSerialNumber() != null) {
            dfpPraramDoc.append(DfpParameters.HARDWARE_SR_NUM, dfpParameters.getHardwareSerialNumber());
        }

        if (dfpParameters.getDiskDriveSerialNumber() != null) {
            dfpPraramDoc.append(DfpParameters.DISK_DRIVE_SR_NUM, dfpParameters.getDiskDriveSerialNumber());
        }

        if (dfpParameters.getiMEI() != null) {
            dfpPraramDoc.append(DfpParameters.IMEI, dfpParameters.getiMEI());
        }

        if (dfpParameters.getiMSI() != null) {
            dfpPraramDoc.append(DfpParameters.IMSI, dfpParameters.getiMSI());
        }

        if (dfpParameters.getModel() != null) {
            dfpPraramDoc.append(DfpParameters.MODEL, dfpParameters.getModel());
        }

        if (dfpParameters.getNetworkCountryISO() != null) {
            dfpPraramDoc.append(DfpParameters.NW_COUNTRY_ISO, dfpParameters.getNetworkCountryISO());
        }

        if (dfpParameters.getNetworkOperator() != null) {
            dfpPraramDoc.append(DfpParameters.NW_OP, dfpParameters.getNetworkOperator());
        }

        if (dfpParameters.getNetworkOperatorName() != null) {
            dfpPraramDoc.append(DfpParameters.NW_OP_NAME, dfpParameters.getNetworkOperatorName());
        }

        if (dfpParameters.getPhoneNumber() != null) {
            dfpPraramDoc.append(DfpParameters.PHONE_NUM, dfpParameters.getPhoneNumber());
        }

        if (dfpParameters.getProduct() != null) {
            dfpPraramDoc.append(DfpParameters.PRODUCT, dfpParameters.getProduct());
        }

        if (dfpParameters.getRadio() != null) {
            dfpPraramDoc.append(DfpParameters.RADIO, dfpParameters.getRadio());
        }

        if (dfpParameters.getScreenSize() != null) {
            dfpPraramDoc.append(DfpParameters.SCREEN_SIZE, dfpParameters.getScreenSize());
        }

        if (dfpParameters.getTags() != null) {
            dfpPraramDoc.append(DfpParameters.TAGS, dfpParameters.getTags());
        }

        if (dfpParameters.getType() != null) {
            dfpPraramDoc.append(DfpParameters.TYPE, dfpParameters.getType());
        }

        if (dfpParameters.getLatitude() != null) {
            dfpPraramDoc.append(DfpParameters.LATITUDE, dfpParameters.getLatitude());
        }

        if (dfpParameters.getLongitude() != null) {
            dfpPraramDoc.append(DfpParameters.LONGITUDE, dfpParameters.getLongitude());
        }

        if (dfpParameters.getAltitude() != null) {
            dfpPraramDoc.append(DfpParameters.ALTITUDE, dfpParameters.getAltitude());
        }

        if (dfpParameters.getAppName() != null) {
            dfpPraramDoc.append(DfpParameters.APPNAME, dfpParameters.getAppName());
        }

        if (dfpParameters.getAppVersion() != null) {
            dfpPraramDoc.append(DfpParameters.APPVERSION, dfpParameters.getAppVersion());
        }

        if (dfpParameters.getProcessorInfo() != null) {
            dfpPraramDoc.append(DfpParameters.PROCESSORINFO, dfpParameters.getProcessorInfo());
        }

        if (dfpParameters.getProcessorSerialNumber() != null) {
            dfpPraramDoc.append(DfpParameters.PROCESSORSERIALNUMBER, dfpParameters.getProcessorSerialNumber());
        }

        if (dfpParameters.getNetBios() != null) {
            dfpPraramDoc.append(DfpParameters.NETBIOS, dfpParameters.getNetBios());
        }

        if (dfpParameters.getDnsHostname() != null) {
            dfpPraramDoc.append(DfpParameters.DNSHOSTNAME, dfpParameters.getDnsHostname());
        }

        if (dfpParameters.getDnsDomain() != null) {
            dfpPraramDoc.append(DfpParameters.DNSDOMAIN, dfpParameters.getDnsDomain());
        }

        if (dfpParameters.getArchitecture() != null) {
            dfpPraramDoc.append(DfpParameters.ARCHITECTURE, dfpParameters.getArchitecture());
        }

        if (dfpParameters.getOsServicePack() != null) {
            dfpPraramDoc.append(DfpParameters.OSSERVICEPACK, dfpParameters.getOsServicePack());
        }

        if (dfpParameters.getOsBuildNumber() != null) {
            dfpPraramDoc.append(DfpParameters.OSBUILDNUMBER, dfpParameters.getOsBuildNumber());
        }

        if (dfpParameters.getCpuBrand() != null) {
            dfpPraramDoc.append(DfpParameters.CPUBRAND, dfpParameters.getCpuBrand());
        }

        if (dfpParameters.getCpuType() != null) {
            dfpPraramDoc.append(DfpParameters.CPUTYPE, dfpParameters.getCpuType());
        }

        if (dfpParameters.getPackages() != null) {
            dfpPraramDoc.append(DfpParameters.PACKAGES, dfpParameters.getPackages());
        }

        if (dfpParameters.getCurrentProcessorSpeed() != null) {
            dfpPraramDoc.append(DfpParameters.CURRENTPROCESSORSPEED, dfpParameters.getCurrentProcessorSpeed());
        }

        if (dfpParameters.getL3Cache() != null) {
            dfpPraramDoc.append(DfpParameters.L3CACHE, dfpParameters.getL3Cache());
        }

        if (dfpParameters.getBootRomVersion() != null) {
            dfpPraramDoc.append(DfpParameters.BOOTROMVERSION, dfpParameters.getBootRomVersion());
        }

        if (dfpParameters.getL2CacheCore() != null) {
            dfpPraramDoc.append(DfpParameters.L2CACHECORE, dfpParameters.getL2CacheCore());
        }

        if (dfpParameters.getNumberOfCores() != null) {
            dfpPraramDoc.append(DfpParameters.NUMBEROFCORES, dfpParameters.getNumberOfCores());
        }

        if (dfpParameters.getMachineName() != null) {
            dfpPraramDoc.append(DfpParameters.MACHINENAME, dfpParameters.getMachineName());
        }

        if (dfpParameters.getPrimaryMACAddress() != null) {
            dfpPraramDoc.append(DfpParameters.PRIMARYMACADDRESS, dfpParameters.getPrimaryMACAddress());
        }

        if (dfpParameters.getLocalizedName() != null) {
            dfpPraramDoc.append(DfpParameters.LOCALIZEDNAME, dfpParameters.getLocalizedName());
        }

        if (dfpParameters.getPhysicalMemory() != null) {
            dfpPraramDoc.append(DfpParameters.PHYSICALMEMORY, dfpParameters.getPhysicalMemory());
        }

        if (dfpParameters.getSerialNumber() != null) {
            dfpPraramDoc.append(DfpParameters.SERIALNUMBER, dfpParameters.getSerialNumber());
        }

        if (dfpParameters.getMachineModel() != null) {
            dfpPraramDoc.append(DfpParameters.MACHINEMODEL, dfpParameters.getMachineModel());
        }

        if (dfpParameters.getSmcVersionSystem() != null) {
            dfpPraramDoc.append(DfpParameters.SMCVERSIONSYSTEM, dfpParameters.getSmcVersionSystem());
        }

        if (dfpParameters.getPlatformUuid() != null) {
            dfpPraramDoc.append(DfpParameters.PLATFORMUUID, dfpParameters.getPlatformUuid());
        }

        if (dfpParameters.getSsid() != null) {
            dfpPraramDoc.append(DfpParameters.SSID, dfpParameters.getSsid());
        }

        if (dfpParameters.getBssid() != null) {
            dfpPraramDoc.append(DfpParameters.BSSID, dfpParameters.getBssid());
        }

        if (dfpParameters.getCsDfp() != null) {
            dfpPraramDoc.append(DfpParameters.CS_DFP, dfpParameters.getCsDfp());
        }

        if (dfpParameters.getManufacturer_FB() != null) {
            dfpPraramDoc.append(DfpParameters.MANUFACTURER_FB, dfpParameters.getManufacturer_FB());
        }

        if (dfpParameters.getHardwareSerialNumber_FB() != null) {
            dfpPraramDoc.append(DfpParameters.HARDWARE_SR_NUM_FB, dfpParameters.getHardwareSerialNumber_FB());
        }

        if (dfpParameters.getDiskDriveSerialNumber_FB() != null) {
            dfpPraramDoc.append(DfpParameters.DISK_DRIVE_SR_NUM_FB, dfpParameters.getDiskDriveSerialNumber_FB());
        }

        if (dfpParameters.getOsMajor() != null) {
            dfpPraramDoc.append(DfpParameters.OS_MAJOR, dfpParameters.getOsMajor());
        }

        return dfpPraramDoc;

    }
}
