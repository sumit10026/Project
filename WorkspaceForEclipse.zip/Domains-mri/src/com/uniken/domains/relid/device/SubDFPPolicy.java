package com.uniken.domains.relid.device;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class SubDFPPolicy {

    @SerializedName("name")
    public String name;

    @SerializedName("value")
    public List<String> value;

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    /**
     * @return the value
     */
    public List<String> getValue() {
        return value;
    }

    /**
     * @param value
     *            the value to set
     */
    public void setValue(final List<String> value) {
        this.value = value;
    }

}
