package com.uniken.domains.relid;

import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * Key Association domain for Agent, user and device
 */
public class CommonKeyAssociation {

    public static final String ID_STR = "_id";
    public static final String KEY_ID_STR = "key_id";
    public static final String KEY_STR = "key";
    public static final String CREATED_TS_STR = "created_ts";

    @Id
    @SerializedName(ID_STR)
    @Field(ID_STR)
    private ObjectId id;

    @SerializedName(KEY_ID_STR)
    @Field(KEY_ID_STR)
    @Indexed(unique = true)
    private String keyId;

    @SerializedName(KEY_STR)
    @Field(KEY_STR)
    private String key;

    @SerializedName(CREATED_TS_STR)
    @Field(CREATED_TS_STR)
    private Date createdTs;

    /**
     * @return the id
     */
    public ObjectId getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final ObjectId id) {
        this.id = id;
    }

    /**
     * @return the keyId
     */
    public String getKeyId() {
        return keyId;
    }

    /**
     * @param keyId
     *            the keyId to set
     */
    public void setKeyId(final String keyId) {
        this.keyId = keyId;
    }

    /**
     * @return the key
     */
    public String getKey() {
        return key;
    }

    /**
     * @param key
     *            the key to set
     */
    public void setKey(final String key) {
        this.key = key;
    }

    /**
     * @return the createdTs
     */
    public Date getCreatedTs() {
        return createdTs;
    }

    /**
     * @param createdTs
     *            the createdTs to set
     */
    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }
}
