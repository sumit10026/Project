package com.uniken.domains.relid.log;

import java.util.Date;

import com.google.gson.annotations.SerializedName;

public class ISALog {

    public final static String DEVICE_ID = "device_id";
    public final static String SESSION_ID = "session_id";
    public final static String TYPE = "type";
    public final static String METHOD = "method";
    public final static String TS = "timestamp";
    public final static String REQUESTER_ID = "requester_id";
    public final static String DATA = "data";

    @SerializedName(DEVICE_ID)
    private String deviceId;

    @SerializedName(SESSION_ID)
    private String sessionId;

    @SerializedName(TYPE)
    private String type;

    @SerializedName(METHOD)
    private String method;

    @SerializedName(TS)
    private Date timestamp;

    @SerializedName(REQUESTER_ID)
    private String requesterId;

    @SerializedName(DATA)
    private String data;

    /**
     * @return the deviceId
     */
    public String getDeviceId() {
        return deviceId;
    }

    /**
     * @param deviceId
     *            the deviceId to set
     */
    public void setDeviceId(final String deviceId) {
        this.deviceId = deviceId;
    }

    /**
     * @return the sessionId
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * @param sessionId
     *            the sessionId to set
     */
    public void setSessionId(final String sessionId) {
        this.sessionId = sessionId;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type
     *            the type to set
     */
    public void setType(final String type) {
        this.type = type;
    }

    /**
     * @return the method
     */
    public String getMethod() {
        return method;
    }

    /**
     * @param method
     *            the method to set
     */
    public void setMethod(final String method) {
        this.method = method;
    }

    /**
     * @return the timestamp
     */
    public Date getTimestamp() {
        return timestamp;
    }

    /**
     * @param timestamp
     *            the timestamp to set
     */
    public void setTimestamp(final Date timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * @return the requesterId
     */
    public String getRequesterId() {
        return requesterId;
    }

    /**
     * @param requesterId
     *            the requesterId to set
     */
    public void setRequesterId(final String requesterId) {
        this.requesterId = requesterId;
    }

    /**
     * @return the data
     */
    public String getData() {
        return data;
    }

    /**
     * @param data
     *            the data to set
     */
    public void setData(final String data) {
        this.data = data;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "IXGLog [deviceId=" + deviceId + ", sessionId=" + sessionId + ", type=" + type + ", method=" + method
                + ", timestamp=" + timestamp + ", requesterId=" + requesterId + ", data=" + data + "]";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((data == null) ? 0 : data.hashCode());
        result = prime * result + ((deviceId == null) ? 0 : deviceId.hashCode());
        result = prime * result + ((method == null) ? 0 : method.hashCode());
        result = prime * result + ((requesterId == null) ? 0 : requesterId.hashCode());
        result = prime * result + ((sessionId == null) ? 0 : sessionId.hashCode());
        result = prime * result + ((timestamp == null) ? 0 : timestamp.hashCode());
        result = prime * result + ((type == null) ? 0 : type.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final ISALog other = (ISALog) obj;
        if (data == null) {
            if (other.data != null)
                return false;
        } else if (!data.equals(other.data))
            return false;
        if (deviceId == null) {
            if (other.deviceId != null)
                return false;
        } else if (!deviceId.equals(other.deviceId))
            return false;
        if (method == null) {
            if (other.method != null)
                return false;
        } else if (!method.equals(other.method))
            return false;
        if (requesterId == null) {
            if (other.requesterId != null)
                return false;
        } else if (!requesterId.equals(other.requesterId))
            return false;
        if (sessionId == null) {
            if (other.sessionId != null)
                return false;
        } else if (!sessionId.equals(other.sessionId))
            return false;
        if (timestamp == null) {
            if (other.timestamp != null)
                return false;
        } else if (!timestamp.equals(other.timestamp))
            return false;
        if (type == null) {
            if (other.type != null)
                return false;
        } else if (!type.equals(other.type))
            return false;
        return true;
    }

}
