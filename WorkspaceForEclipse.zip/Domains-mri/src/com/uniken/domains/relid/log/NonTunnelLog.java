package com.uniken.domains.relid.log;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

public class NonTunnelLog {

    public final static String UUID = "uuid";
    public final static String HNIP = "hnip";
    public final static String PORT = "port";
    public final static String CREATED_TS = "create_ts";
    public final static String TIME = "time";
    public final static String ACCESS = "access";
    public final static String SESSION_ID = "session_id";
    public final static String DEVICE_ID = "device_id";
    public final static String ACCESSOR_ID = "accessor_id";

    @SerializedName(UUID)
    @Field(UUID)
    private String uuid;

    @SerializedName(HNIP)
    @Field(HNIP)
    private String hnip;

    @SerializedName(PORT)
    @Field(PORT)
    private Integer port;

    @SerializedName(CREATED_TS)
    @Field(CREATED_TS)
    private Date createdTs;

    @SerializedName(TIME)
    @Field(TIME)
    private String time;

    @SerializedName(ACCESS)
    @Field(ACCESS)
    private String access;

    @SerializedName(SESSION_ID)
    @Field(SESSION_ID)
    private String sessionId;

    @SerializedName(DEVICE_ID)
    @Field(DEVICE_ID)
    private String deviceId;

    @SerializedName(ACCESSOR_ID)
    @Field(ACCESSOR_ID)
    private String userId;

    /**
     * @return the uuid
     */
    public String getUuid() {
        return uuid;
    }

    /**
     * @param uuid
     *            the uuid to set
     */
    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    /**
     * @return the hnip
     */
    public String getHnip() {
        return hnip;
    }

    /**
     * @param hnip
     *            the hnip to set
     */
    public void setHnip(final String hnip) {
        this.hnip = hnip;
    }

    /**
     * @return the port
     */
    public Integer getPort() {
        return port;
    }

    /**
     * @param port
     *            the port to set
     */
    public void setPort(final Integer port) {
        this.port = port;
    }

    /**
     * @return the createdTs
     */
    public Date getCreatedTs() {
        return createdTs;
    }

    /**
     * @param createdTs
     *            the createdTs to set
     */
    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }

    /**
     * @return the time
     */
    public String getTime() {
        return time;
    }

    /**
     * @param time
     *            the time to set
     */
    public void setTime(final String time) {
        this.time = time;
    }

    /**
     * @return the access
     */
    public String getAccess() {
        return access;
    }

    /**
     * @param access
     *            the access to set
     */
    public void setAccess(final String access) {
        this.access = access;
    }

    /**
     * @return the sessionId
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * @param sessionId
     *            the sessionId to set
     */
    public void setSessionId(final String sessionId) {
        this.sessionId = sessionId;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(final String deviceId) {
        this.deviceId = deviceId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "NonTunnelLog [uuid=" + uuid + ", hnip=" + hnip + ", port=" + port + ", createdTs=" + createdTs
                + ", time=" + time + ", access=" + access + ", sessionId=" + sessionId + ", userId=" + userId + "]";
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((access == null) ? 0 : access.hashCode());
        result = prime * result + ((createdTs == null) ? 0 : createdTs.hashCode());
        result = prime * result + ((hnip == null) ? 0 : hnip.hashCode());
        result = prime * result + ((port == null) ? 0 : port.hashCode());
        result = prime * result + ((sessionId == null) ? 0 : sessionId.hashCode());
        result = prime * result + ((time == null) ? 0 : time.hashCode());
        result = prime * result + ((uuid == null) ? 0 : uuid.hashCode());
        result = prime * result + ((userId == null) ? 0 : userId.hashCode());
        return result;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(final Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        final NonTunnelLog other = (NonTunnelLog) obj;
        if (access == null) {
            if (other.access != null)
                return false;
        } else if (!access.equals(other.access))
            return false;
        if (createdTs == null) {
            if (other.createdTs != null)
                return false;
        } else if (!createdTs.equals(other.createdTs))
            return false;
        if (hnip == null) {
            if (other.hnip != null)
                return false;
        } else if (!hnip.equals(other.hnip))
            return false;
        if (port == null) {
            if (other.port != null)
                return false;
        } else if (!port.equals(other.port))
            return false;
        if (sessionId == null) {
            if (other.sessionId != null)
                return false;
        } else if (!sessionId.equals(other.sessionId))
            return false;
        if (time == null) {
            if (other.time != null)
                return false;
        } else if (!time.equals(other.time))
            return false;
        if (uuid == null) {
            if (other.uuid != null)
                return false;
        } else if (!uuid.equals(other.uuid))
            return false;
        if (userId == null) {
            if (other.userId != null)
                return false;
        } else if (!userId.equals(other.userId))
            return false;
        return true;
    }

    public final static String CREATED_TS_STR = "create_ts_str";

    @SerializedName(CREATED_TS_STR)
    @Field(CREATED_TS_STR)
    private String createdTsStr;

    public String getCreatedTsStr() {
        return createdTsStr;
    }

    public void setCreatedTsStr(final String createdTsStr) {
        this.createdTsStr = createdTsStr;
    }

    public void parseDateToString(final String dateFormat) {
        final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        if (null != this.createdTs)
            this.createdTsStr = sdf.format(this.createdTs);

    }

}
