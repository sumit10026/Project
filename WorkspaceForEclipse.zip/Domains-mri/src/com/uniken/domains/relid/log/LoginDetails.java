package com.uniken.domains.relid.log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.relid.device.DfpParameters;

public class LoginDetails {

    public final static String USER_ID = "user_id";
    public final static String USER_UUID = "user_uuid";
    public final static String DEVICE_ID = "device_id";
    public final static String DEVICE_NAME = "device_name";
    public final static String LOGIN_TS = "login_ts";

    public final static String LOGOUT_TS = "logout_ts";
    public final static String USER_SESSION_ID = "user_session_id";
    public final static String APP_UUID = "app_uuid";
    public final static String SESSION_EXPIRY_TS = "session_expiry_ts";
    public final static String SESSION_EXPIRED_BY = "session_expired_by";
    public static final String PRIMARY_GROUP_NAME_STR = "primary_group_name";
    public static final String PRIMARY_GROUP_UUID_STR = "primary_group_uuid";
    public static final String SECONDARY_GROUP_NAMES_STR = "secondary_group_names";
    public static final String SECONDARY_GROUP_UUIDS_STR = "secondary_group_uuids";
    public final static String LOGIN_TS_STR = "login_ts_str";
    public final static String LOGOUT_TS_STR = "logout_ts_str";
    public final static String SESSION_EXPIRY_TS_STR = "session_expiry_ts_str";

    public final static String LOGIN_CLIENT_IP_ADDRESS = "login_client_ip_address";
    public final static String LOGOUT_CLIENT_IP_ADDRESS = "logout_client_ip_address";

    public final static String APP_AGENT_NAME = "app_agent_name";
    public final static String APP_NAME = "app_name";
    public final static String APP_VERSION = "app_version";
    public final static String DEVICE_DETAILS = "device_details";

    private String id;

    @SerializedName(USER_UUID)
    @Field(USER_UUID)
    private String userUuid;

    @SerializedName(DEVICE_ID)
    @Field(DEVICE_ID)
    private String deviceId;

    @SerializedName(DEVICE_NAME)
    @Field(DEVICE_NAME)
    private String deviceName;

    @SerializedName(USER_ID)
    @Field(USER_ID)
    private String userId;

    @SerializedName(LOGIN_TS)
    @Field(LOGIN_TS)
    private Date loginTs;

    @SerializedName(LOGOUT_TS)
    @Field(LOGOUT_TS)
    private Date logoutTs;

    @SerializedName(USER_SESSION_ID)
    @Field(USER_SESSION_ID)
    private String userSessionId;

    @SerializedName(APP_UUID)
    @Field(APP_UUID)
    private String appUuid;

    @SerializedName(SESSION_EXPIRY_TS)
    @Field(SESSION_EXPIRY_TS)
    private Date sessionExpiryTs;

    @SerializedName(SESSION_EXPIRED_BY)
    @Field(SESSION_EXPIRED_BY)
    private String sessionExpiredBy;

    @SerializedName(PRIMARY_GROUP_NAME_STR)
    @Field(PRIMARY_GROUP_NAME_STR)
    private String primaryGroup;

    @SerializedName(SECONDARY_GROUP_NAMES_STR)
    @Field(SECONDARY_GROUP_NAMES_STR)
    private List<String> secondaryGroupNames;

    @SerializedName(PRIMARY_GROUP_UUID_STR)
    @Field(PRIMARY_GROUP_UUID_STR)
    private String primaryGroupUuid;

    @SerializedName(SECONDARY_GROUP_UUIDS_STR)
    @Field(SECONDARY_GROUP_UUIDS_STR)
    private List<String> secondaryGroupUuids;

    @SerializedName(LOGIN_TS_STR)
    @Field(LOGIN_TS_STR)
    private String loginTsStr;

    @SerializedName(LOGOUT_TS_STR)
    @Field(LOGOUT_TS_STR)
    private String logoutTsStr;

    @SerializedName(SESSION_EXPIRY_TS_STR)
    @Field(SESSION_EXPIRY_TS_STR)
    private String sessionExpiryTsStr;

    @SerializedName(LOGIN_CLIENT_IP_ADDRESS)
    @Field(LOGIN_CLIENT_IP_ADDRESS)
    private String loginClientIpAddress;

    @SerializedName(LOGOUT_CLIENT_IP_ADDRESS)
    @Field(LOGOUT_CLIENT_IP_ADDRESS)
    private String logoutClientIpAddress;

    @SerializedName(APP_AGENT_NAME)
    @Field(APP_AGENT_NAME)
    private String appAgentName;

    @SerializedName(APP_NAME)
    @Field(APP_NAME)
    private String appName;

    @SerializedName(APP_VERSION)
    @Field(APP_VERSION)
    private String appVersion;

    @SerializedName(DEVICE_DETAILS)
    @Field(DEVICE_DETAILS)
    private DfpParameters deviceDetails;

    public String getLoginTsStr() {
        return loginTsStr;
    }

    public void setLoginTsStr(final String loginTsStr) {
        this.loginTsStr = loginTsStr;
    }

    public String getLogoutTsStr() {
        return logoutTsStr;
    }

    public void setLogoutTsStr(final String logoutTsStr) {
        this.logoutTsStr = logoutTsStr;
    }

    public Date getSessionExpiryTs() {
        return sessionExpiryTs;
    }

    public void setSessionExpiryTs(final Date sessionExpiryTs) {
        this.sessionExpiryTs = sessionExpiryTs;
    }

    public String getSessionExpiryTsStr() {
        return sessionExpiryTsStr;
    }

    public void setSessionExpiryTsStr(final String sessionExpiryTsStr) {
        this.sessionExpiryTsStr = sessionExpiryTsStr;
    }

    public String getPrimaryGroup() {
        return primaryGroup;
    }

    public void setPrimaryGroup(final String primaryGroup) {
        this.primaryGroup = primaryGroup;
    }

    public List<String> getSecondaryGroupNames() {
        return secondaryGroupNames;
    }

    public void setSecondaryGroupNames(final List<String> secondaryGroupNames) {
        this.secondaryGroupNames = secondaryGroupNames;
    }

    public String getPrimaryGroupUuid() {
        return primaryGroupUuid;
    }

    public void setPrimaryGroupUuid(final String primaryGroupUuid) {
        this.primaryGroupUuid = primaryGroupUuid;
    }

    public List<String> getSecondaryGroupUuids() {
        return secondaryGroupUuids;
    }

    public void setSecondaryGroupUuids(final List<String> secondaryGroupUuids) {
        this.secondaryGroupUuids = secondaryGroupUuids;
    }

    /**
     * @return the id
     */
    public String getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final String id) {
        this.id = id;
    }

    /**
     * @return the userUuid
     */
    public String getUserUuid() {
        return userUuid;
    }

    /**
     * @param userUuid
     *            the userUuid to set
     */
    public void setUserUuid(final String userUuid) {
        this.userUuid = userUuid;
    }

    /**
     * @return the deviceId
     */
    public String getDeviceId() {
        return deviceId;
    }

    /**
     * @param deviceId
     *            the deviceId to set
     */
    public void setDeviceId(final String deviceId) {
        this.deviceId = deviceId;
    }

    /**
     * @return the deviceName
     */
    public String getDeviceName() {
        return deviceName;
    }

    /**
     * @param deviceName
     *            the deviceName to set
     */
    public void setDeviceName(final String deviceName) {
        this.deviceName = deviceName;
    }

    /**
     * @return the loginTs
     */
    public Date getLoginTs() {
        return loginTs;
    }

    /**
     * @param loginTs
     *            the loginTs to set
     */
    public void setLoginTs(final Date loginTs) {
        this.loginTs = loginTs;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @return the logoutTs
     */
    public Date getLogoutTs() {
        return logoutTs;
    }

    /**
     * @param logoutTs
     *            the logoutTs to set
     */
    public void setLogoutTs(final Date logoutTs) {
        this.logoutTs = logoutTs;
    }

    /**
     * @return the userSessionId
     */
    public String getUserSessionId() {
        return userSessionId;
    }

    /**
     * @param userSessionId
     *            the userSessionId to set
     */
    public void setUserSessionId(final String userSessionId) {
        this.userSessionId = userSessionId;
    }

    /**
     * @return the appUuid
     */
    public String getAppUuid() {
        return appUuid;
    }

    /**
     * @param appUuid
     *            the appUuid to set
     */
    public void setAppUuid(final String appUuid) {
        this.appUuid = appUuid;
    }

    public String getSessionExpiredBy() {
        return sessionExpiredBy;
    }

    public void setSessionExpiredBy(final String sessionExpiredBy) {
        this.sessionExpiredBy = sessionExpiredBy;
    }

    /**
     * @return the loginClientIpAddress
     */
    public String getLoginClientIpAddress() {
        return loginClientIpAddress;
    }

    /**
     * @param loginClientIpAddress
     *            the loginClientIpAddress to set
     */
    public void setLoginClientIpAddress(final String loginClientIpAddress) {
        this.loginClientIpAddress = loginClientIpAddress;
    }

    /**
     * @return the logoutClientIpAddress
     */
    public String getLogoutClientIpAddress() {
        return logoutClientIpAddress;
    }

    /**
     * @param logoutClientIpAddress
     *            the logoutClientIpAddress to set
     */
    public void setLogoutClientIpAddress(final String logoutClientIpAddress) {
        this.logoutClientIpAddress = logoutClientIpAddress;
    }

    /**
     * @return the appAgentName
     */
    public String getAppAgentName() {
        return appAgentName;
    }

    /**
     * @param appAgentName
     *            the appAgentName to set
     */
    public void setAppAgentName(final String appAgentName) {
        this.appAgentName = appAgentName;
    }

    /**
     * @return the appName
     */
    public String getAppName() {
        return appName;
    }

    /**
     * @param appName
     *            the appName to set
     */
    public void setAppName(final String appName) {
        this.appName = appName;
    }

    /**
     * @return the appVersion
     */
    public String getAppVersion() {
        return appVersion;
    }

    /**
     * @param appVersion
     *            the appVersion to set
     */
    public void setAppVersion(final String appVersion) {
        this.appVersion = appVersion;
    }

    /**
     * @return the deviceDetails
     */
    public DfpParameters getDeviceDetails() {
        return deviceDetails;
    }

    /**
     * @param deviceDetails
     *            the deviceDetails to set
     */
    public void setDeviceDetails(final DfpParameters deviceDetails) {
        this.deviceDetails = deviceDetails;
    }

    /**
     * @param userUuid
     * @param deviceId
     * @param deviceName
     * @param userId
     * @param loginTs
     * @param logoutTs
     * @param userSessionId
     * @param appUuid
     */

    public LoginDetails(final String userUuid, final String deviceId, final String deviceName, final String userId,
            final Date loginTs, final Date sessionExpiryTs, final String userSessionId, final String appUuid,
            final String sessionExpiredBy, final String primaryGroup, final String primaryGroupUuid,
            final List<String> secondaryGroupNames, final List<String> secondaryGroupUuids,
            final String loginClientIpAddress, final String logoutClientIpAddress, final String appAgentName,
            final String appName, final String appVersion, final DfpParameters deviceDetails) {
        super();
        this.userUuid = userUuid;
        this.deviceId = deviceId;
        this.deviceName = deviceName;
        this.userId = userId;
        this.loginTs = loginTs;
        this.sessionExpiryTs = sessionExpiryTs;
        this.userSessionId = userSessionId;
        this.appUuid = appUuid;
        this.sessionExpiredBy = sessionExpiredBy;
        this.primaryGroup = primaryGroup;
        this.primaryGroupUuid = primaryGroupUuid;
        this.secondaryGroupNames = secondaryGroupNames;
        this.secondaryGroupUuids = secondaryGroupUuids;
        this.loginClientIpAddress = loginClientIpAddress;
        this.logoutClientIpAddress = logoutClientIpAddress;
        this.appAgentName = appAgentName;
        this.appName = appName;
        this.appVersion = appVersion;
        this.deviceDetails = deviceDetails;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("LoginDetails [deviceName=");
        builder.append(deviceName);
        builder.append(", deviceId=");
        builder.append(deviceId);
        builder.append(", userId=");
        builder.append(userId);
        builder.append(", loginTs=");
        builder.append(loginTs);
        builder.append(", logoutTs=");
        builder.append(logoutTs);
        builder.append(", sessionExpiryTs=");
        builder.append(sessionExpiryTs);
        builder.append(", sessionExpiredBy=");
        builder.append(sessionExpiredBy);
        builder.append(", primaryGroup=");
        builder.append(primaryGroup);
        builder.append(", secondaryGroupNames=");
        builder.append(secondaryGroupNames);
        builder.append(", primaryGroupUuid=");
        builder.append(primaryGroupUuid);
        builder.append(", primaryGroupUuid=");
        builder.append(primaryGroupUuid);
        builder.append(", loginClientIpAddress=");
        builder.append(loginClientIpAddress);
        builder.append(", logoutClientIpAddress=");
        builder.append(logoutClientIpAddress);
        builder.append(", appAgentName=");
        builder.append(appAgentName);
        builder.append(", appName=");
        builder.append(appName);
        builder.append(", appVersion=");
        builder.append(appVersion);
        builder.append(", deviceDetails=");
        builder.append(deviceDetails);
        builder.append("]");
        return builder.toString();
    }

    /**
     * Gets the BSON document form of given {@link LoginDetails} POJO.
     * 
     * @param loginDetails
     *            the login details
     * @return the document
     */
    public static org.bson.Document getDocument(final LoginDetails loginDetails) {
        if (null == loginDetails) {
            return null;
        }

        final org.bson.Document document = new org.bson.Document();

        if (null != loginDetails.getDeviceId()) {
            document.append(DEVICE_ID, loginDetails.getDeviceId());
        }

        if (null != loginDetails.getDeviceName()) {
            document.append(DEVICE_NAME, loginDetails.getDeviceName());
        }

        if (null != loginDetails.getLoginTs()) {
            document.append(LOGIN_TS, loginDetails.getLoginTs());
        }

        if (null != loginDetails.getUserId()) {
            document.append(USER_ID, loginDetails.getUserId());
        }

        if (null != loginDetails.getUserUuid()) {
            document.append(USER_UUID, loginDetails.getUserUuid());
        }

        if (null != loginDetails.getLogoutTs()) {
            document.append(LOGOUT_TS, loginDetails.getLogoutTs());
        }

        if (null != loginDetails.getUserSessionId()) {
            document.append(USER_SESSION_ID, loginDetails.getUserSessionId());
        }

        if (null != loginDetails.getAppUuid()) {
            document.append(APP_UUID, loginDetails.getAppUuid());
        }

        if (null != loginDetails.getAppAgentName()) {
            document.append(APP_AGENT_NAME, loginDetails.getAppAgentName());
        }

        if (null != loginDetails.getAppName()) {
            document.append(APP_NAME, loginDetails.getAppName());
        }

        if (null != loginDetails.getAppVersion()) {
            document.append(APP_VERSION, loginDetails.getAppVersion());
        }

        if (null != loginDetails.getDeviceDetails()) {
            document.append(DEVICE_DETAILS, DfpParameters.getBsonDocument(loginDetails.getDeviceDetails()));
        }

        if (null != loginDetails.getSessionExpiryTs()) {
            document.append(SESSION_EXPIRY_TS, loginDetails.getSessionExpiryTs());
        }

        if (null != loginDetails.getSessionExpiredBy()) {
            document.append(SESSION_EXPIRED_BY, loginDetails.getSessionExpiredBy());
        }

        if (null != loginDetails.getPrimaryGroup()) {
            document.append(PRIMARY_GROUP_NAME_STR, loginDetails.getPrimaryGroup());
        }

        if (null != loginDetails.getPrimaryGroupUuid()) {
            document.append(PRIMARY_GROUP_UUID_STR, loginDetails.getPrimaryGroupUuid());
        }

        if (null != loginDetails.getSecondaryGroupNames()) {
            document.append(SECONDARY_GROUP_NAMES_STR, loginDetails.getSecondaryGroupNames());
        }

        if (null != loginDetails.getSecondaryGroupUuids()) {
            document.append(SECONDARY_GROUP_UUIDS_STR, loginDetails.getSecondaryGroupUuids());
        }

        if (null != loginDetails.getLoginClientIpAddress()) {
            document.append(LOGIN_CLIENT_IP_ADDRESS, loginDetails.getLoginClientIpAddress());
        }

        if (null != loginDetails.getLogoutClientIpAddress()) {
            document.append(LOGOUT_CLIENT_IP_ADDRESS, loginDetails.getLogoutClientIpAddress());
        }
        return document;
    }

    public void parseDateToString(final String dateFormat) {
        final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        if (null != this.loginTs)
            this.loginTsStr = sdf.format(this.loginTs);
        if (null != this.logoutTs)
            this.logoutTsStr = sdf.format(this.logoutTs);
        if (null != this.sessionExpiryTs)
            this.sessionExpiryTsStr = sdf.format(this.sessionExpiryTs);
    }

}
