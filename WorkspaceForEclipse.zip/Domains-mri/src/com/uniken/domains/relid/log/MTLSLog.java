package com.uniken.domains.relid.log;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.relid.BaseEntity;

/**
 * @author uniken-L056
 */
public class MTLSLog extends BaseEntity {

    public final static String TARGET_IP = "target_ip";
    public final static String TARGET_PORT = "target_port";
    public final static String PROXY_IP = "proxy_ip";
    public final static String PROXY_PORT = "proxy_port";
    public final static String SOURCE_HNIP = "source_hnip";
    public final static String SOURCE_PORT = "source_port";
    public final static String STATUS = "status";
    public final static String UUID = "uuid";
    public final static String SSN_ID = "ssn_id";
    public final static String CREATED_TS = "create_ts";
    public final static String REQUESTER_ID = "requester_id";
    public final static String APP_UUID = "app_uuid";
    public final static String DEVICE_ID = "device_id";
    public final static String USER_ID = "user_id";
    public final static String URI = "uri";

    @SerializedName(TARGET_IP)
    @Field(TARGET_IP)
    private String targetIp;

    @SerializedName(TARGET_PORT)
    @Field(TARGET_PORT)
    private String targetPort;

    @SerializedName(PROXY_IP)
    @Field(PROXY_IP)
    private String proxyIp;

    @SerializedName(PROXY_PORT)
    @Field(PROXY_PORT)
    private String proxyPort;

    @SerializedName(SOURCE_HNIP)
    @Field(SOURCE_HNIP)
    private String sourceHnIp;

    @SerializedName(SOURCE_PORT)
    @Field(SOURCE_PORT)
    private String sourcePort;

    @SerializedName(STATUS)
    @Field(STATUS)
    private String status;

    @SerializedName(UUID)
    @Field(UUID)
    private String uuid;

    @SerializedName(SSN_ID)
    @Field(SSN_ID)
    private String ssnId;

    @SerializedName(CREATED_TS)
    @Field(CREATED_TS)
    private Date createTs;

    @SerializedName(REQUESTER_ID)
    @Field(REQUESTER_ID)
    private String requesterId;

    @Field(APP_UUID)
    @SerializedName(APP_UUID)
    private String appUuid;

    @Field(USER_ID)
    @SerializedName(USER_ID)
    private String userId;

    @SerializedName(URI)
    @Field(URI)
    private String uri;

    /**
     * @return the targetIp
     */
    public String getTargetIp() {
        return targetIp;
    }

    /**
     * @param targetIp
     *            the targetIp to set
     */
    public void setTargetIp(final String targetIp) {
        this.targetIp = targetIp;
    }

    /**
     * @return the targetPort
     */
    public String getTargetPort() {
        return targetPort;
    }

    /**
     * @param targetPort
     *            the targetPort to set
     */
    public void setTargetPort(final String targetPort) {
        this.targetPort = targetPort;
    }

    /**
     * @return the proxyIp
     */
    public String getProxyIp() {
        return proxyIp;
    }

    /**
     * @param proxyIp
     *            the proxyIp to set
     */
    public void setProxyIp(final String proxyIp) {
        this.proxyIp = proxyIp;
    }

    /**
     * @return the proxyPort
     */
    public String getProxyPort() {
        return proxyPort;
    }

    /**
     * @param proxyPort
     *            the proxyPort to set
     */
    public void setProxyPort(final String proxyPort) {
        this.proxyPort = proxyPort;
    }

    /**
     * @return the sourceHnIp
     */
    public String getSourceHnIp() {
        return sourceHnIp;
    }

    /**
     * @param sourceHnIp
     *            the sourceHnIp to set
     */
    public void setSourceHnIp(final String sourceHnIp) {
        this.sourceHnIp = sourceHnIp;
    }

    /**
     * @return the sourcePort
     */
    public String getSourcePort() {
        return sourcePort;
    }

    /**
     * @param sourcePort
     *            the sourcePort to set
     */
    public void setSourcePort(final String sourcePort) {
        this.sourcePort = sourcePort;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(final String status) {
        this.status = status;
    }

    /**
     * @return the uuid
     */
    public String getUuid() {
        return uuid;
    }

    /**
     * @param uuid
     *            the uuid to set
     */
    public void setUuid(final String uuid) {
        this.uuid = uuid;
    }

    /**
     * @return the ssnId
     */
    public String getSsnId() {
        return ssnId;
    }

    /**
     * @param ssnId
     *            the ssnId to set
     */
    public void setSsnId(final String ssnId) {
        this.ssnId = ssnId;
    }

    /**
     * @return the createTs
     */
    public Date getCreateTs() {
        return createTs;
    }

    /**
     * @param createTs
     *            the createTs to set
     */
    public void setCreateTs(final Date createTs) {
        this.createTs = createTs;
    }

    /**
     * @return the requesterId
     */
    public String getRequesterId() {
        return requesterId;
    }

    /**
     * @param requesterId
     *            the requesterId to set
     */
    public void setRequesterId(final String requesterId) {
        this.requesterId = requesterId;
    }

    /**
     * @return the appUuid
     */
    public String getAppUuid() {
        return appUuid;
    }

    /**
     * @param appUuid
     *            the appUuid to set
     */
    public void setAppUuid(final String appUuid) {
        this.appUuid = appUuid;

    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param UserId
     *            the UserId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @return the uri
     */
    public String getUri() {
        return uri;
    }

    /**
     * @param uri
     *            the uri to set
     */
    public void setUri(final String uri) {
        this.uri = uri;
    }

    public final static String CREATED_TS_STR = "create_ts_str";

    @SerializedName(CREATED_TS_STR)
    @Field(CREATED_TS_STR)
    private String createTsStr;

    public String getCreateTsStr() {
        return createTsStr;
    }

    public void setCreateTsStr(final String createTsStr) {
        this.createTsStr = createTsStr;
    }

    public void parseDateToString(final String dateFormat) {
        final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        if (null != this.createTs)
            this.createTsStr = sdf.format(this.createTs);

    }

}
