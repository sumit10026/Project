package com.uniken.domains.relid;

import org.bson.types.ObjectId;

import com.google.gson.annotations.SerializedName;

/**
 * All Classes which will persisted to database should extend BaseEntity class.
 * It has instance of ObjectId which acts as storage of mongoDB primary keys
 * while domain serialization and deserialization. It inherits serialization and
 * deserialization functions from JsonEntity
 * 
 * @author UNIKEN
 */
public abstract class BaseEntity {

    public static final String ID_STR = "_id";

    @SerializedName(ID_STR)
    protected ObjectId id;

    public BaseEntity() {
        super();
    }

    /**
     * @return the id
     */
    public ObjectId getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final ObjectId id) {
        this.id = id;
    }

}
