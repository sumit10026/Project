/**
 * 
 */
package com.uniken.domains.auth;

import com.google.gson.annotations.SerializedName;

/**
 * @author Kushal Jaiswal
 */
public class AccessTokenResponse {

    public static final String ACCESS_TOKEN_STR = "access_token";
    public static final String TOKEN_TYPE_STR = "token_type";
    public static final String EXPIRES_IN_STR = "expires_in";
    public static final String SCOPE_STR = "scope";
    public static final String JTI_STR = "jti";
    public static final String REFRESH_TOKEN_STR = "refresh_token";
    public static final String ERROR_TIMESTAMP_STR = "timestamp";
    public static final String STATUS_CODE_STR = "status";
    public static final String ERROR_STR = "error";
    public static final String ERROR_MESSAGE = "message";
    public static final String PATH_STR = "path";

    @SerializedName(ACCESS_TOKEN_STR)
    private final String accessToken;

    @SerializedName(TOKEN_TYPE_STR)
    private String tokenType;

    @SerializedName(EXPIRES_IN_STR)
    private final String expireIn;

    @SerializedName(SCOPE_STR)
    private final String scope;

    @SerializedName(JTI_STR)
    private final String jti;

    @SerializedName(REFRESH_TOKEN_STR)
    private String refreshToken;

    @SerializedName(ERROR_TIMESTAMP_STR)
    private String timestamp;

    @SerializedName(STATUS_CODE_STR)
    private String status;

    @SerializedName(ERROR_STR)
    private String error;

    @SerializedName(ERROR_MESSAGE)
    private String errorMmessage;

    @SerializedName(PATH_STR)
    private String path;

    /**
     * @param accessToken
     * @param tokenType
     * @param expireIn
     * @param scope
     * @param jti
     * @param refreshToken
     */
    public AccessTokenResponse(final String accessToken, final String tokenType, final String expireIn,
            final String scope, final String jti) {

        this.tokenType = "";
        this.accessToken = accessToken;
        this.tokenType = tokenType;
        this.expireIn = expireIn;
        this.scope = scope;
        this.jti = jti;
    }

    /**
     * @param accessToken
     * @param tokenType
     * @param expireIn
     * @param scope
     * @param jti
     * @param refreshToken
     */
    public AccessTokenResponse(final String accessToken, final String tokenType, final String expireIn,
            final String scope, final String jti, final String refreshToken) {

        this.tokenType = "";
        this.accessToken = accessToken;
        this.tokenType = tokenType;
        this.expireIn = expireIn;
        this.scope = scope;
        this.jti = jti;
        this.refreshToken = refreshToken;
    }

    /**
     * @param refreshToken
     *            the refreshToken to set
     */
    public void setRefreshToken(final String refreshToken) {
        this.refreshToken = refreshToken;
    }

    /**
     * @return the accessToken
     */
    public String getAccessToken() {
        return accessToken;
    }

    /**
     * @return the tokenType
     */
    public String getTokenType() {
        return tokenType;
    }

    /**
     * @return the expireIn
     */
    public String getExpireIn() {
        return expireIn;
    }

    /**
     * @return the scope
     */
    public String getScope() {
        return scope;
    }

    /**
     * @return the jti
     */
    public String getJti() {
        return jti;
    }

    /**
     * @return the refreshToken
     */
    public String getRefreshToken() {
        return refreshToken;
    }

    /**
     * @return the timestamp
     */
    public String getTimestamp() {
        return timestamp;
    }

    /**
     * @param timestamp
     *            the timestamp to set
     */
    public void setTimestamp(final String timestamp) {
        this.timestamp = timestamp;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(final String status) {
        this.status = status;
    }

    /**
     * @return the error
     */
    public String getError() {
        return error;
    }

    /**
     * @param error
     *            the error to set
     */
    public void setError(final String error) {
        this.error = error;
    }

    /**
     * @return the errorMmessage
     */
    public String getErrorMmessage() {
        return errorMmessage;
    }

    /**
     * @param errorMmessage
     *            the errorMmessage to set
     */
    public void setErrorMmessage(final String errorMmessage) {
        this.errorMmessage = errorMmessage;
    }

    /**
     * @return the path
     */
    public String getPath() {
        return path;
    }

    /**
     * @param path
     *            the path to set
     */
    public void setPath(final String path) {
        this.path = path;
    }

    class ErrorResponse {

    }
}
