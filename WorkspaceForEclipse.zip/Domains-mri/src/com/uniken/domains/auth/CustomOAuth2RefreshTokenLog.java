/**
 * 
 */
package com.uniken.domains.auth;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.enums.auth.TokenStatus;

/**
 * Custom Refresh Token log for OAuth2.0
 * 
 * @author Kushal Jaiswal
 */
@Document(collection = "oauth_refresh_token_log")
public class CustomOAuth2RefreshTokenLog extends CustomOAuth2RefreshToken {

    private static final long serialVersionUID = 1L;

    private static final String TOKEN_STATUS_KEY = "status";
    public static final String ARCHIVED_TS_KEY = "archived_ts";

    @Field(TOKEN_STATUS_KEY)
    @SerializedName(TOKEN_STATUS_KEY)
    private TokenStatus tokenStatus;

    @Field(ARCHIVED_TS_KEY)
    @SerializedName(ARCHIVED_TS_KEY)
    private Date archivedTS;

    /**
     * Create the {@link CustomOAuth2RefreshTokenLog} object.
     * 
     * @param token
     *            the refresh token value.
     * @param authentication
     *            the authentication.
     * @param expiration
     *            the expire time stamp of the refresh token.
     * @param createdTS
     *            the created time stamp
     * @param archivedTS
     *            the archived time stamp
     */
    public CustomOAuth2RefreshTokenLog(final String token, final OAuth2Authentication authentication,
            final TokenStatus tokenStatus, final Date expiration, final Date createdTS, final Date archivedTS,
            final String requestorId) {

        super(token, expiration, authentication, createdTS, requestorId);
        this.tokenStatus = tokenStatus;
        this.archivedTS = archivedTS;
    }

    /**
     * Created object of Expired {@link CustomOAuth2RefreshTokenLog}
     * 
     * @param refreshToken
     *            the refresh token.
     * @return the {@link CustomOAuth2RefreshTokenLog}
     */
    public static CustomOAuth2RefreshTokenLog getInstanceOfExpiredRefreshTokenLog(
            final CustomOAuth2RefreshToken refreshToken, final Date archivedTS) {

        return new CustomOAuth2RefreshTokenLog(refreshToken.getValue(), refreshToken.getAuthentication(),
                TokenStatus.EXPIRED, refreshToken.getExpiration(), refreshToken.getCreatedTS(), archivedTS,
                refreshToken.getRequestorId());
    }

    /**
     * Created object of Revoked {@link CustomOAuth2RefreshTokenLog}
     * 
     * @param refreshToken
     *            the refresh token.
     * @return the {@link CustomOAuth2RefreshTokenLog}
     */
    public static CustomOAuth2RefreshTokenLog getInstanceOfRevokedRefreshTokenLog(
            final CustomOAuth2RefreshToken refreshToken, final Date archivedTS) {

        return new CustomOAuth2RefreshTokenLog(refreshToken.getValue(), refreshToken.getAuthentication(),
                TokenStatus.REVOKED, refreshToken.getExpiration(), refreshToken.getCreatedTS(), archivedTS,
                refreshToken.getRequestorId());
    }

    /**
     * @param tokenStatus
     *            the tokenStatus to set
     */
    public void setTokenStatus(final TokenStatus tokenStatus) {
        this.tokenStatus = tokenStatus;
    }

    /**
     * @return the tokenStatus
     */
    public TokenStatus getTokenStatus() {
        return tokenStatus;
    }

    /**
     * @return the archivedTS
     */
    public Date getArchivedTSTS() {
        return archivedTS;
    }

    /**
     * @param archivedTS
     *            the archivedTS to set
     */
    public void setArchivedTSTS(final Date archivedTS) {
        this.archivedTS = archivedTS;
    }

}
