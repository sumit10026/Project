/**
 * 
 */
package com.uniken.domains.auth;

import com.google.gson.annotations.SerializedName;

/**
 * @author Kushal Jaiswal
 */
public class RevokeRequest {

    public static final String TOKEN_KEY = "token";
    public static final String TOKEN_TYPE_KEY = "token_type";
    public static final String CLIENT_ID_KEY = "client_id";

    @SerializedName(TOKEN_KEY)
    private String token;

    @SerializedName(TOKEN_TYPE_KEY)
    private String tokenType;

    @SerializedName(CLIENT_ID_KEY)
    private String clientId;

    /**
     * @param token
     * @param tokenType
     * @param clientId
     */
    public RevokeRequest(final String token, final String tokenType, final String clientId) {
        this.token = token;
        this.tokenType = tokenType;
        this.clientId = clientId;
    }

    /**
     * @return the token
     */
    public String getToken() {
        return token;
    }

    /**
     * @param token
     *            the token to set
     */
    public void setToken(final String token) {
        this.token = token;
    }

    /**
     * @return the tokenType
     */
    public String getTokenType() {
        return tokenType;
    }

    /**
     * @param tokenType
     *            the tokenType to set
     */
    public void setTokenType(final String tokenType) {
        this.tokenType = tokenType;
    }

    /**
     * @return the clientId
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * @param clientId
     *            the clientId to set
     */
    public void setClientId(final String clientId) {
        this.clientId = clientId;
    }

}
