/**
 * 
 */
package com.uniken.domains.auth;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * @author Kushal Jaiswal
 */
public class RevokeTokenResponse {

    public static final String TOKEN_KEY = "token";
    public static final String TOKEN_TYPE_KEY = "token_type";
    public static final String MESSAGE_KEY = "message";

    /** The token. */
    @Field(TOKEN_KEY)
    @SerializedName(TOKEN_KEY)
    private String token;

    /** The token type. */
    @Field(TOKEN_TYPE_KEY)
    @SerializedName(TOKEN_TYPE_KEY)
    private String tokenType;

    /** The message. */
    @Field(MESSAGE_KEY)
    @SerializedName(MESSAGE_KEY)
    private String message;

    public RevokeTokenResponse() {
    }

    /**
     * @param token
     * @param tokenType
     * @param message
     */
    public RevokeTokenResponse(final String token, final String tokenType, final String message) {
        super();
        this.token = token;
        this.tokenType = tokenType;
        this.message = message;
    }

    /**
     * @return the token
     */
    public String getToken() {
        return token;
    }

    /**
     * @param token
     *            the token to set
     */
    public void setToken(final String token) {
        this.token = token;
    }

    /**
     * @return the tokenType
     */
    public String getTokenType() {
        return tokenType;
    }

    /**
     * @param tokenType
     *            the tokenType to set
     */
    public void setTokenType(final String tokenType) {
        this.tokenType = tokenType;
    }

    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message
     *            the message to set
     */
    public void setMessage(final String message) {
        this.message = message;
    }

}
