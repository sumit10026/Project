/**
 * 
 */
package com.uniken.domains.auth;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.auth.fido.FIDO2RegisteredAuthenticationModule;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.enums.auth.AuthTypeStatus;

/**
 * @author Kushal Jaiswal
 */
public class RegisteredAuthenticationModule
        implements
        Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -9094201240223905066L;
    public static final String CREATEDTS_STR = "created_ts";
    public static final String UPDATEDTS_STR = "updated_ts";
    public static final String AUTHTYPE_STR = "authType";
    public static final String AUTHTYPESTATUS_STR = "authTypeStatus";
    public static final String LAST_AUTH_TYPE_STATUS = "lastAuthTypeStatus";
    public static final String ARCHIVED_TS = "archived_ts";

    @SerializedName(CREATEDTS_STR)
    @Field(CREATEDTS_STR)
    private final Date createdTS;

    @SerializedName(UPDATEDTS_STR)
    @Field(UPDATEDTS_STR)
    private final Date updatedTS;

    @SerializedName(AUTHTYPE_STR)
    @Field(AUTHTYPE_STR)
    private final AuthType authType;

    @SerializedName(AUTHTYPESTATUS_STR)
    @Field(AUTHTYPESTATUS_STR)
    private AuthTypeStatus authTypeStatus;

    @SerializedName(LAST_AUTH_TYPE_STATUS)
    @Field(LAST_AUTH_TYPE_STATUS)
    private AuthTypeStatus lastAuthTypeStatus;

    @SerializedName(ARCHIVED_TS)
    @Field(ARCHIVED_TS)
    private Date archivedTS;

    /**
     * @param createdTS
     * @param updatedTS
     * @param authType
     */
    public RegisteredAuthenticationModule(final Date createdTS, final Date updatedTS, final AuthType authType,
            final AuthTypeStatus authTypeStatus) {
        super();
        this.createdTS = createdTS;
        this.updatedTS = updatedTS;
        this.authType = authType;
        this.authTypeStatus = authTypeStatus;
    }

    /**
     * @return the createdTS
     */
    public Date getCreatedTS() {
        return createdTS;
    }

    /**
     * @return the updatedTS
     */
    public Date getUpdatedTS() {
        return updatedTS;
    }

    /**
     * @return the authType
     */
    public AuthType getAuthType() {
        return authType;
    }

    /**
     * @return the authTypeStatus
     */
    public AuthTypeStatus getAuthTypeStatus() {
        return authTypeStatus;
    }

    /**
     * @param authTypeStatus
     *            the authTypeStatus to set
     */
    public void setAuthTypeStatus(final AuthTypeStatus authTypeStatus) {
        this.authTypeStatus = authTypeStatus;
    }

    public AuthTypeStatus getLastAuthTypeStatus() {
        return lastAuthTypeStatus;
    }

    public void setLastAuthTypeStatus(final AuthTypeStatus lastAuthTypeStatus) {
        this.lastAuthTypeStatus = lastAuthTypeStatus;
    }

    public Date getArchivedTS() {
        return archivedTS;
    }

    public void setArchivedTS(final Date archivedTS) {
        this.archivedTS = archivedTS;
    }

    /**
     * Retrieves the bson document used to store or fetch from database layer.
     * 
     * @param registeredAuthenticationModules
     * @return
     */
    public static List<Document> getBsonDocuments(
            final RegisteredAuthenticationModule... registeredAuthenticationModules) {

        final List<Document> documents = new ArrayList<>();

        for (final RegisteredAuthenticationModule registeredAuthenticationModule : registeredAuthenticationModules) {
            if (registeredAuthenticationModule.getAuthType().equals(AuthType.FIDO)) {
                documents.add(FIDO2RegisteredAuthenticationModule
                        .getBsonDocument((FIDO2RegisteredAuthenticationModule) registeredAuthenticationModule));
            }
        }

        return documents;
    }

}
