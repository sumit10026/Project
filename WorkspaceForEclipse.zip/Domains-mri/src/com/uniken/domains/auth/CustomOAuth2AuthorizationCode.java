/**
 * 
 */
package com.uniken.domains.auth;

import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.google.gson.annotations.SerializedName;

/**
 * POJO object for Authorization Code.
 * 
 * @author Kushal Jaiswal
 */
@Document(collection = "oauth_authorization_code")
public class CustomOAuth2AuthorizationCode {

    public static final String CODE_KEY = "code";
    public static final String AUTHENTICATION_KEY = "authentication";
    public static final String CREATED_TS_KEY = "created_ts";
    public static final String REQUESTOR_ID_KEY = "requestorId";

    @Id
    private ObjectId _id;

    @Field(CODE_KEY)
    @SerializedName(CODE_KEY)
    @Indexed(name = CODE_KEY, unique = true)
    private String code;

    @Field(AUTHENTICATION_KEY)
    @SerializedName(AUTHENTICATION_KEY)
    private OAuth2Authentication authentication;

    @Field(CREATED_TS_KEY)
    @SerializedName(CREATED_TS_KEY)
    private Date createdTS;

    @SerializedName(REQUESTOR_ID_KEY)
    @Field(REQUESTOR_ID_KEY)
    private String requestorId;

    public CustomOAuth2AuthorizationCode() {
    }

    /**
     * Create Object for {@link CustomOAuth2AuthorizationCode}.
     * 
     * @param code
     *            the code.
     * @param authentication
     *            the authentication.
     * @param createdTS
     *            the created timestamp
     * @param requestorId
     *            request specific id
     */
    public CustomOAuth2AuthorizationCode(final String code, final OAuth2Authentication authentication,
            final Date createdTS, final String requestorId) {
        this.code = code;
        this.authentication = authentication;
        this.createdTS = createdTS;
        this.requestorId = requestorId;
    }

    /**
     * @return
     */
    public ObjectId get_id() {
        return _id;
    }

    /**
     * @param _id
     */
    public void set_id(final ObjectId _id) {
        this._id = _id;
    }

    /**
     * @return the code
     */
    public String getCode() {
        return code;
    }

    /**
     * @param code
     *            the code to set
     */
    public void setCode(final String code) {
        this.code = code;
    }

    /**
     * Gets the OAuth2Authentication
     * 
     * @return the {@link OAuth2Authentication}
     */
    public OAuth2Authentication getAuthentication() {
        return authentication;
    }

    /**
     * @param authentication
     *            the {@link OAuth2Authentication} to set
     */
    public void setAuthentication(final OAuth2Authentication authentication) {
        this.authentication = authentication;
    }

    /**
     * @return the createdTS
     */
    public Date getCreatedTS() {
        return createdTS;
    }

    /**
     * @param createdTS
     *            the createdTS to set
     */
    public void setCreatedTS(final Date createdTS) {
        this.createdTS = createdTS;
    }

    /**
     * @return
     */
    public String getRequestorId() {
        return requestorId;
    }

    /**
     * @param requestorId
     */
    public void setRequestorId(final String requestorId) {
        this.requestorId = requestorId;
    }

}
