package com.uniken.domains.auth;

import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

public class AuthenticationInfo {

    public static final String ID = "_id";
    public static final String USERNAME = "user_name";
    public static final String ENTERPRISE_ID = "enterprise_id";
    public static final String CRED = "password";
    public static final String AUTHENTICATION_METHOD = "method";
    public static final String GOOGLE_SERVER_AUTHENTICATION_KEY = "google_server_authentication_key";
    public static final String GOOGLE_SERVER_MESSAGE_KEY = "google_server_message_key";
    public static final String USE_FCM_FOR_APNS = "use_fcm_for_apns";
    public static final String APPLE_SERVER_CERTIFICATE_CONTENT = "apple_server_certificate_content";
    public static final String APPLE_SERVER_CERTIFICATE_PSWD = "apple_server_certificate_password";
    public static final String APPLE_SERVER_CERTIFICATE_DEV_MODE = "apple_server_certificate_dev_mode";
    public static final String APPLE_SERVER_AUTH_KEY = "apple_server_auth_key";
    public static final String APPLE_SERVER_TEAM_ID = "apple_server_team_id";
    public static final String APPLE_SERVER_TOPIC_ID = "apple_server_topic_id";
    public static final String APPLE_SERVER_KEY_ID = "apple_server_key_id";

    public static final String CLIENT_ID = "client_id";

    public static final String UPDATE_TS = "update_ts";
    public static final String CREATE_TS = "create_ts";

    @SerializedName(ID)
    @Field(ID)
    private ObjectId id;

    @SerializedName(USERNAME)
    @Field(USERNAME)
    private String username;

    @SerializedName(ENTERPRISE_ID)
    @Field(ENTERPRISE_ID)
    private String enterpriseId;

    @SerializedName(CRED)
    @Field(CRED)
    private String cred;

    @SerializedName(CREATE_TS)
    @Field(CREATE_TS)
    private Date createTimestamp;

    @SerializedName(AUTHENTICATION_METHOD)
    @Field(AUTHENTICATION_METHOD)
    private String method;

    @SerializedName(GOOGLE_SERVER_AUTHENTICATION_KEY)
    @Field(GOOGLE_SERVER_AUTHENTICATION_KEY)
    private String googleServerAuthenticationKey;

    @SerializedName(USE_FCM_FOR_APNS)
    @Field(USE_FCM_FOR_APNS)
    private boolean useFcmForApns;

    @SerializedName(APPLE_SERVER_CERTIFICATE_CONTENT)
    @Field(APPLE_SERVER_CERTIFICATE_CONTENT)
    private String appleServerCertificateContent;

    @SerializedName(APPLE_SERVER_CERTIFICATE_PSWD)
    @Field(APPLE_SERVER_CERTIFICATE_PSWD)
    private String appleServerCertificatePswd;

    @SerializedName(APPLE_SERVER_CERTIFICATE_DEV_MODE)
    @Field(APPLE_SERVER_CERTIFICATE_DEV_MODE)
    private boolean appleServerCertificateDevMode;

    @SerializedName(APPLE_SERVER_AUTH_KEY)
    @Field(APPLE_SERVER_AUTH_KEY)
    private String appleServerAuthKey;

    @SerializedName(APPLE_SERVER_TEAM_ID)
    @Field(APPLE_SERVER_TEAM_ID)
    private String appleServerTeamId;

    @SerializedName(APPLE_SERVER_TOPIC_ID)
    @Field(APPLE_SERVER_TOPIC_ID)
    private String appleServerTopicId;

    @SerializedName(APPLE_SERVER_KEY_ID)
    @Field(APPLE_SERVER_KEY_ID)
    private String appleServerKeyId;

    @SerializedName(UPDATE_TS)
    @Field(UPDATE_TS)
    private Date updateTimestamp;

    @SerializedName(CLIENT_ID)
    private String clientId;

    /**
     * @return the id
     */
    public ObjectId getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final ObjectId id) {
        this.id = id;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username
     *            the username to set
     */
    public void setUsername(final String username) {
        this.username = username;
    }

    /**
     * @return the enterpriseId
     */
    public String getEnterpriseId() {
        return enterpriseId;
    }

    /**
     * @param enterpriseId
     *            the enterpriseId to set
     */
    public void setEnterpriseId(final String enterpriseId) {
        this.enterpriseId = enterpriseId;
    }

    /**
     * @return the cred
     */
    public String getCred() {
        return cred;
    }

    /**
     * @param cred
     *            the cred to set
     */
    public void setCred(final String cred) {
        this.cred = cred;
    }

    /**
     * @return the createTimestamp
     */
    public Date getCreateTimestamp() {
        return createTimestamp;
    }

    /**
     * @param createTimestamp
     *            the createTimestamp to set
     */
    public void setCreateTimestamp(final Date createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    /**
     * @return the method
     */
    public String getMethod() {
        return method;
    }

    /**
     * @param method
     *            the method to set
     */
    public void setMethod(final String method) {
        this.method = method;
    }

    public String getGoogleServerAuthenticationKey() {
        return googleServerAuthenticationKey;
    }

    public void setGoogleServerAuthenticationKey(final String googleServerAuthenticationKey) {
        this.googleServerAuthenticationKey = googleServerAuthenticationKey;
    }

    public boolean isUseFcmForApns() {
        return useFcmForApns;
    }

    public void setUseFcmForApns(final boolean useFcmForApns) {
        this.useFcmForApns = useFcmForApns;
    }

    public String getAppleServerCertificateContent() {
        return appleServerCertificateContent;
    }

    public void setAppleServerCertificateContent(final String appleServerCertificateContent) {
        this.appleServerCertificateContent = appleServerCertificateContent;
    }

    public String getAppleServerCertificatePswd() {
        return appleServerCertificatePswd;
    }

    public void setAppleServerCertificatePswd(final String appleServerCertificatePswd) {
        this.appleServerCertificatePswd = appleServerCertificatePswd;
    }

    public boolean isAppleServerCertificateDevMode() {
        return appleServerCertificateDevMode;
    }

    public void setAppleServerCertificateDevMode(final boolean appleServerCertificateDevMode) {
        this.appleServerCertificateDevMode = appleServerCertificateDevMode;
    }

    public void setAppleServerAuthKey(final String appleServerAuthKey) {
        this.appleServerAuthKey = appleServerAuthKey;
    }

    public void setAppleServerTeamId(final String appleServerTeamId) {
        this.appleServerTeamId = appleServerTeamId;
    }

    public void setAppleServerTopicId(final String appleServerTopicId) {
        this.appleServerTopicId = appleServerTopicId;
    }

    public void setAppleServerKeyId(final String appleServerKeyId) {
        this.appleServerKeyId = appleServerKeyId;
    }

    /**
     * @return the updateTimestamp
     */
    public Date getUpdateTimestamp() {
        return updateTimestamp;
    }

    /**
     * @param updateTimestamp
     *            the updateTimestamp to set
     */
    public void setUpdateTimestamp(final Date updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

    /**
     * @return the clientId
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * @param clientId
     *            the clientId to set
     */
    public void setClientId(final String clientId) {
        this.clientId = clientId;
    }

    public String getAppleServerAuthKey() {
        return appleServerAuthKey;
    }

    public String getAppleServerTeamId() {
        return appleServerTeamId;
    }

    public String getAppleServerTopicId() {
        return appleServerTopicId;
    }

    public String getAppleServerKeyId() {
        return appleServerKeyId;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        return "AuthenticationInfo [id=" + id + ", username=" + username + ", enterpriseId=" + enterpriseId + ", cred="
                + cred + ", createTimestamp=" + createTimestamp + ", method=" + method + ", useFcmForApns="
                + useFcmForApns + ", appleServerCertificateDevMode=" + appleServerCertificateDevMode
                + ", appleServerAuthKey=" + appleServerAuthKey + ", appleServerTeamId=" + appleServerTeamId
                + ", appleServerKeyId=" + appleServerKeyId + ", appleServerTopicId=" + appleServerTopicId
                + ", updateTimestamp=" + updateTimestamp + "]";
    }

}
