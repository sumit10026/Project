/**
 * 
 */
package com.uniken.domains.auth;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * POJO object for Authorization Code.
 * 
 * @author Kushal Jaiswal
 */
@Document(collection = "oauth_authorization_code_log")
public class CustomOAuth2AuthorizationCodeLog extends CustomOAuth2AuthorizationCode {

    public static final String ARCHIVED_TS_KEY = "archived_ts";

    @Field(ARCHIVED_TS_KEY)
    @SerializedName(ARCHIVED_TS_KEY)
    private Date archivedTS;

    public CustomOAuth2AuthorizationCodeLog() {
    }

    /**
     * Create Object for {@link CustomOAuth2AuthorizationCodeLog}.
     * 
     * @param customOAuth2AuthorizationCode
     *            the customOAuth2AuthorizationCode.
     * @param archivedTS
     *            the archived time stamp.
     */
    public CustomOAuth2AuthorizationCodeLog(final CustomOAuth2AuthorizationCode customOAuth2AuthorizationCode,
            final Date archivedTS) {

        super(customOAuth2AuthorizationCode.getCode(), customOAuth2AuthorizationCode.getAuthentication(),
                customOAuth2AuthorizationCode.getCreatedTS(), customOAuth2AuthorizationCode.getRequestorId());
        set_id(customOAuth2AuthorizationCode.get_id());
        this.archivedTS = archivedTS;
    }

    /**
     * @return the archivedTS
     */
    public Date getArchivedTS() {
        return archivedTS;
    }

    /**
     * @param archivedTS
     *            the archivedTS to set
     */
    public void setArchivedTS(final Date archivedTS) {
        this.archivedTS = archivedTS;
    }

}
