package com.uniken.domains.auth;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.google.gson.annotations.SerializedName;

/**
 * The Class OAuthAuthenticationLog.
 */
public class OAuthAuthenticationLog
        implements
        Serializable {

    private static final long serialVersionUID = 1L;

    public static final String RESOURCE_ID = "resource_id";
    public static final String API = "api";
    public static final String ERROR_DESCRIPTION = "error_description";
    public static final String ERROR = "error";
    public static final String RESPONSE_HTTP_STATUS_CODE = "response_http_status_code";
    public static final String IS_AUTHENTICATED = "is_authenticated";
    public static final String CLIENT_NAME = "client_name";
    public static final String ACCESS_TOKEN_HASH = "access_token_hash";
    public static final String CREATED_TS = "created_ts";

    // required
    @SerializedName(RESOURCE_ID)
    private String resourceId;

    // optional
    @SerializedName(API)
    private String api;

    @SerializedName(CLIENT_NAME)
    private String clientName;

    @SerializedName(IS_AUTHENTICATED)
    private boolean authenticated;

    private transient String accessToken;

    @SerializedName(ACCESS_TOKEN_HASH)
    private String accessTokenHash;

    @SerializedName(RESPONSE_HTTP_STATUS_CODE)
    private int responseHttpStatusCode;

    @SerializedName(ERROR)
    private String error;

    @SerializedName(ERROR_DESCRIPTION)
    private String errorDescription;

    @SerializedName(CREATED_TS)
    private Date createdTs;

    @SerializedName("createdTsStr")
    private String createdTsStr;

    /**
     * @return the resourceId
     */
    public String getResourceId() {
        return resourceId;
    }

    /**
     * @param resourceId
     *            the resourceId to set
     */
    public void setResourceId(final String resourceId) {
        this.resourceId = resourceId;
    }

    /**
     * @return the api
     */
    public String getApi() {
        return api;
    }

    /**
     * @param api
     *            the api to set
     */
    public void setApi(final String api) {
        this.api = api;
    }

    /**
     * Gets the client name.
     *
     * @return the clientName
     */
    public String getClientName() {
        return clientName;
    }

    /**
     * Sets the client name.
     *
     * @param clientName
     *            the clientName to set
     */
    public void setClientName(final String clientName) {
        this.clientName = clientName;
    }

    /**
     * @return the authenticated
     */
    public boolean isAuthenticated() {
        return authenticated;
    }

    /**
     * @param authenticated
     *            the authenticated to set
     */
    public void setAuthenticated(final boolean authenticated) {
        this.authenticated = authenticated;
    }

    /**
     * @return the accessToken
     */
    public String getAccessToken() {
        return accessToken;
    }

    /**
     * @param accessToken
     *            the accessToken to set
     */
    public void setAccessToken(final String accessToken) {
        this.accessToken = accessToken;
    }

    /**
     * @return the accessTokenHash
     */
    public String getAccessTokenHash() {
        return accessTokenHash;
    }

    /**
     * @param accessTokenHash
     *            the accessTokenHash to set
     */
    public void setAccessTokenHash(final String accessTokenHash) {
        this.accessTokenHash = accessTokenHash;
    }

    /**
     * @return the responseHttpStatusCode
     */
    public int getResponseHttpStatusCode() {
        return responseHttpStatusCode;
    }

    /**
     * @param responseHttpStatusCode
     *            the responseHttpStatusCode to set
     */
    public void setResponseHttpStatusCode(final int responseHttpStatusCode) {
        this.responseHttpStatusCode = responseHttpStatusCode;
    }

    /**
     * @return the error
     */
    public String getError() {
        return error;
    }

    /**
     * @param error
     *            the error to set
     */
    public void setError(final String error) {
        this.error = error;
    }

    /**
     * @return the errorDescription
     */
    public String getErrorDescription() {
        return errorDescription;
    }

    /**
     * @param errorDescription
     *            the errorDescription to set
     */
    public void setErrorDescription(final String errorDescription) {
        this.errorDescription = errorDescription;
    }

    /**
     * @return the createdTs
     */
    public Date getCreatedTs() {
        return createdTs;
    }

    /**
     * @param createdTs
     *            the createdTs to set
     */
    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }

    public String getCreatedTsStr() {
        return createdTsStr;
    }

    public void setCreatedTsStr(final String createdTsStr) {
        this.createdTsStr = createdTsStr;
    }

    /**
     * The Class OAuthAuthenticationRequestLogBuilder.
     */
    public static class Builder {

        // required
        private final AuthenticationResponse authenticationResponse;

        // optional
        private String api;

        /**
         * Instantiates a new o auth authentication request log builder.
         *
         * @param resourceId
         *            the resource id
         * @param authenticationResponse
         *            the authentication response
         */
        public Builder(final AuthenticationResponse authenticationResponse) {
            this.authenticationResponse = authenticationResponse;
        }

        /**
         * Sets the api.
         *
         * @param api
         *            the api
         * @return the o auth authentication request log builder
         */
        public Builder setApi(final String api) {
            this.api = api;
            return this;
        }

        /**
         * Builds the OAuthAuthenticationLog.
         *
         * @return the o auth authentication request log
         */
        public OAuthAuthenticationLog build() {
            final OAuthAuthenticationLog oAuthAuthenticationLog = new OAuthAuthenticationLog();
            oAuthAuthenticationLog.api = this.api;
            oAuthAuthenticationLog.accessToken = authenticationResponse.getAccessToken();
            oAuthAuthenticationLog.clientName = authenticationResponse.getClientName();
            oAuthAuthenticationLog.authenticated = authenticationResponse.isAuthenticated();
            oAuthAuthenticationLog.responseHttpStatusCode = authenticationResponse.getHttpResponseStatusCode();
            if (authenticationResponse.getHttpResponseFields() != null) {
                oAuthAuthenticationLog.error = authenticationResponse.getHttpResponseFields()
                        .get(AuthenticationResponse.HTTP_RESPONSE_FIELD_KEY_ERROR);
                oAuthAuthenticationLog.errorDescription = authenticationResponse.getHttpResponseFields()
                        .get(AuthenticationResponse.HTTP_RESPONSE_FIELD_KEY_ERROR_DESCRIPTION);
            }
            return oAuthAuthenticationLog;
        }

    }

    public void parseDateToString(final String dateFormat) {
        final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        if (null != this.createdTs)
            this.createdTsStr = sdf.format(this.createdTs);
    }
}
