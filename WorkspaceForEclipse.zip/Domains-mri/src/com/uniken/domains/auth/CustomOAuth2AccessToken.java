/**
 * 
 */
package com.uniken.domains.auth;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.security.oauth2.common.DefaultExpiringOAuth2RefreshToken;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2RefreshToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.util.OAuthUtils;

/**
 * Custom Access Token for OAuth2.0
 * 
 * @author Kushal Jaiswal
 */
@Document(collection = "oauth_access_token")
public class CustomOAuth2AccessToken extends DefaultOAuth2AccessToken {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public static final String TOKEN_ID_KEY = "token_id";
    public static final String REFRESH_TOKEN_KEY = "refresh_token";
    public static final String REFRESH_TOKEN_ID_KEY = "refresh_token_id";
    public static final String AUTHENTICATION_ID_KEY = "authentication_id";
    public static final String AUTHENTICATION_KEY = "authentication";
    public static final String CLIENT_ID_KEY = "client_id";
    public static final String USERNAME_KEY = "username";
    public static final String CREATED_TS_KEY = "created_ts";
    public static final String CREATED_TS_STR_KEY = "created_ts_str";
    public static final String TOKEN_TYPE_KEY = "token_type";
    public static final String TOKEN_SCOPE_KEY = "token_scope";
    public static final String TOKEN_EXPIRATION_STR_KEY = "token_expiration_str";
    public static final String AUTHENTICATION_REQUEST_RESOURCE_IDS_KEY = "authentication_request_resource_ids";
    public static final String AUTHENTICATION_REQUEST_REQUEST_PARAM_GRANT_TYPE_KEY = "authentication_request_grant_type";
    public static final String IS_REFRESH_TOKEN_AVAILABLE_KEY = "refresh_token_available";
    public static final String REFRESH_TOKEN_EXPIRATION_STR_KEY = "refresh_token_expiration_str";
    public static final String REQUESTOR_ID_KEY = "requestorId";

    // @Id
    // private String _id;

    @Id
    private ObjectId _id;

    @SerializedName(TOKEN_ID_KEY)
    @Field(TOKEN_ID_KEY)
    @Indexed(name = TOKEN_ID_KEY, unique = true)
    private String tokenId;

    @SerializedName(REFRESH_TOKEN_ID_KEY)
    @Field(REFRESH_TOKEN_ID_KEY)
    private String refreshTokenId;

    @SerializedName(AUTHENTICATION_ID_KEY)
    @Field(AUTHENTICATION_ID_KEY)
    private String authenticationId;

    @SerializedName(USERNAME_KEY)
    @Field(USERNAME_KEY)
    private String username;

    @SerializedName(CLIENT_ID_KEY)
    @Field(CLIENT_ID_KEY)
    private String clientId;

    @SerializedName(AUTHENTICATION_KEY)
    @Field(AUTHENTICATION_KEY)
    private OAuth2Authentication authentication;

    @SerializedName(REFRESH_TOKEN_KEY)
    @Field(REFRESH_TOKEN_KEY)
    private OAuth2RefreshToken refreshToken;

    @SerializedName(CREATED_TS_KEY)
    @Field(CREATED_TS_KEY)
    private Date createdTS;

    @SerializedName(CREATED_TS_STR_KEY)
    @Field(CREATED_TS_STR_KEY)
    private String createdTSStr;

    @SerializedName(TOKEN_EXPIRATION_STR_KEY)
    @Field(TOKEN_EXPIRATION_STR_KEY)
    private String tokenExpirationStr;

    @SerializedName(AUTHENTICATION_REQUEST_RESOURCE_IDS_KEY)
    @Field(AUTHENTICATION_REQUEST_RESOURCE_IDS_KEY)
    private Set<String> authenticationRequestResourceIds;

    @SerializedName(AUTHENTICATION_REQUEST_REQUEST_PARAM_GRANT_TYPE_KEY)
    @Field(AUTHENTICATION_REQUEST_REQUEST_PARAM_GRANT_TYPE_KEY)
    private String authenticationRequestRequestParamGrantType;

    @SerializedName(IS_REFRESH_TOKEN_AVAILABLE_KEY)
    @Field(IS_REFRESH_TOKEN_AVAILABLE_KEY)
    private boolean refreshTokenAvailable;

    @SerializedName(REFRESH_TOKEN_EXPIRATION_STR_KEY)
    @Field(REFRESH_TOKEN_EXPIRATION_STR_KEY)
    private String refreshTokenExpirationStr;

    @SerializedName(REQUESTOR_ID_KEY)
    @Field(REQUESTOR_ID_KEY)
    private String requestorId;

    /**
     * @param accessToken
     * @param authentication
     * @param authenticationId
     */
    public CustomOAuth2AccessToken(final OAuth2AccessToken accessToken, final OAuth2Authentication authentication,
            final String authenticationId) {

        super(accessToken);

        if (accessToken instanceof CustomOAuth2AccessToken) {
            final CustomOAuth2AccessToken customOAuth2AccessToken = (CustomOAuth2AccessToken) accessToken;
            set_id(customOAuth2AccessToken.get_id());
            setCreatedTS(customOAuth2AccessToken.getCreatedTS());
            setRequestorId(customOAuth2AccessToken.getRequestorId());
        }

        this.authentication = authentication;
        this.tokenId = OAuthUtils.extractTokenKey(accessToken.getValue());
        this.authenticationId = authenticationId;
        this.clientId = authentication.getOAuth2Request().getClientId();
        this.username = authentication.isClientOnly() ? null : authentication.getName();
        this.refreshTokenAvailable = accessToken.getRefreshToken() != null;

        if (accessToken.getRefreshToken() != null) {
            this.refreshTokenId = OAuthUtils.extractTokenKey(accessToken.getRefreshToken().getValue());
        }

    }

    /**
     * @param token
     */
    public CustomOAuth2AccessToken(final String token) {
        super(token);
    }

    /**
     * @return the _id
     */
    public ObjectId get_id() {
        return _id;
    }

    /**
     * @param _id
     *            the _id to set
     */
    public void set_id(final ObjectId _id) {
        this._id = _id;
    }

    // /**
    // * @return the _id
    // */
    // public String get_id() {
    // return _id;
    // }
    //
    // /**
    // * @param _id
    // * the _id to set
    // */
    // public void set_id(final String _id) {
    // this._id = _id;
    // }

    /**
     * @return the tokenId
     */
    public String getTokenId() {
        return tokenId;
    }

    /**
     * @param tokenId
     *            the tokenId to set
     */
    public void setTokenId(final String tokenId) {
        this.tokenId = tokenId;
    }

    /**
     * @return the refreshTokenId
     */
    public String getRefreshTokenId() {
        return refreshTokenId;
    }

    /**
     * @param refreshTokenId
     *            the refreshTokenId to set
     */
    public void setRefreshTokenId(final String refreshTokenId) {
        this.refreshTokenId = refreshTokenId;
    }

    /**
     * @return the authenticationId
     */
    public String getAuthenticationId() {
        return authenticationId;
    }

    /**
     * @param authenticationId
     *            the authenticationId to set
     */
    public void setAuthenticationId(final String authenticationId) {
        this.authenticationId = authenticationId;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username
     *            the username to set
     */
    public void setUsername(final String username) {
        this.username = username;
    }

    /**
     * @return the clientId
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * @param clientId
     *            the clientId to set
     */
    public void setClientId(final String clientId) {
        this.clientId = clientId;
    }

    /**
     * @return the serializable Object {@link OAuth2Authentication} of
     *         authentication
     */
    public OAuth2Authentication getAuthentication() {
        return authentication;
    }

    /**
     * Set the object of {@link OAuth2Authentication}
     * 
     * @param authentication
     *            the authentication to set
     */
    public void setAuthentication(final OAuth2Authentication authentication) {
        this.authentication = authentication;
    }

    /**
     * @return the refreshToken
     */
    @Override
    public OAuth2RefreshToken getRefreshToken() {
        return refreshToken;
    }

    /**
     * @param refreshToken
     *            the refreshToken to set
     */
    @Override
    public void setRefreshToken(final OAuth2RefreshToken refreshToken) {
        this.refreshToken = refreshToken;
    }

    /**
     * @return the createdTS
     */
    public Date getCreatedTS() {
        return createdTS;
    }

    /**
     * @param createdTS
     *            the createdTS to set
     */
    public void setCreatedTS(final Date createdTS) {
        this.createdTS = createdTS;
    }

    /**
     * @return the createdTSStr
     */
    public String getCreatedTSStr() {
        return createdTSStr;
    }

    /**
     * @param createdTSStr
     *            the createdTSStr to set
     */
    public void setCreatedTSStr(final String createdTSStr) {
        this.createdTSStr = createdTSStr;
    }

    /**
     * @return the tokenExpirationStr
     */
    public String getTokenExpirationStr() {
        return tokenExpirationStr;
    }

    /**
     * @param tokenExpirationStr
     *            the tokenExpirationStr to set
     */
    public void setTokenExpirationStr(final String tokenExpirationStr) {
        this.tokenExpirationStr = tokenExpirationStr;
    }

    /**
     * @return the authenticationRequestResourceIds
     */
    public Set<String> getAuthenticationRequestResourceIds() {
        return authenticationRequestResourceIds;
    }

    /**
     * @param authenticationRequestResourceIds
     *            the authenticationRequestResourceIds to set
     */
    public void setAuthenticationRequestResourceIds(final Set<String> authenticationRequestResourceIds) {
        this.authenticationRequestResourceIds = authenticationRequestResourceIds;
    }

    /**
     * @return the authenticationRequestRequestParamGrantType
     */
    public String getAuthenticationRequestRequestParamGrantType() {
        return authenticationRequestRequestParamGrantType;
    }

    /**
     * @param authenticationRequestRequestParamGrantType
     *            the authenticationRequestRequestParamGrantType to set
     */
    public void setAuthenticationRequestRequestParamGrantType(final String authenticationRequestRequestParamGrantType) {
        this.authenticationRequestRequestParamGrantType = authenticationRequestRequestParamGrantType;
    }

    /**
     * @return the refreshTokenAvailable
     */
    public boolean isRefreshTokenAvailable() {
        return refreshTokenAvailable;
    }

    /**
     * @param refreshTokenAvailable
     *            the refreshTokenAvailable to set
     */
    public void setRefreshTokenAvailable(final boolean refreshTokenAvailable) {
        this.refreshTokenAvailable = refreshTokenAvailable;
    }

    /**
     * @return the refreshTokenExpirationStr
     */
    public String getRefreshTokenExpirationStr() {
        return refreshTokenExpirationStr;
    }

    /**
     * @param refreshTokenExpirationStr
     *            the refreshTokenExpirationStr to set
     */
    public void setRefreshTokenExpirationStr(final String refreshTokenExpirationStr) {
        this.refreshTokenExpirationStr = refreshTokenExpirationStr;
    }

    /**
     * @return
     */
    public String getRequestorId() {
        return requestorId;
    }

    /**
     * @param requestorId
     */
    public void setRequestorId(final String requestorId) {
        this.requestorId = requestorId;
    }

    public void parseDateToString(final String dateFormat) {
        final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        if (null != this.createdTS) {
            this.createdTSStr = sdf.format(this.createdTS);
        }

        if (null != this.getExpiration()) {
            this.tokenExpirationStr = sdf.format(this.getExpiration());
        }

        if (this.getRefreshToken() instanceof DefaultExpiringOAuth2RefreshToken) {
            this.refreshTokenExpirationStr = sdf
                    .format(((DefaultExpiringOAuth2RefreshToken) this.getRefreshToken()).getExpiration());
        }
    }
}
