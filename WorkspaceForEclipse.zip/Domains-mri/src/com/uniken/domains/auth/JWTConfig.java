package com.uniken.domains.auth;

public class JWTConfig {

    private String kid;
    private String audience;
    private String issuer;
    private String algorithm;
    private String secret;
    private String rsBlob;
    private String keystorePassword;
    private String certificateType;
    private String certificateAlias;

    /**
     * @return the kid
     */
    public String getKid() {
        return kid;
    }

    /**
     * @param kid
     *            the kid to set
     */
    public void setKid(final String kid) {
        this.kid = kid;
    }

    /**
     * @return the audience
     */
    public String getAudience() {
        return audience;
    }

    /**
     * @param audience
     *            the audience to set
     */
    public void setAudience(final String audience) {
        this.audience = audience;
    }

    /**
     * @return the issuer
     */
    public String getIssuer() {
        return issuer;
    }

    /**
     * @param issuer
     *            the issuer to set
     */
    public void setIssuer(final String issuer) {
        this.issuer = issuer;
    }

    /**
     * @return the algorithm
     */
    public String getAlgorithm() {
        return algorithm;
    }

    /**
     * @param algorithm
     *            the algorithm to set
     */
    public void setAlgorithm(final String algorithm) {
        this.algorithm = algorithm;
    }

    /**
     * @return the secret
     */
    public String getSecret() {
        return secret;
    }

    /**
     * @param secret
     *            the secret to set
     */
    public void setSecret(final String secret) {
        this.secret = secret;
    }

    /**
     * @return the rsBlob
     */
    public String getRsBlob() {
        return rsBlob;
    }

    /**
     * @param rsBlob
     *            the rsBlob to set
     */
    public void setRsBlob(final String rsBlob) {
        this.rsBlob = rsBlob;
    }

    /**
     * @return the keystorePassword
     */
    public String getKeystorePassword() {
        return keystorePassword;
    }

    /**
     * @param keystorePassword
     *            the keystorePassword to set
     */
    public void setKeystorePassword(final String keystorePassword) {
        this.keystorePassword = keystorePassword;
    }

    /**
     * @return the certificateType
     */
    public String getCertificateType() {
        return certificateType;
    }

    /**
     * @param certificateType
     *            the certificateType to set
     */
    public void setCertificateType(final String certificateType) {
        this.certificateType = certificateType;
    }

    /**
     * @return the certificateAlias
     */
    public String getCertificateAlias() {
        return certificateAlias;
    }

    /**
     * @param certificateAlias
     *            the certificateAlias to set
     */
    public void setCertificateAlias(final String certificateAlias) {
        this.certificateAlias = certificateAlias;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("JWTConfig [kid=");
        builder.append(kid);
        builder.append(", audience=");
        builder.append(audience);
        builder.append(", issuer=");
        builder.append(issuer);
        builder.append(", algorithm=");
        builder.append(algorithm);
        builder.append(", certificateType=");
        builder.append(certificateType);
        builder.append(", certificateAlias=");
        builder.append(certificateAlias);
        builder.append("]");
        return builder.toString();
    }

}
