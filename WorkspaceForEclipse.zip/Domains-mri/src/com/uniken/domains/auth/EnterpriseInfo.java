package com.uniken.domains.auth;

import java.util.Collection;
import java.util.Date;
import java.util.Map;
import java.util.Set;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.oauth2.provider.ClientDetails;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.relid.LogDomain;

/**
 * Enterprise info domain class.
 * 
 * @author UNIKEN
 */

@Document
@CompoundIndex(name = "enterprise_idx", def = "{'enterprise_id' : 1}", unique = true)
public class EnterpriseInfo extends LogDomain
        implements
        ClientDetails {

    private static final long serialVersionUID = 1L;

    public static final String ENTERPRISE_ID_STR = "enterprise_id";
    public static final String USER_NAME_STR = "user_name";
    public static final String PSWD = "password";

    public static final String GOOGLE_SERVER_AUTHENTICATION_KEY_STR = "google_server_authentication_key";
    public static final String USE_FCM_FOR_APNS = "use_fcm_for_apns";
    public static final String APPLE_SERVER_CERTIFICATE_DEV_MODE_STR = "apple_server_certificate_dev_mode";

    public static final String APPLE_SERVER_AUTH_KEY = "apple_server_auth_key";
    public static final String APPLE_SERVER_TEAM_ID = "apple_server_team_id";
    public static final String APPLE_SERVER_KEY_ID = "apple_server_key_id";
    public static final String APPLE_SERVER_TOPIC_ID = "apple_server_topic_id";

    public static final String METHOD_STR = "method";

    public static final String MAPPED_APPAGENT_UUID = "mapped_appagent_uuid";
    public static final String MAPPED_APPAGENT_NAME = "mapped_appagent_name";
    public static final String MAPPED_ENTERPRISE_NOTIFICATION_MESSAGE = "mapped_enterprise_notification_message";

    public static final String CLIENT_NAME = "client_name";
    public static final String RESOURCE_IDS = "resource_ids";
    public static final String AUTHORIZED_GRANT_TYPES = "authorized_grant_types";
    public static final String ACCESS_TOKEN_VALIDITY = "access_token_validity_seconds";
    public static final String IS_REFRESH_TOKEN_REQ = "enable_refresh_token";
    public static final String REFRESH_TOKEN_VALIDITY = "refresh_token_validity_seconds";
    public static final String CLIENT_ID = "client_id";
    public static final String CLIENT_SECRET = "client_secret";
    public static final String SECRET_REQUIRED = "secret_required";
    public static final String SCOPED = "scoped";
    public static final String SCOPE = "scope";
    public static final String REGISTERED_REDIRECT_URI = "registered_redirect_uri";
    public static final String REGISTERED_ERRROR_URI = "registered_error_uri";
    public static final String AUTHORITIES = "authorities";
    public static final String AUTO_APPROVE = "auto_approve";
    public static final String ADDITIONAL_INFORMATION = "additional_information";
    public static final String ENABLE_TOKEN_GENERATION = "enable_token_generation";
    public static final String AUTO_GENERATE = "auto_generate";

    @Id
    private ObjectId _id;

    @SerializedName(ENTERPRISE_ID_STR)
    private String enterprise_id;

    @SerializedName(USER_NAME_STR)
    private String user_name;

    @SerializedName(PSWD)
    private String password;

    @SerializedName(METHOD_STR)
    private String method;

    @SerializedName(GOOGLE_SERVER_AUTHENTICATION_KEY_STR)
    private String google_server_authentication_key;

    @SerializedName(USE_FCM_FOR_APNS)
    private boolean use_fcm_for_apns;

    @SerializedName(APPLE_SERVER_CERTIFICATE_DEV_MODE_STR)
    private boolean apple_server_certificate_dev_mode;

    @SerializedName(APPLE_SERVER_AUTH_KEY)
    private String apple_server_auth_key;

    @SerializedName(APPLE_SERVER_TEAM_ID)
    private String apple_server_team_id;

    @SerializedName(APPLE_SERVER_KEY_ID)
    private String apple_server_key_id;

    @SerializedName(APPLE_SERVER_TOPIC_ID)
    private String apple_server_topic_id;

    @SerializedName("credsUploadStatusGoogle")
    private String credsUploadStatusGoogle = "PENDING";

    @SerializedName("credsUploadStatusApple")
    private String credsUploadStatusApple = "PENDING";

    @SerializedName(MAPPED_APPAGENT_UUID)
    private String mapped_appagent_uuid;

    @SerializedName(MAPPED_APPAGENT_NAME)
    private String mapped_appagent_name;

    @SerializedName(MAPPED_ENTERPRISE_NOTIFICATION_MESSAGE)
    private String mapped_enterprise_notification_message;

    @SerializedName(CLIENT_NAME)
    @Field(CLIENT_NAME)
    private String clientName;

    @SerializedName(RESOURCE_IDS)
    @Field(RESOURCE_IDS)
    private Set<String> resourceIds;

    @SerializedName(AUTHORIZED_GRANT_TYPES)
    @Field(AUTHORIZED_GRANT_TYPES)
    private Set<String> authorizedGrantTypes;

    @SerializedName(ACCESS_TOKEN_VALIDITY)
    @Field(ACCESS_TOKEN_VALIDITY)
    private int accessTokenValiditySeconds;

    @SerializedName(IS_REFRESH_TOKEN_REQ)
    @Field(IS_REFRESH_TOKEN_REQ)
    private boolean isRefreshTokenRequired;

    @SerializedName(REFRESH_TOKEN_VALIDITY)
    @Field(REFRESH_TOKEN_VALIDITY)
    private int refreshTokenValiditySeconds;

    @SerializedName(CLIENT_ID)
    @Field(CLIENT_ID)
    private String clientId;

    @SerializedName(CLIENT_SECRET)
    @Field(CLIENT_SECRET)
    private String clientSecret;

    @SerializedName(SECRET_REQUIRED)
    @Field(SECRET_REQUIRED)
    private boolean secretRequired;

    @SerializedName(SCOPED)
    @Field(SCOPED)
    private boolean scoped;

    @SerializedName(SCOPE)
    @Field(SCOPE)
    private Set<String> scope;

    @SerializedName(REGISTERED_REDIRECT_URI)
    @Field(REGISTERED_REDIRECT_URI)
    private Set<String> registeredRedirectUri;

    @SerializedName(REGISTERED_ERRROR_URI)
    @Field(REGISTERED_ERRROR_URI)
    private Set<String> registeredErrorUri;

    @SerializedName(AUTHORITIES)
    @Field(AUTHORITIES)
    private Collection<GrantedAuthority> authorities;

    @SerializedName(AUTO_APPROVE)
    @Field(AUTO_APPROVE)
    private boolean autoApprove;

    @SerializedName(ADDITIONAL_INFORMATION)
    @Field(ADDITIONAL_INFORMATION)
    private Map<String, Object> additionalInformation;

    @SerializedName(ENABLE_TOKEN_GENERATION)
    @Field(ENABLE_TOKEN_GENERATION)
    private boolean isTokenGenerationEnable;

    @SerializedName(AUTO_GENERATE)
    @Field(AUTO_GENERATE)
    private boolean autoGenerate;

    /**
     * @return the enterprise_id
     */
    public String getEnterprise_id() {
        return enterprise_id;
    }

    /**
     * @param enterprise_id
     *            the enterprise_id to set
     */
    public void setEnterprise_id(final String enterprise_id) {
        this.enterprise_id = enterprise_id;
    }

    /**
     * @return the user_name
     */
    public String getUser_name() {
        return user_name;
    }

    /**
     * @param user_name
     *            the user_name to set
     */
    public void setUser_name(final String user_name) {
        this.user_name = user_name;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password
     *            the password to set
     */
    public void setPassword(final String password) {
        this.password = password;
    }

    /**
     * @return the method
     */
    public String getMethod() {
        return method;
    }

    /**
     * @param method
     *            the method to set
     */
    public void setMethod(final String method) {
        this.method = method;
    }

    public String getGoogle_server_authentication_key() {
        return google_server_authentication_key;
    }

    public void setGoogle_server_authentication_key(final String google_server_authentication_key) {
        this.google_server_authentication_key = google_server_authentication_key;
    }

    public boolean isApple_server_certificate_dev_mode() {
        return apple_server_certificate_dev_mode;
    }

    public void setApple_server_certificate_dev_mode(final boolean apple_server_certificate_dev_mode) {
        this.apple_server_certificate_dev_mode = apple_server_certificate_dev_mode;
    }

    public String getCredsUploadStatusGoogle() {
        return credsUploadStatusGoogle;
    }

    public void setCredsUploadStatusGoogle(final String credsUploadStatusGoogle) {
        this.credsUploadStatusGoogle = credsUploadStatusGoogle;
    }

    public String getCredsUploadStatusApple() {
        return credsUploadStatusApple;
    }

    public void setCredsUploadStatusApple(final String credsUploadStatusApple) {
        this.credsUploadStatusApple = credsUploadStatusApple;
    }

    /**
     * @return the mapped_appagent_uuid
     */
    public String getMapped_appagent_uuid() {
        return mapped_appagent_uuid;
    }

    /**
     * @param mapped_appagent_uuid
     *            the mapped_appagent_uuid to set
     */
    public void setMapped_appagent_uuid(final String mapped_appagent_uuid) {
        this.mapped_appagent_uuid = mapped_appagent_uuid;
    }

    /**
     * @return the mapped_appagent_name
     */
    public String getMapped_appagent_name() {
        return mapped_appagent_name;
    }

    /**
     * @param mapped_appagent_name
     *            the mapped_appagent_name to set
     */
    public void setMapped_appagent_name(final String mapped_appagent_name) {
        this.mapped_appagent_name = mapped_appagent_name;
    }

    /**
     * Gets the mapped enterprise notification message.
     *
     * @return the mapped enterprise notification message
     */
    public String getMapped_enterprise_notification_message() {
        return mapped_enterprise_notification_message;
    }

    /**
     * Sets the mapped enterprise notification message.
     *
     * @param mapped_enterprise_notification_message
     *            the new mapped enterprise notification message
     */
    public void setMapped_enterprise_notification_message(final String mapped_enterprise_notification_message) {
        this.mapped_enterprise_notification_message = mapped_enterprise_notification_message;
    }

    /**
     * Gets the client name.
     *
     * @return the clientName
     */
    public String getClientName() {
        return clientName;
    }

    /**
     * Sets the client name.
     *
     * @param clientName
     *            the clientName to set
     */
    public void setClientName(final String clientName) {
        this.clientName = clientName;
    }

    /**
     * Get all the resources configured during client on boarding
     * 
     * @return : configured resource during client on boarding
     */
    public Set<String> getResourceIds() {
        return resourceIds;
    }

    /**
     * Set all the resource ids configured while client on boarding
     * 
     * @param resourceIds
     *            : List of Resource name
     */
    public void setResourceIds(final Set<String> resourceIds) {
        this.resourceIds = resourceIds;
    }

    /**
     * Gets the authorized grant types.
     *
     * @return the authorized grant types
     */
    public Set<String> getAuthorizedGrantTypes() {
        return authorizedGrantTypes;
    }

    /**
     * Sets the authorized grant types.
     *
     * @param authorizedGrantTypes
     *            the new authorized grant types
     */
    public void setAuthorizedGrantTypes(final Set<String> authorizedGrantTypes) {
        this.authorizedGrantTypes = authorizedGrantTypes;
    }

    /**
     * @return : If refresh token
     */
    public boolean isRefreshTokenRequired() {
        return isRefreshTokenRequired;
    }

    public void setRefreshTokenRequired(final boolean isRefreshTokenRequired) {
        this.isRefreshTokenRequired = isRefreshTokenRequired;
    }

    /**
     * @return : returns client unique ID
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * Set client Id
     * 
     * @param clientId
     */
    public void setClientId(final String clientId) {
        this.clientId = clientId;
    }

    @Override
    public boolean isSecretRequired() {
        return secretRequired;
    }

    /**
     * @param secretRequired
     *            the secretRequired to set
     */
    public void setSecretRequired(final boolean secretRequired) {
        this.secretRequired = secretRequired;
    }

    @Override
    public String getClientSecret() {
        return clientSecret;
    }

    /**
     * Sets the client secret
     * 
     * @param clientSecret
     *            the clientSecret to set
     */
    public void setClientSecret(final String clientSecret) {
        this.clientSecret = clientSecret;
    }

    @Override
    public boolean isScoped() {
        return scoped;
    }

    /**
     * Sets the scoped status.
     * 
     * @param scoped
     *            the scoped to set
     */
    public void setScoped(final boolean scoped) {
        this.scoped = scoped;
    }

    @Override
    public Set<String> getScope() {
        return scope;
    }

    /**
     * Sets the scope
     * 
     * @param scope
     *            the scope to set
     */
    public void setScope(final Set<String> scope) {
        this.scope = scope;
    }

    @Override
    public Set<String> getRegisteredRedirectUri() {
        return registeredRedirectUri;
    }

    /**
     * Sets the registered redirect uri
     * 
     * @param registeredRedirectUri
     *            the registeredRedirectUri to set
     */
    public void setRegisteredRedirectUri(final Set<String> registeredRedirectUri) {
        this.registeredRedirectUri = registeredRedirectUri;
    }

    @Override
    public Collection<GrantedAuthority> getAuthorities() {
        return authorities;
    }

    /**
     * Sets the authorities
     * 
     * @param authorities
     *            the authorities to set
     */
    public void setAuthorities(final Collection<GrantedAuthority> authorities) {
        this.authorities = authorities;
    }

    @Override
    public Integer getAccessTokenValiditySeconds() {
        return accessTokenValiditySeconds;
    }

    /**
     * Sets the access token validity in seconds
     * 
     * @param accessTokenValiditySeconds
     *            the accessTokenValiditySeconds to set
     */
    public void setAccessTokenValiditySeconds(final int accessTokenValiditySeconds) {
        this.accessTokenValiditySeconds = accessTokenValiditySeconds;
    }

    @Override
    public Integer getRefreshTokenValiditySeconds() {
        return refreshTokenValiditySeconds;
    }

    /**
     * Sets the refresh token validity in seconds
     * 
     * @param refreshTokenValiditySeconds
     *            the refreshTokenValiditySeconds to set
     */
    public void setRefreshTokenValiditySeconds(final int refreshTokenValiditySeconds) {
        this.refreshTokenValiditySeconds = refreshTokenValiditySeconds;
    }

    @Override
    public boolean isAutoApprove(final String scope) {
        return autoApprove;
    }

    /**
     * Sets the auto approve flag.
     * 
     * @param autoApprove
     *            the autoApprove to set
     */
    public void setAutoApprove(final boolean autoApprove) {
        this.autoApprove = autoApprove;
    }

    @Override
    public Map<String, Object> getAdditionalInformation() {
        return additionalInformation;
    }

    /**
     * Sets the additional information of client
     * 
     * @param additionalInformation
     *            the additionalInformation to set
     */
    public void setAdditionalInformation(final Map<String, Object> additionalInformation) {
        this.additionalInformation = additionalInformation;
    }

    public Set<String> getRegisteredErrrorUri() {
        return registeredErrorUri;
    }

    public void setRegisteredErrrorUri(final Set<String> registeredErrrorUri) {
        this.registeredErrorUri = registeredErrrorUri;
    }

    /**
     * @return the isTokenGenerationEnable
     */
    public boolean isTokenGenerationEnable() {
        return isTokenGenerationEnable;
    }

    /**
     * @param isTokenGenerationEnable
     *            the isTokenGenerationEnable to set
     */
    public void setTokenGenerationEnable(final boolean isTokenGenerationEnable) {
        this.isTokenGenerationEnable = isTokenGenerationEnable;
    }

    public boolean isAutoGenerate() {
        return autoGenerate;
    }

    public void setAutoGenerate(final boolean autoGenerate) {
        this.autoGenerate = autoGenerate;
    }

    @SerializedName("createdTs")
    private Date createdTs;

    @SerializedName("updatedTs")
    private Date updatedTs;

    /**
     * @return the createdTs
     */
    public Date getCreatedTs() {
        return createdTs;
    }

    /**
     * @param createdTs
     *            the createdTs to set
     */
    public void setCreatedTs(final Date createdTs) {
        this.createdTs = createdTs;
    }

    /**
     * @return the updatedTs
     */
    public Date getUpdatedTs() {
        return updatedTs;
    }

    /**
     * @param updatedTs
     *            the updatedTs to set
     */
    public void setUpdatedTs(final Date updatedTs) {
        this.updatedTs = updatedTs;
    }

    public boolean isUse_fcm_for_apns() {
        return use_fcm_for_apns;
    }

    public void setUse_fcm_for_apns(final boolean use_fcm_for_apns) {
        this.use_fcm_for_apns = use_fcm_for_apns;
    }

    public String getApple_server_auth_key() {
        return apple_server_auth_key;
    }

    public void setApple_server_auth_key(final String apple_server_auth_key) {
        this.apple_server_auth_key = apple_server_auth_key;
    }

    public String getApple_server_team_id() {
        return apple_server_team_id;
    }

    public void setApple_server_team_id(final String apple_server_team_id) {
        this.apple_server_team_id = apple_server_team_id;
    }

    public String getApple_server_key_id() {
        return apple_server_key_id;
    }

    public void setApple_server_key_id(final String apple_server_key_id) {
        this.apple_server_key_id = apple_server_key_id;
    }

    public String getApple_server_topic_id() {
        return apple_server_topic_id;
    }

    public void setApple_server_topic_id(final String apple_server_topic_id) {
        this.apple_server_topic_id = apple_server_topic_id;
    }

    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("EnterpriseInfo [enterprise_id=");
        builder.append(enterprise_id);
        builder.append(", user_name=");
        builder.append(user_name);
        builder.append(", method=");
        builder.append(method);
        builder.append(", credsUploadStatusGoogle=");
        builder.append(credsUploadStatusGoogle);
        builder.append(", credsUploadStatusApple=");
        builder.append(credsUploadStatusApple);
        builder.append(", mapped_appagent_name=");
        builder.append(mapped_appagent_name);
        builder.append(", mapped_enterprise_notification_message=");
        builder.append(mapped_enterprise_notification_message);
        builder.append(", resourceIds=");
        builder.append(resourceIds);
        builder.append(", authorizedGrantTypes=");
        builder.append(authorizedGrantTypes);
        builder.append(", accessTokenValiditySeconds=");
        builder.append(accessTokenValiditySeconds);
        builder.append(", isRefreshTokenRequired=");
        builder.append(isRefreshTokenRequired);
        builder.append(", refreshTokenValiditySeconds=");
        builder.append(refreshTokenValiditySeconds);
        builder.append(", secretRequired=");
        builder.append(secretRequired);
        builder.append(", scoped=");
        builder.append(scoped);
        builder.append(", scope=");
        builder.append(scope);
        builder.append(", registeredRedirectUri=");
        builder.append(registeredRedirectUri);
        builder.append(", registeredErrorUri=");
        builder.append(registeredErrorUri);
        builder.append(", authorities=");
        builder.append(authorities);
        builder.append(", autoApprove=");
        builder.append(autoApprove);
        builder.append(", isTokenGenerationEnable=");
        builder.append(isTokenGenerationEnable);
        builder.append(", autoGenerate=");
        builder.append(autoGenerate);
        builder.append(", createdTs=");
        builder.append(createdTs);
        builder.append(", updatedTs=");
        builder.append(updatedTs);
        builder.append(", use_fcm_for_apns=");
        builder.append(use_fcm_for_apns);
        builder.append(", apple_server_certificate_dev_mode=");
        builder.append(apple_server_certificate_dev_mode);
        builder.append(", apple_server_auth_key=");
        builder.append(apple_server_auth_key);
        builder.append(", apple_server_team_id=");
        builder.append(apple_server_team_id);
        builder.append(", apple_server_topic_id=");
        builder.append(apple_server_topic_id);
        builder.append(", apple_server_key_id=");
        builder.append(apple_server_key_id);
        builder.append("]");
        return builder.toString();
    }

}
