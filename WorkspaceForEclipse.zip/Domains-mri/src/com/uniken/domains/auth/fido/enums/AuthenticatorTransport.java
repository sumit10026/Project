package com.uniken.domains.auth.fido.enums;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.bson.Document;

public enum AuthenticatorTransport {
    usb("usb"), nfc("nfc"), ble("ble"), internal("internal");

    public String transport;

    private static final Map<String, AuthenticatorTransport> AuthenticatorTransportMap = new HashMap<String, AuthenticatorTransport>();

    static {

        for (final AuthenticatorTransport authenticatorTransport : values()) {
            AuthenticatorTransportMap.put(authenticatorTransport.getTransport(), authenticatorTransport);
        }

    }

    private AuthenticatorTransport(final String transport) {
        this.transport = transport;
    }

    public String getTransport() {
        return this.transport;
    }

    /**
     * @return
     */
    public static Map<String, AuthenticatorTransport> getAuthenticatorTransportMap() {
        return AuthenticatorTransportMap;
    }

    /**
     * @param AuthenticatorTransport
     * @return
     */
    public static AuthenticatorTransport getAuthenticatorTransport(final String transport) {

        return AuthenticatorTransportMap.get(transport);
    }

    public static Document getBsonDocument(final AuthenticatorTransport authenticatorTransport) {
        if (null == authenticatorTransport) {
            return null;
        }

        final Document logsDoc = new Document();
        return logsDoc;
    }

    public static List<Document> getBsonDocuments(final List<AuthenticatorTransport> authenticatorTransports) {
        if (null == authenticatorTransports) {
            return null;
        }

        final List<Document> docs = new ArrayList<Document>();
        for (int kk = 0; kk < authenticatorTransports.size(); kk++) {
            docs.add(getBsonDocument(authenticatorTransports.get(kk)));
        }
        return docs;
    }
}
