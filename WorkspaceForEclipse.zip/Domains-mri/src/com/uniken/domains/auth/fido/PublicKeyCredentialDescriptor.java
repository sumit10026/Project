package com.uniken.domains.auth.fido;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.auth.fido.enums.AuthenticatorTransport;
import com.uniken.domains.auth.fido.enums.PublicKeyCredentialType;

/**
 * https://www.w3.org/TR/webauthn-2/#dictdef-publickeycredentialdescriptor
 * 
 * @author Uniken Inc.
 */
public class PublicKeyCredentialDescriptor
        implements
        Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 4380011208889126540L;
    public static final String TYPE_STR = "type";
    public static final String ID_STR = "id";
    public static final String TRANSPORTS_STR = "transports";

    @SerializedName(TYPE_STR)
    @Field(TYPE_STR)
    PublicKeyCredentialType type;

    @SerializedName(ID_STR)
    @Field(ID_STR)
    String id;

    @SerializedName(TRANSPORTS_STR)
    @Field(TRANSPORTS_STR)
    List<AuthenticatorTransport> transports;

    public PublicKeyCredentialDescriptor(final PublicKeyCredentialType type, final String id,
            final List<AuthenticatorTransport> transports) {
        this.type = type;
        this.id = id;
        this.transports = transports;
    }

    public PublicKeyCredentialType getType() {
        return type;
    }

    public void setType(final PublicKeyCredentialType type) {
        this.type = type;
    }

    public String getId() {
        return id;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public List<AuthenticatorTransport> getTransports() {
        return transports;
    }

    public void setTransports(final List<AuthenticatorTransport> transports) {
        this.transports = transports;
    }

    /**
     * @param publicKeyCredentialDescriptor
     * @return
     */
    public static Document getBsonDocument(final PublicKeyCredentialDescriptor publicKeyCredentialDescriptor) {
        if (null == publicKeyCredentialDescriptor) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != publicKeyCredentialDescriptor.getType()) {
            logsDoc.append(TYPE_STR, publicKeyCredentialDescriptor.getType());
        }

        if (null != publicKeyCredentialDescriptor.getId()) {
            logsDoc.append(ID_STR, publicKeyCredentialDescriptor.getId());
        }

        if (null != publicKeyCredentialDescriptor.getTransports()) {
            logsDoc.append(TRANSPORTS_STR,
                    AuthenticatorTransport.getBsonDocuments(publicKeyCredentialDescriptor.getTransports()));
        }

        return logsDoc;
    }

    /**
     * @param publicKeyCredentialDescriptors
     * @return
     */
    public static List<Document> getBsonDocuments(
            final List<PublicKeyCredentialDescriptor> publicKeyCredentialDescriptors) {

        final List<Document> documents = new ArrayList<>();

        for (final PublicKeyCredentialDescriptor publicKeyCredentialDescriptor : publicKeyCredentialDescriptors) {
            documents.add(PublicKeyCredentialDescriptor.getBsonDocument(publicKeyCredentialDescriptor));
        }

        return documents;
    }
}
