package com.uniken.domains.auth.fido;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.auth.RegisteredAuthenticationModule;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.enums.auth.AuthTypeStatus;

/**
 * The domain module is used while FIDO2 registration workflow.
 * 
 * @author Uniken Inc.
 */
public class FIDO2RegisteredAuthenticationModule extends RegisteredAuthenticationModule {

    /**
     * 
     */
    private static final long serialVersionUID = 9198443432548449911L;
    public static final String USERID_STR = "userid";
    public static final String DOMAIN_STR = "domain";
    public static final String CHALLENGE_STR = "challenge";
    public static final String CREDENTIALCREATIONOPTIONS_STR = "credentialCreationOptions";
    public static final String AUTHENTICATORATTESTATIONRESPONSE_STR = "authenticatorAttestationResponse";
    public static final String ECPOINT_STR = "ecPoint";
    public static final String REGISTRATIONKEYID_STR = "registrationKeyId";
    public static final String REGISTRATIONKEYTYPE_STR = "registrationKeyType";
    public static final String COUNTER_STR = "counter";
    public static final String ATTESTATIONTYPE_STR = "attestationType";
    public static final String SIGNATUREALGORITHMTYPE_STR = "sigAlgorithmType";
    public static final String ATTESTATIONCONVEYANCEPREFERENCE_STR = "attestationConveyancePreference";
    public static final String TRANSPORT_STR = "transport";
    public static final String AUTHENTICATOR_UUID = "authenticator_uuid";
    public static final String AUTHENTICATOR_USER_PREFERRED_NAME = "authenticator_user_preferred_name";
    public static final String AUTHENTICATOR_DESCRIPTION = "authenticator_description";
    public static final String AUTHENTICATOR_NAME = "authenticator_name";
    public static final String AUTHENTICATOR_AAGUID = "aaguid";
    public static final String USER_AGENT = "userAgent";

    @SerializedName(USERID_STR)
    @Field(USERID_STR)
    private final String userId;

    @SerializedName(DOMAIN_STR)
    @Field(DOMAIN_STR)
    private final String domain;

    @SerializedName(CHALLENGE_STR)
    @Field(CHALLENGE_STR)
    private final String challenge;

    @SerializedName(CREDENTIALCREATIONOPTIONS_STR)
    @Field(CREDENTIALCREATIONOPTIONS_STR)
    private final PublicKeyCredentialCreationOptions credentialCreationOptions;

    @SerializedName(AUTHENTICATORATTESTATIONRESPONSE_STR)
    @Field(AUTHENTICATORATTESTATIONRESPONSE_STR)
    private AuthenticatorAttestationResponse authenticatorAttestationResponse;

    @SerializedName(ECPOINT_STR)
    @Field(ECPOINT_STR)
    private String ecPoint;

    @SerializedName(REGISTRATIONKEYID_STR)
    @Field(REGISTRATIONKEYID_STR)
    private String registrationKeyId;

    @SerializedName(REGISTRATIONKEYTYPE_STR)
    @Field(REGISTRATIONKEYTYPE_STR)
    private String registrationKeyType;

    @SerializedName(COUNTER_STR)
    @Field(COUNTER_STR)
    private int counter;

    @SerializedName(ATTESTATIONTYPE_STR)
    @Field(ATTESTATIONTYPE_STR)
    private String attestationType;

    @SerializedName(SIGNATUREALGORITHMTYPE_STR)
    @Field(SIGNATUREALGORITHMTYPE_STR)
    private int sigAlgorithmType;

    @SerializedName(ATTESTATIONCONVEYANCEPREFERENCE_STR)
    @Field(ATTESTATIONCONVEYANCEPREFERENCE_STR)
    private final String attestationConveyancePreference;

    @SerializedName(TRANSPORT_STR)
    @Field(TRANSPORT_STR)
    private final String transport;

    @SerializedName(AUTHENTICATOR_UUID)
    @Field(AUTHENTICATOR_UUID)
    private String authenticatorUuid;

    @SerializedName(AUTHENTICATOR_DESCRIPTION)
    @Field(AUTHENTICATOR_DESCRIPTION)
    private String authenticatorDescription;

    @SerializedName(AUTHENTICATOR_NAME)
    @Field(AUTHENTICATOR_NAME)
    private String authenticatorName;

    @SerializedName(AUTHENTICATOR_USER_PREFERRED_NAME)
    @Field(AUTHENTICATOR_USER_PREFERRED_NAME)
    private String authenticatorUserPreferredName;

    @SerializedName(AUTHENTICATOR_AAGUID)
    @Field(AUTHENTICATOR_AAGUID)
    private String authenticatorAaguid;

    @SerializedName(USER_AGENT)
    @Field(USER_AGENT)
    private String userAgent;

    /**
     * @param userId
     * @param createdTS
     * @param updatedTS
     * @param authType
     * @param authTypeStatus
     * @param domain
     * @param challenge
     * @param credentialCreationOptions
     * @param attestationConveyancePreference
     * @param transport
     * @param authenticatorDescription
     */
    public FIDO2RegisteredAuthenticationModule(final String userId, final Date createdTS, final Date updatedTS,
            final AuthType authType, final AuthTypeStatus authTypeStatus, final String domain, final String challenge,
            final PublicKeyCredentialCreationOptions credentialCreationOptions,
            final String attestationConveyancePreference, final String transport,
            final String authenticatorDescription) {

        super(createdTS, updatedTS, authType, authTypeStatus);
        this.userId = userId;
        this.domain = domain;
        this.challenge = challenge;
        this.credentialCreationOptions = credentialCreationOptions;
        this.attestationConveyancePreference = attestationConveyancePreference;
        this.transport = transport;
        this.authenticatorDescription = authenticatorDescription;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @return the domain
     */
    public String getDomain() {
        return domain;
    }

    /**
     * @return the challenge
     */
    public String getChallenge() {
        return challenge;
    }

    /**
     * @return the credentialCreationOptions
     */
    public PublicKeyCredentialCreationOptions getCredentialCreationOptions() {
        return credentialCreationOptions;
    }

    /**
     * @return the authenticatorAttestationResponse
     */
    public AuthenticatorAttestationResponse getAuthenticatorAttestationResponse() {
        return authenticatorAttestationResponse;
    }

    /**
     * @return the ecPoint
     */
    public String getEcPoint() {
        return ecPoint;
    }

    /**
     * @return the registrationKeyId
     */
    public String getRegistrationKeyId() {
        return registrationKeyId;
    }

    /**
     * @return the registrationKeyType
     */
    public String getRegistrationKeyType() {
        return registrationKeyType;
    }

    /**
     * @return the counter
     */
    public int getCounter() {
        return counter;
    }

    /**
     * @return the attestationType
     */
    public String getAttestationType() {
        return attestationType;
    }

    /**
     * @return the sigAlgorithmType
     */
    public int getSigAlgorithmType() {
        return sigAlgorithmType;
    }

    /**
     * @return the attestationConveyancePreference
     */
    public String getAttestationConveyancePreference() {
        return attestationConveyancePreference;
    }

    /**
     * @param authenticatorAttestationResponse
     *            the authenticatorAttestationResponse to set
     */
    public void setAuthenticatorAttestationResponse(
            final AuthenticatorAttestationResponse authenticatorAttestationResponse) {
        this.authenticatorAttestationResponse = authenticatorAttestationResponse;
    }

    /**
     * @param ecPoint
     *            the ecPoint to set
     */
    public void setEcPoint(final String ecPoint) {
        this.ecPoint = ecPoint;
    }

    /**
     * @param registrationKeyId
     *            the registrationKeyId to set
     */
    public void setRegistrationKeyId(final String registrationKeyId) {
        this.registrationKeyId = registrationKeyId;
    }

    /**
     * @param registrationKeyType
     *            the registrationKeyType to set
     */
    public void setRegistrationKeyType(final String registrationKeyType) {
        this.registrationKeyType = registrationKeyType;
    }

    /**
     * @param counter
     *            the counter to set
     */
    public void setCounter(final int counter) {
        this.counter = counter;
    }

    /**
     * @param attestationType
     *            the attestationType to set
     */
    public void setAttestationType(final String attestationType) {
        this.attestationType = attestationType;
    }

    /**
     * @param sigAlgorithmType
     *            the sigAlgorithmType to set
     */
    public void setSigAlgorithmType(final int sigAlgorithmType) {
        this.sigAlgorithmType = sigAlgorithmType;
    }

    public String getTransport() {
        return transport;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public void setUserAgent(final String userAgent) {
        this.userAgent = userAgent;
    }

    public String getAuthenticatorUuid() {
        return authenticatorUuid;
    }

    public void setAuthenticatorUuid(final String authenticatorUuid) {
        this.authenticatorUuid = authenticatorUuid;
    }

    public String getAuthenticatorDescription() {
        return authenticatorDescription;
    }

    public void setAuthenticatorDescription(final String authenticatorDescription) {
        this.authenticatorDescription = authenticatorDescription;
    }

    public String getAuthenticatorName() {
        return authenticatorName;
    }

    public void setAuthenticatorName(final String authenticatorName) {
        this.authenticatorName = authenticatorName;
    }

    public String getAuthenticatorUserPreferredName() {
        return authenticatorUserPreferredName;
    }

    public void setAuthenticatorUserPreferredName(final String authenticatorUserPreferredName) {
        this.authenticatorUserPreferredName = authenticatorUserPreferredName;
    }

    public String getAuthenticatorAaguid() {
        return authenticatorAaguid;
    }

    public void setAuthenticatorAaguid(final String authenticatorAaguid) {
        this.authenticatorAaguid = authenticatorAaguid;
    }

    /**
     * Returns bson document from pojo object.
     * 
     * @param registeredAuthenticationModule
     * @return
     */
    public static Document getBsonDocument(final FIDO2RegisteredAuthenticationModule registeredAuthenticationModule) {
        if (null == registeredAuthenticationModule) {
            return null;
        }

        final Document document = new Document();

        if (null != registeredAuthenticationModule.getUserId()) {
            document.append(USERID_STR, registeredAuthenticationModule.getUserId());
        }

        if (null != registeredAuthenticationModule.getDomain()) {
            document.append(DOMAIN_STR, registeredAuthenticationModule.getDomain());
        }

        if (null != registeredAuthenticationModule.getChallenge()) {
            document.append(CHALLENGE_STR, registeredAuthenticationModule.getChallenge());
        }

        if (null != registeredAuthenticationModule.getCredentialCreationOptions()) {
            document.append(CREDENTIALCREATIONOPTIONS_STR, PublicKeyCredentialCreationOptions
                    .getBsonDocument(registeredAuthenticationModule.getCredentialCreationOptions()));
        }

        if (null != registeredAuthenticationModule.getAuthenticatorAttestationResponse()) {
            document.append(AUTHENTICATORATTESTATIONRESPONSE_STR, AuthenticatorAttestationResponse
                    .getBsonDocument(registeredAuthenticationModule.getAuthenticatorAttestationResponse()));
        }

        if (null != registeredAuthenticationModule.getEcPoint()) {
            document.append(ECPOINT_STR, registeredAuthenticationModule.getEcPoint());
        }

        if (null != registeredAuthenticationModule.getRegistrationKeyId()) {
            document.append(REGISTRATIONKEYID_STR, registeredAuthenticationModule.getRegistrationKeyId());
        }

        if (null != registeredAuthenticationModule.getRegistrationKeyType()) {
            document.append(REGISTRATIONKEYTYPE_STR, registeredAuthenticationModule.getRegistrationKeyType());
        }

        document.append(COUNTER_STR, registeredAuthenticationModule.getCounter());

        if (null != registeredAuthenticationModule.getAttestationType()) {
            document.append(ATTESTATIONTYPE_STR, registeredAuthenticationModule.getAttestationType());
        }

        document.append(SIGNATUREALGORITHMTYPE_STR, registeredAuthenticationModule.getSigAlgorithmType());

        if (null != registeredAuthenticationModule.getAttestationConveyancePreference()) {
            document.append(ATTESTATIONCONVEYANCEPREFERENCE_STR,
                    registeredAuthenticationModule.getAttestationConveyancePreference());
        }

        if (null != registeredAuthenticationModule.getTransport()) {
            document.append(TRANSPORT_STR, registeredAuthenticationModule.getTransport());
        }

        if (null != registeredAuthenticationModule.getAuthenticatorUuid()) {
            document.append(AUTHENTICATOR_UUID, registeredAuthenticationModule.getAuthenticatorUuid());
        }

        if (null != registeredAuthenticationModule.getAuthenticatorDescription()) {
            document.append(AUTHENTICATOR_DESCRIPTION, registeredAuthenticationModule.getAuthenticatorDescription());
        }

        if (null != registeredAuthenticationModule.getAuthenticatorName()) {
            document.append(AUTHENTICATOR_NAME, registeredAuthenticationModule.getAuthenticatorName());
        }

        if (null != registeredAuthenticationModule.getAuthenticatorUserPreferredName()) {
            document.append(AUTHENTICATOR_USER_PREFERRED_NAME,
                    registeredAuthenticationModule.getAuthenticatorUserPreferredName());
        }

        if (null != registeredAuthenticationModule.getAuthenticatorAaguid()) {
            document.append(AUTHENTICATOR_AAGUID, registeredAuthenticationModule.getAuthenticatorAaguid());
        }

        if (null != registeredAuthenticationModule.getUserAgent()) {
            document.append(USER_AGENT, registeredAuthenticationModule.getUserAgent());
        }

        return document;
    }

    /**
     * Returns list of bson document from list of pojo domain objects
     * 
     * @param registeredAuthenticationModules
     * @return
     */
    public static List<Document> getBsonDocuments(
            final FIDO2RegisteredAuthenticationModule... registeredAuthenticationModules) {

        final List<Document> documents = new ArrayList<Document>();

        for (final FIDO2RegisteredAuthenticationModule registeredAuthenticationModule : registeredAuthenticationModules) {
            documents.add(getBsonDocument(registeredAuthenticationModule));
        }

        return documents;
    }

}
