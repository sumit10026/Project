package com.uniken.domains.auth.fido;

import java.io.Serializable;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * @author Uniken Inc.
 */
public class AuthenticatorAttestationResponseTransports
        implements
        Serializable {

    public static final String AUTHENTICATOR_ATTESTATION_RESPONSE_TRANSPORTS_STR = "getTransports";

    @SerializedName(AUTHENTICATOR_ATTESTATION_RESPONSE_TRANSPORTS_STR)
    @Field(AUTHENTICATOR_ATTESTATION_RESPONSE_TRANSPORTS_STR)
    String transports;

    public String getAuthenticatorAttestationResponseTransports() {
        return transports;
    }

    public void setAuthenticatorAttestationResponseTransports(final String transports) {
        this.transports = transports;
    }

    public static Document getBsonDocument(final AuthenticatorAttestationResponseTransports transports) {

        if (null == transports) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != transports) {
            logsDoc.append(AUTHENTICATOR_ATTESTATION_RESPONSE_TRANSPORTS_STR,
                    transports.getAuthenticatorAttestationResponseTransports());
        }

        return logsDoc;
    }
}
