package com.uniken.domains.auth.fido;

import java.io.Serializable;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * @author Uniken Inc.
 */
public class AuthenticatorAttestationResponsePublicKey
        implements
        Serializable {

    public static final String AUTHENTICATOR_ATTESTATION_RESPONSE_PUBLIC_KEY_STR = "getPublicKey";

    @SerializedName(AUTHENTICATOR_ATTESTATION_RESPONSE_PUBLIC_KEY_STR)
    @Field(AUTHENTICATOR_ATTESTATION_RESPONSE_PUBLIC_KEY_STR)
    String authenticatorAttestationPublicKey;

    public String getAuthenticatorAttestationPublicKey() {
        return authenticatorAttestationPublicKey;
    }

    public void setAuthenticatorAttestationPublicKey(final String authenticatorAttestationPublicKey) {
        this.authenticatorAttestationPublicKey = authenticatorAttestationPublicKey;
    }

    public static Document getBsonDocument(final AuthenticatorAttestationResponsePublicKey authenticatorData) {

        if (null == authenticatorData) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != authenticatorData) {
            logsDoc.append(AUTHENTICATOR_ATTESTATION_RESPONSE_PUBLIC_KEY_STR,
                    authenticatorData.getAuthenticatorAttestationPublicKey());
        }

        return logsDoc;
    }
}
