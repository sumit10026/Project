package com.uniken.domains.auth.fido;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * https://www.w3.org/TR/webauthn-2/#authenticatorresponse
 * 
 * @author Uniken Inc.
 */
public class AuthenticatorResponse {

    public static final String CLIENTDATA_JSON_STR = "clientDataJSON";

    @SerializedName(CLIENTDATA_JSON_STR)
    @Field(CLIENTDATA_JSON_STR)
    public String clientDataJSON;

    public String getClientDataJson() {
        return clientDataJSON;
    }

    public void setClientDataJson(final String clientDataJSON) {
        this.clientDataJSON = clientDataJSON;
    }

}
