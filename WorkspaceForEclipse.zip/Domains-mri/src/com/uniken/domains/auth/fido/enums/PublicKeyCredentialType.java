package com.uniken.domains.auth.fido.enums;

import java.util.HashMap;
import java.util.Map;

import com.google.gson.annotations.SerializedName;

/**
 * Reference : https://www.w3.org/TR/webauthn-2/#enumdef-publickeycredentialtype
 * 
 * @author Uniken Inc.
 */
public enum PublicKeyCredentialType {

    @SerializedName(value = "public-key", alternate = { "public_key" })
    public_key("public-key");

    public String publicKey;

    private static final Map<String, PublicKeyCredentialType> userPublicKeyCredentialTypeMap = new HashMap<String, PublicKeyCredentialType>();

    static {

        for (final PublicKeyCredentialType userPublicKeyCredentialType : values()) {
            userPublicKeyCredentialTypeMap.put(userPublicKeyCredentialType.getPublicKeyCredentialType(),
                    userPublicKeyCredentialType);
        }

    }

    private PublicKeyCredentialType(final String publicKey) {
        this.publicKey = publicKey;
    }

    public String getPublicKeyCredentialType() {
        return this.publicKey;
    }

    /**
     * @return
     */
    public static Map<String, PublicKeyCredentialType> getPublicKeyCredentialTypeMap() {
        return userPublicKeyCredentialTypeMap;
    }

    /**
     * @param UserVerificationRequirement
     * @return
     */
    public static PublicKeyCredentialType getPublicKeyCredentialType(final String publicKey) {

        return userPublicKeyCredentialTypeMap.get(publicKey);
    }
}
