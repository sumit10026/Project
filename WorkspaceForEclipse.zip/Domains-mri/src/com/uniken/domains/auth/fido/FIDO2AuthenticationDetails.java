package com.uniken.domains.auth.fido;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * The FIDO Authentication entity class used in FIDO2 authentication.
 * 
 * @author Uniken Inc.
 */
public class FIDO2AuthenticationDetails {

    public static final String ID_STR = "_id";
    public static final String USERNAME_STR = "username";
    public static final String USERID_STR = "userid";
    public static final String DOMAIN_STR = "domain";
    public static final String CHALLENGE_STR = "challenge";
    public static final String CREDENTIAL_CREATION_REQUEST_OPTIONS_STR = "credentialCreationOptions";
    public static final String AUTHENTICATOR_ASSERTION_RESPONSE_STR = "authenticatorAssertionResponse";
    public static final String REGISTRATIONKEYID_STR = "registrationKeyId";
    public static final String USERVERIFICATION_STR = "UserVerification";
    public static final String CREATEDTS_STR = "created_ts";
    public static final String UPDATEDTS_STR = "updated_ts";

    @SerializedName(value = ID_STR)
    private ObjectId id;

    @SerializedName(USERNAME_STR)
    @Field(USERNAME_STR)
    private final String username;

    @SerializedName(USERID_STR)
    @Field(USERID_STR)
    private String userId;

    @SerializedName(DOMAIN_STR)
    @Field(DOMAIN_STR)
    private final String domain;

    @SerializedName(CHALLENGE_STR)
    @Field(CHALLENGE_STR)
    private final String challenge;

    @SerializedName(CREDENTIAL_CREATION_REQUEST_OPTIONS_STR)
    @Field(CREDENTIAL_CREATION_REQUEST_OPTIONS_STR)
    private final PublicKeyCredentialRequestOptions credentialCreationRequestOptions;

    @SerializedName(AUTHENTICATOR_ASSERTION_RESPONSE_STR)
    @Field(AUTHENTICATOR_ASSERTION_RESPONSE_STR)
    private AuthenticatorAssertionResponse w3cAuthenticatorAssertionResponse;

    @SerializedName(REGISTRATIONKEYID_STR)
    @Field(REGISTRATIONKEYID_STR)
    private String registrationKeyId;

    @SerializedName(USERVERIFICATION_STR)
    @Field(USERVERIFICATION_STR)
    private final String userVerificationOption;

    @SerializedName(CREATEDTS_STR)
    @Field(CREATEDTS_STR)
    private final Date createdDate;

    @SerializedName(UPDATEDTS_STR)
    @Field(UPDATEDTS_STR)
    private Date updatedDate;

    public FIDO2AuthenticationDetails(final String username, final String domain, final String challenge,
            final PublicKeyCredentialRequestOptions credentialCreationRequestOptions,
            final String userVerificationOption, final Date createdDate, final Date updatedDate) {
        this.username = username;
        this.domain = domain;
        this.challenge = challenge;
        this.credentialCreationRequestOptions = credentialCreationRequestOptions;
        this.userVerificationOption = userVerificationOption;
        this.createdDate = createdDate;
        this.updatedDate = updatedDate;
    }

    /**
     * @return the id
     */
    public ObjectId getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final ObjectId id) {
        this.id = id;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @return the domain
     */
    public String getDomain() {
        return domain;
    }

    /**
     * @return the challenge
     */
    public String getChallenge() {
        return challenge;
    }

    /**
     * @return
     */
    public PublicKeyCredentialRequestOptions getCredentialCreationRequestOptions() {
        return credentialCreationRequestOptions;
    }

    /**
     * @return the w3cAuthenticatorAssertionResponse
     */
    public AuthenticatorAssertionResponse getW3cAuthenticatorAssertionResponse() {
        return w3cAuthenticatorAssertionResponse;
    }

    /**
     * @return the registrationKeyId
     */
    public String getRegistrationKeyId() {
        return registrationKeyId;
    }

    /**
     * @return the userVerificationOption
     */
    public String getUserVerificationOption() {
        return userVerificationOption;
    }

    /**
     * @return the createdDate
     */
    public Date getCreatedDate() {
        return createdDate;
    }

    /**
     * @return the updatedDate
     */
    public Date getUpdatedDate() {
        return updatedDate;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @param w3cAuthenticatorAssertionResponse
     *            the w3cAuthenticatorAssertionResponse to set
     */
    public void setW3cAuthenticatorAssertionResponse(
            final AuthenticatorAssertionResponse w3cAuthenticatorAssertionResponse) {
        this.w3cAuthenticatorAssertionResponse = w3cAuthenticatorAssertionResponse;
    }

    /**
     * @param registrationKeyId
     *            the registrationKeyId to set
     */
    public void setRegistrationKeyId(final String registrationKeyId) {
        this.registrationKeyId = registrationKeyId;
    }

    /**
     * @param updatedDate
     *            the updatedDate to set
     */
    public void setUpdatedDate(final Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    /**
     * Returns bson document from the pojo object
     * 
     * @param authenticationDbRecord
     * @return
     */
    public static Document getBsonDocument(final FIDO2AuthenticationDetails authenticationDbRecord) {
        if (null == authenticationDbRecord) {
            return null;
        }

        final Document document = new Document();

        if (null != authenticationDbRecord.getId()) {
            document.append(ID_STR, authenticationDbRecord.getId());
        }

        if (null != authenticationDbRecord.getUsername()) {
            document.append(USERNAME_STR, authenticationDbRecord.getUsername());
        }

        if (null != authenticationDbRecord.getUserId()) {
            document.append(USERID_STR, authenticationDbRecord.getUserId());
        }

        if (null != authenticationDbRecord.getDomain()) {
            document.append(DOMAIN_STR, authenticationDbRecord.getDomain());
        }

        if (null != authenticationDbRecord.getChallenge()) {
            document.append(CHALLENGE_STR, authenticationDbRecord.getChallenge());
        }

        if (null != authenticationDbRecord.getCredentialCreationRequestOptions()) {
            document.append(CREDENTIAL_CREATION_REQUEST_OPTIONS_STR, PublicKeyCredentialRequestOptions
                    .getBsonDocument(authenticationDbRecord.getCredentialCreationRequestOptions()));
        }

        if (null != authenticationDbRecord.getW3cAuthenticatorAssertionResponse()) {
            document.append(AUTHENTICATOR_ASSERTION_RESPONSE_STR,
                    authenticationDbRecord.getW3cAuthenticatorAssertionResponse());
        }

        if (null != authenticationDbRecord.getRegistrationKeyId()) {
            document.append(REGISTRATIONKEYID_STR, authenticationDbRecord.getRegistrationKeyId());
        }

        if (null != authenticationDbRecord.getUserVerificationOption()) {
            document.append(USERVERIFICATION_STR, authenticationDbRecord.getUserVerificationOption());
        }

        if (null != authenticationDbRecord.getUserVerificationOption()) {
            document.append(CREATEDTS_STR, authenticationDbRecord.getCreatedDate());
        }

        if (null != authenticationDbRecord.getUserVerificationOption()) {
            document.append(UPDATEDTS_STR, authenticationDbRecord.getUpdatedDate());
        }

        return document;
    }

    /**
     * Returns the list of bson document from pojo objects
     * 
     * @param authenticationDbRecords
     * @return
     */
    public static List<Document> getBsonDocuments(final FIDO2AuthenticationDetails... authenticationDbRecords) {

        final List<Document> documents = new ArrayList<>();

        for (final FIDO2AuthenticationDetails authenticationDbRecord : authenticationDbRecords) {
            documents.add(getBsonDocument(authenticationDbRecord));
        }

        return documents;
    }
}
