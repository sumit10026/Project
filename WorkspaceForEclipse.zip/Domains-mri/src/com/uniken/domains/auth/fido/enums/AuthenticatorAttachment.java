package com.uniken.domains.auth.fido.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * Reference : https://www.w3.org/TR/webauthn-2/#enumdef-authenticatorattachment
 * 
 * @author Uniken Inc.
 */
public enum AuthenticatorAttachment {
    platform("platform"), crossplatform("cross-platform");

    public String authenticatorAttachment;

    private static final Map<String, AuthenticatorAttachment> AuthenticatorAttachmentMap = new HashMap<String, AuthenticatorAttachment>();

    static {

        for (final AuthenticatorAttachment userAuthenticatorAttachment : values()) {
            AuthenticatorAttachmentMap.put(userAuthenticatorAttachment.getAuthenticatorAttachment(),
                    userAuthenticatorAttachment);
        }

    }

    private AuthenticatorAttachment(final String authenticatorAttachment) {
        this.authenticatorAttachment = authenticatorAttachment;
    }

    public String getAuthenticatorAttachment() {
        return this.authenticatorAttachment;
    }

    /**
     * @return
     */
    public static Map<String, AuthenticatorAttachment> getAuthenticatorAttachmentMap() {
        return AuthenticatorAttachmentMap;
    }

    /**
     * @param AuthenticatorAttachment
     * @return
     */
    public static AuthenticatorAttachment getAuthenticatorAttachment(final String authenticatorAttachment) {

        return AuthenticatorAttachmentMap.get(authenticatorAttachment);
    }
}
