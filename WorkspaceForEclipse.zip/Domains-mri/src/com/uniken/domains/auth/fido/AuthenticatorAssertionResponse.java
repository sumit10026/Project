package com.uniken.domains.auth.fido;

import java.io.Serializable;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * Authenticator assertion response. Refer -
 * https://www.w3.org/TR/webauthn-2/#authenticatorassertionresponse
 * 
 * @author Uniken Inc.
 */
public class AuthenticatorAssertionResponse extends AuthenticatorResponse
        implements
        Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -5338583171214910864L;

    public static final String AUTHENTICATOR_DATA_STR = "authenticatorData";
    public static final String SIGNATURE_STR = "signature";
    public static final String USERHANDLE_STR = "userHandle";

    @SerializedName(AUTHENTICATOR_DATA_STR)
    @Field(AUTHENTICATOR_DATA_STR)
    String authenticatorData;

    @SerializedName(SIGNATURE_STR)
    @Field(SIGNATURE_STR)
    String signature;

    @SerializedName(USERHANDLE_STR)
    @Field(USERHANDLE_STR)
    String userHandle;

    public String getAuthenticatorData() {
        return authenticatorData;
    }

    public void setAuthenticatorData(final String authenticatorData) {
        this.authenticatorData = authenticatorData;
    }

    public String getSignature() {
        return signature;
    }

    public void setSignature(final String signature) {
        this.signature = signature;
    }

    public String getUserHandle() {
        return userHandle;
    }

    public void setUserHandle(final String userHandle) {
        this.userHandle = userHandle;
    }

    public static Document getBsonDocument(final AuthenticatorAssertionResponse authenticatorAssertionResponse) {
        if (null == authenticatorAssertionResponse) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != authenticatorAssertionResponse.getAuthenticatorData()) {
            logsDoc.append(AUTHENTICATOR_DATA_STR, authenticatorAssertionResponse.getAuthenticatorData());
        }

        if (null != authenticatorAssertionResponse.getSignature()) {
            logsDoc.append(SIGNATURE_STR, authenticatorAssertionResponse.getSignature());
        }

        if (null != authenticatorAssertionResponse.getUserHandle()) {
            logsDoc.append(USERHANDLE_STR, authenticatorAssertionResponse.getUserHandle());
        }

        if (null != authenticatorAssertionResponse.getClientDataJson()) {
            logsDoc.append(CLIENTDATA_JSON_STR, authenticatorAssertionResponse.getClientDataJson());
        }

        return logsDoc;
    }
}
