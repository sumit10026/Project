package com.uniken.domains.auth.fido.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * Reference :
 * https://www.w3.org/TR/webauthn-2/#enumdef-attestationconveyancepreference
 * 
 * @author Uniken Inc.
 */
public enum AttestationConveyancePreference {
    none("none"), indirect("indirect"), direct("direct"), enterprise("enterprise");

    public String attestationConveyancePreference;

    private static final Map<String, AttestationConveyancePreference> AttestationConveyancePreferenceMap = new HashMap<String, AttestationConveyancePreference>();

    static {

        for (final AttestationConveyancePreference userAttestationConveyancePreference : values()) {
            AttestationConveyancePreferenceMap.put(
                    userAttestationConveyancePreference.getAttestationConveyancePreference(),
                    userAttestationConveyancePreference);
        }

    }

    private AttestationConveyancePreference(final String attestationConveyancePreference) {
        this.attestationConveyancePreference = attestationConveyancePreference;
    }

    public String getAttestationConveyancePreference() {
        return this.attestationConveyancePreference;
    }

    /**
     * @return
     */
    public static Map<String, AttestationConveyancePreference> getAttestationConveyancePreferenceMap() {
        return AttestationConveyancePreferenceMap;
    }

    /**
     * @param AttestationConveyancePreference
     * @return
     */
    public static AttestationConveyancePreference getAttestationConveyancePreference(
            final String attestationConveyancePreference) {

        return AttestationConveyancePreferenceMap.get(attestationConveyancePreference);
    }
}
