package com.uniken.domains.auth.fido;

import java.io.Serializable;
import java.util.List;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.auth.fido.enums.AttestationConveyancePreference;

/**
 * Reference :
 * https://www.w3.org/TR/webauthn-2/#dictdef-publickeycredentialcreationoptions
 * 
 * @author Uniken Inc.
 */
public class PublicKeyCredentialCreationOptions
        implements
        Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 1325751153913699125L;
    public static final String RP_STR = "rp";
    public static final String USER_STR = "user";
    public static final String CHALLENGE_STR = "challenge";
    public static final String PUBKEY_CRED_PARAMS_STR = "pubKeyCredParams";
    public static final String TIMEOUT_STR = "timeout";
    public static final String EXCLUDE_CREDENTIALS_STR = "excludeCredentials";
    public static final String AUTHENTICATOR_SELECTION_STR = "authenticatorSelection";
    public static final String ATTESTATION_STR = "attestation";
    public static final String AUTHENTICATION_EXTENSIONS_CLIENT_INPUTS_STR = "extensions";
    public static final String STATUS_STR = "status";
    public static final String ERROR_MESSAGE_STR = "errorMessage";

    @SerializedName(RP_STR)
    @Field(RP_STR)
    PublicKeyCredentialRpEntity rp;

    @SerializedName(USER_STR)
    @Field(USER_STR)
    PublicKeyCredentialUserEntity user;

    @SerializedName(CHALLENGE_STR)
    @Field(CHALLENGE_STR)
    String challenge;

    @SerializedName(PUBKEY_CRED_PARAMS_STR)
    @Field(PUBKEY_CRED_PARAMS_STR)
    List<PublicKeyCredentialParameters> pubKeyCredParams;

    @SerializedName(TIMEOUT_STR)
    @Field(TIMEOUT_STR)
    long timeout;

    @SerializedName(EXCLUDE_CREDENTIALS_STR)
    @Field(EXCLUDE_CREDENTIALS_STR)
    List<PublicKeyCredentialDescriptor> excludeCredentials;

    @SerializedName(AUTHENTICATOR_SELECTION_STR)
    @Field(AUTHENTICATOR_SELECTION_STR)
    AuthenticatorSelectionCriteria authenticatorSelection;

    @SerializedName(ATTESTATION_STR)
    @Field(ATTESTATION_STR)
    AttestationConveyancePreference attestation = AttestationConveyancePreference.none;

    @SerializedName(AUTHENTICATION_EXTENSIONS_CLIENT_INPUTS_STR)
    @Field(AUTHENTICATION_EXTENSIONS_CLIENT_INPUTS_STR)
    AuthenticationExtensionsClientInputs extensions;

    @SerializedName(STATUS_STR)
    @Field(STATUS_STR)
    String status;

    @SerializedName(ERROR_MESSAGE_STR)
    @Field(ERROR_MESSAGE_STR)
    String errorMessage;

    public PublicKeyCredentialRpEntity getRp() {
        return rp;
    }

    public void setRp(final PublicKeyCredentialRpEntity rp) {
        this.rp = rp;
    }

    public PublicKeyCredentialUserEntity getUser() {
        return user;
    }

    public void setUser(final PublicKeyCredentialUserEntity user) {
        this.user = user;
    }

    public String getChallenge() {
        return challenge;
    }

    public void setChallenge(final String challenge) {
        this.challenge = challenge;
    }

    public List<PublicKeyCredentialParameters> getPubKeyCredParams() {
        return pubKeyCredParams;
    }

    public void setPubKeyCredParams(final List<PublicKeyCredentialParameters> pubKeyCredParams) {
        this.pubKeyCredParams = pubKeyCredParams;
    }

    public long getTimeout() {
        return timeout;
    }

    public void setTimeout(final long timeout) {
        this.timeout = timeout;
    }

    public List<PublicKeyCredentialDescriptor> getExcludeCredentials() {
        return excludeCredentials;
    }

    public void setExcludeCredentials(final List<PublicKeyCredentialDescriptor> excludeCredentials) {
        this.excludeCredentials = excludeCredentials;
    }

    public AuthenticatorSelectionCriteria getAuthenticatorSelection() {
        return authenticatorSelection;
    }

    public void setAuthenticatorSelection(final AuthenticatorSelectionCriteria authenticatorSelection) {
        this.authenticatorSelection = authenticatorSelection;
    }

    public AttestationConveyancePreference getAttestation() {
        return attestation;
    }

    public void setAttestation(final AttestationConveyancePreference attestation) {
        this.attestation = attestation;
    }

    public AuthenticationExtensionsClientInputs getExtensions() {
        return extensions;
    }

    public void setExtensions(final AuthenticationExtensionsClientInputs extensions) {
        this.extensions = extensions;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(final String status) {
        this.status = status;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(final String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public static Document getBsonDocument(final PublicKeyCredentialCreationOptions credentialCreationOptions) {

        if (null == credentialCreationOptions) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != credentialCreationOptions.getRp()) {
            logsDoc.append(RP_STR, PublicKeyCredentialRpEntity.getBsonDocument(credentialCreationOptions.getRp()));
        }

        if (null != credentialCreationOptions.getUser()) {
            logsDoc.append(USER_STR,
                    PublicKeyCredentialUserEntity.getBsonDocument(credentialCreationOptions.getUser()));
        }

        if (null != credentialCreationOptions.getChallenge()) {
            logsDoc.append(CHALLENGE_STR, credentialCreationOptions.getChallenge());
        }

        if (null != credentialCreationOptions.getPubKeyCredParams()) {
            logsDoc.append(PUBKEY_CRED_PARAMS_STR,
                    PublicKeyCredentialParameters.getBsonDocuments(credentialCreationOptions.getPubKeyCredParams()));
        }

        logsDoc.append(TIMEOUT_STR, credentialCreationOptions.getTimeout());

        if (null != credentialCreationOptions.getExcludeCredentials()) {
            logsDoc.append(EXCLUDE_CREDENTIALS_STR,
                    PublicKeyCredentialDescriptor.getBsonDocuments(credentialCreationOptions.getExcludeCredentials()));
        }

        if (null != credentialCreationOptions.getAuthenticatorSelection()) {
            logsDoc.append(AUTHENTICATOR_SELECTION_STR, AuthenticatorSelectionCriteria
                    .getBsonDocument(credentialCreationOptions.getAuthenticatorSelection()));
        }

        if (null != credentialCreationOptions.getAttestation()) {
            logsDoc.append(ATTESTATION_STR,
                    credentialCreationOptions.getAttestation().getAttestationConveyancePreference());
        }

        if (null != credentialCreationOptions.getExtensions()) {
            logsDoc.append(AUTHENTICATION_EXTENSIONS_CLIENT_INPUTS_STR,
                    credentialCreationOptions.getExtensions().getExtensions());
        }

        if (null != credentialCreationOptions.getStatus()) {
            logsDoc.append(STATUS_STR, credentialCreationOptions.getStatus());
        }

        if (null != credentialCreationOptions.getErrorMessage()) {
            logsDoc.append(ERROR_MESSAGE_STR, credentialCreationOptions.getErrorMessage());
        }

        return logsDoc;
    }
}
