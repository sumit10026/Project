package com.uniken.domains.auth.fido;

import java.io.Serializable;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * Reference -
 * https://www.w3.org/TR/webauthn-2/#authenticatorattestationresponse
 * 
 * @author Uniken Inc.
 */
public class AuthenticatorAttestationResponse extends AuthenticatorResponse
        implements
        Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = -7470640657114166067L;
    public static final String ATTESTATION_OBJECT_STR = "attestationObject";
    public static final String TRANSPORTS_STR = "getTransports";
    public static final String AUTHENTICATOR_DATA_STR = "getAuthenticatorData";
    public static final String PUBLIC_KEY_STR = "getPublicKey";
    public static final String PUBLIC_KEY_ALGORITHM_STR = "getPublicKeyAlgorithm";

    @SerializedName(ATTESTATION_OBJECT_STR)
    @Field(ATTESTATION_OBJECT_STR)
    String attestationObject;

    @SerializedName(TRANSPORTS_STR)
    @Field(TRANSPORTS_STR)
    AuthenticatorAttestationResponseTransports getTransports;

    @SerializedName(AUTHENTICATOR_DATA_STR)
    @Field(AUTHENTICATOR_DATA_STR)
    AuthenticatorData getAuthenticatorData;

    @SerializedName(PUBLIC_KEY_STR)
    @Field(PUBLIC_KEY_STR)
    AuthenticatorAttestationResponsePublicKey getPublicKey;

    @SerializedName(PUBLIC_KEY_ALGORITHM_STR)
    @Field(PUBLIC_KEY_ALGORITHM_STR)
    AuthenticatorAttestationResponsePublicKeyAlgorithms getPublicKeyAlgorithm;

    public String getAttestationObject() {
        return attestationObject;
    }

    public void setAttestationObject(final String attestationObject) {
        this.attestationObject = attestationObject;
    }

    public AuthenticatorAttestationResponseTransports getGetTransports() {
        return getTransports;
    }

    public void setGetTransports(final AuthenticatorAttestationResponseTransports getTransports) {
        this.getTransports = getTransports;
    }

    public AuthenticatorData getGetAuthenticatorData() {
        return getAuthenticatorData;
    }

    public void setGetAuthenticatorData(final AuthenticatorData getAuthenticatorData) {
        this.getAuthenticatorData = getAuthenticatorData;
    }

    public AuthenticatorAttestationResponsePublicKey getGetPublicKey() {
        return getPublicKey;
    }

    public void setGetPublicKey(final AuthenticatorAttestationResponsePublicKey getPublicKey) {
        this.getPublicKey = getPublicKey;
    }

    public AuthenticatorAttestationResponsePublicKeyAlgorithms getGetPublicKeyAlgorithm() {
        return getPublicKeyAlgorithm;
    }

    public void setGetPublicKeyAlgorithm(
            final AuthenticatorAttestationResponsePublicKeyAlgorithms getPublicKeyAlgorithm) {
        this.getPublicKeyAlgorithm = getPublicKeyAlgorithm;
    }

    public static Document getBsonDocument(final AuthenticatorAttestationResponse authenticatorAttestationResponse) {

        if (null == authenticatorAttestationResponse) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != authenticatorAttestationResponse.getAttestationObject()) {
            logsDoc.append(ATTESTATION_OBJECT_STR, authenticatorAttestationResponse.getAttestationObject());
        }

        if (null != authenticatorAttestationResponse.getGetTransports()) {
            logsDoc.append(TRANSPORTS_STR, AuthenticatorAttestationResponseTransports
                    .getBsonDocument(authenticatorAttestationResponse.getGetTransports()));
        }

        if (null != authenticatorAttestationResponse.getGetAuthenticatorData()) {
            logsDoc.append(AUTHENTICATOR_DATA_STR,
                    AuthenticatorData.getBsonDocument(authenticatorAttestationResponse.getGetAuthenticatorData()));
        }

        if (null != authenticatorAttestationResponse.getGetPublicKey()) {
            logsDoc.append(PUBLIC_KEY_STR, AuthenticatorAttestationResponsePublicKey
                    .getBsonDocument(authenticatorAttestationResponse.getGetPublicKey()));
        }

        if (null != authenticatorAttestationResponse.getGetPublicKeyAlgorithm()) {
            logsDoc.append(PUBLIC_KEY_ALGORITHM_STR, AuthenticatorAttestationResponsePublicKeyAlgorithms
                    .getBsonDocument(authenticatorAttestationResponse.getGetPublicKeyAlgorithm()));
        }

        if (null != authenticatorAttestationResponse.getClientDataJson()) {
            logsDoc.append(CLIENTDATA_JSON_STR, authenticatorAttestationResponse.getClientDataJson());
        }

        return logsDoc;
    }

}
