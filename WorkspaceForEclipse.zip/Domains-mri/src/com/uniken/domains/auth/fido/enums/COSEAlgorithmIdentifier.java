package com.uniken.domains.auth.fido.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * Reference 1 : https://www.w3.org/TR/webauthn-2/#biblio-iana-cose-algs-reg
 * Reference 2 : https://www.iana.org/assignments/cose/cose.xhtml#algorithms
 * 
 * @author Uniken Inc.
 */
public enum COSEAlgorithmIdentifier {
    ES256("-7"),
    PS512("-39"),
    PS384("-38"),
    PS256("-37"),
    ES512("-36"),
    ES384("-35"),
    RS512("-259"),
    RS384("-258"),
    RS256("-257");

    public String algorithm;

    private static final Map<String, COSEAlgorithmIdentifier> COSEAlgorithmIdentifierMap = new HashMap<String, COSEAlgorithmIdentifier>();

    static {

        for (final COSEAlgorithmIdentifier algorithmIdentifier : values()) {
            COSEAlgorithmIdentifierMap.put(algorithmIdentifier.getAlgorithm(), algorithmIdentifier);
        }

    }

    /**
     * @param algorithm
     */
    private COSEAlgorithmIdentifier(final String algorithm) {
        this.algorithm = algorithm;
    }

    /**
     * @return the algorithm
     */
    public String getAlgorithm() {
        return algorithm;
    }

    /**
     * @return
     */
    public static Map<String, COSEAlgorithmIdentifier> getCOSEAlgorithmIdentifierMap() {
        return COSEAlgorithmIdentifierMap;
    }

    /**
     * @param algorithmIdentifier
     * @return
     */
    public static COSEAlgorithmIdentifier getCOSEAlgorithmIdentifier(final String algorithmIdentifier) {

        return COSEAlgorithmIdentifierMap.get(algorithmIdentifier);
    }
}
