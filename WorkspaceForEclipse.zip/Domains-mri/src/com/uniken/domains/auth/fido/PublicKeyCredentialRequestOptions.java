package com.uniken.domains.auth.fido;

import java.io.Serializable;
import java.util.List;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.auth.fido.enums.UserVerificationRequirement;

/**
 * FIDO2 Authentication Request POJO Refer
 * https://www.w3.org/TR/webauthn-2/#dictdef-publickeycredentialrequestoptions
 * 
 * @author Uniken Inc.
 */
public class PublicKeyCredentialRequestOptions
        implements
        Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 7523316912349999159L;
    public static final String CHALLENGE_STR = "challenge";
    public static final String TIMEOUT_STR = "timeout";
    public static final String ALLOW_CREDENTIALS_STR = "allowCredentials";
    public static final String USERVERIFICATION_STR = "userVerification";
    public static final String AUTHENTICATION_EXTENSIONS_CLIENT_INPUTS_STR = "extensions";

    @SerializedName(CHALLENGE_STR)
    @Field(CHALLENGE_STR)
    String challenge;

    @SerializedName(TIMEOUT_STR)
    @Field(TIMEOUT_STR)
    long timeout;

    @SerializedName(ALLOW_CREDENTIALS_STR)
    @Field(ALLOW_CREDENTIALS_STR)
    List<PublicKeyCredentialDescriptor> allowCredentials;

    @SerializedName(USERVERIFICATION_STR)
    @Field(USERVERIFICATION_STR)
    UserVerificationRequirement userVerification = UserVerificationRequirement.preferred;

    @SerializedName(AUTHENTICATION_EXTENSIONS_CLIENT_INPUTS_STR)
    @Field(AUTHENTICATION_EXTENSIONS_CLIENT_INPUTS_STR)
    AuthenticationExtensionsClientInputs extensions;

    public String getChallenge() {
        return challenge;
    }

    public void setChallenge(final String challenge) {
        this.challenge = challenge;
    }

    public long getTimeout() {
        return timeout;
    }

    public void setTimeout(final long timeout) {
        this.timeout = timeout;
    }

    public List<PublicKeyCredentialDescriptor> getAllowCredentials() {
        return allowCredentials;
    }

    public void setAllowCredentials(final List<PublicKeyCredentialDescriptor> allowCredentials) {
        this.allowCredentials = allowCredentials;
    }

    public UserVerificationRequirement getUserVerification() {
        return userVerification;
    }

    public void setUserVerification(final UserVerificationRequirement userVerification) {
        this.userVerification = userVerification;
    }

    public AuthenticationExtensionsClientInputs getExtensions() {
        return extensions;
    }

    public void setExtensions(final AuthenticationExtensionsClientInputs extensions) {
        this.extensions = extensions;
    }

    public static Document getBsonDocument(final PublicKeyCredentialRequestOptions credentialCreationRequestOptions) {

        if (null == credentialCreationRequestOptions) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != credentialCreationRequestOptions.getChallenge()) {
            logsDoc.append(CHALLENGE_STR, credentialCreationRequestOptions.getChallenge());
        }

        logsDoc.append(TIMEOUT_STR, credentialCreationRequestOptions.getTimeout());

        if (null != credentialCreationRequestOptions.getAllowCredentials()) {
            logsDoc.append(ALLOW_CREDENTIALS_STR, PublicKeyCredentialDescriptor
                    .getBsonDocuments(credentialCreationRequestOptions.getAllowCredentials()));
        }

        if (null != credentialCreationRequestOptions.getUserVerification()) {
            logsDoc.append(USERVERIFICATION_STR, credentialCreationRequestOptions.getUserVerification().name());
        }

        if (null != credentialCreationRequestOptions.getExtensions()) {
            logsDoc.append(AUTHENTICATION_EXTENSIONS_CLIENT_INPUTS_STR,
                    credentialCreationRequestOptions.getExtensions().getExtensions());
        }

        return logsDoc;
    }
}
