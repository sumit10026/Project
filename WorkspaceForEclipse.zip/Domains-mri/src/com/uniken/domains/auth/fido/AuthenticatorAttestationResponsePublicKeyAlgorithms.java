package com.uniken.domains.auth.fido;

import java.io.Serializable;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * @author Uniken Inc.
 */
public class AuthenticatorAttestationResponsePublicKeyAlgorithms
        implements
        Serializable {

    public static final String AUTHENTICATOR_ATTESTATION_RESPONSE_PUBLICKEY_ALGORITHMS_STR = "getPublicKeyAlgorithm";

    @SerializedName(AUTHENTICATOR_ATTESTATION_RESPONSE_PUBLICKEY_ALGORITHMS_STR)
    @Field(AUTHENTICATOR_ATTESTATION_RESPONSE_PUBLICKEY_ALGORITHMS_STR)
    String authenticatorAttestationPublicKeyAlgorithms;

    public String getAuthenticatorAttestationPublicKeyAlgorithms() {
        return authenticatorAttestationPublicKeyAlgorithms;
    }

    public void setgetAuthenticatorAttestationPublicKeyAlgorithms(
            final String authenticatorAttestationPublicKeyAlgorithms) {
        this.authenticatorAttestationPublicKeyAlgorithms = authenticatorAttestationPublicKeyAlgorithms;
    }

    public static Document getBsonDocument(
            final AuthenticatorAttestationResponsePublicKeyAlgorithms authenticatorAttestationPublicKeyAlgorithms) {

        if (null == authenticatorAttestationPublicKeyAlgorithms) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != authenticatorAttestationPublicKeyAlgorithms) {
            logsDoc.append(AUTHENTICATOR_ATTESTATION_RESPONSE_PUBLICKEY_ALGORITHMS_STR,
                    authenticatorAttestationPublicKeyAlgorithms.getAuthenticatorAttestationPublicKeyAlgorithms());
        }

        return logsDoc;
    }
}
