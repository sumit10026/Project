package com.uniken.domains.auth.fido;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * https://www.w3.org/TR/webauthn-2/#dictdef-authenticationextensionsclientinputs
 * 
 * @author Uniken Inc.
 */
public class AuthenticationExtensionsClientInputs {

    public static final String EXTENSIONS_STR = "extensions";

    @SerializedName(EXTENSIONS_STR)
    @Field(EXTENSIONS_STR)
    public String extensions;

    public String getExtensions() {
        return extensions;
    }

    public void setExtensions(final String extensions) {
        this.extensions = extensions;
    }

}
