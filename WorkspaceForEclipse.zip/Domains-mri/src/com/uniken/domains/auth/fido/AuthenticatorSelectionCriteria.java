package com.uniken.domains.auth.fido;

import java.io.Serializable;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.auth.fido.enums.AuthenticatorAttachment;
import com.uniken.domains.auth.fido.enums.ResidentKeyRequirement;
import com.uniken.domains.auth.fido.enums.UserVerificationRequirement;

/**
 * https://www.w3.org/TR/webauthn-2/#dictdef-authenticatorselectioncriteria
 * 
 * @author Uniken Inc.
 */
public class AuthenticatorSelectionCriteria
        implements
        Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 7391594988366313249L;
    public static final String AUTHENTICATOR_ATTACHMENT_STR = "authenticatorAttachment";
    public static final String RESIDENT_KEY_STR = "residentKey";
    public static final String REQUIRE_RESIDENT_KEY_STR = "requireResidentKey";
    public static final String USERVERIFICATION_STR = "userVerification";

    @SerializedName(AUTHENTICATOR_ATTACHMENT_STR)
    @Field(AUTHENTICATOR_ATTACHMENT_STR)
    AuthenticatorAttachment authenticatorAttachment;

    @SerializedName(RESIDENT_KEY_STR)
    @Field(RESIDENT_KEY_STR)
    ResidentKeyRequirement residentKey;

    @SerializedName(REQUIRE_RESIDENT_KEY_STR)
    @Field(REQUIRE_RESIDENT_KEY_STR)
    boolean requireResidentKey = false;

    @SerializedName(USERVERIFICATION_STR)
    @Field(USERVERIFICATION_STR)
    UserVerificationRequirement userVerification = UserVerificationRequirement.preferred;

    public AuthenticatorAttachment getAuthenticatorAttachment() {
        return authenticatorAttachment;
    }

    public void setAuthenticatorAttachment(final AuthenticatorAttachment authenticatorAttachment) {
        this.authenticatorAttachment = authenticatorAttachment;
    }

    public ResidentKeyRequirement getResidentKey() {
        return residentKey;
    }

    public void setResidentKey(final ResidentKeyRequirement residentKey) {
        this.residentKey = residentKey;
    }

    public boolean isRequireResidentKey() {
        return requireResidentKey;
    }

    public void setRequireResidentKey(final boolean requireResidentKey) {
        this.requireResidentKey = requireResidentKey;
        if (requireResidentKey) {
            residentKey = ResidentKeyRequirement.required;
        } else {
            residentKey = ResidentKeyRequirement.discouraged;
        }
    }

    public UserVerificationRequirement getUserVerification() {
        return userVerification;
    }

    public void setUserVerification(final UserVerificationRequirement userVerification) {
        this.userVerification = userVerification;
    }

    public static Document getBsonDocument(final AuthenticatorSelectionCriteria authenticatorSelectionCriteria) {
        if (null == authenticatorSelectionCriteria) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != authenticatorSelectionCriteria.getAuthenticatorAttachment()) {
            logsDoc.append(AUTHENTICATOR_ATTACHMENT_STR,
                    authenticatorSelectionCriteria.getAuthenticatorAttachment().name());
        }

        if (null != authenticatorSelectionCriteria.getResidentKey()) {
            logsDoc.append(RESIDENT_KEY_STR, authenticatorSelectionCriteria.getResidentKey().name());
        }

        logsDoc.append(REQUIRE_RESIDENT_KEY_STR, authenticatorSelectionCriteria.isRequireResidentKey());

        if (null != authenticatorSelectionCriteria.getUserVerification()) {
            logsDoc.append(USERVERIFICATION_STR, authenticatorSelectionCriteria.getUserVerification().name());
        }

        return logsDoc;
    }
}
