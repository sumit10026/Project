package com.uniken.domains.auth.fido.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * Reference : https://www.w3.org/TR/webauthn-2/#enumdef-residentkeyrequirement
 * 
 * @author Uniken Inc.
 */
public enum ResidentKeyRequirement {
    discouraged("discouraged"), preferred("preferred"), required("required");

    public String rk;

    private static final Map<String, ResidentKeyRequirement> ResidentKeyRequirementMap = new HashMap<String, ResidentKeyRequirement>();

    static {

        for (final ResidentKeyRequirement userResidentKeyRequirement : values()) {
            ResidentKeyRequirementMap.put(userResidentKeyRequirement.getResidentKeyRequirement(),
                    userResidentKeyRequirement);
        }

    }

    private ResidentKeyRequirement(final String rk) {
        this.rk = rk;
    }

    public String getResidentKeyRequirement() {
        return this.rk;
    }

    /**
     * @return
     */
    public static Map<String, ResidentKeyRequirement> getUserVerificationRequirementMap() {
        return ResidentKeyRequirementMap;
    }

    /**
     * @param ResidentKeyRequirement
     * @return
     */
    public static ResidentKeyRequirement getResidentKeyRequirement(final String rk) {

        return ResidentKeyRequirementMap.get(rk);
    }
}
