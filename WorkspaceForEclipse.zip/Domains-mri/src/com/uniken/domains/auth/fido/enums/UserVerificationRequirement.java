package com.uniken.domains.auth.fido.enums;

import java.util.HashMap;
import java.util.Map;

/**
 * Reference :
 * https://www.w3.org/TR/webauthn-2/#enumdef-userverificationrequirement
 * 
 * @author Uniken Inc.
 */
public enum UserVerificationRequirement {
    required("required"), preferred("preferred"), discouraged("discouraged");

    public String uv;

    private static final Map<String, UserVerificationRequirement> UserVerificationRequirementMap = new HashMap<String, UserVerificationRequirement>();

    static {

        for (final UserVerificationRequirement userVerificationRequirement : values()) {
            UserVerificationRequirementMap.put(userVerificationRequirement.getUserVerificationRequirement(),
                    userVerificationRequirement);
        }

    }

    private UserVerificationRequirement(final String uv) {
        this.uv = uv;
    }

    public String getUserVerificationRequirement() {
        return this.uv;
    }

    /**
     * @return
     */
    public static Map<String, UserVerificationRequirement> getUserVerificationRequirementMap() {
        return UserVerificationRequirementMap;
    }

    /**
     * @param UserVerificationRequirement
     * @return
     */
    public static UserVerificationRequirement getAuthenticatorTransport(final String uv) {

        return UserVerificationRequirementMap.get(uv);
    }
}
