package com.uniken.domains.auth.fido;

import java.io.Serializable;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * Reference :
 * https://www.w3.org/TR/webauthn-2/#dictdef-publickeycredentialuserentity
 * 
 * @author Uniken Inc.
 */
public class PublicKeyCredentialUserEntity
        implements
        Serializable {
    /**
     * 
     */
    private static final long serialVersionUID = 6726579026135015085L;
    public static final String ID_STR = "id";
    public static final String NAME_STR = "name";
    public static final String DISPLAY_NAME_STR = "displayName";

    @SerializedName(ID_STR)
    @Field(ID_STR)
    public String id;

    @SerializedName(NAME_STR)
    @Field(NAME_STR)
    public String name;

    @SerializedName(DISPLAY_NAME_STR)
    @Field(DISPLAY_NAME_STR)
    public String displayName;

    public String getId() {
        return id;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(final String displayName) {
        this.displayName = displayName;
    }

    public static Document getBsonDocument(final PublicKeyCredentialUserEntity user) {
        if (null == user) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != user.getId()) {
            logsDoc.append(ID_STR, user.getId());
        }

        if (null != user.getName()) {
            logsDoc.append(NAME_STR, user.getName());
        }

        if (null != user.getDisplayName()) {
            logsDoc.append(DISPLAY_NAME_STR, user.getDisplayName());
        }

        return logsDoc;
    }
}
