package com.uniken.domains.auth.fido;

import java.io.Serializable;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * Reference :
 * https://www.w3.org/TR/webauthn-2/#dictdef-publickeycredentialrpentity
 * 
 * @author Uniken Inc.
 */
public class PublicKeyCredentialRpEntity
        implements
        Serializable {
    public final static String ID_STR = "id";
    public final static String NAME_STR = "name";

    @SerializedName(ID_STR)
    @Field(ID_STR)
    String id;

    @SerializedName(NAME_STR)
    @Field(NAME_STR)
    String name;

    public String getId() {
        return id;
    }

    public void setId(final String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(final String name) {
        this.name = name;
    }

    public static Document getBsonDocument(final PublicKeyCredentialRpEntity rp) {
        if (rp == null) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != rp.getId()) {
            logsDoc.append(ID_STR, rp.getId());
        }

        if (null != rp.getName()) {
            logsDoc.append(NAME_STR, rp.getName());
        }

        return logsDoc;

    }

}
