package com.uniken.domains.auth.fido;

import java.io.Serializable;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * @author Uniken Inc.
 */
public class AuthenticatorData
        implements
        Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 7123819338758577289L;

    public static final String AUTHENTICATOR_DATA_STR = "getAuthenticatorData";

    @SerializedName(AUTHENTICATOR_DATA_STR)
    @Field(AUTHENTICATOR_DATA_STR)
    String authenticatorData;

    public String getAuthenticatorData() {
        return authenticatorData;
    }

    public void setAuthenticatorData(final String authenticatorData) {
        this.authenticatorData = authenticatorData;
    }

    public static Document getBsonDocument(final AuthenticatorData authenticatorData) {

        if (null == authenticatorData) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != authenticatorData) {
            logsDoc.append(AUTHENTICATOR_DATA_STR, authenticatorData.getAuthenticatorData());
        }

        return logsDoc;
    }
}
