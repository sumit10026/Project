package com.uniken.domains.auth.fido;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.auth.fido.enums.COSEAlgorithmIdentifier;

/**
 * Reference :
 * https://www.w3.org/TR/webauthn-2/#dictdef-publickeycredentialparameters
 * 
 * @author Uniken Inc.
 */
public class PublicKeyCredentialParameters
        implements
        Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 3129088702299945322L;
    public static final String TYPE_STR = "type";
    public static final String ALGORITHM_STR = "alg";

    @SerializedName(TYPE_STR)
    @Field(TYPE_STR)
    String type;

    @SerializedName(ALGORITHM_STR)
    @Field(ALGORITHM_STR)
    Integer alg;

    public String getType() {
        return type;
    }

    public void setType(final String type) {
        this.type = type;
    }

    public Integer getAlg() {
        return alg;
    }

    public void setAlg(final Integer alg) {
        this.alg = alg;
    }

    public static Document getBsonDocument(final PublicKeyCredentialParameters publicKeyCredentialParameter) {
        if (null == publicKeyCredentialParameter) {
            return null;
        }

        final Document logsDoc = new Document();

        if (null != publicKeyCredentialParameter.getType()) {
            logsDoc.append(TYPE_STR, publicKeyCredentialParameter.getType());
        }

        logsDoc.append(ALGORITHM_STR, COSEAlgorithmIdentifier
                .getCOSEAlgorithmIdentifier((String.valueOf(publicKeyCredentialParameter.getAlg()))));

        return logsDoc;
    }

    public static List<Document> getBsonDocuments(
            final List<PublicKeyCredentialParameters> publicKeyCredentialParameters) {

        final List<Document> documents = new ArrayList<>();

        for (final PublicKeyCredentialParameters publicKeyCredentialParameter : publicKeyCredentialParameters) {
            documents.add(PublicKeyCredentialParameters.getBsonDocument(publicKeyCredentialParameter));
        }

        return documents;
    }
}
