/**
 * 
 */
package com.uniken.domains.auth;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.enums.auth.TokenStatus;

/**
 * Custom Access Token for OAuth2.0
 * 
 * @author Kushal Jaiswal
 */
@Document(collection = "oauth_access_token_log")
public class CustomOAuth2AccessTokenLog extends CustomOAuth2AccessToken {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public static final String STATUS_KEY = "status";
    public static final String ARCHIVED_TS_KEY = "archived_ts";
    public static final String ARCHIVED_TS_STR_KEY = "archived_ts_str";

    @Field(STATUS_KEY)
    @SerializedName(value = STATUS_KEY)
    private TokenStatus tokenStatus;

    @Field(ARCHIVED_TS_KEY)
    @SerializedName(value = ARCHIVED_TS_KEY)
    private Date archivedTS;

    @Field(ARCHIVED_TS_STR_KEY)
    @SerializedName(value = ARCHIVED_TS_STR_KEY)
    private String archivedTSStr;

    /**
     * @param accessToken
     * @param authentication
     * @param authenticationId
     */
    private CustomOAuth2AccessTokenLog(final CustomOAuth2AccessToken accessToken, final TokenStatus tokenStatus,
            final Date archivedTS) {

        super(accessToken, accessToken.getAuthentication(), accessToken.getAuthenticationId());
        this.tokenStatus = tokenStatus;
        this.archivedTS = archivedTS;

    }

    /**
     * Get's the instance of {@link CustomOAuth2AccessTokenLog} with status as
     * Expired
     * 
     * @param accessToken
     *            the accessToken
     * @param archivedTS
     *            the archived time stamp.
     * @return the CustomOAuth2AccessTokenLog instance.
     */
    public static CustomOAuth2AccessTokenLog getInstanceOfExpiredAccessTokenLog(
            final CustomOAuth2AccessToken accessToken, final Date archivedTS) {

        return new CustomOAuth2AccessTokenLog(accessToken, TokenStatus.EXPIRED, archivedTS);

    }

    /**
     * Get's the instance of {@link CustomOAuth2AccessTokenLog} with status as
     * Revoked
     * 
     * @param accessToken
     *            the accessToken
     * @param archivedTS
     *            the archived time stamp.
     * @return the CustomOAuth2AccessTokenLog instance.
     */
    public static CustomOAuth2AccessTokenLog getInstanceOfRevokedAccessTokenLog(
            final CustomOAuth2AccessToken accessToken, final Date archivedTS) {

        return new CustomOAuth2AccessTokenLog(accessToken, TokenStatus.REVOKED, archivedTS);

    }

    /**
     * @return the tokenStatus
     */
    public TokenStatus getTokenStatus() {
        return tokenStatus;
    }

    /**
     * @param tokenStatus
     *            the tokenStatus to set
     */
    public void setTokenStatus(final TokenStatus tokenStatus) {
        this.tokenStatus = tokenStatus;
    }

    /**
     * @return the archivedTS
     */
    public Date getArchivedTS() {
        return archivedTS;
    }

    /**
     * @param archivedTS
     *            the archivedTS to set
     */
    public void setArchivedTS(final Date archivedTS) {
        this.archivedTS = archivedTS;
    }

    /**
     * @return the archivedTSStr
     */
    public String getArchivedTSStr() {
        return archivedTSStr;
    }

    /**
     * @param archivedTSStr
     *            the archivedTSStr to set
     */
    public void setArchivedTSStr(final String archivedTSStr) {
        this.archivedTSStr = archivedTSStr;
    }

    @Override
    public void parseDateToString(final String dateFormat) {

        super.parseDateToString(dateFormat);

        final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        if (null != this.archivedTS) {
            this.archivedTSStr = sdf.format(this.archivedTS);
        }
    }

}
