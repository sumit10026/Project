/**
 * 
 */
package com.uniken.domains.auth;

import com.google.gson.annotations.SerializedName;

/**
 * @author Kushal Jaiswal
 */
public class AccessTokenRequest {

    public static final String USER_ID_STR = "user_id";
    public static final String SESSION_ID_STR = "session_id";
    public static final String APP_SESSION_ID_STR = "app_session_id";
    public static final String APP_AGENT_NAME_STR = "app_id";
    public static final String MTD_STATUS_STR = "mtd_status";
    public static final String REVOKE_TOKEN_STR = "revoke_token";
    public static final String REFRESH_TOKEN_STR = "refresh_token";
    public static final String APP_UUID_STR = "app_uuid";

    @SerializedName(USER_ID_STR)
    private final String userId;

    @SerializedName(SESSION_ID_STR)
    private final String sessionId;

    @SerializedName(APP_SESSION_ID_STR)
    private final String appSessionId;

    @SerializedName(APP_AGENT_NAME_STR)
    private final String appAgentName;

    @SerializedName(MTD_STATUS_STR)
    private String mtdStatus;

    @SerializedName(REFRESH_TOKEN_STR)
    private String refreshToken;

    @SerializedName(REVOKE_TOKEN_STR)
    private String revokeToken;

    @SerializedName(APP_UUID_STR)
    private final String appUuid;

    /**
     * @param userId
     * @param sessionId
     * @param appSessionId
     * @param appAgentName
     * @param appUuid
     *            the app uuid
     * @param mtdStatus
     */
    private AccessTokenRequest(final String userId, final String sessionId, final String appSessionId,
            final String appAgentName, final String appUuid) {
        this.userId = userId;
        this.sessionId = sessionId;
        this.appSessionId = appSessionId;
        this.appAgentName = appAgentName;
        this.appUuid = appUuid;
    }

    /**
     * Get instances of AccessTokenRequest of type refresh token request.
     * 
     * @param userId
     * @param sessionId
     * @param appSessionId
     * @param appAgentName
     * @param appUuid
     * @param refreshToken
     * @return {@link AccessTokenRequest}
     */
    public AccessTokenRequest getInstanceOfRefreshTokenExchangeRequest(final String userId, final String sessionId,
            final String appSessionId, final String appAgentName, final String appUuid, final String refreshToken) {

        final AccessTokenRequest tokenRequest = new AccessTokenRequest(userId, sessionId, appSessionId, appAgentName,
                appUuid);
        tokenRequest.setRefreshToken(refreshToken);

        return tokenRequest;

    }

    /**
     * Get instances of AccessToken request of type revoke token request.
     * 
     * @param userId
     * @param sessionId
     * @param appSessionId
     * @param appAgentName
     * @param appUuid
     * @param revokeToken
     * @return {@link AccessTokenRequest}
     */
    public AccessTokenRequest getInstanceOfRevokeTokenRequest(final String userId, final String sessionId,
            final String appSessionId, final String appAgentName, final String appUuid, final String revokeToken) {

        final AccessTokenRequest tokenRequest = new AccessTokenRequest(userId, sessionId, appSessionId, appAgentName,
                appUuid);

        tokenRequest.setRevokeToken(revokeToken);

        return tokenRequest;

    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @return the sessionId
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * @return the appSessionId
     */
    public String getAppSessionId() {
        return appSessionId;
    }

    /**
     * @return the appAgentName
     */
    public String getAppAgentName() {
        return appAgentName;
    }

    /**
     * @param mtdStatus
     *            the mtdStatus to set
     */
    public void setMtdStatus(final String mtdStatus) {
        this.mtdStatus = mtdStatus;
    }

    /**
     * @return the mtdStatus
     */
    public String getMtdStatus() {
        return mtdStatus;
    }

    /**
     * @return the revokeToken
     */
    public String getRevokeToken() {
        return revokeToken;
    }

    /**
     * @return the refreshToken
     */
    public String getRefreshToken() {
        return refreshToken;
    }

    /**
     * @param refreshToken
     *            the refreshToken to set
     */
    public void setRefreshToken(final String refreshToken) {
        this.refreshToken = refreshToken;
    }

    /**
     * @param revokeToken
     *            the revokeToken to set
     */
    public void setRevokeToken(final String revokeToken) {
        this.revokeToken = revokeToken;
    }

    /**
     * @return the appUuid
     */
    public String getAppUuid() {
        return appUuid;
    }

}
