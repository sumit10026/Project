package com.uniken.domains.auth;

import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

@Document(collection = "app_ent_mapping")
public class AppAgentEnterpriseMapping {

    public static final String ID = "_id";
    public static final String APP_AGENT_UUID = "app_uuid";
    public static final String APP_AGENT_ID = "app_id";
    public static final String ENTERPRISE_ID = "enterprise_id";
    public static final String UPDATE_TS = "update_ts";
    public static final String CREATE_TS = "create_ts";
    public static final String ENTERPRISE_NOTIFICATION_MESSAGE = "enterprise_notification_message";

    @SerializedName(ID)
    @Field(ID)
    private ObjectId id;

    @SerializedName(APP_AGENT_UUID)
    @Field(APP_AGENT_UUID)
    private String appUuid;

    @SerializedName(APP_AGENT_ID)
    @Field(APP_AGENT_ID)
    private String appId;

    @SerializedName(ENTERPRISE_ID)
    @Field(ENTERPRISE_ID)
    private String enterpriseId;

    @SerializedName(CREATE_TS)
    @Field(CREATE_TS)
    private Date createTimestamp;

    @SerializedName(UPDATE_TS)
    @Field(UPDATE_TS)
    private Date updateTimestamp;

    @SerializedName(ENTERPRISE_NOTIFICATION_MESSAGE)
    @Field(ENTERPRISE_NOTIFICATION_MESSAGE)
    private String enterpriseNotificationMessage;

    /**
     * Gets the id.
     *
     * @return the id
     */
    public ObjectId getId() {
        return id;
    }

    /**
     * Sets the id.
     *
     * @param id
     *            the id to set
     */
    public void setId(final ObjectId id) {
        this.id = id;
    }

    /**
     * Gets the app uuid.
     *
     * @return the appUuid
     */
    public String getAppUuid() {
        return appUuid;
    }

    /**
     * Sets the app uuid.
     *
     * @param appUuid
     *            the appUuid to set
     */
    public void setAppUuid(final String appUuid) {
        this.appUuid = appUuid;
    }

    /**
     * Gets the app id.
     *
     * @return the appId
     */
    public String getAppId() {
        return appId;
    }

    /**
     * Sets the app id.
     *
     * @param appId
     *            the appId to set
     */
    public void setAppId(final String appId) {
        this.appId = appId;
    }

    /**
     * Gets the enterprise id.
     *
     * @return the enterpriseId
     */
    public String getEnterpriseId() {
        return enterpriseId;
    }

    /**
     * Sets the enterprise id.
     *
     * @param enterpriseId
     *            the enterpriseId to set
     */
    public void setEnterpriseId(final String enterpriseId) {
        this.enterpriseId = enterpriseId;
    }

    /**
     * Gets the creates the timestamp.
     *
     * @return the createTimestamp
     */
    public Date getCreateTimestamp() {
        return createTimestamp;
    }

    /**
     * Sets the creates the timestamp.
     *
     * @param createTimestamp
     *            the createTimestamp to set
     */
    public void setCreateTimestamp(final Date createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    /**
     * Gets the update timestamp.
     *
     * @return the updateTimestamp
     */
    public Date getUpdateTimestamp() {
        return updateTimestamp;
    }

    /**
     * Sets the update timestamp.
     *
     * @param updateTimestamp
     *            the updateTimestamp to set
     */
    public void setUpdateTimestamp(final Date updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

    /**
     * Gets the enterprise notification message.
     *
     * @return the enterprise notification message
     */
    public String getEnterpriseNotificationMessage() {
        return enterpriseNotificationMessage;
    }

    /**
     * Sets the enterprise notification message.
     *
     * @param enterpriseNotificationMessage
     *            the new enterprise notification message
     */
    public void setEnterpriseNotificationMessage(final String enterpriseNotificationMessage) {
        this.enterpriseNotificationMessage = enterpriseNotificationMessage;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("AppAgentEnterpriseMapping [id=");
        builder.append(id);
        builder.append(", appUuid=");
        builder.append(appUuid);
        builder.append(", appId=");
        builder.append(appId);
        builder.append(", enterpriseId=");
        builder.append(enterpriseId);
        builder.append(", createTimestamp=");
        builder.append(createTimestamp);
        builder.append(", updateTimestamp=");
        builder.append(updateTimestamp);
        builder.append(", enterpriseNotificationMessage=");
        builder.append(enterpriseNotificationMessage);
        builder.append("]");
        return builder.toString();
    }

}
