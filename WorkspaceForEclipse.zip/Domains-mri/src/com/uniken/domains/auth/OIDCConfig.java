package com.uniken.domains.auth;

import org.springframework.data.mongodb.core.mapping.Document;

import com.uniken.domains.relid.LogDomain;

@Document(collection = "oidc_config")
public class OIDCConfig extends LogDomain {

    public static final String APP_AGENT_NAME = "appAgentName";

    private String appAgentName;
    private String appAgentUuid;
    private JWTConfig jwtConfig;

    /**
     * @return the appAgentName
     */
    public String getAppAgentName() {
        return appAgentName;
    }

    /**
     * @param appAgentName
     *            the appAgentName to set
     */
    public void setAppAgentName(final String appAgentName) {
        this.appAgentName = appAgentName;
    }

    /**
     * @return the appAgentUuid
     */
    public String getAppAgentUuid() {
        return appAgentUuid;
    }

    /**
     * @param appAgentUuid
     *            the appAgentUuid to set
     */
    public void setAppAgentUuid(final String appAgentUuid) {
        this.appAgentUuid = appAgentUuid;
    }

    /**
     * @return the jwtConfig
     */
    public JWTConfig getJwtConfig() {
        return jwtConfig;
    }

    /**
     * @param jwtConfig
     *            the jwtConfig to set
     */
    public void setJwtConfig(final JWTConfig jwtConfig) {
        this.jwtConfig = jwtConfig;
    }

    /*
     * (non-Javadoc)
     * @see java.lang.Object#toString()
     */
    @Override
    public String toString() {
        final StringBuilder builder = new StringBuilder();
        builder.append("OIDCConfig [appAgentName=");
        builder.append(appAgentName);
        builder.append(", appAgentUuid=");
        builder.append(appAgentUuid);
        builder.append(", jwtConfig=");
        builder.append(jwtConfig);
        builder.append("]");
        return builder.toString();
    }

}
