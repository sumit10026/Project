/**
 * 
 */
package com.uniken.domains.auth;

import java.io.Serializable;
import java.util.Date;

import org.bson.types.ObjectId;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;
import org.springframework.security.oauth2.common.DefaultExpiringOAuth2RefreshToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.util.OAuthUtils;

/**
 * Custom Refresh Token for OAuth2.0
 * 
 * @author Kushal Jaiswal
 */
@Document(collection = "oauth_refresh_token")
public class CustomOAuth2RefreshToken extends DefaultExpiringOAuth2RefreshToken
        implements
        Serializable {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public static final String TOKEN_ID_KEY = "tokenId";
    public static final String AUTHENTICATION_KEY = "authentication";
    public static final String CREATED_TS_KEY = "created_ts";
    public static final String REQUESTOR_ID_KEY = "requestorId";

    @Id
    private ObjectId id;

    @Field(TOKEN_ID_KEY)
    @SerializedName(TOKEN_ID_KEY)
    @Indexed(name = TOKEN_ID_KEY, unique = true)
    private String tokenId;

    @Field(AUTHENTICATION_KEY)
    @SerializedName(AUTHENTICATION_KEY)
    private OAuth2Authentication authentication;

    @Field(CREATED_TS_KEY)
    @SerializedName(CREATED_TS_KEY)
    private Date createdTS;

    @SerializedName(REQUESTOR_ID_KEY)
    @Field(REQUESTOR_ID_KEY)
    private String requestorId;

    /**
     * Default Constructor to get {@link CustomOAuth2RefreshToken} object.
     * <strong>Note: Make sure you should set token id as well</strong>
     * 
     * @param token
     * @param expiration
     */
    public CustomOAuth2RefreshToken(final String token, final Date expiration,
            final OAuth2Authentication authentication, final Date createdTS, final String requestorId) {

        super(token, expiration);
        this.setAuthentication(authentication);
        this.setTokenId(OAuthUtils.extractTokenKey(token));
        this.createdTS = createdTS;
        this.setRequestorId(requestorId);
    }

    /**
     * @return the id
     */
    public ObjectId getId() {
        return id;
    }

    /**
     * @param id
     *            the id to set
     */
    public void setId(final ObjectId id) {
        this.id = id;
    }

    /**
     * @return the tokenId
     */
    public String getTokenId() {
        return tokenId;
    }

    /**
     * @param tokenId
     *            the tokenId to set
     */
    public void setTokenId(final String tokenId) {
        this.tokenId = tokenId;
    }

    /**
     * @return the authentication
     */
    public OAuth2Authentication getAuthentication() {
        return authentication;
    }

    /**
     * @param authentication
     *            the authentication to set
     */
    public void setAuthentication(final OAuth2Authentication authentication) {
        this.authentication = authentication;
    }

    /**
     * @return the createdTS
     */
    public Date getCreatedTS() {
        return createdTS;
    }

    /**
     * @param createdTS
     *            the createdTS to set
     */
    public void setCreatedTS(final Date createdTS) {
        this.createdTS = createdTS;
    }

    /**
     * @return
     */
    public String getRequestorId() {
        return requestorId;
    }

    /**
     * @param requestorId
     */
    public void setRequestorId(final String requestorId) {
        this.requestorId = requestorId;
    }

}
