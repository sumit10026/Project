package com.uniken.domains.auth;

import java.util.Map;
import java.util.Set;

/**
 * The Class AuthenticationResponse.
 */
public class AuthenticationResponse {

    public static final String HTTP_RESPONSE_FIELD_KEY_ERROR = "error";
    public static final String HTTP_RESPONSE_FIELD_KEY_ERROR_DESCRIPTION = "error_description";

    private String accessToken;
    private boolean isAuthenticated;
    private Map<String, String> httpResponseHeaders;
    private int httpResponseStatusCode;
    private Map<String, String> httpResponseFields;
    private String clientId;
    private String clientName;
    private String username;
    private Set<String> scope;
    private Map<String, Object> introspectionClaims;

    /**
     * Gets the access token.
     *
     * @return the access token
     */
    public String getAccessToken() {
        return accessToken;
    }

    /**
     * Sets the access token.
     *
     * @param accessToken
     *            the new access token
     */
    public void setAccessToken(final String accessToken) {
        this.accessToken = accessToken;
    }

    /**
     * Checks if is authenticated.
     *
     * @return true, if is authenticated
     */
    public boolean isAuthenticated() {
        return isAuthenticated;
    }

    /**
     * Sets the authenticated.
     *
     * @param isAuthenticated
     *            the new authenticated
     */
    public void setAuthenticated(final boolean isAuthenticated) {
        this.isAuthenticated = isAuthenticated;
    }

    /**
     * Gets the http response headers.
     *
     * @return the http response headers
     */
    public Map<String, String> getHttpResponseHeaders() {
        return httpResponseHeaders;
    }

    /**
     * Sets the http response headers.
     *
     * @param httpResponseHeaders
     *            the http response headers
     */
    public void setHttpResponseHeaders(final Map<String, String> httpResponseHeaders) {
        this.httpResponseHeaders = httpResponseHeaders;
    }

    /**
     * Gets the http response status code.
     *
     * @return the http response status code
     */
    public int getHttpResponseStatusCode() {
        return httpResponseStatusCode;
    }

    /**
     * Sets the http response status code.
     *
     * @param httpResponseStatusCode
     *            the new http response status code
     */
    public void setHttpResponseStatusCode(final int httpResponseStatusCode) {
        this.httpResponseStatusCode = httpResponseStatusCode;
    }

    /**
     * Gets the http response fields.
     *
     * @return the http response fields
     */
    public Map<String, String> getHttpResponseFields() {
        return httpResponseFields;
    }

    /**
     * Sets the http response fields.
     *
     * @param httpResponseFields
     *            the http response fields
     */
    public void setHttpResponseFields(final Map<String, String> httpResponseFields) {
        this.httpResponseFields = httpResponseFields;
    }

    /**
     * Gets the client id.
     *
     * @return the client id
     */
    public String getClientId() {
        return clientId;
    }

    /**
     * Sets the client id.
     *
     * @param clientId
     *            the new client id
     */
    public void setClientId(final String clientId) {
        this.clientId = clientId;
    }

    /**
     * Gets the client name.
     *
     * @return the clientName
     */
    public String getClientName() {
        return clientName;
    }

    /**
     * Sets the client name.
     *
     * @param clientName
     *            the clientName to set
     */
    public void setClientName(final String clientName) {
        this.clientName = clientName;
    }

    /**
     * @return the username
     */
    public String getUsername() {
        return username;
    }

    /**
     * @param username
     *            the username to set
     */
    public void setUsername(final String username) {
        this.username = username;
    }

    /**
     * @return the scope
     */
    public Set<String> getScope() {
        return scope;
    }

    /**
     * @param scope
     *            the scope to set
     */
    public void setScope(final Set<String> scope) {
        this.scope = scope;
    }

    /**
     * @return the introspectionClaims
     */
    public Map<String, Object> getIntrospectionClaims() {
        return introspectionClaims;
    }

    /**
     * @param introspectionClaims
     *            the introspectionClaims to set
     */
    public void setIntrospectionClaims(final Map<String, Object> introspectionClaims) {
        this.introspectionClaims = introspectionClaims;
    }

}
