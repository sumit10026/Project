package com.uniken.domains.auth;

import java.util.List;

import com.google.gson.annotations.SerializedName;

public class AuthenticationInfoResponse {

    @SerializedName("data")
    private List<AuthenticationInfo> data;

    @SerializedName("response_code")
    private short responseCode;

    @SerializedName("error_code")
    private short errorCode;

    @SerializedName("error_msg")
    private String errorMsg;

    /**
     * @return the data
     */
    public List<AuthenticationInfo> getData() {
        return data;
    }

    /**
     * @param data
     *            the data to set
     */
    public void setData(final List<AuthenticationInfo> data) {
        this.data = data;
    }

    /**
     * @return the responseCode
     */
    public short getResponseCode() {
        return responseCode;
    }

    /**
     * @param responseCode
     *            the responseCode to set
     */
    public void setResponseCode(final short responseCode) {
        this.responseCode = responseCode;
    }

    /**
     * @return the errorCode
     */
    public short getErrorCode() {
        return errorCode;
    }

    /**
     * @param errorCode
     *            the errorCode to set
     */
    public void setErrorCode(final short errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * @return the errorMsg
     */
    public String getErrorMsg() {
        return errorMsg;
    }

    /**
     * @param errorMsg
     *            the errorMsg to set
     */
    public void setErrorMsg(final String errorMsg) {
        this.errorMsg = errorMsg;
    }

}
