package com.uniken.domains.reqresp;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.springframework.data.annotation.PersistenceConstructor;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

public class RequestResponseLoggingDomain {

    public static final String LOGID_STR = "log_id";
    public static final String LOGTYPE_STR = "log_type";
    public static final String SOURCEIP_STR = "source_ip";
    public static final String SOURCEPORT_STR = "source_port";
    public static final String URI_STR = "request_uri";
    public static final String LOGDATA_STR = "log_data";
    public static final String CREATEDTS_STR = "created_ts";
    public static final String MODULENAME_STR = "module_name";
    public static final String AUTHTYPE_STR = "auth_type";
    public static final String AUTHUSER_STR = "auth_user";
    public static final String USER_ID_STR = "user_id";
    public static final String CREATEDTSSTR_STR = "created_ts_str";

    @SerializedName(LOGID_STR)
    @Field(LOGID_STR)
    private final String logId;

    @SerializedName(LOGTYPE_STR)
    @Field(LOGTYPE_STR)
    private final String logType;

    @SerializedName(USER_ID_STR)
    @Field(USER_ID_STR)
    private final String userId;

    @SerializedName(SOURCEIP_STR)
    @Field(SOURCEIP_STR)
    private final String sourceIp;

    @SerializedName(SOURCEPORT_STR)
    @Field(SOURCEPORT_STR)
    private final int sourcePort;

    @SerializedName(URI_STR)
    @Field(URI_STR)
    private final String requestUri;

    @SerializedName(LOGDATA_STR)
    @Field(LOGDATA_STR)
    private final String logData;

    @SerializedName(MODULENAME_STR)
    @Field(MODULENAME_STR)
    private final String moduleName;

    @SerializedName(CREATEDTS_STR)
    @Field(CREATEDTS_STR)
    private final Date createdTs;

    @SerializedName(AUTHTYPE_STR)
    @Field(AUTHTYPE_STR)
    private final String authType;

    @SerializedName(AUTHUSER_STR)
    @Field(AUTHUSER_STR)
    private final String authUser;

    @SerializedName(CREATEDTSSTR_STR)
    @Field(CREATEDTSSTR_STR)
    private String createdTsStr;

    @PersistenceConstructor
    public RequestResponseLoggingDomain(final String logId, final String logType, final String sourceIp,
            final int sourcePort, final String requestUri, final String logData, final String moduleName,
            final Date createdTs, final String authType, final String authUser, final String userId) {
        this.logId = logId;
        this.logType = logType;
        this.sourceIp = sourceIp;
        this.sourcePort = sourcePort;
        this.requestUri = requestUri;
        this.logData = logData;
        this.moduleName = moduleName;
        this.createdTs = createdTs;
        this.authType = authType;
        this.authUser = authUser;
        this.userId = userId;
    }

    public RequestResponseLoggingDomain(final String logId, final String logType, final String sourceIp,
            final int sourcePort, final String requestUri, final String logData, final String moduleName,
            final String authType, final String authUser, final String userId) {
        this.logId = logId;
        this.logType = logType;
        this.sourceIp = sourceIp;
        this.sourcePort = sourcePort;
        this.requestUri = requestUri;
        this.logData = logData;
        this.moduleName = moduleName;
        this.createdTs = new Date();
        this.authType = authType;
        this.authUser = authUser;
        this.userId = userId;
    }

    public String getLogId() {
        return logId;
    }

    public String getLogType() {
        return logType;
    }

    public String getSourceIp() {
        return sourceIp;
    }

    public int getSourcePort() {
        return sourcePort;
    }

    public String getRequestUri() {
        return requestUri;
    }

    public String getLogData() {
        return logData;
    }

    public String getModuleName() {
        return moduleName;
    }

    public Date getCreatedTs() {
        return createdTs;
    }

    public String getAuthType() {
        return authType;
    }

    public String getAuthUser() {
        return authUser;
    }

    public String getUserId() {
        return userId;
    }

    public static Document getBsonDocument(final RequestResponseLoggingDomain requestResponseDomain) {

        final Document doc = new Document();

        if (requestResponseDomain == null) {
            return null;
        }

        if (requestResponseDomain.getLogId() != null) {
            doc.append(LOGID_STR, requestResponseDomain.getLogId());
        }

        if (requestResponseDomain.getLogType() != null) {
            doc.append(LOGTYPE_STR, requestResponseDomain.getLogType());
        }

        if (requestResponseDomain.getUserId() != null) {
            doc.append(USER_ID_STR, requestResponseDomain.getUserId());
        }

        if (requestResponseDomain.getLogData() != null) {
            doc.append(LOGDATA_STR, requestResponseDomain.getLogData());
        }

        if (requestResponseDomain.getModuleName() != null) {
            doc.append(MODULENAME_STR, requestResponseDomain.getModuleName());
        }

        if (requestResponseDomain.getRequestUri() != null) {
            doc.append(URI_STR, requestResponseDomain.getRequestUri());
        }

        if (requestResponseDomain.getSourceIp() != null) {
            doc.append(SOURCEIP_STR, requestResponseDomain.getSourceIp());
        }

        doc.append(SOURCEPORT_STR, requestResponseDomain.getSourcePort());

        if (requestResponseDomain.getAuthType() != null) {
            doc.append(AUTHTYPE_STR, requestResponseDomain.getAuthType());
        }

        if (requestResponseDomain.getAuthUser() != null) {
            doc.append(AUTHUSER_STR, requestResponseDomain.getAuthUser());
        }

        if (requestResponseDomain.getCreatedTs() != null) {
            doc.append(CREATEDTS_STR, requestResponseDomain.getCreatedTs());
        }

        return doc;
    }

    /**
     * Create Bson Document from the provided list of validation logs
     * 
     * @param devices
     *            list of Device object
     * @return
     */
    public static List<Document> getBsonDocuments(final List<RequestResponseLoggingDomain> requestResponseLogs) {

        final List<Document> documents = new ArrayList<Document>();

        for (final RequestResponseLoggingDomain requestResponseLog : requestResponseLogs) {
            documents.add(getBsonDocument(requestResponseLog));
        }

        return documents;

    }

    public String getCreatedTsStr() {
        return createdTsStr;
    }

    public void parseDateToString(final String dateFormat) {
        final SimpleDateFormat sdf = new SimpleDateFormat(dateFormat);

        if (null != this.createdTs)
            this.createdTsStr = sdf.format(this.createdTs);

    }

}
