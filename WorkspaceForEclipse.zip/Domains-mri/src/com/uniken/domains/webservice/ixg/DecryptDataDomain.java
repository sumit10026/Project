package com.uniken.domains.webservice.ixg;

import org.bson.Document;

import com.google.gson.annotations.SerializedName;

/**
 * Domain for decryption of data.
 * 
 * @author Abhijit Daund
 */
public class DecryptDataDomain extends EncDecDomain {

    public static final String IS_ENCRYPTED_TEXT_DATA_PACKET_STR = "isEncryptedTxtDataPacket";

    public static final String ENCRYPTED_DATA_STR = "encryptedData";

    @SerializedName(ENCRYPTED_DATA_STR)
    private String encryptedData;

    @SerializedName(IS_ENCRYPTED_TEXT_DATA_PACKET_STR)
    private Boolean isEncryptedTxtDataPacket;

    /**
     * @return the encryptedData
     */
    public String getEncryptedData() {
        return encryptedData;
    }

    /**
     * @param encryptedData
     *            the encryptedData to set
     */
    public void setEncryptedData(final String encryptedData) {
        this.encryptedData = encryptedData;
    }

    /**
     * @return the isEncryptedTxtDataPacket
     */
    public Boolean isEncryptedTxtDataPacket() {
        return isEncryptedTxtDataPacket;
    }

    /**
     * @param isEncryptedTxtDataPacket
     *            the isEncryptedTxtDataPacket to set
     */
    public void setEncryptedTxtDataPacket(final Boolean isEncryptedTxtDataPacket) {
        this.isEncryptedTxtDataPacket = isEncryptedTxtDataPacket;
    }

    /**
     * Gets the document form of given decryptDataDomain.
     * 
     * @param decryptDataDomain
     *            the decryptDataDomain
     * @return the document
     */
    public static Document getDocument(final DecryptDataDomain decryptDataDomain) {
        if (null == decryptDataDomain) {
            return null;
        }

        final Document document = EncDecDomain.getDocument(decryptDataDomain);

        if (null != decryptDataDomain.getEncryptedData()) {
            document.append(ENCRYPTED_DATA_STR, decryptDataDomain.getEncryptedData());
        }

        if (null != decryptDataDomain.isEncryptedTxtDataPacket()) {
            document.append(IS_ENCRYPTED_TEXT_DATA_PACKET_STR, decryptDataDomain.isEncryptedTxtDataPacket());
        }

        return document;
    }
}
