package com.uniken.domains.webservice.ixg;

import org.bson.Document;

import com.google.gson.annotations.SerializedName;

/**
 * Domain for encryption of data.
 * 
 * @author Abhijit Daund
 */
public class EncryptDataDomain extends EncDecDomain {

    public static final String PLAIN_DATA_STR = "plainData";

    @SerializedName(PLAIN_DATA_STR)
    private String plainData;

    /**
     * @return the plainData
     */
    public String getPlainData() {
        return plainData;
    }

    /**
     * @param plainData
     *            the plainData to set
     */
    public void setPlainData(final String plainData) {
        this.plainData = plainData;
    }

    /**
     * Gets the document form of given encryptDataDomain.
     * 
     * @param encryptDataDomain
     *            the encryptDataDomain
     * @return the document
     */
    public static Document getDocument(final EncryptDataDomain encryptDataDomain) {
        if (null == encryptDataDomain) {
            return null;
        }

        final Document document = EncDecDomain.getDocument(encryptDataDomain);

        if (null != encryptDataDomain.getPlainData()) {
            document.append(PLAIN_DATA_STR, encryptDataDomain.getPlainData());
        }

        return document;
    }
}
