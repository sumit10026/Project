package com.uniken.domains.webservice.ixg;

import org.bson.Document;

import com.google.gson.annotations.SerializedName;

/**
 * Super class for EncryptDataDomain and DecryptDataDomain.
 * 
 * @author Abhijit Daund
 */
abstract class EncDecDomain {

    public static final String KEY_ID_STR = "keyId";
    public static final String CIPHER_SALT_STR = "cipherSalt";
    public static final String CIPHER_SPEC_STR = "cipherSpec";
    public static final String EPRIVACY_SCOPE_STR = "ePrivacyScope";

    @SerializedName(KEY_ID_STR)
    private String keyId;

    @SerializedName(CIPHER_SALT_STR)
    private String cipherSalt;

    @SerializedName(CIPHER_SPEC_STR)
    private String cipherSpec;

    @SerializedName(EPRIVACY_SCOPE_STR)
    private String ePrivacyScope;

    /**
     * @return the keyId
     */
    public String getKeyId() {
        return keyId;
    }

    /**
     * @param keyId
     *            the keyId to set
     */
    public void setKeyId(final String keyId) {
        this.keyId = keyId;
    }

    /**
     * @return the cipherSalt
     */
    public String getCipherSalt() {
        return cipherSalt;
    }

    /**
     * @param cipherSalt
     *            the cipherSalt to set
     */
    public void setCipherSalt(final String cipherSalt) {
        this.cipherSalt = cipherSalt;
    }

    /**
     * @return the cipherSpec
     */
    public String getCipherSpec() {
        return cipherSpec;
    }

    /**
     * @param cipherSpec
     *            the cipherSpec to set
     */
    public void setCipherSpec(final String cipherSpec) {
        this.cipherSpec = cipherSpec;
    }

    /**
     * @return the ePrivacyScope
     */
    public String getEPrivacyScope() {
        return ePrivacyScope;
    }

    /**
     * @param ePrivacyScope
     *            the ePrivacyScope to set
     */
    public void setePrivacyScope(final String ePrivacyScope) {
        this.ePrivacyScope = ePrivacyScope;
    }

    /**
     * Gets the document form of given encDecDomain.
     * 
     * @param encDecDomain
     *            the encDecDomain
     * @return the document
     */
    public static Document getDocument(final EncDecDomain encDecDomain) {
        if (null == encDecDomain) {
            return null;
        }

        final Document document = new Document();

        if (null != encDecDomain.getKeyId()) {
            document.append(KEY_ID_STR, encDecDomain.getKeyId());
        }

        if (null != encDecDomain.getCipherSalt()) {
            document.append(CIPHER_SALT_STR, encDecDomain.getCipherSalt());
        }

        if (null != encDecDomain.getCipherSpec()) {
            document.append(CIPHER_SPEC_STR, encDecDomain.getCipherSpec());
        }

        if (null != encDecDomain.getEPrivacyScope()) {
            document.append(EPRIVACY_SCOPE_STR, encDecDomain.getEPrivacyScope());
        }

        return document;
    }
}
