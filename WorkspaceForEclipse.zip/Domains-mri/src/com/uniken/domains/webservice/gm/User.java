package com.uniken.domains.webservice.gm;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.google.gson.annotations.SerializedName;

/**
 * User domain class.
 * 
 * @author Abhijit Daund
 */
public class User {

    public static final String USER_NAME_STR = "userName";
    public static final String PASSWORD_STR = "password";

    @SerializedName(USER_NAME_STR)
    private String userName;

    @SerializedName(PASSWORD_STR)
    private String password;

    /**
     * @return the userName
     */
    public String getUserName() {
        return userName;
    }

    /**
     * @param userName
     *            the userName to set
     */
    public void setUserName(final String userName) {
        this.userName = userName;
    }

    /**
     * @return the password
     */
    public String getPassword() {
        return password;
    }

    /**
     * @param password
     *            the password to set
     */
    public void setPassword(final String password) {
        this.password = password;
    }

    /**
     * Gets the document form of given user.
     * 
     * @param user
     *            the user
     * @return the document
     */
    public static Document getDocument(final User user) {
        if (null == user) {
            return null;
        }

        final Document document = new Document();

        if (null != user.getUserName()) {
            document.append(USER_NAME_STR, user.getUserName());
        }

        if (null != user.getPassword()) {
            document.append(PASSWORD_STR, user.getPassword());
        }

        return document;
    }

    /**
     * Gets a list of documents given users.
     * 
     * @param users
     *            the users
     * @return a list of documents
     */
    public static List<Document> getDocument(final User... users) {
        if (null == users) {
            return null;
        }

        final List<Document> documentList = new ArrayList<Document>(users.length);
        for (final User user : users) {
            documentList.add(getDocument(user));
        }

        return documentList;
    }
}
