package com.uniken.domains.webservice.gm;

import org.bson.Document;

import com.google.gson.annotations.SerializedName;

/**
 * Session domain class.
 * 
 * @author Abhijit Daund
 */
public class Session {

    public static final String SESSION_ID_STR = "sessionId";

    @SerializedName(SESSION_ID_STR)
    private String sessionId;

    /**
     * @return the sessionId
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * @param sessionId
     *            the sessionId to set
     */
    public void setSessionId(final String sessionId) {
        this.sessionId = sessionId;
    }

    /**
     * Gets the document form of given session.
     * 
     * @param session
     *            the session
     * @return the document
     */
    public static Document getDocument(final Session session) {
        if (null == session) {
            return null;
        }

        final Document document = new Document();

        if (null != session.getSessionId()) {
            document.append(SESSION_ID_STR, session.getSessionId());
        }

        return document;
    }
}
