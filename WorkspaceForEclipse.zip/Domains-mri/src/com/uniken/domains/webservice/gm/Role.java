package com.uniken.domains.webservice.gm;

import java.util.ArrayList;
import java.util.List;

import org.bson.Document;

import com.google.gson.annotations.SerializedName;

/**
 * Role domain class.
 * 
 * @author Abhijit Daund
 */
public class Role {

    public static final String ROLE_STR = "role";

    @SerializedName(ROLE_STR)
    private String role;

    /**
     * @return the role
     */
    public String getRole() {
        return role;
    }

    /**
     * @param role
     *            the role to set
     */
    public void setRole(final String role) {
        this.role = role;
    }

    /**
     * Gets the document form of given role.
     * 
     * @param role
     *            the role
     * @return the document
     */
    public static Document getDocument(final Role role) {
        if (null == role) {
            return null;
        }

        final Document document = new Document();
        if (null != role.getRole()) {
            document.append(ROLE_STR, role.getRole());
        }

        return document;
    }

    /**
     * Gets a list of documents of given roles.
     * 
     * @param roles
     *            the roles
     * @return a list of documents
     */
    public static List<Document> getDocument(final Role... roles) {
        if (null == roles) {
            return null;
        }

        final List<Document> documentList = new ArrayList<Document>(roles.length);
        for (final Role role : roles) {
            documentList.add(getDocument(role));
        }

        return documentList;
    }
}
