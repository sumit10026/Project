package com.uniken.domains.webservice.gm;

import java.util.Date;
import java.util.List;

import org.bson.Document;
import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

/**
 * RelId user domain class.
 * 
 * @author Abhijit Daund
 */
public class RelIdUser extends WSRequest {

    public static final String FIRST_NAME = "firstName";
    public static final String LAST_NAME = "lastName";
    public static final String USER_ID_STR = "userId";
    public static final String GROUP_NAME_STR = "groupName";
    public static final String EMAIL_ID_STR = "emailId";
    public static final String MOBILE_NUMBER_STR = "mobileNumber";
    public static final String ACT_CODE_STR = "actCode";
    public static final String SECONDARY_GROUP_NAMES_STR = "secondaryGroupNames";
    public static final String STATUS_STR = "status";
    public static final String SESSION_ID_STR = "sessionId";
    public static final String LOGIN_ID_STR = "loginId";
    public static final String SOURCE_TYPE_STR = "sourceType";
    public static final String PREDEFINED_CODE_STR = "predefinedCode";
    public static final String PREDEFINED_VER_KEY_STR = "predefinedVerKey";
    public static final String PREDEFINED_CODE_EXPIRYTS_STR = "predefinedCodeExpiryTs";

    @SerializedName(FIRST_NAME)
    private String firstName;

    @SerializedName(LAST_NAME)
    private String lastName;

    @SerializedName(USER_ID_STR)
    private String userId;

    @SerializedName(LOGIN_ID_STR)
    private String loginId;

    @SerializedName(GROUP_NAME_STR)
    private String groupName;

    @SerializedName(EMAIL_ID_STR)
    private String emailId;

    @SerializedName(MOBILE_NUMBER_STR)
    private String mobileNumber;

    @SerializedName(ACT_CODE_STR)
    private String actCode;

    @SerializedName(SECONDARY_GROUP_NAMES_STR)
    private String secondaryGroupNames;

    @SerializedName(STATUS_STR)
    private String status;

    @SerializedName(SESSION_ID_STR)
    private String sessionId;

    @SerializedName(SOURCE_TYPE_STR)
    private String sourceType;

    @SerializedName(PREDEFINED_CODE_STR)
    private String predefinedCode;

    @SerializedName(PREDEFINED_VER_KEY_STR)
    private String predefinedVerKey;

    @SerializedName(PREDEFINED_CODE_EXPIRYTS_STR)
    private Date predefinedCodeExpiryTs;

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName
     *            the firstName to set
     */
    public void setFirstName(final String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName
     *            the lastName to set
     */
    public void setLastName(final String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userId
     *            the userId to set
     */
    public void setUserId(final String userId) {
        this.userId = userId;
    }

    /**
     * @return the loginId
     */
    public String getLoginId() {
        return loginId;
    }

    /**
     * @param loginId
     *            the loginId to set
     */
    public void setLoginId(final String loginId) {
        this.loginId = loginId;
    }

    /**
     * @return the groupName
     */
    public String getGroupName() {
        return groupName;
    }

    /**
     * @param groupName
     *            the groupName to set
     */
    public void setGroupName(final String groupName) {
        this.groupName = groupName;
    }

    /**
     * @return the emailId
     */
    public String getEmailId() {
        return emailId;
    }

    /**
     * @param emailId
     *            the emailId to set
     */
    public void setEmailId(final String emailId) {
        this.emailId = emailId;
    }

    /**
     * @return the mobileNumber
     */
    public String getMobileNumber() {
        return mobileNumber;
    }

    /**
     * @param mobileNumber
     *            the mobileNumber to set
     */
    public void setMobileNumber(final String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }

    /**
     * @return the actCode
     */
    public String getActCode() {
        return actCode;
    }

    /**
     * @param actCode
     *            the actCode to set
     */
    public void setActCode(final String actCode) {
        this.actCode = actCode;
    }

    /**
     * @return the secondaryGroupNames
     */
    public String getSecondaryGroupNames() {
        return secondaryGroupNames;
    }

    /**
     * @param secondaryGroupNames
     *            the secondaryGroupNames to set
     */
    public void setSecondaryGroupNames(final String secondaryGroupNames) {
        this.secondaryGroupNames = secondaryGroupNames;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status
     *            the status to set
     */
    public void setStatus(final String status) {
        this.status = status;
    }

    /**
     * @return the sessionId
     */
    public String getSessionId() {
        return sessionId;
    }

    /**
     * @param sessionId
     *            the sessionId to set
     */
    public void setSessionId(final String sessionId) {
        this.sessionId = sessionId;
    }

    /**
     * @return the sourceType
     */
    public String getSourceType() {
        return sourceType;
    }

    /**
     * @param sourceType
     *            the sourceType to set
     */
    public void setSourceType(final String sourceType) {
        this.sourceType = sourceType;
    }

    /**
     * @return the predefinedCode
     */
    public String getPredefinedCode() {
        return predefinedCode;
    }

    /**
     * @param predefinedCode
     *            the predefinedCode to set
     */
    public void setPredefinedCode(final String predefinedCode) {
        this.predefinedCode = predefinedCode;
    }

    /**
     * @return the predefinedVerKey
     */
    public String getPredefinedVerKey() {
        return predefinedVerKey;
    }

    /**
     * @param predefinedVerKey
     *            the predefinedVerKey to set
     */
    public void setPredefinedVerKey(final String predefinedVerKey) {
        this.predefinedVerKey = predefinedVerKey;
    }

    /**
     * @return the predefinedCodeExpiryTs
     */
    public Date getPredefinedCodeExpiryTs() {
        return predefinedCodeExpiryTs;
    }

    /**
     * @param predefinedCodeExpiryTs
     *            the predefinedCodeExpiryTs to set
     */
    public void setPredefinedCodeExpiryTs(final Date predefinedCodeExpiryTs) {
        this.predefinedCodeExpiryTs = predefinedCodeExpiryTs;
    }

    /**
     * Gets the document form of given relIdUser.
     * 
     * @param relIdUser
     *            the relIdUser
     * @return the document
     */
    public static Document getDocument(final RelIdUser relIdUser) {
        if (null == relIdUser) {
            return null;
        }

        final Document document = new Document();

        if (null != relIdUser.getUserId()) {
            document.append(USER_ID_STR, relIdUser.getUserId());
        }

        if (null != relIdUser.getGroupName()) {
            document.append(GROUP_NAME_STR, relIdUser.getGroupName());
        }

        if (null != relIdUser.getEmailId()) {
            document.append(EMAIL_ID_STR, relIdUser.getEmailId());
        }

        if (null != relIdUser.getMobileNumber()) {
            document.append(MOBILE_NUMBER_STR, relIdUser.getMobileNumber());
        }

        if (null != relIdUser.getActCode()) {
            document.append(ACT_CODE_STR, relIdUser.getActCode());
        }

        if (null != relIdUser.getSecondaryGroupNames()) {
            document.append(SECONDARY_GROUP_NAMES_STR, relIdUser.getSecondaryGroupNames());
        }

        if (null != relIdUser.getStatus()) {
            document.append(STATUS_STR, relIdUser.getStatus());
        }

        if (null != relIdUser.getSessionId()) {
            document.append(SESSION_ID_STR, relIdUser.getSessionId());
        }

        if (null != relIdUser.getSourceType()) {
            document.append(SOURCE_TYPE_STR, relIdUser.getSourceType());
        }

        if (null != relIdUser.getPredefinedCode()) {
            document.append(PREDEFINED_CODE_STR, relIdUser.getPredefinedCode());
        }

        if (null != relIdUser.getPredefinedVerKey()) {
            document.append(PREDEFINED_VER_KEY_STR, relIdUser.getPredefinedVerKey());
        }

        if (null != relIdUser.getPredefinedCodeExpiryTs()) {
            document.append(PREDEFINED_CODE_EXPIRYTS_STR, relIdUser.getPredefinedCodeExpiryTs());
        }

        return document;
    }

    private String groupUuid;

    private List<String> secondaryGroupUuidsList;

    private List<String> secondaryGroupNamesList;

    /**
     * @return the groupUuid
     */
    public String getGroupUuid() {
        return groupUuid;
    }

    /**
     * @param groupUuid
     *            the groupUuid to set
     */
    public void setGroupUuid(final String groupUuid) {
        this.groupUuid = groupUuid;
    }

    /**
     * @return the secondaryGroupUuidsList
     */
    public List<String> getSecondaryGroupUuidsList() {
        return secondaryGroupUuidsList;
    }

    /**
     * @param secondaryGroupUuidsList
     *            the secondaryGroupUuidsList to set
     */
    public void setSecondaryGroupUuidsList(final List<String> secondaryGroupUuidsList) {
        this.secondaryGroupUuidsList = secondaryGroupUuidsList;
    }

    /**
     * @return the secondaryGroupNamesList
     */
    public List<String> getSecondaryGroupNamesList() {
        return secondaryGroupNamesList;
    }

    /**
     * @param secondaryGroupNamesList
     *            the secondaryGroupNamesList to set
     */
    public void setSecondaryGroupNamesList(final List<String> secondaryGroupNamesList) {
        this.secondaryGroupNamesList = secondaryGroupNamesList;
    }

    public static final String USN_CHANGED = "usnChanged";
    public static final String DISTINGUISHED_NAME = "distinguishedName";

    @SerializedName(value = USN_CHANGED)
    @Field(USN_CHANGED)
    private Long usnChanged;

    @SerializedName(value = DISTINGUISHED_NAME)
    @Field(DISTINGUISHED_NAME)
    private String distinguishedName;

    /**
     * @return the usnChanged
     */
    public Long getUsnChanged() {
        return usnChanged;
    }

    /**
     * @param usnChanged
     *            the usnChanged to set
     */
    public void setUsnChanged(final Long usnChanged) {
        this.usnChanged = usnChanged;
    }

    /**
     * @return the distinguishedName
     */
    public String getDistinguishedName() {
        return distinguishedName;
    }

    /**
     * @param distinguishedName
     *            the distinguishedName to set
     */
    public void setDistinguishedName(final String distinguishedName) {
        this.distinguishedName = distinguishedName;
    }

}
