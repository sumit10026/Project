package com.uniken.domains.webservice.gm;

import com.google.gson.annotations.SerializedName;

/**
 * Web service request domain.
 * 
 * @author Abhijit Daund
 */
abstract class WSRequest {

    public static final String REQUEST_OWNER_STR = "requestOwner";

    @SerializedName(REQUEST_OWNER_STR)
    private String requestOwner;

    /**
     * @return the requestOwner
     */
    public String getRequestOwner() {
        return requestOwner;
    }

    /**
     * @param requestOwner
     *            the requestOwner to set
     */
    public void setRequestOwner(final String requestOwner) {
        this.requestOwner = requestOwner;
    }
}
