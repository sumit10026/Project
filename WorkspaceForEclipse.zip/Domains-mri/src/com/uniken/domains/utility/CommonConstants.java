/**
 * 
 */
package com.uniken.domains.utility;

/**
 * @author Kushal Jaiswal
 */
public class CommonConstants {

    public static final String SHA256 = "SHA-256";
    public static final String SHA512 = "SHA-512";
    public static final String SHA384 = "SHA-384";
    public static final String SHA1 = "SHA-1";

    public static final String AES = "AES";

    public static final String MD2 = "MD2";
    public static final String MD5 = "MD5";

    public static final String AES_CFB_NOPADDIND = "AES/CFB/NoPadding";
    public static final String AES_CFB_PKCS5PADDING = "AES/CFB/PKCS5Padding";

    public static final int BYTE_SIZE_128 = 128;
    public static final int BYTE_SIZE_192 = 192;
    public static final int BITS_IN_BYTES = 8;
}
