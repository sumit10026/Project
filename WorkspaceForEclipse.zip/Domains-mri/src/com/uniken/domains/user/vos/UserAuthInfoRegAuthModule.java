/**
 * 
 */
package com.uniken.domains.user.vos;

import java.util.Set;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.auth.RegisteredAuthenticationModule;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.relid.user.UserAuthInfo;

/**
 * @author Kushal Jaiswal
 */
public class UserAuthInfoRegAuthModule extends UserAuthInfo {

    public static final String REG_AUTHENTICATION_MODULE_STR = "reg_authentication_module";
    public static final String REG_AUTH_TYPE_STR = "reg_auth_types";

    @SerializedName(REG_AUTHENTICATION_MODULE_STR)
    @Field(REG_AUTHENTICATION_MODULE_STR)
    private RegisteredAuthenticationModule regAuthModule;

    @SerializedName(REG_AUTH_TYPE_STR)
    @Field(REG_AUTH_TYPE_STR)
    private Set<AuthType> regAuthTypes;

    /**
     * @return the regAuthModule
     */
    public RegisteredAuthenticationModule getRegAuthModule() {
        return regAuthModule;
    }

    /**
     * @param regAuthModule
     *            the regAuthModule to set
     */
    public void setRegAuthModule(final RegisteredAuthenticationModule regAuthModule) {
        this.regAuthModule = regAuthModule;
    }

    /**
     * @return the regAuthTypes
     */
    public Set<AuthType> getRegAuthTypes() {
        return regAuthTypes;
    }

    /**
     * @param regAuthTypes
     *            the regAuthTypes to set
     */
    public void setRegAuthTypes(final Set<AuthType> regAuthTypes) {
        this.regAuthTypes = regAuthTypes;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = super.hashCode();
        result = prime * result + ((regAuthModule == null) ? 0 : regAuthModule.hashCode());
        result = prime * result + ((regAuthTypes == null) ? 0 : regAuthTypes.hashCode());
        return result;
    }

    @Override
    public boolean equals(final Object obj) {
        if (this == obj)
            return true;
        if (!super.equals(obj))
            return false;
        if (getClass() != obj.getClass())
            return false;
        final UserAuthInfoRegAuthModule other = (UserAuthInfoRegAuthModule) obj;
        if (regAuthModule == null) {
            if (other.regAuthModule != null)
                return false;
        } else if (!regAuthModule.equals(other.regAuthModule))
            return false;
        if (regAuthTypes == null) {
            if (other.regAuthTypes != null)
                return false;
        } else if (!regAuthTypes.equals(other.regAuthTypes))
            return false;
        return true;
    }

}
