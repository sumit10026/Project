package com.uniken.domains.user.vos;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;

public class SecureCookie {
    public static final String SECURE_COOKIE_VALUE = "secure_cookie_value";
    public static final String SECURE_COOKIE_INFO = "secure_cookie_info";
    public static final String SECURE_COOKIE_CREATED_TS = "secure_cookie_created_ts";
    public static final String SECURE_COOKIE_UPDATED_TS = "secure_cookie_updated_ts";
    public static final String SECURE_COOKIE_EXPIRY_TS = "secure_cookie_expiry_ts";
    public static final String SECURE_COOKIE_MAX_AGE_IN_SECONDS = "secure_cookie_max_age_in_seconds";

    @SerializedName(value = SECURE_COOKIE_VALUE)
    @Field(SECURE_COOKIE_VALUE)
    private String secureCookieValue;

    @SerializedName(value = SECURE_COOKIE_INFO)
    @Field(SECURE_COOKIE_INFO)
    private String secureCookieInfo;

    @SerializedName(value = SECURE_COOKIE_CREATED_TS)
    @Field(SECURE_COOKIE_CREATED_TS)
    private Date secureCookieCreatedTs;

    @SerializedName(value = SECURE_COOKIE_UPDATED_TS)
    @Field(SECURE_COOKIE_UPDATED_TS)
    private Date secureCookieUpdatedTs;

    @SerializedName(value = SECURE_COOKIE_EXPIRY_TS)
    @Field(SECURE_COOKIE_EXPIRY_TS)
    private Date secureCookieExpiryTs;

    @SerializedName(value = SECURE_COOKIE_MAX_AGE_IN_SECONDS)
    @Field(SECURE_COOKIE_MAX_AGE_IN_SECONDS)
    private int secureCookieMaxAgeInSeconds;

    public String getSecureCookieValue() {
        return secureCookieValue;
    }

    public void setSecureCookieValue(final String secureCookieValue) {
        this.secureCookieValue = secureCookieValue;
    }

    public String getSecureCookieInfo() {
        return secureCookieInfo;
    }

    public void setSecureCookieInfo(final String secureCookieInfo) {
        this.secureCookieInfo = secureCookieInfo;
    }

    public Date getSecureCookieCreatedTs() {
        return secureCookieCreatedTs;
    }

    public void setSecureCookieCreatedTs(final Date secureCookieCreatedTs) {
        this.secureCookieCreatedTs = secureCookieCreatedTs;
    }

    public Date getSecureCookieUpdatedTs() {
        return secureCookieUpdatedTs;
    }

    public void setSecureCookieUpdatedTs(final Date secureCookieUpdatedTs) {
        this.secureCookieUpdatedTs = secureCookieUpdatedTs;
    }

    public Date getSecureCookieExpiryTs() {
        return secureCookieExpiryTs;
    }

    public void setSecureCookieExpiryTs(final Date secureCookieExpiryTs) {
        this.secureCookieExpiryTs = secureCookieExpiryTs;
    }

    public int getSecureCookieMaxAgeInSeconds() {
        return secureCookieMaxAgeInSeconds;
    }

    public void setSecureCookieMaxAgeInSeconds(final int secureCookieMaxAgeInSeconds) {
        this.secureCookieMaxAgeInSeconds = secureCookieMaxAgeInSeconds;
    }
}
