package com.uniken.domains.user.vos;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.data.mongodb.core.mapping.Field;

import com.google.gson.annotations.SerializedName;
import com.uniken.domains.auth.RegisteredAuthenticationModule;
import com.uniken.domains.enums.WebUserStatus;
import com.uniken.domains.enums.auth.AuthType;
import com.uniken.domains.relid.user.UserBrowser;

public class WebUserDetails {

    public static final String BROWSERS_STR = "browsers";
    public static final String ARCHIVE_BROWSERS = "archive_browsers";
    public static final String BLOCKED_TS = "blocked_ts";
    public static final String LAST_BLOCKED_METHOD = "last_blocked_method";
    public static final String LAST_BLOCKED_INTERVAL = "blocked_interval";
    public static final String WEB_USER_STATUS = "web_user_status";
    public static final String WEB_ATTEMPT_COUNTER = "web_attempt_counter";
    public static final String AUTH_GENERATION_ATTEMPT_COUNTER = "auth_generation_attempt_counter";
    public static final String ARCHIVE_REG_AUTHENTICATION_MODULE = "archive_reg_authentication_module";

    @SerializedName(BROWSERS_STR)
    @Field(BROWSERS_STR)
    private List<UserBrowser> browsers = new ArrayList<>();

    @SerializedName(ARCHIVE_BROWSERS)
    @Field(ARCHIVE_BROWSERS)
    private List<UserBrowser> archiveBrowsers = new ArrayList<>();

    @SerializedName(value = BLOCKED_TS)
    @Field(BLOCKED_TS)
    private Date blockedTs;

    @SerializedName(value = LAST_BLOCKED_METHOD)
    @Field(LAST_BLOCKED_METHOD)
    private String lastBlockedMethod;

    @SerializedName(value = LAST_BLOCKED_INTERVAL)
    @Field(LAST_BLOCKED_INTERVAL)
    private int lastBlockedInterval;

    @SerializedName(value = WEB_USER_STATUS)
    @Field(WEB_USER_STATUS)
    private WebUserStatus webUserStatus;

    @SerializedName(value = WEB_ATTEMPT_COUNTER)
    @Field(WEB_ATTEMPT_COUNTER)
    private List<Integer> webAttemptCounter = new ArrayList<>();

    @SerializedName(value = AUTH_GENERATION_ATTEMPT_COUNTER)
    @Field(AUTH_GENERATION_ATTEMPT_COUNTER)
    private Map<AuthType, Integer> authGenerationAttemptCounter = new HashMap<>();

    public Map<AuthType, Integer> getAuthGenerationAttemptCounter() {
        return authGenerationAttemptCounter;
    }

    public void setAuthGenerationAttemptCounter(final Map<AuthType, Integer> authGenerationAttemptCounter) {
        this.authGenerationAttemptCounter = authGenerationAttemptCounter;
    }

    @SerializedName(ARCHIVE_REG_AUTHENTICATION_MODULE)
    @Field(ARCHIVE_REG_AUTHENTICATION_MODULE)
    private List<RegisteredAuthenticationModule> archiveRegAuthModule = new ArrayList<>();

    public List<RegisteredAuthenticationModule> getArchiveRegAuthModule() {
        return archiveRegAuthModule;
    }

    public void setArchiveRegAuthModule(final List<RegisteredAuthenticationModule> archiveRegAuthModule) {
        this.archiveRegAuthModule = archiveRegAuthModule;
    }

    public Date getBlockedTs() {
        return blockedTs;
    }

    public void setBlockedTs(final Date blockedTs) {
        this.blockedTs = blockedTs;
    }

    public String getLastBlockedMethod() {
        return lastBlockedMethod;
    }

    public void setLastBlockedMethod(final String lastBlockedMethod) {
        this.lastBlockedMethod = lastBlockedMethod;
    }

    public int getLastBlockedInterval() {
        return lastBlockedInterval;
    }

    public void setLastBlockedInterval(final int lastBlockedInterval) {
        this.lastBlockedInterval = lastBlockedInterval;
    }

    public WebUserStatus getWebUserStatus() {
        return webUserStatus;
    }

    public void setWebUserStatus(final WebUserStatus webUserStatus) {
        this.webUserStatus = webUserStatus;
    }

    public List<Integer> getWebAttemptCounter() {
        return webAttemptCounter;
    }

    public void setWebAttemptCounter(final List<Integer> webAttemptCounter) {
        this.webAttemptCounter = webAttemptCounter;
    }

    public List<UserBrowser> getBrowsers() {
        return browsers;
    }

    public void setBrowsers(final List<UserBrowser> browsers) {
        this.browsers = browsers;
    }

    public List<UserBrowser> getArchiveBrowsers() {
        return archiveBrowsers;
    }

    public void setArchiveBrowsers(final List<UserBrowser> archiveBrowsers) {
        this.archiveBrowsers = archiveBrowsers;
    }

}
